// OILPULSE.OS — Supermodern Industrial Oil Pump Digital Twin & Animation Simulator
'use client';

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  calculatePumpPhysics, 
  DEFAULT_PUMP_PARAMS, 
  PumpParameters, 
  SimulationState, 
  PumpType 
} from '../lib/simulation/physics';
import { FLUID_DATABASE, FluidProperties } from '../lib/simulation/fluids';
import { MaterialPreset, VisualizationMode } from '../lib/three/materials';
import { ComponentMetadata } from '../lib/three/pumpBuilder';
import { INITIAL_DIGITAL_TWIN_PASSPORT } from '../lib/simulation/digitalTwin';
import { FAULT_SCENARIOS, FaultScenario } from '../lib/simulation/faults';
import { findOptimalBEP } from '../lib/simulation/optimizer';
import { pumpAudio } from '../lib/simulation/audio';

// Components
import { ModeNavigation, AppViewMode } from '../components/ModeNavigation';
import { HeroTelemetryOverlay } from '../components/HeroTelemetryOverlay';
import { TimelineController } from '../components/TimelineController';
import { ControlPanel } from '../components/ControlPanel';
import { PumpViewport } from '../components/PumpViewport';
import { PumpCurveLab } from '../components/PumpCurveLab';
import { ManufacturingTwin } from '../components/ManufacturingTwin';
import { FaultMaintenancePanel } from '../components/FaultMaintenancePanel';
import { MultiPumpFacility } from '../components/MultiPumpFacility';
import { EngineeringModal } from '../components/EngineeringModal';

export default function OilpulseApp() {
  // 1. Simulation Parameters
  const [params, setParams] = useState<PumpParameters>(DEFAULT_PUMP_PARAMS);
  const [simState, setSimState] = useState<SimulationState>(() => calculatePumpPhysics(DEFAULT_PUMP_PARAMS));
  
  // 2. Viewport & Rendering State
  const [viewMode, setViewMode] = useState<AppViewMode>('twin');
  const [materialPreset, setMaterialPreset] = useState<MaterialPreset>('cast-titanium');
  const [explodedProgress, setExplodedProgress] = useState<number>(0);
  const [selectedComponent, setSelectedComponent] = useState<ComponentMetadata | null>(null);

  // 3. UI Settings & Clocks
  const [unitSystem, setUnitSystem] = useState<'SI' | 'Imperial'>('SI');
  const [isAudioMuted, setIsAudioMuted] = useState<boolean>(true);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [simulationTime, setSimulationTime] = useState<number>(0);
  const [timeScale, setTimeScale] = useState<number>(1);
  const [isStarted, setIsStarted] = useState<boolean>(false);

  // 4. Digital Passport
  const [passport] = useState(INITIAL_DIGITAL_TWIN_PASSPORT);

  // Map AppViewMode to 3D VisualizationMode
  const get3DVizMode = (mode: AppViewMode): VisualizationMode => {
    switch (mode) {
      case 'cutaway': return 'cutaway';
      case 'xray': return 'xray';
      case 'flow': return 'flow';
      case 'pressure': return 'pressure';
      case 'thermal': return 'thermal';
      case 'vibration': return 'vibration';
      default: return 'standard';
    }
  };

  // Automated Simulation Loop (60 Hz)
  const lastTimeRef = useRef<number>(performance.now());
  useEffect(() => {
    let animationFrameId: number;

    const tick = (now: number) => {
      const deltaSec = Math.min(0.1, (now - lastTimeRef.current) / 1000);
      lastTimeRef.current = now;

      if (isPlaying) {
        setSimulationTime((prev) => prev + deltaSec * timeScale);

        // Smooth speed ramp towards target RPM
        setParams((current) => {
          if (Math.abs(current.currentRpm - current.targetRpm) > 1) {
            const rampStep = 450 * deltaSec * timeScale;
            const newRpm = current.currentRpm < current.targetRpm
              ? Math.min(current.targetRpm, current.currentRpm + rampStep)
              : Math.max(current.targetRpm, current.currentRpm - rampStep);
            return { ...current, currentRpm: newRpm };
          }
          return current;
        });
      }

      // Re-evaluate multi-physics state
      setSimState((_) => {
        const nextState = calculatePumpPhysics(params);
        // Audio synthesis update
        pumpAudio.updateAudio(nextState);
        return nextState;
      });

      animationFrameId = requestAnimationFrame(tick);
    };

    animationFrameId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animationFrameId);
  }, [isPlaying, timeScale, params]);

  // Audio Toggle
  const handleToggleAudio = useCallback(() => {
    const muted = pumpAudio.toggleMute();
    setIsAudioMuted(muted);
  }, []);

  // Update Parameters Callback
  const handleUpdateParams = useCallback((updated: Partial<PumpParameters>) => {
    setParams((prev) => ({ ...prev, ...updated }));
  }, []);

  // Start Simulation from Hero
  const handleStartSimulation = useCallback(() => {
    setIsStarted(true);
    setParams((prev) => ({ ...prev, targetRpm: 3600 }));
    if (isAudioMuted) {
      // Promptly initialize WebAudio context on user gesture
      const muted = pumpAudio.toggleMute();
      setIsAudioMuted(muted);
    }
  }, [isAudioMuted]);

  // Autonomous BEP Optimizer
  const handleOptimizeBEP = useCallback(() => {
    const opt = findOptimalBEP(params);
    setParams((prev) => ({
      ...prev,
      targetRpm: opt.optimalRpm,
      valveOpenPercent: opt.optimalValvePercent
    }));
  }, [params]);

  // Fault Injection
  const handleInjectFault = useCallback((scenario: FaultScenario) => {
    const mods = scenario.physicsModifications;
    setParams((prev) => ({
      ...prev,
      bearingWearFactor: mods.bearingWearFactor ?? 1.0,
      sealLeakageFactor: mods.sealLeakageFactor ?? 1.0,
      cavitationFactor: mods.cavitationFactor ?? 0.0,
      rotorImbalanceGrams: mods.rotorImbalanceGrams ?? 0.0,
      motorPhaseImbalance: mods.motorPhaseImbalance ?? 0.0,
      inletPressureBar: mods.inletPressureOffsetBar ? Math.max(0.2, prev.inletPressureBar + mods.inletPressureOffsetBar) : prev.inletPressureBar,
      fluidTempC: mods.fluidTempOffsetC ? prev.fluidTempC + mods.fluidTempOffsetC : prev.fluidTempC,
      valveOpenPercent: mods.valvePositionPercent ?? prev.valveOpenPercent
    }));
  }, []);

  const handleClearFaults = useCallback(() => {
    setParams((prev) => ({
      ...prev,
      targetRpm: 3600,
      inletPressureBar: 2.5,
      pipeBackpressureBar: 8.5,
      valveOpenPercent: 78,
      fluidTempC: 38,
      bearingWearFactor: 1.0,
      sealLeakageFactor: 1.0,
      rotorImbalanceGrams: 0.0,
      cavitationFactor: 0.0,
      motorPhaseImbalance: 0.0
    }));
  }, []);

  // Disassembly step in maintenance
  const handleMaintenanceDisassembly = useCallback((stepIdx: number) => {
    if (stepIdx === 0) setExplodedProgress(0.0);
    else if (stepIdx === 1) setExplodedProgress(0.25);
    else if (stepIdx === 2) setExplodedProgress(0.55);
    else if (stepIdx === 3) setExplodedProgress(0.85);
    else if (stepIdx === 4) setExplodedProgress(0.35);
    else setExplodedProgress(0.0);
  }, []);

  return (
    <main className="relative w-screen h-screen overflow-hidden flex flex-col bg-[#060709] text-white">
      {/* 1. Mode Navigation Header */}
      {viewMode !== 'cinematic' && (
        <ModeNavigation
          currentMode={viewMode}
          onSelectMode={(mode) => {
            setViewMode(mode);
            if (mode === 'exploded') {
              setExplodedProgress(0.75);
            }
          }}
        />
      )}

      {/* 2. Main Middle Stage Container */}
      <div className="relative flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* 3D Viewport Stage */}
        <div className="relative flex-1 h-full min-h-0">
          <PumpViewport
            simulationState={simState}
            pumpParams={params}
            vizMode={get3DVizMode(viewMode)}
            materialPreset={materialPreset}
            explodedProgress={explodedProgress}
            onExplodedChange={setExplodedProgress}
            onSelectComponentMeta={setSelectedComponent}
            selectedComponent={selectedComponent}
          />

          {/* Hero Telemetry Overlay on top of 3D Viewport */}
          {['twin', 'cutaway', 'xray', 'flow', 'pressure', 'thermal', 'vibration', 'cinematic'].includes(viewMode) && (
            <HeroTelemetryOverlay
              state={simState}
              unitSystem={unitSystem}
              onToggleUnit={() => setUnitSystem((prev) => (prev === 'SI' ? 'Imperial' : 'SI'))}
              onSelectFluid={(fluid) => setParams((p) => ({ ...p, fluidId: fluid.id }))}
              isAudioMuted={isAudioMuted}
              onToggleAudio={handleToggleAudio}
              onOpenOptimizer={handleOptimizeBEP}
              onStartSimulation={handleStartSimulation}
              isStarted={isStarted}
            />
          )}

          {/* Modal Overlay Views for Specialized Modes */}
          {viewMode === 'curves' && (
            <div className="absolute inset-0 z-30 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
              <PumpCurveLab state={simState} params={params} onUpdateParams={handleUpdateParams} />
            </div>
          )}

          {viewMode === 'manufacturing' && (
            <div className="absolute inset-0 z-30 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
              <ManufacturingTwin passport={passport} />
            </div>
          )}

          {viewMode === 'metrology' && (
            <div className="absolute inset-0 z-30 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
              <ManufacturingTwin passport={passport} />
            </div>
          )}

          {viewMode === 'faults' && (
            <div className="absolute inset-0 z-30 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
              <FaultMaintenancePanel
                currentParams={params}
                simulationState={simState}
                onInjectFault={handleInjectFault}
                onClearFaults={handleClearFaults}
                onTriggerMaintenanceDisassembly={handleMaintenanceDisassembly}
              />
            </div>
          )}

          {viewMode === 'facility' && (
            <div className="absolute inset-0 z-30 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
              <MultiPumpFacility
                leadPumpState={simState}
                onSelectPump={(id) => console.log('Selected pump:', id)}
              />
            </div>
          )}

          {viewMode === 'engineering' && (
            <div className="absolute inset-0 z-30 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
              <EngineeringModal state={simState} onClose={() => setViewMode('twin')} />
            </div>
          )}
        </div>

        {/* Engineering Parameter Controls Drawer */}
        {viewMode !== 'cinematic' && (
          <ControlPanel
            params={params}
            onUpdateParams={handleUpdateParams}
            materialPreset={materialPreset}
            onSetMaterial={setMaterialPreset}
            explodedProgress={explodedProgress}
            onSetExploded={setExplodedProgress}
            onOptimize={handleOptimizeBEP}
            onSelectFluid={(fluid) => setParams((p) => ({ ...p, fluidId: fluid.id }))}
          />
        )}
      </div>

      {/* 3. Bottom Timeline Scrubber */}
      {viewMode !== 'cinematic' && (
        <TimelineController
          simulationTime={simulationTime}
          timeScale={timeScale}
          isPlaying={isPlaying}
          onTogglePlay={() => setIsPlaying((p) => !p)}
          onReset={() => {
            setSimulationTime(0);
            setParams((p) => ({ ...p, currentRpm: 0, targetRpm: 0 }));
          }}
          onStep={() => setSimulationTime((t) => t + 0.2)}
          onSetTimeScale={setTimeScale}
          onScrubTime={(t) => {
            setSimulationTime(t);
            if (t < 3) setParams((p) => ({ ...p, targetRpm: 0 }));
            else if (t < 7) setParams((p) => ({ ...p, targetRpm: 1200 }));
            else if (t < 11) setParams((p) => ({ ...p, targetRpm: 2400 }));
            else setParams((p) => ({ ...p, targetRpm: 3600 }));
          }}
        />
      )}

      {/* Cinematic Mode Exit Button */}
      {viewMode === 'cinematic' && (
        <button
          onClick={() => setViewMode('twin')}
          className="absolute top-4 right-4 z-40 px-3 py-1.5 rounded text-xs font-tech glass-panel border border-white/20 text-gray-300 hover:text-white cursor-pointer"
        >
          EXIT CINEMATIC
        </button>
      )}
    </main>
  );
}
