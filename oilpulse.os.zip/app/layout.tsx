import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'OILPULSE.OS — Industrial Oil Pump Digital Twin',
  description: 'Supermodern Industrial Oil Pump Digital Twin & Physics Animation Simulator.',
  openGraph: {
    title: 'OILPULSE.OS — Industrial Oil Pump Digital Twin',
    description: 'Supermodern Industrial Oil Pump Digital Twin & Physics Animation Simulator.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'OILPULSE.OS — Industrial Oil Pump Digital Twin',
    description: 'Supermodern Industrial Oil Pump Digital Twin & Physics Animation Simulator.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
