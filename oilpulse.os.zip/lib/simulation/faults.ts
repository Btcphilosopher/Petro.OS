// OILPULSE.OS — Fault Injection & Diagnostics Scenarios

export interface FaultScenario {
  id: string;
  name: string;
  severity: 'minor' | 'moderate' | 'critical';
  description: string;
  physicsModifications: {
    bearingWearFactor?: number;
    sealLeakageFactor?: number;
    cavitationFactor?: number;
    rotorImbalanceGrams?: number;
    motorPhaseImbalance?: number;
    inletPressureOffsetBar?: number;
    fluidTempOffsetC?: number;
    valvePositionPercent?: number;
  };
  symptoms: string[];
  recommendedAction: string;
}

export const FAULT_SCENARIOS: Record<string, FaultScenario> = {
  'nominal': {
    id: 'nominal',
    name: 'Nominal Operational State',
    severity: 'minor',
    description: 'All mechanical clearances, bearings, seals, and fluid thermophysical parameters within factory tolerances.',
    physicsModifications: {
      bearingWearFactor: 1.0,
      sealLeakageFactor: 1.0,
      cavitationFactor: 0.0,
      rotorImbalanceGrams: 0.0,
      motorPhaseImbalance: 0.0
    },
    symptoms: ['Smooth harmonic vibration (< 2.3 mm/s RMS)', 'Thermal equilibrium maintained at ~68°C', 'Efficiency matching BEP design curve'],
    recommendedAction: 'Continue standard condition-based telemetry monitoring.'
  },
  'bearing-spall': {
    id: 'bearing-spall',
    name: 'Bearing Outer Race Spall (BPFO Defect)',
    severity: 'critical',
    description: 'Micro-fatigue flaking on outer raceway causing periodic impact shocks at 3.58× shaft frequency.',
    physicsModifications: {
      bearingWearFactor: 2.8,
      rotorImbalanceGrams: 4.5
    },
    symptoms: ['Sharp high-frequency spike at BPFO (214 Hz at 3600 RPM)', 'Bearing drive temperature surges toward 95°C+', 'Mechanical efficiency degraded by 8.5%'],
    recommendedAction: 'Schedule precision bearing replacement during next maintenance window. Apply synthetic high-film grease.'
  },
  'seal-failure': {
    id: 'seal-failure',
    name: 'Mechanical Seal Face Degradation',
    severity: 'moderate',
    description: 'Silicon carbide vs carbon stationary face gap enlarged by thermal distortion or particulate scoring.',
    physicsModifications: {
      sealLeakageFactor: 3.2
    },
    symptoms: ['Volumetric slip flow increased, lower differential head', 'Secondary containment pressure warning', 'Slight hydraulic pressure flutter'],
    recommendedAction: 'Inspect seal barrier fluid flush plan 53B and replace mechanical cartridge seal assembly.'
  },
  'cavitation-surge': {
    id: 'cavitation-surge',
    name: 'Net Positive Suction Head Cavitation',
    severity: 'critical',
    description: 'Suction pressure drops below vapor pressure, forming microscopic vapor bubbles that implode aggressively on impeller vanes.',
    physicsModifications: {
      cavitationFactor: 0.9,
      inletPressureOffsetBar: -1.8
    },
    symptoms: ['Acoustic crackle / gravel sound in pump casing', 'Severe pressure oscillation and erratic head loss', 'High blade-pass vibration harmonics'],
    recommendedAction: 'Increase suction vessel level, open inlet throttling valve, or reduce fluid temperature to lower vapor pressure.'
  },
  'suction-starvation': {
    id: 'suction-starvation',
    name: 'Inlet Strainer Cake Fouling',
    severity: 'moderate',
    description: 'Heavy asphaltene particulates and wax crystallization clogging the 40-mesh suction basket.',
    physicsModifications: {
      inletPressureOffsetBar: -2.2,
      cavitationFactor: 0.45
    },
    symptoms: ['High differential pressure across suction strainer', 'Reduced discharge flow volume', 'Low motor current due to partial pump unloading'],
    recommendedAction: 'Initiate automated duplex strainer backflush cycle or switch to parallel filter train.'
  },
  'rotor-unbalance': {
    id: 'rotor-unbalance',
    name: 'Impeller Dynamic Unbalance (18g)',
    severity: 'moderate',
    description: 'Asymmetric solid accumulation or partial erosion on impeller vane tip causing strong 1× rotational mass eccentricity.',
    physicsModifications: {
      rotorImbalanceGrams: 18.0
    },
    symptoms: ['High sinusoidal 1× RPM radial vibration (60 Hz)', 'Cyclic radial load fatigue on bearings', 'Observable mechanical skid wobble'],
    recommendedAction: 'Perform in-situ two-plane dynamic balancing or remove impeller for abrasive blast cleaning.'
  },
  'high-viscosity-cold': {
    id: 'high-viscosity-cold',
    name: 'Cold-Start High Viscosity Surge',
    severity: 'moderate',
    description: 'Fluid ambient temperature at 8°C causing exponential viscosity spike (over 850 cP) during initial start.',
    physicsModifications: {
      fluidTempOffsetC: -35.0
    },
    symptoms: ['Motor starting torque surges to 160% nominal', 'Severe viscous drag friction', 'Volumetric flow suppressed until thermal warmup'],
    recommendedAction: 'Engage steam tracing jackets or ramp VFD speed at 15% rate until fluid temperature reaches 45°C.'
  },
  'motor-phase-fault': {
    id: 'motor-phase-fault',
    name: 'Stator Winding Phase Imbalance (6%)',
    severity: 'critical',
    description: 'Unequal phase voltage / high winding resistance in Phase B generating negative sequence magnetic torque.',
    physicsModifications: {
      motorPhaseImbalance: 0.75
    },
    symptoms: ['High 2× line frequency electrical vibration (120 Hz)', 'Rapid stator core temperature rise (>105°C)', 'Pulsating shaft torque'],
    recommendedAction: 'Check VFD inverter bridge IGBT switching, inspect motor terminal box connections, and measure phase insulation resistance.'
  }
};
