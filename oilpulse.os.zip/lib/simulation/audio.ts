// OILPULSE.OS — Procedural Web Audio Sound Engine for Industrial Pump Physics

class PumpAudioEngine {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = true;
  private masterGain: GainNode | null = null;
  
  // Motor oscillator
  private motorOsc: OscillatorNode | null = null;
  private motorSubOsc: OscillatorNode | null = null;
  private motorGain: GainNode | null = null;
  
  // Fluid noise
  private fluidGain: GainNode | null = null;
  private fluidFilter: BiquadFilterNode | null = null;
  
  // Cavitation noise
  private cavitationGain: GainNode | null = null;
  
  // Bearing harmonic
  private bearingOsc: OscillatorNode | null = null;
  private bearingGain: GainNode | null = null;

  public init() {
    if (typeof window === 'undefined') return;
    if (this.ctx) return;
    
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(0.0, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);
      
      // Motor Tone
      this.motorOsc = this.ctx.createOscillator();
      this.motorOsc.type = 'sawtooth';
      this.motorOsc.frequency.setValueAtTime(60, this.ctx.currentTime);
      
      this.motorSubOsc = this.ctx.createOscillator();
      this.motorSubOsc.type = 'sine';
      this.motorSubOsc.frequency.setValueAtTime(30, this.ctx.currentTime);
      
      this.motorGain = this.ctx.createGain();
      this.motorGain.gain.setValueAtTime(0.04, this.ctx.currentTime);
      
      const motorFilter = this.ctx.createBiquadFilter();
      motorFilter.type = 'lowpass';
      motorFilter.frequency.setValueAtTime(450, this.ctx.currentTime);
      
      this.motorOsc.connect(motorFilter);
      this.motorSubOsc.connect(motorFilter);
      motorFilter.connect(this.motorGain);
      this.motorGain.connect(this.masterGain);
      
      this.motorOsc.start();
      this.motorSubOsc.start();
      
      // Fluid White/Pink Noise
      const bufferSize = this.ctx.sampleRate * 2;
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      let b0 = 0, b1 = 0, b2 = 0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        b0 = 0.99 * b0 + white * 0.05;
        b1 = 0.95 * b1 + white * 0.10;
        b2 = 0.85 * b2 + white * 0.20;
        output[i] = (b0 + b1 + b2) * 0.5;
      }
      
      const noiseSource = this.ctx.createBufferSource();
      noiseSource.buffer = noiseBuffer;
      noiseSource.loop = true;
      
      this.fluidFilter = this.ctx.createBiquadFilter();
      this.fluidFilter.type = 'bandpass';
      this.fluidFilter.frequency.setValueAtTime(600, this.ctx.currentTime);
      this.fluidFilter.Q.setValueAtTime(1.8, this.ctx.currentTime);
      
      this.fluidGain = this.ctx.createGain();
      this.fluidGain.gain.setValueAtTime(0.01, this.ctx.currentTime);
      
      noiseSource.connect(this.fluidFilter);
      this.fluidFilter.connect(this.fluidGain);
      this.fluidGain.connect(this.masterGain);
      noiseSource.start();
      
      // Bearing high frequency whine
      this.bearingOsc = this.ctx.createOscillator();
      this.bearingOsc.type = 'sine';
      this.bearingOsc.frequency.setValueAtTime(214, this.ctx.currentTime);
      
      this.bearingGain = this.ctx.createGain();
      this.bearingGain.gain.setValueAtTime(0.0, this.ctx.currentTime);
      
      this.bearingOsc.connect(this.bearingGain);
      this.bearingGain.connect(this.masterGain);
      this.bearingOsc.start();
      
      // Cavitation crackle
      this.cavitationGain = this.ctx.createGain();
      this.cavitationGain.gain.setValueAtTime(0.0, this.ctx.currentTime);
      const cavFilter = this.ctx.createBiquadFilter();
      cavFilter.type = 'highpass';
      cavFilter.frequency.setValueAtTime(1800, this.ctx.currentTime);
      noiseSource.connect(cavFilter);
      cavFilter.connect(this.cavitationGain);
      this.cavitationGain.connect(this.masterGain);
      
    } catch {
      // AudioContext unavailable or restricted
    }
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (!this.ctx || !this.masterGain) return;
    if (this.ctx.state === 'suspended' && !muted) {
      this.ctx.resume();
    }
    const targetGain = muted ? 0.0 : 0.45;
    this.masterGain.gain.setTargetAtTime(targetGain, this.ctx.currentTime, 0.08);
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public toggleMute(): boolean {
    if (!this.ctx) {
      this.init();
    }
    this.setMuted(!this.isMuted);
    return this.isMuted;
  }

  public updateAudio(state: { rpm: number; flowRateLpm: number; cavitationRisk: number }) {
    if (!this.ctx || this.isMuted) return;
    this.update(state.rpm, state.flowRateLpm, state.cavitationRisk, 1.0);
  }

  public update(rpm: number, flowLpm: number, cavitationRisk: number, bearingWear: number) {
    if (!this.ctx || this.isMuted || !this.masterGain) return;
    
    const now = this.ctx.currentTime;
    const baseFreq = Math.max(10, (rpm / 60) * 2); // 2-pole motor shaft fundamental
    
    if (this.motorOsc && this.motorSubOsc) {
      this.motorOsc.frequency.setTargetAtTime(baseFreq, now, 0.05);
      this.motorSubOsc.frequency.setTargetAtTime(baseFreq * 0.5, now, 0.05);
    }
    
    if (this.motorGain) {
      const motorVol = rpm > 50 ? Math.min(0.15, 0.02 + (rpm / 3600) * 0.12) : 0.0;
      this.motorGain.gain.setTargetAtTime(motorVol, now, 0.05);
    }
    
    if (this.fluidGain && this.fluidFilter) {
      const fluidVol = Math.min(0.20, (flowLpm / 1500) * 0.18);
      const centerFreq = 400 + (flowLpm / 1500) * 900;
      this.fluidGain.gain.setTargetAtTime(fluidVol, now, 0.08);
      this.fluidFilter.frequency.setTargetAtTime(centerFreq, now, 0.08);
    }
    
    if (this.bearingOsc && this.bearingGain) {
      const bpfoFreq = (rpm / 60) * 3.58;
      this.bearingOsc.frequency.setTargetAtTime(bpfoFreq, now, 0.05);
      const bearingVol = rpm > 50 ? Math.min(0.12, (bearingWear - 1.0) * 0.06) : 0;
      this.bearingGain.gain.setTargetAtTime(bearingVol, now, 0.05);
    }
    
    if (this.cavitationGain) {
      const cavVol = cavitationRisk > 0.2 ? Math.min(0.25, cavitationRisk * 0.22) : 0;
      this.cavitationGain.gain.setTargetAtTime(cavVol, now, 0.05);
    }
  }
}

export const pumpAudio = new PumpAudioEngine();
