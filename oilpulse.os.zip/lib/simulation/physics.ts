// OILPULSE.OS — Industrial Pump Physics Simulation Engine
import { FluidProperties, calculateViscosityAtTemp, calculateDensityAtTemp, FLUID_DATABASE } from './fluids';

export type PumpType = 'centrifugal' | 'gear' | 'screw' | 'piston';

export interface PumpGeometry {
  diameter: number; // m
  shaftDiameter: number; // mm
  impellerDiameter: number; // mm
  housingLength: number; // mm
  inletDiameter: number; // mm
  outletDiameter: number; // mm
  bladeCount?: number;
  gearTeethCount?: number;
  pistonStroke?: number; // mm
  pistonBore?: number; // mm
  displacementPerRev?: number; // cm³/rev
}

export interface MotorSpecs {
  ratedPowerKw: number;
  ratedRpm: number;
  polePairs: number;
  ratedEfficiency: number; // 0..1
  nominalVoltage: number; // V
  ratedCurrent: number; // A
  powerFactor: number;
}

export interface PumpParameters {
  pumpType: PumpType;
  targetRpm: number;
  currentRpm: number;
  inletPressureBar: number; // bar
  dischargePressureBar: number; // bar
  fluidId: string;
  customFluid?: FluidProperties;
  fluidTempC: number;
  ambientTempC: number;
  valveOpenPercent: number; // 0..100
  pipeBackpressureBar: number;
  simulationTime: number; // seconds elapsed
  timeScale: number; // 1x, 2x, etc.
  
  // Degradation / Fault factors (1.0 = nominal)
  bearingWearFactor: number; // >= 1.0
  sealLeakageFactor: number; // >= 1.0
  rotorImbalanceGrams: number; // 0 = perfectly balanced
  cavitationFactor: number; // 0..1
  motorPhaseImbalance: number; // 0..1
}

export const DEFAULT_PUMP_PARAMS: PumpParameters = {
  pumpType: 'centrifugal',
  targetRpm: 3600,
  currentRpm: 3600,
  inletPressureBar: 2.5,
  dischargePressureBar: 8.5,
  fluidId: 'iso-vg-46',
  fluidTempC: 38.0,
  ambientTempC: 22.0,
  valveOpenPercent: 78,
  pipeBackpressureBar: 8.5,
  simulationTime: 0,
  timeScale: 1.0,
  bearingWearFactor: 1.0,
  sealLeakageFactor: 1.0,
  rotorImbalanceGrams: 0.0,
  cavitationFactor: 0.0,
  motorPhaseImbalance: 0.0
};

export interface SimulationState {
  pumpType: PumpType;
  rpm: number;
  angularVelocityRadS: number;
  
  // Fluid dynamics
  fluid: FluidProperties;
  viscosityActual: number; // Pa·s
  densityActual: number; // kg/m³
  reynoldsNumber: number;
  flowRateLpm: number; // L/min
  flowRateM3h: number; // m³/h
  flowVelocityMs: number; // m/s in discharge
  
  // Pressures & Head
  inletPressureMpa: number;
  dischargePressureMpa: number;
  differentialPressureMpa: number;
  headMeters: number;
  npshAvailable: number; // m
  npshRequired: number; // m
  cavitationRisk: number; // 0..1 (0 = safe, 1 = severe cavitation)
  
  // Power & Mechanics
  torqueNm: number;
  hydraulicPowerKw: number;
  shaftPowerKw: number;
  electricalPowerKw: number;
  motorCurrentAmps: number;
  
  // Efficiencies
  hydraulicEfficiency: number; // 0..100%
  volumetricEfficiency: number; // 0..100%
  mechanicalEfficiency: number; // 0..100%
  overallEfficiency: number; // 0..100%
  
  // Thermal
  motorTempC: number;
  bearingDriveTempC: number;
  bearingPumpTempC: number;
  housingTempC: number;
  fluidDischargeTempC: number;
  thermalTransientProgress: number; // 0..1
  
  // Vibration & Diagnostics
  vibrationRmsMms: number; // mm/s RMS (ISO 10816)
  vibrationIsoZone: 'A' | 'B' | 'C' | 'D'; // A: Good, B: Acceptable, C: Warning, D: Danger
  vibrationFft: {
    freq1xHz: number;
    amp1x: number;
    freq2xHz: number;
    amp2x: number;
    bladePassFreqHz: number;
    bladePassAmp: number;
    bearingBpfoHz: number;
    bearingBpfoAmp: number;
  };
  displacementJitter: { x: number; y: number; z: number };
  
  // Flow Particles & Visual multipliers
  particleSpeedMultiplier: number;
  particleDensityMultiplier: number;
  pressureVisualField: number; // 0..1
  streamlineTension: number;
  
  // Health & Operating state
  healthScore: number; // 0..100%
  stateTag: 'DORMANT' | 'STARTING' | 'RUNNING' | 'WARNING' | 'FAULT' | 'CAVITATING';
}

export const DEFAULT_GEOMETRY: Record<PumpType, PumpGeometry> = {
  centrifugal: {
    diameter: 0.58,
    shaftDiameter: 48,
    impellerDiameter: 265,
    housingLength: 820,
    inletDiameter: 125,
    outletDiameter: 80,
    bladeCount: 6
  },
  gear: {
    diameter: 0.42,
    shaftDiameter: 38,
    impellerDiameter: 160,
    housingLength: 640,
    inletDiameter: 100,
    outletDiameter: 75,
    gearTeethCount: 14,
    displacementPerRev: 180 // cm³/rev
  },
  screw: {
    diameter: 0.46,
    shaftDiameter: 42,
    impellerDiameter: 180,
    housingLength: 950,
    inletDiameter: 150,
    outletDiameter: 100,
    displacementPerRev: 320
  },
  piston: {
    diameter: 0.52,
    shaftDiameter: 55,
    impellerDiameter: 200,
    housingLength: 880,
    inletDiameter: 125,
    outletDiameter: 80,
    pistonStroke: 90,
    pistonBore: 70
  }
};

export const DEFAULT_MOTOR: MotorSpecs = {
  ratedPowerKw: 55.0,
  ratedRpm: 3600,
  polePairs: 1,
  ratedEfficiency: 0.942,
  nominalVoltage: 400,
  ratedCurrent: 98.5,
  powerFactor: 0.88
};

/**
 * Executes a full step of the multi-physics simulation model
 */
export function calculatePumpPhysics(
  params: PumpParameters,
  geometry: PumpGeometry = DEFAULT_GEOMETRY[params.pumpType],
  motor: MotorSpecs = DEFAULT_MOTOR
): SimulationState {
  const g = 9.80665;
  const fluid = params.customFluid || FLUID_DATABASE[params.fluidId] || FLUID_DATABASE['iso-vg-46'];
  
  // Calculate temperature-dependent fluid properties
  const tempFluid = Math.max(5, params.fluidTempC);
  const mu = calculateViscosityAtTemp(fluid, tempFluid); // Pa·s
  const rho = calculateDensityAtTemp(fluid, tempFluid); // kg/m³
  const kinematicViscosity = mu / rho; // m²/s
  
  const rpm = Math.max(0, params.currentRpm);
  const omega = (rpm * 2 * Math.PI) / 60; // rad/s
  const speedRatio = motor.ratedRpm > 0 ? rpm / motor.ratedRpm : 0;
  
  let flowRateLpm = 0;
  let headMeters = 0;
  let differentialPressureMpa = 0;
  let hydraulicEfficiency = 0;
  let volumetricEfficiency = 0.96;
  
  // Valve & throttling resistance
  const valveFraction = Math.max(0.01, params.valveOpenPercent / 100);
  const valveResistanceFactor = Math.pow(1 / valveFraction, 1.8);
  const backpressureMpa = params.pipeBackpressureBar * 0.1;
  const inletMpa = params.inletPressureBar * 0.1;

  if (rpm <= 10) {
    // Dormant / Stopped state
    differentialPressureMpa = 0;
    headMeters = 0;
    flowRateLpm = 0;
    hydraulicEfficiency = 0;
    volumetricEfficiency = 0;
  } else if (params.pumpType === 'centrifugal') {
    // Centrifugal Pump Physics (Affinity Laws & H-Q polynomial)
    // Rated Head at nominal RPM: H0 ~ 110m, Qmax ~ 1600 L/min
    const H0 = 105.0 * Math.pow(speedRatio, 2);
    const Qmax = 1450.0 * speedRatio;
    
    // Viscosity correction factor (ANSI/HI 9.6.7 viscosity derating)
    const viscRatio = Math.max(1, mu / 0.001); // relative to water
    const viscosityDerate = 1 / (1 + 0.18 * Math.log10(viscRatio));
    
    // Operating flow calculation based on system curve vs pump curve intersection
    // H_pump(Q) = H0 - A * Q^2
    // H_sys(Q) = H_static + B * valveResistance * Q^2
    const H_static = Math.max(5, (backpressureMpa - inletMpa) * 1e6 / (rho * g));
    const A_pump = (H0 * 0.45) / Math.pow(Math.max(10, Qmax), 2);
    const B_sys = 0.000045 * valveResistanceFactor;
    
    if (H0 > H_static) {
      const Q_operating = Math.sqrt(Math.max(0, (H0 - H_static) / (A_pump + B_sys)));
      flowRateLpm = Math.min(Qmax, Q_operating) * viscosityDerate;
      headMeters = Math.max(0, H0 - A_pump * Math.pow(flowRateLpm, 2));
    } else {
      flowRateLpm = 0;
      headMeters = H0;
    }
    
    differentialPressureMpa = (rho * g * headMeters) / 1e6;
    
    // Efficiency peak at BEP (approx 72% of Qmax)
    const bepFlow = Qmax * 0.72;
    const flowDeviation = bepFlow > 0 ? (flowRateLpm - bepFlow) / bepFlow : 1;
    const peakHydEff = 0.88 * viscosityDerate;
    hydraulicEfficiency = Math.max(0.1, peakHydEff * (1 - 1.2 * Math.pow(flowDeviation, 2))) * 100;
    volumetricEfficiency = 97.5;
    
  } else if (params.pumpType === 'gear') {
    // External Rotary Gear Pump (Positive Displacement)
    const displacement = (geometry.displacementPerRev || 180) * 1e-6; // m³/rev
    const theoreticalQ_m3s = displacement * (rpm / 60);
    const theoreticalQ_lpm = theoreticalQ_m3s * 60000;
    
    // Slip flow: Q_slip = C_slip * DeltaP / mu
    const targetDeltaP = Math.max(0.2, (params.dischargePressureBar - params.inletPressureBar) * 0.1);
    differentialPressureMpa = targetDeltaP * (0.3 + 0.7 * speedRatio) * Math.min(1.5, valveResistanceFactor * 0.4);
    
    const slipCoeff = 0.0000015 * params.sealLeakageFactor;
    const slipFlowLpm = (slipCoeff * differentialPressureMpa * 1e6 / mu) * 60000;
    flowRateLpm = Math.max(0, theoreticalQ_lpm - slipFlowLpm);
    headMeters = (differentialPressureMpa * 1e6) / (rho * g);
    
    volumetricEfficiency = theoreticalQ_lpm > 0 ? Math.min(99, Math.max(30, (flowRateLpm / theoreticalQ_lpm) * 100)) : 0;
    hydraulicEfficiency = 89.0 - (0.05 * differentialPressureMpa);
    
  } else if (params.pumpType === 'screw') {
    // Twin Screw Positive Displacement Pump (High pressure, wide viscosity range)
    const displacement = (geometry.displacementPerRev || 320) * 1e-6;
    const theoreticalQ_lpm = displacement * (rpm / 60) * 60000;
    
    differentialPressureMpa = Math.max(0.3, (params.dischargePressureBar - params.inletPressureBar) * 0.1) * Math.min(1.4, valveResistanceFactor * 0.35);
    const slipFlowLpm = (0.0000008 * params.sealLeakageFactor * differentialPressureMpa * 1e6 / Math.sqrt(mu)) * 60000;
    flowRateLpm = Math.max(0, theoreticalQ_lpm - slipFlowLpm);
    headMeters = (differentialPressureMpa * 1e6) / (rho * g);
    
    volumetricEfficiency = theoreticalQ_lpm > 0 ? Math.min(98.5, Math.max(40, (flowRateLpm / theoreticalQ_lpm) * 100)) : 0;
    hydraulicEfficiency = 86.5;
    
  } else {
    // Reciprocating Piston Pump
    const strokeM = (geometry.pistonStroke || 90) / 1000;
    const boreM = (geometry.pistonBore || 70) / 1000;
    const areaM2 = Math.PI * Math.pow(boreM / 2, 2);
    const numCylinders = 3; // Triplex
    const displacementM3 = areaM2 * strokeM * numCylinders;
    const theoreticalQ_lpm = displacementM3 * (rpm / 60) * 60000;
    
    differentialPressureMpa = Math.max(0.5, (params.dischargePressureBar - params.inletPressureBar) * 0.1) * Math.min(2.0, valveResistanceFactor * 0.5);
    const valveLossLpm = theoreticalQ_lpm * (0.04 * params.sealLeakageFactor);
    flowRateLpm = Math.max(0, theoreticalQ_lpm - valveLossLpm);
    headMeters = (differentialPressureMpa * 1e6) / (rho * g);
    
    volumetricEfficiency = Math.max(50, 96.0 - (2.0 * params.sealLeakageFactor));
    hydraulicEfficiency = 91.0;
  }
  
  const dischargeMpa = inletMpa + differentialPressureMpa;
  const flowRateM3s = (flowRateLpm / 60000);
  const flowRateM3h = flowRateLpm * 0.06;
  
  // Velocity in discharge nozzle
  const dischargeRadiusM = (geometry.outletDiameter / 2) / 1000;
  const dischargeAreaM2 = Math.PI * Math.pow(dischargeRadiusM, 2);
  const flowVelocityMs = dischargeAreaM2 > 0 ? flowRateM3s / dischargeAreaM2 : 0;
  
  // Reynolds number Re = (rho * v * D) / mu
  const reynoldsNumber = mu > 0 ? (rho * flowVelocityMs * (geometry.outletDiameter / 1000)) / mu : 0;
  
  // NPSH and Cavitation
  const vapourPressurePa = fluid.vapourPressure * 1000;
  const inletPressurePa = inletMpa * 1e6;
  const suctionVelocityMs = flowRateM3s / (Math.PI * Math.pow((geometry.inletDiameter / 2) / 1000, 2));
  const npshAvailable = Math.max(0.1, (inletPressurePa - vapourPressurePa) / (rho * g) + Math.pow(suctionVelocityMs, 2) / (2 * g));
  const npshRequired = Math.max(1.2, 1.8 * Math.pow(speedRatio, 1.4) * Math.pow(Math.max(0.1, flowRateLpm / 1000), 0.6));
  
  const cavitationMargin = npshAvailable - npshRequired;
  let cavitationRisk = 0;
  if (cavitationMargin < 0.5 || params.cavitationFactor > 0.3) {
    cavitationRisk = Math.min(1.0, Math.max(0, (1.2 - cavitationMargin) / 1.5 + params.cavitationFactor));
  }
  
  // Power & Torque Calculations
  const hydraulicPowerW = flowRateM3s * (differentialPressureMpa * 1e6);
  const hydraulicPowerKw = hydraulicPowerW / 1000;
  
  // Mechanical friction: bearings, seals, viscous drag
  const bearingLossKw = (0.85 + 0.45 * Math.pow(speedRatio, 1.5)) * params.bearingWearFactor;
  const sealLossKw = (0.35 + 0.20 * speedRatio) * params.sealLeakageFactor;
  const viscousDragLossKw = 0.6 * (mu / 0.05) * Math.pow(speedRatio, 2);
  const mechanicalLossKw = (bearingLossKw + sealLossKw + viscousDragLossKw) * (rpm > 0 ? 1 : 0);
  
  const hydEffFraction = Math.max(0.1, hydraulicEfficiency / 100);
  const shaftPowerKw = rpm > 0 ? (hydraulicPowerKw / hydEffFraction) + mechanicalLossKw : 0;
  
  // Motor electrical power & current
  const motorEff = Math.max(0.5, motor.ratedEfficiency * (0.8 + 0.2 * Math.min(1, shaftPowerKw / motor.ratedPowerKw)));
  const electricalPowerKw = shaftPowerKw > 0 ? shaftPowerKw / motorEff : 0.05;
  const motorCurrentAmps = (electricalPowerKw * 1000) / (Math.sqrt(3) * motor.nominalVoltage * motor.powerFactor);
  
  // Torque (N·m)
  const torqueNm = omega > 0 ? (shaftPowerKw * 1000) / omega : 0;
  
  // Overall Efficiency
  const overallEfficiency = electricalPowerKw > 0 ? Math.min(95, Math.max(0, (hydraulicPowerKw / electricalPowerKw) * 100)) : 0;
  const mechanicalEfficiency = shaftPowerKw > 0 ? Math.min(98, Math.max(40, ((shaftPowerKw - mechanicalLossKw) / shaftPowerKw) * 100)) : 0;
  
  // Thermal Simulation with transient time constant (~180 seconds to equilibrium)
  const thermalTau = 160.0;
  const timeProgress = Math.min(1.0, params.simulationTime / thermalTau);
  const thermalTransientProgress = 1.0 - Math.exp(-params.simulationTime / thermalTau);
  
  const heatGenMotorKw = electricalPowerKw - shaftPowerKw;
  const heatGenPumpKw = shaftPowerKw - hydraulicPowerKw;
  
  const ambient = params.ambientTempC;
  const motorTempC = ambient + (heatGenMotorKw * 6.5 * (1 + params.motorPhaseImbalance * 0.8)) * thermalTransientProgress;
  const bearingDriveTempC = ambient + (bearingLossKw * 18.0 * params.bearingWearFactor) * thermalTransientProgress;
  const bearingPumpTempC = ambient + (bearingLossKw * 14.0 + (tempFluid - ambient) * 0.3) * thermalTransientProgress;
  const housingTempC = (tempFluid * 0.7 + ambient * 0.3) + (heatGenPumpKw * 1.8) * thermalTransientProgress;
  const fluidDischargeTempC = tempFluid + (hydraulicPowerKw > 0 ? (heatGenPumpKw / (rho * (flowRateM3s || 0.0001) * fluid.specificHeat)) : 0);
  
  // Vibration Spectrum Calculation (ISO 10816-3 Classification)
  const baseFreq1x = rpm / 60; // Hz
  const bladePassFreq = baseFreq1x * (geometry.bladeCount || geometry.gearTeethCount || 6);
  const bearingBpfoFreq = baseFreq1x * 3.58; // Ball pass outer race frequency
  
  const amp1x = (0.65 * Math.pow(speedRatio, 1.8) + (params.rotorImbalanceGrams / 8.0)) * (rpm > 0 ? 1 : 0);
  const amp2x = (0.35 * Math.pow(speedRatio, 1.6)) * (rpm > 0 ? 1 : 0);
  const bladePassAmp = (0.40 * Math.pow(speedRatio, 2.0) + cavitationRisk * 1.8) * (rpm > 0 ? 1 : 0);
  const bearingBpfoAmp = (0.25 + (params.bearingWearFactor - 1.0) * 2.2) * (rpm > 0 ? 1 : 0);
  
  const totalVibRms = Math.sqrt(
    Math.pow(amp1x, 2) + Math.pow(amp2x, 2) + Math.pow(bladePassAmp, 2) + Math.pow(bearingBpfoAmp, 2)
  );
  
  let vibrationIsoZone: 'A' | 'B' | 'C' | 'D' = 'A';
  if (totalVibRms < 2.3) vibrationIsoZone = 'A'; // Good
  else if (totalVibRms < 4.5) vibrationIsoZone = 'B'; // Acceptable
  else if (totalVibRms < 7.1) vibrationIsoZone = 'C'; // Warning
  else vibrationIsoZone = 'D'; // Danger
  
  // Instantaneous spatial displacement oscillation
  const oscPhase = params.simulationTime * omega;
  const displacementJitter = {
    x: Math.sin(oscPhase) * (amp1x * 0.0008),
    y: Math.cos(oscPhase) * (amp1x * 0.0008),
    z: Math.sin(oscPhase * 3.58) * (bearingBpfoAmp * 0.0004)
  };
  
  // Health Score (0 - 100%)
  let healthScore = 100.0;
  healthScore -= (params.bearingWearFactor - 1.0) * 28.0;
  healthScore -= (params.sealLeakageFactor - 1.0) * 22.0;
  healthScore -= cavitationRisk * 30.0;
  healthScore -= params.motorPhaseImbalance * 20.0;
  healthScore -= (params.rotorImbalanceGrams / 20.0) * 15.0;
  if (motorTempC > 95) healthScore -= (motorTempC - 95) * 1.5;
  healthScore = Math.max(5, Math.min(100, Math.round(healthScore)));
  
  // State Tag
  let stateTag: SimulationState['stateTag'] = 'RUNNING';
  if (rpm <= 10) stateTag = 'DORMANT';
  else if (rpm < params.targetRpm * 0.95 && params.simulationTime < 8) stateTag = 'STARTING';
  else if (cavitationRisk > 0.6) stateTag = 'CAVITATING';
  else if (healthScore < 40 || vibrationIsoZone === 'D') stateTag = 'FAULT';
  else if (healthScore < 70 || vibrationIsoZone === 'C') stateTag = 'WARNING';
  
  return {
    pumpType: params.pumpType,
    rpm,
    angularVelocityRadS: omega,
    fluid,
    viscosityActual: mu,
    densityActual: rho,
    reynoldsNumber,
    flowRateLpm: Math.round(flowRateLpm * 10) / 10,
    flowRateM3h: Math.round(flowRateM3h * 100) / 100,
    flowVelocityMs: Math.round(flowVelocityMs * 100) / 100,
    inletPressureMpa: Math.round(inletMpa * 100) / 100,
    dischargePressureMpa: Math.round(dischargeMpa * 100) / 100,
    differentialPressureMpa: Math.round(differentialPressureMpa * 100) / 100,
    headMeters: Math.round(headMeters * 10) / 10,
    npshAvailable: Math.round(npshAvailable * 100) / 100,
    npshRequired: Math.round(npshRequired * 100) / 100,
    cavitationRisk: Math.round(cavitationRisk * 100) / 100,
    torqueNm: Math.round(torqueNm * 10) / 10,
    hydraulicPowerKw: Math.round(hydraulicPowerKw * 100) / 100,
    shaftPowerKw: Math.round(shaftPowerKw * 100) / 100,
    electricalPowerKw: Math.round(electricalPowerKw * 100) / 100,
    motorCurrentAmps: Math.round(motorCurrentAmps * 10) / 10,
    hydraulicEfficiency: Math.round(hydraulicEfficiency * 10) / 10,
    volumetricEfficiency: Math.round(volumetricEfficiency * 10) / 10,
    mechanicalEfficiency: Math.round(mechanicalEfficiency * 10) / 10,
    overallEfficiency: Math.round(overallEfficiency * 10) / 10,
    motorTempC: Math.round(motorTempC * 10) / 10,
    bearingDriveTempC: Math.round(bearingDriveTempC * 10) / 10,
    bearingPumpTempC: Math.round(bearingPumpTempC * 10) / 10,
    housingTempC: Math.round(housingTempC * 10) / 10,
    fluidDischargeTempC: Math.round(fluidDischargeTempC * 10) / 10,
    thermalTransientProgress,
    vibrationRmsMms: Math.round(totalVibRms * 100) / 100,
    vibrationIsoZone,
    vibrationFft: {
      freq1xHz: Math.round(baseFreq1x * 10) / 10,
      amp1x: Math.round(amp1x * 100) / 100,
      freq2xHz: Math.round(baseFreq1x * 20) / 10,
      amp2x: Math.round(amp2x * 100) / 100,
      bladePassFreqHz: Math.round(bladePassFreq * 10) / 10,
      bladePassAmp: Math.round(bladePassAmp * 100) / 100,
      bearingBpfoHz: Math.round(bearingBpfoFreq * 10) / 10,
      bearingBpfoAmp: Math.round(bearingBpfoAmp * 100) / 100
    },
    displacementJitter,
    particleSpeedMultiplier: Math.max(0.05, flowVelocityMs / 2.8),
    particleDensityMultiplier: Math.min(2.5, Math.max(0.2, (flowRateLpm / 800) * (mu / 0.05))),
    pressureVisualField: Math.min(1.0, differentialPressureMpa / 12.0),
    streamlineTension: Math.min(1.0, differentialPressureMpa / 8.0),
    healthScore,
    stateTag
  };
}
