// OILPULSE.OS — Fluid Database & Thermodynamics

export interface FluidProperties {
  id: string;
  name: string;
  category: 'crude' | 'fuel' | 'lubricant' | 'hydraulic' | 'synthetic' | 'heavy' | 'custom';
  density: number; // kg/m³ at 20°C
  dynamicViscosity20C: number; // Pa·s (1 Pa·s = 1000 cP)
  dynamicViscosity80C: number; // Pa·s
  viscosityIndex: number;
  specificHeat: number; // J/(kg·K)
  thermalConductivity: number; // W/(m·K)
  vapourPressure: number; // kPa at 20°C
  bulkModulus: number; // GPa
  colorHex: string;
  colorSecondaryHex: string;
  particleOpacity: number;
  description: string;
}

export const FLUID_DATABASE: Record<string, FluidProperties> = {
  'crude-light': {
    id: 'crude-light',
    name: 'Light Crude Oil (Brent API 38.3°)',
    category: 'crude',
    density: 835,
    dynamicViscosity20C: 0.0072, // 7.2 cP
    dynamicViscosity80C: 0.0018,
    viscosityIndex: 110,
    specificHeat: 2050,
    thermalConductivity: 0.135,
    vapourPressure: 28.5,
    bulkModulus: 1.45,
    colorHex: '#c28522',
    colorSecondaryHex: '#784606',
    particleOpacity: 0.85,
    description: 'Low-density, sweet paraffinic crude with low sulfur content and rapid fluid shear.'
  },
  'crude-heavy': {
    id: 'crude-heavy',
    name: 'Heavy Crude Oil (Maya API 21.8°)',
    category: 'crude',
    density: 923,
    dynamicViscosity20C: 0.420, // 420 cP
    dynamicViscosity80C: 0.038,
    viscosityIndex: 85,
    specificHeat: 1890,
    thermalConductivity: 0.128,
    vapourPressure: 8.2,
    bulkModulus: 1.62,
    colorHex: '#3b200b',
    colorSecondaryHex: '#180c03',
    particleOpacity: 0.95,
    description: 'High-viscosity asphaltene-rich crude requiring significant positive displacement torque.'
  },
  'diesel': {
    id: 'diesel',
    name: 'Ultra-Low Sulfur Diesel (ULSD No. 2)',
    category: 'fuel',
    density: 840,
    dynamicViscosity20C: 0.0034, // 3.4 cP
    dynamicViscosity80C: 0.0011,
    viscosityIndex: 125,
    specificHeat: 2180,
    thermalConductivity: 0.142,
    vapourPressure: 0.4,
    bulkModulus: 1.50,
    colorHex: '#eab308',
    colorSecondaryHex: '#a16207',
    particleOpacity: 0.70,
    description: 'Distillate hydrocarbon with low shear resistance and high volumetric pumpability.'
  },
  'iso-vg-46': {
    id: 'iso-vg-46',
    name: 'Industrial Lube ISO VG 46',
    category: 'lubricant',
    density: 875,
    dynamicViscosity20C: 0.105, // 105 cP
    dynamicViscosity80C: 0.012,
    viscosityIndex: 102,
    specificHeat: 1970,
    thermalConductivity: 0.131,
    vapourPressure: 0.01,
    bulkModulus: 1.70,
    colorHex: '#d97706',
    colorSecondaryHex: '#92400e',
    particleOpacity: 0.82,
    description: 'Standard bearing and circulating oil with high anti-wear and thermal oxidation stability.'
  },
  'hydraulic-vg-32': {
    id: 'hydraulic-vg-32',
    name: 'Hydraulic Fluid ISO VG 32 (HM/HV)',
    category: 'hydraulic',
    density: 865,
    dynamicViscosity20C: 0.068, // 68 cP
    dynamicViscosity80C: 0.009,
    viscosityIndex: 145,
    specificHeat: 2020,
    thermalConductivity: 0.133,
    vapourPressure: 0.005,
    bulkModulus: 1.75,
    colorHex: '#f59e0b',
    colorSecondaryHex: '#b45309',
    particleOpacity: 0.75,
    description: 'High-VI mineral hydraulic oil engineered for high-pressure power transmission and zero foam.'
  },
  'synthetic-5w40': {
    id: 'synthetic-5w40',
    name: 'Synthetic Polyalphaolefin 5W-40',
    category: 'synthetic',
    density: 852,
    dynamicViscosity20C: 0.145,
    dynamicViscosity80C: 0.014,
    viscosityIndex: 172,
    specificHeat: 2150,
    thermalConductivity: 0.138,
    vapourPressure: 0.001,
    bulkModulus: 1.68,
    colorHex: '#e18700',
    colorSecondaryHex: '#854d0e',
    particleOpacity: 0.80,
    description: 'PAO group IV synthetic formulation for severe thermal gradients and wide operating ranges.'
  },
  'trans-heavy': {
    id: 'trans-heavy',
    name: 'Heavy Gear Oil ISO VG 220',
    category: 'heavy',
    density: 895,
    dynamicViscosity20C: 0.580,
    dynamicViscosity80C: 0.032,
    viscosityIndex: 95,
    specificHeat: 1850,
    thermalConductivity: 0.126,
    vapourPressure: 0.002,
    bulkModulus: 1.82,
    colorHex: '#713f12',
    colorSecondaryHex: '#451a03',
    particleOpacity: 0.90,
    description: 'Extreme-pressure gear lubricant engineered for severe shock loading and high tooth mesh stress.'
  },
  'bitumen-cutback': {
    id: 'bitumen-cutback',
    name: 'Bitumen Asphalt Cutback RC-250',
    category: 'heavy',
    density: 980,
    dynamicViscosity20C: 1.850, // 1850 cP
    dynamicViscosity80C: 0.095,
    viscosityIndex: 70,
    specificHeat: 1720,
    thermalConductivity: 0.115,
    vapourPressure: 0.08,
    bulkModulus: 1.95,
    colorHex: '#1f1610',
    colorSecondaryHex: '#0c0704',
    particleOpacity: 0.98,
    description: 'Ultra-viscous asphaltic binder requiring heating jackets and low-shear screw displacement.'
  },
  'transformer-oil': {
    id: 'transformer-oil',
    name: 'Inhibited Dielectric Transformer Oil',
    category: 'lubricant',
    density: 870,
    dynamicViscosity20C: 0.022,
    dynamicViscosity80C: 0.004,
    viscosityIndex: 105,
    specificHeat: 2100,
    thermalConductivity: 0.130,
    vapourPressure: 0.003,
    bulkModulus: 1.55,
    colorHex: '#fbbf24',
    colorSecondaryHex: '#b45309',
    particleOpacity: 0.65,
    description: 'High-purity naphthenic fluid for superior cooling and dielectric insulation breakdown resistance.'
  },
  'custom-user': {
    id: 'custom-user',
    name: 'Custom User Fluid Specification',
    category: 'custom',
    density: 880,
    dynamicViscosity20C: 0.050,
    dynamicViscosity80C: 0.008,
    viscosityIndex: 115,
    specificHeat: 2000,
    thermalConductivity: 0.132,
    vapourPressure: 1.5,
    bulkModulus: 1.65,
    colorHex: '#f59e0b',
    colorSecondaryHex: '#92400e',
    particleOpacity: 0.80,
    description: 'Parametrically adjustable fluid composition with user-configured thermophysical state.'
  }
};

/**
 * Calculates temperature-dependent dynamic viscosity using the Andrade / Walther equation
 * @param fluid Fluid properties
 * @param tempC Temperature in Celsius
 */
export function calculateViscosityAtTemp(fluid: FluidProperties, tempC: number): number {
  const T = Math.max(0, tempC) + 273.15; // Kelvin
  const T1 = 20 + 273.15;
  const T2 = 80 + 273.15;
  
  const mu1 = Math.max(0.0001, fluid.dynamicViscosity20C);
  const mu2 = Math.max(0.0001, fluid.dynamicViscosity80C);
  
  // B = ln(mu1/mu2) / (1/T1 - 1/T2)
  const B = Math.log(mu1 / mu2) / ((1 / T1) - (1 / T2));
  const A = mu1 * Math.exp(-B / T1);
  
  const mu = A * Math.exp(B / T);
  return Math.max(0.0005, mu);
}

/**
 * Calculates temperature-dependent density with thermal expansion coefficient
 * @param fluid Fluid properties
 * @param tempC Temperature in Celsius
 */
export function calculateDensityAtTemp(fluid: FluidProperties, tempC: number): number {
  const beta = 0.00075; // typical volumetric expansion coefficient for hydrocarbon oils (1/K)
  const deltaT = tempC - 20;
  return fluid.density / (1 + beta * deltaT);
}
