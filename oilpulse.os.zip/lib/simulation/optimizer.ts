// OILPULSE.OS — Automated Operating Point Optimizer

import { calculatePumpPhysics, PumpParameters, SimulationState } from './physics';

export interface OptimizationResult {
  optimalRpm: number;
  optimalValvePercent: number;
  optimalDischargeBar: number;
  predictedFlowLpm: number;
  predictedHeadMeters: number;
  predictedEfficiency: number;
  predictedPowerKw: number;
  annualEnergyCostSavingUsd: number;
  co2ReductionKgPerYear: number;
  scoreImprovementPercent: number;
  state: SimulationState;
}

export function findBestEfficiencyPoint(currentParams: PumpParameters): OptimizationResult {
  let bestEfficiency = -1;
  let bestParams: PumpParameters = { ...currentParams };
  let bestState: SimulationState | null = null;
  
  // Grid search over operating parameters
  const rpmCandidates = [2400, 2800, 3000, 3200, 3400, 3600, 3800];
  const valveCandidates = [60, 75, 85, 95, 100];
  
  for (const rpm of rpmCandidates) {
    for (const valve of valveCandidates) {
      const testParams: PumpParameters = {
        ...currentParams,
        targetRpm: rpm,
        currentRpm: rpm,
        valveOpenPercent: valve,
        bearingWearFactor: 1.0,
        sealLeakageFactor: 1.0,
        cavitationFactor: 0.0,
        rotorImbalanceGrams: 0.0,
        motorPhaseImbalance: 0.0,
        simulationTime: 300
      };
      
      const state = calculatePumpPhysics(testParams);
      
      // Objective: maximize overall efficiency while avoiding cavitation & keeping vibration safe
      if (state.cavitationRisk < 0.2 && state.overallEfficiency > bestEfficiency) {
        bestEfficiency = state.overallEfficiency;
        bestParams = testParams;
        bestState = state;
      }
    }
  }
  
  if (!bestState) {
    bestState = calculatePumpPhysics(currentParams);
  }
  
  const currentState = calculatePumpPhysics(currentParams);
  const powerDiffKw = Math.max(0, currentState.electricalPowerKw - bestState.electricalPowerKw);
  const hoursPerYear = 8000;
  const kwhCostUsd = 0.12; // $/kWh
  const annualEnergyCostSavingUsd = Math.round(powerDiffKw * hoursPerYear * kwhCostUsd);
  const co2ReductionKgPerYear = Math.round(powerDiffKw * hoursPerYear * 0.42); // 0.42 kg CO2 / kWh
  const scoreImprovementPercent = Math.round(Math.max(0, bestEfficiency - currentState.overallEfficiency) * 10) / 10;
  
  return {
    optimalRpm: bestParams.targetRpm,
    optimalValvePercent: bestParams.valveOpenPercent,
    optimalDischargeBar: bestParams.dischargePressureBar,
    predictedFlowLpm: bestState.flowRateLpm,
    predictedHeadMeters: bestState.headMeters,
    predictedEfficiency: bestState.overallEfficiency,
    predictedPowerKw: bestState.electricalPowerKw,
    annualEnergyCostSavingUsd,
    co2ReductionKgPerYear,
    scoreImprovementPercent,
    state: bestState
  };
}

export const findOptimalBEP = findBestEfficiencyPoint;
