// OILPULSE.OS — Digital Twin Asset Identity & Lifecycle System

export type TwinLifecycleState = 
  | 'DESIGNED'
  | 'MANUFACTURED'
  | 'ASSEMBLED'
  | 'INSPECTED'
  | 'CALIBRATED'
  | 'READY'
  | 'RUNNING'
  | 'WARNING'
  | 'FAULT'
  | 'MAINTENANCE'
  | 'RETIRED';

export interface MetrologyRecord {
  featureName: string;
  nominalValue: number;
  tolerancePlus: number;
  toleranceMinus: number;
  measuredValue: number;
  unit: string;
  status: 'PASS' | 'WARNING' | 'FAIL';
  measurementTool: string;
}

export interface MaintenanceLogEntry {
  id: string;
  timestamp: string;
  component: string;
  action: 'INSPECTION' | 'LUBRICATION' | 'SEAL_REPLACEMENT' | 'BEARING_REPLACEMENT' | 'BALANCING' | 'OVERHAUL';
  technician: string;
  notes: string;
  torqueAppliedNm?: number;
}

export interface DigitalTwinPassport {
  pumpId: string;
  serialNumber: string;
  modelDesignation: string;
  revision: string;
  manufacturer: string;
  manufactureDate: string;
  commissionDate: string;
  casingMaterial: string;
  shaftMaterial: string;
  impellerMaterial: string;
  designStandard: string; // e.g. "API 610 12th Ed / ISO 13709"
  totalOperatingHours: number;
  totalVolumePumpedM3: number;
  lastServiceDate: string;
  nextServiceDueHours: number;
  
  metrologyRecords: MetrologyRecord[];
  maintenanceHistory: MaintenanceLogEntry[];
}

export const INITIAL_DIGITAL_TWIN: DigitalTwinPassport = {
  pumpId: 'OILPULSE-P01',
  serialNumber: 'SN-2035-HYD-98842',
  modelDesignation: 'OILPULSE // TURBOMAX-550',
  revision: 'REV-4.2C',
  manufacturer: 'AUREOM INDUSTRIAL SYSTEMS GMBH',
  manufactureDate: '2035-04-18',
  commissionDate: '2035-05-02',
  casingMaterial: 'ASTM A995 Gr 4A Super Duplex Stainless',
  shaftMaterial: '17-4 PH Precipitation Hardened Steel',
  impellerMaterial: 'Inconel 718 Laser Powder Bed Fusion',
  designStandard: 'API 610 12th Ed / ISO 13709 / ATEX Zone 1',
  totalOperatingHours: 4128.5,
  totalVolumePumpedM3: 310840.0,
  lastServiceDate: '2035-08-10',
  nextServiceDueHours: 871.5,
  
  metrologyRecords: [
    {
      featureName: 'Shaft Journal Runout (Radial TIR)',
      nominalValue: 0.000,
      tolerancePlus: 0.005,
      toleranceMinus: 0.000,
      measuredValue: 0.002,
      unit: 'mm',
      status: 'PASS',
      measurementTool: 'Mitutoyo Contact LVDT Metrology'
    },
    {
      featureName: 'Impeller Outer Diameter & Balance',
      nominalValue: 265.000,
      tolerancePlus: 0.020,
      toleranceMinus: 0.020,
      measuredValue: 265.008,
      unit: 'mm',
      status: 'PASS',
      measurementTool: 'Zeiss Prismo 5-Axis CMM'
    },
    {
      featureName: 'Dynamic Rotor Residual Unbalance',
      nominalValue: 0.00,
      tolerancePlus: 0.85,
      toleranceMinus: 0.00,
      measuredValue: 0.38,
      unit: 'g·mm',
      status: 'PASS',
      measurementTool: 'Schenck Dynamic Balancer (ISO G1.0)'
    },
    {
      featureName: 'Mechanical Seal Face Flatness',
      nominalValue: 0.0,
      tolerancePlus: 2.0,
      toleranceMinus: 0.0,
      measuredValue: 0.6,
      unit: 'helium bands',
      status: 'PASS',
      measurementTool: 'Monochromatic Optical Flat'
    },
    {
      featureName: 'Hydrostatic Casing Pressure Proof',
      nominalValue: 22.5,
      tolerancePlus: 5.0,
      toleranceMinus: 0.0,
      measuredValue: 24.5,
      unit: 'MPa',
      status: 'PASS',
      measurementTool: 'Resato Hydrostatic Proof Rig (30min)'
    }
  ],
  
  maintenanceHistory: [
    {
      id: 'MNT-2035-001',
      timestamp: '2035-05-02 08:30 UTC',
      component: 'Overall Skid',
      action: 'INSPECTION',
      technician: 'L. Vance (Lead Diagnostics)',
      notes: 'Initial commissioning laser alignment completed. Angular offset 0.01mm, parallel offset 0.02mm.'
    },
    {
      id: 'MNT-2035-002',
      timestamp: '2035-08-10 14:15 UTC',
      component: 'Thrust Bearing 7310-BECBM',
      action: 'LUBRICATION',
      technician: 'K. Tanaka',
      notes: 'Replenished synthetic polyalphaolefin grease. Monitored vibration baseline.'
    }
  ]
};

export const INITIAL_DIGITAL_TWIN_PASSPORT = INITIAL_DIGITAL_TWIN;

export interface TelemetryPoint {
  timeSec: number;
  rpm: number;
  flowLpm: number;
  pressureMpa: number;
  tempC: number;
  vibrationRms: number;
  efficiency: number;
  powerKw: number;
}
