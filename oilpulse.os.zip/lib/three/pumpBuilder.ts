// OILPULSE.OS — Parametric 3D Industrial Pump Geometry Builder
import * as THREE from 'three';
import { MaterialLibrary } from './materials';
import { PumpType } from '../simulation/physics';

export interface ComponentMetadata {
  id: string;
  name: string;
  group: 'motor' | 'coupling' | 'shaft' | 'bearings' | 'seals' | 'rotor' | 'casing' | 'base' | 'sensors';
  description: string;
  material: string;
  wearCondition: string;
  tolerance: string;
  operatingTempNominal: string;
  explodedOffset: THREE.Vector3;
}

export interface BuiltPumpModel {
  rootGroup: THREE.Group;
  rotatingShaftGroup: THREE.Group;
  rotorGroup: THREE.Group;
  secondaryRotorGroup?: THREE.Group; // for gear / screw secondary rotor
  pistonPlungers?: THREE.Mesh[]; // for piston pump
  checkValves?: THREE.Mesh[];
  componentMeshes: Map<string, { mesh: THREE.Object3D; meta: ComponentMetadata; basePos: THREE.Vector3 }>;
  sensorIndicators: THREE.Mesh[];
}

export function buildParametricPump(
  type: PumpType,
  materials: MaterialLibrary
): BuiltPumpModel {
  const rootGroup = new THREE.Group();
  rootGroup.name = 'OILPULSE_PUMP_ROOT';

  const rotatingShaftGroup = new THREE.Group();
  rotatingShaftGroup.name = 'ROTATING_SHAFT_ASSEMBLY';

  const rotorGroup = new THREE.Group();
  rotorGroup.name = 'PRIMARY_ROTOR_ASSEMBLY';

  let secondaryRotorGroup: THREE.Group | undefined;
  const pistonPlungers: THREE.Mesh[] = [];
  const checkValves: THREE.Mesh[] = [];
  const componentMeshes = new Map<string, { mesh: THREE.Object3D; meta: ComponentMetadata; basePos: THREE.Vector3 }>();
  const sensorIndicators: THREE.Mesh[] = [];

  // Helper to register component for exploded view & metrology picking
  const registerComponent = (
    id: string,
    mesh: THREE.Object3D,
    meta: Omit<ComponentMetadata, 'id'>
  ) => {
    mesh.name = id;
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    const basePos = mesh.position.clone();
    componentMeshes.set(id, {
      mesh,
      meta: { ...meta, id },
      basePos
    });
  };

  // 1. BASE SKID (Common for all models)
  const baseSkidGroup = new THREE.Group();
  const baseBedGeom = new THREE.BoxGeometry(2.2, 0.12, 0.9);
  const baseBed = new THREE.Mesh(baseBedGeom, materials.baseSkid);
  baseBed.position.set(0, -0.45, 0);
  baseSkidGroup.add(baseBed);

  // Mounting pads & anchor bolt rings
  const padGeom = new THREE.BoxGeometry(0.24, 0.08, 0.24);
  const boltGeom = new THREE.CylinderGeometry(0.02, 0.02, 0.06, 12);
  const padPositions = [
    [-0.9, -0.35, -0.32],
    [-0.9, -0.35, 0.32],
    [0.9, -0.35, -0.32],
    [0.9, -0.35, 0.32],
    [0.0, -0.35, -0.32],
    [0.0, -0.35, 0.32],
  ];
  padPositions.forEach(([x, y, z]) => {
    const pad = new THREE.Mesh(padGeom, materials.motorFins);
    pad.position.set(x, y, z);
    const bolt = new THREE.Mesh(boltGeom, materials.flangeBolts);
    bolt.position.set(x, y + 0.06, z);
    baseSkidGroup.add(pad, bolt);
  });

  registerComponent('base_skid', baseSkidGroup, {
    name: 'Cast Iron Structural Skid Base',
    group: 'base',
    description: 'Heavy dampening structural base with machined co-planar mounting pads and vibration isolation anchors.',
    material: 'ASTM A48 Class 40B Gray Cast Iron',
    wearCondition: 'Nominal (Zero deflection, < 0.01mm)',
    tolerance: 'Co-planarity ±0.015 mm / m',
    operatingTempNominal: '24°C - 38°C',
    explodedOffset: new THREE.Vector3(0, -0.6, 0)
  });
  rootGroup.add(baseSkidGroup);

  // 2. ELECTRIC INDUCTION MOTOR (Common drive unit, on left side x = -0.6)
  const motorGroup = new THREE.Group();
  motorGroup.position.set(-0.65, 0, 0);

  // Stator Housing
  const motorStatorGeom = new THREE.CylinderGeometry(0.32, 0.32, 0.65, 32);
  motorStatorGeom.rotateZ(Math.PI / 2);
  const motorStator = new THREE.Mesh(motorStatorGeom, materials.motorHousing);
  motorGroup.add(motorStator);

  // Motor Cooling Fins
  const finCount = 18;
  for (let i = 0; i < finCount; i++) {
    const angle = (i / finCount) * Math.PI * 2;
    const finGeom = new THREE.BoxGeometry(0.60, 0.012, 0.045);
    const fin = new THREE.Mesh(finGeom, materials.motorFins);
    fin.position.set(
      0,
      Math.cos(angle) * 0.33,
      Math.sin(angle) * 0.33
    );
    fin.rotation.x = angle;
    motorGroup.add(fin);
  }

  // Motor Terminal Box
  const terminalGeom = new THREE.BoxGeometry(0.18, 0.14, 0.18);
  const terminalBox = new THREE.Mesh(terminalGeom, materials.motorHousing);
  terminalBox.position.set(0, 0.38, 0);
  motorGroup.add(terminalBox);

  // Motor Fan Cowl & End Bell
  const fanCowlGeom = new THREE.CylinderGeometry(0.33, 0.31, 0.14, 32);
  fanCowlGeom.rotateZ(Math.PI / 2);
  const fanCowl = new THREE.Mesh(fanCowlGeom, materials.motorFins);
  fanCowl.position.set(-0.38, 0, 0);
  motorGroup.add(fanCowl);

  registerComponent('electric_motor', motorGroup, {
    name: '55 kW IE4 Super Premium Induction Motor',
    group: 'motor',
    description: '4-pole 400V 50/60Hz squirrel-cage induction motor with vacuum pressure impregnated (VPI) Class H stator windings.',
    material: 'Cast Iron Frame / Copper Stator Winding / Laser-cut Silicon Steel Core',
    wearCondition: 'Nominal 100% Insulation Resistance (> 500 MΩ)',
    tolerance: 'Rotor Dynamic Balance ISO 1940 Grade G1.0',
    operatingTempNominal: '65°C - 85°C',
    explodedOffset: new THREE.Vector3(-0.8, 0, 0)
  });
  rootGroup.add(motorGroup);

  // 3. FLEXIBLE COUPLING (Around x = -0.22)
  const couplingGroup = new THREE.Group();
  couplingGroup.position.set(-0.24, 0, 0);

  const hubMotorGeom = new THREE.CylinderGeometry(0.11, 0.11, 0.08, 24);
  hubMotorGeom.rotateZ(Math.PI / 2);
  const hubMotor = new THREE.Mesh(hubMotorGeom, materials.internalMetal);
  hubMotor.position.set(-0.05, 0, 0);

  const spiderGeom = new THREE.CylinderGeometry(0.12, 0.12, 0.03, 16);
  spiderGeom.rotateZ(Math.PI / 2);
  const spiderDisc = new THREE.Mesh(spiderGeom, materials.seals);
  spiderDisc.position.set(0, 0, 0);

  const hubPumpGeom = new THREE.CylinderGeometry(0.11, 0.11, 0.08, 24);
  hubPumpGeom.rotateZ(Math.PI / 2);
  const hubPump = new THREE.Mesh(hubPumpGeom, materials.internalMetal);
  hubPump.position.set(0.05, 0, 0);

  couplingGroup.add(hubMotor, spiderDisc, hubPump);

  registerComponent('flexible_coupling', couplingGroup, {
    name: 'Disc Pack Flexible Shaft Coupling',
    group: 'coupling',
    description: 'Zero-backlash torsionally stiff metallic disc pack coupling accommodating angular and parallel shaft misalignments.',
    material: 'Forged AISI 4140 Alloy Steel / Stainless Disc Packs',
    wearCondition: 'Nominal (< 0.02mm runout)',
    tolerance: 'Axial Gap 4.00 ±0.15 mm',
    operatingTempNominal: '35°C - 50°C',
    explodedOffset: new THREE.Vector3(-0.35, 0.4, 0)
  });
  rootGroup.add(couplingGroup);

  // 4. MAIN SHAFT (Rotating with rotatingShaftGroup)
  const shaftGeom = new THREE.CylinderGeometry(0.042, 0.042, 1.15, 32);
  shaftGeom.rotateZ(Math.PI / 2);
  const shaftMesh = new THREE.Mesh(shaftGeom, materials.shaft);
  shaftMesh.position.set(0.35, 0, 0);
  rotatingShaftGroup.add(shaftMesh);

  // Shaft sleeve & keyways
  const sleeveGeom = new THREE.CylinderGeometry(0.048, 0.048, 0.22, 24);
  sleeveGeom.rotateZ(Math.PI / 2);
  const shaftSleeve = new THREE.Mesh(sleeveGeom, materials.internalMetal);
  shaftSleeve.position.set(0.28, 0, 0);
  rotatingShaftGroup.add(shaftSleeve);

  registerComponent('drive_shaft', rotatingShaftGroup, {
    name: 'Precision Ground Drive Shaft',
    group: 'shaft',
    description: 'Heavy-duty stepped drive shaft hardened and micro-ground at bearing and seal journals for minimal dynamic deflection.',
    material: '17-4 PH Precipitation Hardened Stainless Steel',
    wearCondition: 'Radial TIR < 0.003 mm',
    tolerance: 'Journal Diameter h6 (Ø48.000 +0.000 / -0.016 mm)',
    operatingTempNominal: '45°C - 65°C',
    explodedOffset: new THREE.Vector3(0, 0.5, 0)
  });
  rootGroup.add(rotatingShaftGroup);

  // 5. BEARING HOUSINGS & BEARINGS (DE & NDE)
  const bearingsGroup = new THREE.Group();
  bearingsGroup.position.set(0.05, 0, 0);

  const bearingHousingGeom = new THREE.CylinderGeometry(0.18, 0.18, 0.38, 32);
  bearingHousingGeom.rotateZ(Math.PI / 2);
  const bearingHousing = new THREE.Mesh(bearingHousingGeom, materials.casing);
  bearingHousing.position.set(0, 0, 0);

  // Bearing Rings (DE Ball bearing + NDE Duplex Angular Contact)
  const ringGeom1 = new THREE.TorusGeometry(0.075, 0.022, 16, 32);
  ringGeom1.rotateY(Math.PI / 2);
  const bearingRing1 = new THREE.Mesh(ringGeom1, materials.bearings);
  bearingRing1.position.set(-0.12, 0, 0);

  const ringGeom2 = new THREE.TorusGeometry(0.075, 0.022, 16, 32);
  ringGeom2.rotateY(Math.PI / 2);
  const bearingRing2 = new THREE.Mesh(ringGeom2, materials.bearings);
  bearingRing2.position.set(0.12, 0, 0);

  bearingsGroup.add(bearingHousing, bearingRing1, bearingRing2);

  registerComponent('bearings_assembly', bearingsGroup, {
    name: 'Heavy-Duty Radial & Thrust Bearings Cartridge',
    group: 'bearings',
    description: 'Deep groove radial ball bearing paired with back-to-back 7310-BECBM angular contact thrust bearings with oil bath lubrication.',
    material: 'High-Carbon Chromium Bearing Steel (100Cr6 / AISI 52100)',
    wearCondition: 'ISO Class Normal Clearance (Radial Play 18 µm)',
    tolerance: 'ABEC-7 / ISO P4 Precision Tolerance',
    operatingTempNominal: '55°C - 75°C',
    explodedOffset: new THREE.Vector3(0, 0.45, -0.45)
  });
  rootGroup.add(bearingsGroup);

  // 6. MECHANICAL SEAL ASSEMBLY
  const sealGroup = new THREE.Group();
  sealGroup.position.set(0.32, 0, 0);

  const sealGlandGeom = new THREE.CylinderGeometry(0.14, 0.14, 0.09, 24);
  sealGlandGeom.rotateZ(Math.PI / 2);
  const sealGland = new THREE.Mesh(sealGlandGeom, materials.internalMetal);

  const sealFaceGeom = new THREE.TorusGeometry(0.065, 0.012, 16, 32);
  sealFaceGeom.rotateY(Math.PI / 2);
  const sealFace = new THREE.Mesh(sealFaceGeom, materials.seals);

  sealGroup.add(sealGland, sealFace);

  registerComponent('mechanical_seal', sealGroup, {
    name: 'Cartridge Dual Mechanical Seal (API Plan 53B)',
    group: 'seals',
    description: 'Cartridge balanced dual-seal arrangement with silicon carbide vs resin-impregnated carbon faces and pressurized barrier fluid.',
    material: 'Silicon Carbide (SiC) / Premium Carbon Graphite / Kalrez O-Rings',
    wearCondition: 'Face Flatness < 2 Helium Light Bands (0.6 µm)',
    tolerance: 'Gap Clearance 0.001 mm',
    operatingTempNominal: '40°C - 70°C',
    explodedOffset: new THREE.Vector3(0.2, 0.4, 0.4)
  });
  rootGroup.add(sealGroup);

  // 7. PUMP SPECIFIC ROTOR & CASING ARCHITECTURES
  if (type === 'centrifugal') {
    // 7A. CENTRIFUGAL VOLUTE PUMP
    const casingGroup = new THREE.Group();
    casingGroup.position.set(0.68, 0, 0);

    // Volute Spiral Casing
    const voluteGeom = new THREE.TorusGeometry(0.26, 0.15, 24, 48);
    const volute = new THREE.Mesh(voluteGeom, materials.casing);
    volute.rotation.y = Math.PI / 2;
    casingGroup.add(volute);

    // Front suction nozzle (pointing forward / right +X)
    const suctionGeom = new THREE.CylinderGeometry(0.12, 0.12, 0.35, 24);
    suctionGeom.rotateZ(Math.PI / 2);
    const suctionNozzle = new THREE.Mesh(suctionGeom, materials.casing);
    suctionNozzle.position.set(0.25, 0, 0);

    const suctionFlangeGeom = new THREE.CylinderGeometry(0.20, 0.20, 0.045, 24);
    suctionFlangeGeom.rotateZ(Math.PI / 2);
    const suctionFlange = new THREE.Mesh(suctionFlangeGeom, materials.flangeBolts);
    suctionFlange.position.set(0.42, 0, 0);
    casingGroup.add(suctionNozzle, suctionFlange);

    // Discharge nozzle (pointing straight UP +Y)
    const dischargeGeom = new THREE.CylinderGeometry(0.09, 0.09, 0.42, 24);
    const dischargeNozzle = new THREE.Mesh(dischargeGeom, materials.casing);
    dischargeNozzle.position.set(0, 0.35, 0);

    const dischargeFlangeGeom = new THREE.CylinderGeometry(0.17, 0.17, 0.045, 24);
    const dischargeFlange = new THREE.Mesh(dischargeFlangeGeom, materials.flangeBolts);
    dischargeFlange.position.set(0, 0.56, 0);
    casingGroup.add(dischargeNozzle, dischargeFlange);

    // Flange bolts
    for (let b = 0; b < 8; b++) {
      const bAngle = (b / 8) * Math.PI * 2;
      const bMesh = new THREE.Mesh(boltGeom, materials.flangeBolts);
      bMesh.position.set(0.42, Math.cos(bAngle) * 0.16, Math.sin(bAngle) * 0.16);
      bMesh.rotation.z = Math.PI / 2;
      casingGroup.add(bMesh);

      const bMeshUp = new THREE.Mesh(boltGeom, materials.flangeBolts);
      bMeshUp.position.set(Math.cos(bAngle) * 0.13, 0.56, Math.sin(bAngle) * 0.13);
      casingGroup.add(bMeshUp);
    }

    registerComponent('pump_casing', casingGroup, {
      name: 'Single-Stage Spiral Volute Casing (API 610 OH2)',
      group: 'casing',
      description: 'Radially split heavy-wall cast casing with center-line support to withstand high thermal expansion and pipeline nozzle loads.',
      material: 'ASTM A995 Gr 4A Super Duplex Stainless Steel',
      wearCondition: 'Hydrostatic Tested to 24.5 MPa (Zero Porosity)',
      tolerance: 'Volute Wall Thickness 18.5 ±0.8 mm',
      operatingTempNominal: 'Fluid Temperature + 5°C',
      explodedOffset: new THREE.Vector3(0.65, 0, 0)
    });
    rootGroup.add(casingGroup);

    // Impeller (attached to rotorGroup at x = 0.68)
    rotorGroup.position.set(0.68, 0, 0);
    const impellerHubGeom = new THREE.CylinderGeometry(0.08, 0.05, 0.14, 24);
    impellerHubGeom.rotateZ(Math.PI / 2);
    const impellerHub = new THREE.Mesh(impellerHubGeom, materials.impeller);
    rotorGroup.add(impellerHub);

    // Shrouds
    const backShroudGeom = new THREE.CylinderGeometry(0.24, 0.24, 0.02, 32);
    backShroudGeom.rotateZ(Math.PI / 2);
    const backShroud = new THREE.Mesh(backShroudGeom, materials.impeller);
    backShroud.position.set(-0.04, 0, 0);
    rotorGroup.add(backShroud);

    // 6 Logarithmic Curved Impeller Vanes
    const vaneCount = 6;
    for (let v = 0; v < vaneCount; v++) {
      const vAngle = (v / vaneCount) * Math.PI * 2;
      const vaneGeom = new THREE.BoxGeometry(0.015, 0.045, 0.18);
      const vane = new THREE.Mesh(vaneGeom, materials.impeller);
      vane.position.set(
        0,
        Math.cos(vAngle) * 0.14,
        Math.sin(vAngle) * 0.14
      );
      vane.rotation.x = vAngle + 0.55; // backward curved pitch
      rotorGroup.add(vane);
    }

    registerComponent('impeller_rotor', rotorGroup, {
      name: 'Enclosed 6-Vane Backward-Curved Impeller',
      group: 'rotor',
      description: 'Precision 5-axis CNC machined enclosed impeller dynamically balanced with front & back wear rings to minimize axial thrust.',
      material: 'Laser Powder Bed Inconel 718 Superalloy',
      wearCondition: 'Dynamic Unbalance < 0.38 g·mm (ISO G1.0)',
      tolerance: 'Impeller Outer Diameter Ø265.00 ±0.02 mm',
      operatingTempNominal: 'Fluid Temperature',
      explodedOffset: new THREE.Vector3(0.35, 0.45, 0.3)
    });
    rotatingShaftGroup.add(rotorGroup);

  } else if (type === 'gear') {
    // 7B. ROTARY EXTERNAL GEAR PUMP
    const gearCasingGroup = new THREE.Group();
    gearCasingGroup.position.set(0.65, 0, 0);

    // Figure-8 double cylinder housing
    const geom1 = new THREE.CylinderGeometry(0.20, 0.20, 0.28, 32);
    geom1.rotateZ(Math.PI / 2);
    const body1 = new THREE.Mesh(geom1, materials.casing);
    body1.position.set(0, 0.12, 0);

    const geom2 = new THREE.CylinderGeometry(0.20, 0.20, 0.28, 32);
    geom2.rotateZ(Math.PI / 2);
    const body2 = new THREE.Mesh(geom2, materials.casing);
    body2.position.set(0, -0.12, 0);

    gearCasingGroup.add(body1, body2);

    // Inlet & Outlet side ports
    const portGeom = new THREE.CylinderGeometry(0.08, 0.08, 0.22, 24);
    portGeom.rotateX(Math.PI / 2);
    const inletPort = new THREE.Mesh(portGeom, materials.casing);
    inletPort.position.set(0, 0, -0.25);
    const outletPort = new THREE.Mesh(portGeom, materials.casing);
    outletPort.position.set(0, 0, 0.25);
    gearCasingGroup.add(inletPort, outletPort);

    registerComponent('gear_casing', gearCasingGroup, {
      name: 'Precision Cast Dual-Chamber Gear Housing',
      group: 'casing',
      description: 'Precision bored figure-8 gear chamber with micro-honed internal clearances for zero-slip volumetric fluid transfer.',
      material: 'Nodular Ductile Iron EN-GJS-400-15',
      wearCondition: 'Bore Radial Clearance 0.035 mm',
      tolerance: 'Center Distance 140.00 ±0.010 mm',
      operatingTempNominal: 'Fluid Temperature',
      explodedOffset: new THREE.Vector3(0.6, 0, 0)
    });
    rootGroup.add(gearCasingGroup);

    // Drive Gear (Top)
    rotorGroup.position.set(0.65, 0.12, 0);
    const gearHubGeom = new THREE.CylinderGeometry(0.14, 0.14, 0.18, 32);
    gearHubGeom.rotateZ(Math.PI / 2);
    const driveGear = new THREE.Mesh(gearHubGeom, materials.impeller);
    rotorGroup.add(driveGear);

    // Drive gear teeth
    for (let t = 0; t < 14; t++) {
      const tAngle = (t / 14) * Math.PI * 2;
      const toothGeom = new THREE.BoxGeometry(0.18, 0.022, 0.04);
      const tooth = new THREE.Mesh(toothGeom, materials.impeller);
      tooth.position.set(0, Math.cos(tAngle) * 0.15, Math.sin(tAngle) * 0.15);
      tooth.rotation.x = tAngle;
      rotorGroup.add(tooth);
    }
    rotatingShaftGroup.add(rotorGroup);

    // Driven Gear (Bottom, counter-rotating)
    secondaryRotorGroup = new THREE.Group();
    secondaryRotorGroup.position.set(0.65, -0.12, 0);
    const drivenGear = new THREE.Mesh(gearHubGeom, materials.impeller);
    secondaryRotorGroup.add(drivenGear);
    for (let t = 0; t < 14; t++) {
      const tAngle = (t / 14) * Math.PI * 2 + (Math.PI / 14); // offset mesh
      const toothGeom = new THREE.BoxGeometry(0.18, 0.022, 0.04);
      const tooth = new THREE.Mesh(toothGeom, materials.impeller);
      tooth.position.set(0, Math.cos(tAngle) * 0.15, Math.sin(tAngle) * 0.15);
      tooth.rotation.x = tAngle;
      secondaryRotorGroup.add(tooth);
    }
    rootGroup.add(secondaryRotorGroup);

    registerComponent('drive_gear', rotorGroup, {
      name: 'Precision Involute Driving Spur Gear',
      group: 'rotor',
      description: 'Case-hardened precision ground spur gear with optimized tooth tip relief to eliminate hydraulic fluid trapping.',
      material: 'Carburized AISI 8620 Nickel-Chromium Steel',
      wearCondition: 'Surface Hardness 60 HRC (Zero Pitting)',
      tolerance: 'DIN 3962 Quality Grade 5 Precision',
      operatingTempNominal: 'Fluid Temperature + 8°C',
      explodedOffset: new THREE.Vector3(0.2, 0.45, 0.3)
    });

  } else if (type === 'screw') {
    // 7C. TWIN SCREW POSITIVE DISPLACEMENT PUMP
    const screwCasingGroup = new THREE.Group();
    screwCasingGroup.position.set(0.70, 0, 0);

    const screwHousingGeom = new THREE.BoxGeometry(0.72, 0.42, 0.52);
    const screwHousing = new THREE.Mesh(screwHousingGeom, materials.casing);
    screwCasingGroup.add(screwHousing);

    registerComponent('screw_casing', screwCasingGroup, {
      name: 'Twin-Screw Multiphase Cartridge Casing',
      group: 'casing',
      description: 'Heavy-wall casing with internal liner sleeves capable of handling high gas-volume fractions and abrasive fluid shear.',
      material: 'Chrome-Moly Alloy Steel with Nitrided Liner',
      wearCondition: 'Radial Gap 0.045 mm',
      tolerance: 'Bore Parallelism 0.008 mm',
      operatingTempNominal: 'Fluid Temperature',
      explodedOffset: new THREE.Vector3(0.7, 0, 0)
    });
    rootGroup.add(screwCasingGroup);

    // Primary Screw Spindle
    rotorGroup.position.set(0.70, 0.09, 0);
    const screwCoreGeom = new THREE.CylinderGeometry(0.05, 0.05, 0.65, 24);
    screwCoreGeom.rotateZ(Math.PI / 2);
    const screwCore = new THREE.Mesh(screwCoreGeom, materials.impeller);
    rotorGroup.add(screwCore);

    // Helical flights
    for (let f = 0; f < 10; f++) {
      const flightGeom = new THREE.TorusGeometry(0.09, 0.02, 16, 24);
      flightGeom.rotateY(Math.PI / 2);
      const flight = new THREE.Mesh(flightGeom, materials.impeller);
      flight.position.set(-0.25 + f * 0.055, 0, 0);
      rotorGroup.add(flight);
    }
    rotatingShaftGroup.add(rotorGroup);

    // Secondary Intermeshing Screw
    secondaryRotorGroup = new THREE.Group();
    secondaryRotorGroup.position.set(0.70, -0.09, 0);
    const screwCore2 = new THREE.Mesh(screwCoreGeom, materials.impeller);
    secondaryRotorGroup.add(screwCore2);
    for (let f = 0; f < 10; f++) {
      const flightGeom = new THREE.TorusGeometry(0.09, 0.02, 16, 24);
      flightGeom.rotateY(Math.PI / 2);
      const flight = new THREE.Mesh(flightGeom, materials.impeller);
      flight.position.set(-0.22 + f * 0.055, 0, 0);
      secondaryRotorGroup.add(flight);
    }
    rootGroup.add(secondaryRotorGroup);

    registerComponent('primary_screw_rotor', rotorGroup, {
      name: 'Left-Handed Multi-Stage Archimedean Screw Spindle',
      group: 'rotor',
      description: 'Precision milled non-contacting intermeshing helical screw generating continuous non-pulsating axial displacement.',
      material: 'Nitrided 41CrAlMo7-10 Tool Steel',
      wearCondition: 'Clearance Uniformity 99.2%',
      tolerance: 'Screw Pitch Lead 45.00 ±0.01 mm',
      operatingTempNominal: 'Fluid Temperature',
      explodedOffset: new THREE.Vector3(0.2, 0.4, 0.3)
    });

  } else {
    // 7D. TRIPLEX RECIPROCATING PISTON PUMP
    const pistonCasingGroup = new THREE.Group();
    pistonCasingGroup.position.set(0.72, 0, 0);

    const crankcaseGeom = new THREE.BoxGeometry(0.55, 0.44, 0.65);
    const crankcase = new THREE.Mesh(crankcaseGeom, materials.casing);
    pistonCasingGroup.add(crankcase);

    // 3 Liquid cylinders on right
    for (let c = 0; c < 3; c++) {
      const zOffset = (c - 1) * 0.20;
      const cylGeom = new THREE.CylinderGeometry(0.08, 0.08, 0.32, 24);
      cylGeom.rotateZ(Math.PI / 2);
      const cyl = new THREE.Mesh(cylGeom, materials.casing);
      cyl.position.set(0.38, 0, zOffset);
      pistonCasingGroup.add(cyl);

      // Ceramic Plunger
      const plungerGeom = new THREE.CylinderGeometry(0.045, 0.045, 0.28, 24);
      plungerGeom.rotateZ(Math.PI / 2);
      const plunger = new THREE.Mesh(plungerGeom, materials.impeller);
      plunger.position.set(0.35, 0, zOffset);
      pistonPlungers.push(plunger);
      rootGroup.add(plunger);

      // Check valves (top discharge, bottom suction)
      const valveTop = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.08, 16), materials.sensors);
      valveTop.position.set(0.46, 0.12, zOffset);
      const valveBottom = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.08, 16), materials.sensors);
      valveBottom.position.set(0.46, -0.12, zOffset);
      checkValves.push(valveTop, valveBottom);
      pistonCasingGroup.add(valveTop, valveBottom);
    }

    registerComponent('piston_crankcase', pistonCasingGroup, {
      name: 'Triplex High-Pressure Fluid End & Crankcase',
      group: 'casing',
      description: 'Heavy ductile iron power end with crosshead slide guides and forged stainless steel fluid end block.',
      material: 'Forged 316L Stainless Steel Fluid Block',
      wearCondition: 'Packing Seal Hydro-leakage 0.00 mL/min',
      tolerance: 'Cylinder Bore Ø70.00 ±0.01 mm',
      operatingTempNominal: 'Fluid Temperature + 12°C',
      explodedOffset: new THREE.Vector3(0.65, 0, 0)
    });
    rootGroup.add(pistonCasingGroup);
  }

  // 8. HIGH-PRECISION SENSORS & TELEMETRY PROBES
  const sensorGroup = new THREE.Group();
  
  // Vibration Sensor on Bearing Housing
  const vibSensorGeom = new THREE.CylinderGeometry(0.022, 0.022, 0.06, 16);
  const vibSensor = new THREE.Mesh(vibSensorGeom, materials.sensors);
  vibSensor.position.set(0.05, 0.20, 0);
  sensorIndicators.push(vibSensor);
  sensorGroup.add(vibSensor);

  // Pressure Transmitter on Discharge Flange
  const pressSensorGeom = new THREE.CylinderGeometry(0.025, 0.025, 0.09, 16);
  const pressSensor = new THREE.Mesh(pressSensorGeom, materials.sensors);
  pressSensor.position.set(0.68, 0.62, 0);
  sensorIndicators.push(pressSensor);
  sensorGroup.add(pressSensor);

  // RTD Temperature Sensor on Motor Stator
  const tempSensorGeom = new THREE.CylinderGeometry(0.018, 0.018, 0.05, 16);
  const tempSensor = new THREE.Mesh(tempSensorGeom, materials.sensors);
  tempSensor.position.set(-0.65, 0.34, 0.20);
  sensorIndicators.push(tempSensor);
  sensorGroup.add(tempSensor);

  registerComponent('digital_sensors', sensorGroup, {
    name: 'Integrated IIoT Multi-Sensory Instrumentation',
    group: 'sensors',
    description: 'High-frequency piezoresistive pressure transmitter, tri-axial accelerometer (0-10 kHz), and Class A RTD Pt100 temperature probes.',
    material: 'Hermetic Stainless 316L with Gold-plated Contacts',
    wearCondition: 'Calibrated (Zero Drift < 0.02% FS)',
    tolerance: 'Measurement Accuracy ±0.05%',
    operatingTempNominal: '-40°C to +125°C',
    explodedOffset: new THREE.Vector3(0, 0.7, 0)
  });
  rootGroup.add(sensorGroup);

  return {
    rootGroup,
    rotatingShaftGroup,
    rotorGroup,
    secondaryRotorGroup,
    pistonPlungers,
    checkValves,
    componentMeshes,
    sensorIndicators
  };
}
