// OILPULSE.OS — Three.js Custom PBR & Engineering Visualization Materials
import * as THREE from 'three';

export type MaterialPreset = 'cast-titanium' | 'brushed-steel' | 'carbon-composite' | 'marine-bronze' | 'anodized-cyan' | 'ceramic-white';
export type VisualizationMode = 'standard' | 'cutaway' | 'xray' | 'flow' | 'pressure' | 'thermal' | 'vibration' | 'exploded';

export interface MaterialLibrary {
  casing: THREE.Material;
  internalMetal: THREE.Material;
  shaft: THREE.Material;
  impeller: THREE.Material;
  bearings: THREE.Material;
  seals: THREE.Material;
  motorHousing: THREE.Material;
  motorFins: THREE.Material;
  baseSkid: THREE.Material;
  flangeBolts: THREE.Material;
  sensors: THREE.Material;
  fluidCore: THREE.Material;
  glassXray: THREE.Material;
  clippingPlanes: THREE.Plane[];
}

export function createMaterials(preset: MaterialPreset = 'cast-titanium', mode: VisualizationMode = 'standard'): MaterialLibrary {
  const clippingPlanes: THREE.Plane[] = [];
  
  if (mode === 'cutaway') {
    // Cut away quadrant (Z > 0 and X > -0.2)
    clippingPlanes.push(new THREE.Plane(new THREE.Vector3(0, 0, -1), 0.02));
  }

  // Preset color configs
  let casingColor = 0x22262d;
  let casingMetalness = 0.88;
  let casingRoughness = 0.28;
  let accentColor = 0xf59e0b;

  switch (preset) {
    case 'brushed-steel':
      casingColor = 0xd1d5db;
      casingMetalness = 0.95;
      casingRoughness = 0.18;
      accentColor = 0x3b82f6;
      break;
    case 'carbon-composite':
      casingColor = 0x111317;
      casingMetalness = 0.35;
      casingRoughness = 0.65;
      accentColor = 0xef4444;
      break;
    case 'marine-bronze':
      casingColor = 0x925c28;
      casingMetalness = 0.85;
      casingRoughness = 0.32;
      accentColor = 0xd97706;
      break;
    case 'anodized-cyan':
      casingColor = 0x0e3a47;
      casingMetalness = 0.92;
      casingRoughness = 0.22;
      accentColor = 0x06b6d4;
      break;
    case 'ceramic-white':
      casingColor = 0xe5e7eb;
      casingMetalness = 0.15;
      casingRoughness = 0.12;
      accentColor = 0x10b981;
      break;
    case 'cast-titanium':
    default:
      casingColor = 0x282d37;
      casingMetalness = 0.90;
      casingRoughness = 0.25;
      accentColor = 0xf59e0b;
      break;
  }

  // Base materials
  let casingMat: THREE.Material;
  let motorHousingMat: THREE.Material;
  let glassXrayMat: THREE.Material;

  if (mode === 'xray') {
    casingMat = new THREE.MeshPhysicalMaterial({
      color: 0x1e293b,
      metalness: 0.1,
      roughness: 0.1,
      transmission: 0.88,
      thickness: 1.2,
      transparent: true,
      opacity: 0.35,
      wireframe: false,
      depthWrite: false
    });
    motorHousingMat = new THREE.MeshPhysicalMaterial({
      color: 0x0f172a,
      metalness: 0.2,
      roughness: 0.2,
      transmission: 0.82,
      thickness: 1.0,
      transparent: true,
      opacity: 0.40,
      depthWrite: false
    });
  } else if (mode === 'thermal') {
    casingMat = new THREE.MeshStandardMaterial({
      color: 0x3b4252,
      metalness: 0.6,
      roughness: 0.4,
      clippingPlanes,
      clipShadows: true
    });
    motorHousingMat = new THREE.MeshStandardMaterial({
      color: 0xd97706, // Hot motor
      metalness: 0.5,
      roughness: 0.4,
      emissive: 0x78350f,
      emissiveIntensity: 0.35,
      clippingPlanes
    });
  } else if (mode === 'pressure') {
    casingMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      metalness: 0.7,
      roughness: 0.3,
      clippingPlanes,
      clipShadows: true
    });
    motorHousingMat = new THREE.MeshStandardMaterial({
      color: 0x334155,
      metalness: 0.8,
      roughness: 0.3,
      clippingPlanes
    });
  } else {
    casingMat = new THREE.MeshStandardMaterial({
      color: casingColor,
      metalness: casingMetalness,
      roughness: casingRoughness,
      clippingPlanes,
      clipShadows: true
    });
    motorHousingMat = new THREE.MeshStandardMaterial({
      color: 0x1c212a,
      metalness: 0.85,
      roughness: 0.35,
      clippingPlanes,
      clipShadows: true
    });
  }

  const internalMetalMat = new THREE.MeshStandardMaterial({
    color: 0x94a3b8,
    metalness: 0.95,
    roughness: 0.15,
    clippingPlanes
  });

  const shaftMat = new THREE.MeshStandardMaterial({
    color: 0xcfd8dc,
    metalness: 0.98,
    roughness: 0.08,
    clippingPlanes
  });

  const impellerMat = new THREE.MeshStandardMaterial({
    color: mode === 'thermal' ? 0xf59e0b : (mode === 'pressure' ? 0xef4444 : 0xcd7f32), // Gold bronze or thermal/pressure
    metalness: 0.92,
    roughness: 0.18,
    emissive: mode === 'thermal' ? 0x92400e : 0x000000,
    emissiveIntensity: mode === 'thermal' ? 0.3 : 0.0,
    clippingPlanes
  });

  const bearingsMat = new THREE.MeshStandardMaterial({
    color: mode === 'thermal' ? 0xd97706 : 0xe2e8f0,
    metalness: 0.96,
    roughness: 0.10,
    clippingPlanes
  });

  const sealsMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    metalness: 0.4,
    roughness: 0.6,
    clippingPlanes
  });

  const motorFinsMat = new THREE.MeshStandardMaterial({
    color: 0x11141a,
    metalness: 0.75,
    roughness: 0.4,
    clippingPlanes
  });

  const baseSkidMat = new THREE.MeshStandardMaterial({
    color: 0x0d1117,
    metalness: 0.6,
    roughness: 0.5,
    clippingPlanes
  });

  const flangeBoltsMat = new THREE.MeshStandardMaterial({
    color: 0xa1a1aa,
    metalness: 0.95,
    roughness: 0.12,
    clippingPlanes
  });

  const sensorsMat = new THREE.MeshStandardMaterial({
    color: accentColor,
    metalness: 0.8,
    roughness: 0.2,
    emissive: accentColor,
    emissiveIntensity: 0.4
  });

  const fluidCoreMat = new THREE.MeshPhysicalMaterial({
    color: 0xd97706,
    metalness: 0.1,
    roughness: 0.15,
    transmission: 0.65,
    thickness: 0.8,
    transparent: true,
    opacity: 0.85,
    clippingPlanes
  });

  glassXrayMat = new THREE.MeshPhysicalMaterial({
    color: 0x38bdf8,
    metalness: 0.1,
    roughness: 0.05,
    transmission: 0.92,
    thickness: 0.5,
    transparent: true,
    opacity: 0.25
  });

  return {
    casing: casingMat,
    internalMetal: internalMetalMat,
    shaft: shaftMat,
    impeller: impellerMat,
    bearings: bearingsMat,
    seals: sealsMat,
    motorHousing: motorHousingMat,
    motorFins: motorFinsMat,
    baseSkid: baseSkidMat,
    flangeBolts: flangeBoltsMat,
    sensors: sensorsMat,
    fluidCore: fluidCoreMat,
    glassXray: glassXrayMat,
    clippingPlanes
  };
}
