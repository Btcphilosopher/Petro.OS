// OILPULSE.OS — Viscous Fluid Streamline & Particle Animation Engine
import * as THREE from 'three';
import { FluidProperties } from '../simulation/fluids';
import { PumpType } from '../simulation/physics';

export class FluidParticleSystem {
  public particlePoints: THREE.Points;
  public streamlineGroup: THREE.Group;
  private particlePositions: Float32Array;
  private particleLifespans: Float32Array;
  private particleSpeeds: Float32Array;
  private particlePaths: Array<{ type: 'suction' | 'impeller' | 'discharge'; progress: number; radius: number; angle: number }>;
  private particleCount: number = 2400;
  private geometry: THREE.BufferGeometry;
  private material: THREE.PointsMaterial;

  constructor(scene: THREE.Group) {
    this.particleCount = 2400;
    this.particlePositions = new Float32Array(this.particleCount * 3);
    this.particleLifespans = new Float32Array(this.particleCount);
    this.particleSpeeds = new Float32Array(this.particleCount);
    this.particlePaths = [];

    // Initialize individual particle states
    for (let i = 0; i < this.particleCount; i++) {
      const progress = Math.random();
      const radius = 0.02 + Math.random() * 0.07;
      const angle = Math.random() * Math.PI * 2;
      this.particlePaths.push({
        type: progress < 0.35 ? 'suction' : (progress < 0.75 ? 'impeller' : 'discharge'),
        progress,
        radius,
        angle
      });
      this.particleLifespans[i] = Math.random();
      this.particleSpeeds[i] = 0.6 + Math.random() * 0.8;
      
      this.particlePositions[i * 3 + 0] = 0.7;
      this.particlePositions[i * 3 + 1] = 0;
      this.particlePositions[i * 3 + 2] = 0;
    }

    this.geometry = new THREE.BufferGeometry();
    this.geometry.setAttribute('position', new THREE.BufferAttribute(this.particlePositions, 3));

    // Canvas circular texture for smooth glowing particles
    const canvas = document.createElement('canvas');
    canvas.width = 32;
    canvas.height = 32;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      const gradient = ctx.createRadialGradient(16, 16, 0, 16, 16, 16);
      gradient.addColorStop(0, 'rgba(255, 255, 255, 1)');
      gradient.addColorStop(0.3, 'rgba(245, 158, 11, 0.85)');
      gradient.addColorStop(0.8, 'rgba(217, 119, 6, 0.25)');
      gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, 32, 32);
    }
    const texture = new THREE.CanvasTexture(canvas);

    this.material = new THREE.PointsMaterial({
      size: 0.042,
      map: texture,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      color: 0xf59e0b
    });

    this.particlePoints = new THREE.Points(this.geometry, this.material);
    this.particlePoints.name = 'FLUID_PARTICLES';
    scene.add(this.particlePoints);

    // Volumetric Streamline Tubes for "Flow Mode"
    this.streamlineGroup = new THREE.Group();
    this.streamlineGroup.name = 'FLUID_STREAMLINE_TUBES';
    this.buildStreamlines();
    scene.add(this.streamlineGroup);
  }

  private buildStreamlines() {
    const streamlineCount = 12;
    const lineMaterial = new THREE.MeshBasicMaterial({
      color: 0xf59e0b,
      transparent: true,
      opacity: 0.45,
      wireframe: true
    });

    for (let i = 0; i < streamlineCount; i++) {
      const angle = (i / streamlineCount) * Math.PI * 2;
      const points: THREE.Vector3[] = [];
      
      // Suction curve
      for (let s = 0; s < 5; s++) {
        const x = 1.1 - s * 0.09;
        points.push(new THREE.Vector3(x, Math.cos(angle) * 0.06, Math.sin(angle) * 0.06));
      }
      
      // Volute spiral swirl
      for (let v = 0; v < 8; v++) {
        const vAngle = angle + (v / 8) * Math.PI * 2;
        const r = 0.08 + (v / 8) * 0.16;
        points.push(new THREE.Vector3(0.68 + (Math.random() - 0.5) * 0.02, Math.cos(vAngle) * r, Math.sin(vAngle) * r));
      }
      
      // Discharge nozzle vertical
      for (let d = 0; d < 5; d++) {
        const y = 0.25 + d * 0.08;
        points.push(new THREE.Vector3(0.68, y, Math.sin(angle) * 0.05));
      }

      const curve = new THREE.CatmullRomCurve3(points);
      const tubeGeom = new THREE.TubeGeometry(curve, 32, 0.008, 6, false);
      const tube = new THREE.Mesh(tubeGeom, lineMaterial);
      this.streamlineGroup.add(tube);
    }
  }

  public setFluid(fluid: FluidProperties) {
    this.material.color.set(fluid.colorHex);
    this.material.opacity = fluid.particleOpacity;
  }

  public setVisible(showParticles: boolean, showStreamlines: boolean) {
    this.particlePoints.visible = showParticles;
    this.streamlineGroup.visible = showStreamlines;
  }

  public update(
    deltaSec: number,
    flowRateLpm: number,
    rpm: number,
    pumpType: PumpType,
    speedMultiplier: number
  ) {
    if (rpm <= 5 || flowRateLpm <= 1) {
      this.material.opacity = 0.15;
      return;
    }

    this.material.opacity = Math.min(0.95, 0.4 + (flowRateLpm / 1400) * 0.5);

    const positions = this.geometry.attributes.position.array as Float32Array;
    const baseSpeed = Math.max(0.15, speedMultiplier) * (0.8 + (flowRateLpm / 800));

    for (let i = 0; i < this.particleCount; i++) {
      const p = this.particlePaths[i];
      p.progress += deltaSec * baseSpeed * this.particleSpeeds[i] * 0.4;
      
      if (p.progress >= 1.0) {
        p.progress = 0.0;
        p.angle = Math.random() * Math.PI * 2;
        p.radius = 0.02 + Math.random() * 0.07;
      }

      let x = 0.7;
      let y = 0;
      let z = 0;

      if (pumpType === 'centrifugal') {
        if (p.progress < 0.35) {
          // Suction Stage (X: 1.15 -> 0.70)
          const norm = p.progress / 0.35;
          x = 1.15 - norm * 0.45;
          y = Math.cos(p.angle) * p.radius;
          z = Math.sin(p.angle) * p.radius;
        } else if (p.progress < 0.75) {
          // Impeller Spiral Swirl (Volute)
          const norm = (p.progress - 0.35) / 0.40;
          const swirlAngle = p.angle + norm * Math.PI * 4;
          const swirlRadius = p.radius + norm * 0.18;
          x = 0.68 + (Math.sin(norm * Math.PI) * 0.04);
          y = Math.cos(swirlAngle) * swirlRadius;
          z = Math.sin(swirlAngle) * swirlRadius;
        } else {
          // Discharge Stage (Y: 0.20 -> 0.65)
          const norm = (p.progress - 0.75) / 0.25;
          x = 0.68 + (Math.sin(p.angle) * 0.02);
          y = 0.22 + norm * 0.42;
          z = Math.cos(p.angle) * (p.radius * 0.7);
        }
      } else if (pumpType === 'gear') {
        // Gear pump side-to-side displacement
        if (p.progress < 0.3) {
          x = 0.65 + (Math.sin(p.angle) * 0.03);
          y = (Math.cos(p.angle) * 0.06);
          z = -0.35 + (p.progress / 0.3) * 0.22;
        } else if (p.progress < 0.7) {
          const norm = (p.progress - 0.3) / 0.4;
          x = 0.65 + (Math.sin(norm * Math.PI * 2) * 0.08);
          y = Math.cos(p.angle + norm * Math.PI * 3) * 0.14;
          z = -0.13 + norm * 0.26;
        } else {
          const norm = (p.progress - 0.7) / 0.3;
          x = 0.65 + (Math.sin(p.angle) * 0.03);
          y = (Math.cos(p.angle) * 0.06);
          z = 0.13 + norm * 0.22;
        }
      } else if (pumpType === 'screw') {
        // Screw pump continuous axial flow (X: 0.35 -> 1.05)
        const norm = p.progress;
        x = 0.38 + norm * 0.65;
        const helicalAngle = p.angle + norm * Math.PI * 8;
        y = Math.cos(helicalAngle) * 0.07;
        z = Math.sin(helicalAngle) * 0.07;
      } else {
        // Piston pump pulsating fluid displacement
        const cylIdx = i % 3;
        const zCyl = (cylIdx - 1) * 0.20;
        if (p.progress < 0.5) {
          x = 0.75 - (p.progress / 0.5) * 0.35;
          y = -0.15 + (p.progress / 0.5) * 0.15;
          z = zCyl + Math.sin(p.angle) * 0.03;
        } else {
          x = 0.40 + ((p.progress - 0.5) / 0.5) * 0.35;
          y = ((p.progress - 0.5) / 0.5) * 0.20;
          z = zCyl + Math.cos(p.angle) * 0.03;
        }
      }

      positions[i * 3 + 0] = x;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = z;
    }

    this.geometry.attributes.position.needsUpdate = true;
  }
}
