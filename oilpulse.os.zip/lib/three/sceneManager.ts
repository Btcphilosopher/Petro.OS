// OILPULSE.OS — Master Three.js Scene Controller & Renderer
import * as THREE from 'three';
import { createMaterials, MaterialPreset, VisualizationMode, MaterialLibrary } from './materials';
import { buildParametricPump, BuiltPumpModel, ComponentMetadata } from './pumpBuilder';
import { FluidParticleSystem } from './particles';
import { SimulationState, PumpType } from '../simulation/physics';

export type CameraMode = 'hero' | 'orbit' | 'macro' | 'shaft' | 'internal' | 'flow' | 'facility';

export interface SceneManagerOptions {
  canvas: HTMLCanvasElement;
  onSelectComponent?: (meta: ComponentMetadata | null) => void;
}

export class PumpSceneManager {
  private canvas: HTMLCanvasElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private materials: MaterialLibrary;
  private pumpModel: BuiltPumpModel | null = null;
  private fluidParticles: FluidParticleSystem | null = null;
  
  private currentPumpType: PumpType = 'centrifugal';
  private currentMaterialPreset: MaterialPreset = 'cast-titanium';
  private currentVizMode: VisualizationMode = 'standard';
  private currentCameraMode: CameraMode = 'hero';
  
  private animationFrameId: number | null = null;
  private lastTime: number = 0;
  private isOrbiting: boolean = false;
  private orbitAngle: number = 0.8;
  private orbitRadius: number = 3.2;
  private orbitHeight: number = 1.1;

  // Exploded View progress (0 = fully assembled, 1 = fully exploded)
  public explodedProgress: number = 0;
  private targetExplodedProgress: number = 0;

  // Interactive Orbit / Drag state
  private isUserDragging: boolean = false;
  private previousMousePosition = { x: 0, y: 0 };
  private cameraSpherical = { radius: 3.2, theta: 0.9, phi: 1.15 };
  private cameraTarget = new THREE.Vector3(0.05, 0.0, 0.0);
  private desiredCameraPosition = new THREE.Vector3(2.2, 1.3, 2.4);

  // Raycasting & Selection
  private raycaster = new THREE.Raycaster();
  private mouseVector = new THREE.Vector2();
  public selectedComponent: ComponentMetadata | null = null;
  private onSelectComponent?: (meta: ComponentMetadata | null) => void;

  // Grid & Studio Lights
  private gridHelper: THREE.GridHelper;
  private keyLight: THREE.DirectionalLight;
  private fillLight: THREE.DirectionalLight;
  private rimLight: THREE.DirectionalLight;

  constructor(options: SceneManagerOptions) {
    this.canvas = options.canvas;
    this.onSelectComponent = options.onSelectComponent;

    // 1. Renderer Setup
    this.renderer = new THREE.WebGLRenderer({
      canvas: this.canvas,
      antialias: true,
      powerPreference: 'high-performance',
      alpha: true
    });
    this.renderer.setSize(this.canvas.clientWidth, this.canvas.clientHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.localClippingEnabled = true;

    // 2. Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x060709);

    // 3. Camera
    this.camera = new THREE.PerspectiveCamera(
      42,
      this.canvas.clientWidth / this.canvas.clientHeight,
      0.1,
      50
    );
    this.setCameraPreset('hero');

    // 4. Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.65);
    this.scene.add(ambientLight);

    this.keyLight = new THREE.DirectionalLight(0xffffff, 2.4);
    this.keyLight.position.set(4, 5, 4);
    this.keyLight.castShadow = true;
    this.keyLight.shadow.mapSize.width = 2048;
    this.keyLight.shadow.mapSize.height = 2048;
    this.keyLight.shadow.bias = -0.0001;
    this.scene.add(this.keyLight);

    this.fillLight = new THREE.DirectionalLight(0x38bdf8, 0.9);
    this.fillLight.position.set(-4, 2, -3);
    this.scene.add(this.fillLight);

    this.rimLight = new THREE.DirectionalLight(0xf59e0b, 1.4);
    this.rimLight.position.set(0, 4, -4);
    this.scene.add(this.rimLight);

    // 5. Studio Floor Grid
    this.gridHelper = new THREE.GridHelper(10, 40, 0x374151, 0x1f2937);
    this.gridHelper.position.y = -0.52;
    this.scene.add(this.gridHelper);

    // Subtle Ground Shadow Plane
    const shadowPlaneGeom = new THREE.PlaneGeometry(8, 8);
    const shadowPlaneMat = new THREE.ShadowMaterial({ opacity: 0.45 });
    const shadowPlane = new THREE.Mesh(shadowPlaneGeom, shadowPlaneMat);
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.y = -0.518;
    shadowPlane.receiveShadow = true;
    this.scene.add(shadowPlane);

    // 6. Materials & Models
    this.materials = createMaterials(this.currentMaterialPreset, this.currentVizMode);
    this.rebuildPump();

    // 7. Event Listeners
    this.setupEventListeners();

    // 8. Start Render Loop
    this.lastTime = performance.now();
    this.animate();
  }

  private setupEventListeners() {
    this.canvas.addEventListener('mousedown', this.onMouseDown.bind(this));
    window.addEventListener('mousemove', this.onMouseMove.bind(this));
    window.addEventListener('mouseup', this.onMouseUp.bind(this));
    this.canvas.addEventListener('wheel', this.onWheel.bind(this), { passive: true });
    this.canvas.addEventListener('click', this.onClick.bind(this));
  }

  private onMouseDown(e: MouseEvent) {
    this.isUserDragging = true;
    this.previousMousePosition = { x: e.clientX, y: e.clientY };
  }

  private onMouseMove(e: MouseEvent) {
    const rect = this.canvas.getBoundingClientRect();
    this.mouseVector.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouseVector.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    if (!this.isUserDragging) return;

    const deltaX = e.clientX - this.previousMousePosition.x;
    const deltaY = e.clientY - this.previousMousePosition.y;

    this.cameraSpherical.theta -= deltaX * 0.007;
    this.cameraSpherical.phi = Math.max(0.15, Math.min(Math.PI / 2 - 0.05, this.cameraSpherical.phi - deltaY * 0.007));

    this.previousMousePosition = { x: e.clientX, y: e.clientY };
    this.currentCameraMode = 'hero';
  }

  private onMouseUp() {
    this.isUserDragging = false;
  }

  private onWheel(e: WheelEvent) {
    this.cameraSpherical.radius = Math.max(1.2, Math.min(8.0, this.cameraSpherical.radius + e.deltaY * 0.002));
  }

  private onClick(e: MouseEvent) {
    const rect = this.canvas.getBoundingClientRect();
    this.mouseVector.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouseVector.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.mouseVector, this.camera);
    if (!this.pumpModel) return;

    const intersects = this.raycaster.intersectObjects(this.pumpModel.rootGroup.children, true);
    if (intersects.length > 0) {
      let currentObj: THREE.Object3D | null = intersects[0].object;
      while (currentObj && currentObj !== this.pumpModel.rootGroup) {
        if (currentObj.name && this.pumpModel.componentMeshes.has(currentObj.name)) {
          const comp = this.pumpModel.componentMeshes.get(currentObj.name)!;
          this.selectedComponent = comp.meta;
          if (this.onSelectComponent) this.onSelectComponent(comp.meta);
          return;
        }
        currentObj = currentObj.parent;
      }
    }

    this.selectedComponent = null;
    if (this.onSelectComponent) this.onSelectComponent(null);
  }

  public rebuildPump(type: PumpType = this.currentPumpType, preset: MaterialPreset = this.currentMaterialPreset, mode: VisualizationMode = this.currentVizMode) {
    this.currentPumpType = type;
    this.currentMaterialPreset = preset;
    this.currentVizMode = mode;

    if (this.pumpModel) {
      this.scene.remove(this.pumpModel.rootGroup);
    }
    if (this.fluidParticles) {
      this.scene.remove(this.fluidParticles.particlePoints);
      this.scene.remove(this.fluidParticles.streamlineGroup);
    }

    this.materials = createMaterials(preset, mode);
    this.pumpModel = buildParametricPump(type, this.materials);
    this.scene.add(this.pumpModel.rootGroup);

    this.fluidParticles = new FluidParticleSystem(this.scene as unknown as THREE.Group);
    this.fluidParticles.setVisible(mode !== 'standard' || true, mode === 'flow');
  }

  public setExplodedViewProgress(progress: number) {
    this.targetExplodedProgress = Math.max(0, Math.min(1, progress));
  }

  public setVisualizationMode(mode: VisualizationMode) {
    this.rebuildPump(this.currentPumpType, this.currentMaterialPreset, mode);
  }

  public setMaterialPreset(preset: MaterialPreset) {
    this.rebuildPump(this.currentPumpType, preset, this.currentVizMode);
  }

  public setPumpType(type: PumpType) {
    this.rebuildPump(type, this.currentMaterialPreset, this.currentVizMode);
  }

  public setCameraPreset(mode: CameraMode) {
    this.currentCameraMode = mode;
    switch (mode) {
      case 'hero':
        this.cameraSpherical = { radius: 3.2, theta: 0.85, phi: 1.18 };
        this.cameraTarget.set(0.05, 0.05, 0);
        break;
      case 'orbit':
        this.isOrbiting = true;
        break;
      case 'macro':
        this.cameraSpherical = { radius: 1.45, theta: 1.25, phi: 1.10 };
        this.cameraTarget.set(0.68, 0.1, 0.1);
        break;
      case 'shaft':
        this.cameraSpherical = { radius: 2.1, theta: Math.PI / 2, phi: 1.3 };
        this.cameraTarget.set(-0.1, 0, 0);
        break;
      case 'internal':
        this.cameraSpherical = { radius: 1.1, theta: 0.4, phi: 1.25 };
        this.cameraTarget.set(0.65, 0, 0);
        break;
      case 'flow':
        this.cameraSpherical = { radius: 2.4, theta: 0.5, phi: 0.95 };
        this.cameraTarget.set(0.7, 0.15, 0);
        break;
      case 'facility':
        this.cameraSpherical = { radius: 6.2, theta: 0.8, phi: 1.05 };
        this.cameraTarget.set(0, 0, 0);
        break;
    }
  }

  public resize(width: number, height: number) {
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  public updateSimulation(state: SimulationState, deltaSec: number) {
    if (!this.pumpModel) return;

    // 1. Mechanical Rotation
    const dTheta = state.angularVelocityRadS * deltaSec;
    if (this.pumpModel.rotatingShaftGroup) {
      this.pumpModel.rotatingShaftGroup.rotation.x += dTheta;
    }

    // Secondary rotor (gear/screw) counter-rotates
    if (this.pumpModel.secondaryRotorGroup) {
      this.pumpModel.secondaryRotorGroup.rotation.x -= dTheta;
    }

    // Piston reciprocating motion
    if (this.pumpModel.pistonPlungers && this.pumpModel.pistonPlungers.length > 0) {
      const strokeProgress = performance.now() * 0.001 * state.angularVelocityRadS;
      this.pumpModel.pistonPlungers.forEach((plunger, idx) => {
        const phase = strokeProgress + (idx * (Math.PI * 2 / 3));
        plunger.position.x = 0.35 + Math.sin(phase) * 0.06;
      });
    }

    // 2. Physical Vibration Displacement Jitter
    if (state.rpm > 0) {
      this.pumpModel.rootGroup.position.set(
        state.displacementJitter.x,
        state.displacementJitter.y,
        state.displacementJitter.z
      );
    } else {
      this.pumpModel.rootGroup.position.set(0, 0, 0);
    }

    // 3. Fluid Particle System update
    if (this.fluidParticles) {
      this.fluidParticles.setFluid(state.fluid);
      this.fluidParticles.update(
        deltaSec,
        state.flowRateLpm,
        state.rpm,
        state.pumpType,
        state.particleSpeedMultiplier
      );
    }

    // 4. Sensor Indicators pulse glow
    this.pumpModel.sensorIndicators.forEach((sensor, i) => {
      const pulse = 0.3 + 0.7 * Math.abs(Math.sin(performance.now() * 0.004 + i));
      if (sensor.material instanceof THREE.MeshStandardMaterial) {
        sensor.material.emissiveIntensity = state.rpm > 0 ? pulse : 0.15;
      }
    });

    // 5. Thermal or Pressure color updates on materials
    if (this.currentVizMode === 'thermal') {
      const heatFactor = Math.min(1.0, (state.motorTempC - 20) / 75);
      const heatColor = new THREE.Color().setHSL(0.08 - heatFactor * 0.08, 0.95, 0.35 + heatFactor * 0.25);
      (this.materials.motorHousing as THREE.MeshStandardMaterial).emissive = heatColor;
      (this.materials.motorHousing as THREE.MeshStandardMaterial).emissiveIntensity = 0.2 + heatFactor * 0.6;
    }
  }

  private animate = () => {
    this.animationFrameId = requestAnimationFrame(this.animate);

    const now = performance.now();
    const deltaSec = Math.min(0.1, (now - this.lastTime) / 1000);
    this.lastTime = now;

    // Smooth lerp for exploded view
    this.explodedProgress += (this.targetExplodedProgress - this.explodedProgress) * 0.12;
    if (this.pumpModel) {
      this.pumpModel.componentMeshes.forEach((item) => {
        const targetPos = item.basePos.clone().add(
          item.meta.explodedOffset.clone().multiplyScalar(this.explodedProgress)
        );
        item.mesh.position.lerp(targetPos, 0.15);
      });
    }

    // Orbit Camera Update
    if (this.currentCameraMode === 'orbit') {
      this.cameraSpherical.theta += deltaSec * 0.22;
    }

    // Smooth Camera Spherical Interpolation
    const sinPhi = Math.sin(this.cameraSpherical.phi);
    const cosPhi = Math.cos(this.cameraSpherical.phi);
    const sinTheta = Math.sin(this.cameraSpherical.theta);
    const cosTheta = Math.cos(this.cameraSpherical.theta);

    this.desiredCameraPosition.set(
      this.cameraTarget.x + this.cameraSpherical.radius * sinPhi * sinTheta,
      this.cameraTarget.y + this.cameraSpherical.radius * cosPhi,
      this.cameraTarget.z + this.cameraSpherical.radius * sinPhi * cosTheta
    );

    this.camera.position.lerp(this.desiredCameraPosition, 0.08);
    this.camera.lookAt(this.cameraTarget);

    this.renderer.render(this.scene, this.camera);
  };

  public dispose() {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }
    this.renderer.dispose();
  }
}
