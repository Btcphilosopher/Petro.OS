// OILPULSE.OS — 3D Interactive Viewport with Component Inspector
'use client';

import React, { useEffect, useRef, useState } from 'react';
import { PumpSceneManager, CameraMode } from '../lib/three/sceneManager';
import { MaterialPreset, VisualizationMode } from '../lib/three/materials';
import { ComponentMetadata } from '../lib/three/pumpBuilder';
import { SimulationState, PumpParameters, PumpType } from '../lib/simulation/physics';
import { Camera, Layers, Scissors, Eye, Maximize2, Compass, Info, X } from 'lucide-react';

interface PumpViewportProps {
  simulationState: SimulationState;
  pumpParams: PumpParameters;
  vizMode: VisualizationMode;
  materialPreset: MaterialPreset;
  explodedProgress: number;
  onExplodedChange: (val: number) => void;
  onSelectComponentMeta: (meta: ComponentMetadata | null) => void;
  selectedComponent: ComponentMetadata | null;
}

const CAMERA_PRESETS: Array<{ id: CameraMode; label: string }> = [
  { id: 'hero', label: 'HERO' },
  { id: 'orbit', label: 'ORBIT' },
  { id: 'macro', label: 'IMPELLER' },
  { id: 'shaft', label: 'SHAFT' },
  { id: 'internal', label: 'SEAL' },
  { id: 'flow', label: 'FLOW' },
  { id: 'facility', label: 'BAY' }
];

export function PumpViewport({
  simulationState,
  pumpParams,
  vizMode,
  materialPreset,
  explodedProgress,
  onExplodedChange,
  onSelectComponentMeta,
  selectedComponent
}: PumpViewportProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const sceneManagerRef = useRef<PumpSceneManager | null>(null);
  const [activeCamera, setActiveCamera] = useState<CameraMode>('hero');
  const [fps, setFps] = useState<number>(60);

  // Initialize Three.js Scene
  useEffect(() => {
    if (!canvasRef.current) return;

    const manager = new PumpSceneManager({
      canvas: canvasRef.current,
      onSelectComponent: (meta) => {
        onSelectComponentMeta(meta);
      }
    });
    sceneManagerRef.current = manager;

    // Responsive Canvas Resize Observer
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        if (width > 0 && height > 0) {
          manager.resize(width, height);
        }
      }
    });

    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }

    // FPS loop
    let lastFpsTime = performance.now();
    let frameCount = 0;
    const fpsInterval = setInterval(() => {
      const now = performance.now();
      const elapsed = (now - lastFpsTime) / 1000;
      setFps(Math.round(frameCount / elapsed));
      frameCount = 0;
      lastFpsTime = now;
    }, 1000);

    const countFrame = () => {
      frameCount++;
      requestAnimationFrame(countFrame);
    };
    const reqId = requestAnimationFrame(countFrame);

    return () => {
      clearInterval(fpsInterval);
      cancelAnimationFrame(reqId);
      resizeObserver.disconnect();
      manager.dispose();
      sceneManagerRef.current = null;
    };
  }, []);

  // Sync Viz Mode & Material Preset
  useEffect(() => {
    if (sceneManagerRef.current) {
      sceneManagerRef.current.rebuildPump(pumpParams.pumpType, materialPreset, vizMode);
    }
  }, [pumpParams.pumpType, materialPreset, vizMode]);

  // Sync Exploded View
  useEffect(() => {
    if (sceneManagerRef.current) {
      sceneManagerRef.current.setExplodedViewProgress(explodedProgress);
    }
  }, [explodedProgress]);

  // Sync Simulation State per frame
  useEffect(() => {
    if (sceneManagerRef.current) {
      sceneManagerRef.current.updateSimulation(simulationState, 0.016);
    }
  }, [simulationState]);

  const handleSetCamera = (mode: CameraMode) => {
    setActiveCamera(mode);
    if (sceneManagerRef.current) {
      sceneManagerRef.current.setCameraPreset(mode);
    }
  };

  return (
    <div
      ref={containerRef}
      id="pump-3d-viewport-container"
      className="relative w-full h-full min-h-[480px] flex-1 overflow-hidden bg-[#060709] select-none"
    >
      {/* 3D Canvas */}
      <canvas ref={canvasRef} className="w-full h-full block cursor-grab active:cursor-grabbing outline-none" />

      {/* Top Left Floating Camera & Render Stats */}
      <div className="absolute top-4 left-4 z-20 flex flex-col space-y-2 pointer-events-none">
        {/* Camera Preset Toolbar */}
        <div className="pointer-events-auto flex items-center space-x-1 bg-black/60 backdrop-blur-md p-1 rounded border border-white/10 shadow-lg">
          <Camera className="w-3.5 h-3.5 text-orange-500 ml-1.5 mr-1" />
          {CAMERA_PRESETS.map((preset) => (
            <button
              key={preset.id}
              onClick={() => handleSetCamera(preset.id)}
              className={`px-2 py-0.5 rounded text-[10px] font-tech transition-all cursor-pointer ${
                activeCamera === preset.id
                  ? 'bg-orange-500 text-black font-bold'
                  : 'text-gray-400 hover:text-white hover:bg-white/10'
              }`}
            >
              {preset.label}
            </button>
          ))}
        </div>

        {/* Live FPS & Engine Specs */}
        <div className="flex items-center space-x-2 text-[10px] font-mono-num text-gray-400 bg-black/40 px-2 py-0.5 rounded border border-white/5 w-fit">
          <span className="flex items-center space-x-1 text-emerald-400">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>{fps} FPS</span>
          </span>
          <span>|</span>
          <span>PHYSICS 60Hz</span>
          <span>|</span>
          <span>PBR TONE MAP ACES</span>
        </div>
      </div>

      {/* Floating Component Inspector Card (When clicked) */}
      {selectedComponent && (
        <div className="absolute top-4 right-4 z-20 w-80 glass-panel p-4 rounded-lg border border-orange-500/40 bg-black/80 shadow-[0_8px_32px_rgba(0,0,0,0.8)] pointer-events-auto animate-in fade-in slide-in-from-right-4">
          <div className="flex justify-between items-start border-b border-white/10 pb-2 mb-2">
            <div>
              <span className="text-[9px] font-mono-num text-orange-400 uppercase tracking-widest block">
                COMPONENT TELEMETRY // {selectedComponent.id.toUpperCase()}
              </span>
              <h3 className="text-sm font-bold font-tech text-white">
                {selectedComponent.name}
              </h3>
            </div>
            <button
              onClick={() => onSelectComponentMeta(null)}
              className="p-1 rounded text-gray-400 hover:text-white hover:bg-white/10 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <p className="text-xs text-gray-300 leading-relaxed mb-3">
            {selectedComponent.description}
          </p>

          <div className="space-y-1.5 bg-black/60 p-2.5 rounded border border-white/5 text-[11px] font-mono-num">
            <div className="flex justify-between text-gray-300">
              <span className="text-gray-500 font-tech">ALLOY / MATERIAL:</span>
              <span className="text-orange-400">{selectedComponent.material}</span>
            </div>
            <div className="flex justify-between text-gray-300">
              <span className="text-gray-500 font-tech">OPERATING TEMP:</span>
              <span className="text-rose-400">{selectedComponent.operatingTempNominal}</span>
            </div>
            <div className="flex justify-between text-gray-300">
              <span className="text-gray-500 font-tech">WEAR CONDITION:</span>
              <span className="text-purple-400">{selectedComponent.wearCondition}</span>
            </div>
            <div className="flex justify-between text-gray-300">
              <span className="text-gray-500 font-tech">TOLERANCE:</span>
              <span className="text-emerald-400 font-bold">{selectedComponent.tolerance}</span>
            </div>
          </div>
        </div>
      )}

      {/* Orbit Interaction Helper Hint */}
      <div className="absolute bottom-4 left-4 z-10 pointer-events-none text-[10px] font-tech text-gray-400 bg-black/40 px-2.5 py-1 rounded border border-white/5 flex items-center space-x-1.5">
        <Compass className="w-3.5 h-3.5 text-amber-400" />
        <span>Left Click + Drag to Orbit | Scroll to Zoom | Click any 3D part to inspect</span>
      </div>
    </div>
  );
}
