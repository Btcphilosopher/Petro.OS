// OILPULSE.OS — Precision Engineering Parameters & Material Control Panel
'use client';

import React from 'react';
import { PumpParameters, PumpType } from '../lib/simulation/physics';
import { FluidProperties, FLUID_DATABASE } from '../lib/simulation/fluids';
import { MaterialPreset } from '../lib/three/materials';
import { Sliders, Sparkles, Layers, Palette, RefreshCw } from 'lucide-react';

interface ControlPanelProps {
  params: PumpParameters;
  onUpdateParams: (updated: Partial<PumpParameters>) => void;
  materialPreset: MaterialPreset;
  onSetMaterial: (preset: MaterialPreset) => void;
  explodedProgress: number;
  onSetExploded: (val: number) => void;
  onOptimize: () => void;
  onSelectFluid: (fluid: FluidProperties) => void;
}

const PUMP_TYPES: Array<{ id: PumpType; label: string; desc: string }> = [
  { id: 'centrifugal', label: 'CENTRIFUGAL', desc: 'API 610 Spiral Volute' },
  { id: 'gear', label: 'GEAR PUMP', desc: 'Positive Displacement External' },
  { id: 'screw', label: 'SCREW PUMP', desc: 'Twin Archimedean Spindles' },
  { id: 'piston', label: 'PISTON PUMP', desc: 'Triplex High-Pressure Plunger' },
];

const MATERIAL_PRESETS: Array<{ id: MaterialPreset; label: string }> = [
  { id: 'cast-titanium', label: 'Cast Titanium' },
  { id: 'brushed-steel', label: 'Brushed Steel' },
  { id: 'carbon-composite', label: 'Carbon Composite' },
  { id: 'marine-bronze', label: 'Marine Bronze' },
  { id: 'anodized-cyan', label: 'Anodized Cyan' },
  { id: 'ceramic-white', label: 'Ceramic White' },
];

export function ControlPanel({
  params,
  onUpdateParams,
  materialPreset,
  onSetMaterial,
  explodedProgress,
  onSetExploded,
  onOptimize,
  onSelectFluid
}: ControlPanelProps) {
  return (
    <div id="control-panel-drawer" className="w-full lg:w-80 glass-panel border-l border-white/10 p-4 flex flex-col space-y-5 overflow-y-auto max-h-[calc(100vh-140px)] select-none">
      {/* Panel Header */}
      <div className="flex items-center justify-between border-b border-white/10 pb-3">
        <div className="flex items-center space-x-2">
          <Sliders className="w-4 h-4 text-orange-500" />
          <h2 className="text-xs font-bold tracking-wider text-white font-tech uppercase">
            ENGINEERING PARAMETERS
          </h2>
        </div>
        <button
          onClick={onOptimize}
          className="flex items-center space-x-1 px-2 py-1 rounded text-[10px] font-tech text-orange-400 bg-orange-500/10 border border-orange-500/40 hover:bg-orange-500/20 transition-all cursor-pointer"
          title="Find Best Efficiency Point (BEP)"
        >
          <Sparkles className="w-3 h-3 text-orange-500" />
          <span>BEP OPTIMIZE</span>
        </button>
      </div>

      {/* 1. Pump Archetype Switcher */}
      <div className="space-y-1.5">
        <label className="text-[10px] font-tech text-gray-400 tracking-wider">
          PUMP ARCHETYPE
        </label>
        <div className="grid grid-cols-2 gap-1.5">
          {PUMP_TYPES.map((pt) => (
            <button
              key={pt.id}
              onClick={() => onUpdateParams({ pumpType: pt.id })}
              className={`p-2 rounded text-left transition-all cursor-pointer ${
                params.pumpType === pt.id
                  ? 'bg-orange-500/20 border border-orange-500/60 text-white'
                  : 'bg-white/5 border border-white/5 text-gray-400 hover:text-gray-200'
              }`}
            >
              <div className="text-[11px] font-bold font-tech text-orange-400">
                {pt.label}
              </div>
              <div className="text-[9px] text-gray-400 truncate">
                {pt.desc}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* 2. Fluid Selection */}
      <div className="space-y-1.5">
        <div className="flex justify-between items-center">
          <label className="text-[10px] font-tech text-gray-400 tracking-wider">
            HYDROCARBON FLUID
          </label>
          <span className="text-[9px] font-mono-num text-orange-400">
            {FLUID_DATABASE[params.fluidId]?.density} kg/m³
          </span>
        </div>
        <select
          value={params.fluidId}
          onChange={(e) => {
            const fluid = FLUID_DATABASE[e.target.value];
            if (fluid) {
              onUpdateParams({ fluidId: fluid.id });
              onSelectFluid(fluid);
            }
          }}
          className="w-full bg-black/60 border border-white/15 rounded p-2 text-xs text-white font-mono-num outline-none focus:border-orange-500 cursor-pointer"
        >
          {Object.values(FLUID_DATABASE).map((f) => (
            <option key={f.id} value={f.id} className="bg-gray-900 text-white">
              {f.name} ({(f.dynamicViscosity20C * 1000).toFixed(1)} cP)
            </option>
          ))}
        </select>
      </div>

      {/* 3. Primary Sliders */}
      <div className="space-y-4 pt-1">
        {/* RPM */}
        <div className="space-y-1">
          <div className="flex justify-between text-[11px] font-tech text-gray-300">
            <span>SHAFT SPEED (RPM)</span>
            <span className="font-mono-num text-orange-400 font-bold">{params.targetRpm} RPM</span>
          </div>
          <input
            type="range"
            min={0}
            max={4500}
            step={50}
            value={params.targetRpm}
            onChange={(e) => {
              const val = parseInt(e.target.value);
              onUpdateParams({ targetRpm: val, currentRpm: val });
            }}
            className="w-full cursor-pointer"
          />
          <div className="flex justify-between text-[9px] text-gray-500 font-mono-num">
            <span>0 RPM</span>
            <span>1800</span>
            <span>3600 (Nominal)</span>
            <span>4500</span>
          </div>
        </div>

        {/* Valve Throttling */}
        <div className="space-y-1">
          <div className="flex justify-between text-[11px] font-tech text-gray-300">
            <span>DISCHARGE VALVE OPEN</span>
            <span className="font-mono-num text-orange-400 font-bold">{params.valveOpenPercent}%</span>
          </div>
          <input
            type="range"
            min={5}
            max={100}
            step={1}
            value={params.valveOpenPercent}
            onChange={(e) => onUpdateParams({ valveOpenPercent: parseInt(e.target.value) })}
            className="w-full cursor-pointer"
          />
        </div>

        {/* Inlet Pressure */}
        <div className="space-y-1">
          <div className="flex justify-between text-[11px] font-tech text-gray-300">
            <span>SUCTION PRESSURE</span>
            <span className="font-mono-num text-cyan-400 font-bold">{params.inletPressureBar.toFixed(1)} bar</span>
          </div>
          <input
            type="range"
            min={0.2}
            max={10.0}
            step={0.1}
            value={params.inletPressureBar}
            onChange={(e) => onUpdateParams({ inletPressureBar: parseFloat(e.target.value) })}
            className="w-full cursor-pointer"
          />
        </div>

        {/* Backpressure */}
        <div className="space-y-1">
          <div className="flex justify-between text-[11px] font-tech text-gray-300">
            <span>PIPELINE BACKPRESSURE</span>
            <span className="font-mono-num text-rose-400 font-bold">{params.pipeBackpressureBar.toFixed(1)} bar</span>
          </div>
          <input
            type="range"
            min={2.0}
            max={50.0}
            step={0.5}
            value={params.pipeBackpressureBar}
            onChange={(e) => onUpdateParams({ pipeBackpressureBar: parseFloat(e.target.value) })}
            className="w-full cursor-pointer"
          />
        </div>

        {/* Fluid Temperature */}
        <div className="space-y-1">
          <div className="flex justify-between text-[11px] font-tech text-gray-300">
            <span>FLUID TEMPERATURE</span>
            <span className="font-mono-num text-yellow-400 font-bold">{params.fluidTempC.toFixed(0)} °C</span>
          </div>
          <input
            type="range"
            min={5}
            max={120}
            step={1}
            value={params.fluidTempC}
            onChange={(e) => onUpdateParams({ fluidTempC: parseFloat(e.target.value) })}
            className="w-full cursor-pointer"
          />
        </div>
      </div>

      {/* 4. Exploded View Slider */}
      <div className="space-y-1.5 border-t border-white/10 pt-3">
        <div className="flex justify-between items-center text-[11px] font-tech text-gray-300">
          <div className="flex items-center space-x-1.5">
            <Layers className="w-3.5 h-3.5 text-orange-500" />
            <span>EXPLODED SEPARATION</span>
          </div>
          <span className="font-mono-num text-orange-400 font-bold">{Math.round(explodedProgress * 100)}%</span>
        </div>
        <input
          type="range"
          min={0}
          max={1}
          step={0.01}
          value={explodedProgress}
          onChange={(e) => onSetExploded(parseFloat(e.target.value))}
          className="w-full cursor-pointer"
        />
      </div>

      {/* 5. 3D Material / Finish Preset */}
      <div className="space-y-1.5 border-t border-white/10 pt-3">
        <div className="flex items-center space-x-1.5 text-[10px] font-tech text-gray-400 tracking-wider">
          <Palette className="w-3.5 h-3.5 text-gray-400" />
          <span>METALLIC PBR MATERIAL</span>
        </div>
        <div className="grid grid-cols-3 gap-1">
          {MATERIAL_PRESETS.map((mat) => (
            <button
              key={mat.id}
              onClick={() => onSetMaterial(mat.id)}
              className={`px-2 py-1 rounded text-[10px] font-tech truncate transition-all cursor-pointer ${
                materialPreset === mat.id
                  ? 'bg-orange-500/20 border border-orange-500/50 text-orange-400 font-semibold'
                  : 'bg-white/5 border border-white/5 text-gray-400 hover:text-gray-200'
              }`}
            >
              {mat.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
