// OILPULSE.OS — Manufacturing Digital Twin & Metrology Pipeline
'use client';

import React, { useState } from 'react';
import { DigitalTwinPassport } from '../lib/simulation/digitalTwin';
import { Factory, CheckCircle2, ShieldCheck, Cpu, ArrowRight, Play, RotateCcw, QrCode, FileCheck } from 'lucide-react';

interface ManufacturingTwinProps {
  passport: DigitalTwinPassport;
  onJumpToStage?: (stageIndex: number) => void;
}

const MANUFACTURING_STAGES = [
  {
    id: 'casting',
    title: '01. Raw Super-Duplex Casting',
    facility: 'Böhler Precision Foundry (Linz)',
    process: 'Vacuum induction melting and ceramic investment casting of ASTM A995 Grade 4A volute body.',
    specs: 'Tensile Strength: 760 MPa | Ferrite Content: 48.5% | Radiographic Quality: ASTM E446 Level 1'
  },
  {
    id: 'cnc',
    title: '02. 5-Axis CNC Precision Milling',
    facility: 'DMG MORI Ultrasonic Machine Cell',
    process: 'Simultaneous 5-axis trochoidal milling of logarithmic impeller vanes and spiral volute tongue.',
    specs: 'Surface Roughness Ra: 0.4 µm | Geometric True Position: ±0.008 mm'
  },
  {
    id: 'shaft',
    title: '03. Induction Shaft Grinding',
    facility: 'Studer CNC Precision Grinding Rig',
    process: 'Induction surface hardening (52 HRC) and sub-micron cylindrical grinding on bearing journals.',
    specs: 'Radial TIR: 0.002 mm (Tolerance h6) | Cylindricity: 0.0015 mm'
  },
  {
    id: 'balancing',
    title: '04. Dynamic Rotor Balancing',
    facility: 'Schenck High-Speed Balancing Rig',
    process: 'Two-plane dynamic balance correction at 4500 RPM to eliminate 1× rotational mass eccentricity.',
    specs: 'Residual Unbalance: 0.38 g·mm | ISO 1940 Grade: G1.0 Ultra-Precision'
  },
  {
    id: 'seals',
    title: '05. Mechanical Seal Lapping',
    facility: 'John Crane Cleanroom Assembly',
    process: 'Monochromatic diamond lapping of silicon carbide vs carbon seal faces with barrier fluid porting.',
    specs: 'Face Flatness: 0.6 Helium Light Bands | Leakage Proof: 0.00 mL/hr'
  },
  {
    id: 'hydro',
    title: '06. Hydrostatic Pressure Proof Test',
    facility: 'Resato High-Pressure Hydro Bunker',
    process: '30-minute hydrostatic pressure hold at 1.5× rated casing pressure with calibrated transducer log.',
    specs: 'Test Pressure: 24.5 MPa (245 bar) | Pressure Decay: 0.000 MPa (Pass)'
  },
  {
    id: 'cmm',
    title: '07. CMM 3D Laser Metrology',
    facility: 'Zeiss Prismo Metrology Lab (20.0°C)',
    process: 'Full 3D coordinate point cloud scan verifying 142 critical geometric dimensions and GD&T datum.',
    specs: 'Conformity Score: 100% (142/142 Features Pass) | Uncertainty: ±0.5 µm'
  },
  {
    id: 'digital_twin',
    title: '08. Digital Twin Serialization',
    facility: 'OILPULSE.OS Genesis Registry',
    process: 'Immutable digital twin asset creation with embedded tolerance certificates, CAD hash, and QR passport.',
    specs: 'Asset ID: OILPULSE-P01 | Serial: SN-2035-HYD-98842 | Status: COMMISSIONED'
  }
];

export function ManufacturingTwin({ passport }: ManufacturingTwinProps) {
  const [activeStageIdx, setActiveStageIdx] = useState(0);
  const [isPlayingSeq, setIsPlayingSeq] = useState(false);

  const activeStage = MANUFACTURING_STAGES[activeStageIdx];

  const handleNext = () => {
    setActiveStageIdx((prev) => (prev + 1) % MANUFACTURING_STAGES.length);
  };

  const handlePrev = () => {
    setActiveStageIdx((prev) => (prev - 1 + MANUFACTURING_STAGES.length) % MANUFACTURING_STAGES.length);
  };

  return (
    <div id="manufacturing-twin-view" className="glass-panel p-4 md:p-6 rounded-lg border border-white/10 flex flex-col space-y-5 max-w-4xl mx-auto my-auto select-none shadow-[0_8px_32px_rgba(0,0,0,0.6)]">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 border-b border-white/10 pb-3">
        <div className="flex items-center space-x-2">
          <Factory className="w-4 h-4 text-amber-400" />
          <div>
            <h2 className="text-sm font-bold tracking-wider text-white font-tech uppercase">
              MANUFACTURING DIGITAL TWIN & METROLOGY LEDGER
            </h2>
            <p className="text-[11px] text-gray-400 font-mono-num">
              Traceable cradle-to-commissioning production lifecycle for {passport.serialNumber}
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 bg-white/5 px-2.5 py-1 rounded border border-white/10 text-xs font-mono-num text-amber-300">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>API 610 12TH ED / ISO 13709</span>
        </div>
      </div>

      {/* Stage Progression Steps */}
      <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5">
        {MANUFACTURING_STAGES.map((s, idx) => {
          const isSelected = activeStageIdx === idx;
          const isCompleted = idx <= activeStageIdx;
          return (
            <button
              key={s.id}
              onClick={() => setActiveStageIdx(idx)}
              className={`p-1.5 rounded text-center transition-all cursor-pointer border ${
                isSelected
                  ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-[0_0_8px_rgba(245,158,11,0.3)]'
                  : isCompleted
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                  : 'bg-white/5 border-white/5 text-gray-500 hover:text-gray-300'
              }`}
            >
              <div className="text-[10px] font-mono-num font-bold">0{idx + 1}</div>
              <div className="text-[8px] font-tech truncate">{s.title.split(' ')[1]}</div>
            </button>
          );
        })}
      </div>

      {/* Active Stage Detail Card */}
      <div className="glass-panel p-4 rounded border border-amber-500/30 bg-black/40 flex flex-col space-y-3">
        <div className="flex justify-between items-start">
          <div>
            <div className="text-xs font-mono-num text-amber-400 font-bold uppercase tracking-wider">
              {activeStage.title}
            </div>
            <div className="text-[11px] text-gray-400 font-tech mt-0.5">
              Facility: {activeStage.facility}
            </div>
          </div>
          <span className="px-2 py-0.5 rounded text-[10px] font-tech bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
            METROLOGY VERIFIED
          </span>
        </div>

        <p className="text-xs text-gray-300 leading-relaxed">
          {activeStage.process}
        </p>

        <div className="bg-black/60 p-2.5 rounded border border-white/10 text-[11px] font-mono-num text-emerald-400">
          <span className="text-gray-400 font-tech text-[9px] block mb-1">INSPECTION TOLERANCES & METRICS:</span>
          {activeStage.specs}
        </div>
      </div>

      {/* CMM Metrology Tolerances Table */}
      <div className="space-y-1.5">
        <div className="flex items-center space-x-2 text-[11px] font-tech text-gray-300">
          <FileCheck className="w-3.5 h-3.5 text-amber-400" />
          <span>FACTORY CMM DIMENSIONAL INSPECTION DATA (ZEISS PRISMO)</span>
        </div>
        <div className="w-full overflow-x-auto border border-white/10 rounded">
          <table className="w-full text-left text-[10px] font-mono-num">
            <thead className="bg-white/5 text-gray-400 border-b border-white/10">
              <tr>
                <th className="p-2">FEATURE NAME</th>
                <th className="p-2">NOMINAL</th>
                <th className="p-2">TOLERANCE</th>
                <th className="p-2">MEASURED</th>
                <th className="p-2">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {passport.metrologyRecords.map((m, i) => (
                <tr key={i} className="hover:bg-white/5">
                  <td className="p-2 text-white">{m.featureName}</td>
                  <td className="p-2 text-gray-400">{m.nominalValue} {m.unit}</td>
                  <td className="p-2 text-gray-400">+{m.tolerancePlus} / -{m.toleranceMinus}</td>
                  <td className="p-2 text-amber-300 font-bold">{m.measuredValue} {m.unit}</td>
                  <td className="p-2">
                    <span className="text-[9px] font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/30">
                      {m.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Bottom Passport Footer */}
      <div className="flex flex-col sm:flex-row justify-between items-center gap-3 border-t border-white/10 pt-3 text-[11px] font-mono-num text-gray-400">
        <div className="flex items-center space-x-3">
          <QrCode className="w-4 h-4 text-amber-400" />
          <span>DIGITAL PASSPORT HASH: <strong className="text-white font-tech">0x8842...98A1</strong></span>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handlePrev}
            className="px-3 py-1 rounded bg-white/5 hover:bg-white/10 text-white font-tech text-xs border border-white/10 cursor-pointer"
          >
            PREV STAGE
          </button>
          <button
            onClick={handleNext}
            className="px-3 py-1 rounded bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-tech text-xs border border-amber-500/50 cursor-pointer"
          >
            NEXT STAGE →
          </button>
        </div>
      </div>
    </div>
  );
}
