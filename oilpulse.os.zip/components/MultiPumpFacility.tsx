// OILPULSE.OS — Multi-Pump Bay Facility Overview & Load Sharing
'use client';

import React, { useState } from 'react';
import { Grid, Activity, Zap, Droplet, ArrowRight, ShieldCheck, Power } from 'lucide-react';
import { SimulationState } from '../lib/simulation/physics';

interface MultiPumpProps {
  leadPumpState: SimulationState;
  onSelectPump: (pumpId: string) => void;
}

interface FacilityPump {
  id: string;
  tag: string;
  name: string;
  role: string;
  rpm: number;
  flowLpm: number;
  powerKw: number;
  tempC: number;
  status: 'ONLINE' | 'STANDBY' | 'WARNING' | 'TRIPPED';
  loadPercent: number;
}

export function MultiPumpFacility({ leadPumpState, onSelectPump }: MultiPumpProps) {
  const [pumps, setPumps] = useState<FacilityPump[]>([
    {
      id: 'P-101',
      tag: 'P-101-ALPHA',
      name: 'Primary Process Lead Pump',
      role: 'Heavy Crude Main Feed Train',
      rpm: 3600,
      flowLpm: 1250,
      powerKw: 52.4,
      tempC: 68.4,
      status: 'ONLINE',
      loadPercent: 88
    },
    {
      id: 'P-102',
      tag: 'P-102-BETA',
      name: 'Secondary Parallel Booster',
      role: 'Load-Sharing Distribution',
      rpm: 3400,
      flowLpm: 1180,
      powerKw: 48.9,
      tempC: 65.2,
      status: 'ONLINE',
      loadPercent: 82
    },
    {
      id: 'P-103',
      tag: 'P-103-GAMMA',
      name: 'High-Pressure Injection',
      role: 'Downstream Transfer Line',
      rpm: 2900,
      flowLpm: 950,
      powerKw: 41.2,
      tempC: 62.0,
      status: 'ONLINE',
      loadPercent: 70
    },
    {
      id: 'P-104',
      tag: 'P-104-DELTA',
      name: 'Emergency Hot Standby',
      role: 'N+1 Redundancy Backup',
      rpm: 0,
      flowLpm: 0,
      powerKw: 0.8,
      tempC: 24.5,
      status: 'STANDBY',
      loadPercent: 0
    }
  ]);

  const [activePumpId, setActivePumpId] = useState('P-101');

  // Compute facility aggregates
  const totalFlow = pumps.reduce((acc, p) => acc + (p.status === 'ONLINE' ? p.flowLpm : 0), 0);
  const totalPower = pumps.reduce((acc, p) => acc + (p.status === 'ONLINE' ? p.powerKw : 0), 0);

  const togglePumpPower = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setPumps((prev) =>
      prev.map((p) => {
        if (p.id !== id) return p;
        if (p.status === 'ONLINE') {
          return { ...p, status: 'STANDBY', rpm: 0, flowLpm: 0, powerKw: 0.5, loadPercent: 0 };
        } else {
          return { ...p, status: 'ONLINE', rpm: 3400, flowLpm: 1150, powerKw: 48.0, loadPercent: 80 };
        }
      })
    );
  };

  return (
    <div id="multi-pump-facility-view" className="glass-panel p-4 md:p-6 rounded-lg border border-white/10 flex flex-col space-y-5 max-w-4xl mx-auto my-auto select-none shadow-[0_8px_32px_rgba(0,0,0,0.6)]">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 border-b border-white/10 pb-3">
        <div className="flex items-center space-x-2">
          <Grid className="w-4 h-4 text-amber-400" />
          <div>
            <h2 className="text-sm font-bold tracking-wider text-white font-tech uppercase">
              TRAIN ALPHA // 4-BAY FACILITY PUMP STATION
            </h2>
            <p className="text-[11px] text-gray-400 font-mono-num">
              Supermodern parallel pumping array with dynamic load sharing & auto-failover
            </p>
          </div>
        </div>

        {/* Facility Summary Badges */}
        <div className="flex items-center space-x-3 text-xs font-mono-num">
          <div className="flex items-center space-x-1.5 bg-white/5 px-2.5 py-1 rounded border border-white/10 text-amber-300">
            <Droplet className="w-3.5 h-3.5 text-amber-400" />
            <span>{totalFlow.toLocaleString()} L/min TOTAL</span>
          </div>
          <div className="flex items-center space-x-1.5 bg-white/5 px-2.5 py-1 rounded border border-white/10 text-cyan-300">
            <Zap className="w-3.5 h-3.5 text-cyan-400" />
            <span>{totalPower.toFixed(1)} kW TOTAL</span>
          </div>
        </div>
      </div>

      {/* 4 Pump Bay Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {pumps.map((pump) => {
          const isSelected = activePumpId === pump.id;
          const isOnline = pump.status === 'ONLINE';

          return (
            <div
              key={pump.id}
              onClick={() => {
                setActivePumpId(pump.id);
                onSelectPump(pump.id);
              }}
              className={`p-4 rounded-lg border transition-all cursor-pointer flex flex-col justify-between space-y-3 ${
                isSelected
                  ? 'bg-amber-500/15 border-amber-500 shadow-[0_0_16px_rgba(245,158,11,0.25)]'
                  : 'bg-white/5 border-white/10 hover:border-white/20'
              }`}
            >
              {/* Pump Header */}
              <div className="flex justify-between items-start">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-mono-num font-bold text-amber-400">{pump.tag}</span>
                    <span className={`text-[9px] font-tech px-1.5 py-0.5 rounded ${
                      isOnline ? 'bg-emerald-500/20 text-emerald-300' : 'bg-gray-500/20 text-gray-400'
                    }`}>
                      {pump.status}
                    </span>
                  </div>
                  <div className="text-[11px] font-tech text-white font-semibold mt-0.5">
                    {pump.name}
                  </div>
                  <div className="text-[9px] text-gray-400">
                    {pump.role}
                  </div>
                </div>

                <button
                  onClick={(e) => togglePumpPower(pump.id, e)}
                  className={`p-1.5 rounded transition-all cursor-pointer ${
                    isOnline ? 'bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30' : 'bg-white/10 text-gray-400 hover:bg-white/20'
                  }`}
                  title="Toggle Pump State"
                >
                  <Power className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Metrics */}
              <div className="grid grid-cols-3 gap-2 bg-black/40 p-2.5 rounded border border-white/5 text-center font-mono-num">
                <div>
                  <span className="text-[9px] text-gray-400 block font-tech">SPEED</span>
                  <strong className="text-xs text-white">{pump.rpm} RPM</strong>
                </div>
                <div>
                  <span className="text-[9px] text-gray-400 block font-tech">FLOW</span>
                  <strong className="text-xs text-amber-400">{pump.flowLpm} L/min</strong>
                </div>
                <div>
                  <span className="text-[9px] text-gray-400 block font-tech">TEMP</span>
                  <strong className="text-xs text-rose-400">{pump.tempC}°C</strong>
                </div>
              </div>

              {/* Load Bar */}
              <div className="space-y-1">
                <div className="flex justify-between text-[9px] font-tech text-gray-400">
                  <span>CAPACITY LOAD</span>
                  <span className="font-mono-num text-amber-300">{pump.loadPercent}%</span>
                </div>
                <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-amber-500 to-amber-300 rounded-full"
                    style={{ width: `${pump.loadPercent}%` }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer */}
      <div className="flex justify-between items-center text-[11px] font-mono-num text-gray-400 border-t border-white/10 pt-3">
        <span>FACILITY REDUNDANCY: <strong className="text-emerald-400 font-tech">N+1 ACTIVE</strong></span>
        <span className="text-amber-400 font-tech cursor-pointer hover:underline">
          INSPECT CURRENT DIGITAL TWIN (P-101) →
        </span>
      </div>
    </div>
  );
}
