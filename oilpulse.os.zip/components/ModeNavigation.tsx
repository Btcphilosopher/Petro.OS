// OILPULSE.OS — Supermodern Mode Navigation System
'use client';

import React from 'react';
import { 
  Box, 
  Scissors, 
  Eye, 
  Wind, 
  Gauge, 
  Thermometer, 
  Activity, 
  Layers, 
  TrendingUp, 
  Factory, 
  FileCheck, 
  Wrench, 
  Grid, 
  BookOpen, 
  Film 
} from 'lucide-react';

export type AppViewMode = 
  | 'twin'
  | 'cutaway'
  | 'xray'
  | 'flow'
  | 'pressure'
  | 'thermal'
  | 'vibration'
  | 'exploded'
  | 'curves'
  | 'manufacturing'
  | 'metrology'
  | 'faults'
  | 'facility'
  | 'engineering'
  | 'cinematic';

interface ModeNavProps {
  currentMode: AppViewMode;
  onSelectMode: (mode: AppViewMode) => void;
}

const MODES: Array<{ id: AppViewMode; label: string; icon: React.ElementType; category: string }> = [
  { id: 'twin', label: '3D TWIN', icon: Box, category: 'hero' },
  { id: 'cutaway', label: 'CUTAWAY', icon: Scissors, category: '3d' },
  { id: 'xray', label: 'X-RAY', icon: Eye, category: '3d' },
  { id: 'flow', label: 'FLOW FIELD', icon: Wind, category: '3d' },
  { id: 'pressure', label: 'PRESSURE', icon: Gauge, category: '3d' },
  { id: 'thermal', label: 'THERMAL', icon: Thermometer, category: '3d' },
  { id: 'vibration', label: 'VIBRATION', icon: Activity, category: '3d' },
  { id: 'exploded', label: 'EXPLODED', icon: Layers, category: '3d' },
  { id: 'curves', label: 'PUMP LAB', icon: TrendingUp, category: 'lab' },
  { id: 'manufacturing', label: 'MANUFACTURING', icon: Factory, category: 'twin' },
  { id: 'metrology', label: 'METROLOGY', icon: FileCheck, category: 'twin' },
  { id: 'faults', label: 'FAULTS & REPAIR', icon: Wrench, category: 'ops' },
  { id: 'facility', label: '4-TRAIN BAY', icon: Grid, category: 'ops' },
  { id: 'engineering', label: 'EQUATIONS', icon: BookOpen, category: 'doc' },
  { id: 'cinematic', label: 'CINEMATIC', icon: Film, category: 'view' },
];

export function ModeNavigation({ currentMode, onSelectMode }: ModeNavProps) {
  return (
    <div id="mode-navigation-bar" className="w-full glass-panel border-b border-white/10 px-3 py-1.5 flex items-center space-x-1 overflow-x-auto select-none z-25 scrollbar-none">
      {MODES.map((m) => {
        const Icon = m.icon;
        const isActive = currentMode === m.id;
        return (
          <button
            key={m.id}
            id={`nav-mode-${m.id}`}
            onClick={() => onSelectMode(m.id)}
            className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded text-[11px] font-tech tracking-wider whitespace-nowrap transition-all cursor-pointer ${
              isActive
                ? 'bg-orange-500/20 text-orange-400 border border-orange-500/50 shadow-[0_0_12px_rgba(242,125,38,0.25)] font-semibold'
                : 'text-gray-400 hover:text-gray-200 hover:bg-white/5 border border-transparent'
            }`}
          >
            <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-orange-500' : 'text-gray-400'}`} />
            <span>{m.label}</span>
          </button>
        );
      })}
    </div>
  );
}
