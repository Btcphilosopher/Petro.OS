// OILPULSE.OS — Hero Telemetry Overlay with Supermodern Readouts
'use client';

import React from 'react';
import { SimulationState } from '../lib/simulation/physics';
import { FluidProperties, FLUID_DATABASE } from '../lib/simulation/fluids';
import { Droplet, Activity, Zap, Gauge, Thermometer, ShieldAlert, Volume2, VolumeX, Sparkles } from 'lucide-react';

interface HeroTelemetryProps {
  state: SimulationState;
  unitSystem: 'SI' | 'Imperial';
  onToggleUnit: () => void;
  onSelectFluid: (fluid: FluidProperties) => void;
  isAudioMuted: boolean;
  onToggleAudio: () => void;
  onOpenOptimizer: () => void;
  onStartSimulation: () => void;
  isStarted: boolean;
}

export function HeroTelemetryOverlay({
  state,
  unitSystem,
  onToggleUnit,
  onSelectFluid,
  isAudioMuted,
  onToggleAudio,
  onOpenOptimizer,
  onStartSimulation,
  isStarted
}: HeroTelemetryProps) {
  const isImperial = unitSystem === 'Imperial';

  // Unit conversion helpers
  const displayRpm = Math.round(state.rpm).toLocaleString();
  const displayFlow = isImperial
    ? `${(state.flowRateLpm * 0.264172).toFixed(1)} GPM`
    : `${state.flowRateLpm.toFixed(1)} L/min`;
  const displayPressure = isImperial
    ? `${(state.dischargePressureMpa * 145.038).toFixed(1)} PSI`
    : `${state.dischargePressureMpa.toFixed(2)} MPa`;
  const displayTemp = isImperial
    ? `${((state.motorTempC * 9) / 5 + 32).toFixed(1)} °F`
    : `${state.motorTempC.toFixed(1)} °C`;
  const displayPower = isImperial
    ? `${(state.electricalPowerKw * 1.34102).toFixed(1)} HP`
    : `${state.electricalPowerKw.toFixed(1)} kW`;
  const displayHead = isImperial
    ? `${(state.headMeters * 3.28084).toFixed(1)} ft`
    : `${state.headMeters.toFixed(1)} m`;

  // State color
  let stateBg = 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';
  if (state.stateTag === 'DORMANT') stateBg = 'bg-gray-500/10 text-gray-400 border-gray-500/30';
  else if (state.stateTag === 'STARTING') stateBg = 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30';
  else if (state.stateTag === 'WARNING') stateBg = 'bg-amber-500/10 text-amber-400 border-amber-500/30';
  else if (state.stateTag === 'FAULT' || state.stateTag === 'CAVITATING') stateBg = 'bg-rose-500/10 text-rose-400 border-rose-500/30';

  return (
    <div id="hero-telemetry-container" className="pointer-events-none absolute inset-0 z-20 flex flex-col justify-between p-4 md:p-6">
      {/* Top Bar */}
      <div className="flex items-start justify-between">
        {/* Product Identity */}
        <div className="pointer-events-auto flex flex-col space-y-1">
          <div className="flex items-center space-x-3">
            <div className="h-2 w-2 rounded-full bg-orange-500 shadow-[0_0_8px_#F27D26] animate-pulse" />
            <h1 className="text-sm md:text-base font-bold tracking-widest text-white font-tech">
              OILPULSE<span className="text-orange-500">.OS</span>
            </h1>
            <span className="text-[10px] text-orange-500 font-mono-num border-l border-white/10 pl-3 uppercase tracking-widest">
              [ Version 3.7 Pro ]
            </span>
          </div>
          <div className="text-[10px] tracking-wide text-zinc-400 uppercase font-tech pl-5">
            PUMP-01 // DIGITAL TWIN ARCHITECTURE
          </div>
        </div>

        {/* Top Right Controls & Fluid Pill */}
        <div className="pointer-events-auto flex items-center space-x-2 md:space-x-3">
          {/* Audio Synthesizer Toggle */}
          <button
            id="audio-toggle-btn"
            onClick={onToggleAudio}
            className="flex items-center space-x-1.5 px-2.5 py-1.5 rounded text-xs font-mono-num glass-panel border border-white/10 hover:border-orange-500/40 text-gray-300 transition-all cursor-pointer"
            title="Toggle Procedural Physics Sound"
          >
            {isAudioMuted ? <VolumeX className="w-3.5 h-3.5 text-gray-400" /> : <Volume2 className="w-3.5 h-3.5 text-orange-500 animate-pulse" />}
            <span className="hidden sm:inline">{isAudioMuted ? 'AUDIO OFF' : 'AUDIO LIVE'}</span>
          </button>

          {/* Unit Switcher */}
          <button
            id="unit-system-btn"
            onClick={onToggleUnit}
            className="px-2.5 py-1.5 rounded text-xs font-mono-num glass-panel border border-white/10 hover:border-white/20 text-gray-300 transition-all cursor-pointer"
          >
            {unitSystem}
          </button>

          {/* Autonomous Optimizer Trigger */}
          <button
            id="optimizer-btn"
            onClick={onOpenOptimizer}
            className="hidden sm:flex items-center space-x-1.5 px-3 py-1.5 rounded text-xs font-tech glass-panel border border-orange-500/40 text-orange-400 hover:bg-orange-500/10 transition-all cursor-pointer shadow-[0_0_12px_rgba(242,125,38,0.2)]"
          >
            <Sparkles className="w-3.5 h-3.5 text-orange-500" />
            <span>OPTIMIZE BEP</span>
          </button>

          {/* State Tag */}
          <div className={`px-2.5 py-1 rounded text-xs font-tech font-semibold tracking-wider border ${stateBg}`}>
            {state.stateTag}
          </div>
        </div>
      </div>

      {/* Central Hero Start Overlay (When Dormant) */}
      {!isStarted && state.stateTag === 'DORMANT' && (
        <div className="pointer-events-auto mx-auto my-auto flex flex-col items-center justify-center p-8 text-center max-w-md glass-panel rounded-lg border border-amber-500/30 shadow-[0_0_40px_rgba(0,0,0,0.8)]">
          <div className="h-3 w-3 rounded-full bg-amber-400 shadow-[0_0_12px_rgba(245,158,11,0.9)] animate-ping mb-4" />
          <h2 className="text-xl font-bold tracking-widest text-white font-tech uppercase mb-1">
            OILPULSE // PUMP-01
          </h2>
          <p className="text-xs text-amber-400 font-mono-num mb-3 tracking-widest uppercase">
            SYSTEM READY — DORMANT ROTOR
          </p>
          <p className="text-xs text-gray-400 mb-6 leading-relaxed">
            Click to engage 55 kW induction motor, initiate automated speed ramp, pressurized fluid flow, and full multi-physics telemetry.
          </p>
          <button
            id="hero-start-simulation-btn"
            onClick={onStartSimulation}
            className="w-full py-3 px-6 rounded text-sm font-tech font-semibold tracking-widest text-black bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 shadow-[0_0_20px_rgba(245,158,11,0.5)] transition-all cursor-pointer transform hover:scale-[1.02]"
          >
            START SIMULATION
          </button>
        </div>
      )}

      {/* Center Cinematic Giant Numerical Readout */}
      {isStarted && (
        <div className="pointer-events-none mx-auto my-auto flex flex-col items-center justify-center text-center select-none">
          <div className="text-[42px] sm:text-[64px] md:text-[84px] font-extrabold tracking-tighter text-white font-mono-num leading-none drop-shadow-[0_4px_16px_rgba(0,0,0,0.8)]">
            {displayRpm}
            <span className="text-base sm:text-xl font-normal text-amber-400 ml-2 tracking-widest font-tech">RPM</span>
          </div>

          <div className="flex items-center space-x-3 mt-1">
            <span className="text-xs sm:text-sm font-semibold tracking-wider text-emerald-400 font-mono-num bg-emerald-500/10 px-2.5 py-0.5 rounded border border-emerald-500/20">
              {state.overallEfficiency.toFixed(1)}% OVERALL EFFICIENCY
            </span>
            <span className="text-xs text-gray-400 font-mono-num">
              HEAD: {displayHead}
            </span>
          </div>
        </div>
      )}

      {/* Bottom Floating Telemetry Strip */}
      <div className="pointer-events-auto grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 md:gap-3">
        {/* Flow Metric */}
        <div className="glass-panel p-2.5 sm:p-3 rounded border border-white/5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-[10px] text-gray-400 font-tech">
            <span>FLOW RATE</span>
            <Droplet className="w-3 h-3 text-amber-400" />
          </div>
          <div className="text-base sm:text-lg font-bold text-white font-mono-num mt-1">
            {displayFlow}
          </div>
          <div className="text-[10px] text-gray-500 font-mono-num">
            Vel: {state.flowVelocityMs} m/s
          </div>
        </div>

        {/* Pressure Metric */}
        <div className="glass-panel p-2.5 sm:p-3 rounded border border-white/5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-[10px] text-gray-400 font-tech">
            <span>DISCHARGE P</span>
            <Gauge className="w-3 h-3 text-cyan-400" />
          </div>
          <div className="text-base sm:text-lg font-bold text-white font-mono-num mt-1">
            {displayPressure}
          </div>
          <div className="text-[10px] text-gray-500 font-mono-num">
            ΔP: {state.differentialPressureMpa} MPa
          </div>
        </div>

        {/* Temperature Metric */}
        <div className="glass-panel p-2.5 sm:p-3 rounded border border-white/5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-[10px] text-gray-400 font-tech">
            <span>MOTOR TEMP</span>
            <Thermometer className="w-3 h-3 text-rose-400" />
          </div>
          <div className="text-base sm:text-lg font-bold text-white font-mono-num mt-1">
            {displayTemp}
          </div>
          <div className="text-[10px] text-gray-500 font-mono-num">
            Brg: {state.bearingDriveTempC.toFixed(1)}°C
          </div>
        </div>

        {/* Power Metric */}
        <div className="glass-panel p-2.5 sm:p-3 rounded border border-white/5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-[10px] text-gray-400 font-tech">
            <span>SHAFT POWER</span>
            <Zap className="w-3 h-3 text-yellow-400" />
          </div>
          <div className="text-base sm:text-lg font-bold text-white font-mono-num mt-1">
            {displayPower}
          </div>
          <div className="text-[10px] text-gray-500 font-mono-num">
            Torque: {state.torqueNm} N·m
          </div>
        </div>

        {/* Vibration Metric */}
        <div className="glass-panel p-2.5 sm:p-3 rounded border border-white/5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-[10px] text-gray-400 font-tech">
            <span>VIBRATION RMS</span>
            <Activity className="w-3 h-3 text-purple-400" />
          </div>
          <div className="text-base sm:text-lg font-bold text-white font-mono-num mt-1">
            {state.vibrationRmsMms} mm/s
          </div>
          <div className="text-[10px] text-gray-500 font-mono-num">
            ISO Zone {state.vibrationIsoZone} (1×: {state.vibrationFft.amp1x} mm/s)
          </div>
        </div>

        {/* Fluid Info & Health */}
        <div className="glass-panel p-2.5 sm:p-3 rounded border border-white/5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-[10px] text-gray-400 font-tech">
            <span>FLUID MEDIUM</span>
            <span className="text-[10px] text-emerald-400 font-mono-num">HP: {state.healthScore}%</span>
          </div>
          <div className="text-xs font-semibold text-amber-300 truncate font-mono-num mt-1" title={state.fluid.name}>
            {state.fluid.name.split('(')[0]}
          </div>
          <div className="text-[10px] text-gray-400 font-mono-num">
            μ: {(state.viscosityActual * 1000).toFixed(1)} cP | ρ: {Math.round(state.densityActual)}
          </div>
        </div>
      </div>
    </div>
  );
}
