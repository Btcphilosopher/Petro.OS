// OILPULSE.OS — Cinematic Timeline & Simulation Clock Controller
'use client';

import React from 'react';
import { Play, Pause, RotateCcw, FastForward, StepForward, Clock } from 'lucide-react';

interface TimelineProps {
  simulationTime: number;
  timeScale: number;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onReset: () => void;
  onStep: () => void;
  onSetTimeScale: (scale: number) => void;
  onScrubTime: (targetTime: number) => void;
}

const TIMELINE_STAGES = [
  { time: 0, label: 'START', desc: 'Dormant system' },
  { time: 3, label: 'POWER', desc: 'Motor excitation' },
  { time: 7, label: 'ACCEL', desc: 'Ramping 0 to 3600 RPM' },
  { time: 11, label: 'PRIMING', desc: 'Fluid chamber entry' },
  { time: 16, label: 'PRESSURIZE', desc: 'Differential head build' },
  { time: 22, label: 'STEADY', desc: 'Thermal & flow equilibrium' },
  { time: 32, label: 'LOAD PEAK', desc: 'High backpressure demand' },
];

export function TimelineController({
  simulationTime,
  timeScale,
  isPlaying,
  onTogglePlay,
  onReset,
  onStep,
  onSetTimeScale,
  onScrubTime
}: TimelineProps) {
  const maxTime = 40.0;
  const progressPercent = Math.min(100, (simulationTime / maxTime) * 100);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = (secs % 60).toFixed(1);
    return `${m.toString().padStart(2, '0')}:${parseFloat(s) < 10 ? '0' : ''}${s}s`;
  };

  return (
    <div id="timeline-controller" className="w-full glass-panel border-t border-white/10 px-4 py-2.5 flex flex-col space-y-2 select-none z-30">
      {/* Top Controls Row */}
      <div className="flex items-center justify-between">
        {/* Playback Controls */}
        <div className="flex items-center space-x-2">
          <button
            id="timeline-play-btn"
            onClick={onTogglePlay}
            className="p-1.5 rounded bg-orange-500/20 hover:bg-orange-500/30 text-orange-400 border border-orange-500/40 transition-all cursor-pointer"
            title={isPlaying ? 'Pause Simulation' : 'Run Simulation'}
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
          </button>

          <button
            id="timeline-step-btn"
            onClick={onStep}
            className="p-1.5 rounded bg-white/5 hover:bg-white/10 text-gray-300 border border-white/10 transition-all cursor-pointer"
            title="Step +0.2s"
          >
            <StepForward className="w-4 h-4" />
          </button>

          <button
            id="timeline-reset-btn"
            onClick={onReset}
            className="p-1.5 rounded bg-white/5 hover:bg-white/10 text-gray-300 border border-white/10 transition-all cursor-pointer"
            title="Reset Simulation Clock"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* Clock Time */}
          <div className="flex items-center space-x-1.5 text-xs text-gray-300 font-mono-num ml-2 border-l border-white/10 pl-3">
            <Clock className="w-3.5 h-3.5 text-orange-500" />
            <span>T+{formatTime(simulationTime)}</span>
          </div>
        </div>

        {/* Speed Multiplier Badges */}
        <div className="flex items-center space-x-1">
          {[0.5, 1, 2, 5, 10].map((scale) => (
            <button
              key={scale}
              onClick={() => onSetTimeScale(scale)}
              className={`px-2 py-0.5 rounded text-[10px] font-mono-num transition-all cursor-pointer ${
                timeScale === scale
                  ? 'bg-orange-500 text-black font-bold'
                  : 'bg-white/5 text-gray-400 hover:text-gray-200 border border-white/5'
              }`}
            >
              {scale}×
            </button>
          ))}
        </div>
      </div>

      {/* Scrubbable Progress Bar & Stages */}
      <div className="relative w-full pt-1 pb-1">
        {/* Stage Markers */}
        <div className="relative w-full h-1 bg-white/10 rounded-full overflow-visible">
          {/* Active progress fill */}
          <div
            className="absolute top-0 left-0 h-full bg-gradient-to-r from-orange-500 to-orange-400 rounded-full shadow-[0_0_8px_rgba(242,125,38,0.6)]"
            style={{ width: `${progressPercent}%` }}
          />

          {/* Playhead thumb */}
          <div
            className="absolute top-1/2 -mt-2 -ml-2 w-4 h-4 rounded-full bg-orange-500 border-2 border-white shadow-[0_0_10px_rgba(242,125,38,0.9)] cursor-grab active:cursor-grabbing"
            style={{ left: `${progressPercent}%` }}
          />
        </div>

        {/* Clickable timeline scrubber track */}
        <input
          type="range"
          min={0}
          max={maxTime}
          step={0.1}
          value={simulationTime}
          onChange={(e) => onScrubTime(parseFloat(e.target.value))}
          className="absolute inset-0 w-full opacity-0 cursor-pointer"
        />

        {/* Stage Label Buttons */}
        <div className="flex justify-between w-full mt-2 text-[9px] font-tech text-gray-400">
          {TIMELINE_STAGES.map((stage) => {
            const isPassed = simulationTime >= stage.time;
            return (
              <button
                key={stage.label}
                onClick={() => onScrubTime(stage.time)}
                className={`transition-all hover:text-amber-300 cursor-pointer ${
                  isPassed ? 'text-amber-400 font-semibold' : 'text-gray-500'
                }`}
              >
                {stage.label}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
