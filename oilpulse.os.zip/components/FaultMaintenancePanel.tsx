// OILPULSE.OS — Fault Injection & Automated Maintenance Disassembly Flow
'use client';

import React, { useState } from 'react';
import { FAULT_SCENARIOS, FaultScenario } from '../lib/simulation/faults';
import { PumpParameters, SimulationState } from '../lib/simulation/physics';
import { AlertTriangle, Wrench, ShieldCheck, CheckCircle2, RotateCcw, Flame, Activity, Zap } from 'lucide-react';

interface FaultMaintenanceProps {
  currentParams: PumpParameters;
  simulationState: SimulationState;
  onInjectFault: (scenario: FaultScenario) => void;
  onClearFaults: () => void;
  onTriggerMaintenanceDisassembly: (stepIdx: number) => void;
}

const MAINTENANCE_STEPS = [
  {
    step: 1,
    title: 'De-energize & Lockout Tagout (LOTO)',
    desc: 'Isolate 400V 3-phase electrical feeder, depressurize volute casing to 0.0 bar, drain residual hydrocarbons to closed recovery drain.'
  },
  {
    step: 2,
    title: 'Disassemble Flexible Coupling',
    desc: 'Loosen hub clamp bolts, extract metallic disc pack assembly, verify radial/axial runout on drive motor stub.'
  },
  {
    step: 3,
    title: 'Extract Bearing & Seal Cartridge',
    desc: 'Unbolt Plan 53B gland plate, slide out silicon carbide stationary/rotary face sub-assembly, pull 7310 duplex angular contact bearings.'
  },
  {
    step: 4,
    title: 'Inspect & Replace Defective Component',
    desc: 'Install new precision ABEC-7 bearing set, lap mechanical seal faces to < 2 helium light bands, dynamically balance rotor to ISO G1.0.'
  },
  {
    step: 5,
    title: 'Precision Laser Shaft Re-alignment',
    desc: 'Execute dual-laser optical alignment between motor and pump shafts to within 0.015 mm angular & parallel tolerances.'
  },
  {
    step: 6,
    title: 'Hydrostatic Verification & Commissioning',
    desc: 'Perform 15-minute nitrogen leak decay test, ramp VFD to 1800 RPM, verify baseline vibration < 1.8 mm/s RMS, return asset to service.'
  }
];

export function FaultMaintenancePanel({
  currentParams,
  simulationState,
  onInjectFault,
  onClearFaults,
  onTriggerMaintenanceDisassembly
}: FaultMaintenanceProps) {
  const [activeTab, setActiveTab] = useState<'FAULTS' | 'MAINTENANCE'>('FAULTS');
  const [activeMaintStep, setActiveMaintStep] = useState(0);

  const isFaulted = simulationState.healthScore < 85 || simulationState.stateTag === 'FAULT' || simulationState.stateTag === 'WARNING' || simulationState.stateTag === 'CAVITATING';

  const handleStepClick = (idx: number) => {
    setActiveMaintStep(idx);
    onTriggerMaintenanceDisassembly(idx);
  };

  return (
    <div id="fault-maintenance-view" className="glass-panel p-4 md:p-6 rounded-lg border border-white/10 flex flex-col space-y-4 max-w-4xl mx-auto my-auto select-none shadow-[0_8px_32px_rgba(0,0,0,0.6)]">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 border-b border-white/10 pb-3">
        <div className="flex items-center space-x-2">
          <AlertTriangle className={`w-4 h-4 ${isFaulted ? 'text-rose-400 animate-pulse' : 'text-amber-400'}`} />
          <div>
            <h2 className="text-sm font-bold tracking-wider text-white font-tech uppercase">
              FAULT INJECTION MATRIX & PREDICTIVE MAINTENANCE
            </h2>
            <p className="text-[11px] text-gray-400 font-mono-num">
              Simulate real-world mechanical degradation, thermal runaway, and automated overhaul sequence.
            </p>
          </div>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center space-x-1 bg-white/5 p-1 rounded border border-white/10">
          <button
            onClick={() => setActiveTab('FAULTS')}
            className={`px-3 py-1 rounded text-xs font-tech transition-all cursor-pointer ${
              activeTab === 'FAULTS' ? 'bg-amber-500 text-black font-bold' : 'text-gray-400 hover:text-white'
            }`}
          >
            FAULT SCENARIOS
          </button>
          <button
            onClick={() => setActiveTab('MAINTENANCE')}
            className={`px-3 py-1 rounded text-xs font-tech transition-all cursor-pointer ${
              activeTab === 'MAINTENANCE' ? 'bg-amber-500 text-black font-bold' : 'text-gray-400 hover:text-white'
            }`}
          >
            DISASSEMBLY & REPAIR
          </button>
        </div>
      </div>

      {activeTab === 'FAULTS' ? (
        /* Fault Matrix View */
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
            {Object.values(FAULT_SCENARIOS).map((scenario) => {
              const isNominal = scenario.id === 'nominal';
              const isCritical = scenario.severity === 'critical';
              return (
                <button
                  key={scenario.id}
                  onClick={() => onInjectFault(scenario)}
                  className={`p-3 rounded text-left border transition-all cursor-pointer flex flex-col justify-between ${
                    isNominal
                      ? 'bg-emerald-500/10 border-emerald-500/30 hover:border-emerald-500 text-emerald-300'
                      : isCritical
                      ? 'bg-rose-500/10 border-rose-500/30 hover:border-rose-500 text-rose-300'
                      : 'bg-amber-500/10 border-amber-500/30 hover:border-amber-500 text-amber-300'
                  }`}
                >
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-[11px] font-bold font-tech uppercase">{scenario.name}</span>
                      <span className={`text-[9px] px-1.5 py-0.5 rounded font-mono-num ${
                        isNominal ? 'bg-emerald-500/20 text-emerald-400' : isCritical ? 'bg-rose-500/20 text-rose-400' : 'bg-amber-500/20 text-amber-400'
                      }`}>
                        {scenario.severity.toUpperCase()}
                      </span>
                    </div>
                    <p className="text-[10px] text-gray-400 leading-relaxed">
                      {scenario.description}
                    </p>
                  </div>
                  <div className="mt-3 text-[9px] font-tech text-amber-400 underline">
                    {isNominal ? 'RESTORE NOMINAL' : 'INJECT FAULT →'}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Current Health & Diagnostic Telemetry Card */}
          <div className="glass-panel p-3.5 rounded border border-white/10 bg-black/40 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div className="space-y-1">
              <div className="text-xs font-tech text-gray-300 flex items-center space-x-2">
                <span>HEALTH SCORE:</span>
                <strong className={`font-mono-num text-sm ${simulationState.healthScore > 80 ? 'text-emerald-400' : simulationState.healthScore > 50 ? 'text-amber-400' : 'text-rose-400'}`}>
                  {simulationState.healthScore}%
                </strong>
                <span className="text-gray-500">|</span>
                <span>VIBRATION ISO ZONE:</span>
                <strong className={`font-mono-num text-sm ${simulationState.vibrationIsoZone === 'A' ? 'text-emerald-400' : simulationState.vibrationIsoZone === 'B' ? 'text-cyan-400' : simulationState.vibrationIsoZone === 'C' ? 'text-amber-400' : 'text-rose-400'}`}>
                  ZONE {simulationState.vibrationIsoZone} ({simulationState.vibrationRmsMms} mm/s)
                </strong>
              </div>
              <div className="text-[11px] text-gray-400 font-mono-num">
                Bearing Temp: {simulationState.bearingDriveTempC.toFixed(1)}°C | Motor Temp: {simulationState.motorTempC.toFixed(1)}°C | Cavitation: {(simulationState.cavitationRisk * 100).toFixed(0)}%
              </div>
            </div>

            <button
              onClick={onClearFaults}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 text-xs font-tech border border-emerald-500/40 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>CLEAR ALL FAULTS</span>
            </button>
          </div>
        </div>
      ) : (
        /* Interactive Maintenance Disassembly Flow */
        <div className="space-y-4">
          <div className="flex justify-between items-center text-xs text-gray-400 font-mono-num">
            <span>PROCEDURE: ISO 10816-3 PRECISION OVERHAUL SEQUENCE</span>
            <span className="text-amber-400">STEP {activeMaintStep + 1} OF 6</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
            {MAINTENANCE_STEPS.map((s, idx) => {
              const isCurrent = activeMaintStep === idx;
              const isPast = idx < activeMaintStep;
              return (
                <button
                  key={s.step}
                  onClick={() => handleStepClick(idx)}
                  className={`p-3 rounded text-left border transition-all cursor-pointer flex flex-col justify-between ${
                    isCurrent
                      ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.25)]'
                      : isPast
                      ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                      : 'bg-white/5 border-white/10 text-gray-400 hover:text-gray-200'
                  }`}
                >
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-xs font-mono-num font-bold">STEP 0{s.step}</span>
                      {isPast && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                    </div>
                    <div className="text-[11px] font-tech font-bold text-white mb-1">
                      {s.title}
                    </div>
                    <p className="text-[10px] text-gray-400 leading-relaxed">
                      {s.desc}
                    </p>
                  </div>
                  <div className="mt-2 text-[9px] font-mono-num text-amber-400 underline">
                    {isCurrent ? 'ACTIVE VIEW' : 'PREVIEW 3D →'}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Action Row */}
          <div className="flex justify-between items-center border-t border-white/10 pt-3">
            <button
              onClick={() => handleStepClick(Math.max(0, activeMaintStep - 1))}
              disabled={activeMaintStep === 0}
              className="px-3 py-1.5 rounded bg-white/5 hover:bg-white/10 text-xs font-tech text-gray-300 border border-white/10 disabled:opacity-30 cursor-pointer"
            >
              ← PREVIOUS STEP
            </button>

            <button
              onClick={() => {
                if (activeMaintStep < 5) {
                  handleStepClick(activeMaintStep + 1);
                } else {
                  onClearFaults();
                  handleStepClick(0);
                }
              }}
              className="px-4 py-1.5 rounded bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black text-xs font-tech font-bold shadow-[0_0_12px_rgba(245,158,11,0.4)] cursor-pointer"
            >
              {activeMaintStep < 5 ? 'NEXT DISASSEMBLY STEP →' : 'COMPLETE REPAIR & RETURN TO SERVICE'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
