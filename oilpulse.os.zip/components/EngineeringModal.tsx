// OILPULSE.OS — Fluid Mechanics Equations & Engineering Diagnostic Ledger
'use client';

import React from 'react';
import { SimulationState } from '../lib/simulation/physics';
import { BookOpen, Download, FileText, CheckCircle2, Calculator } from 'lucide-react';

interface EngineeringModalProps {
  state: SimulationState;
  onClose?: () => void;
}

export function EngineeringModal({ state, onClose }: EngineeringModalProps) {
  // Export telemetry JSON
  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(state, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `OILPULSE_Telemetry_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Export CSV
  const handleExportCSV = () => {
    const headers = ['TimestampMs', 'RPM', 'Flow_Lpm', 'Discharge_MPa', 'Head_m', 'Power_kW', 'Torque_Nm', 'Efficiency_pct', 'Vibration_RMS', 'Health_Score'];
    const row = [
      Date.now(),
      state.rpm.toFixed(1),
      state.flowRateLpm.toFixed(2),
      state.dischargePressureMpa.toFixed(3),
      state.headMeters.toFixed(2),
      state.electricalPowerKw.toFixed(2),
      state.torqueNm.toFixed(2),
      state.overallEfficiency.toFixed(2),
      state.vibrationRmsMms.toFixed(2),
      state.healthScore
    ];
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), row.join(',')].join('\n');
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', encodeURI(csvContent));
    downloadAnchor.setAttribute('download', `OILPULSE_Telemetry_${Date.now()}.csv`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div id="engineering-equations-view" className="glass-panel p-4 md:p-6 rounded-lg border border-white/10 flex flex-col space-y-5 max-w-4xl mx-auto my-auto select-none shadow-[0_8px_32px_rgba(0,0,0,0.6)]">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 border-b border-white/10 pb-3">
        <div className="flex items-center space-x-2">
          <Calculator className="w-4 h-4 text-orange-500" />
          <div>
            <h2 className="text-sm font-bold tracking-wider text-white font-tech uppercase">
              HYDRODYNAMIC EQUATIONS & MULTI-PHYSICS DIAGNOSTICS
            </h2>
            <p className="text-[11px] text-gray-400 font-mono-num">
              Deterministic SI governing principles evaluated at 60 Hz simulation cycle
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleExportJSON}
            className="flex items-center space-x-1.5 px-2.5 py-1 rounded bg-white/5 hover:bg-white/10 text-gray-300 text-xs font-mono-num border border-white/10 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-orange-400" />
            <span>EXPORT JSON</span>
          </button>
          <button
            onClick={handleExportCSV}
            className="flex items-center space-x-1.5 px-2.5 py-1 rounded bg-white/5 hover:bg-white/10 text-gray-300 text-xs font-mono-num border border-white/10 cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5 text-cyan-400" />
            <span>EXPORT CSV</span>
          </button>
        </div>
      </div>

      {/* Equations Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 font-mono-num">
        {/* Reynolds Number */}
        <div className="glass-panel p-3.5 rounded border border-white/5 bg-black/40 space-y-2">
          <div className="flex justify-between items-center text-xs font-tech text-orange-400 font-bold">
            <span>REYNOLDS NUMBER (Re)</span>
            <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/30">
              {state.reynoldsNumber > 4000 ? 'TURBULENT FLOW' : 'LAMINAR FLOW'}
            </span>
          </div>
          <div className="bg-black/60 p-2 rounded text-center text-xs text-orange-400 font-tech">
            Re = (ρ · v · D) / μ
          </div>
          <div className="text-[11px] text-gray-300 space-y-0.5">
            <div>Current Re: <strong className="text-white">{Math.round(state.reynoldsNumber).toLocaleString()}</strong></div>
            <div className="text-gray-500 text-[10px]">
              ρ = {Math.round(state.densityActual)} kg/m³ | v = {state.flowVelocityMs} m/s | μ = {(state.viscosityActual * 1000).toFixed(2)} mPa·s
            </div>
          </div>
        </div>

        {/* Specific Speed */}
        <div className="glass-panel p-3.5 rounded border border-white/5 bg-black/40 space-y-2">
          <div className="flex justify-between items-center text-xs font-tech text-orange-400 font-bold">
            <span>SPECIFIC SPEED (Ns)</span>
            <span className="text-[10px] text-cyan-400 bg-cyan-500/10 px-1.5 py-0.5 rounded border border-cyan-500/30">
              RADIAL VOLUTE
            </span>
          </div>
          <div className="bg-black/60 p-2 rounded text-center text-xs text-cyan-400 font-tech">
            Ns = N · √Q / H^(3/4)
          </div>
          <div className="text-[11px] text-gray-300 space-y-0.5">
            <div>Current Ns: <strong className="text-white">{Math.round(state.headMeters > 0 ? (state.rpm * Math.sqrt(state.flowRateLpm / 60000)) / Math.pow(state.headMeters, 0.75) : 0)} (Metric)</strong></div>
            <div className="text-gray-500 text-[10px]">
              N = {state.rpm} RPM | Q = {(state.flowRateLpm / 60000).toFixed(4)} m³/s | H = {state.headMeters.toFixed(1)} m
            </div>
          </div>
        </div>

        {/* Affinity Laws */}
        <div className="glass-panel p-3.5 rounded border border-white/5 bg-black/40 space-y-2">
          <div className="flex justify-between items-center text-xs font-tech text-orange-400 font-bold">
            <span>AFFINITY LAWS (PUMP SCALING)</span>
          </div>
          <div className="bg-black/60 p-2 rounded text-center text-xs text-orange-400 font-tech">
            Q ∝ N | H ∝ N² | P ∝ N³
          </div>
          <div className="text-[11px] text-gray-300 space-y-0.5">
            <div>Speed Scaling Ratio (N/N_rated): <strong className="text-white">{(state.rpm / 3600).toFixed(3)}</strong></div>
            <div className="text-gray-500 text-[10px]">
              Head Factor: {Math.pow(state.rpm / 3600, 2).toFixed(3)} | Power Factor: {Math.pow(state.rpm / 3600, 3).toFixed(3)}
            </div>
          </div>
        </div>

        {/* Cavitation / NPSH */}
        <div className="glass-panel p-3.5 rounded border border-white/5 bg-black/40 space-y-2">
          <div className="flex justify-between items-center text-xs font-tech text-orange-400 font-bold">
            <span>NPSH MARGIN & CAVITATION</span>
            <span className={`text-[10px] px-1.5 py-0.5 rounded border ${
              (state.npshAvailable - state.npshRequired) > 1.5 ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
            }`}>
              {(state.npshAvailable - state.npshRequired) > 1.5 ? 'SAFE MARGIN' : 'CAVITATION RISK'}
            </span>
          </div>
          <div className="bg-black/60 p-2 rounded text-center text-xs text-rose-400 font-tech">
            NPSH_Margin = NPSHa - NPSHr
          </div>
          <div className="text-[11px] text-gray-300 space-y-0.5">
            <div>Net Margin: <strong className="text-white">{(state.npshAvailable - state.npshRequired).toFixed(2)} m</strong> (NPSHa: {state.npshAvailable.toFixed(2)}m)</div>
            <div className="text-gray-500 text-[10px]">
              Vapor Pressure: 0.08 bar | Fluid Cavitation Risk: {(state.cavitationRisk * 100).toFixed(0)}%
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
