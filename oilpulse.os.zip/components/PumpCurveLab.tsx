// OILPULSE.OS — Interactive Pump Performance Curve Laboratory
'use client';

import React, { useState, useRef } from 'react';
import { SimulationState, PumpParameters } from '../lib/simulation/physics';
import { TrendingUp, Activity, Zap, CheckCircle2, Crosshair } from 'lucide-react';

interface PumpCurveLabProps {
  state: SimulationState;
  params: PumpParameters;
  onUpdateParams: (updated: Partial<PumpParameters>) => void;
}

export function PumpCurveLab({ state, params, onUpdateParams }: PumpCurveLabProps) {
  const [activeCurveTab, setActiveCurveTab] = useState<'HQ' | 'ETA' | 'POWER' | 'ALL'>('ALL');
  const svgRef = useRef<SVGSVGElement | null>(null);
  const [isDraggingPoint, setIsDraggingPoint] = useState(false);

  // SVG Chart Dimensions
  const width = 640;
  const height = 340;
  const padding = { top: 30, right: 40, bottom: 45, left: 60 };
  const graphWidth = width - padding.left - padding.right;
  const graphHeight = height - padding.top - padding.bottom;

  // Maximum scale limits
  const maxFlow = 1600; // L/min
  const maxHead = 140; // meters
  const maxEff = 100; // %
  const maxPower = 75; // kW

  // Coordinate transforms
  const flowToX = (q: number) => padding.left + (q / maxFlow) * graphWidth;
  const headToY = (h: number) => padding.top + (1 - h / maxHead) * graphHeight;
  const effToY = (e: number) => padding.top + (1 - e / maxEff) * graphHeight;
  const powerToY = (p: number) => padding.top + (1 - p / maxPower) * graphHeight;

  // Generate H-Q and Efficiency curves based on current RPM
  const speedRatio = Math.max(0.2, state.rpm / 3600);
  const H0 = 105.0 * Math.pow(speedRatio, 2);
  const Qmax = 1450.0 * speedRatio;
  const bepFlow = Qmax * 0.72;
  const bepHead = H0 - (H0 * 0.45) * Math.pow(bepFlow / Math.max(10, Qmax), 2);
  const bepEff = 88.0;

  // Polyline points
  const numSteps = 40;
  const hqPoints: string[] = [];
  const effPoints: string[] = [];
  const powerPoints: string[] = [];
  const sysPoints: string[] = [];

  const H_static = 25.0;
  const valveResistanceFactor = Math.pow(100 / Math.max(10, params.valveOpenPercent), 1.8);
  const B_sys = 0.000045 * valveResistanceFactor;

  for (let i = 0; i <= numSteps; i++) {
    const q = (i / numSteps) * maxFlow;
    if (q <= Qmax) {
      const h = Math.max(0, H0 - (H0 * 0.45) * Math.pow(q / Math.max(10, Qmax), 2));
      hqPoints.push(`${flowToX(q)},${headToY(h)}`);

      const dev = (q - bepFlow) / Math.max(1, bepFlow);
      const eff = Math.max(0, bepEff * (1 - 1.2 * Math.pow(dev, 2)));
      effPoints.push(`${flowToX(q)},${effToY(eff)}`);

      const pKw = Math.max(5, (q / 60000 * h * 9.81 * 0.88) / Math.max(0.1, eff / 100) + 2.5);
      powerPoints.push(`${flowToX(q)},${powerToY(pKw)}`);
    }

    const hSys = H_static + B_sys * Math.pow(q, 2);
    if (hSys <= maxHead) {
      sysPoints.push(`${flowToX(q)},${headToY(hSys)}`);
    }
  }

  // Operating point
  const opX = flowToX(state.flowRateLpm);
  const opY = headToY(state.headMeters);

  // Handle Dragging Operating Point to drive the 3D twin live!
  const handlePointerDown = () => setIsDraggingPoint(true);
  const handlePointerUp = () => setIsDraggingPoint(false);
  const handlePointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    if (!isDraggingPoint || !svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const clientX = e.clientX - rect.left;
    const clientY = e.clientY - rect.top;

    const normX = Math.max(0, Math.min(1, (clientX - padding.left) / graphWidth));
    const targetQ = normX * maxFlow;

    // Adjust valve opening to intersect at this flow
    const targetValve = Math.min(100, Math.max(10, Math.round((targetQ / (Qmax * 0.9)) * 100)));
    onUpdateParams({ valveOpenPercent: targetValve });
  };

  return (
    <div id="pump-curve-lab-container" className="glass-panel p-4 md:p-6 rounded-lg border border-white/10 flex flex-col space-y-4 max-w-4xl mx-auto my-auto shadow-[0_8px_32px_rgba(0,0,0,0.6)]">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 border-b border-white/10 pb-3">
        <div>
          <div className="flex items-center space-x-2">
            <TrendingUp className="w-4 h-4 text-amber-400" />
            <h2 className="text-sm font-bold tracking-wider text-white font-tech uppercase">
              PUMP PERFORMANCE CURVE LABORATORY (ISO 9906 GRADE 1B)
            </h2>
          </div>
          <p className="text-[11px] text-gray-400 font-mono-num mt-0.5">
            Interactive Characteristic Map — Drag Operating Point (●) to modulate live 3D pump hydraulic state.
          </p>
        </div>

        {/* Curve Type Tabs */}
        <div className="flex items-center space-x-1 bg-white/5 p-1 rounded border border-white/10">
          {(['ALL', 'HQ', 'ETA', 'POWER'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveCurveTab(tab)}
              className={`px-2.5 py-1 rounded text-[10px] font-tech transition-all cursor-pointer ${
                activeCurveTab === tab
                  ? 'bg-amber-500 text-black font-bold'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              {tab === 'ALL' ? 'COMBINED' : tab === 'HQ' ? 'HEAD (H-Q)' : tab === 'ETA' ? 'EFFICIENCY (η-Q)' : 'POWER (P-Q)'}
            </button>
          ))}
        </div>
      </div>

      {/* SVG Chart Area */}
      <div className="relative w-full overflow-hidden bg-black/40 rounded border border-white/5 p-2">
        <svg
          ref={svgRef}
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto select-none"
          onPointerDown={handlePointerDown}
          onPointerUp={handlePointerUp}
          onPointerMove={handlePointerMove}
        >
          {/* Grid lines */}
          {[0, 0.25, 0.5, 0.75, 1].map((ratio) => {
            const y = padding.top + ratio * graphHeight;
            const x = padding.left + ratio * graphWidth;
            return (
              <React.Fragment key={ratio}>
                <line
                  x1={padding.left}
                  y1={y}
                  x2={width - padding.right}
                  y2={y}
                  stroke="rgba(255,255,255,0.07)"
                  strokeDasharray="3 3"
                />
                <line
                  x1={x}
                  y1={padding.top}
                  x2={x}
                  y2={height - padding.bottom}
                  stroke="rgba(255,255,255,0.07)"
                  strokeDasharray="3 3"
                />
              </React.Fragment>
            );
          })}

          {/* Axes */}
          <line
            x1={padding.left}
            y1={height - padding.bottom}
            x2={width - padding.right}
            y2={height - padding.bottom}
            stroke="rgba(255,255,255,0.3)"
          />
          <line
            x1={padding.left}
            y1={padding.top}
            x2={padding.left}
            y2={height - padding.bottom}
            stroke="rgba(255,255,255,0.3)"
          />

          {/* Axis Labels */}
          <text
            x={width / 2}
            y={height - 12}
            textAnchor="middle"
            fill="#9ca3af"
            fontSize="10"
            fontFamily="monospace"
          >
            FLOW RATE Q (L/min)
          </text>
          <text
            x={-height / 2}
            y={20}
            transform="rotate(-90)"
            textAnchor="middle"
            fill="#9ca3af"
            fontSize="10"
            fontFamily="monospace"
          >
            TOTAL HEAD H (m) / EFFICIENCY η (%)
          </text>

          {/* System Resistance Curve (Dash Red) */}
          {(activeCurveTab === 'ALL' || activeCurveTab === 'HQ') && sysPoints.length > 0 && (
            <polyline
              points={sysPoints.join(' ')}
              fill="none"
              stroke="#ef4444"
              strokeWidth="2"
              strokeDasharray="4 4"
              opacity="0.8"
            />
          )}

          {/* Head-Flow H-Q Curve (Solid Gold) */}
          {(activeCurveTab === 'ALL' || activeCurveTab === 'HQ') && (
            <polyline
              points={hqPoints.join(' ')}
              fill="none"
              stroke="#f59e0b"
              strokeWidth="3"
            />
          )}

          {/* Efficiency η-Q Curve (Emerald) */}
          {(activeCurveTab === 'ALL' || activeCurveTab === 'ETA') && (
            <polyline
              points={effPoints.join(' ')}
              fill="none"
              stroke="#10b981"
              strokeWidth="2.5"
            />
          )}

          {/* Power P-Q Curve (Cyan) */}
          {(activeCurveTab === 'ALL' || activeCurveTab === 'POWER') && (
            <polyline
              points={powerPoints.join(' ')}
              fill="none"
              stroke="#06b6d4"
              strokeWidth="2"
            />
          )}

          {/* Best Efficiency Point (BEP) Indicator */}
          <circle
            cx={flowToX(bepFlow)}
            cy={headToY(bepHead)}
            r="5"
            fill="#10b981"
            stroke="#ffffff"
            strokeWidth="1.5"
          />
          <text
            x={flowToX(bepFlow) + 8}
            y={headToY(bepHead) - 8}
            fill="#10b981"
            fontSize="9"
            fontFamily="monospace"
            fontWeight="bold"
          >
            BEP ({Math.round(bepFlow)} L/min, {bepEff}%)
          </text>

          {/* Active Live Operating Point (Draggable Target) */}
          <circle
            cx={opX}
            cy={opY}
            r="8"
            fill="#f59e0b"
            stroke="#ffffff"
            strokeWidth="2.5"
            className="cursor-pointer filter drop-shadow-[0_0_8px_rgba(245,158,11,1)]"
          />
          <circle
            cx={opX}
            cy={opY}
            r="16"
            fill="rgba(245,158,11,0.15)"
            className="animate-ping"
          />

          {/* Operating Point Data Callout */}
          <rect
            x={Math.min(width - 150, Math.max(padding.left + 10, opX - 65))}
            y={Math.max(padding.top + 5, opY - 45)}
            width="130"
            height="36"
            rx="4"
            fill="rgba(10,12,17,0.9)"
            stroke="rgba(245,158,11,0.6)"
          />
          <text
            x={Math.min(width - 150, Math.max(padding.left + 10, opX - 65)) + 65}
            y={Math.max(padding.top + 5, opY - 45) + 14}
            textAnchor="middle"
            fill="#ffffff"
            fontSize="10"
            fontFamily="monospace"
            fontWeight="bold"
          >
            Q: {state.flowRateLpm.toFixed(0)} L/min | H: {state.headMeters.toFixed(1)}m
          </text>
          <text
            x={Math.min(width - 150, Math.max(padding.left + 10, opX - 65)) + 65}
            y={Math.max(padding.top + 5, opY - 45) + 28}
            textAnchor="middle"
            fill="#10b981"
            fontSize="9"
            fontFamily="monospace"
          >
            η: {state.overallEfficiency.toFixed(1)}% | P: {state.shaftPowerKw.toFixed(1)} kW
          </text>
        </svg>
      </div>

      {/* Legend & Verification Strip */}
      <div className="flex flex-wrap items-center justify-between gap-3 text-[11px] font-mono-num border-t border-white/10 pt-3">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-1.5">
            <span className="w-3 h-0.5 bg-amber-500 inline-block" />
            <span className="text-gray-300">Pump H-Q</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="w-3 h-0.5 bg-emerald-500 inline-block" />
            <span className="text-gray-300">Efficiency η</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="w-3 h-0.5 bg-cyan-500 inline-block" />
            <span className="text-gray-300">Power P</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="w-3 h-0.5 bg-rose-500 inline-block border-b border-dashed" />
            <span className="text-gray-300">System Curve</span>
          </div>
        </div>

        <div className="flex items-center space-x-2 text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/20 text-[10px] font-tech">
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>AFFINITY LAW COUPLED (N={state.rpm} RPM)</span>
        </div>
      </div>
    </div>
  );
}
