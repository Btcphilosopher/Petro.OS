package com.example.northsea.models

enum class AlarmClass(val label: String, val severityLevel: Int) {
  EMERGENCY("EMERGENCY", 1),
  CRITICAL("CRITICAL", 2),
  WARNING("WARNING", 3),
  ADVISORY("ADVISORY", 4),
  INFORMATION("INFORMATION", 5)
}

enum class AlarmCategory {
  PROCESS_PRESSURE,
  PROCESS_TEMPERATURE,
  GAS_DETECTION,
  FIRE_SAFETY,
  EQUIPMENT_VIBRATION,
  ELECTRICAL_GRID,
  PIPELINE_INTEGRITY,
  COMMUNICATIONS,
  SUBSEA_HYDRAULIC,
  ENVIRONMENTAL_LIMIT
}

data class AlarmItem(
  val id: String,
  val tag: String,
  val assetName: String,
  val alarmClass: AlarmClass,
  val category: AlarmCategory,
  val message: String,
  val timestamp: Long,
  val currentValue: Double,
  val setpointValue: Double,
  val unit: String,
  val silRating: String = "SIL-2",
  val isAcknowledged: Boolean = false,
  val isShelved: Boolean = false,
  val acknowledgedBy: String? = null
)
