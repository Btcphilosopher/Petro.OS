package com.example.northsea.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.northsea.models.MasterKpiSummary
import com.example.northsea.models.OperationalStatus
import com.example.northsea.models.SimulationScenario
import com.example.northsea.models.UserRole
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HudHeader(
  kpi: MasterKpiSummary,
  currentRole: UserRole,
  activeScenario: SimulationScenario,
  onRoleSwitch: (UserRole) -> Unit,
  onAlertClick: () -> Unit,
  onScenarioClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  var showRoleDialog by remember { mutableStateOf(false) }
  var currentTimeStr by remember { mutableStateOf("00:00:00 UTC") }

  LaunchedEffect(Unit) {
    val formatter = SimpleDateFormat("HH:mm:ss 'UTC'", Locale.UK).apply {
      timeZone = TimeZone.getTimeZone("UTC")
    }
    while (true) {
      currentTimeStr = formatter.format(Date())
      kotlinx.coroutines.delay(1000)
    }
  }

  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(HudBackground)
      .padding(horizontal = 12.dp, vertical = 6.dp)
  ) {
    // Bento Header Row: North Sea Command / Operations HUD + Safety Indicator Pill + Badges
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 8.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Left: Brand Title
      Column {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Text(
            text = "NORTH SEA COMMAND",
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary
          )
          Text(
            text = "•",
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted
          )
          Text(
            text = currentTimeStr,
            style = MaterialTheme.typography.labelSmall,
            color = GasCyan
          )
        }
        Text(
          text = "OPERATIONS HUD",
          style = MaterialTheme.typography.headlineLarge,
          color = TextPrimary
        )
      }

      // Right: Safety Status Pill + Scenario + Role Clearance + Alert Badges
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        // Bento Safety Pill
        val isSafetyNormal = kpi.safetyStatus == OperationalStatus.NORMAL
        Surface(
          shape = RoundedCornerShape(6.dp),
          color = if (isSafetyNormal) Color(0x2010B981) else Color(0x20EF4444),
          border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSafetyNormal) Color(0x6034D399) else Color(0x60EF4444)
          ),
          modifier = Modifier.clickable { onAlertClick() }
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
          ) {
            Box(
              modifier = Modifier
                .size(6.dp)
                .background(if (isSafetyNormal) StatusNormal else StatusCritical, RoundedCornerShape(3.dp))
            )
            Text(
              text = if (isSafetyNormal) "SAFETY: NORMAL" else "SAFETY: ALERT",
              style = MaterialTheme.typography.labelSmall,
              color = if (isSafetyNormal) StatusNormal else StatusCritical
            )
          }
        }

        // Active Role Badge
        Surface(
          shape = RoundedCornerShape(6.dp),
          color = Color(currentRole.badgeColor).copy(alpha = 0.15f),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(currentRole.badgeColor).copy(alpha = 0.5f)),
          modifier = Modifier.clickable { showRoleDialog = true }
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Security,
              contentDescription = "Security Role",
              tint = Color(currentRole.badgeColor),
              modifier = Modifier.size(12.dp)
            )
            Text(
              text = currentRole.roleName.uppercase(),
              style = MaterialTheme.typography.labelSmall,
              color = Color(currentRole.badgeColor)
            )
          }
        }

        // Scenario Tag
        Surface(
          shape = RoundedCornerShape(6.dp),
          color = if (activeScenario.id == "SCEN-BASE") HudSurfaceElevated else StatusWarning.copy(alpha = 0.2f),
          border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (activeScenario.id == "SCEN-BASE") HudSurfaceBorder else StatusWarning.copy(alpha = 0.6f)
          ),
          modifier = Modifier.clickable { onScenarioClick() }
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Science,
              contentDescription = "Scenario",
              tint = if (activeScenario.id == "SCEN-BASE") TextSecondary else StatusWarning,
              modifier = Modifier.size(12.dp)
            )
            Text(
              text = activeScenario.title.take(12).uppercase(),
              style = MaterialTheme.typography.labelSmall,
              color = if (activeScenario.id == "SCEN-BASE") TextSecondary else StatusWarning
            )
          }
        }

        // Alarm Bell Badge
        if (kpi.activeAlertCount > 0) {
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = StatusCritical.copy(alpha = 0.2f),
            border = androidx.compose.foundation.BorderStroke(1.dp, StatusCritical.copy(alpha = 0.6f)),
            modifier = Modifier.clickable { onAlertClick() }
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Notifications,
                contentDescription = "Alarms",
                tint = StatusCritical,
                modifier = Modifier.size(12.dp)
              )
              Text(
                text = "${kpi.activeAlertCount}",
                style = MaterialTheme.typography.labelSmall,
                color = StatusCritical
              )
            }
          }
        }
      }
    }

    // Bento Master Metric Summary Ribbon (Rounded container with subtle slate border & grid divider lines)
    Surface(
      shape = RoundedCornerShape(10.dp),
      color = HudSurface,
      border = androidx.compose.foundation.BorderStroke(1.dp, HudSurfaceBorder),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState())
          .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        KpiItem(
          label = "OIL (BOPD)",
          value = String.format("%,.0f", kpi.totalOilProductionBopd),
          unit = "",
          accent = GasCyan
        )
        KpiDivider()
        KpiItem(
          label = "GAS (MMSCFD)",
          value = String.format("%,.0f", kpi.totalGasProductionMmscfd),
          unit = "",
          accent = GasCyan
        )
        KpiDivider()
        KpiItem(
          label = "UPTIME",
          value = String.format("%.1f%%", kpi.uptimePercentage),
          unit = "",
          accent = StatusNormal
        )
        KpiDivider()
        KpiItem(
          label = "GRID POWER",
          value = "${kpi.gridPowerMw.toInt()} MW",
          unit = "",
          accent = WindCyan
        )
        KpiDivider()
        KpiItem(
          label = "GAS EXPORT",
          value = String.format("%,.0f", kpi.gasExportMmscfd),
          unit = "MMSCFD",
          accent = GasCyan
        )
        KpiDivider()
        KpiItem(
          label = "FLARING",
          value = String.format("%.2f%%", kpi.flaringPercentage),
          unit = "",
          accent = if (kpi.flaringPercentage > 1.5) StatusWarning else TextPrimary
        )
        KpiDivider()
        KpiItem(
          label = "DAILY REVENUE",
          value = "£${String.format("%.1f", kpi.dailyRevenueGbp)}M",
          unit = "",
          accent = PetroleumGold
        )
      }
    }
  }

  // Security Role Selection Dialog
  if (showRoleDialog) {
    AlertDialog(
      onDismissRequest = { showRoleDialog = false },
      title = {
        Text("SELECT OPERATIONAL CLEARANCE", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            "Access levels enforce strict SCADA write permissions and audit logging:",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
          )
          UserRole.values().forEach { role ->
            Surface(
              shape = RoundedCornerShape(4.dp),
              color = if (role == currentRole) HudSurfaceHover else HudSurfaceElevated,
              border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (role == currentRole) Color(role.badgeColor) else HudSurfaceBorder
              ),
              modifier = Modifier
                .fillMaxWidth()
                .clickable {
                  onRoleSwitch(role)
                  showRoleDialog = false
                }
            ) {
              Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Column {
                  Text(role.roleName, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                  Text(role.clearance, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
                if (role == currentRole) {
                  Text("ACTIVE", style = MaterialTheme.typography.labelSmall, color = Color(role.badgeColor))
                }
              }
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showRoleDialog = false }) {
          Text("CLOSE", color = GasCyan)
        }
      },
      containerColor = HudSurface,
      shape = RoundedCornerShape(4.dp)
    )
  }
}

@Composable
private fun KpiItem(
  label: String,
  value: String,
  unit: String,
  accent: Color = TextPrimary
) {
  Column {
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall,
      color = TextSecondary,
      maxLines = 1
    )
    Row(
      verticalAlignment = Alignment.Bottom,
      horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
      Text(
        text = value,
        style = MaterialTheme.typography.titleMedium,
        color = accent
      )
      if (unit.isNotEmpty()) {
        Text(
          text = unit,
          style = MaterialTheme.typography.labelSmall,
          color = TextSecondary,
          modifier = Modifier.padding(bottom = 1.dp)
        )
      }
    }
  }
}

@Composable
private fun KpiDivider() {
  Box(
    modifier = Modifier
      .height(24.dp)
      .width(1.dp)
      .background(HudSurfaceBorder)
  )
}
