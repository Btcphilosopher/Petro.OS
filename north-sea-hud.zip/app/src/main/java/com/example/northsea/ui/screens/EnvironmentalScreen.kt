package com.example.northsea.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.northsea.models.OperationalStatus
import com.example.northsea.ui.components.*
import com.example.northsea.viewmodel.NorthSeaHudViewModel
import com.example.ui.theme.*

@Composable
fun EnvironmentalScreen(
  viewModel: NorthSeaHudViewModel,
  modifier: Modifier = Modifier
) {
  val env = viewModel.environmental.value

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(HudBackground)
      .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Top Emissions KPI Card
    item {
      HudCard(
        title = "NORTH SEA ENVIRONMENTAL TELEMETRY & CARBON INTENSITY",
        tag = "ESG-GHG-TELEMETRY",
        status = OperationalStatus.NORMAL
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          MetricKpiCell("CO2 Intensity", "${String.format("%.1f", env.co2IntensityKgBoe)} kg", "/ boe", status = OperationalStatus.NORMAL, modifier = Modifier.weight(1f))
          MetricKpiCell("Daily CO2 Mass", "${String.format("%,.0f", env.co2EmissionsTodayTonnes)} t", "/day", modifier = Modifier.weight(1f))
          MetricKpiCell("Methane Slip", "${String.format("%.2f", env.methaneSlipRatePercent)}%", "", status = OperationalStatus.NORMAL, modifier = Modifier.weight(1f))
          MetricKpiCell("Renewable Share", "${String.format("%.1f", env.renewablePowerSharePercent)}%", "GRID", modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          CircularEngineeringGauge(
            value = env.co2IntensityKgBoe,
            max = 25.0,
            unit = "kg/boe",
            title = "Carbon Intensity",
            gaugeColor = WindCyan,
            warningThreshold = 18.0,
            size = 100.dp,
            modifier = Modifier.weight(1f)
          )
          CircularEngineeringGauge(
            value = env.oilInWaterContentPpm,
            max = 40.0,
            unit = "ppm OIW",
            title = "Produced Water",
            gaugeColor = StatusNormal,
            warningThreshold = 25.0,
            criticalThreshold = 30.0,
            size = 100.dp,
            modifier = Modifier.weight(1f)
          )
          CircularEngineeringGauge(
            value = env.platformElectrificationPercent,
            unit = "%",
            title = "Electrification",
            gaugeColor = PowerYellow,
            size = 100.dp,
            modifier = Modifier.weight(1f)
          )
          CircularEngineeringGauge(
            value = env.flaringPercentOfProduction,
            max = 3.0,
            unit = "%",
            title = "Routine Flaring",
            gaugeColor = PetroleumGold,
            size = 100.dp,
            modifier = Modifier.weight(1f)
          )
        }
      }
    }

    // Produced Water & Marine Protection
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        HudCard(
          title = "Marine Discharge & Hydrocyclones",
          tag = "MAR-ENV-01",
          status = OperationalStatus.NORMAL,
          modifier = Modifier.weight(1f)
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            LinearEngineeringBar("Produced Water Discharge", env.producedWaterDischargeBpd, 25000.0, "BPD", barColor = WaterBlue)
            LinearEngineeringBar("Oil in Water (Limit: 30 ppm)", env.oilInWaterContentPpm, env.maxPermissibleOiwPpm, "ppm", barColor = StatusNormal)
            LinearEngineeringBar("Subsea Water Reinjection Ratio", env.waterReinjectionPercent, 100.0, "%", barColor = StatusNormal)
          }
        }

        HudCard(
          title = "Flaring, Venting & Fugitives",
          tag = "FLARE-VENT-04",
          status = OperationalStatus.NORMAL,
          modifier = Modifier.weight(1f)
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            LinearEngineeringBar("HP Flare Purge Rate", env.flaringRateMmscfd, 20.0, "MMSCFD", barColor = PetroleumGold)
            LinearEngineeringBar("Atmospheric Vent Rate", env.ventingRateMmscfd, 2.0, "MMSCFD", barColor = GasCyan)
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text("OPTICAL GAS IMAGING: NOMINAL", style = MaterialTheme.typography.labelSmall, color = StatusNormal)
              Text("NO LEAKS DETECTED", style = MaterialTheme.typography.labelSmall, color = StatusNormal)
            }
          }
        }
      }
    }

    // Decarbonisation & Wind Avoidance Card
    item {
      HudCard(
        title = "OFFSHORE WIND DECARBONISATION IMPACT",
        tag = "NET-ZERO-TRANSITION",
        status = OperationalStatus.NORMAL
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text("AVOIDED CO2 (WIND BACK-FEED)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Text("${String.format("%,.0f", env.emissionsAvoidedWindTonneDay)} t / day", style = MaterialTheme.typography.titleMedium, color = WindCyan)
          }
          Column(modifier = Modifier.weight(1f)) {
            Text("TARGET 2030 CARBON INTENSITY", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Text("≤ ${env.targetCo2IntensityKgBoe.toInt()} kg CO2 / boe", style = MaterialTheme.typography.titleMedium, color = StatusNormal)
          }
          Column(modifier = Modifier.weight(1f)) {
            Text("CARBON PRICE AVOIDANCE VALUE", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Text("£277,000 / day", style = MaterialTheme.typography.titleMedium, color = PetroleumGold)
          }
        }
      }
    }
  }
}
