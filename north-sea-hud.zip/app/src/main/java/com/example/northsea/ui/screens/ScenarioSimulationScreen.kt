package com.example.northsea.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.northsea.data.NorthSeaDataProvider
import com.example.northsea.models.OperationalStatus
import com.example.northsea.models.SimulationScenario
import com.example.northsea.ui.components.HudCard
import com.example.northsea.ui.components.MetricKpiCell
import com.example.northsea.viewmodel.NorthSeaHudViewModel
import com.example.ui.theme.*

@Composable
fun ScenarioSimulationScreen(
  viewModel: NorthSeaHudViewModel,
  modifier: Modifier = Modifier
) {
  val activeScenario = viewModel.activeScenario.value
  val scenarios = NorthSeaDataProvider.scenarios

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(HudBackground)
      .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Top Active Scenario Status Banner
    item {
      HudCard(
        title = "OPERATIONAL SCENARIO & CONTINGENCY SIMULATION ENGINE",
        tag = "WHAT-IF-STUDIO",
        status = if (activeScenario.id == "SCEN-BASE") OperationalStatus.NORMAL else OperationalStatus.WARNING
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          MetricKpiCell("Loaded Scenario", activeScenario.title, "", status = if (activeScenario.id == "SCEN-BASE") OperationalStatus.NORMAL else OperationalStatus.WARNING, modifier = Modifier.weight(1.5f))
          MetricKpiCell("Oil Impact", "${if (activeScenario.oilProductionDeltaBopd >= 0) "+" else ""}${String.format("%,.0f", activeScenario.oilProductionDeltaBopd)} BOPD", "", modifier = Modifier.weight(1f))
          MetricKpiCell("Gas Impact", "${if (activeScenario.gasProductionDeltaMmscfd >= 0) "+" else ""}${String.format("%,.0f", activeScenario.gasProductionDeltaMmscfd)} MMSCFD", "", modifier = Modifier.weight(1f))
          MetricKpiCell("Power Delta", "${if (activeScenario.powerDeltaMw >= 0) "+" else ""}${activeScenario.powerDeltaMw.toInt()} MW", "", modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
          text = "Description: ${activeScenario.description}",
          style = MaterialTheme.typography.bodySmall,
          color = TextSecondary
        )
      }
    }

    // Scenarios Selector List
    item {
      Text(
        text = "AVAILABLE OPERATIONAL SCENARIOS (REAL-TIME MODELING)",
        style = MaterialTheme.typography.titleMedium,
        color = TextPrimary
      )
    }

    items(scenarios) { sc ->
      val isActive = sc.id == activeScenario.id
      val cardColor = if (isActive) HudSurfaceHover else HudSurface
      val borderColor = if (isActive) GasCyan else HudSurfaceBorder

      Surface(
        shape = RoundedCornerShape(4.dp),
        color = cardColor,
        border = androidx.compose.foundation.BorderStroke(1.dp, borderColor),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Box(
                modifier = Modifier
                  .size(8.dp)
                  .background(if (isActive) GasCyan else TextMuted, RoundedCornerShape(2.dp))
              )
              Text(sc.title.uppercase(), style = MaterialTheme.typography.titleSmall, color = TextPrimary)
              Text("[${sc.id}]", style = MaterialTheme.typography.labelSmall, color = GasCyan)
            }

            if (isActive) {
              Surface(
                shape = RoundedCornerShape(2.dp),
                color = GasCyan.copy(alpha = 0.2f),
                border = androidx.compose.foundation.BorderStroke(1.dp, GasCyan)
              ) {
                Text(
                  text = "ACTIVE SCENARIO",
                  style = MaterialTheme.typography.labelSmall,
                  color = GasCyan,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = sc.description,
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
          )

          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
              Text(
                text = "OIL: ${if (sc.oilProductionDeltaBopd >= 0) "+" else ""}${String.format("%,.0f", sc.oilProductionDeltaBopd)} BOPD",
                style = MaterialTheme.typography.labelSmall,
                color = if (sc.oilProductionDeltaBopd < 0) StatusCritical else StatusNormal
              )
              Text(
                text = "GAS: ${if (sc.gasProductionDeltaMmscfd >= 0) "+" else ""}${String.format("%,.0f", sc.gasProductionDeltaMmscfd)} MMSCFD",
                style = MaterialTheme.typography.labelSmall,
                color = if (sc.gasProductionDeltaMmscfd < 0) StatusWarning else GasCyan
              )
              Text(
                text = "POWER: ${if (sc.powerDeltaMw >= 0) "+" else ""}${sc.powerDeltaMw.toInt()} MW",
                style = MaterialTheme.typography.labelSmall,
                color = PowerYellow
              )
            }

            if (!isActive) {
              Button(
                onClick = { viewModel.activateScenario(sc) },
                colors = ButtonDefaults.buttonColors(containerColor = HudSurfaceElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, GasCyan),
                shape = RoundedCornerShape(2.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
              ) {
                Text("RUN SIMULATION", style = MaterialTheme.typography.labelSmall, color = GasCyan)
              }
            }
          }
        }
      }
    }
  }
}
