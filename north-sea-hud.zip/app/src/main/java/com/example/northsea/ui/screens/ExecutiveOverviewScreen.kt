package com.example.northsea.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.northsea.models.OperationalStatus
import com.example.northsea.ui.components.*
import com.example.northsea.viewmodel.NorthSeaHudViewModel
import com.example.ui.theme.*

@Composable
fun ExecutiveOverviewScreen(
  viewModel: NorthSeaHudViewModel,
  modifier: Modifier = Modifier
) {
  val kpi = viewModel.masterKpi.value
  val econ = viewModel.economicSummary.value
  val env = viewModel.environmental.value

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(HudBackground)
      .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Executive Top Performance Ribbon
    item {
      HudCard(
        title = "EXECUTIVE OPERATIONS & C-SUITE PERFORMANCE SUMMARY",
        tag = "EXEC-BOARD-01",
        status = OperationalStatus.NORMAL
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          MetricKpiCell("Daily Net Margin", "£${String.format("%.1f", econ.estimatedNetOperatingMarginGbp)}M", "/day", status = OperationalStatus.NORMAL, modifier = Modifier.weight(1f))
          MetricKpiCell("Fleet Uptime", "${String.format("%.1f", kpi.uptimePercentage)}%", "AVAILABILITY", modifier = Modifier.weight(1f))
          MetricKpiCell("Safety Milestone", "428 DAYS", "LTI FREE", status = OperationalStatus.NORMAL, modifier = Modifier.weight(1f))
          MetricKpiCell("Carbon Intensity", "${String.format("%.1f", env.co2IntensityKgBoe)} kg", "/ boe", modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(10.dp))
        LinearEngineeringBar("Annual Target Delivery", 98.2, 100.0, "%", barColor = StatusNormal)
      }
    }

    // Capital & Strategic Energy Delivery
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        HudCard(
          title = "Integrated Energy Output",
          tag = "ENERGY-TERAWATTS",
          status = OperationalStatus.NORMAL,
          modifier = Modifier.weight(1f)
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            TelemetryRowItem("Hydrocarbons Energy Eqv", "3,820 GWh / day", PetroleumGold)
            TelemetryRowItem("Offshore Wind Export", "134 GWh / day", WindCyan)
            TelemetryRowItem("UK Energy Demand Share", "18.4% of Total UK", TextPrimary)
            LinearEngineeringBar("Export Reliability", 99.8, 100.0, "%", barColor = StatusNormal)
          }
        }

        HudCard(
          title = "Cost Structure & Capital Allocation",
          tag = "FIN-OPEX-CAPEX",
          status = OperationalStatus.NORMAL,
          modifier = Modifier.weight(1f)
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            TelemetryRowItem("Unit Operating Cost", "$16.80 / boe", TextPrimary)
            TelemetryRowItem("Operating Margin", "78.2%", StatusNormal)
            TelemetryRowItem("Decarbonisation CAPEX", "£420M Allocated", WindCyan)
            LinearEngineeringBar("Budget Spend Pacing", 94.0, 100.0, "%", barColor = GasCyan)
          }
        }
      }
    }

    // Regulatory & ESG Governance
    item {
      HudCard(
        title = "UK NSTA & HSE REGULATORY COMPLIANCE STATUS",
        tag = "NSTA-HSE-AUDIT",
        status = OperationalStatus.NORMAL
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text("NSTA STEWARDSHIP RATING", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Text("TIER 1 (EXEMPLARY)", style = MaterialTheme.typography.titleMedium, color = StatusNormal)
          }
          Column(modifier = Modifier.weight(1f)) {
            Text("HSE SAFETY CASE AUDIT", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Text("VALID THROUGH 2029", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
          }
          Column(modifier = Modifier.weight(1f)) {
            Text("ETS CARBON ALLOWANCES", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Text("100% COVERAGE SURPLUS", style = MaterialTheme.typography.titleMedium, color = WindCyan)
          }
        }
      }
    }
  }
}

@Composable
private fun TelemetryRowItem(label: String, value: String, accent: Color) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    Text(value, style = MaterialTheme.typography.labelMedium, color = accent)
  }
}
