package com.example.northsea.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.northsea.models.OperationalStatus
import com.example.northsea.models.PlatformAsset
import com.example.northsea.ui.components.*
import com.example.northsea.viewmodel.NorthSeaHudViewModel
import com.example.ui.theme.*

@Composable
fun OffshorePlatformHudScreen(
  viewModel: NorthSeaHudViewModel,
  modifier: Modifier = Modifier
) {
  val platform = viewModel.selectedPlatform.value
  val allPlatforms = viewModel.platforms.value

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(HudBackground)
      .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Platform Selector Tabs
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        allPlatforms.forEach { p ->
          val isSelected = p.id == platform.id
          Surface(
            shape = RoundedCornerShape(2.dp),
            color = if (isSelected) GasCyan.copy(alpha = 0.2f) else HudSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) GasCyan else HudSurfaceBorder),
            modifier = Modifier.clickable { viewModel.selectPlatformById(p.id) }
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Box(
                modifier = Modifier
                  .size(6.dp)
                  .background(if (p.status == OperationalStatus.NORMAL) StatusNormal else StatusWarning, RoundedCornerShape(2.dp))
              )
              Text(
                text = p.name.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = if (isSelected) TextPrimary else TextSecondary
              )
            }
          }
        }
      }
    }

    // Platform Primary HUD Header Card
    item {
      HudCard(
        title = "PLATFORM: ${platform.name.uppercase()}",
        tag = "${platform.quadrantBlock} • ${platform.fieldName}",
        status = platform.status,
        trailingContent = {
          Surface(
            shape = RoundedCornerShape(2.dp),
            color = StatusNormal.copy(alpha = 0.15f),
            border = androidx.compose.foundation.BorderStroke(1.dp, StatusNormal)
          ) {
            Text(
              text = "STATUS: ${if (platform.status == OperationalStatus.NORMAL) "OPERATIONAL" else "WARNING"}",
              style = MaterialTheme.typography.labelSmall,
              color = StatusNormal,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
        }
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          MetricKpiCell("Water Depth", "${platform.waterDepthM.toInt()}m", "", modifier = Modifier.weight(1f))
          MetricKpiCell("POB Capacity", "${platform.personnelOnBoard} / ${platform.maxCapacityPob}", "POB", modifier = Modifier.weight(1f))
          MetricKpiCell("Active Wells", "${platform.activeWellsCount} / ${platform.totalWellsCount}", "WELLS", modifier = Modifier.weight(1f))
          MetricKpiCell("ESD System", platform.esdStatus, "", modifier = Modifier.weight(1f))
        }
      }
    }

    // 4 Quad Panels: Production, Process, Power, Export
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        // PRODUCTION
        HudCard(
          title = "PRODUCTION",
          tag = "WELL-PROD",
          status = OperationalStatus.NORMAL,
          modifier = Modifier.weight(1f)
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            TelemetryRowItem("OIL", "${String.format("%,.0f", platform.oilBopd)} BOPD", PetroleumGold)
            TelemetryRowItem("GAS", "${String.format("%,.0f", platform.gasMmscfd)} MMSCFD", GasCyan)
            TelemetryRowItem("WATER", "${String.format("%,.0f", platform.waterBpd)} BPD", WaterBlue)
            Spacer(modifier = Modifier.height(4.dp))
            LinearEngineeringBar("Water Cut", (platform.waterBpd / (platform.oilBopd + platform.waterBpd) * 100), 100.0, "%", barColor = WaterBlue)
          }
        }

        // PROCESS
        HudCard(
          title = "PROCESS UTILISATION",
          tag = "PROC-SEP",
          status = OperationalStatus.NORMAL,
          modifier = Modifier.weight(1f)
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            LinearEngineeringBar("SEPARATOR", platform.separatorUtilPercent, 100.0, "%", barColor = StatusNormal)
            LinearEngineeringBar("COMPRESSION", platform.compressionUtilPercent, 100.0, "%", barColor = GasCyan)
            LinearEngineeringBar("WATER INJECTION", platform.waterInjectionUtilPercent, 100.0, "%", barColor = WaterBlue)
          }
        }
      }
    }

    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        // POWER
        HudCard(
          title = "POWER GENERATION",
          tag = "PWR-GEN",
          status = OperationalStatus.NORMAL,
          modifier = Modifier.weight(1f)
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            TelemetryRowItem("LOAD", "${platform.powerLoadMw.toInt()} MW", TextPrimary)
            TelemetryRowItem("GENERATION", "${platform.powerGenMw.toInt()} MW", PowerYellow)
            TelemetryRowItem("EFFICIENCY", "${platform.powerEfficiencyPercent.toInt()}%", StatusNormal)
            Spacer(modifier = Modifier.height(4.dp))
            LinearEngineeringBar("Reserve Margin", (platform.powerGenMw - platform.powerLoadMw), platform.powerGenMw, "MW", barColor = StatusNormal)
          }
        }

        // EXPORT
        HudCard(
          title = "EXPORT PIPELINES",
          tag = "EXP-SUBSEA",
          status = OperationalStatus.NORMAL,
          modifier = Modifier.weight(1f)
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            LinearEngineeringBar("OIL PIPELINE", platform.oilPipelineExportPercent, 100.0, "%", barColor = PetroleumGold)
            LinearEngineeringBar("GAS PIPELINE", platform.gasPipelineExportPercent, 100.0, "%", barColor = GasCyan)
            Spacer(modifier = Modifier.height(4.dp))
            TelemetryRowItem("EXPORT VALVES", "100% OPEN / NOMINAL", StatusNormal)
          }
        }
      }
    }

    // Safety and Weather strip for Platform
    item {
      HudCard(
        title = "OFFSHORE PLATFORM SAFETY & METOCEAN STATUS",
        tag = "ENV-F&G",
        status = OperationalStatus.NORMAL
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          MetricKpiCell("Helideck Status", platform.helideckStatus, "", modifier = Modifier.weight(1f))
          MetricKpiCell("Wind Speed", "${platform.windSpeedKts} kts", "NNW", modifier = Modifier.weight(1f))
          MetricKpiCell("Significant Waves", "${platform.waveHeightM}m", "Hs", modifier = Modifier.weight(1f))
          MetricKpiCell("Fire & Gas System", platform.fireAndGasStatus, "", modifier = Modifier.weight(1f))
        }
      }
    }
  }
}

@Composable
private fun TelemetryRowItem(label: String, value: String, accent: Color) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    Text(value, style = MaterialTheme.typography.labelMedium, color = accent)
  }
}
