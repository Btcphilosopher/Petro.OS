package com.example.northsea.models

data class MarineTrafficVessel(
  val mmsi: String,
  val name: String,
  val type: String, // "Emergency Response & Rescue (ERRV)", "Platform Supply (PSV)", "Crude Tanker", "Crew Transfer (CTV)"
  val speedKts: Double,
  val headingDeg: Int,
  val distanceNm: Double,
  val nearestPlatform: String,
  val status: String
)

data class MetoceanCondition(
  val location: String,
  val windSpeedKts: Double,
  val windDirection: String,
  val gustKts: Double,
  val significantWaveHeightM: Double,
  val maxWaveHeightM: Double,
  val wavePeriodSec: Double,
  val visibilityNm: Double,
  val airTempC: Double,
  val seaTempC: Double,
  val barometricPressureMbar: Double
)

data class SafetyOverlayData(
  val overallSafetyStatus: OperationalStatus,
  val sisEsdArmed: Boolean,
  val fireAndGasZoneStatus: String,
  val lifeboatReadinessPercent: Int,
  val totalLifeboats: Int,
  val availableLifeboats: Int,
  val helideckStatus: String, // "GREEN (OPEN)", "AMBER (RESTRICTED)", "RED (CLOSED)"
  val nextHelicopterEtaMin: Int,
  val helicopterMission: String,
  val standbyVesselOnStation: Boolean,
  val metocean: MetoceanCondition,
  val marineVessels: List<MarineTrafficVessel>
)
