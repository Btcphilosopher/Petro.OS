package com.example.northsea.models

data class MarketCommodity(
  val symbol: String,
  val name: String,
  val price: Double,
  val change24h: Double,
  val changePercent24h: Double,
  val unit: String,
  val currencySymbol: String,
  val sparklineHistory: List<Double>
)

data class EconomicSummary(
  val brentCrudeUsd: Double,
  val ukNaturalGasPenceTherm: Double,
  val ukPowerGbpMwh: Double,
  val ukEtsCarbonGbpTonne: Double,
  val dailyOilRevenueGbp: Double,
  val dailyGasRevenueGbp: Double,
  val dailyPowerRevenueGbp: Double,
  val totalDailyRevenueGbp: Double,
  val dailyOpexGbp: Double,
  val dailyTransportationCostGbp: Double,
  val estimatedNetOperatingMarginGbp: Double,
  val marginPercent: Double
)

data class ProductionForecastPoint(
  val label: String,
  val periodDays: Int,
  val oilBopdP50: Double,
  val oilBopdP10: Double,
  val oilBopdP90: Double,
  val gasMmscfdP50: Double,
  val revenueEstimateGbpM: Double
)
