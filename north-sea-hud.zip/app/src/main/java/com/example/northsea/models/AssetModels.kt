package com.example.northsea.models

enum class AssetCategory {
  OFFSHORE_PLATFORM,
  SUBSEA_FIELD,
  PIPELINE,
  GAS_TERMINAL,
  OIL_TERMINAL,
  OFFSHORE_WIND_FARM,
  INTERCONNECTOR
}

data class GeoCoordinate(
  val latitude: Double,
  val longitude: Double
)

data class PlatformAsset(
  val id: String,
  val name: String,
  val fieldName: String,
  val quadrantBlock: String,
  val coordinates: GeoCoordinate,
  val waterDepthM: Double,
  val status: OperationalStatus,
  val oilBopd: Double,
  val gasMmscfd: Double,
  val waterBpd: Double,
  val separatorUtilPercent: Double,
  val compressionUtilPercent: Double,
  val waterInjectionUtilPercent: Double,
  val powerLoadMw: Double,
  val powerGenMw: Double,
  val powerEfficiencyPercent: Double,
  val oilPipelineExportPercent: Double,
  val gasPipelineExportPercent: Double,
  val personnelOnBoard: Int,
  val maxCapacityPob: Int,
  val activeWellsCount: Int,
  val totalWellsCount: Int,
  val esdStatus: String = "ARMED / NORMAL",
  val fireAndGasStatus: String = "ALL ZONES SECURE",
  val helideckStatus: String = "OPEN (GREEN)",
  val windSpeedKts: Double = 24.5,
  val waveHeightM: Double = 3.2
)

data class SubseaFieldAsset(
  val id: String,
  val name: String,
  val tiedToPlatformId: String,
  val coordinates: GeoCoordinate,
  val manifoldsCount: Int,
  val subseaXmasTreesCount: Int,
  val reservoirPressurePsi: Double,
  val reservoirTempC: Double,
  val status: OperationalStatus
)

data class PipelineAsset(
  val id: String,
  val name: String,
  val origin: String,
  val destination: String,
  val diameterInches: Int,
  val lengthKm: Double,
  val currentFlowMmscfdOrBpd: Double,
  val capacityMmscfdOrBpd: Double,
  val currentPressureBar: Double,
  val maxOperatingPressureBar: Double,
  val temperatureC: Double,
  val integrityStatus: String,
  val pigInspectionDaysAgo: Int,
  val status: OperationalStatus,
  val routePoints: List<GeoCoordinate> = emptyList()
)

data class TerminalAsset(
  val id: String,
  val name: String,
  val location: String,
  val coordinates: GeoCoordinate,
  val incomingGasMmscfd: Double,
  val processedGasMmscfd: Double,
  val storageUtilPercent: Double,
  val exportRateMmscfd: Double,
  val pressureBar: Double,
  val compressorTrainsActive: Int,
  val totalCompressorTrains: Int,
  val plantAvailabilityPercent: Double,
  val status: OperationalStatus
)

data class WindFarmAsset(
  val id: String,
  val name: String,
  val coordinates: GeoCoordinate,
  val totalTurbines: Int,
  val availableTurbines: Int,
  val currentOutputMw: Double,
  val nameplateCapacityMw: Double,
  val windSpeedKts: Double,
  val capacityFactorPercent: Double,
  val gridExportMw: Double,
  val platformSupplyMw: Double,
  val curtailmentMw: Double,
  val batteryStorageMw: Double,
  val status: OperationalStatus
)

data class WellAsset(
  val id: String,
  val name: String,
  val platformId: String,
  val fieldName: String,
  val wellType: String, // Production, Water Injection, Gas Lift
  val status: WellStatus,
  val oilFlowBopd: Double,
  val gasFlowMmscfd: Double,
  val waterCutPercent: Double,
  val flowingTubingPressurePsi: Double,
  val bottomHolePressurePsi: Double,
  val temperatureC: Double,
  val gasOilRatioScfBbl: Double,
  val chokePercent: Double,
  val artificialLiftType: String, // Gas Lift, ESP, Natural Flow
  val artificialLiftActive: Boolean,
  val healthScorePercent: Double,
  val optimizationStatus: String
)

enum class WellStatus {
  PRODUCING,
  SHUT_IN,
  MAINTENANCE,
  DEPLETED,
  OPTIMISATION_REQUIRED
}

data class CompressorTrain(
  val id: String,
  val name: String,
  val platformOrFacility: String,
  val stage: String,
  val suctionPressureBar: Double,
  val dischargePressureBar: Double,
  val gasFlowMmscfd: Double,
  val rpm: Double,
  val turbineLoadMw: Double,
  val inletTempC: Double,
  val dischargeTempC: Double,
  val polytropicEfficiencyPercent: Double,
  val vibrationMmS: Double,
  val surgeMarginPercent: Double,
  val antiSurgeValvePercent: Double,
  val compressorHealthPercent: Double,
  val status: OperationalStatus
)
