package com.example.northsea.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.northsea.models.MarketCommodity
import com.example.northsea.models.OperationalStatus
import com.example.northsea.ui.components.*
import com.example.northsea.viewmodel.NorthSeaHudViewModel
import com.example.ui.theme.*

@Composable
fun EconomicTradingScreen(
  viewModel: NorthSeaHudViewModel,
  modifier: Modifier = Modifier
) {
  val commodities = viewModel.marketCommodities.value
  val econ = viewModel.economicSummary.value

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(HudBackground)
      .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Executive Economic Margin Card
    item {
      HudCard(
        title = "NORTH SEA COMMERCIAL INTELLIGENCE & REVENUE MARGINS",
        tag = "ECON-TRADING-01",
        status = OperationalStatus.NORMAL
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          MetricKpiCell("Gross Daily Revenue", "£${String.format("%.1f", econ.totalDailyRevenueGbp)}M", "/day", modifier = Modifier.weight(1f))
          MetricKpiCell("Daily OPEX", "£${String.format("%.1f", econ.dailyOpexGbp)}M", "/day", modifier = Modifier.weight(1f))
          MetricKpiCell("Transport / Tariff", "£${String.format("%.1f", econ.dailyTransportationCostGbp)}M", "/day", modifier = Modifier.weight(1f))
          MetricKpiCell("Net Operating Margin", "£${String.format("%.1f", econ.estimatedNetOperatingMarginGbp)}M", "(${econ.marginPercent.toInt()}%)", status = OperationalStatus.NORMAL, modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(10.dp))
        LinearEngineeringBar("Operating Margin Ratio", econ.estimatedNetOperatingMarginGbp, econ.totalDailyRevenueGbp, "£M", barColor = PetroleumGold)
      }
    }

    // Live Commodity Tickers Grid
    item {
      Text(
        text = "LIVE ENERGY MARKET COMMODITY TICKERS (24H SCADA FEED)",
        style = MaterialTheme.typography.titleMedium,
        color = TextPrimary
      )
    }

    items(commodities) { comm ->
      CommodityTickerCard(commodity = comm)
    }

    // Cost Breakdown & Netback Structure
    item {
      HudCard(
        title = "Production Value & Netback Analysis",
        tag = "NETBACK-VAL-03",
        status = OperationalStatus.NORMAL
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text("CRUDE OIL LIFTING COST", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Text("$14.20 / bbl", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
          }
          Column(modifier = Modifier.weight(1f)) {
            Text("GAS PROCESSING TARIFF", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Text("12.4 p / therm", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
          }
          Column(modifier = Modifier.weight(1f)) {
            Text("CARBON ETS EXPOSURE", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Text("£0.85 / boe", style = MaterialTheme.typography.titleMedium, color = StatusWarning)
          }
        }
      }
    }
  }
}

@Composable
private fun CommodityTickerCard(commodity: MarketCommodity) {
  val isPositive = commodity.change24h >= 0

  Surface(
    shape = RoundedCornerShape(4.dp),
    color = HudSurface,
    border = androidx.compose.foundation.BorderStroke(1.dp, HudSurfaceBorder),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier.padding(12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Column(modifier = Modifier.weight(1.5f)) {
        Text(commodity.name.uppercase(), style = MaterialTheme.typography.titleSmall, color = TextPrimary)
        Text("${commodity.symbol} • Spot Contract", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
      }

      SparklineMiniGraph(
        dataPoints = commodity.sparklineHistory,
        modifier = Modifier
          .weight(1.5f)
          .height(28.dp)
          .padding(horizontal = 8.dp),
        lineColor = if (isPositive) StatusNormal else StatusCritical
      )

      Column(
        modifier = Modifier.weight(1.2f),
        horizontalAlignment = Alignment.End
      ) {
        Text(
          text = "${commodity.currencySymbol}${String.format("%.2f", commodity.price)} ${commodity.unit}",
          style = MaterialTheme.typography.titleMedium,
          color = TextPrimary
        )
        Text(
          text = "${if (isPositive) "+" else ""}${String.format("%.2f", commodity.change24h)} (${if (isPositive) "+" else ""}${String.format("%.2f", commodity.changePercent24h)}%)",
          style = MaterialTheme.typography.labelSmall,
          color = if (isPositive) StatusNormal else StatusCritical
        )
      }
    }
  }
}
