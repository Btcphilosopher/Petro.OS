package com.example.northsea.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.northsea.models.OperationalStatus
import com.example.northsea.models.ProductionForecastPoint
import com.example.northsea.ui.components.HudCard
import com.example.northsea.ui.components.MetricKpiCell
import com.example.northsea.viewmodel.NorthSeaHudViewModel
import com.example.ui.theme.*

@Composable
fun ProductionForecastScreen(
  viewModel: NorthSeaHudViewModel,
  modifier: Modifier = Modifier
) {
  val periods = listOf(
    ProductionForecastPoint("TODAY", 0, 443700.0, 435000.0, 452000.0, 1650.0, 48.6),
    ProductionForecastPoint("+7 DAYS", 7, 441000.0, 428000.0, 455000.0, 1640.0, 48.2),
    ProductionForecastPoint("+30 DAYS", 30, 438500.0, 415000.0, 458000.0, 1620.0, 47.9),
    ProductionForecastPoint("+90 DAYS", 90, 431000.0, 395000.0, 460000.0, 1590.0, 46.8),
    ProductionForecastPoint("+1 YEAR", 365, 415000.0, 360000.0, 465000.0, 1520.0, 45.1),
    ProductionForecastPoint("+5 YEARS", 1825, 340000.0, 280000.0, 420000.0, 1250.0, 37.5)
  )

  var selectedPeriod by remember { mutableStateOf(periods.first()) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(HudBackground)
      .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Top Horizon Selector
    item {
      HudCard(
        title = "RESERVOIR DECLINE & PRODUCTION FORECAST (CONFIDENCE BANDS P10/P50/P90)",
        tag = "DCA-SIM-AI",
        status = OperationalStatus.NORMAL
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          MetricKpiCell("Selected Horizon", selectedPeriod.label, "", modifier = Modifier.weight(1f))
          MetricKpiCell("P50 Expected Oil", "${String.format("%,.0f", selectedPeriod.oilBopdP50)} BOPD", "", modifier = Modifier.weight(1f))
          MetricKpiCell("P50 Expected Gas", "${String.format("%,.0f", selectedPeriod.gasMmscfdP50)} MMSCFD", "", modifier = Modifier.weight(1f))
          MetricKpiCell("Est. Daily Gross", "£${String.format("%.1f", selectedPeriod.revenueEstimateGbpM)}M", "", modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          periods.forEach { pt ->
            val isSelected = pt.label == selectedPeriod.label
            Surface(
              shape = RoundedCornerShape(2.dp),
              color = if (isSelected) GasCyan.copy(alpha = 0.2f) else HudSurfaceElevated,
              border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) GasCyan else HudSurfaceBorder),
              modifier = Modifier
                .weight(1f)
                .clickable { selectedPeriod = pt }
            ) {
              Column(
                modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
              ) {
                Text(pt.label, style = MaterialTheme.typography.labelSmall, color = if (isSelected) GasCyan else TextPrimary)
                Text("${(pt.oilBopdP50 / 1000).toInt()}k", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
              }
            }
          }
        }
      }
    }

    // Confidence Bands Breakdown
    item {
      HudCard(
        title = "P10 / P50 / P90 UNCERTAINTY BAND ANALYSIS: ${selectedPeriod.label}",
        tag = "MONTE-CARLO-PROB",
        status = OperationalStatus.NORMAL
      ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          ConfidenceBarRow("P10 High Optimistic Case", selectedPeriod.oilBopdP90, 500000.0, "BOPD", StatusNormal)
          ConfidenceBarRow("P50 Base Expected Production", selectedPeriod.oilBopdP50, 500000.0, "BOPD", GasCyan)
          ConfidenceBarRow("P90 Conservative Downside", selectedPeriod.oilBopdP10, 500000.0, "BOPD", StatusWarning)
        }
      }
    }

    // Planned Turnaround & Maintenance Impact
    item {
      HudCard(
        title = "Scheduled Turnarounds & Maintenance Outage Windows",
        tag = "TAR-SCHEDULE",
        status = OperationalStatus.NORMAL
      ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          MaintenanceScheduleItem("Forties Alpha Major Turnaround", "Q3 2026", "14 Days", "-32,000 BOPD")
          MaintenanceScheduleItem("SEAL Pipeline Subsea Tie-In", "Q4 2026", "5 Days", "-180 MMSCFD")
          MaintenanceScheduleItem("Clair Ridge Phase 2 Debottlenecking", "Q2 2027", "21 Days", "+15,000 BOPD Net Gain")
        }
      }
    }
  }
}

@Composable
private fun ConfidenceBarRow(label: String, value: Double, max: Double, unit: String, color: Color) {
  Column(modifier = Modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
      Text("${String.format("%,.0f", value)} $unit", style = MaterialTheme.typography.labelMedium, color = color)
    }
    Spacer(modifier = Modifier.height(4.dp))
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(8.dp)
        .background(HudSurfaceBorder, RoundedCornerShape(2.dp))
    ) {
      Box(
        modifier = Modifier
          .fillMaxWidth((value / max).toFloat().coerceIn(0f, 1f))
          .fillMaxHeight()
          .background(color, RoundedCornerShape(2.dp))
      )
    }
  }
}

@Composable
private fun MaintenanceScheduleItem(title: String, timeline: String, duration: String, impact: String) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Column {
      Text(title, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
      Text("Timeline: $timeline • Duration: $duration", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    }
    Text(impact, style = MaterialTheme.typography.labelSmall, color = if (impact.startsWith("+")) StatusNormal else StatusWarning)
  }
}
