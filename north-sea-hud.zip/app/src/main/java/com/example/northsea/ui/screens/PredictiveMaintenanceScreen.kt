package com.example.northsea.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.northsea.models.OperationalStatus
import com.example.northsea.models.PredictiveMaintenanceAsset
import com.example.northsea.ui.components.HudCard
import com.example.northsea.ui.components.LinearEngineeringBar
import com.example.northsea.ui.components.MetricKpiCell
import com.example.northsea.viewmodel.NorthSeaHudViewModel
import com.example.ui.theme.*

@Composable
fun PredictiveMaintenanceScreen(
  viewModel: NorthSeaHudViewModel,
  modifier: Modifier = Modifier
) {
  val assets = viewModel.maintenanceAssets.value

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(HudBackground)
      .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Top AI Health Summary
    item {
      HudCard(
        title = "AI PREDICTIVE MAINTENANCE & MACHINERY INTEGRITY ENGINE",
        tag = "AI-RUL-VIB",
        status = OperationalStatus.NORMAL
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          MetricKpiCell("Monitored Assets", "${assets.size} TRAINS", "", modifier = Modifier.weight(1f))
          MetricKpiCell("Average Fleet Health", "92.4%", "", status = OperationalStatus.NORMAL, modifier = Modifier.weight(1f))
          MetricKpiCell("Predicted Outages (30d)", "1 ASSET", "ADVISORY", status = OperationalStatus.WARNING, modifier = Modifier.weight(1f))
          MetricKpiCell("Avoided Unplanned Losses", "£4.2M", "YTD SAVINGS", modifier = Modifier.weight(1f))
        }
      }
    }

    // Asset Predictive Cards
    items(assets) { asset ->
      val statusColor = when (asset.status) {
        OperationalStatus.NORMAL -> StatusNormal
        OperationalStatus.ADVISORY -> StatusAdvisory
        OperationalStatus.WARNING -> StatusWarning
        OperationalStatus.CRITICAL -> StatusCritical
        else -> PetroleumGold
      }

      Surface(
        shape = RoundedCornerShape(10.dp),
        color = HudSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, HudSurfaceBorder),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Box(modifier = Modifier.size(8.dp).background(statusColor, RoundedCornerShape(3.dp)))
              Text(asset.name.uppercase(), style = MaterialTheme.typography.titleSmall, color = TextPrimary)
              Text("[${asset.tag}]", style = MaterialTheme.typography.labelSmall, color = GasCyan)
            }

            Text(asset.platform, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
          }

          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            MetricKpiCell("Health Index", "${asset.assetHealthPercent.toInt()}%", "", status = asset.status, modifier = Modifier.weight(1f))
            MetricKpiCell("Failure Risk", "${String.format("%.1f", asset.failureRiskPercent)}%", "", status = asset.status, modifier = Modifier.weight(1f))
            MetricKpiCell("Est RUL", "${asset.remainingUsefulLifeHours / 24} DAYS", "", modifier = Modifier.weight(1f))
            MetricKpiCell("Efficiency", "${asset.efficiencyPercent.toInt()}%", "", modifier = Modifier.weight(1f))
          }

          Spacer(modifier = Modifier.height(8.dp))

          LinearEngineeringBar(
            label = "Machinery Health Score (${asset.equipmentType})",
            currentValue = asset.assetHealthPercent,
            maxValue = 100.0,
            unit = "%",
            barColor = statusColor
          )

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = "ANOMALY: ${asset.anomalyType} (AI Conf: ${asset.aiConfidencePercent.toInt()}%)",
            style = MaterialTheme.typography.labelSmall,
            color = if (asset.status != OperationalStatus.NORMAL) StatusWarning else TextMuted
          )

          Spacer(modifier = Modifier.height(2.dp))

          Text(
            text = "RECOMMENDATION: ${asset.recommendation}",
            style = MaterialTheme.typography.bodySmall,
            color = TextPrimary
          )
        }
      }
    }
  }
}
