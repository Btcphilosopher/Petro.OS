package com.example.northsea.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.northsea.models.OperationalStatus
import com.example.northsea.models.WindFarmAsset
import com.example.northsea.ui.components.*
import com.example.northsea.viewmodel.NorthSeaHudViewModel
import com.example.ui.theme.*

@Composable
fun PowerAndWindScreen(
  viewModel: NorthSeaHudViewModel,
  modifier: Modifier = Modifier
) {
  val windFarms = viewModel.windFarms.value
  val platforms = viewModel.platforms.value
  val freq = viewModel.liveGridFrequencyHz.value

  val totalWindOutput = windFarms.sumOf { it.currentOutputMw }
  val totalPlatformLoad = platforms.sumOf { it.powerLoadMw }
  val totalPlatformGen = platforms.sumOf { it.powerGenMw }
  val totalBattery = windFarms.sumOf { it.batteryStorageMw }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(HudBackground)
      .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Top Integrated Grid Balance
    item {
      HudCard(
        title = "INTEGRATED NORTH SEA POWER & ELECTRIFICATION GRID",
        tag = "OFFSHORE-MICROGRID",
        status = OperationalStatus.NORMAL
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          MetricKpiCell("Grid Frequency", String.format("%.2f", freq), "Hz", status = OperationalStatus.NORMAL, modifier = Modifier.weight(1f))
          MetricKpiCell("Offshore Wind Gen", "${String.format("%,.0f", totalWindOutput)} MW", "", modifier = Modifier.weight(1f))
          MetricKpiCell("Platform Gas Gen", "${totalPlatformGen.toInt()} MW", "", modifier = Modifier.weight(1f))
          MetricKpiCell("BESS Storage", "${totalBattery.toInt()} MW", "", modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          CircularEngineeringGauge(
            value = freq,
            min = 49.5,
            max = 50.5,
            unit = "Hz",
            title = "Synchronous Freq",
            gaugeColor = StatusNormal,
            modifier = Modifier.weight(1f)
          )
          CircularEngineeringGauge(
            value = 88.5,
            unit = "%",
            title = "Capacity Factor",
            gaugeColor = WindCyan,
            modifier = Modifier.weight(1f)
          )
          CircularEngineeringGauge(
            value = 38.5,
            unit = "%",
            title = "Platform Electrif.",
            gaugeColor = PowerYellow,
            modifier = Modifier.weight(1f)
          )
          CircularEngineeringGauge(
            value = 0.98,
            min = 0.8,
            max = 1.0,
            unit = "PF",
            title = "Power Factor",
            gaugeColor = GasCyan,
            modifier = Modifier.weight(1f)
          )
        }
      }
    }

    // Offshore Wind Arrays
    item {
      Text(
        text = "OFFSHORE WIND ARRAYS & PLATFORM INTERCONNECTORS",
        style = MaterialTheme.typography.titleMedium,
        color = TextPrimary
      )
    }

    items(windFarms) { wind ->
      Surface(
        shape = RoundedCornerShape(4.dp),
        color = HudSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, HudSurfaceBorder),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Box(modifier = Modifier.size(8.dp).background(WindCyan, RoundedCornerShape(2.dp)))
              Text(wind.name.uppercase(), style = MaterialTheme.typography.titleSmall, color = TextPrimary)
              Text("[${wind.id}]", style = MaterialTheme.typography.labelSmall, color = WindCyan)
            }

            Text(
              text = "TURBINES: ${wind.availableTurbines} / ${wind.totalTurbines} AVAILABLE",
              style = MaterialTheme.typography.labelSmall,
              color = StatusNormal
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            MetricKpiCell("Wind Output", "${String.format("%,.0f", wind.currentOutputMw)} MW", "/ ${wind.nameplateCapacityMw.toInt()} MW", modifier = Modifier.weight(1f))
            MetricKpiCell("Wind Speed", "${wind.windSpeedKts} kts", "", modifier = Modifier.weight(1f))
            MetricKpiCell("Platform Feed", "${wind.platformSupplyMw.toInt()} MW", "HVDC CABLE", modifier = Modifier.weight(1f))
            MetricKpiCell("National Grid Export", "${wind.gridExportMw.toInt()} MW", "", modifier = Modifier.weight(1f))
          }

          Spacer(modifier = Modifier.height(8.dp))

          LinearEngineeringBar(
            label = "Nameplate Capacity Factor",
            currentValue = wind.currentOutputMw,
            maxValue = wind.nameplateCapacityMw,
            unit = "MW",
            barColor = WindCyan
          )
        }
      }
    }
  }
}
