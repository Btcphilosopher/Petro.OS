package com.example.northsea.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.northsea.models.OperationalStatus
import com.example.northsea.models.PipelineAsset
import com.example.northsea.ui.components.HudCard
import com.example.northsea.ui.components.LinearEngineeringBar
import com.example.northsea.ui.components.MetricKpiCell
import com.example.northsea.viewmodel.NorthSeaHudViewModel
import com.example.ui.theme.*

@Composable
fun PipelineNetworkScreen(
  viewModel: NorthSeaHudViewModel,
  modifier: Modifier = Modifier
) {
  val pipelines = viewModel.pipelines.value
  var selectedPipe by remember { mutableStateOf<PipelineAsset?>(null) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(HudBackground)
      .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Network Summary
    item {
      HudCard(
        title = "NORTH SEA PIPELINE TRANSMISSION GRID (29 TRUNK LINES)",
        tag = "GRID-PIPE-MASTER",
        status = OperationalStatus.NORMAL
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          MetricKpiCell("Active Grid Lines", "29 LINES", "", modifier = Modifier.weight(1f))
          MetricKpiCell("Total Linepack", "84.2%", "CAPACITY", modifier = Modifier.weight(1f))
          MetricKpiCell("Gas Grid Flow", "6,100", "MMSCFD", modifier = Modifier.weight(1f))
          MetricKpiCell("Oil Grid Flow", "445,000", "BOPD", modifier = Modifier.weight(1f))
        }
      }
    }

    // Pipelines List
    items(pipelines) { pipe ->
      val isSelected = selectedPipe?.id == pipe.id
      val utilization = (pipe.currentFlowMmscfdOrBpd / pipe.capacityMmscfdOrBpd) * 100

      Surface(
        shape = RoundedCornerShape(4.dp),
        color = if (isSelected) HudSurfaceHover else HudSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) GasCyan else HudSurfaceBorder),
        modifier = Modifier
          .fillMaxWidth()
          .clickable { selectedPipe = pipe }
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Box(modifier = Modifier.size(8.dp).background(StatusNormal, RoundedCornerShape(2.dp)))
              Text(pipe.name.uppercase(), style = MaterialTheme.typography.titleSmall, color = TextPrimary)
              Text("[${pipe.id}]", style = MaterialTheme.typography.labelSmall, color = GasCyan)
            }

            Text(
              text = "${pipe.diameterInches}\" • ${pipe.lengthKm.toInt()} km",
              style = MaterialTheme.typography.labelSmall,
              color = TextSecondary
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            MetricKpiCell("Origin → Destination", "${pipe.origin} → ${pipe.destination}", "", modifier = Modifier.weight(2f))
            MetricKpiCell("Operating Pressure", "${String.format("%.1f", pipe.currentPressureBar)} bar", "/ ${pipe.maxOperatingPressureBar} bar", modifier = Modifier.weight(1f))
            MetricKpiCell("Process Temp", "${String.format("%.1f", pipe.temperatureC)} °C", "", modifier = Modifier.weight(1f))
          }

          Spacer(modifier = Modifier.height(8.dp))

          LinearEngineeringBar(
            label = "Hydraulic Flow Utilisation",
            currentValue = pipe.currentFlowMmscfdOrBpd,
            maxValue = pipe.capacityMmscfdOrBpd,
            unit = "",
            barColor = GasCyan
          )

          Spacer(modifier = Modifier.height(6.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = "INTEGRITY: ${pipe.integrityStatus}",
              style = MaterialTheme.typography.labelSmall,
              color = StatusNormal
            )
            Text(
              text = "LAST SMART PIG RUN: ${pipe.pigInspectionDaysAgo} DAYS AGO",
              style = MaterialTheme.typography.labelSmall,
              color = TextSecondary
            )
          }
        }
      }
    }
  }
}
