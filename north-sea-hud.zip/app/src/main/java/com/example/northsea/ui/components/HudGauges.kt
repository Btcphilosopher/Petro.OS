package com.example.northsea.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun CircularEngineeringGauge(
  value: Double,
  min: Double = 0.0,
  max: Double = 100.0,
  unit: String,
  title: String,
  modifier: Modifier = Modifier,
  size: Dp = 120.dp,
  gaugeColor: Color = GasCyan,
  warningThreshold: Double? = null,
  criticalThreshold: Double? = null
) {
  val clampedValue = value.coerceIn(min, max)
  val sweepFraction = ((clampedValue - min) / (max - min)).toFloat()

  val activeColor = when {
    criticalThreshold != null && value >= criticalThreshold -> StatusCritical
    warningThreshold != null && value >= warningThreshold -> StatusWarning
    else -> gaugeColor
  }

  Column(
    modifier = modifier,
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Box(
      modifier = Modifier.size(size),
      contentAlignment = Alignment.Center
    ) {
      Canvas(modifier = Modifier.fillMaxSize().padding(8.dp)) {
        val strokeWidth = 8.dp.toPx()
        val startAngle = 135f
        val totalSweep = 270f

        // Background track
        drawArc(
          color = HudSurfaceBorder,
          startAngle = startAngle,
          sweepAngle = totalSweep,
          useCenter = false,
          style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
          size = Size(this.size.width, this.size.height)
        )

        // Active sweep
        drawArc(
          color = activeColor,
          startAngle = startAngle,
          sweepAngle = totalSweep * sweepFraction,
          useCenter = false,
          style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
          size = Size(this.size.width, this.size.height)
        )

        // Tick marks
        val tickCount = 10
        val center = Offset(this.size.width / 2, this.size.height / 2)
        val radius = (this.size.width / 2) - 12.dp.toPx()

        for (i in 0..tickCount) {
          val angleDeg = startAngle + (totalSweep * (i.toFloat() / tickCount))
          val angleRad = Math.toRadians(angleDeg.toDouble())
          val p1 = Offset(
            (center.x + (radius - 4.dp.toPx()) * cos(angleRad)).toFloat(),
            (center.y + (radius - 4.dp.toPx()) * sin(angleRad)).toFloat()
          )
          val p2 = Offset(
            (center.x + radius * cos(angleRad)).toFloat(),
            (center.y + radius * sin(angleRad)).toFloat()
          )
          drawLine(
            color = if (i.toFloat() / tickCount <= sweepFraction) activeColor else TextMuted,
            start = p1,
            end = p2,
            strokeWidth = 1.5.dp.toPx()
          )
        }
      }

      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
      ) {
        Text(
          text = if (value >= 1000) String.format("%.0f", value) else String.format("%.1f", value),
          style = MaterialTheme.typography.titleMedium,
          color = TextPrimary
        )
        Text(
          text = unit,
          style = MaterialTheme.typography.labelSmall,
          color = TextSecondary
        )
      }
    }

    Text(
      text = title.uppercase(),
      style = MaterialTheme.typography.labelSmall,
      color = TextSecondary
    )
  }
}

@Composable
fun LinearEngineeringBar(
  label: String,
  currentValue: Double,
  maxValue: Double,
  unit: String,
  modifier: Modifier = Modifier,
  barColor: Color = GasCyan,
  warningPercent: Double = 80.0,
  criticalPercent: Double = 92.0
) {
  val percentage = if (maxValue > 0) (currentValue / maxValue * 100).coerceIn(0.0, 100.0) else 0.0
  val activeColor = when {
    percentage >= criticalPercent -> StatusCritical
    percentage >= warningPercent -> StatusWarning
    else -> barColor
  }

  Column(modifier = modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = label.uppercase(),
        style = MaterialTheme.typography.labelSmall,
        color = TextSecondary
      )
      Text(
        text = "${String.format("%.1f", currentValue)} / ${String.format("%.1f", maxValue)} $unit (${percentage.toInt()}%)",
        style = MaterialTheme.typography.labelSmall,
        color = TextPrimary
      )
    }

    Spacer(modifier = Modifier.height(4.dp))

    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(6.dp)
        .background(HudSurfaceBorder, RoundedCornerShape(3.dp))
    ) {
      Box(
        modifier = Modifier
          .fillMaxWidth((percentage / 100.0).toFloat())
          .fillMaxHeight()
          .background(activeColor, RoundedCornerShape(3.dp))
      )
    }
  }
}

@Composable
fun SparklineMiniGraph(
  dataPoints: List<Double>,
  modifier: Modifier = Modifier,
  lineColor: Color = GasCyan
) {
  if (dataPoints.size < 2) return

  val min = dataPoints.minOrNull() ?: 0.0
  val max = dataPoints.maxOrNull() ?: 100.0
  val range = if (max - min == 0.0) 1.0 else max - min

  Canvas(modifier = modifier) {
    val stepX = size.width / (dataPoints.size - 1)
    val path = Path()

    dataPoints.forEachIndexed { index, value ->
      val x = index * stepX
      val normalizedY = ((value - min) / range).toFloat()
      val y = size.height - (normalizedY * size.height)

      if (index == 0) {
        path.moveTo(x, y)
      } else {
        path.lineTo(x, y)
      }
    }

    drawPath(
      path = path,
      color = lineColor,
      style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
    )
  }
}
