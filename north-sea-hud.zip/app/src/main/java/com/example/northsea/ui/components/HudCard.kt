package com.example.northsea.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.northsea.models.OperationalStatus
import com.example.ui.theme.*

@Composable
fun HudCard(
  modifier: Modifier = Modifier,
  title: String? = null,
  tag: String? = null,
  status: OperationalStatus = OperationalStatus.NORMAL,
  trailingContent: @Composable (() -> Unit)? = null,
  content: @Composable ColumnScope.() -> Unit
) {
  val statusColor = when (status) {
    OperationalStatus.NORMAL -> StatusNormal
    OperationalStatus.ADVISORY -> StatusAdvisory
    OperationalStatus.WARNING -> StatusWarning
    OperationalStatus.CRITICAL -> StatusCritical
    OperationalStatus.EMERGENCY -> StatusEmergency
    OperationalStatus.OFFLINE -> StatusOffline
    OperationalStatus.MAINTENANCE -> PetroleumGold
  }

  Box(
    modifier = modifier
      .clip(RoundedCornerShape(12.dp))
      .background(HudSurface)
      .border(BorderStroke(1.dp, HudSurfaceBorder), RoundedCornerShape(12.dp))
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp)
    ) {
      if (title != null || tag != null || trailingContent != null) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            // Bento Status Indicator Dot
            Box(
              modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(statusColor)
            )

            if (tag != null) {
              Text(
                text = "[$tag]",
                style = MaterialTheme.typography.labelSmall,
                color = GasCyan
              )
            }

            if (title != null) {
              Text(
                text = title.uppercase(),
                style = MaterialTheme.typography.labelMedium,
                color = TextSecondary
              )
            }
          }

          trailingContent?.invoke()
        }
      }

      content()
    }
  }
}

@Composable
fun MetricKpiCell(
  label: String,
  value: String,
  unit: String? = null,
  status: OperationalStatus = OperationalStatus.NORMAL,
  modifier: Modifier = Modifier
) {
  val valueColor = when (status) {
    OperationalStatus.NORMAL -> GasCyan
    OperationalStatus.ADVISORY -> StatusAdvisory
    OperationalStatus.WARNING -> StatusWarning
    OperationalStatus.CRITICAL -> StatusCritical
    OperationalStatus.EMERGENCY -> StatusEmergency
    OperationalStatus.OFFLINE -> TextMuted
    OperationalStatus.MAINTENANCE -> PetroleumGold
  }

  Column(modifier = modifier) {
    Text(
      text = label.uppercase(),
      style = MaterialTheme.typography.labelSmall,
      color = TextTertiary,
      maxLines = 1
    )
    Spacer(modifier = Modifier.height(2.dp))
    Row(
      verticalAlignment = Alignment.Bottom,
      horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
      Text(
        text = value,
        style = MaterialTheme.typography.displaySmall,
        color = valueColor
      )
      if (unit != null) {
        Text(
          text = unit,
          style = MaterialTheme.typography.labelSmall,
          color = TextTertiary,
          modifier = Modifier.padding(bottom = 2.dp)
        )
      }
    }
  }
}

