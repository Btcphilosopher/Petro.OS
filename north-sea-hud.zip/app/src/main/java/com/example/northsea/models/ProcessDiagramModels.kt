package com.example.northsea.models

enum class NodeType {
  WELLS_CLUSTER,
  WELL_HEAD,
  MANIFOLD,
  SEPARATION_PRIMARY,
  SEPARATION_OIL,
  SEPARATION_GAS,
  SEPARATION_WATER,
  GAS_DEHYDRATION,
  GAS_COMPRESSION,
  OIL_TREATMENT,
  OIL_EXPORT_PUMP,
  WATER_INJECTION_PUMP,
  SUBSEA_PIPELINE,
  TERMINAL_RECEPTION
}

data class ProcessNode(
  val id: String,
  val title: String,
  val type: NodeType,
  val subtitle: String,
  val pressureBar: Double,
  val temperatureC: Double,
  val flowRate: Double,
  val flowUnit: String,
  val status: OperationalStatus,
  val xRel: Float, // Relative X coordinate (0f..1f)
  val yRel: Float  // Relative Y coordinate (0f..1f)
)

data class ProcessFlowConnection(
  val id: String,
  val sourceNodeId: String,
  val targetNodeId: String,
  val medium: String, // "OIL", "GAS", "WATER", "MULTIPHASE"
  val flowRate: Double,
  val flowUnit: String
)
