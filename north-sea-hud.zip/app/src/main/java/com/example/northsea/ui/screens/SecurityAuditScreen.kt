package com.example.northsea.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.northsea.models.AuditLogEntry
import com.example.northsea.models.OperationalStatus
import com.example.northsea.models.UserRole
import com.example.northsea.ui.components.HudCard
import com.example.northsea.ui.components.MetricKpiCell
import com.example.northsea.viewmodel.NorthSeaHudViewModel
import com.example.ui.theme.*

@Composable
fun SecurityAuditScreen(
  viewModel: NorthSeaHudViewModel,
  modifier: Modifier = Modifier
) {
  val auditLogs = viewModel.auditLogs.value
  val currentRole = viewModel.currentUserRole.value

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(HudBackground)
      .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Top Security Architecture & IEC 62443 Cyber Posture
    item {
      HudCard(
        title = "IEC 62443 INDUSTRIAL CYBERSECURITY & OT SCADA AIR-GAP STATUS",
        tag = "OT-SEC-LEDGER",
        status = OperationalStatus.NORMAL
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          MetricKpiCell("SCADA OT Isolation", "AIR-GAPPED", "LEVEL 4", status = OperationalStatus.NORMAL, modifier = Modifier.weight(1f))
          MetricKpiCell("Current Session Clearance", currentRole.clearance, "", modifier = Modifier.weight(1f))
          MetricKpiCell("Active Role", currentRole.roleName, "", modifier = Modifier.weight(1f))
          MetricKpiCell("Immutable Ledger", "SYNCED (100%)", "CRYPTO-HASH", status = OperationalStatus.NORMAL, modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = "FIREWALL STATUS: All offshore PLC subnets isolated behind unidirectional data diodes.",
            style = MaterialTheme.typography.labelSmall,
            color = StatusNormal
          )
          Text(
            text = "LOG RETENTION: 7 YEARS (UK NSTA REGULATORY COMPLIANT)",
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary
          )
        }
      }
    }

    // Role Elevation Quick Actions
    item {
      Text(
        text = "ROLE-BASED ACCESS CONTROL (RBAC) PROFILES",
        style = MaterialTheme.typography.titleMedium,
        color = TextPrimary
      )
    }

    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        UserRole.values().take(3).forEach { role ->
          RoleSummaryButton(
            role = role,
            isActive = role == currentRole,
            onClick = { viewModel.switchRole(role) },
            modifier = Modifier.weight(1f)
          )
        }
      }
    }

    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        UserRole.values().drop(3).forEach { role ->
          RoleSummaryButton(
            role = role,
            isActive = role == currentRole,
            onClick = { viewModel.switchRole(role) },
            modifier = Modifier.weight(1f)
          )
        }
      }
    }

    // Cryptographic Audit Ledger
    item {
      Text(
        text = "CRYPTOGRAPHICALLY VERIFIED AUDIT LOG (${auditLogs.size} ENTRIES)",
        style = MaterialTheme.typography.titleMedium,
        color = TextPrimary
      )
    }

    items(auditLogs) { log ->
      AuditLogRow(log = log)
    }
  }
}

@Composable
private fun RoleSummaryButton(
  role: UserRole,
  isActive: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Surface(
    shape = RoundedCornerShape(4.dp),
    color = if (isActive) HudSurfaceHover else HudSurface,
    border = androidx.compose.foundation.BorderStroke(1.dp, if (isActive) Color(role.badgeColor) else HudSurfaceBorder),
    modifier = modifier.clickable { onClick() }
  ) {
    Column(modifier = Modifier.padding(8.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(role.roleName, style = MaterialTheme.typography.labelSmall, color = if (isActive) Color(role.badgeColor) else TextPrimary)
        if (isActive) {
          Box(modifier = Modifier.size(6.dp).background(Color(role.badgeColor), RoundedCornerShape(2.dp)))
        }
      }
      Text(role.clearance, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    }
  }
}

@Composable
private fun AuditLogRow(log: AuditLogEntry) {
  Surface(
    shape = RoundedCornerShape(4.dp),
    color = HudSurface,
    border = androidx.compose.foundation.BorderStroke(1.dp, HudSurfaceBorder),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(10.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Text(log.formattedTime, style = MaterialTheme.typography.labelSmall, color = GasCyan)
          Text("[${log.actionType}]", style = MaterialTheme.typography.labelSmall, color = TextPrimary)
          Text("• ${log.targetAsset}", style = MaterialTheme.typography.labelSmall, color = PetroleumGold)
        }

        Text(log.verificationHash, style = MaterialTheme.typography.labelSmall, color = TextMuted)
      }

      Spacer(modifier = Modifier.height(4.dp))

      Text(
        text = log.details,
        style = MaterialTheme.typography.bodySmall,
        color = TextSecondary
      )

      Spacer(modifier = Modifier.height(2.dp))

      Text(
        text = "OPERATOR: ${log.operatorName} (${log.userRole.roleName}) • ID: ${log.id}",
        style = MaterialTheme.typography.labelSmall,
        color = TextMuted
      )
    }
  }
}
