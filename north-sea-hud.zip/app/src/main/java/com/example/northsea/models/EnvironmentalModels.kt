package com.example.northsea.models

data class EnvironmentalTelemetry(
  val co2EmissionsTodayTonnes: Double,
  val co2IntensityKgBoe: Double,
  val targetCo2IntensityKgBoe: Double,
  val methaneSlipRatePercent: Double,
  val methaneConcentrationPpm: Double,
  val flaringRateMmscfd: Double,
  val flaringPercentOfProduction: Double,
  val ventingRateMmscfd: Double,
  val producedWaterDischargeBpd: Double,
  val oilInWaterContentPpm: Double,
  val maxPermissibleOiwPpm: Double,
  val waterReinjectionPercent: Double,
  val platformElectrificationPercent: Double,
  val renewablePowerSharePercent: Double,
  val emissionsAvoidedWindTonneDay: Double
)
