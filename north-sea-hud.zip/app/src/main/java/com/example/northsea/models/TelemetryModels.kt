package com.example.northsea.models

enum class TelemetryQuality {
  GOOD,
  ESTIMATED,
  MANUAL,
  BAD,
  SIMULATED,
  OPTIMISED
}

enum class OperationalStatus {
  NORMAL,
  ADVISORY,
  WARNING,
  CRITICAL,
  EMERGENCY,
  OFFLINE,
  MAINTENANCE
}

enum class MeasurementType(val unit: String) {
  OIL_FLOW("BOPD"),
  GAS_FLOW("MMSCFD"),
  WATER_FLOW("BPD"),
  CONDENSATE("BPD"),
  PRESSURE_PSI("PSI"),
  PRESSURE_BAR("bar"),
  TEMPERATURE_C("°C"),
  TEMPERATURE_F("°F"),
  POWER_MW("MW"),
  POWER_KW("kW"),
  FREQUENCY_HZ("Hz"),
  VOLTAGE_KV("kV"),
  VIBRATION_MM_S("mm/s"),
  RPM("RPM"),
  SURGE_MARGIN("%"),
  EFFICIENCY("%"),
  CHOKE_PERCENT("%"),
  WATER_CUT("%"),
  GAS_OIL_RATIO("SCF/bbl"),
  EMISSIONS_CO2_T_DAY("t/d"),
  METHANE_PPM("ppm"),
  FLARING_PERCENT("%"),
  WIND_SPEED_KTS("kts"),
  WAVE_HEIGHT_M("m")
}

data class TelemetryMeasurement(
  val timestamp: Long,
  val assetId: String,
  val tag: String,
  val description: String,
  val measurementType: MeasurementType,
  val value: Double,
  val quality: TelemetryQuality = TelemetryQuality.GOOD,
  val status: OperationalStatus = OperationalStatus.NORMAL,
  val minThreshold: Double = 0.0,
  val maxThreshold: Double = 100.0
)

data class MasterKpiSummary(
  val totalOilProductionBopd: Double,
  val totalGasProductionMmscfd: Double,
  val totalPowerMw: Double,
  val gasExportMmscfd: Double,
  val gridPowerMw: Double,
  val flaringPercentage: Double,
  val uptimePercentage: Double,
  val safetyStatus: OperationalStatus,
  val activeAlertCount: Int,
  val dailyRevenueGbp: Double,
  val carbonIntensityKgBoe: Double
)
