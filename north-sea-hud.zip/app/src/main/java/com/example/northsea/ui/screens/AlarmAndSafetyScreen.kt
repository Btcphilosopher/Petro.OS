package com.example.northsea.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.northsea.models.AlarmClass
import com.example.northsea.models.AlarmItem
import com.example.northsea.models.OperationalStatus
import com.example.northsea.ui.components.HudCard
import com.example.northsea.ui.components.MetricKpiCell
import com.example.northsea.viewmodel.NorthSeaHudViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun AlarmAndSafetyScreen(
  viewModel: NorthSeaHudViewModel,
  modifier: Modifier = Modifier
) {
  val alarms = viewModel.alarms.value
  val safety = viewModel.safetyOverlay.value
  val selectedClass = viewModel.alarmClassFilter.value

  val filteredAlarms = alarms.filter {
    selectedClass == null || it.alarmClass == selectedClass
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(HudBackground)
      .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Top Safety & Lifeboat Readiness Overlay
    item {
      HudCard(
        title = "OFFSHORE SAFETY SYSTEMS & LIFE SUPPORT OVERLAY",
        tag = "SIS-ESD-METOCEAN",
        status = safety.overallSafetyStatus
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          MetricKpiCell("SIS / ESD Systems", if (safety.sisEsdArmed) "ARMED / 100%" else "INHIBITED", "", status = OperationalStatus.NORMAL, modifier = Modifier.weight(1f))
          MetricKpiCell("Lifeboat Fleet", "${safety.availableLifeboats} / ${safety.totalLifeboats}", "READY", modifier = Modifier.weight(1f))
          MetricKpiCell("Helideck Status", safety.helideckStatus, "", status = OperationalStatus.NORMAL, modifier = Modifier.weight(1f))
          MetricKpiCell("Standby ERRV", if (safety.standbyVesselOnStation) "ON-STATION (0.8 NM)" else "ABSENT", "", modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = "METOCEAN: Wind ${safety.metocean.windSpeedKts} kts ${safety.metocean.windDirection} • Waves Hs ${safety.metocean.significantWaveHeightM}m • Sea Temp ${safety.metocean.seaTempC}°C",
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary
          )
          Text(
            text = "NEXT FLIGHT: ${safety.helicopterMission} (${safety.nextHelicopterEtaMin}m)",
            style = MaterialTheme.typography.labelSmall,
            color = GasCyan
          )
        }
      }
    }

    // Alarm Filter Bar
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        FilterChip(
          selected = selectedClass == null,
          onClick = { viewModel.setAlarmClassFilter(null) },
          label = { Text("ALL ALARMS (${alarms.size})", style = MaterialTheme.typography.labelSmall) }
        )
        FilterChip(
          selected = selectedClass == AlarmClass.CRITICAL,
          onClick = { viewModel.setAlarmClassFilter(if (selectedClass == AlarmClass.CRITICAL) null else AlarmClass.CRITICAL) },
          label = { Text("CRITICAL (${alarms.count { it.alarmClass == AlarmClass.CRITICAL }})", style = MaterialTheme.typography.labelSmall, color = StatusCritical) }
        )
        FilterChip(
          selected = selectedClass == AlarmClass.WARNING,
          onClick = { viewModel.setAlarmClassFilter(if (selectedClass == AlarmClass.WARNING) null else AlarmClass.WARNING) },
          label = { Text("WARNING (${alarms.count { it.alarmClass == AlarmClass.WARNING }})", style = MaterialTheme.typography.labelSmall, color = StatusWarning) }
        )
        FilterChip(
          selected = selectedClass == AlarmClass.ADVISORY,
          onClick = { viewModel.setAlarmClassFilter(if (selectedClass == AlarmClass.ADVISORY) null else AlarmClass.ADVISORY) },
          label = { Text("ADVISORY (${alarms.count { it.alarmClass == AlarmClass.ADVISORY }})", style = MaterialTheme.typography.labelSmall, color = StatusAdvisory) }
        )
      }
    }

    // Alarms List
    items(filteredAlarms) { alarm ->
      AlarmItemCard(
        alarm = alarm,
        onAcknowledge = { viewModel.acknowledgeAlarm(alarm.id) },
        onShelve = { viewModel.shelveAlarm(alarm.id) }
      )
    }
  }
}

@Composable
private fun AlarmItemCard(
  alarm: AlarmItem,
  onAcknowledge: () -> Unit,
  onShelve: () -> Unit
) {
  val severityColor = when (alarm.alarmClass) {
    AlarmClass.EMERGENCY -> StatusEmergency
    AlarmClass.CRITICAL -> StatusCritical
    AlarmClass.WARNING -> StatusWarning
    AlarmClass.ADVISORY -> StatusAdvisory
    AlarmClass.INFORMATION -> GasCyan
  }

  val timeFormatter = remember { SimpleDateFormat("HH:mm:ss", Locale.UK) }
  val timeStr = remember(alarm.timestamp) { timeFormatter.format(Date(alarm.timestamp)) }

  Surface(
    shape = RoundedCornerShape(10.dp),
    color = if (!alarm.isAcknowledged) severityColor.copy(alpha = 0.08f) else HudSurface,
    border = androidx.compose.foundation.BorderStroke(1.dp, if (!alarm.isAcknowledged) severityColor else HudSurfaceBorder),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(modifier = Modifier.size(8.dp).background(severityColor, RoundedCornerShape(3.dp)))
          Text(alarm.tag, style = MaterialTheme.typography.titleSmall, color = TextPrimary)
          Text("[${alarm.alarmClass.label}]", style = MaterialTheme.typography.labelSmall, color = severityColor)
          Text("• ${alarm.category.name}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        }

        Text(timeStr, style = MaterialTheme.typography.labelSmall, color = TextMuted)
      }

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = alarm.message,
        style = MaterialTheme.typography.bodyMedium,
        color = TextPrimary
      )

      Spacer(modifier = Modifier.height(6.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
          Text("CURRENT: ${alarm.currentValue} ${alarm.unit}", style = MaterialTheme.typography.labelSmall, color = TextPrimary)
          Text("SETPOINT: ${alarm.setpointValue} ${alarm.unit}", style = MaterialTheme.typography.labelSmall, color = StatusCritical)
          Text("ASSET: ${alarm.assetName}", style = MaterialTheme.typography.labelSmall, color = GasCyan)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          if (!alarm.isAcknowledged) {
            Button(
              onClick = onAcknowledge,
              colors = ButtonDefaults.buttonColors(containerColor = severityColor),
              shape = RoundedCornerShape(6.dp),
              contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
            ) {
              Text("ACKNOWLEDGE", style = MaterialTheme.typography.labelSmall, color = HudBackground)
            }
          } else {
            Text(
              text = "ACK BY: ${alarm.acknowledgedBy ?: "OPERATOR"}",
              style = MaterialTheme.typography.labelSmall,
              color = StatusNormal
            )
          }

          if (!alarm.isShelved) {
            OutlinedButton(
              onClick = onShelve,
              shape = RoundedCornerShape(6.dp),
              contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
              border = androidx.compose.foundation.BorderStroke(1.dp, HudSurfaceBorder)
            ) {
              Text("SHELVE 60M", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
          }
        }
      }
    }
  }
}

