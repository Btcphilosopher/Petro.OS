package com.example.northsea.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.northsea.models.OperationalStatus
import com.example.northsea.models.PlatformAsset
import com.example.northsea.ui.components.*
import com.example.northsea.viewmodel.HudScreen
import com.example.northsea.viewmodel.NorthSeaHudViewModel
import com.example.ui.theme.*

@Composable
fun MasterOperationsHudScreen(
  viewModel: NorthSeaHudViewModel,
  modifier: Modifier = Modifier
) {
  val kpi = viewModel.masterKpi.value
  val platforms = viewModel.platforms.value
  val pipelines = viewModel.pipelines.value
  val terminals = viewModel.terminals.value
  val alarms = viewModel.alarms.value
  val windFarms = viewModel.windFarms.value
  val frequency = viewModel.liveGridFrequencyHz.value

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(HudBackground)
      .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Row 1: Key Operational Panels (Production & Reservoir)
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        // Production Summary
        HudCard(
          title = "North Sea Production",
          tag = "PROD-SYS-01",
          status = OperationalStatus.NORMAL,
          modifier = Modifier.weight(1f)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            MetricKpiCell("Total Oil", String.format("%,.0f", kpi.totalOilProductionBopd), "BOPD", modifier = Modifier.weight(1f))
            MetricKpiCell("Total Gas", String.format("%,.0f", kpi.totalGasProductionMmscfd), "MMSCFD", modifier = Modifier.weight(1f))
            MetricKpiCell("Condensate", "38,400", "BPD", modifier = Modifier.weight(1f))
          }
          Spacer(modifier = Modifier.height(10.dp))
          LinearEngineeringBar("Production Efficiency", 96.4, 100.0, "%", barColor = StatusNormal)
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("PRODUCING WELLS: 364 / 387", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Text("OFFLINE WELLS: 23", style = MaterialTheme.typography.labelSmall, color = StatusWarning)
          }
        }

        // Reservoir Telemetry
        HudCard(
          title = "Reservoir Telemetry",
          tag = "RES-MOD-04",
          status = OperationalStatus.NORMAL,
          modifier = Modifier.weight(1f)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            MetricKpiCell("Avg Reservoir P", "3,480", "PSI", modifier = Modifier.weight(1f))
            MetricKpiCell("Reservoir Temp", "98.5", "°C", modifier = Modifier.weight(1f))
            MetricKpiCell("Water Cut", "28.4", "%", modifier = Modifier.weight(1f))
          }
          Spacer(modifier = Modifier.height(10.dp))
          LinearEngineeringBar("Water Injection Voidage Replacement", 104.2, 100.0, "%", barColor = WaterBlue)
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("RECOVERY FACTOR: 44.8%", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Text("DECLINE RATE: -4.2%/yr", style = MaterialTheme.typography.labelSmall, color = GasCyan)
          }
        }
      }
    }

    // Row 2: Live Platform Matrix (Interactive Cards)
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "OFFSHORE PLATFORM FLEET STATUS (18 ASSETS)",
          style = MaterialTheme.typography.titleMedium,
          color = TextPrimary
        )
        TextButton(onClick = { viewModel.navigateTo(HudScreen.OFFSHORE_PLATFORM) }) {
          Text("VIEW PLATFORM HUD →", style = MaterialTheme.typography.labelSmall, color = GasCyan)
        }
      }
    }

    item {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        platforms.take(4).forEach { platform ->
          PlatformMatrixRow(
            platform = platform,
            onClick = {
              viewModel.selectPlatformById(platform.id)
              viewModel.navigateTo(HudScreen.OFFSHORE_PLATFORM)
            }
          )
        }
      }
    }

    // Row 3: Grid Power & Offshore Wind Integration
    item {
      HudCard(
        title = "Integrated Power & North Sea Grid Balance",
        tag = "GRID-SYN-09",
        status = OperationalStatus.NORMAL
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          MetricKpiCell("Grid Frequency", String.format("%.2f", frequency), "Hz", status = OperationalStatus.NORMAL, modifier = Modifier.weight(1f))
          MetricKpiCell("Gas Turbine Gen", "312", "MW", modifier = Modifier.weight(1f))
          MetricKpiCell("Offshore Wind Gen", String.format("%,.0f", windFarms.sumOf { it.currentOutputMw }), "MW", modifier = Modifier.weight(1f))
          MetricKpiCell("Platform Electrification", "38.5", "%", modifier = Modifier.weight(1f))
        }
        Spacer(modifier = Modifier.height(10.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          CircularEngineeringGauge(
            value = 88.4,
            unit = "%",
            title = "Grid Reserve",
            size = 90.dp,
            gaugeColor = StatusNormal,
            modifier = Modifier.weight(1f)
          )
          CircularEngineeringGauge(
            value = 92.0,
            unit = "%",
            title = "Turbine Avail",
            size = 90.dp,
            gaugeColor = GasCyan,
            modifier = Modifier.weight(1f)
          )
          CircularEngineeringGauge(
            value = windFarms.firstOrNull()?.capacityFactorPercent ?: 86.6,
            unit = "%",
            title = "Wind Cap Factor",
            size = 90.dp,
            gaugeColor = WindCyan,
            modifier = Modifier.weight(1f)
          )
          CircularEngineeringGauge(
            value = 0.68,
            unit = "%",
            title = "Flare Loss",
            size = 90.dp,
            gaugeColor = PetroleumGold,
            modifier = Modifier.weight(1f)
          )
        }
      }
    }

    // Row 4: Export Pipelines & Shore Terminals
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        // Pipelines
        HudCard(
          title = "Subsea Pipelines (29 Lines)",
          tag = "PIPE-NET-01",
          status = OperationalStatus.NORMAL,
          modifier = Modifier.weight(1f)
        ) {
          pipelines.take(3).forEach { pipe ->
            Column(modifier = Modifier.padding(vertical = 4.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(pipe.name, style = MaterialTheme.typography.labelSmall, color = TextPrimary)
                Text("${pipe.currentPressureBar} bar", style = MaterialTheme.typography.labelSmall, color = GasCyan)
              }
              LinearEngineeringBar(
                label = "${pipe.origin.take(15)} → ${pipe.destination.take(15)}",
                currentValue = pipe.currentFlowMmscfdOrBpd,
                maxValue = pipe.capacityMmscfdOrBpd,
                unit = "",
                barColor = GasCyan
              )
            }
          }
        }

        // Shore Terminals
        HudCard(
          title = "Shore-Based Terminals",
          tag = "TERM-RECEPT-06",
          status = OperationalStatus.NORMAL,
          modifier = Modifier.weight(1f)
        ) {
          terminals.take(3).forEach { term ->
            Column(modifier = Modifier.padding(vertical = 4.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(term.name, style = MaterialTheme.typography.labelSmall, color = TextPrimary)
                Text("${term.processedGasMmscfd.toInt()} MMSCFD", style = MaterialTheme.typography.labelSmall, color = PetroleumGold)
              }
              LinearEngineeringBar(
                label = "Storage: ${term.storageUtilPercent}% • Plant Avail",
                currentValue = term.plantAvailabilityPercent,
                maxValue = 100.0,
                unit = "%",
                barColor = StatusNormal
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun PlatformMatrixRow(
  platform: PlatformAsset,
  onClick: () -> Unit
) {
  Surface(
    shape = RoundedCornerShape(10.dp),
    color = HudSurface,
    border = androidx.compose.foundation.BorderStroke(1.dp, HudSurfaceBorder),
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onClick() }
  ) {
    Row(
      modifier = Modifier.padding(12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.weight(1.5f)
      ) {
        Box(
          modifier = Modifier
            .size(8.dp)
            .background(
              if (platform.status == OperationalStatus.NORMAL) StatusNormal else StatusWarning,
              RoundedCornerShape(4.dp)
            )
        )
        Column {
          Text(platform.name.uppercase(), style = MaterialTheme.typography.titleSmall, color = TextPrimary)
          Text("${platform.fieldName} • ${platform.quadrantBlock}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        }
      }

      Row(
        modifier = Modifier.weight(2f),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text("OIL EXPORT", style = MaterialTheme.typography.labelSmall, color = TextTertiary)
          Text("${String.format("%,.0f", platform.oilBopd)} BOPD", style = MaterialTheme.typography.labelMedium, color = PetroleumGold)
        }
        Column {
          Text("GAS EXPORT", style = MaterialTheme.typography.labelSmall, color = TextTertiary)
          Text("${String.format("%,.0f", platform.gasMmscfd)} MMSCFD", style = MaterialTheme.typography.labelMedium, color = GasCyan)
        }
        Column {
          Text("LOAD / GEN", style = MaterialTheme.typography.labelSmall, color = TextTertiary)
          Text("${platform.powerLoadMw.toInt()} / ${platform.powerGenMw.toInt()} MW", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
        }
        Column {
          Text("POB", style = MaterialTheme.typography.labelSmall, color = TextTertiary)
          Text("${platform.personnelOnBoard} / ${platform.maxCapacityPob}", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
        }
      }

      Icon(
        imageVector = Icons.Default.ChevronRight,
        contentDescription = "Inspect",
        tint = GasCyan,
        modifier = Modifier.size(16.dp)
      )
    }
  }
}
