package com.example.northsea.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.example.northsea.viewmodel.HudScreen
import com.example.ui.theme.*

@Composable
fun HudNavigationBar(
  currentScreen: HudScreen,
  onScreenSelect: (HudScreen) -> Unit,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .background(HudSurfaceElevated)
      .border(1.dp, HudSurfaceBorder)
      .horizontalScroll(rememberScrollState())
      .padding(horizontal = 8.dp, vertical = 4.dp),
    horizontalArrangement = Arrangement.spacedBy(4.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    HudScreen.values().forEach { screen ->
      val isSelected = currentScreen == screen
      val icon = getScreenIcon(screen)

      Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected) HudSurface else Color.Transparent,
        border = androidx.compose.foundation.BorderStroke(
          1.dp,
          if (isSelected) GasCyan.copy(alpha = 0.6f) else Color.Transparent
        ),
        modifier = Modifier.clickable { onScreenSelect(screen) }
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Icon(
            imageVector = icon,
            contentDescription = screen.title,
            tint = if (isSelected) GasCyan else TextTertiary,
            modifier = Modifier.size(14.dp)
          )
          Text(
            text = screen.title.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            color = if (isSelected) TextPrimary else TextSecondary
          )
        }
      }
    }
  }
}

private fun getScreenIcon(screen: HudScreen): ImageVector {
  return when (screen) {
    HudScreen.MASTER_OPERATIONS -> Icons.Default.Dashboard
    HudScreen.NORTH_SEA_MAP -> Icons.Default.Map
    HudScreen.PROCESS_DIAGRAM -> Icons.Default.AccountTree
    HudScreen.OFFSHORE_PLATFORM -> Icons.Default.Sensors
    HudScreen.WELL_OPERATIONS -> Icons.Default.VerticalAlignBottom
    HudScreen.GAS_COMPRESSION -> Icons.Default.Speed
    HudScreen.PIPELINE_NETWORK -> Icons.Default.Timeline
    HudScreen.POWER_AND_WIND -> Icons.Default.Bolt
    HudScreen.ECONOMIC_TRADING -> Icons.Default.TrendingUp
    HudScreen.PRODUCTION_FORECAST -> Icons.Default.QueryStats
    HudScreen.PREDICTIVE_MAINTENANCE -> Icons.Default.Build
    HudScreen.ALARMS_AND_SAFETY -> Icons.Default.Warning
    HudScreen.ENVIRONMENTAL_HUD -> Icons.Default.Eco
    HudScreen.SCENARIO_SIMULATION -> Icons.Default.Science
    HudScreen.EXECUTIVE_OVERVIEW -> Icons.Default.Assessment
    HudScreen.SECURITY_AUDIT -> Icons.Default.Lock
  }
}
