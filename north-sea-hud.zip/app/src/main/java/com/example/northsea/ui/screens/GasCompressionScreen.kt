package com.example.northsea.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.northsea.models.CompressorTrain
import com.example.northsea.models.OperationalStatus
import com.example.northsea.ui.components.*
import com.example.northsea.viewmodel.NorthSeaHudViewModel
import com.example.ui.theme.*

@Composable
fun GasCompressionScreen(
  viewModel: NorthSeaHudViewModel,
  modifier: Modifier = Modifier
) {
  val compressors = viewModel.compressors.value
  var selectedTrain by remember { mutableStateOf(compressors.first()) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(HudBackground)
      .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Train Selector Strip
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        compressors.forEach { comp ->
          val isSelected = comp.id == selectedTrain.id
          Surface(
            shape = RoundedCornerShape(2.dp),
            color = if (isSelected) GasCyan.copy(alpha = 0.2f) else HudSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) GasCyan else HudSurfaceBorder),
            modifier = Modifier.clickable { selectedTrain = comp }
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Box(modifier = Modifier.size(6.dp).background(StatusNormal, RoundedCornerShape(2.dp)))
              Text(comp.name.uppercase(), style = MaterialTheme.typography.labelSmall, color = if (isSelected) TextPrimary else TextSecondary)
            }
          }
        }
      }
    }

    // Selected Compressor Header Card
    item {
      HudCard(
        title = "COMPRESSOR: ${selectedTrain.name.uppercase()}",
        tag = "${selectedTrain.platformOrFacility} • ${selectedTrain.stage}",
        status = selectedTrain.status
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          MetricKpiCell("Suction Pressure", "${String.format("%.1f", selectedTrain.suctionPressureBar)} bar", "", modifier = Modifier.weight(1f))
          MetricKpiCell("Discharge Press", "${String.format("%.1f", selectedTrain.dischargePressureBar)} bar", "", modifier = Modifier.weight(1f))
          MetricKpiCell("Gas Flow Rate", "${String.format("%,.0f", selectedTrain.gasFlowMmscfd)} MMSCFD", "", modifier = Modifier.weight(1f))
          MetricKpiCell("Rotor Speed", "${String.format("%,.0f", selectedTrain.rpm)} RPM", "", modifier = Modifier.weight(1f))
        }
      }
    }

    // Large Circular SCADA Gauges Row
    item {
      HudCard(
        title = "REAL-TIME SCADA GAUGE MATRIX",
        tag = "CENTRIFUGAL-DYNAMICS",
        status = OperationalStatus.NORMAL
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceEvenly
        ) {
          CircularEngineeringGauge(
            value = selectedTrain.surgeMarginPercent,
            unit = "%",
            title = "Surge Margin",
            gaugeColor = StatusNormal,
            size = 110.dp
          )
          CircularEngineeringGauge(
            value = selectedTrain.vibrationMmS,
            max = 5.0,
            unit = "mm/s",
            title = "Shaft Vibration",
            gaugeColor = GasCyan,
            warningThreshold = 3.5,
            criticalThreshold = 4.5,
            size = 110.dp
          )
          CircularEngineeringGauge(
            value = selectedTrain.polytropicEfficiencyPercent,
            unit = "%",
            title = "Efficiency",
            gaugeColor = WindCyan,
            size = 110.dp
          )
          CircularEngineeringGauge(
            value = selectedTrain.compressorHealthPercent,
            unit = "%",
            title = "Rotor Health",
            gaugeColor = StatusNormal,
            size = 110.dp
          )
        }
      }
    }

    // Compressor Performance & Thermal Balance
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        HudCard(
          title = "Thermal & Mechanical Load",
          tag = "THERMAL-01",
          status = OperationalStatus.NORMAL,
          modifier = Modifier.weight(1f)
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            LinearEngineeringBar("Turbine Driver Load", selectedTrain.turbineLoadMw, 25.0, "MW", barColor = PowerYellow)
            LinearEngineeringBar("Inlet Temperature", selectedTrain.inletTempC, 100.0, "°C", barColor = GasCyan)
            LinearEngineeringBar("Discharge Temperature", selectedTrain.dischargeTempC, 160.0, "°C", barColor = StatusWarning)
          }
        }

        HudCard(
          title = "Anti-Surge & Seal Diagnostics",
          tag = "ASV-SEAL-02",
          status = OperationalStatus.NORMAL,
          modifier = Modifier.weight(1f)
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            LinearEngineeringBar("Anti-Surge Valve Position", selectedTrain.antiSurgeValvePercent, 100.0, "%", barColor = StatusNormal)
            TelemetryRowItem("Dry Gas Seal N2 Diff", "2.8 bar (NOMINAL)", StatusNormal)
            TelemetryRowItem("Lube Oil Header Press", "3.4 bar (NORMAL)", StatusNormal)
            TelemetryRowItem("Thrust Bearing Temp", "76.4 °C (OPTIMAL)", TextPrimary)
          }
        }
      }
    }
  }
}

@Composable
private fun TelemetryRowItem(label: String, value: String, accent: Color) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    Text(value, style = MaterialTheme.typography.labelSmall, color = accent)
  }
}
