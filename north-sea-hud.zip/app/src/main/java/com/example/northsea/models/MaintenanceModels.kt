package com.example.northsea.models

data class PredictiveMaintenanceAsset(
  val id: String,
  val tag: String,
  val name: String,
  val platform: String,
  val equipmentType: String,
  val assetHealthPercent: Double,
  val failureRiskPercent: Double,
  val efficiencyPercent: Double,
  val nextMaintenanceDays: Int,
  val remainingUsefulLifeHours: Int,
  val anomalyType: String,
  val aiConfidencePercent: Double,
  val recommendation: String,
  val status: OperationalStatus
)
