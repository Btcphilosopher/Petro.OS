package com.example.northsea.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.northsea.models.NodeType
import com.example.northsea.models.OperationalStatus
import com.example.northsea.models.ProcessNode
import com.example.northsea.ui.components.HudCard
import com.example.northsea.ui.components.MetricKpiCell
import com.example.northsea.viewmodel.NorthSeaHudViewModel
import com.example.ui.theme.*

@Composable
fun ProcessDiagramScreen(
  viewModel: NorthSeaHudViewModel,
  modifier: Modifier = Modifier
) {
  val processNodes = viewModel.processNodes.value
  var selectedNode by remember { mutableStateOf<ProcessNode?>(null) }

  // Animated flow pulse phase
  val infiniteTransition = rememberInfiniteTransition(label = "FlowPhase")
  val phase by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(2000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "ParticlePhase"
  )

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(HudBackground)
      .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    // Header strip for Process Diagram
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = "NORTH SEA ALPHA • SCADA PROCESS FLOW DIAGRAM (P&ID)",
          style = MaterialTheme.typography.titleMedium,
          color = TextPrimary
        )
        Text(
          text = "WELLS → MULTIPHASE SEPARATION → GAS COMPRESSION & OIL STABILISATION → EXPORT",
          style = MaterialTheme.typography.labelSmall,
          color = TextSecondary
        )
      }

      Surface(
        shape = RoundedCornerShape(2.dp),
        color = StatusNormal.copy(alpha = 0.15f),
        border = androidx.compose.foundation.BorderStroke(1.dp, StatusNormal)
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Box(modifier = Modifier.size(6.dp).background(StatusNormal, RoundedCornerShape(2.dp)))
          Text("LIVE TELEMETRY STREAMING", style = MaterialTheme.typography.labelSmall, color = StatusNormal)
        }
      }
    }

    // Process Canvas / Visual Diagram
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(300.dp)
        .background(HudSurface)
        .border(1.dp, HudSurfaceBorder, RoundedCornerShape(4.dp))
    ) {
      Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        fun toPx(node: ProcessNode): Offset {
          return Offset(node.xRel * w, node.yRel * h)
        }

        // Draw connections with animated flow pulses
        val wellNode = processNodes.find { it.type == NodeType.WELLS_CLUSTER }
        val manifoldNode = processNodes.find { it.type == NodeType.MANIFOLD }
        val sepNode = processNodes.find { it.type == NodeType.SEPARATION_PRIMARY }
        val gasCompNode = processNodes.find { it.type == NodeType.GAS_COMPRESSION }
        val oilTreatNode = processNodes.find { it.type == NodeType.OIL_TREATMENT }
        val waterInjNode = processNodes.find { it.type == NodeType.WATER_INJECTION_PUMP }
        val gasExpNode = processNodes.find { it.type == NodeType.SUBSEA_PIPELINE && it.id == "NODE-GAS-EXP" }
        val oilExpNode = processNodes.find { it.type == NodeType.SUBSEA_PIPELINE && it.id == "NODE-OIL-EXP" }
        val termNode = processNodes.find { it.type == NodeType.TERMINAL_RECEPTION }

        fun drawFlowLine(from: Offset, to: Offset, color: Color, flowWidth: Float = 3f) {
          drawLine(
            color = color.copy(alpha = 0.3f),
            start = from,
            end = to,
            strokeWidth = flowWidth.dp.toPx(),
            cap = StrokeCap.Round
          )
          // Animated particle pulse along line
          val pX = from.x + (to.x - from.x) * phase
          val pY = from.y + (to.y - from.y) * phase
          drawCircle(
            color = color,
            radius = 3.dp.toPx(),
            center = Offset(pX, pY)
          )
        }

        if (wellNode != null && manifoldNode != null) drawFlowLine(toPx(wellNode), toPx(manifoldNode), StatusAdvisory)
        if (manifoldNode != null && sepNode != null) drawFlowLine(toPx(manifoldNode), toPx(sepNode), StatusAdvisory)

        // Split to Gas, Oil, Water
        if (sepNode != null && gasCompNode != null) drawFlowLine(toPx(sepNode), toPx(gasCompNode), GasCyan)
        if (sepNode != null && oilTreatNode != null) drawFlowLine(toPx(sepNode), toPx(oilTreatNode), PetroleumGold)
        if (sepNode != null && waterInjNode != null) drawFlowLine(toPx(sepNode), toPx(waterInjNode), WaterBlue)

        // From Treatment to Export
        if (gasCompNode != null && gasExpNode != null) drawFlowLine(toPx(gasCompNode), toPx(gasExpNode), GasCyan)
        if (oilTreatNode != null && oilExpNode != null) drawFlowLine(toPx(oilTreatNode), toPx(oilExpNode), PetroleumGold)

        // From Export to Terminal
        if (gasExpNode != null && termNode != null) drawFlowLine(toPx(gasExpNode), toPx(termNode), GasCyan)
        if (oilExpNode != null && termNode != null) drawFlowLine(toPx(oilExpNode), toPx(termNode), PetroleumGold)
      }

      // Render interactive node buttons on top of canvas
      processNodes.forEach { node ->
        Box(
          modifier = Modifier
            .fillMaxSize()
            .padding(
              start = ((node.xRel * 100).toInt()).dp,
              top = ((node.yRel * 100).toInt()).dp
            )
        )
      }

      // Render Node Chips
      Row(
        modifier = Modifier
          .fillMaxSize()
          .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        processNodes.take(5).forEach { node ->
          ProcessNodeChip(
            node = node,
            isSelected = selectedNode?.id == node.id,
            onClick = { selectedNode = node }
          )
        }
      }
    }

    // Detailed Inspection Card for selected node or default
    val inspected = selectedNode ?: processNodes.first()
    HudCard(
      title = "NODE TELEMETRY: ${inspected.title}",
      tag = inspected.id,
      status = inspected.status
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        MetricKpiCell("Operating Pressure", String.format("%.1f", inspected.pressureBar), "bar", modifier = Modifier.weight(1f))
        MetricKpiCell("Process Temperature", String.format("%.1f", inspected.temperatureC), "°C", modifier = Modifier.weight(1f))
        MetricKpiCell("Current Flow", String.format("%,.0f", inspected.flowRate), inspected.flowUnit, modifier = Modifier.weight(1f))
        MetricKpiCell("Integrity Status", "NOMINAL (100%)", "", status = OperationalStatus.NORMAL, modifier = Modifier.weight(1f))
      }

      Spacer(modifier = Modifier.height(10.dp))
      Text(
        text = "Process Details: ${inspected.subtitle}. Pressure transmitter and dual turbine meters reporting good quality SCADA signal.",
        style = MaterialTheme.typography.bodySmall,
        color = TextSecondary
      )
    }

    // Process Units Grid
    LazyColumn(
      modifier = Modifier.fillMaxWidth().weight(1f),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      items(processNodes) { node ->
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = if (selectedNode?.id == node.id) HudSurfaceHover else HudSurface,
          border = androidx.compose.foundation.BorderStroke(1.dp, if (selectedNode?.id == node.id) GasCyan else HudSurfaceBorder),
          modifier = Modifier
            .fillMaxWidth()
            .clickable { selectedNode = node }
        ) {
          Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1.5f)) {
              Text(node.title, style = MaterialTheme.typography.titleSmall, color = TextPrimary)
              Text(node.subtitle, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
            Row(
              modifier = Modifier.weight(2f),
              horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
              Text("${String.format("%.1f", node.pressureBar)} bar", style = MaterialTheme.typography.labelMedium, color = GasCyan)
              Text("${String.format("%.1f", node.temperatureC)} °C", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
              Text("${String.format("%,.0f", node.flowRate)} ${node.flowUnit}", style = MaterialTheme.typography.labelMedium, color = PetroleumGold)
            }
          }
        }
      }
    }
  }
}

@Composable
private fun ProcessNodeChip(
  node: ProcessNode,
  isSelected: Boolean,
  onClick: () -> Unit
) {
  Surface(
    shape = RoundedCornerShape(6.dp),
    color = if (isSelected) GasCyan.copy(alpha = 0.2f) else HudSurfaceElevated.copy(alpha = 0.9f),
    border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) GasCyan else HudSurfaceBorder),
    modifier = Modifier.clickable { onClick() }
  ) {
    Column(modifier = Modifier.padding(6.dp)) {
      Text(node.title.take(12), style = MaterialTheme.typography.labelSmall, color = TextPrimary)
      Text("${node.pressureBar.toInt()} bar", style = MaterialTheme.typography.labelSmall, color = GasCyan)
    }
  }
}
