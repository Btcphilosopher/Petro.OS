package com.example.northsea.data

import com.example.northsea.models.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.sin
import kotlin.random.Random

class TelemetryEngine(private val scope: CoroutineScope) {

  private val _masterKpi = MutableStateFlow(createInitialKpi())
  val masterKpi: StateFlow<MasterKpiSummary> = _masterKpi.asStateFlow()

  private val _platforms = MutableStateFlow(NorthSeaDataProvider.platforms)
  val platforms: StateFlow<List<PlatformAsset>> = _platforms.asStateFlow()

  private val _pipelines = MutableStateFlow(NorthSeaDataProvider.pipelines)
  val pipelines: StateFlow<List<PipelineAsset>> = _pipelines.asStateFlow()

  private val _terminals = MutableStateFlow(NorthSeaDataProvider.terminals)
  val terminals: StateFlow<List<TerminalAsset>> = _terminals.asStateFlow()

  private val _windFarms = MutableStateFlow(NorthSeaDataProvider.windFarms)
  val windFarms: StateFlow<List<WindFarmAsset>> = _windFarms.asStateFlow()

  private val _wells = MutableStateFlow(NorthSeaDataProvider.wells)
  val wells: StateFlow<List<WellAsset>> = _wells.asStateFlow()

  private val _compressors = MutableStateFlow(NorthSeaDataProvider.compressorTrains)
  val compressors: StateFlow<List<CompressorTrain>> = _compressors.asStateFlow()

  private val _processNodes = MutableStateFlow(NorthSeaDataProvider.processNodes)
  val processNodes: StateFlow<List<ProcessNode>> = _processNodes.asStateFlow()

  private val _marketCommodities = MutableStateFlow(NorthSeaDataProvider.marketCommodities)
  val marketCommodities: StateFlow<List<MarketCommodity>> = _marketCommodities.asStateFlow()

  private val _economicSummary = MutableStateFlow(createInitialEconomics())
  val economicSummary: StateFlow<EconomicSummary> = _economicSummary.asStateFlow()

  private val _alarms = MutableStateFlow(NorthSeaDataProvider.initialAlarms)
  val alarms: StateFlow<List<AlarmItem>> = _alarms.asStateFlow()

  private val _maintenanceAssets = MutableStateFlow(NorthSeaDataProvider.predictiveMaintenance)
  val maintenanceAssets: StateFlow<List<PredictiveMaintenanceAsset>> = _maintenanceAssets.asStateFlow()

  private val _activeScenario = MutableStateFlow(NorthSeaDataProvider.scenarios.first())
  val activeScenario: StateFlow<SimulationScenario> = _activeScenario.asStateFlow()

  private val _safetyOverlay = MutableStateFlow(createInitialSafety())
  val safetyOverlay: StateFlow<SafetyOverlayData> = _safetyOverlay.asStateFlow()

  private val _environmental = MutableStateFlow(createInitialEnvironmental())
  val environmental: StateFlow<EnvironmentalTelemetry> = _environmental.asStateFlow()

  private val _currentUserRole = MutableStateFlow(UserRole.CONTROL_ROOM_SUPERVISOR)
  val currentUserRole: StateFlow<UserRole> = _currentUserRole.asStateFlow()

  private val _auditLogs = MutableStateFlow(createInitialAuditLogs())
  val auditLogs: StateFlow<List<AuditLogEntry>> = _auditLogs.asStateFlow()

  private val _selectedPlatformId = MutableStateFlow("NS-ALPHA")
  val selectedPlatformId: StateFlow<String> = _selectedPlatformId.asStateFlow()

  private val _liveGridFrequencyHz = MutableStateFlow(50.00)
  val liveGridFrequencyHz: StateFlow<Double> = _liveGridFrequencyHz.asStateFlow()

  private var tickCount = 0L

  init {
    startTelemetryLoop()
  }

  private fun startTelemetryLoop() {
    scope.launch(Dispatchers.Default) {
      while (true) {
        delay(1000)
        tickCount++
        updateOscillatingTelemetry()
      }
    }
  }

  private fun updateOscillatingTelemetry() {
    val oscillation = sin(tickCount * 0.1) * 0.015 // ±1.5% wave
    val freqNoise = (Random.nextDouble(-0.04, 0.04))
    _liveGridFrequencyHz.value = 50.00 + (sin(tickCount * 0.2) * 0.03) + freqNoise

    val scenario = _activeScenario.value

    // Update platforms with realistic small variations + scenario delta
    val updatedPlatforms = _platforms.value.map { platform ->
      val noise = (Random.nextDouble(-0.008, 0.008))
      val oil = (platform.oilBopd * (1.0 + oscillation + noise) + (scenario.oilProductionDeltaBopd / 6)).coerceAtLeast(0.0)
      val gas = (platform.gasMmscfd * (1.0 + oscillation + noise) + (scenario.gasProductionDeltaMmscfd / 6)).coerceAtLeast(0.0)
      val power = (platform.powerLoadMw * (1.0 + noise) + (scenario.powerDeltaMw / 6)).coerceAtLeast(0.0)

      platform.copy(
        oilBopd = (oil * 10).toInt() / 10.0,
        gasMmscfd = (gas * 10).toInt() / 10.0,
        powerLoadMw = (power * 10).toInt() / 10.0
      )
    }
    _platforms.value = updatedPlatforms

    // Calculate Master KPI
    val totalOil = updatedPlatforms.sumOf { it.oilBopd } + 215000.0 // + Other 12 non-detailed platforms
    val totalGas = updatedPlatforms.sumOf { it.gasMmscfd } + 920.0
    val totalPower = updatedPlatforms.sumOf { it.powerLoadMw } + _windFarms.value.sumOf { it.currentOutputMw }
    val gasExport = totalGas * 0.94
    val gridPower = _windFarms.value.sumOf { it.gridExportMw }
    val flaring = (0.65 + sin(tickCount * 0.05) * 0.1).coerceIn(0.2, 3.0)
    val uptime = if (scenario.id == "SCEN-STORM") 94.2 else 99.4

    val unackAlarmsCount = _alarms.value.count { !it.isAcknowledged }
    val safetyStatus = if (scenario.id == "SCEN-STORM") OperationalStatus.WARNING else if (unackAlarmsCount > 3) OperationalStatus.WARNING else OperationalStatus.NORMAL

    val dailyRev = (totalOil * 82.45 * 0.78 / 1_000_000) + (totalGas * 1000 * 0.942 * 0.01 / 1_000_000) + 12.5

    _masterKpi.value = MasterKpiSummary(
      totalOilProductionBopd = (totalOil).toInt().toDouble(),
      totalGasProductionMmscfd = (totalGas * 10).toInt() / 10.0,
      totalPowerMw = (totalPower * 10).toInt() / 10.0,
      gasExportMmscfd = (gasExport * 10).toInt() / 10.0,
      gridPowerMw = (gridPower * 10).toInt() / 10.0,
      flaringPercentage = (flaring * 100).toInt() / 100.0,
      uptimePercentage = uptime,
      safetyStatus = safetyStatus,
      activeAlertCount = unackAlarmsCount,
      dailyRevenueGbp = (dailyRev * 10).toInt() / 10.0,
      carbonIntensityKgBoe = if (scenario.id == "SCEN-WIND-SURPLUS") 8.4 else 12.8
    )

    // Update process diagram nodes
    val updatedNodes = _processNodes.value.map { node ->
      val nodeOsc = sin(tickCount * 0.15) * 0.5
      when (node.type) {
        NodeType.WELLS_CLUSTER -> node.copy(pressureBar = 165.0 + nodeOsc, flowRate = (totalOil / 4.4))
        NodeType.GAS_COMPRESSION -> node.copy(pressureBar = 148.0 + nodeOsc * 0.8, flowRate = (totalGas / 3.8))
        NodeType.OIL_TREATMENT -> node.copy(flowRate = (totalOil / 5.2))
        NodeType.SUBSEA_PIPELINE -> node.copy(pressureBar = 112.5 + nodeOsc * 0.4)
        else -> node
      }
    }
    _processNodes.value = updatedNodes
  }

  fun selectPlatform(platformId: String) {
    _selectedPlatformId.value = platformId
    logAction("ASSET_SELECTION", platformId, "Operator viewed platform details")
  }

  fun switchUserRole(newRole: UserRole) {
    val previous = _currentUserRole.value
    _currentUserRole.value = newRole
    logAction("ROLE_SWITCH", "AUTH_SYSTEM", "Role elevated/switched from ${previous.roleName} to ${newRole.roleName}")
  }

  fun acknowledgeAlarm(alarmId: String) {
    val currentRole = _currentUserRole.value
    val updatedList = _alarms.value.map { alarm ->
      if (alarm.id == alarmId) {
        alarm.copy(
          isAcknowledged = true,
          acknowledgedBy = "${currentRole.roleName} (ID-6842)"
        )
      } else alarm
    }
    _alarms.value = updatedList
    logAction("ALARM_ACKNOWLEDGE", alarmId, "Alarm acknowledged by ${currentRole.roleName}")
  }

  fun shelveAlarm(alarmId: String, durationMinutes: Int = 60) {
    val currentRole = _currentUserRole.value
    val updatedList = _alarms.value.map { alarm ->
      if (alarm.id == alarmId) {
        alarm.copy(isShelved = true)
      } else alarm
    }
    _alarms.value = updatedList
    logAction("ALARM_SHELVE", alarmId, "Alarm shelved for ${durationMinutes}m by ${currentRole.roleName}")
  }

  fun adjustWellChoke(wellId: String, newChokePercent: Double) {
    val currentRole = _currentUserRole.value
    val updatedWells = _wells.value.map { well ->
      if (well.id == wellId) {
        val flowMultiplier = (newChokePercent / 100.0) * 1.15
        well.copy(
          chokePercent = newChokePercent,
          oilFlowBopd = if (newChokePercent > 0) (8200.0 * flowMultiplier).coerceAtLeast(0.0) else 0.0,
          status = if (newChokePercent <= 0.0) WellStatus.SHUT_IN else WellStatus.PRODUCING
        )
      } else well
    }
    _wells.value = updatedWells
    logAction("WELL_CHOKE_ADJUST", wellId, "Well choke adjusted to $newChokePercent% by ${currentRole.roleName}")
  }

  fun activateScenario(scenario: SimulationScenario) {
    _activeScenario.value = scenario
    logAction("SCENARIO_EXECUTE", scenario.id, "Simulation scenario loaded: ${scenario.title}")
  }

  fun logAction(actionType: String, targetAsset: String, details: String) {
    val timeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.UK).apply {
      timeZone = TimeZone.getTimeZone("UTC")
    }
    val now = System.currentTimeMillis()
    val hash = Integer.toHexString((now.toString() + actionType + targetAsset).hashCode()).uppercase().takeLast(8)

    val entry = AuditLogEntry(
      id = "AUD-${Random.nextInt(10000, 99999)}",
      timestamp = now,
      formattedTime = timeFormat.format(Date(now)),
      userRole = _currentUserRole.value,
      operatorName = "OP-${_currentUserRole.value.name.take(3)}-094",
      actionType = actionType,
      targetAsset = targetAsset,
      details = details,
      verificationHash = "0x$hash"
    )

    _auditLogs.value = listOf(entry) + _auditLogs.value.take(49)
  }

  private fun createInitialKpi() = MasterKpiSummary(
    totalOilProductionBopd = 443700.0,
    totalGasProductionMmscfd = 1650.0,
    totalPowerMw = 6420.0,
    gasExportMmscfd = 1580.0,
    gridPowerMw = 5560.0,
    flaringPercentage = 0.68,
    uptimePercentage = 99.4,
    safetyStatus = OperationalStatus.NORMAL,
    activeAlertCount = 2,
    dailyRevenueGbp = 48.6,
    carbonIntensityKgBoe = 12.8
  )

  private fun createInitialEconomics() = EconomicSummary(
    brentCrudeUsd = 82.45,
    ukNaturalGasPenceTherm = 94.20,
    ukPowerGbpMwh = 78.50,
    ukEtsCarbonGbpTonne = 44.80,
    dailyOilRevenueGbp = 28.5,
    dailyGasRevenueGbp = 15.6,
    dailyPowerRevenueGbp = 4.5,
    totalDailyRevenueGbp = 48.6,
    dailyOpexGbp = 8.2,
    dailyTransportationCostGbp = 2.4,
    estimatedNetOperatingMarginGbp = 38.0,
    marginPercent = 78.2
  )

  private fun createInitialSafety() = SafetyOverlayData(
    overallSafetyStatus = OperationalStatus.NORMAL,
    sisEsdArmed = true,
    fireAndGasZoneStatus = "ALL ZONES NOMINAL / 100% COVERAGE",
    lifeboatReadinessPercent = 100,
    totalLifeboats = 12,
    availableLifeboats = 12,
    helideckStatus = "OPEN (GREEN)",
    nextHelicopterEtaMin = 22,
    helicopterMission = "CREW CHANGE (ABERDEEN DYCE → ALPHA)",
    standbyVesselOnStation = true,
    metocean = NorthSeaDataProvider.metocean,
    marineVessels = NorthSeaDataProvider.marineTraffic
  )

  private fun createInitialEnvironmental() = EnvironmentalTelemetry(
    co2EmissionsTodayTonnes = 4850.0,
    co2IntensityKgBoe = 12.8,
    targetCo2IntensityKgBoe = 10.0,
    methaneSlipRatePercent = 0.08,
    methaneConcentrationPpm = 1.2,
    flaringRateMmscfd = 11.2,
    flaringPercentOfProduction = 0.68,
    ventingRateMmscfd = 0.4,
    producedWaterDischargeBpd = 17400.0,
    oilInWaterContentPpm = 14.5,
    maxPermissibleOiwPpm = 30.0,
    waterReinjectionPercent = 94.2,
    platformElectrificationPercent = 38.5,
    renewablePowerSharePercent = 64.2,
    emissionsAvoidedWindTonneDay = 6200.0
  )

  private fun createInitialAuditLogs(): List<AuditLogEntry> {
    val timeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.UK).apply {
      timeZone = TimeZone.getTimeZone("UTC")
    }
    val now = System.currentTimeMillis()

    return listOf(
      AuditLogEntry(
        id = "AUD-10024",
        timestamp = now - 120000L,
        formattedTime = timeFormat.format(Date(now - 120000L)),
        userRole = UserRole.CONTROL_ROOM_SUPERVISOR,
        operatorName = "OP-SUP-094",
        actionType = "SYSTEM_INITIALIZE",
        targetAsset = "NORTH_SEA_CORE_GRID",
        details = "Telemetry ingestion stream established across 18 platform PLC nodes.",
        verificationHash = "0x89C4FA12"
      ),
      AuditLogEntry(
        id = "AUD-10023",
        timestamp = now - 650000L,
        formattedTime = timeFormat.format(Date(now - 650000L)),
        userRole = UserRole.ENGINEER,
        operatorName = "OP-ENG-112",
        actionType = "CHOKE_OPTIMIZATION",
        targetAsset = "W-21/10-P02",
        details = "Gas lift injection tuned to 38 MMSCFD for maximum reservoir drawdown.",
        verificationHash = "0x3F77B09A"
      ),
      AuditLogEntry(
        id = "AUD-10022",
        timestamp = now - 1800000L,
        formattedTime = timeFormat.format(Date(now - 1800000L)),
        userRole = UserRole.OPERATOR,
        operatorName = "OP-OPS-044",
        actionType = "ALARM_ACKNOWLEDGE",
        targetAsset = "VA-K101B",
        details = "Acknowledged transient bearing vibration advisory.",
        verificationHash = "0x11B56C2D"
      )
    )
  }
}
