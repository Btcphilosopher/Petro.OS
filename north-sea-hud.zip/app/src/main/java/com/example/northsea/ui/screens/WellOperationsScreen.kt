package com.example.northsea.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.northsea.models.OperationalStatus
import com.example.northsea.models.WellAsset
import com.example.northsea.models.WellStatus
import com.example.northsea.ui.components.HudCard
import com.example.northsea.ui.components.LinearEngineeringBar
import com.example.northsea.ui.components.MetricKpiCell
import com.example.northsea.viewmodel.NorthSeaHudViewModel
import com.example.ui.theme.*

@Composable
fun WellOperationsScreen(
  viewModel: NorthSeaHudViewModel,
  modifier: Modifier = Modifier
) {
  val wells = viewModel.wells.value
  var selectedWell by remember { mutableStateOf<WellAsset?>(null) }
  var showChokeDialog by remember { mutableStateOf(false) }
  var pendingChokeValue by remember { mutableStateOf(50f) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(HudBackground)
      .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Field-level Well Fleet Status KPIs
    item {
      HudCard(
        title = "NORTH SEA WELL MANAGEMENT & ARTIFICIAL LIFT (387 WELLS)",
        tag = "WELL-OPS-MASTER",
        status = OperationalStatus.NORMAL
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          MetricKpiCell("Producing Wells", "364", "", status = OperationalStatus.NORMAL, modifier = Modifier.weight(1f))
          MetricKpiCell("Shut-In Wells", "12", "", status = OperationalStatus.ADVISORY, modifier = Modifier.weight(1f))
          MetricKpiCell("Maintenance", "8", "", status = OperationalStatus.MAINTENANCE, modifier = Modifier.weight(1f))
          MetricKpiCell("Optimisation Req", "3", "", status = OperationalStatus.WARNING, modifier = Modifier.weight(1f))
        }
      }
    }

    // Detailed Well Cards List
    items(wells) { well ->
      WellCard(
        well = well,
        isSelected = selectedWell?.id == well.id,
        onInspect = { selectedWell = well },
        onChokeClick = {
          selectedWell = well
          pendingChokeValue = well.chokePercent.toFloat()
          showChokeDialog = true
        }
      )
    }
  }

  // Choke Position Adjustment Dialog
  if (showChokeDialog && selectedWell != null) {
    val well = selectedWell!!
    AlertDialog(
      onDismissRequest = { showChokeDialog = false },
      title = {
        Text("ADJUST CHOKE: ${well.name}", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Text(
            "Current Choke: ${well.chokePercent.toInt()}% • Flowing Pressure: ${well.flowingTubingPressurePsi.toInt()} PSI",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
          )

          Text("New Choke Position: ${pendingChokeValue.toInt()}%", style = MaterialTheme.typography.titleSmall, color = GasCyan)

          Slider(
            value = pendingChokeValue,
            onValueChange = { pendingChokeValue = it },
            valueRange = 0f..100f,
            steps = 100,
            colors = SliderDefaults.colors(thumbColor = GasCyan, activeTrackColor = GasCyan)
          )

          Text(
            "Action will be signed and logged to cryptographic security audit ledger.",
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.adjustWellChoke(well.id, pendingChokeValue.toDouble())
            showChokeDialog = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = GasCyan),
          shape = RoundedCornerShape(2.dp)
        ) {
          Text("APPLY SETPOINT", color = HudBackground, style = MaterialTheme.typography.labelSmall)
        }
      },
      dismissButton = {
        TextButton(onClick = { showChokeDialog = false }) {
          Text("CANCEL", color = TextSecondary)
        }
      },
      containerColor = HudSurface,
      shape = RoundedCornerShape(4.dp)
    )
  }
}

@Composable
private fun WellCard(
  well: WellAsset,
  isSelected: Boolean,
  onInspect: () -> Unit,
  onChokeClick: () -> Unit
) {
  val statusColor = when (well.status) {
    WellStatus.PRODUCING -> StatusNormal
    WellStatus.SHUT_IN -> StatusOffline
    WellStatus.MAINTENANCE -> PetroleumGold
    WellStatus.DEPLETED -> TextMuted
    WellStatus.OPTIMISATION_REQUIRED -> StatusWarning
  }

  Surface(
    shape = RoundedCornerShape(4.dp),
    color = if (isSelected) HudSurfaceHover else HudSurface,
    border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) GasCyan else HudSurfaceBorder),
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onInspect() }
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(modifier = Modifier.size(8.dp).background(statusColor, RoundedCornerShape(2.dp)))
          Text(well.name.uppercase(), style = MaterialTheme.typography.titleSmall, color = TextPrimary)
          Text("[${well.id}]", style = MaterialTheme.typography.labelSmall, color = GasCyan)
        }

        Surface(
          shape = RoundedCornerShape(2.dp),
          color = statusColor.copy(alpha = 0.15f),
          border = androidx.compose.foundation.BorderStroke(1.dp, statusColor)
        ) {
          Text(
            text = well.status.name,
            style = MaterialTheme.typography.labelSmall,
            color = statusColor,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        MetricKpiCell("Oil Flow", "${String.format("%,.0f", well.oilFlowBopd)} BOPD", modifier = Modifier.weight(1f))
        MetricKpiCell("Gas Flow", "${String.format("%,.1f", well.gasFlowMmscfd)} MMSCFD", modifier = Modifier.weight(1f))
        MetricKpiCell("Water Cut", "${String.format("%.1f", well.waterCutPercent)}%", modifier = Modifier.weight(1f))
        MetricKpiCell("Tubing Press", "${well.flowingTubingPressurePsi.toInt()} PSI", modifier = Modifier.weight(1f))
      }

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "LIFT: ${well.artificialLiftType.uppercase()} • HEALTH ${well.healthScorePercent.toInt()}%",
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary
          )
          Text(
            text = "STATUS: ${well.optimizationStatus}",
            style = MaterialTheme.typography.labelSmall,
            color = if (well.status == WellStatus.OPTIMISATION_REQUIRED) StatusWarning else TextMuted
          )
        }

        Button(
          onClick = onChokeClick,
          colors = ButtonDefaults.buttonColors(containerColor = HudSurfaceElevated),
          border = androidx.compose.foundation.BorderStroke(1.dp, GasCyan),
          shape = RoundedCornerShape(2.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
        ) {
          Text("CHOKE: ${well.chokePercent.toInt()}%", style = MaterialTheme.typography.labelSmall, color = GasCyan)
        }
      }
    }
  }
}
