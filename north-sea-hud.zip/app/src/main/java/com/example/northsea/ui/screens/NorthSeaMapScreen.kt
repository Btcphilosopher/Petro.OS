package com.example.northsea.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.example.northsea.models.GeoCoordinate
import com.example.northsea.models.OperationalStatus
import com.example.northsea.models.PlatformAsset
import com.example.northsea.ui.components.HudCard
import com.example.northsea.ui.components.MetricKpiCell
import com.example.northsea.viewmodel.HudScreen
import com.example.northsea.viewmodel.MapZoomLevel
import com.example.northsea.viewmodel.NorthSeaHudViewModel
import com.example.ui.theme.*
import kotlin.math.hypot

@Composable
fun NorthSeaMapScreen(
  viewModel: NorthSeaHudViewModel,
  modifier: Modifier = Modifier
) {
  val platforms = viewModel.platforms.value
  val pipelines = viewModel.pipelines.value
  val terminals = viewModel.terminals.value
  val windFarms = viewModel.windFarms.value
  val safetyOverlay = viewModel.safetyOverlay.value
  val currentZoom = viewModel.mapZoomLevel.value
  val filterPlatforms = viewModel.mapFilterPlatforms.value
  val filterPipelines = viewModel.mapFilterPipelines.value
  val filterTerminals = viewModel.mapFilterTerminals.value
  val filterWind = viewModel.mapFilterWind.value
  val filterMarine = viewModel.mapFilterMarineTraffic.value

  var selectedPlatformForModal by remember { mutableStateOf<PlatformAsset?>(null) }

  // Map coordinate bounds: Latitude 52.0 to 62.0 (South to North), Longitude -4.0 to 4.0 (West to East)
  val minLat = 52.0
  val maxLat = 62.0
  val minLon = -4.0
  val maxLon = 4.0

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(HudBackground)
  ) {
    // Map Canvas
    Canvas(
      modifier = Modifier
        .fillMaxSize()
        .pointerInput(platforms, filterPlatforms) {
          detectTapGestures { tapOffset ->
            if (!filterPlatforms) return@detectTapGestures
            val width = size.width
            val height = size.height

            // Find closest platform
            var closest: PlatformAsset? = null
            var minDistance = Float.MAX_VALUE

            platforms.forEach { platform ->
              val normX = ((platform.coordinates.longitude - minLon) / (maxLon - minLon)).toFloat()
              val normY = (1f - ((platform.coordinates.latitude - minLat) / (maxLat - minLat))).toFloat()

              val screenX = normX * width
              val screenY = normY * height

              val dist = hypot((tapOffset.x - screenX).toDouble(), (tapOffset.y - screenY).toDouble()).toFloat()
              if (dist < 40.dp.toPx() && dist < minDistance) {
                minDistance = dist
                closest = platform
              }
            }

            if (closest != null) {
              selectedPlatformForModal = closest
            }
          }
        }
    ) {
      val canvasWidth = size.width
      val canvasHeight = size.height

      // Function to project geo coordinates to canvas XY
      fun project(coord: GeoCoordinate): Offset {
        val normX = ((coord.longitude - minLon) / (maxLon - minLon)).toFloat()
        val normY = (1f - ((coord.latitude - minLat) / (maxLat - minLat))).toFloat()
        return Offset(normX * canvasWidth, normY * canvasHeight)
      }

      // Draw Bathymetry / Grid Lines
      for (lat in 52..62 step 2) {
        val y = (1f - ((lat - minLat) / (maxLat - minLat))).toFloat() * canvasHeight
        drawLine(
          color = SeaMedium,
          start = Offset(0f, y),
          end = Offset(canvasWidth, y),
          strokeWidth = 1.dp.toPx()
        )
      }

      for (lon in -4..4 step 2) {
        val x = ((lon - minLon) / (maxLon - minLon)).toFloat() * canvasWidth
        drawLine(
          color = SeaMedium,
          start = Offset(x, 0f),
          end = Offset(x, canvasHeight),
          strokeWidth = 1.dp.toPx()
        )
      }

      // Draw Shoreline approximation (UK Coastline on West)
      val ukCoast = Path().apply {
        moveTo(project(GeoCoordinate(51.5, 0.5)).x, project(GeoCoordinate(51.5, 0.5)).y)
        lineTo(project(GeoCoordinate(53.0, 0.2)).x, project(GeoCoordinate(53.0, 0.2)).y)
        lineTo(project(GeoCoordinate(54.0, -0.2)).x, project(GeoCoordinate(54.0, -0.2)).y)
        lineTo(project(GeoCoordinate(55.0, -1.5)).x, project(GeoCoordinate(55.0, -1.5)).y)
        lineTo(project(GeoCoordinate(56.5, -2.5)).x, project(GeoCoordinate(56.5, -2.5)).y)
        lineTo(project(GeoCoordinate(57.5, -1.8)).x, project(GeoCoordinate(57.5, -1.8)).y)
        lineTo(project(GeoCoordinate(58.5, -3.0)).x, project(GeoCoordinate(58.5, -3.0)).y)
        lineTo(project(GeoCoordinate(60.0, -1.5)).x, project(GeoCoordinate(60.0, -1.5)).y)
      }
      drawPath(
        path = ukCoast,
        color = Shoreline,
        style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
      )

      // Draw Pipelines
      if (filterPipelines) {
        pipelines.forEach { pipe ->
          if (pipe.routePoints.size >= 2) {
            val path = Path()
            pipe.routePoints.forEachIndexed { index, coord ->
              val pt = project(coord)
              if (index == 0) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y)
            }
            drawPath(
              path = path,
              color = GasCyan.copy(alpha = 0.5f),
              style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
            )
          }
        }
      }

      // Draw Terminals
      if (filterTerminals) {
        terminals.forEach { term ->
          val pos = project(term.coordinates)
          drawRect(
            color = PetroleumGold,
            topLeft = Offset(pos.x - 6.dp.toPx(), pos.y - 6.dp.toPx()),
            size = androidx.compose.ui.geometry.Size(12.dp.toPx(), 12.dp.toPx())
          )
        }
      }

      // Draw Wind Farms
      if (filterWind) {
        windFarms.forEach { wind ->
          val pos = project(wind.coordinates)
          drawCircle(
            color = WindCyan.copy(alpha = 0.3f),
            radius = 16.dp.toPx(),
            center = pos
          )
          drawCircle(
            color = WindCyan,
            radius = 5.dp.toPx(),
            center = pos
          )
        }
      }

      // Draw Marine Traffic
      if (filterMarine) {
        safetyOverlay.marineVessels.forEach { vessel ->
          val refPlatform = platforms.find { it.name == vessel.nearestPlatform } ?: platforms.first()
          val offsetLat = refPlatform.coordinates.latitude + (vessel.distanceNm * 0.015)
          val offsetLon = refPlatform.coordinates.longitude + (vessel.distanceNm * 0.02)
          val pos = project(GeoCoordinate(offsetLat, offsetLon))

          drawCircle(
            color = StatusAdvisory,
            radius = 4.dp.toPx(),
            center = pos
          )
        }
      }

      // Draw Platforms
      if (filterPlatforms) {
        platforms.forEach { platform ->
          val pos = project(platform.coordinates)
          val statusColor = if (platform.status == OperationalStatus.NORMAL) StatusNormal else StatusWarning

          // Platform Outer Glow
          drawCircle(
            color = statusColor.copy(alpha = 0.25f),
            radius = 14.dp.toPx(),
            center = pos
          )
          // Platform Solid Point
          drawCircle(
            color = statusColor,
            radius = 6.dp.toPx(),
            center = pos
          )
        }
      }
    }

    // Top Controls Bar (Zoom selector & Filter toggles)
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Zoom Level Dropdown
        Surface(
          shape = RoundedCornerShape(2.dp),
          color = HudSurface.copy(alpha = 0.9f),
          border = androidx.compose.foundation.BorderStroke(1.dp, HudSurfaceBorder)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Icon(Icons.Default.ZoomIn, contentDescription = null, tint = GasCyan, modifier = Modifier.size(16.dp))
            Text(
              text = "ZOOM: ${currentZoom.label}",
              style = MaterialTheme.typography.labelSmall,
              color = TextPrimary
            )
          }
        }

        // Map Legend
        Surface(
          shape = RoundedCornerShape(2.dp),
          color = HudSurface.copy(alpha = 0.9f),
          border = androidx.compose.foundation.BorderStroke(1.dp, HudSurfaceBorder)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            LegendItem("Platforms", StatusNormal)
            LegendItem("Wind", WindCyan)
            LegendItem("Pipelines", GasCyan)
            LegendItem("Terminals", PetroleumGold)
            LegendItem("Vessels", StatusAdvisory)
          }
        }
      }

      // Filter Toggle Chips
      Row(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        FilterChip(
          selected = filterPlatforms,
          onClick = { viewModel.toggleMapFilter("PLATFORMS") },
          label = { Text("PLATFORMS", style = MaterialTheme.typography.labelSmall) }
        )
        FilterChip(
          selected = filterPipelines,
          onClick = { viewModel.toggleMapFilter("PIPELINES") },
          label = { Text("PIPELINES", style = MaterialTheme.typography.labelSmall) }
        )
        FilterChip(
          selected = filterTerminals,
          onClick = { viewModel.toggleMapFilter("TERMINALS") },
          label = { Text("TERMINALS", style = MaterialTheme.typography.labelSmall) }
        )
        FilterChip(
          selected = filterWind,
          onClick = { viewModel.toggleMapFilter("WIND") },
          label = { Text("WIND", style = MaterialTheme.typography.labelSmall) }
        )
        FilterChip(
          selected = filterMarine,
          onClick = { viewModel.toggleMapFilter("MARINE") },
          label = { Text("SHIPPING", style = MaterialTheme.typography.labelSmall) }
        )
      }
    }

    // Platform Inspection Modal / Bottom Sheet
    selectedPlatformForModal?.let { platform ->
      Box(
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .fillMaxWidth()
          .padding(12.dp)
      ) {
        HudCard(
          title = platform.name,
          tag = platform.quadrantBlock,
          status = platform.status,
          trailingContent = {
            IconButton(
              onClick = { selectedPlatformForModal = null },
              modifier = Modifier.size(24.dp)
            ) {
              Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
            }
          }
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            MetricKpiCell("Oil Production", "${String.format("%,.0f", platform.oilBopd)} BOPD", modifier = Modifier.weight(1f))
            MetricKpiCell("Gas Production", "${String.format("%,.0f", platform.gasMmscfd)} MMSCFD", modifier = Modifier.weight(1f))
            MetricKpiCell("Electrical Gen", "${platform.powerGenMw.toInt()} MW", modifier = Modifier.weight(1f))
            MetricKpiCell("POB / Max", "${platform.personnelOnBoard} / ${platform.maxCapacityPob}", modifier = Modifier.weight(1f))
          }

          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "LAT ${platform.coordinates.latitude}°N, LON ${platform.coordinates.longitude}°E • DEPTH ${platform.waterDepthM}m",
              style = MaterialTheme.typography.labelSmall,
              color = TextSecondary
            )

            Button(
              onClick = {
                viewModel.selectPlatformById(platform.id)
                viewModel.navigateTo(HudScreen.OFFSHORE_PLATFORM)
                selectedPlatformForModal = null
              },
              colors = ButtonDefaults.buttonColors(containerColor = GasCyan),
              shape = RoundedCornerShape(2.dp),
              contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
              Text("OPEN PLATFORM HUD", style = MaterialTheme.typography.labelSmall, color = HudBackground)
            }
          }
        }
      }
    }
  }
}

@Composable
private fun LegendItem(label: String, color: Color) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(4.dp)
  ) {
    Box(modifier = Modifier.size(6.dp).background(color, CircleShape))
    Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
  }
}
