package com.example.northsea.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.northsea.data.NorthSeaDataProvider
import com.example.northsea.data.TelemetryEngine
import com.example.northsea.models.*
import kotlinx.coroutines.flow.*

enum class HudScreen(val title: String, val shortTag: String) {
  MASTER_OPERATIONS("Operations HUD", "OPS"),
  NORTH_SEA_MAP("North Sea Map", "MAP"),
  PROCESS_DIAGRAM("Process P&ID", "SCADA"),
  OFFSHORE_PLATFORM("Platform Telemetry", "PLAT"),
  WELL_OPERATIONS("Well Management", "WELLS"),
  GAS_COMPRESSION("Gas Compression", "COMP"),
  PIPELINE_NETWORK("Pipeline Grid", "PIPE"),
  POWER_AND_WIND("Power & Offshore Wind", "POWER"),
  ECONOMIC_TRADING("Market Economics", "ECON"),
  PRODUCTION_FORECAST("Production Forecast", "FCST"),
  PREDICTIVE_MAINTENANCE("Asset Health & AI", "MAINT"),
  ALARMS_AND_SAFETY("Alarms & Safety", "ALM"),
  ENVIRONMENTAL_HUD("Environmental & ESG", "ENV"),
  SCENARIO_SIMULATION("Scenario Lab", "SCEN"),
  EXECUTIVE_OVERVIEW("Executive Overview", "EXEC"),
  SECURITY_AUDIT("Security & Audit", "SEC")
}

enum class MapZoomLevel(val label: String) {
  NORTH_SEA("North Sea (1:1M)"),
  FIELD("Field Basin (1:250k)"),
  PLATFORM("Platform 500m (1:10k)"),
  SUBSEA("Subsea Manifold (1:1k)"),
  EQUIPMENT("Xmas Tree / Wellhead (1:100)")
}

class NorthSeaHudViewModel : ViewModel() {

  val telemetryEngine = TelemetryEngine(viewModelScope)

  val masterKpi = telemetryEngine.masterKpi
  val platforms = telemetryEngine.platforms
  val pipelines = telemetryEngine.pipelines
  val terminals = telemetryEngine.terminals
  val windFarms = telemetryEngine.windFarms
  val wells = telemetryEngine.wells
  val compressors = telemetryEngine.compressors
  val processNodes = telemetryEngine.processNodes
  val marketCommodities = telemetryEngine.marketCommodities
  val economicSummary = telemetryEngine.economicSummary
  val alarms = telemetryEngine.alarms
  val maintenanceAssets = telemetryEngine.maintenanceAssets
  val activeScenario = telemetryEngine.activeScenario
  val safetyOverlay = telemetryEngine.safetyOverlay
  val environmental = telemetryEngine.environmental
  val currentUserRole = telemetryEngine.currentUserRole
  val auditLogs = telemetryEngine.auditLogs
  val selectedPlatformId = telemetryEngine.selectedPlatformId
  val liveGridFrequencyHz = telemetryEngine.liveGridFrequencyHz

  private val _currentScreen = MutableStateFlow(HudScreen.MASTER_OPERATIONS)
  val currentScreen: StateFlow<HudScreen> = _currentScreen.asStateFlow()

  private val _mapZoomLevel = MutableStateFlow(MapZoomLevel.NORTH_SEA)
  val mapZoomLevel: StateFlow<MapZoomLevel> = _mapZoomLevel.asStateFlow()

  private val _mapFilterPlatforms = MutableStateFlow(true)
  val mapFilterPlatforms: StateFlow<Boolean> = _mapFilterPlatforms.asStateFlow()

  private val _mapFilterPipelines = MutableStateFlow(true)
  val mapFilterPipelines: StateFlow<Boolean> = _mapFilterPipelines.asStateFlow()

  private val _mapFilterTerminals = MutableStateFlow(true)
  val mapFilterTerminals: StateFlow<Boolean> = _mapFilterTerminals.asStateFlow()

  private val _mapFilterWind = MutableStateFlow(true)
  val mapFilterWind: StateFlow<Boolean> = _mapFilterWind.asStateFlow()

  private val _mapFilterMarineTraffic = MutableStateFlow(true)
  val mapFilterMarineTraffic: StateFlow<Boolean> = _mapFilterMarineTraffic.asStateFlow()

  private val _selectedAssetDetail = MutableStateFlow<Any?>(null)
  val selectedAssetDetail: StateFlow<Any?> = _selectedAssetDetail.asStateFlow()

  private val _alarmCategoryFilter = MutableStateFlow<AlarmCategory?>(null)
  val alarmCategoryFilter: StateFlow<AlarmCategory?> = _alarmCategoryFilter.asStateFlow()

  private val _alarmClassFilter = MutableStateFlow<AlarmClass?>(null)
  val alarmClassFilter: StateFlow<AlarmClass?> = _alarmClassFilter.asStateFlow()

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  val selectedPlatform: StateFlow<PlatformAsset> = combine(platforms, selectedPlatformId) { list, id ->
    list.find { it.id == id } ?: list.first()
  }.stateIn(viewModelScope, SharingStarted.Eagerly, NorthSeaDataProvider.platforms.first())

  fun navigateTo(screen: HudScreen) {
    _currentScreen.value = screen
    telemetryEngine.logAction("NAVIGATE", screen.name, "Navigated to ${screen.title}")
  }

  fun setMapZoom(level: MapZoomLevel) {
    _mapZoomLevel.value = level
  }

  fun toggleMapFilter(filterType: String) {
    when (filterType) {
      "PLATFORMS" -> _mapFilterPlatforms.value = !_mapFilterPlatforms.value
      "PIPELINES" -> _mapFilterPipelines.value = !_mapFilterPipelines.value
      "TERMINALS" -> _mapFilterTerminals.value = !_mapFilterTerminals.value
      "WIND" -> _mapFilterWind.value = !_mapFilterWind.value
      "MARINE" -> _mapFilterMarineTraffic.value = !_mapFilterMarineTraffic.value
    }
  }

  fun selectAssetForInspection(asset: Any?) {
    _selectedAssetDetail.value = asset
  }

  fun selectPlatformById(platformId: String) {
    telemetryEngine.selectPlatform(platformId)
  }

  fun switchRole(role: UserRole) {
    telemetryEngine.switchUserRole(role)
  }

  fun acknowledgeAlarm(alarmId: String) {
    telemetryEngine.acknowledgeAlarm(alarmId)
  }

  fun shelveAlarm(alarmId: String) {
    telemetryEngine.shelveAlarm(alarmId)
  }

  fun adjustWellChoke(wellId: String, newChoke: Double) {
    telemetryEngine.adjustWellChoke(wellId, newChoke)
  }

  fun activateScenario(scenario: SimulationScenario) {
    telemetryEngine.activateScenario(scenario)
  }

  fun setAlarmCategoryFilter(cat: AlarmCategory?) {
    _alarmCategoryFilter.value = cat
  }

  fun setAlarmClassFilter(cls: AlarmClass?) {
    _alarmClassFilter.value = cls
  }

  fun setSearchQuery(query: String) {
    _searchQuery.value = query
  }
}
