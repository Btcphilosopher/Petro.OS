package com.example.northsea.models

data class SimulationScenario(
  val id: String,
  val title: String,
  val category: String,
  val description: String,
  val oilProductionDeltaBopd: Double,
  val gasProductionDeltaMmscfd: Double,
  val powerDeltaMw: Double,
  val revenueDeltaGbpM: Double,
  val emissionsDeltaTons: Double,
  val activeAlarmsInjected: List<String> = emptyList(),
  val keyTakeaway: String
)

data class ScenarioComparisonMetric(
  val label: String,
  val baseValue: String,
  val scenarioValue: String,
  val deltaValue: String,
  val isPositive: Boolean
)
