package com.example.northsea.models

enum class UserRole(val roleName: String, val clearance: String, val badgeColor: Long) {
  OPERATOR("Control Room Operator", "L2 - SCADA Write", 0xFF00E676),
  ENGINEER("Lead Petroleum Engineer", "L3 - Eng & Choke Mod", 0xFF00E5FF),
  CONTROL_ROOM_SUPERVISOR("OIM / Offshore Supervisor", "L4 - ESD & Setpoints", 0xFFFFB703),
  ASSET_MANAGER("North Sea Asset Manager", "L4 - Strategy & Logistics", 0xFF9D4EDD),
  EXECUTIVE("Executive Director Energy", "L5 - North Sea Portfolio", 0xFFFFC107),
  ADMINISTRATOR("Industrial Systems Admin", "L6 - Full System", 0xFFFF3366)
}

data class AuditLogEntry(
  val id: String,
  val timestamp: Long,
  val formattedTime: String,
  val userRole: UserRole,
  val operatorName: String,
  val actionType: String,
  val targetAsset: String,
  val details: String,
  val verificationHash: String
)
