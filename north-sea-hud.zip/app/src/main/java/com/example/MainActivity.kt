package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.northsea.ui.components.HudHeader
import com.example.northsea.ui.components.HudNavigationBar
import com.example.northsea.ui.screens.*
import com.example.northsea.viewmodel.HudScreen
import com.example.northsea.viewmodel.NorthSeaHudViewModel
import com.example.ui.theme.HudBackground
import com.example.ui.theme.NorthSeaHudTheme

class MainActivity : ComponentActivity() {
  private val viewModel: NorthSeaHudViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      NorthSeaHudTheme {
        NorthSeaApp(viewModel = viewModel)
      }
    }
  }
}

@Composable
fun NorthSeaApp(viewModel: NorthSeaHudViewModel) {
  val currentScreen by viewModel.currentScreen.collectAsState()
  val kpi by viewModel.masterKpi.collectAsState()
  val currentRole by viewModel.currentUserRole.collectAsState()
  val activeScenario by viewModel.activeScenario.collectAsState()

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    topBar = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .windowInsetsPadding(WindowInsets.statusBars)
      ) {
        HudHeader(
          kpi = kpi,
          currentRole = currentRole,
          activeScenario = activeScenario,
          onRoleSwitch = { viewModel.switchRole(it) },
          onAlertClick = { viewModel.navigateTo(HudScreen.ALARMS_AND_SAFETY) },
          onScenarioClick = { viewModel.navigateTo(HudScreen.SCENARIO_SIMULATION) }
        )
        HudNavigationBar(
          currentScreen = currentScreen,
          onScreenSelect = { viewModel.navigateTo(it) }
        )
      }
    },
    bottomBar = {
      Spacer(
        modifier = Modifier
          .fillMaxWidth()
          .windowInsetsPadding(WindowInsets.navigationBars)
      )
    },
    containerColor = HudBackground
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .background(HudBackground)
    ) {
      Crossfade(targetState = currentScreen, label = "ScreenTransition") { screen ->
        when (screen) {
          HudScreen.MASTER_OPERATIONS -> MasterOperationsHudScreen(viewModel = viewModel)
          HudScreen.NORTH_SEA_MAP -> NorthSeaMapScreen(viewModel = viewModel)
          HudScreen.PROCESS_DIAGRAM -> ProcessDiagramScreen(viewModel = viewModel)
          HudScreen.OFFSHORE_PLATFORM -> OffshorePlatformHudScreen(viewModel = viewModel)
          HudScreen.WELL_OPERATIONS -> WellOperationsScreen(viewModel = viewModel)
          HudScreen.GAS_COMPRESSION -> GasCompressionScreen(viewModel = viewModel)
          HudScreen.PIPELINE_NETWORK -> PipelineNetworkScreen(viewModel = viewModel)
          HudScreen.POWER_AND_WIND -> PowerAndWindScreen(viewModel = viewModel)
          HudScreen.ECONOMIC_TRADING -> EconomicTradingScreen(viewModel = viewModel)
          HudScreen.PRODUCTION_FORECAST -> ProductionForecastScreen(viewModel = viewModel)
          HudScreen.PREDICTIVE_MAINTENANCE -> PredictiveMaintenanceScreen(viewModel = viewModel)
          HudScreen.ALARMS_AND_SAFETY -> AlarmAndSafetyScreen(viewModel = viewModel)
          HudScreen.ENVIRONMENTAL_HUD -> EnvironmentalScreen(viewModel = viewModel)
          HudScreen.SCENARIO_SIMULATION -> ScenarioSimulationScreen(viewModel = viewModel)
          HudScreen.EXECUTIVE_OVERVIEW -> ExecutiveOverviewScreen(viewModel = viewModel)
          HudScreen.SECURITY_AUDIT -> SecurityAuditScreen(viewModel = viewModel)
        }
      }
    }
  }
}
