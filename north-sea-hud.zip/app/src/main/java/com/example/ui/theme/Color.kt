package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Bento Grid Dark Slate Naval & Engineering Palette
val HudBackground = Color(0xFF0B0F13)       // Deep slate-black canvas
val HudSurface = Color(0xFF151B23)          // Sleek Bento Card background
val HudSurfaceElevated = Color(0xFF1C2430)  // Elevated tile / secondary panel
val HudSurfaceBorder = Color(0xFF1E293B)    // Crisp slate-800 border
val HudSurfaceHover = Color(0xFF243042)     // Interactive hover state

// Bento Text & Micro-Typography
val TextPrimary = Color(0xFFF1F5F9)         // Slate 100
val TextSecondary = Color(0xFF94A3B8)       // Slate 400
val TextTertiary = Color(0xFF64748B)        // Slate 500
val TextMuted = Color(0xFF475569)           // Slate 600

// Bento SCADA Industrial Status Indicators
val StatusNormal = Color(0xFF34D399)        // Emerald 400
val StatusNormalGlow = Color(0x3334D399)
val StatusAdvisory = Color(0xFF38BDF8)      // Sky 400
val StatusWarning = Color(0xFFFBBF24)       // Amber 400
val StatusWarningGlow = Color(0x33FBBF24)
val StatusCritical = Color(0xFFF43F5E)      // Rose 500
val StatusCriticalGlow = Color(0x33F43F5E)
val StatusEmergency = Color(0xFFEF4444)     // Red 500
val StatusOffline = Color(0xFF64748B)       // Slate 500

// Bento Hydrocarbon & Energy Accents
val PetroleumGold = Color(0xFFFBBF24)       // Amber 400 (Brent Crude)
val GasCyan = Color(0xFF22D3EE)             // Cyan 400 (Natural Gas)
val WaterBlue = Color(0xFF38BDF8)           // Sky 400 (Produced Water)
val WindCyan = Color(0xFF06B6D4)            // Cyan 500 (Offshore Wind)
val PowerYellow = Color(0xFFFDE047)         // Yellow 300 (Grid Power)
val CarbonPurple = Color(0xFFA855F7)        // Purple 500 (Emissions / ESG)

// Bento Marine & Depth Accents
val SeaDeep = Color(0xFF070B10)
val SeaMedium = Color(0xFF0F1722)
val SeaShallow = Color(0xFF162334)
val Shoreline = Color(0xFF334155)
val PipelineLine = Color(0xFF22D3EE)
val PowerCableLine = Color(0xFFFDE047)

