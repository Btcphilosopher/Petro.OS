package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val NorthSeaColorScheme = darkColorScheme(
  primary = GasCyan,
  onPrimary = HudBackground,
  primaryContainer = HudSurfaceElevated,
  onPrimaryContainer = GasCyan,
  secondary = PetroleumGold,
  onSecondary = HudBackground,
  secondaryContainer = HudSurfaceElevated,
  onSecondaryContainer = PetroleumGold,
  tertiary = StatusNormal,
  onTertiary = HudBackground,
  tertiaryContainer = HudSurfaceElevated,
  onTertiaryContainer = StatusNormal,
  background = HudBackground,
  onBackground = TextPrimary,
  surface = HudSurface,
  onSurface = TextPrimary,
  surfaceVariant = HudSurfaceElevated,
  onSurfaceVariant = TextSecondary,
  outline = HudSurfaceBorder,
  error = StatusCritical,
  onError = TextPrimary
)

@Composable
fun NorthSeaHudTheme(
  content: @Composable () -> Unit
) {
  MaterialTheme(
    colorScheme = NorthSeaColorScheme,
    typography = Typography,
    content = content
  )
}
