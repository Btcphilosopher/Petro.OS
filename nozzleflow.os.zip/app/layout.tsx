import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'NOZZLEFLOW.OS | Industrial Liquid Nozzle Digital Twin Platform',
  description: 'Industrial Liquid Nozzle Digital Twin, Simulator & Manufacturing Execution System',
  openGraph: {
    title: 'NOZZLEFLOW.OS',
    description: 'Industrial Liquid Nozzle Digital Twin, Simulator & Manufacturing Execution System',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'NOZZLEFLOW.OS',
    description: 'Industrial Liquid Nozzle Digital Twin, Simulator & Manufacturing Execution System',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
