import { FluidProperty } from './types';

export const INITIAL_FLUIDS: FluidProperty[] = [
  {
    id: 'FL-WATER-20C',
    name: 'Water (Pure @ 20°C)',
    category: 'WATER',
    density: 998.2, // kg/m^3
    dynamicViscosity: 0.001002, // Pa.s
    kinematicViscosity: 1.004e-6, // m^2/s
    temperature: 20,
    vaporPressure: 2338, // Pa
    specificHeat: 4182, // J/(kg.K)
    thermalConductivity: 0.598,
    compressibility: 4.5e-10,
    isHazardous: false,
    isCryogenic: false,
    color: '#3b82f6', // blue
    referenceNotes: 'Standard IAPWS-IF97 property model',
  },
  {
    id: 'FL-HYD-OIL-VG46',
    name: 'Industrial Hydraulic Oil ISO VG 46',
    category: 'HYDRAULIC',
    density: 860.0,
    dynamicViscosity: 0.085, // 85 cP
    kinematicViscosity: 9.88e-5,
    temperature: 40,
    vaporPressure: 10,
    specificHeat: 1900,
    thermalConductivity: 0.13,
    compressibility: 7.0e-10,
    isHazardous: false,
    isCryogenic: false,
    color: '#eab308', // amber
    referenceNotes: 'Mineral-based industrial hydraulic fluid ISO VG 46',
  },
  {
    id: 'FL-JET-A1',
    name: 'Aviation Fuel Jet A-1',
    category: 'FUEL',
    density: 804.0,
    dynamicViscosity: 0.00179, // 1.79 cP
    kinematicViscosity: 2.23e-6,
    temperature: 15,
    vaporPressure: 1500,
    specificHeat: 2010,
    thermalConductivity: 0.115,
    compressibility: 9.5e-10,
    isHazardous: true,
    isCryogenic: false,
    color: '#f97316', // orange
    referenceNotes: 'ASTM D1655 Aviation Kerosene specification dataset',
  },
  {
    id: 'FL-MIL-5606',
    name: 'Hydraulic Fluid MIL-PRF-5606H',
    category: 'HYDRAULIC',
    density: 850.0,
    dynamicViscosity: 0.014, // 14 cP
    kinematicViscosity: 1.65e-5,
    temperature: 20,
    vaporPressure: 100,
    specificHeat: 1880,
    thermalConductivity: 0.125,
    compressibility: 8.0e-10,
    isHazardous: true,
    isCryogenic: false,
    color: '#ef4444', // red
    referenceNotes: 'Aero-grade red mineral hydraulic oil',
  },
  {
    id: 'FL-ETHANOL-99',
    name: 'Anhydrous Ethanol (99.8%)',
    category: 'SOLVENT',
    density: 789.0,
    dynamicViscosity: 0.0012, // 1.2 cP
    kinematicViscosity: 1.52e-6,
    temperature: 20,
    vaporPressure: 5800,
    specificHeat: 2440,
    thermalConductivity: 0.171,
    compressibility: 1.1e-9,
    isHazardous: true,
    isCryogenic: false,
    color: '#06b6d4', // cyan
    referenceNotes: 'Industrial solvent / fuel precursor grade',
  },
  {
    id: 'FL-LH2-20K',
    name: 'Liquid Hydrogen (LH2 @ 20.28 K)',
    category: 'CRYOGENIC',
    density: 70.85, // kg/m^3 (Extremely low density)
    dynamicViscosity: 0.0000133, // 0.0133 cP (Ultra low viscosity)
    kinematicViscosity: 1.88e-7,
    temperature: -252.87, // deg C (20.28 K)
    vaporPressure: 101325, // boiling point at 1 atm
    specificHeat: 9680, // J/(kg.K) High specific heat
    thermalConductivity: 0.0988,
    compressibility: 1.8e-8,
    isHazardous: true,
    isCryogenic: true,
    color: '#a855f7', // purple
    referenceNotes: 'NIST Chemistry WebBook cryogenic dataset. SIMULATION ONLY.',
  },
  {
    id: 'FL-LOX-90K',
    name: 'Liquid Oxygen (LOX @ 90.19 K)',
    category: 'CRYOGENIC',
    density: 1141.0, // kg/m^3
    dynamicViscosity: 0.00019, // 0.19 cP
    kinematicViscosity: 1.66e-7,
    temperature: -182.96, // deg C (90.19 K)
    vaporPressure: 101325,
    specificHeat: 1700,
    thermalConductivity: 0.152,
    compressibility: 1.2e-9,
    isHazardous: true,
    isCryogenic: true,
    color: '#38bdf8', // light blue
    referenceNotes: 'Rocket propellant grade LOX dataset. SIMULATION ONLY.',
  },
  {
    id: 'FL-LN2-77K',
    name: 'Liquid Nitrogen (LN2 @ 77.36 K)',
    category: 'CRYOGENIC',
    density: 808.4,
    dynamicViscosity: 0.000158, // 0.158 cP
    kinematicViscosity: 1.95e-7,
    temperature: -195.79,
    vaporPressure: 101325,
    specificHeat: 2040,
    thermalConductivity: 0.133,
    compressibility: 2.1e-9,
    isHazardous: false,
    isCryogenic: true,
    color: '#6366f1', // indigo
    referenceNotes: 'Cryogenic coolant standard dataset. SIMULATION ONLY.',
  },
];

/**
 * Calculates temperature-adjusted fluid density and dynamic viscosity.
 */
export function getFluidPropertiesAtTemp(fluid: FluidProperty, tempC: number): FluidProperty {
  const deltaT = tempC - fluid.temperature;
  
  // Thermal expansion effect on density: rho(T) ~ rho0 / (1 + beta * deltaT)
  const volExpansionCoeff = 0.0007; // ~0.07% per deg C average
  const adjustedDensity = Math.max(10, fluid.density / (1 + volExpansionCoeff * deltaT));
  
  // Andrade equation for viscosity vs temp: mu(T) = mu0 * exp(B * (1/T - 1/T0))
  const T_kelvin = tempC + 273.15;
  const T0_kelvin = fluid.temperature + 273.15;
  const activationEnergyRatio = 1500; // typical scale
  const viscosityRatio = Math.exp(activationEnergyRatio * (1 / Math.max(20, T_kelvin) - 1 / Math.max(20, T0_kelvin)));
  const adjustedViscosity = Math.max(1e-6, fluid.dynamicViscosity * viscosityRatio);
  
  const kinematicVisc = adjustedViscosity / adjustedDensity;

  return {
    ...fluid,
    temperature: tempC,
    density: Number(adjustedDensity.toFixed(2)),
    dynamicViscosity: Number(adjustedViscosity.toFixed(7)),
    kinematicViscosity: Number(kinematicVisc.toFixed(10)),
  };
}
