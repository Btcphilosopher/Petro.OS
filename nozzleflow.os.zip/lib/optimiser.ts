import { NozzleGeometry, FluidProperty } from './types';
import { calculateNozzleFlow } from './flowEngine';

export interface OptimizationWeights {
  flowRateWeight: number; // %
  pressureDropWeight: number; // %
  massWeight: number; // %
  mfgCostWeight: number; // %
  accuracyWeight: number; // %
}

export interface CandidateSolution {
  id: string;
  name: string;
  geometry: NozzleGeometry;
  flowLmin: number;
  pressureDropBar: number;
  estimatedMassKg: number;
  estimatedCostUsd: number;
  accuracyScorePercent: number;
  weightedTotalScore: number; // 0 to 100
}

export function runMultiObjectiveOptimization(
  baseGeometry: NozzleGeometry,
  fluid: FluidProperty,
  inletPressureBar: number,
  outletPressureBar: number,
  tempC: number,
  weights: OptimizationWeights,
  materialDensityKgM3 = 8000,
  materialCostPerKg = 8.5
): CandidateSolution[] {
  const candidates: CandidateSolution[] = [];

  // Generate 5 candidate variation geometries
  const variations: { name: string; orificeMod: number; convMod: number; wallMod: number }[] = [
    { name: 'Baseline Design', orificeMod: 1.0, convMod: 1.0, wallMod: 1.0 },
    { name: 'High-Flow Profile', orificeMod: 1.25, convMod: 1.15, wallMod: 1.1 },
    { name: 'Low Pressure-Drop Venturi', orificeMod: 1.1, convMod: 0.8, wallMod: 0.9 },
    { name: 'Lightweight Compact', orificeMod: 0.95, convMod: 1.0, wallMod: 0.75 },
    { name: 'Precision Metering Micro-Orifice', orificeMod: 0.85, convMod: 1.2, wallMod: 1.0 },
  ];

  variations.forEach((varItem, index) => {
    const candidateGeo: NozzleGeometry = {
      ...baseGeometry,
      orificeDiameter: Number((baseGeometry.orificeDiameter * varItem.orificeMod).toFixed(2)),
      convergingAngle: Number((baseGeometry.convergingAngle * varItem.convMod).toFixed(1)),
      wallThickness: Number((baseGeometry.wallThickness * varItem.wallMod).toFixed(1)),
      internalProfile: varItem.name.includes('Venturi') ? 'VENTURI' : baseGeometry.internalProfile,
    };

    const sim = calculateNozzleFlow(candidateGeo, fluid, inletPressureBar, outletPressureBar, tempC);

    // Approximate metal volume (hollow cylinder minus inner taper)
    const rOuter = (candidateGeo.inletDiameter / 2 + candidateGeo.wallThickness) / 1000;
    const rInner = candidateGeo.inletDiameter / 2 / 1000;
    const lenM = candidateGeo.nozzleLength / 1000;
    const metalVolM3 = Math.PI * (Math.pow(rOuter, 2) - Math.pow(rInner, 2)) * lenM * 0.7; // factor for taper
    const massKg = Number((metalVolM3 * materialDensityKgM3).toFixed(3));
    const costUsd = Number((massKg * materialCostPerKg * 3.5 + 45).toFixed(2)); // material + mfg machining

    // Accuracy score based on Cd and Reynolds
    const accuracyScore = Number(Math.min(99.9, sim.result.flowCoefficientCd * 100).toFixed(1));

    candidates.push({
      id: `CAND-${index + 1}`,
      name: varItem.name,
      geometry: candidateGeo,
      flowLmin: sim.result.volumetricFlowRate,
      pressureDropBar: sim.result.pressureDrop,
      estimatedMassKg: massKg,
      estimatedCostUsd: costUsd,
      accuracyScorePercent: accuracyScore,
      weightedTotalScore: 0,
    });
  });

  // Normalize metrics across candidate pool to calculate weighted score (0 to 100)
  const maxFlow = Math.max(...candidates.map((c) => c.flowLmin));
  const minFlow = Math.min(...candidates.map((c) => c.flowLmin));

  const maxP = Math.max(...candidates.map((c) => c.pressureDropBar));
  const minP = Math.min(...candidates.map((c) => c.pressureDropBar));

  const maxMass = Math.max(...candidates.map((c) => c.estimatedMassKg));
  const minMass = Math.min(...candidates.map((c) => c.estimatedMassKg));

  const maxCost = Math.max(...candidates.map((c) => c.estimatedCostUsd));
  const minCost = Math.min(...candidates.map((c) => c.estimatedCostUsd));

  const sumWeights =
    weights.flowRateWeight +
    weights.pressureDropWeight +
    weights.massWeight +
    weights.mfgCostWeight +
    weights.accuracyWeight || 100;

  candidates.forEach((c) => {
    const flowNorm = maxFlow === minFlow ? 1 : (c.flowLmin - minFlow) / (maxFlow - minFlow);
    const pNorm = maxP === minP ? 1 : 1 - (c.pressureDropBar - minP) / (maxP - minP); // lower is better
    const massNorm = maxMass === minMass ? 1 : 1 - (c.estimatedMassKg - minMass) / (maxMass - minMass); // lower is better
    const costNorm = maxCost === minCost ? 1 : 1 - (c.estimatedCostUsd - minCost) / (maxCost - minCost); // lower is better
    const accNorm = c.accuracyScorePercent / 100;

    const score =
      (flowNorm * weights.flowRateWeight +
        pNorm * weights.pressureDropWeight +
        massNorm * weights.massWeight +
        costNorm * weights.mfgCostWeight +
        accNorm * weights.accuracyWeight) /
      (sumWeights / 100);

    c.weightedTotalScore = Number(score.toFixed(1));
  });

  candidates.sort((a, b) => b.weightedTotalScore - a.weightedTotalScore);

  return candidates;
}
