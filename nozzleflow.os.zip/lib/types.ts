export type UnitSystem = 'SI' | 'METRIC' | 'IMPERIAL' | 'CUSTOM';

export type ComponentDataLevel = 'SIMULATED' | 'MEASURED' | 'CERTIFIED';

export type NozzleStatus =
  | 'DESIGNING'
  | 'SIMULATION READY'
  | 'IN PRODUCTION'
  | 'INSPECTED'
  | 'CALIBRATED'
  | 'IN SERVICE'
  | 'MAINTENANCE DUE'
  | 'QUARANTINED';

export type FluidCategory =
  | 'WATER'
  | 'OIL'
  | 'FUEL'
  | 'HYDRAULIC'
  | 'SOLVENT'
  | 'CRYOGENIC'
  | 'USER_DEFINED';

export type PhaseState = 'LIQUID' | 'GAS' | 'TWO_PHASE' | 'SUPERCRITICAL' | 'CRYOGENIC_LIQUID';

export interface FluidProperty {
  id: string;
  name: string;
  category: FluidCategory;
  density: number; // kg/m^3 at ref temp
  dynamicViscosity: number; // Pa.s at ref temp
  kinematicViscosity: number; // m^2/s
  temperature: number; // deg C
  vaporPressure: number; // Pa
  specificHeat: number; // J/(kg.K)
  thermalConductivity: number; // W/(m.K)
  compressibility: number; // 1/Pa
  isHazardous: boolean;
  isCryogenic: boolean;
  color: string;
  referenceNotes?: string;
}

export interface MaterialProperty {
  id: string;
  name: string;
  density: number; // kg/m^3
  yieldStrength: number; // MPa
  thermalConductivity: number; // W/(m.K)
  minTemp: number; // deg C
  maxTemp: number; // deg C
  corrosionResistance: 'LOW' | 'MEDIUM' | 'HIGH' | 'EXCELLENT';
  costPerKg: number; // USD/kg
  machinabilityIndex: number; // 0-100
  notes: string;
}

export type SprayPattern = 'FLAT_FAN' | 'FULL_CONE' | 'HOLLOW_CONE' | 'SOLID_STREAM' | 'MIST';
export type InternalProfileType = 'CONICAL' | 'VENTURI' | 'BELL_AEROSPIKE' | 'MULTI_ORIFICE' | 'SWIRL';
export type FittingType = 'NPT_1_2' | 'NPT_3_4' | 'FLANGED_ANSI_150' | 'TRI_CLAMP' | 'QUICK_CONNECT';

export interface NozzleGeometry {
  inletDiameter: number; // mm
  outletDiameter: number; // mm
  throatDiameter: number; // mm
  orificeDiameter: number; // mm
  nozzleLength: number; // mm
  convergingAngle: number; // deg
  divergingAngle: number; // deg
  wallThickness: number; // mm
  internalProfile: InternalProfileType;
  inletConnection: FittingType;
  outletConnection: FittingType;
  orificeGeometry: 'CIRCULAR' | 'ELLIPTICAL' | 'SLOT' | 'MULTI_HOLE';
  numberOfOutlets: number;
  sprayPattern: SprayPattern;
  surfaceFinishRa: number; // micrometers (um)
}

export interface InspectionDimension {
  id: string;
  feature: string;
  designValue: number;
  measuredValue: number;
  tolerancePlus: number;
  toleranceMinus: number;
  unit: string;
  status: 'PASS' | 'FAIL' | 'WARNING';
}

export interface SensorTwin {
  id: string;
  name: string;
  type: 'FLOW' | 'PRESSURE' | 'TEMPERATURE' | 'LOAD_CELL';
  rangeMin: number;
  rangeMax: number;
  unit: string;
  resolution: number;
  accuracyPercent: number;
  calibrationDate: string;
  calibrationFactor: number;
  uncertaintyPercent: number;
  status: 'OPTIMAL' | 'DRIFT' | 'FAULT';
  currentIdeal: number;
  currentSensor: number;
  currentCalibrated: number;
}

export interface CalibrationPoint {
  commandedFlow: number; // L/min
  measuredFlow: number; // L/min
  referenceStandard: number; // L/min
  errorPercent: number;
}

export interface CalibrationRecord {
  id: string;
  timestamp: string;
  operator: string;
  fluidName: string;
  points: CalibrationPoint[];
  offset: number;
  gain: number;
  repeatabilityPercent: number;
  overallUncertaintyPercent: number;
  passed: boolean;
  certificateId: string;
}

export interface MfgOperation {
  id: string;
  stepNumber: number;
  name: string;
  machine: string;
  operator: string;
  cycleTimeSec: number;
  tooling: string;
  toleranceMm: number;
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'FAILED';
  completedAt?: string;
}

export interface MaintenanceLog {
  id: string;
  date: string;
  type: 'INSPECTION' | 'CALIBRATION' | 'CLEANING' | 'ORIFICE_REPLACEMENT' | 'SEAL_REPAIR';
  description: string;
  operator: string;
  hoursAtService: number;
}

export interface DigitalTwinEvent {
  id: string;
  timestamp: string;
  type:
    | 'NOZZLE_CREATED'
    | 'GEOMETRY_CHANGED'
    | 'FLUID_CHANGED'
    | 'PRESSURE_CHANGED'
    | 'TEMPERATURE_CHANGED'
    | 'FLOW_UPDATED'
    | 'MASS_UPDATED'
    | 'MANUFACTURING_STARTED'
    | 'MANUFACTURING_COMPLETED'
    | 'INSPECTION_COMPLETED'
    | 'CALIBRATION_COMPLETED'
    | 'TEST_STARTED'
    | 'TEST_COMPLETED'
    | 'FAULT_DETECTED'
    | 'MAINTENANCE_REQUIRED';
  description: string;
  dataLevel: ComponentDataLevel;
}

export interface NozzleDigitalTwin {
  id: string;
  model: string;
  revision: string;
  status: NozzleStatus;
  dataLevel: ComponentDataLevel;
  geometry: NozzleGeometry;
  materialId: string;
  fluidId: string;
  
  // Operating Conditions
  inletPressure: number; // bar
  outletPressure: number; // bar
  fluidTemperature: number; // deg C
  ambientTemperature: number; // deg C
  
  // Metrology & Mfg
  metrology: InspectionDimension[];
  mfgOperations: MfgOperation[];
  currentMfgStepIndex: number;
  mfgProgress: number; // 0 - 100%
  
  // Calibration
  calibrationRecord?: CalibrationRecord;
  
  // Sensors
  sensors: SensorTwin[];
  
  // Lifecycle & Wear
  operatingHours: number;
  totalCycles: number;
  totalMassTransferredKg: number;
  wearIndexPercent: number; // 0 - 100%
  maintenanceLogs: MaintenanceLog[];
  
  // Event History
  events: DigitalTwinEvent[];
}

export interface FlowSimulationResult {
  inletVelocity: number; // m/s
  throatVelocity: number; // m/s
  outletVelocity: number; // m/s
  volumetricFlowRate: number; // L/min
  massFlowRate: number; // kg/s
  pressureDrop: number; // bar
  reynoldsNumber: number;
  flowCoefficientCd: number;
  machNumber?: number;
  cavitationNumber?: number;
  phaseState: PhaseState;
  fidelity: 'LOW' | 'MEDIUM' | 'HIGH';
  assumptions: string[];
}

export interface PositionProfilePoint {
  positionMm: number; // 0 to L
  section: 'INLET' | 'CONVERGING' | 'THROAT' | 'DIVERGING' | 'OUTLET';
  pressureBar: number;
  velocityMs: number;
  temperatureC: number;
  diameterMm: number;
}

export interface MonteCarloResult {
  samplesCount: number;
  meanFlowLmin: number;
  stdDevLmin: number;
  p5FlowLmin: number;
  p50FlowLmin: number;
  p95FlowLmin: number;
  defectRiskPercent: number;
  distribution: { flowBin: number; count: number }[];
}

export interface FaultInjectionState {
  sensorDriftActive: boolean;
  orificeBlockagePercent: number; // 0 - 50%
  temperatureDriftDeg: number;
  pumpPulsationActive: boolean;
  leakActive: boolean;
}
