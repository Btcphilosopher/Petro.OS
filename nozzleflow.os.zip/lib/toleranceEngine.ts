import { NozzleGeometry, FluidProperty, MonteCarloResult } from './types';
import { calculateNozzleFlow } from './flowEngine';

function randomGaussian(mean: number, stdDev: number): number {
  let u = 0,
    v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  const num = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  return mean + num * stdDev;
}

export function runMonteCarloToleranceAnalysis(
  geometry: NozzleGeometry,
  fluid: FluidProperty,
  inletPressureBar: number,
  outletPressureBar: number,
  tempC: number,
  orificeToleranceMm = 0.025,
  sampleSize = 1000
): MonteCarloResult {
  const nominalFlow = calculateNozzleFlow(geometry, fluid, inletPressureBar, outletPressureBar, tempC)
    .result.volumetricFlowRate;

  const stdDevOrifice = orificeToleranceMm / 3; // 3-sigma process capability
  const flows: number[] = [];
  let defects = 0;

  for (let i = 0; i < sampleSize; i++) {
    const sampledOrifice = Math.max(0.1, randomGaussian(geometry.orificeDiameter, stdDevOrifice));
    const sampledGeometry: NozzleGeometry = {
      ...geometry,
      orificeDiameter: sampledOrifice,
    };

    const sim = calculateNozzleFlow(sampledGeometry, fluid, inletPressureBar, outletPressureBar, tempC);
    const flowVal = sim.result.volumetricFlowRate;
    flows.push(flowVal);

    // Defect defined as > 3.0% flow deviation from nominal
    if (Math.abs(flowVal - nominalFlow) / Math.max(0.1, nominalFlow) > 0.03) {
      defects++;
    }
  }

  flows.sort((a, b) => a - b);

  const mean = flows.reduce((acc, v) => acc + v, 0) / sampleSize;
  const variance = flows.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / sampleSize;
  const stdDev = Math.sqrt(variance);

  const p5Index = Math.floor(sampleSize * 0.05);
  const p50Index = Math.floor(sampleSize * 0.5);
  const p95Index = Math.floor(sampleSize * 0.95);

  const p5 = flows[p5Index] ?? mean;
  const p50 = flows[p50Index] ?? mean;
  const p95 = flows[p95Index] ?? mean;

  // Build histogram bins for Recharts rendering
  const minFlow = flows[0] ?? mean;
  const maxFlow = flows[sampleSize - 1] ?? mean;
  const binCount = 15;
  const binWidth = Math.max(0.01, (maxFlow - minFlow) / binCount);

  const distributionMap: { [binLabel: string]: number } = {};
  for (let b = 0; b < binCount; b++) {
    const binCenter = Number((minFlow + (b + 0.5) * binWidth).toFixed(2));
    distributionMap[binCenter] = 0;
  }

  flows.forEach((f) => {
    let bIndex = Math.floor((f - minFlow) / binWidth);
    if (bIndex >= binCount) bIndex = binCount - 1;
    const binCenter = Number((minFlow + (bIndex + 0.5) * binWidth).toFixed(2));
    distributionMap[binCenter] = (distributionMap[binCenter] || 0) + 1;
  });

  const distribution = Object.entries(distributionMap).map(([bin, count]) => ({
    flowBin: parseFloat(bin),
    count,
  }));

  return {
    samplesCount: sampleSize,
    meanFlowLmin: Number(mean.toFixed(2)),
    stdDevLmin: Number(stdDev.toFixed(3)),
    p5FlowLmin: Number(p5.toFixed(2)),
    p50FlowLmin: Number(p50.toFixed(2)),
    p95FlowLmin: Number(p95.toFixed(2)),
    defectRiskPercent: Number(((defects / sampleSize) * 100).toFixed(1)),
    distribution,
  };
}
