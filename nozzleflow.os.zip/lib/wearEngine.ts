import { NozzleDigitalTwin, FluidProperty } from './types';

export function calculateErosionWearIndex(
  twin: NozzleDigitalTwin,
  fluid: FluidProperty,
  throatVelocityMs: number
): {
  wearIndexPercent: number; // 0 to 100%
  remainingHoursEstimate: number;
  orificeDiameterEnlargementMm: number;
  maintenanceStatus: 'OPTIMAL' | 'ATTENTION_NEEDED' | 'REPLACEMENT_REQUIRED';
} {
  // Base erosion rate factor (depends on velocity^2.5 and fluid type)
  let fluidAbrasiveFactor = 1.0;
  if (fluid.category === 'CRYOGENIC') fluidAbrasiveFactor = 0.4;
  if (fluid.category === 'SOLVENT') fluidAbrasiveFactor = 0.8;
  if (fluid.category === 'OIL' || fluid.category === 'HYDRAULIC') fluidAbrasiveFactor = 0.5;

  const velFactor = Math.pow(Math.max(1, throatVelocityMs) / 20.0, 2.2);
  const hours = Math.max(0, twin.operatingHours);
  const cycles = Math.max(0, twin.totalCycles);

  // Wear percentage calculation
  const rawWear = (hours * 0.008 + cycles * 0.0001) * velFactor * fluidAbrasiveFactor;
  const wearIndex = Math.min(100, Math.max(0, rawWear));

  // Orifice diameter enlargement in mm (erosion opens up orifice)
  const enlargementMm = (wearIndex / 100) * 0.45;

  const maxHours = 5000 / Math.max(0.2, velFactor * fluidAbrasiveFactor);
  const remainingHours = Math.max(0, maxHours - hours);

  let maintenanceStatus: 'OPTIMAL' | 'ATTENTION_NEEDED' | 'REPLACEMENT_REQUIRED' = 'OPTIMAL';
  if (wearIndex > 75) {
    maintenanceStatus = 'REPLACEMENT_REQUIRED';
  } else if (wearIndex > 50) {
    maintenanceStatus = 'ATTENTION_NEEDED';
  }

  return {
    wearIndexPercent: Number(wearIndex.toFixed(1)),
    remainingHoursEstimate: Math.round(remainingHours),
    orificeDiameterEnlargementMm: Number(enlargementMm.toFixed(3)),
    maintenanceStatus,
  };
}
