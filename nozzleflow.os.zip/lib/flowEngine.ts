import {
  FluidProperty,
  NozzleGeometry,
  FlowSimulationResult,
  PositionProfilePoint,
  PhaseState,
} from './types';

export function calculateNozzleFlow(
  geometry: NozzleGeometry,
  fluid: FluidProperty,
  inletPressureBar: number,
  outletPressureBar: number,
  tempC: number
): {
  result: FlowSimulationResult;
  profilePoints: PositionProfilePoint[];
} {
  // 1. Convert dimensions to SI meters
  const d_in = Math.max(0.001, geometry.inletDiameter / 1000);
  const d_out = Math.max(0.001, geometry.outletDiameter / 1000);
  const d_thr = Math.max(0.0005, geometry.throatDiameter / 1000);
  const d_ori = Math.max(0.0001, geometry.orificeDiameter / 1000);
  const L_m = Math.max(0.01, geometry.nozzleLength / 1000);

  const effectiveThroatDia = Math.min(d_thr, d_ori);

  // 2. Areas
  const A_in = (Math.PI / 4) * Math.pow(d_in, 2);
  const A_thr = (Math.PI / 4) * Math.pow(effectiveThroatDia, 2);
  const A_out = (Math.PI / 4) * Math.pow(d_out, 2);

  // 3. Pressure differential in Pascals
  const deltaP_bar = Math.max(0.01, inletPressureBar - outletPressureBar);
  const deltaP_pa = deltaP_bar * 100000;

  // 4. Fluid properties
  const rho = Math.max(10, fluid.density);
  const mu = Math.max(1e-7, fluid.dynamicViscosity);

  // 5. Contraction ratio beta
  const beta = effectiveThroatDia / d_in;
  const beta4 = Math.pow(beta, 4);

  // Initial estimate of Cd
  let Cd = 0.82;
  
  // Internal profile modifier
  switch (geometry.internalProfile) {
    case 'VENTURI':
      Cd = 0.96;
      break;
    case 'BELL_AEROSPIKE':
      Cd = 0.94;
      break;
    case 'CONICAL':
      Cd = 0.85;
      break;
    case 'MULTI_ORIFICE':
      Cd = 0.78;
      break;
    case 'SWIRL':
      Cd = 0.72;
      break;
  }

  // Iterative Reynolds and Cd calculation
  let v_thr_ideal = Math.sqrt((2 * deltaP_pa) / (rho * (1 - Math.min(0.95, beta4))));
  let v_thr = Cd * v_thr_ideal;
  let Re = (rho * v_thr * effectiveThroatDia) / mu;

  if (Re < 2000) {
    // Laminar transition reduction
    Cd = Math.max(0.3, Cd * Math.sqrt(Re / 2000));
    v_thr = Cd * v_thr_ideal;
    Re = (rho * v_thr * effectiveThroatDia) / mu;
  }

  // Volumetric Flow Rate Q (m^3/s)
  const Q_m3s = A_thr * v_thr;
  const Q_Lmin = Q_m3s * 60000; // L/min

  // Mass Flow Rate (kg/s)
  const massFlow_kgs = rho * Q_m3s;

  // Velocities
  const v_in = Q_m3s / A_in;
  const v_out = Q_m3s / A_out;

  // Phase State check
  let phaseState: PhaseState = 'LIQUID';
  if (fluid.isCryogenic) {
    phaseState = 'CRYOGENIC_LIQUID';
    if (outletPressureBar * 100000 < fluid.vaporPressure || tempC > -200) {
      phaseState = 'TWO_PHASE';
    }
  } else if (outletPressureBar * 100000 < fluid.vaporPressure) {
    phaseState = 'TWO_PHASE';
  }

  // Cavitation check
  const dynamicPressureThroat = 0.5 * rho * Math.pow(v_thr, 2);
  const P_outlet_pa = outletPressureBar * 100000;
  const cavitationNumber = (P_outlet_pa - fluid.vaporPressure) / Math.max(1, dynamicPressureThroat);

  const assumptions = [
    'Simplified 1D compressible/incompressible Navier-Stokes discharge equation',
    'Steady-state fluid temperature and uniform velocity distribution across cross-sections',
    'Empirical discharge coefficient Cd calibrated for nozzle internal contraction profile',
    'Friction factor based on surface roughness Ra = ' + geometry.surfaceFinishRa + ' µm',
  ];

  const result: FlowSimulationResult = {
    inletVelocity: Number(v_in.toFixed(2)),
    throatVelocity: Number(v_thr.toFixed(2)),
    outletVelocity: Number(v_out.toFixed(2)),
    volumetricFlowRate: Number(Q_Lmin.toFixed(2)),
    massFlowRate: Number(massFlow_kgs.toFixed(3)),
    pressureDrop: Number(deltaP_bar.toFixed(2)),
    reynoldsNumber: Math.round(Re),
    flowCoefficientCd: Number(Cd.toFixed(3)),
    cavitationNumber: Number(cavitationNumber.toFixed(2)),
    phaseState,
    fidelity: 'MEDIUM',
    assumptions,
  };

  // 6. Generate 1D Axial Position Profile (21 points along nozzle length)
  const profilePoints: PositionProfilePoint[] = [];
  const steps = 20;

  for (let i = 0; i <= steps; i++) {
    const fraction = i / steps; // 0.0 to 1.0
    const z_mm = fraction * geometry.nozzleLength;
    
    let section: PositionProfilePoint['section'] = 'INLET';
    let currentDiaMm = geometry.inletDiameter;
    let pBar = inletPressureBar;
    let vMs = v_in;
    let tDegC = tempC;

    if (fraction <= 0.25) {
      // Inlet section
      section = 'INLET';
      currentDiaMm = geometry.inletDiameter;
      vMs = v_in;
      pBar = inletPressureBar;
    } else if (fraction <= 0.6) {
      // Converging section
      section = 'CONVERGING';
      const convFrac = (fraction - 0.25) / 0.35;
      currentDiaMm = geometry.inletDiameter - convFrac * (geometry.inletDiameter - geometry.throatDiameter);
      const currArea = (Math.PI / 4) * Math.pow(currentDiaMm / 1000, 2);
      vMs = Q_m3s / Math.max(1e-8, currArea);
      
      // Bernoulli pressure drop
      const deltaP_local = 0.5 * rho * (Math.pow(vMs, 2) - Math.pow(v_in, 2)) / 100000;
      pBar = Math.max(outletPressureBar, inletPressureBar - deltaP_local);
    } else if (fraction <= 0.7) {
      // Throat / Orifice restriction
      section = 'THROAT';
      currentDiaMm = Math.min(geometry.throatDiameter, geometry.orificeDiameter);
      vMs = v_thr;
      pBar = Math.max(0.01, inletPressureBar - deltaP_bar * 0.95);
    } else {
      // Diverging section / Outlet
      section = 'DIVERGING';
      const divFrac = (fraction - 0.7) / 0.3;
      currentDiaMm = geometry.throatDiameter + divFrac * (geometry.outletDiameter - geometry.throatDiameter);
      const currArea = (Math.PI / 4) * Math.pow(currentDiaMm / 1000, 2);
      vMs = Q_m3s / Math.max(1e-8, currArea);
      
      // Pressure recovery toward outlet pressure
      pBar = (inletPressureBar - deltaP_bar * 0.95) + divFrac * (deltaP_bar * 0.95 - deltaP_bar);
    }

    // Viscous dissipation temperature rise estimate (Joule-Thomson / viscous heating)
    const kineticHeadEnergy = 0.5 * Math.pow(vMs, 2) / Math.max(100, fluid.specificHeat);
    tDegC += kineticHeadEnergy * 0.1;

    profilePoints.push({
      positionMm: Number(z_mm.toFixed(1)),
      section,
      pressureBar: Number(pBar.toFixed(2)),
      velocityMs: Number(vMs.toFixed(2)),
      temperatureC: Number(tDegC.toFixed(2)),
      diameterMm: Number(currentDiaMm.toFixed(2)),
    });
  }

  return { result, profilePoints };
}
