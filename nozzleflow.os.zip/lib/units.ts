import { UnitSystem } from './types';

export interface UnitConfig {
  length: 'mm' | 'cm' | 'm' | 'in';
  mass: 'g' | 'kg' | 't' | 'lb';
  volume: 'mL' | 'L' | 'm³' | 'gal';
  pressure: 'Pa' | 'kPa' | 'MPa' | 'bar' | 'psi';
  temperature: '°C' | 'K' | '°F';
  flowRate: 'kg/s' | 'g/s' | 'L/min' | 'L/s' | 'm³/h' | 'GPM';
  viscosity: 'cP' | 'Pa·s';
}

export const UNIT_PRESETS: Record<UnitSystem, UnitConfig> = {
  SI: {
    length: 'm',
    mass: 'kg',
    volume: 'm³',
    pressure: 'Pa',
    temperature: 'K',
    flowRate: 'kg/s',
    viscosity: 'Pa·s',
  },
  METRIC: {
    length: 'mm',
    mass: 'kg',
    volume: 'L',
    pressure: 'bar',
    temperature: '°C',
    flowRate: 'L/min',
    viscosity: 'cP',
  },
  IMPERIAL: {
    length: 'in',
    mass: 'lb',
    volume: 'gal',
    pressure: 'psi',
    temperature: '°F',
    flowRate: 'GPM',
    viscosity: 'cP',
  },
  CUSTOM: {
    length: 'mm',
    mass: 'kg',
    volume: 'L',
    pressure: 'bar',
    temperature: '°C',
    flowRate: 'L/min',
    viscosity: 'cP',
  },
};

// Internal standard storage SI units:
// Length: mm (or m)
// Pressure: bar
// Flow Rate: L/min
// Temperature: °C
// Mass: kg

export function convertLength(valMm: number, target: UnitConfig['length']): { val: number; unit: string } {
  switch (target) {
    case 'mm':
      return { val: valMm, unit: 'mm' };
    case 'cm':
      return { val: valMm / 10, unit: 'cm' };
    case 'm':
      return { val: valMm / 1000, unit: 'm' };
    case 'in':
      return { val: valMm / 25.4, unit: 'in' };
  }
}

export function convertPressure(valBar: number, target: UnitConfig['pressure']): { val: number; unit: string } {
  switch (target) {
    case 'bar':
      return { val: valBar, unit: 'bar' };
    case 'Pa':
      return { val: valBar * 100000, unit: 'Pa' };
    case 'kPa':
      return { val: valBar * 100, unit: 'kPa' };
    case 'MPa':
      return { val: valBar * 0.1, unit: 'MPa' };
    case 'psi':
      return { val: valBar * 14.5038, unit: 'psi' };
  }
}

export function convertTemp(valC: number, target: UnitConfig['temperature']): { val: number; unit: string } {
  switch (target) {
    case '°C':
      return { val: valC, unit: '°C' };
    case 'K':
      return { val: valC + 273.15, unit: 'K' };
    case '°F':
      return { val: (valC * 9) / 5 + 32, unit: '°F' };
  }
}

export function convertVolumetricFlow(
  valLmin: number,
  target: UnitConfig['flowRate']
): { val: number; unit: string } {
  switch (target) {
    case 'L/min':
      return { val: valLmin, unit: 'L/min' };
    case 'L/s':
      return { val: valLmin / 60, unit: 'L/s' };
    case 'm³/h':
      return { val: valLmin * 0.06, unit: 'm³/h' };
    case 'g/s':
      return { val: (valLmin / 60) * 1000, unit: 'g/s' }; // assumes density ~1000
    case 'kg/s':
      return { val: valLmin / 60, unit: 'kg/s' };
    case 'GPM':
      return { val: valLmin * 0.264172, unit: 'GPM' };
  }
}

export function convertMass(valKg: number, target: UnitConfig['mass']): { val: number; unit: string } {
  switch (target) {
    case 'kg':
      return { val: valKg, unit: 'kg' };
    case 'g':
      return { val: valKg * 1000, unit: 'g' };
    case 't':
      return { val: valKg / 1000, unit: 't' };
    case 'lb':
      return { val: valKg * 2.20462, unit: 'lb' };
  }
}

export function formatUnit(val: number, unit: string, decimals = 2): string {
  return `${val.toLocaleString(undefined, {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })} ${unit}`;
}
