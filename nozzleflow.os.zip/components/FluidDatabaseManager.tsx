'use client';

import React from 'react';
import { FluidProperty } from '../lib/types';
import { Droplet, AlertTriangle, ShieldAlert, Thermometer } from 'lucide-react';

interface FluidDatabaseManagerProps {
  fluids: FluidProperty[];
  selectedFluidId: string;
  temperatureC: number;
  inletPressureBar: number;
  outletPressureBar: number;
  onSelectFluid: (fluidId: string) => void;
  onChangeTemperature: (tempC: number) => void;
  onChangeInletPressure: (pressBar: number) => void;
  onChangeOutletPressure: (pressBar: number) => void;
}

export const FluidDatabaseManager: React.FC<FluidDatabaseManagerProps> = ({
  fluids,
  selectedFluidId,
  temperatureC,
  inletPressureBar,
  outletPressureBar,
  onSelectFluid,
  onChangeTemperature,
  onChangeInletPressure,
  onChangeOutletPressure,
}) => {
  const selectedFluid = fluids.find((f) => f.id === selectedFluidId) || fluids[0];

  return (
    <div className="w-full bg-slate-900/90 backdrop-blur-md rounded-xl border border-slate-800 p-4 font-mono flex flex-col gap-4 text-xs">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <Droplet className="w-4 h-4 text-sky-400" />
          <h2 className="font-bold text-slate-100 text-sm tracking-wide">FLUID PROPERTY DATABASE</h2>
        </div>
        <span className="text-[10px] text-sky-400 bg-sky-950 px-2 py-0.5 rounded border border-sky-800">
          IAPWS / NIST MODELS
        </span>
      </div>

      {/* Safety Banner for Cryogenic / Hazardous fluids */}
      {(selectedFluid.isCryogenic || selectedFluid.isHazardous) && (
        <div className="bg-amber-950/90 border-2 border-amber-500/80 p-3 rounded-lg text-amber-200 flex flex-col gap-1.5 shadow-lg animate-pulse">
          <div className="flex items-center gap-2 font-bold text-amber-400 text-xs">
            <ShieldAlert className="w-4 h-4 text-amber-400" />
            ENGINEERING SIMULATION ONLY • NOT OPERATIONAL CERTIFICATION
          </div>
          <p className="text-[11px] leading-relaxed text-amber-300">
            This platform models {selectedFluid.name} for design evaluation. Software simulation does NOT constitute safety certification or regulatory compliance for hazardous or cryogenic fluid handling.
          </p>
        </div>
      )}

      {/* Fluid Selector */}
      <div>
        <label className="text-[10px] text-slate-400 mb-1.5 block uppercase font-bold">SELECT WORKING FLUID</label>
        <select
          value={selectedFluidId}
          onChange={(e) => onSelectFluid(e.target.value)}
          className="w-full bg-slate-950 text-sky-300 font-bold p-2.5 rounded border border-sky-900/50 focus:outline-none focus:border-sky-500"
        >
          {fluids.map((f) => (
            <option key={f.id} value={f.id}>
              {f.name} ({f.category})
            </option>
          ))}
        </select>
      </div>

      {/* Operating Pressure & Temperature Sliders */}
      <div className="space-y-4 pt-2 border-t border-slate-800">
        <div className="text-slate-400 font-bold text-[11px] uppercase flex items-center gap-1.5 text-cyan-400">
          <Thermometer className="w-3.5 h-3.5" /> OPERATING FLUID CONDITIONS
        </div>

        {/* Temperature */}
        <div className="space-y-1">
          <div className="flex justify-between font-bold">
            <span className="text-slate-300">Fluid Temperature</span>
            <span className="text-amber-400">{temperatureC.toFixed(1)} °C</span>
          </div>
          <input
            type="range"
            min={selectedFluid.isCryogenic ? -260 : -40}
            max={selectedFluid.isCryogenic ? 20 : 250}
            step={selectedFluid.isCryogenic ? 0.5 : 1}
            value={temperatureC}
            onChange={(e) => onChangeTemperature(parseFloat(e.target.value))}
            className="w-full accent-amber-500 cursor-pointer"
          />
        </div>

        {/* Inlet Pressure */}
        <div className="space-y-1">
          <div className="flex justify-between font-bold">
            <span className="text-slate-300">Inlet Pressure (P_in)</span>
            <span className="text-cyan-400">{inletPressureBar.toFixed(2)} bar</span>
          </div>
          <input
            type="range"
            min={0.2}
            max={50.0}
            step={0.2}
            value={inletPressureBar}
            onChange={(e) => onChangeInletPressure(parseFloat(e.target.value))}
            className="w-full accent-cyan-500 cursor-pointer"
          />
        </div>

        {/* Outlet Pressure */}
        <div className="space-y-1">
          <div className="flex justify-between font-bold">
            <span className="text-slate-300">Outlet Backpressure (P_out)</span>
            <span className="text-emerald-400">{outletPressureBar.toFixed(2)} bar</span>
          </div>
          <input
            type="range"
            min={0.1}
            max={Math.max(0.2, inletPressureBar - 0.1)}
            step={0.1}
            value={outletPressureBar}
            onChange={(e) => onChangeOutletPressure(parseFloat(e.target.value))}
            className="w-full accent-emerald-500 cursor-pointer"
          />
        </div>
      </div>

      {/* Thermophysical Properties Card */}
      <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2">
        <div className="text-[10px] text-slate-400 font-bold uppercase border-b border-slate-800 pb-1">
          THERMOPHYSICAL PROPERTIES @ {temperatureC}°C
        </div>
        <div className="grid grid-cols-2 gap-2 text-[11px]">
          <div>
            <span className="text-slate-500">Density ($\rho$):</span>{' '}
            <span className="text-slate-200 font-bold">{selectedFluid.density} kg/m³</span>
          </div>
          <div>
            <span className="text-slate-500">Dyn. Viscosity ($\mu$):</span>{' '}
            <span className="text-slate-200 font-bold">{(selectedFluid.dynamicViscosity * 1000).toFixed(3)} cP</span>
          </div>
          <div>
            <span className="text-slate-500">Kin. Viscosity ($\nu$):</span>{' '}
            <span className="text-slate-200 font-bold">{(selectedFluid.kinematicViscosity * 1e6).toFixed(3)} cSt</span>
          </div>
          <div>
            <span className="text-slate-500">Vapor Pressure:</span>{' '}
            <span className="text-slate-200 font-bold">{(selectedFluid.vaporPressure / 1000).toFixed(2)} kPa</span>
          </div>
          <div>
            <span className="text-slate-500">Specific Heat:</span>{' '}
            <span className="text-slate-200 font-bold">{selectedFluid.specificHeat} J/kg.K</span>
          </div>
          <div>
            <span className="text-slate-500">Thermal Cond:</span>{' '}
            <span className="text-slate-200 font-bold">{selectedFluid.thermalConductivity} W/m.K</span>
          </div>
        </div>
      </div>
    </div>
  );
};
