'use client';

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { MfgOperation } from '../lib/types';

interface Factory3DCanvasProps {
  operations: MfgOperation[];
  currentStepIndex: number;
  isAnimating: boolean;
  onStepChange: (newIndex: number) => void;
  onTogglePlay: () => void;
}

export const Factory3DCanvas: React.FC<Factory3DCanvasProps> = ({
  operations,
  currentStepIndex,
  isAnimating,
  onStepChange,
  onTogglePlay,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const latheMeshRef = useRef<THREE.Mesh | null>(null);
  const toolMeshRef = useRef<THREE.Mesh | null>(null);
  const animFrameRef = useRef<number | null>(null);

  const [machineProgress, setMachineProgress] = useState(0);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#090d16');
    sceneRef.current = scene;

    const width = container.clientWidth || 500;
    const height = container.clientHeight || 350;

    const camera = new THREE.PerspectiveCamera(45, width / height, 1, 1000);
    camera.position.set(60, 50, 90);
    camera.lookAt(0, 0, 0);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lights
    const ambient = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambient);
    const dirLight = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight.position.set(80, 100, 50);
    scene.add(dirLight);

    // CNC Machine Chuck Base
    const chuckGeo = new THREE.CylinderGeometry(20, 20, 15, 32);
    const chuckMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.9, roughness: 0.2 });
    const chuck = new THREE.Mesh(chuckGeo, chuckMat);
    chuck.rotation.z = Math.PI / 2;
    chuck.position.x = -30;
    scene.add(chuck);

    // Billet / Nozzle workpiece being machined
    const billetGeo = new THREE.CylinderGeometry(12, 12, 50, 32);
    const billetMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.8, roughness: 0.3 });
    const billet = new THREE.Mesh(billetGeo, billetMat);
    billet.rotation.z = Math.PI / 2;
    billet.position.x = 5;
    scene.add(billet);
    latheMeshRef.current = billet;

    // Cutting Tool / CMM Probe
    const toolGeo = new THREE.ConeGeometry(3, 15, 16);
    const toolMat = new THREE.MeshStandardMaterial({ color: 0xef4444, metalness: 0.9, roughness: 0.1 });
    const tool = new THREE.Mesh(toolGeo, toolMat);
    tool.position.set(0, 18, 0);
    scene.add(tool);
    toolMeshRef.current = tool;

    // Grid Floor
    const grid = new THREE.GridHelper(200, 20, 0x1e293b, 0x0f172a);
    grid.position.y = -20;
    scene.add(grid);

    // Animation Loop
    let t = 0;
    const animate = () => {
      animFrameRef.current = requestAnimationFrame(animate);

      if (isAnimating) {
        t += 0.05;
        setMachineProgress((prev) => (prev >= 100 ? 0 : prev + 1));

        // Rotate billet spinning in CNC lathe
        if (latheMeshRef.current) {
          latheMeshRef.current.rotation.x += 0.15;
        }

        // Animate tool back and forth along workpiece x-axis
        if (toolMeshRef.current) {
          toolMeshRef.current.position.x = Math.sin(t) * 20;
          toolMeshRef.current.position.y = 14 + Math.cos(t * 2) * 2;
        }
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      renderer.dispose();
    };
  }, [isAnimating]);

  const currentOp = operations[currentStepIndex] || operations[0];

  return (
    <div className="w-full bg-slate-900 rounded-xl border border-slate-800 p-4 flex flex-col gap-4 shadow-xl">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-mono font-bold text-slate-100 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
            3D MANUFACTURING EXECUTION SYSTEM (MES)
          </h3>
          <p className="text-xs font-mono text-slate-400">
            Step {currentStepIndex + 1} of {operations.length}: {currentOp?.name}
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <button
            onClick={() => onStepChange(Math.max(0, currentStepIndex - 1))}
            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded border border-slate-700"
          >
            PREV STEP
          </button>
          <button
            onClick={onTogglePlay}
            className={`px-3 py-1 rounded font-bold border transition-colors ${
              isAnimating
                ? 'bg-amber-500/20 text-amber-300 border-amber-600 hover:bg-amber-500/30'
                : 'bg-emerald-500/20 text-emerald-300 border-emerald-600 hover:bg-emerald-500/30'
            }`}
          >
            {isAnimating ? 'PAUSE CNC' : 'PLAY CNC'}
          </button>
          <button
            onClick={() => onStepChange(Math.min(operations.length - 1, currentStepIndex + 1))}
            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded border border-slate-700"
          >
            NEXT STEP
          </button>
        </div>
      </div>

      {/* 3D Viewport */}
      <div ref={containerRef} className="w-full h-64 rounded-lg overflow-hidden border border-slate-800 relative">
        <div className="absolute top-2 left-2 z-10 bg-slate-950/80 backdrop-blur px-2.5 py-1 rounded text-[11px] font-mono text-slate-300 border border-slate-800">
          MACHINE: <span className="text-cyan-400 font-bold">{currentOp?.machine}</span>
        </div>
        <div className="absolute top-2 right-2 z-10 bg-slate-950/80 backdrop-blur px-2.5 py-1 rounded text-[11px] font-mono text-slate-300 border border-slate-800">
          TOOLING: <span className="text-amber-400 font-bold">{currentOp?.tooling}</span>
        </div>
        <div className="absolute bottom-2 left-2 right-2 z-10 bg-slate-950/90 backdrop-blur p-2 rounded border border-slate-800">
          <div className="flex justify-between text-[11px] font-mono text-slate-400 mb-1">
            <span>MACHINING PROGRESS</span>
            <span>{machineProgress}%</span>
          </div>
          <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-cyan-500 to-emerald-400 transition-all duration-300"
              style={{ width: `${machineProgress}%` }}
            />
          </div>
        </div>
      </div>

      {/* MES Shopfloor Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 font-mono text-xs">
        <div className="bg-slate-950/80 p-2.5 rounded border border-slate-800/80">
          <div className="text-slate-400 text-[10px]">MACHINE UTILIZATION</div>
          <div className="text-sm font-bold text-emerald-400">92.4 %</div>
        </div>
        <div className="bg-slate-950/80 p-2.5 rounded border border-slate-800/80">
          <div className="text-slate-400 text-[10px]">CYCLE TIME</div>
          <div className="text-sm font-bold text-slate-200">{currentOp?.cycleTimeSec} sec</div>
        </div>
        <div className="bg-slate-950/80 p-2.5 rounded border border-slate-800/80">
          <div className="text-slate-400 text-[10px]">TOLERANCE SPEC</div>
          <div className="text-sm font-bold text-amber-400">± {currentOp?.toleranceMm} mm</div>
        </div>
        <div className="bg-slate-950/80 p-2.5 rounded border border-slate-800/80">
          <div className="text-slate-400 text-[10px]">ENERGY CONSUMPTION</div>
          <div className="text-sm font-bold text-cyan-400">4.2 kWh</div>
        </div>
      </div>
    </div>
  );
};
