'use client';

import React from 'react';
import { DigitalTwinEvent } from '../lib/types';
import { Clock, ShieldCheck, Cpu } from 'lucide-react';

interface EventLogViewerProps {
  events: DigitalTwinEvent[];
}

export const EventLogViewer: React.FC<EventLogViewerProps> = ({ events }) => {
  return (
    <div className="w-full bg-slate-900/90 backdrop-blur-md rounded-xl border border-slate-800 p-4 font-mono flex flex-col gap-3 text-xs">
      <div className="flex items-center justify-between border-b border-slate-800 pb-2">
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-cyan-400" />
          <h3 className="font-bold text-slate-100 text-sm">DIGITAL THREAD IMMUTABLE LIFECYCLE AUDIT LOG</h3>
        </div>
        <span className="text-[10px] text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800">
          TRACEABILITY ENGINE
        </span>
      </div>

      <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
        {events.map((ev) => (
          <div
            key={ev.id}
            className="bg-slate-950 p-2.5 rounded-lg border border-slate-800/80 flex items-center justify-between text-[11px]"
          >
            <div className="flex items-center gap-3">
              <span className="text-slate-500 font-mono text-[10px]">{ev.timestamp}</span>
              <div>
                <span className="font-bold text-slate-200">{ev.type}</span>
                <p className="text-slate-400 text-[10px]">{ev.description}</p>
              </div>
            </div>

            <span
              className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                ev.dataLevel === 'CERTIFIED'
                  ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                  : ev.dataLevel === 'MEASURED'
                  ? 'bg-cyan-950 text-cyan-400 border-cyan-800'
                  : 'bg-purple-950 text-purple-400 border-purple-800'
              }`}
            >
              {ev.dataLevel}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};
