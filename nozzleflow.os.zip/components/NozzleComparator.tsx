'use client';

import React from 'react';
import { NozzleDigitalTwin, MaterialProperty, FluidProperty } from '../lib/types';
import { calculateNozzleFlow } from '../lib/flowEngine';
import { GitCompare, CheckCircle2 } from 'lucide-react';

interface NozzleComparatorProps {
  nozzles: NozzleDigitalTwin[];
  materials: MaterialProperty[];
  fluid: FluidProperty;
}

export const NozzleComparator: React.FC<NozzleComparatorProps> = ({ nozzles, materials, fluid }) => {
  return (
    <div className="w-full bg-slate-900/90 backdrop-blur-md rounded-xl border border-slate-800 p-4 font-mono flex flex-col gap-4 text-xs">
      <div className="flex items-center justify-between border-b border-slate-800 pb-2">
        <div className="flex items-center gap-2">
          <GitCompare className="w-4 h-4 text-cyan-400" />
          <h3 className="font-bold text-slate-100 text-sm">SIDE-BY-SIDE NOZZLE COMPARISON</h3>
        </div>
        <span className="text-[10px] text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800">
          MULTIPLE DIGITAL TWINS
        </span>
      </div>

      <div className="overflow-x-auto rounded-lg border border-slate-800">
        <table className="w-full text-left bg-slate-950">
          <thead className="bg-slate-900 text-slate-400 text-[10px] uppercase border-b border-slate-800">
            <tr>
              <th className="p-3">PARAMETER</th>
              {nozzles.map((n) => (
                <th key={n.id} className="p-3 text-cyan-300 font-bold">
                  {n.model} ({n.id})
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/80 text-[11px]">
            <tr>
              <td className="p-3 text-slate-400 font-bold">Orifice Diameter</td>
              {nozzles.map((n) => (
                <td key={n.id} className="p-3 font-bold text-amber-400">
                  {n.geometry.orificeDiameter} mm
                </td>
              ))}
            </tr>
            <tr>
              <td className="p-3 text-slate-400 font-bold">Inlet Diameter</td>
              {nozzles.map((n) => (
                <td key={n.id} className="p-3 text-slate-200">
                  {n.geometry.inletDiameter} mm
                </td>
              ))}
            </tr>
            <tr>
              <td className="p-3 text-slate-400 font-bold">Material</td>
              {nozzles.map((n) => {
                const mat = materials.find((m) => m.id === n.materialId) || materials[0];
                return (
                  <td key={n.id} className="p-3 text-slate-200 font-bold">
                    {mat.name}
                  </td>
                );
              })}
            </tr>
            <tr>
              <td className="p-3 text-slate-400 font-bold">Simulated Flow Rate</td>
              {nozzles.map((n) => {
                const sim = calculateNozzleFlow(
                  n.geometry,
                  fluid,
                  n.inletPressure,
                  n.outletPressure,
                  n.fluidTemperature
                );
                return (
                  <td key={n.id} className="p-3 font-bold text-emerald-400">
                    {sim.result.volumetricFlowRate} L/min
                  </td>
                );
              })}
            </tr>
            <tr>
              <td className="p-3 text-slate-400 font-bold">Mass Flow Rate</td>
              {nozzles.map((n) => {
                const sim = calculateNozzleFlow(
                  n.geometry,
                  fluid,
                  n.inletPressure,
                  n.outletPressure,
                  n.fluidTemperature
                );
                return (
                  <td key={n.id} className="p-3 font-bold text-cyan-400">
                    {sim.result.massFlowRate} kg/s
                  </td>
                );
              })}
            </tr>
            <tr>
              <td className="p-3 text-slate-400 font-bold">Discharge Coeff (Cd)</td>
              {nozzles.map((n) => {
                const sim = calculateNozzleFlow(
                  n.geometry,
                  fluid,
                  n.inletPressure,
                  n.outletPressure,
                  n.fluidTemperature
                );
                return (
                  <td key={n.id} className="p-3 font-bold text-purple-400">
                    {sim.result.flowCoefficientCd}
                  </td>
                );
              })}
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};
