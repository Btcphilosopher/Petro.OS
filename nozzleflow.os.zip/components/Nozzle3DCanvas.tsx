'use client';

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { NozzleGeometry, FluidProperty, SprayPattern } from '../lib/types';

interface Nozzle3DCanvasProps {
  geometry: NozzleGeometry;
  fluid: FluidProperty;
  velocityMs: number;
  inletPressureBar: number;
  tempC: number;
  viewMode: 'SOLID' | 'CUTAWAY' | 'XRAY' | 'EXPLODED' | 'FLOW_ONLY' | 'MEASURE';
  showThermalHeatmap?: boolean;
  onSelectComponent?: (compName: string, details: Record<string, string>) => void;
}

export const Nozzle3DCanvas: React.FC<Nozzle3DCanvasProps> = ({
  geometry,
  fluid,
  velocityMs,
  inletPressureBar,
  tempC,
  viewMode,
  showThermalHeatmap = false,
  onSelectComponent,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const nozzleGroupRef = useRef<THREE.Group | null>(null);
  const flowParticlesRef = useRef<THREE.Points | null>(null);
  const sprayParticlesRef = useRef<THREE.Points | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  const [hoveredComponent, setHoveredComponent] = useState<string | null>(null);

  // Mouse interaction state
  const isDraggingRef = useRef(false);
  const previousMousePositionRef = useRef({ x: 0, y: 0 });
  const rotationRef = useRef({ x: 0.3, y: 0.6 });
  const zoomRef = useRef(150);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // 1. Setup Three.js Scene, Camera, Renderer
    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#0f172a'); // slate-900
    sceneRef.current = scene;

    const width = container.clientWidth || 600;
    const height = container.clientHeight || 400;

    const camera = new THREE.PerspectiveCamera(45, width / height, 1, 1000);
    camera.position.set(0, 30, zoomRef.current);
    camera.lookAt(0, 0, 0);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // 2. Lighting Setup
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight1.position.set(100, 150, 100);
    dirLight1.castShadow = true;
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x38bdf8, 0.6); // Cyan fill
    dirLight2.position.set(-100, -50, -100);
    scene.add(dirLight2);

    // Grid Floor
    const gridHelper = new THREE.GridHelper(300, 30, 0x334155, 0x1e293b);
    gridHelper.position.y = -60;
    scene.add(gridHelper);

    // 3. Build Parametric Nozzle Group
    const nozzleGroup = new THREE.Group();
    scene.add(nozzleGroup);
    nozzleGroupRef.current = nozzleGroup;

    rebuildNozzleMesh(nozzleGroup, geometry, viewMode, showThermalHeatmap, fluid, tempC);

    // 4. Create Animated Fluid Particles inside Nozzle
    const { flowPoints, sprayPoints } = createFluidParticleSystem(geometry, fluid, velocityMs);
    scene.add(flowPoints);
    scene.add(sprayPoints);
    flowParticlesRef.current = flowPoints;
    sprayParticlesRef.current = sprayPoints;

    // 5. Animation Loop
    let particleOffset = 0;
    const animate = () => {
      animationFrameRef.current = requestAnimationFrame(animate);

      // Smooth Rotation update
      if (nozzleGroupRef.current) {
        nozzleGroupRef.current.rotation.x = rotationRef.current.x;
        nozzleGroupRef.current.rotation.y = rotationRef.current.y;
      }

      // Update particle positions based on velocity
      particleOffset += (velocityMs / 50.0) * 0.02;
      if (particleOffset > 1.0) particleOffset = 0;

      updateFluidParticles(
        flowParticlesRef.current,
        sprayParticlesRef.current,
        geometry,
        velocityMs,
        particleOffset,
        fluid.color
      );

      renderer.render(scene, camera);
    };

    animate();

    // Resize Handler
    const handleResize = () => {
      if (!container || !rendererRef.current || !cameraRef.current) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };

    const resizeObserver = new ResizeObserver(() => handleResize());
    resizeObserver.observe(container);

    return () => {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      resizeObserver.disconnect();
      renderer.dispose();
    };
  }, []);

  // Update Mesh when props change
  useEffect(() => {
    if (nozzleGroupRef.current) {
      rebuildNozzleMesh(nozzleGroupRef.current, geometry, viewMode, showThermalHeatmap, fluid, tempC);
    }
  }, [geometry, viewMode, showThermalHeatmap, fluid, tempC]);

  // Mouse Orbit controls
  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current) return;

    const deltaX = e.clientX - previousMousePositionRef.current.x;
    const deltaY = e.clientY - previousMousePositionRef.current.y;

    rotationRef.current.y += deltaX * 0.01;
    rotationRef.current.x += deltaY * 0.01;

    previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  const handleWheel = (e: React.WheelEvent) => {
    zoomRef.current = Math.max(40, Math.min(350, zoomRef.current + e.deltaY * 0.2));
    if (cameraRef.current) {
      cameraRef.current.position.z = zoomRef.current;
    }
  };

  const resetCamera = () => {
    rotationRef.current = { x: 0.3, y: 0.6 };
    zoomRef.current = 150;
    if (cameraRef.current) {
      cameraRef.current.position.set(0, 30, 150);
      cameraRef.current.lookAt(0, 0, 0);
    }
  };

  return (
    <div className="relative w-full h-full bg-slate-950 rounded-xl overflow-hidden border border-slate-800 shadow-2xl flex flex-col">
      {/* Top 3D Control Bar */}
      <div className="absolute top-3 left-3 right-3 z-10 flex items-center justify-between pointer-events-none">
        <div className="flex items-center gap-2 pointer-events-auto bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-700/80 shadow-md">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wide">
            3D DIGITAL TWIN • {geometry.internalProfile}
          </span>
          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/80 px-1.5 py-0.5 rounded border border-emerald-800">
            {viewMode}
          </span>
        </div>

        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            onClick={resetCamera}
            className="text-xs font-mono bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white px-2.5 py-1.5 rounded-lg border border-slate-700 shadow-md transition-all"
          >
            RESET CAMERA
          </button>
        </div>
      </div>

      {/* Main WebGL Container */}
      <div
        ref={containerRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onWheel={handleWheel}
        className="w-full h-full cursor-grab active:cursor-grabbing"
      />

      {/* Floating Canvas Overlay Legend */}
      <div className="absolute bottom-3 left-3 z-10 bg-slate-900/80 backdrop-blur-md px-3 py-2 rounded-lg border border-slate-800 text-[11px] font-mono text-slate-400 flex items-center gap-4">
        <div>
          ROTATE: <span className="text-slate-200">DRAG</span>
        </div>
        <div>
          ZOOM: <span className="text-slate-200">SCROLL</span>
        </div>
        <div>
          INLET: <span className="text-sky-400">{geometry.inletDiameter} mm</span>
        </div>
        <div>
          ORIFICE: <span className="text-amber-400">{geometry.orificeDiameter} mm</span>
        </div>
        <div>
          VELOCITY: <span className="text-emerald-400">{velocityMs} m/s</span>
        </div>
      </div>
    </div>
  );
};

// ----------------------------------------------------------------------
// MESH GENERATION HELPERS
// ----------------------------------------------------------------------

function rebuildNozzleMesh(
  group: THREE.Group,
  geo: NozzleGeometry,
  mode: string,
  thermal: boolean,
  fluid: FluidProperty,
  tempC: number
) {
  // Clear group
  while (group.children.length > 0) {
    const obj = group.children[0];
    group.remove(obj);
  }

  if (mode === 'FLOW_ONLY') return;

  const len = geo.nozzleLength;
  const rIn = geo.inletDiameter / 2;
  const rThr = geo.throatDiameter / 2;
  const rOut = geo.outletDiameter / 2;
  const rOri = geo.orificeDiameter / 2;
  const wall = geo.wallThickness;

  const isCutaway = mode === 'CUTAWAY';
  const isXray = mode === 'XRAY';
  const isExploded = mode === 'EXPLODED';

  // Base metallic material
  let bodyMat: THREE.Material = new THREE.MeshStandardMaterial({
    color: thermal ? getThermalColor(tempC) : 0x94a3b8, // Slate metal or heatmap
    metalness: 0.8,
    roughness: 0.25,
    wireframe: isXray,
    transparent: isXray,
    opacity: isXray ? 0.4 : 1.0,
    side: THREE.DoubleSide,
  });

  const orificeMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b, // Gold/Bronze insert
    metalness: 0.9,
    roughness: 0.15,
  });

  // Section 1: Inlet Flange / Fitting (z: -len/2 to -len/2 + len*0.25)
  const lenInlet = len * 0.25;
  const gInlet = new THREE.CylinderGeometry(
    rIn + wall,
    rIn + wall,
    lenInlet,
    32,
    1,
    false,
    0,
    isCutaway ? Math.PI * 1.5 : Math.PI * 2
  );
  const mInlet = new THREE.Mesh(gInlet, bodyMat);
  mInlet.position.z = isExploded ? -len * 0.4 : -len / 2 + lenInlet / 2;
  mInlet.rotation.x = Math.PI / 2;
  group.add(mInlet);

  // Section 2: Converging Cone (z: -len/2 + lenInlet to -len/2 + lenInlet + len*0.35)
  const lenConv = len * 0.35;
  const gConv = new THREE.CylinderGeometry(
    rThr + wall,
    rIn + wall,
    lenConv,
    32,
    1,
    false,
    0,
    isCutaway ? Math.PI * 1.5 : Math.PI * 2
  );
  const mConv = new THREE.Mesh(gConv, bodyMat);
  mConv.position.z = -len / 2 + lenInlet + lenConv / 2;
  mConv.rotation.x = Math.PI / 2;
  group.add(mConv);

  // Section 3: Orifice Insert (Throat)
  const lenThroat = len * 0.15;
  const gThroat = new THREE.CylinderGeometry(
    rOri + wall * 0.8,
    rThr + wall * 0.8,
    lenThroat,
    32,
    1,
    false,
    0,
    isCutaway ? Math.PI * 1.5 : Math.PI * 2
  );
  const mThroat = new THREE.Mesh(gThroat, orificeMat);
  mThroat.position.z = isExploded ? len * 0.2 : -len / 2 + lenInlet + lenConv + lenThroat / 2;
  mThroat.rotation.x = Math.PI / 2;
  group.add(mThroat);

  // Section 4: Diverging Outlet
  const lenDiv = len * 0.25;
  const gDiv = new THREE.CylinderGeometry(
    rOut + wall,
    rOri + wall * 0.8,
    lenDiv,
    32,
    1,
    false,
    0,
    isCutaway ? Math.PI * 1.5 : Math.PI * 2
  );
  const mDiv = new THREE.Mesh(gDiv, bodyMat);
  mDiv.position.z = isExploded ? len * 0.5 : -len / 2 + lenInlet + lenConv + lenThroat + lenDiv / 2;
  mDiv.rotation.x = Math.PI / 2;
  group.add(mDiv);
}

function getThermalColor(tempC: number): number {
  if (tempC < -100) return 0x38bdf8; // cryogenic blue
  if (tempC < 0) return 0x06b6d4; // cold cyan
  if (tempC < 50) return 0x10b981; // green ambient
  if (tempC < 150) return 0xf59e0b; // warm yellow
  return 0xef4444; // hot red
}

// Particle System creation
function createFluidParticleSystem(
  geo: NozzleGeometry,
  fluid: FluidProperty,
  vMs: number
): { flowPoints: THREE.Points; sprayPoints: THREE.Points } {
  const count = 600;
  const positions = new Float32Array(count * 3);
  const colors = new Float32Array(count * 3);

  const baseColor = new THREE.Color(fluid.color);

  for (let i = 0; i < count; i++) {
    positions[i * 3] = (Math.random() - 0.5) * geo.inletDiameter;
    positions[i * 3 + 1] = (Math.random() - 0.5) * geo.inletDiameter;
    positions[i * 3 + 2] = (Math.random() - 0.5) * geo.nozzleLength;

    colors[i * 3] = baseColor.r;
    colors[i * 3 + 1] = baseColor.g;
    colors[i * 3 + 2] = baseColor.b;
  }

  const flowGeo = new THREE.BufferGeometry();
  flowGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  flowGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

  const flowMat = new THREE.PointsMaterial({
    size: 2.2,
    vertexColors: true,
    transparent: true,
    opacity: 0.85,
    blending: THREE.AdditiveBlending,
  });

  const flowPoints = new THREE.Points(flowGeo, flowMat);

  // Spray points outside nozzle exit
  const sprayCount = 400;
  const sprayPositions = new Float32Array(sprayCount * 3);
  const sprayColors = new Float32Array(sprayCount * 3);

  for (let i = 0; i < sprayCount; i++) {
    sprayPositions[i * 3] = 0;
    sprayPositions[i * 3 + 1] = 0;
    sprayPositions[i * 3 + 2] = geo.nozzleLength / 2;

    sprayColors[i * 3] = baseColor.r;
    sprayColors[i * 3 + 1] = baseColor.g;
    sprayColors[i * 3 + 2] = baseColor.b;
  }

  const sprayGeo = new THREE.BufferGeometry();
  sprayGeo.setAttribute('position', new THREE.BufferAttribute(sprayPositions, 3));
  sprayGeo.setAttribute('color', new THREE.BufferAttribute(sprayColors, 3));

  const sprayMat = new THREE.PointsMaterial({
    size: 1.8,
    vertexColors: true,
    transparent: true,
    opacity: 0.75,
    blending: THREE.AdditiveBlending,
  });

  const sprayPoints = new THREE.Points(sprayGeo, sprayMat);

  return { flowPoints, sprayPoints };
}

function updateFluidParticles(
  flowPts: THREE.Points | null,
  sprayPts: THREE.Points | null,
  geo: NozzleGeometry,
  vMs: number,
  offset: number,
  fluidColorHex: string
) {
  if (!flowPts) return;

  const len = geo.nozzleLength;
  const rIn = geo.inletDiameter / 2;
  const rThr = geo.orificeDiameter / 2;

  const positions = flowPts.geometry.attributes.position.array as Float32Array;
  const count = positions.length / 3;

  for (let i = 0; i < count; i++) {
    // Progress z from -len/2 to +len/2
    let z = ((i / count + offset) % 1.0) * len - len / 2;

    // Radius contracts as z moves toward throat
    const zFrac = (z + len / 2) / len;
    let currentR = rIn;
    if (zFrac > 0.25 && zFrac < 0.7) {
      currentR = rIn - (zFrac - 0.25) * 2.2 * (rIn - rThr);
    } else if (zFrac >= 0.7) {
      currentR = rThr;
    }

    const angle = (i * 137.5 * Math.PI) / 180; // Golden angle dispersion
    const radial = Math.random() * currentR * 0.85;

    positions[i * 3] = Math.cos(angle) * radial;
    positions[i * 3 + 1] = Math.sin(angle) * radial;
    positions[i * 3 + 2] = z;
  }

  flowPts.geometry.attributes.position.needsUpdate = true;

  // Spray particles cone expansion at exit
  if (sprayPts) {
    const sprayPos = sprayPts.geometry.attributes.position.array as Float32Array;
    const sCount = sprayPos.length / 3;

    for (let i = 0; i < sCount; i++) {
      const sprayZ = len / 2 + ((i / sCount + offset * 2) % 1.0) * 80; // plume length
      const spreadR = (sprayZ - len / 2) * 0.45;

      const angle = (i * 2.4);
      sprayPos[i * 3] = Math.cos(angle) * spreadR;
      sprayPos[i * 3 + 1] = Math.sin(angle) * spreadR;
      sprayPos[i * 3 + 2] = sprayZ;
    }

    sprayPts.geometry.attributes.position.needsUpdate = true;
  }
}
