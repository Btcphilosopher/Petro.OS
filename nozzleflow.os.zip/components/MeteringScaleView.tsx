'use client';

import React, { useState, useEffect } from 'react';
import { Scale, Target, Scale as ScaleIcon, AlertTriangle, CheckCircle2 } from 'lucide-react';

interface MeteringScaleViewProps {
  massFlowKgS: number;
  volumetricFlowLmin: number;
  densityKgM3: number;
}

export const MeteringScaleView: React.FC<MeteringScaleViewProps> = ({
  massFlowKgS,
  volumetricFlowLmin,
  densityKgM3,
}) => {
  // Metering Targets
  const [targetMassKg, setTargetMassKg] = useState<number>(10.0);
  const [isDispensing, setIsDispensing] = useState<boolean>(false);
  const [dispensedMassKg, setDispensedMassKg] = useState<number>(0.0);
  const [tareMassKg, setTareMassKg] = useState<number>(2.5); // Tare container weight

  // Scale Noise Simulation
  const [scaleNoise, setScaleNoise] = useState<number>(0);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isDispensing) {
      interval = setInterval(() => {
        setDispensedMassKg((prev) => {
          const next = prev + massFlowKgS * 0.1; // 100ms ticks
          if (next >= targetMassKg) {
            setIsDispensing(false);
            return targetMassKg;
          }
          return next;
        });

        // Add simulated sensor noise (+/- 0.002 kg)
        setScaleNoise((Math.random() - 0.5) * 0.004);
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isDispensing, massFlowKgS, targetMassKg]);

  const estimatedDurationSec = targetMassKg / Math.max(0.01, massFlowKgS);

  // Scale Readouts
  const grossMass = dispensedMassKg + tareMassKg + scaleNoise;
  const netMass = dispensedMassKg + scaleNoise;

  // Mass Balance
  const inputMassKg = targetMassKg * 1.002; // slight tank supply
  const residualInPipeKg = 0.015;
  const unaccountedLossKg = inputMassKg - netMass - residualInPipeKg;
  const massBalanceWarning = Math.abs(unaccountedLossKg) > 0.05;

  return (
    <div className="w-full bg-slate-900/90 backdrop-blur-md rounded-xl border border-slate-800 p-4 font-mono flex flex-col gap-4 text-xs">
      <div className="flex items-center justify-between border-b border-slate-800 pb-2">
        <div className="flex items-center gap-2">
          <Scale className="w-4 h-4 text-purple-400" />
          <h3 className="font-bold text-slate-100 text-sm">PRECISION METERING & INDUSTRIAL WEIGHING ENGINE</h3>
        </div>
        <span className="text-[10px] text-purple-400 bg-purple-950 px-2 py-0.5 rounded border border-purple-800">
          RESOLUTION: 0.001 KG (1g)
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Precision Target Metering */}
        <div className="bg-slate-950 p-3 rounded-lg border border-slate-800/80 flex flex-col gap-3">
          <div className="text-slate-300 font-bold text-xs flex items-center gap-1.5 text-purple-400">
            <Target className="w-3.5 h-3.5" /> TARGET DISPENSE CONTROLLER
          </div>

          <div className="space-y-1">
            <div className="flex justify-between">
              <span className="text-slate-400">Target Mass</span>
              <span className="text-purple-300 font-bold">{targetMassKg.toFixed(2)} kg</span>
            </div>
            <input
              type="range"
              min={1.0}
              max={100.0}
              step={0.5}
              value={targetMassKg}
              onChange={(e) => setTargetMassKg(parseFloat(e.target.value))}
              className="w-full accent-purple-500 cursor-pointer"
            />
          </div>

          <div className="grid grid-cols-2 gap-2 text-[11px] bg-slate-900 p-2 rounded border border-slate-800">
            <div>
              <div className="text-slate-500">MASS FLOW RATE</div>
              <div className="font-bold text-emerald-400">{massFlowKgS.toFixed(3)} kg/s</div>
            </div>
            <div>
              <div className="text-slate-500">EST. DURATION</div>
              <div className="font-bold text-cyan-400">{estimatedDurationSec.toFixed(1)} s</div>
            </div>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => setIsDispensing(!isDispensing)}
              className={`w-full py-2 rounded font-bold transition-all border ${
                isDispensing
                  ? 'bg-amber-500/20 text-amber-300 border-amber-600 hover:bg-amber-500/30'
                  : 'bg-purple-600 text-white border-purple-500 hover:bg-purple-500'
              }`}
            >
              {isDispensing ? 'PAUSE DISPENSING' : 'START PRECISION METERING'}
            </button>
            <button
              onClick={() => setDispensedMassKg(0)}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700"
            >
              RESET
            </button>
          </div>
        </div>

        {/* Digital Scale Readout */}
        <div className="bg-slate-950 p-3 rounded-lg border border-slate-800/80 flex flex-col justify-between">
          <div className="text-slate-300 font-bold text-xs flex items-center justify-between">
            <span className="flex items-center gap-1.5 text-emerald-400">
              <ScaleIcon className="w-3.5 h-3.5" /> INDUSTRIAL LOAD CELL READOUT
            </span>
            <button
              onClick={() => setTareMassKg(grossMass)}
              className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] rounded border border-slate-700"
            >
              ZERO / TARE
            </button>
          </div>

          <div className="bg-slate-900/90 p-3 rounded border border-slate-800/90 my-2 font-mono text-center">
            <div className="text-[10px] text-slate-500">NET DELIVERED MASS</div>
            <div className="text-3xl font-bold text-emerald-400 tracking-wider">
              {netMass.toFixed(3)} <span className="text-sm">kg</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-1">
              GROSS: {grossMass.toFixed(3)} kg • TARE: {tareMassKg.toFixed(3)} kg
            </div>
          </div>

          <div className="flex justify-between text-[11px] text-slate-400 bg-slate-900 p-2 rounded border border-slate-800">
            <span>METERING ACCURACY:</span>
            <span className="text-emerald-400 font-bold">99.92 % (PASS)</span>
          </div>
        </div>
      </div>

      {/* Mass-Balance Engine Trace */}
      <div className="bg-slate-950 p-3 rounded-lg border border-slate-800/80 space-y-2">
        <div className="flex items-center justify-between border-b border-slate-800 pb-1">
          <span className="font-bold text-slate-300 text-xs">MASS-BALANCE & RECOVERY ENGINE</span>
          {massBalanceWarning ? (
            <span className="text-amber-400 bg-amber-950 px-2 py-0.5 rounded border border-amber-800 flex items-center gap-1">
              <AlertTriangle className="w-3 h-3" /> MASS BALANCE WARNING
            </span>
          ) : (
            <span className="text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" /> BALANCE CONVERGED
            </span>
          )}
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-[11px]">
          <div>
            <span className="text-slate-500">INPUT SUPPLY:</span>{' '}
            <span className="font-bold text-slate-200">{inputMassKg.toFixed(3)} kg</span>
          </div>
          <div>
            <span className="text-slate-500">OUTPUT DELIVERED:</span>{' '}
            <span className="font-bold text-emerald-400">{netMass.toFixed(3)} kg</span>
          </div>
          <div>
            <span className="text-slate-500">RESIDUAL PIPE HOLDUP:</span>{' '}
            <span className="font-bold text-purple-400">{residualInPipeKg.toFixed(3)} kg</span>
          </div>
          <div>
            <span className="text-slate-500">MASS LOSS / RECOVERY:</span>{' '}
            <span className={`font-bold ${unaccountedLossKg > 0.03 ? 'text-amber-400' : 'text-slate-200'}`}>
              {unaccountedLossKg.toFixed(3)} kg
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
