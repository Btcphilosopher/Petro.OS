'use client';

import React from 'react';
import { NozzleDigitalTwin, FlowSimulationResult, MaterialProperty, FluidProperty } from '../lib/types';
import { ShieldCheck, Printer, X, FileText, CheckCircle2 } from 'lucide-react';

interface EngineeringReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  twin: NozzleDigitalTwin;
  simResult: FlowSimulationResult;
  material: MaterialProperty;
  fluid: FluidProperty;
}

export const EngineeringReportModal: React.FC<EngineeringReportModalProps> = ({
  isOpen,
  onClose,
  twin,
  simResult,
  material,
  fluid,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto font-mono">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-4xl p-6 shadow-2xl flex flex-col gap-6 max-h-[90vh] overflow-y-auto text-slate-100">
        {/* Header Bar */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-lg border border-emerald-500/40">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-100">NOZZLEFLOW.OS • OFFICIAL ENGINEERING REPORT</h2>
              <p className="text-xs text-slate-400">DIGITAL TWIN LIFECYCLE CERTIFICATE & SIMULATION DOSSIER</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => window.print()}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded border border-slate-700 flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" /> PRINT / SAVE PDF
            </button>
            <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Report Identifiers */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs">
          <div>
            <div className="text-slate-500">NOZZLE ID</div>
            <div className="font-bold text-cyan-400 text-sm">{twin.id}</div>
          </div>
          <div>
            <div className="text-slate-500">MODEL & REVISION</div>
            <div className="font-bold text-slate-200 text-sm">
              {twin.model} ({twin.revision})
            </div>
          </div>
          <div>
            <div className="text-slate-500">DIGITAL TWIN STATUS</div>
            <div className="font-bold text-emerald-400 text-sm">{twin.status}</div>
          </div>
          <div>
            <div className="text-slate-500">DATA LEVEL</div>
            <div className="font-bold text-purple-400 text-sm">{twin.dataLevel}</div>
          </div>
        </div>

        {/* Safety Disclaimer Banner */}
        <div className="bg-amber-950/60 border border-amber-600/60 p-3 rounded-lg text-amber-300 text-xs flex items-center gap-3">
          <ShieldCheck className="w-6 h-6 text-amber-400 shrink-0" />
          <p>
            <strong>NOTICE:</strong> SIMULATED DATA & MEASURED METROLOGY REPORT. THIS DOCUMENT DISTINGUISHES SOFTWARE SIMULATED MODELS FROM EMPIRICAL CALIBRATION MEASUREMENTS.
          </p>
        </div>

        {/* Geometry & Material Specification */}
        <div className="space-y-2">
          <h3 className="font-bold text-cyan-400 text-xs uppercase border-b border-slate-800 pb-1">
            1. GEOMETRIC & METALLURGICAL SPECIFICATIONS
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-xs bg-slate-950 p-3 rounded-lg border border-slate-800">
            <div>
              <span className="text-slate-500">Inlet Diameter:</span> {twin.geometry.inletDiameter} mm
            </div>
            <div>
              <span className="text-slate-500">Orifice Diameter:</span> {twin.geometry.orificeDiameter} mm
            </div>
            <div>
              <span className="text-slate-500">Throat Diameter:</span> {twin.geometry.throatDiameter} mm
            </div>
            <div>
              <span className="text-slate-500">Nozzle Length:</span> {twin.geometry.nozzleLength} mm
            </div>
            <div>
              <span className="text-slate-500">Wall Thickness:</span> {twin.geometry.wallThickness} mm
            </div>
            <div>
              <span className="text-slate-500">Surface Finish:</span> Ra {twin.geometry.surfaceFinishRa} µm
            </div>
            <div>
              <span className="text-slate-500">Body Material:</span> {material.name}
            </div>
            <div>
              <span className="text-slate-500">Internal Profile:</span> {twin.geometry.internalProfile}
            </div>
            <div>
              <span className="text-slate-500">Spray Pattern:</span> {twin.geometry.sprayPattern}
            </div>
          </div>
        </div>

        {/* Flow Performance Results */}
        <div className="space-y-2">
          <h3 className="font-bold text-emerald-400 text-xs uppercase border-b border-slate-800 pb-1">
            2. FLUID MECHANICS & DISCHARGE PERFORMANCE
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs bg-slate-950 p-3 rounded-lg border border-slate-800">
            <div>
              <div className="text-slate-500">VOLUMETRIC FLOW</div>
              <div className="font-bold text-emerald-400">{simResult.volumetricFlowRate} L/min</div>
            </div>
            <div>
              <div className="text-slate-500">MASS FLOW RATE</div>
              <div className="font-bold text-cyan-400">{simResult.massFlowRate} kg/s</div>
            </div>
            <div>
              <div className="text-slate-500">THROAT VELOCITY</div>
              <div className="font-bold text-amber-400">{simResult.throatVelocity} m/s</div>
            </div>
            <div>
              <div className="text-slate-500">FLOW COEFFICIENT (Cd)</div>
              <div className="font-bold text-purple-400">{simResult.flowCoefficientCd}</div>
            </div>
          </div>
        </div>

        {/* CMM Metrology & QA Pass Seal */}
        <div className="bg-emerald-950/40 border border-emerald-800 p-4 rounded-xl flex items-center justify-between">
          <div className="space-y-1">
            <div className="text-emerald-400 font-bold text-sm flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" /> QA QUALITY MANAGEMENT PASSED
            </div>
            <p className="text-xs text-slate-300">
              CMM Metrology, Gravimetric Flow Test, and Pressure Vessel Integrity pass all required tolerances.
            </p>
          </div>

          <div className="text-right border-l border-emerald-800/80 pl-4">
            <div className="text-[10px] text-slate-400">CERTIFICATION SEAL</div>
            <div className="text-xs font-bold text-emerald-300">NOZZLEFLOW CERTIFIED</div>
            <div className="text-[9px] text-slate-500">{new Date().toISOString().split('T')[0]}</div>
          </div>
        </div>
      </div>
    </div>
  );
};
