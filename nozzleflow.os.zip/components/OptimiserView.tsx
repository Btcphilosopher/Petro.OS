'use client';

import React, { useState } from 'react';
import { NozzleGeometry, FluidProperty } from '../lib/types';
import { runMultiObjectiveOptimization, CandidateSolution, OptimizationWeights } from '../lib/optimiser';
import { Sparkles, Trophy, Check } from 'lucide-react';

interface OptimiserViewProps {
  geometry: NozzleGeometry;
  fluid: FluidProperty;
  inletPressureBar: number;
  outletPressureBar: number;
  tempC: number;
  onApplyCandidate: (newGeo: NozzleGeometry) => void;
}

export const OptimiserView: React.FC<OptimiserViewProps> = ({
  geometry,
  fluid,
  inletPressureBar,
  outletPressureBar,
  tempC,
  onApplyCandidate,
}) => {
  const [weights, setWeights] = useState<OptimizationWeights>({
    flowRateWeight: 30,
    pressureDropWeight: 20,
    massWeight: 15,
    mfgCostWeight: 15,
    accuracyWeight: 20,
  });

  const [candidates, setCandidates] = useState<CandidateSolution[]>(() =>
    runMultiObjectiveOptimization(geometry, fluid, inletPressureBar, outletPressureBar, tempC, weights)
  );

  const handleRecalculate = (newWeights: OptimizationWeights) => {
    setWeights(newWeights);
    const res = runMultiObjectiveOptimization(geometry, fluid, inletPressureBar, outletPressureBar, tempC, newWeights);
    setCandidates(res);
  };

  return (
    <div className="w-full bg-slate-900/90 backdrop-blur-md rounded-xl border border-slate-800 p-4 font-mono flex flex-col gap-4 text-xs">
      <div className="flex items-center justify-between border-b border-slate-800 pb-2">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <h3 className="font-bold text-slate-100 text-sm">MULTI-OBJECTIVE NOZZLE OPTIMIZATION ENGINE</h3>
        </div>
        <span className="text-[10px] text-amber-400 bg-amber-950 px-2 py-0.5 rounded border border-amber-800">
          PARETO RANKING
        </span>
      </div>

      {/* Weight Sliders */}
      <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-3">
        <div className="text-[10px] text-slate-400 font-bold uppercase">OBJECTIVE WEIGHT ALLOCATION (%)</div>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          <div>
            <label className="text-slate-400 text-[10px] block">Max Flow ({weights.flowRateWeight}%)</label>
            <input
              type="range"
              min={0}
              max={100}
              value={weights.flowRateWeight}
              onChange={(e) =>
                handleRecalculate({ ...weights, flowRateWeight: parseInt(e.target.value) })
              }
              className="w-full accent-emerald-500"
            />
          </div>
          <div>
            <label className="text-slate-400 text-[10px] block">Min ΔP ({weights.pressureDropWeight}%)</label>
            <input
              type="range"
              min={0}
              max={100}
              value={weights.pressureDropWeight}
              onChange={(e) =>
                handleRecalculate({ ...weights, pressureDropWeight: parseInt(e.target.value) })
              }
              className="w-full accent-cyan-500"
            />
          </div>
          <div>
            <label className="text-slate-400 text-[10px] block">Min Mass ({weights.massWeight}%)</label>
            <input
              type="range"
              min={0}
              max={100}
              value={weights.massWeight}
              onChange={(e) =>
                handleRecalculate({ ...weights, massWeight: parseInt(e.target.value) })
              }
              className="w-full accent-purple-500"
            />
          </div>
          <div>
            <label className="text-slate-400 text-[10px] block">Min Cost ({weights.mfgCostWeight}%)</label>
            <input
              type="range"
              min={0}
              max={100}
              value={weights.mfgCostWeight}
              onChange={(e) =>
                handleRecalculate({ ...weights, mfgCostWeight: parseInt(e.target.value) })
              }
              className="w-full accent-amber-500"
            />
          </div>
          <div>
            <label className="text-slate-400 text-[10px] block">Max Acc. ({weights.accuracyWeight}%)</label>
            <input
              type="range"
              min={0}
              max={100}
              value={weights.accuracyWeight}
              onChange={(e) =>
                handleRecalculate({ ...weights, accuracyWeight: parseInt(e.target.value) })
              }
              className="w-full accent-sky-500"
            />
          </div>
        </div>
      </div>

      {/* Candidate Solutions List */}
      <div className="space-y-2">
        <div className="text-slate-300 font-bold text-xs uppercase">RANKED CANDIDATE GEOMETRIES</div>
        <div className="grid grid-cols-1 gap-2">
          {candidates.map((cand, idx) => (
            <div
              key={cand.id}
              className={`bg-slate-950 p-3 rounded-lg border flex items-center justify-between text-[11px] ${
                idx === 0 ? 'border-amber-500/80 bg-amber-950/20' : 'border-slate-800'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-8 h-8 rounded bg-slate-900 border border-slate-700 font-bold text-amber-400">
                  {idx === 0 ? <Trophy className="w-4 h-4 text-amber-400" /> : `#${idx + 1}`}
                </div>
                <div>
                  <div className="font-bold text-slate-100">{cand.name}</div>
                  <div className="text-slate-400 text-[10px]">
                    Orifice: {cand.geometry.orificeDiameter}mm • Flow: {cand.flowLmin} L/min • Mass: {cand.estimatedMassKg}kg • Cost: ${cand.estimatedCostUsd}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="text-right">
                  <div className="text-[10px] text-slate-500">PARETO SCORE</div>
                  <div className="font-bold text-amber-400 text-sm">{cand.weightedTotalScore} / 100</div>
                </div>

                <button
                  onClick={() => onApplyCandidate(cand.geometry)}
                  className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded font-bold border border-amber-500 text-[10px] flex items-center gap-1"
                >
                  <Check className="w-3 h-3" /> APPLY GEOMETRY
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
