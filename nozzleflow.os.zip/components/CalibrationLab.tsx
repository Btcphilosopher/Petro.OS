'use client';

import React, { useState } from 'react';
import { CalibrationRecord, CalibrationPoint } from '../lib/types';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { Award, CheckCircle, RefreshCw, FileText } from 'lucide-react';

interface CalibrationLabProps {
  record?: CalibrationRecord;
  nozzleId: string;
  fluidName: string;
  onGenerateCertificate: () => void;
}

export const CalibrationLab: React.FC<CalibrationLabProps> = ({
  record,
  nozzleId,
  fluidName,
  onGenerateCertificate,
}) => {
  const [points, setPoints] = useState<CalibrationPoint[]>(
    record?.points || [
      { commandedFlow: 10.0, measuredFlow: 9.98, referenceStandard: 10.0, errorPercent: -0.2 },
      { commandedFlow: 20.0, measuredFlow: 19.95, referenceStandard: 20.0, errorPercent: -0.25 },
      { commandedFlow: 30.0, measuredFlow: 30.04, referenceStandard: 30.0, errorPercent: 0.13 },
      { commandedFlow: 40.0, measuredFlow: 40.08, referenceStandard: 40.0, errorPercent: 0.2 },
      { commandedFlow: 50.0, measuredFlow: 49.92, referenceStandard: 50.0, errorPercent: -0.16 },
    ]
  );

  const [isCalibrating, setIsCalibrating] = useState(false);

  const handleRunCalibrationRun = () => {
    setIsCalibrating(true);
    setTimeout(() => {
      // Add slight random calibration drift
      const newPoints = points.map((p) => {
        const noise = (Math.random() - 0.5) * 0.1;
        const mFlow = p.commandedFlow + noise;
        const err = ((mFlow - p.commandedFlow) / p.commandedFlow) * 100;
        return {
          ...p,
          measuredFlow: Number(mFlow.toFixed(2)),
          errorPercent: Number(err.toFixed(2)),
        };
      });
      setPoints(newPoints);
      setIsCalibrating(false);
    }, 500);
  };

  return (
    <div className="w-full bg-slate-900/90 backdrop-blur-md rounded-xl border border-slate-800 p-4 font-mono flex flex-col gap-4 text-xs">
      <div className="flex items-center justify-between border-b border-slate-800 pb-2">
        <div className="flex items-center gap-2">
          <Award className="w-4 h-4 text-emerald-400" />
          <h3 className="font-bold text-slate-100 text-sm">VIRTUAL FLOW CALIBRATION LABORATORY</h3>
        </div>
        <span className="text-[10px] text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
          ISO/IEC 17025 ACCREDITED BENCH
        </span>
      </div>

      {/* Calibration Workflow Map */}
      <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 flex items-center justify-between text-[11px] font-bold text-slate-300">
        <span className="text-cyan-400">NOZZLE</span> →
        <span className="text-purple-400">CORIOLIS REF METER</span> →
        <span className="text-emerald-400">PRECISION SCALE</span> →
        <span className="text-amber-400">GRAVIMETRIC TEST</span> →
        <span className="text-emerald-400 font-bold bg-emerald-950 px-2 py-1 rounded border border-emerald-800">
          PASS / CERTIFIED
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Calibration Points Table */}
        <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-3">
          <div className="flex justify-between items-center">
            <span className="font-bold text-slate-200">GRAVIMETRIC CALIBRATION DATA</span>
            <button
              onClick={handleRunCalibrationRun}
              disabled={isCalibrating}
              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] rounded border border-slate-700 flex items-center gap-1"
            >
              <RefreshCw className={`w-3 h-3 ${isCalibrating ? 'animate-spin' : ''}`} />
              RE-RUN BENCH
            </button>
          </div>

          <table className="w-full text-left text-[11px]">
            <thead className="text-slate-500 border-b border-slate-800 text-[10px]">
              <tr>
                <th className="pb-1">COMMANDED</th>
                <th className="pb-1">MEASURED</th>
                <th className="pb-1">ERROR %</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {points.map((p, idx) => (
                <tr key={idx}>
                  <td className="py-1.5 text-slate-300 font-bold">{p.commandedFlow.toFixed(1)} L/min</td>
                  <td className="py-1.5 text-emerald-400 font-bold">{p.measuredFlow.toFixed(2)} L/min</td>
                  <td
                    className={`py-1.5 font-bold ${
                      Math.abs(p.errorPercent) < 0.3 ? 'text-emerald-400' : 'text-amber-400'
                    }`}
                  >
                    {p.errorPercent > 0 ? `+${p.errorPercent}` : p.errorPercent} %
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Calibration Curve Graph */}
        <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col justify-between">
          <div className="text-[10px] text-slate-400 font-bold mb-1">CALIBRATION CURVE (COMMANDED VS MEASURED)</div>
          <div className="w-full h-36">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={points}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="commandedFlow" stroke="#64748b" tick={{ fontSize: 9 }} />
                <YAxis stroke="#10b981" tick={{ fontSize: 9 }} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155' }} />
                <Line type="monotone" dataKey="measuredFlow" stroke="#10b981" strokeWidth={2} dot={{ r: 4 }} />
                <Line type="monotone" dataKey="commandedFlow" stroke="#64748b" strokeDasharray="5 5" />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[10px] bg-slate-900 p-2 rounded border border-slate-800/80">
            <div>
              GAIN FACTOR: <span className="font-bold text-emerald-400">0.9985</span>
            </div>
            <div>
              REPEATABILITY: <span className="font-bold text-cyan-400">0.08 %</span>
            </div>
          </div>
        </div>
      </div>

      <button
        onClick={onGenerateCertificate}
        className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold flex items-center justify-center gap-2 border border-emerald-500 shadow-lg text-xs"
      >
        <FileText className="w-4 h-4" /> GENERATE OFFICIAL DIGITAL THREAD CALIBRATION CERTIFICATE
      </button>
    </div>
  );
};
