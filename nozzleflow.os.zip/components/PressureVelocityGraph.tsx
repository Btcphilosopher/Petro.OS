'use client';

import React, { useState } from 'react';
import { PositionProfilePoint } from '../lib/types';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  LineChart,
  Line,
} from 'recharts';
import { Activity, Gauge, Zap } from 'lucide-react';

interface PressureVelocityGraphProps {
  points: PositionProfilePoint[];
  nozzleLengthMm: number;
}

export const PressureVelocityGraph: React.FC<PressureVelocityGraphProps> = ({ points, nozzleLengthMm }) => {
  const [scrubPositionMm, setScrubPositionMm] = useState<number>(nozzleLengthMm * 0.65);

  // Find closest profile point to scrub position
  const closestPoint =
    points.reduce((prev, curr) =>
      Math.abs(curr.positionMm - scrubPositionMm) < Math.abs(prev.positionMm - scrubPositionMm) ? curr : prev
    ) || points[0];

  return (
    <div className="w-full bg-slate-900/90 backdrop-blur-md rounded-xl border border-slate-800 p-4 font-mono flex flex-col gap-4 text-xs">
      <div className="flex items-center justify-between border-b border-slate-800 pb-2">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-emerald-400" />
          <h3 className="font-bold text-slate-100 text-sm">AXIAL FLUID PROFILES (1D NAVIER-STOKES)</h3>
        </div>

        <div className="flex items-center gap-3 text-[11px]">
          <span className="flex items-center gap-1 text-cyan-400">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 inline-block" /> Pressure (bar)
          </span>
          <span className="flex items-center gap-1 text-amber-400">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 inline-block" /> Velocity (m/s)
          </span>
        </div>
      </div>

      {/* Scrub Position Control */}
      <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 flex items-center gap-4">
        <div className="flex items-center gap-2 font-bold text-slate-300 min-w-fit">
          <Gauge className="w-4 h-4 text-cyan-400" />
          SCRUB AXIAL POSITION Z:
        </div>
        <input
          type="range"
          min={0}
          max={nozzleLengthMm}
          step={0.5}
          value={scrubPositionMm}
          onChange={(e) => setScrubPositionMm(parseFloat(e.target.value))}
          className="w-full accent-cyan-400 cursor-pointer"
        />
        <div className="bg-slate-900 px-3 py-1 rounded border border-slate-700 text-cyan-400 font-bold min-w-fit">
          {scrubPositionMm.toFixed(1)} mm
        </div>
      </div>

      {/* Local Section Metrology Callout at Scrub Position */}
      {closestPoint && (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-2 bg-slate-950/80 p-2.5 rounded-lg border border-slate-800 text-[11px]">
          <div>
            <div className="text-slate-500">SECTION</div>
            <div className="font-bold text-slate-100">{closestPoint.section}</div>
          </div>
          <div>
            <div className="text-slate-500">LOCAL INNER DIA</div>
            <div className="font-bold text-amber-400">{closestPoint.diameterMm} mm</div>
          </div>
          <div>
            <div className="text-slate-500">STATIC PRESSURE</div>
            <div className="font-bold text-cyan-400">{closestPoint.pressureBar} bar</div>
          </div>
          <div>
            <div className="text-slate-500">LOCAL VELOCITY</div>
            <div className="font-bold text-emerald-400">{closestPoint.velocityMs} m/s</div>
          </div>
          <div>
            <div className="text-slate-500">EST. TEMP</div>
            <div className="font-bold text-purple-400">{closestPoint.temperatureC} °C</div>
          </div>
        </div>
      )}

      {/* Dual Graphs: Pressure & Velocity */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 h-48">
        {/* Pressure vs Position */}
        <div className="w-full h-full bg-slate-950/90 rounded-lg p-2 border border-slate-800/80">
          <div className="text-[10px] text-slate-400 font-bold mb-1">PRESSURE VS POSITION Z</div>
          <ResponsiveContainer width="100%" height="85%">
            <AreaChart data={points}>
              <defs>
                <linearGradient id="pressGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#38bdf8" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="positionMm" stroke="#64748b" tick={{ fontSize: 10 }} />
              <YAxis stroke="#38bdf8" tick={{ fontSize: 10 }} domain={['auto', 'auto']} />
              <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155' }} />
              <Area type="monotone" dataKey="pressureBar" stroke="#38bdf8" strokeWidth={2} fill="url(#pressGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Velocity vs Position */}
        <div className="w-full h-full bg-slate-950/90 rounded-lg p-2 border border-slate-800/80">
          <div className="text-[10px] text-slate-400 font-bold mb-1">VELOCITY VS POSITION Z</div>
          <ResponsiveContainer width="100%" height="85%">
            <AreaChart data={points}>
              <defs>
                <linearGradient id="velGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="positionMm" stroke="#64748b" tick={{ fontSize: 10 }} />
              <YAxis stroke="#f59e0b" tick={{ fontSize: 10 }} domain={['auto', 'auto']} />
              <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155' }} />
              <Area type="monotone" dataKey="velocityMs" stroke="#f59e0b" strokeWidth={2} fill="url(#velGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
