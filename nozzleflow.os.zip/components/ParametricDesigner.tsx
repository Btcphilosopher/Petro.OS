'use client';

import React from 'react';
import {
  NozzleGeometry,
  InternalProfileType,
  FittingType,
  SprayPattern,
  MaterialProperty,
} from '../lib/types';
import { Sliders, Layers, Cpu, Wrench } from 'lucide-react';

interface ParametricDesignerProps {
  geometry: NozzleGeometry;
  materials: MaterialProperty[];
  selectedMaterialId: string;
  onChangeGeometry: (newGeo: NozzleGeometry) => void;
  onChangeMaterial: (matId: string) => void;
}

export const ParametricDesigner: React.FC<ParametricDesignerProps> = ({
  geometry,
  materials,
  selectedMaterialId,
  onChangeGeometry,
  onChangeMaterial,
}) => {
  const updateField = <K extends keyof NozzleGeometry>(field: K, val: NozzleGeometry[K]) => {
    onChangeGeometry({
      ...geometry,
      [field]: val,
    });
  };

  return (
    <div className="w-full bg-slate-900/90 backdrop-blur-md rounded-xl border border-slate-800 p-4 font-mono flex flex-col gap-5 text-xs">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-cyan-400" />
          <h2 className="font-bold text-slate-100 text-sm tracking-wide">PARAMETRIC NOZZLE DESIGNER</h2>
        </div>
        <span className="text-[10px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
          REAL-TIME 3D RE-MESH
        </span>
      </div>

      {/* Primary Dimensions */}
      <div className="space-y-4">
        <div className="text-slate-400 font-bold text-[11px] uppercase flex items-center gap-1.5 text-cyan-400">
          <Layers className="w-3.5 h-3.5" /> GEOMETRIC BOUNDING DIMENSIONS
        </div>

        {/* Orifice Diameter */}
        <div className="bg-slate-950 p-3 rounded-lg border border-slate-800/90 space-y-2">
          <div className="flex justify-between font-bold">
            <span className="text-amber-400">ORIFICE DIAMETER</span>
            <span className="text-slate-200">{geometry.orificeDiameter.toFixed(1)} mm</span>
          </div>
          <input
            type="range"
            min={0.5}
            max={20.0}
            step={0.1}
            value={geometry.orificeDiameter}
            onChange={(e) => updateField('orificeDiameter', parseFloat(e.target.value))}
            className="w-full accent-amber-500 cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-slate-500">
            <span>0.5 mm</span>
            <span>Micro-Metering</span>
            <span>20.0 mm</span>
          </div>
        </div>

        {/* Inlet Diameter */}
        <div className="space-y-1">
          <div className="flex justify-between">
            <span className="text-slate-300">Inlet Diameter</span>
            <span className="text-cyan-400 font-bold">{geometry.inletDiameter.toFixed(1)} mm</span>
          </div>
          <input
            type="range"
            min={5.0}
            max={50.0}
            step={0.5}
            value={geometry.inletDiameter}
            onChange={(e) => updateField('inletDiameter', parseFloat(e.target.value))}
            className="w-full accent-cyan-500 cursor-pointer"
          />
        </div>

        {/* Throat Diameter */}
        <div className="space-y-1">
          <div className="flex justify-between">
            <span className="text-slate-300">Throat Diameter</span>
            <span className="text-emerald-400 font-bold">{geometry.throatDiameter.toFixed(1)} mm</span>
          </div>
          <input
            type="range"
            min={1.0}
            max={35.0}
            step={0.5}
            value={geometry.throatDiameter}
            onChange={(e) => updateField('throatDiameter', parseFloat(e.target.value))}
            className="w-full accent-emerald-500 cursor-pointer"
          />
        </div>

        {/* Outlet Diameter */}
        <div className="space-y-1">
          <div className="flex justify-between">
            <span className="text-slate-300">Outlet Diameter</span>
            <span className="text-slate-200 font-bold">{geometry.outletDiameter.toFixed(1)} mm</span>
          </div>
          <input
            type="range"
            min={2.0}
            max={40.0}
            step={0.5}
            value={geometry.outletDiameter}
            onChange={(e) => updateField('outletDiameter', parseFloat(e.target.value))}
            className="w-full accent-slate-400 cursor-pointer"
          />
        </div>

        {/* Nozzle Total Length */}
        <div className="space-y-1">
          <div className="flex justify-between">
            <span className="text-slate-300">Nozzle Length</span>
            <span className="text-purple-400 font-bold">{geometry.nozzleLength.toFixed(1)} mm</span>
          </div>
          <input
            type="range"
            min={20.0}
            max={200.0}
            step={1.0}
            value={geometry.nozzleLength}
            onChange={(e) => updateField('nozzleLength', parseFloat(e.target.value))}
            className="w-full accent-purple-500 cursor-pointer"
          />
        </div>

        {/* Wall Thickness */}
        <div className="space-y-1">
          <div className="flex justify-between">
            <span className="text-slate-300">Wall Thickness</span>
            <span className="text-slate-200 font-bold">{geometry.wallThickness.toFixed(1)} mm</span>
          </div>
          <input
            type="range"
            min={1.0}
            max={12.0}
            step={0.5}
            value={geometry.wallThickness}
            onChange={(e) => updateField('wallThickness', parseFloat(e.target.value))}
            className="w-full accent-slate-400 cursor-pointer"
          />
        </div>

        {/* Surface Finish Ra */}
        <div className="space-y-1">
          <div className="flex justify-between">
            <span className="text-slate-300">Surface Finish (Ra)</span>
            <span className="text-amber-300 font-bold">{geometry.surfaceFinishRa.toFixed(2)} µm</span>
          </div>
          <input
            type="range"
            min={0.1}
            max={3.2}
            step={0.05}
            value={geometry.surfaceFinishRa}
            onChange={(e) => updateField('surfaceFinishRa', parseFloat(e.target.value))}
            className="w-full accent-amber-400 cursor-pointer"
          />
        </div>
      </div>

      {/* Internal Profile & Fittings */}
      <div className="space-y-3 pt-2 border-t border-slate-800">
        <div className="text-slate-400 font-bold text-[11px] uppercase flex items-center gap-1.5 text-emerald-400">
          <Cpu className="w-3.5 h-3.5" /> INTERNAL PROFILE & SPRAY GEOMETRY
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="text-[10px] text-slate-400 mb-1 block">INTERNAL CONTOUR</label>
            <select
              value={geometry.internalProfile}
              onChange={(e) => updateField('internalProfile', e.target.value as InternalProfileType)}
              className="w-full bg-slate-950 text-slate-200 p-2 rounded border border-slate-800 focus:outline-none focus:border-cyan-500"
            >
              <option value="CONICAL">Conical Taper</option>
              <option value="VENTURI">Venturi Recovery</option>
              <option value="BELL_AEROSPIKE">Bell Aerospike</option>
              <option value="MULTI_ORIFICE">Multi-Orifice</option>
              <option value="SWIRL">Swirl Atomizer</option>
            </select>
          </div>

          <div>
            <label className="text-[10px] text-slate-400 mb-1 block">SPRAY PATTERN</label>
            <select
              value={geometry.sprayPattern}
              onChange={(e) => updateField('sprayPattern', e.target.value as SprayPattern)}
              className="w-full bg-slate-950 text-slate-200 p-2 rounded border border-slate-800 focus:outline-none focus:border-cyan-500"
            >
              <option value="FULL_CONE">Full Cone</option>
              <option value="HOLLOW_CONE">Hollow Cone</option>
              <option value="FLAT_FAN">Flat Fan</option>
              <option value="SOLID_STREAM">Solid Stream</option>
              <option value="MIST">Micro Mist Atomization</option>
            </select>
          </div>
        </div>

        <div>
          <label className="text-[10px] text-slate-400 mb-1 block">INLET FITTING CONNECTION</label>
          <select
            value={geometry.inletConnection}
            onChange={(e) => updateField('inletConnection', e.target.value as FittingType)}
            className="w-full bg-slate-950 text-slate-200 p-2 rounded border border-slate-800 focus:outline-none focus:border-cyan-500"
          >
            <option value="NPT_1_2">1/2&quot; NPT Threaded</option>
            <option value="NPT_3_4">3/4&quot; NPT Threaded</option>
            <option value="FLANGED_ANSI_150">ANSI 150# Flanged</option>
            <option value="TRI_CLAMP">Sanitary Tri-Clamp</option>
            <option value="QUICK_CONNECT">Industrial Quick Connect</option>
          </select>
        </div>
      </div>

      {/* Material Selection */}
      <div className="space-y-3 pt-2 border-t border-slate-800">
        <div className="text-slate-400 font-bold text-[11px] uppercase flex items-center gap-1.5 text-amber-400">
          <Wrench className="w-3.5 h-3.5" /> METALLURGY & MATERIAL SPEC
        </div>

        <select
          value={selectedMaterialId}
          onChange={(e) => onChangeMaterial(e.target.value)}
          className="w-full bg-slate-950 text-amber-300 font-bold p-2.5 rounded border border-amber-900/50 focus:outline-none focus:border-amber-500"
        >
          {materials.map((m) => (
            <option key={m.id} value={m.id}>
              {m.name} (${m.costPerKg}/kg)
            </option>
          ))}
        </select>
      </div>
    </div>
  );
};
