'use client';

import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

interface TestRig3DCanvasProps {
  pumpActive: boolean;
  pressureBar: number;
  flowLmin: number;
  tempC: number;
  fluidName: string;
  transferredMassKg: number;
}

export const TestRig3DCanvas: React.FC<TestRig3DCanvasProps> = ({
  pumpActive,
  pressureBar,
  flowLmin,
  tempC,
  fluidName,
  transferredMassKg,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const animFrameRef = useRef<number | null>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#0a0f1d');

    const width = container.clientWidth || 500;
    const height = container.clientHeight || 350;

    const camera = new THREE.PerspectiveCamera(45, width / height, 1, 1000);
    camera.position.set(0, 40, 110);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Lights
    const ambient = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambient);
    const dirLight = new THREE.DirectionalLight(0x38bdf8, 1.2);
    dirLight.position.set(50, 100, 50);
    scene.add(dirLight);

    // 1. Fluid Supply Reservoir Tank (Left)
    const tankGeo = new THREE.CylinderGeometry(15, 15, 30, 32);
    const tankMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      metalness: 0.8,
      roughness: 0.3,
      transparent: true,
      opacity: 0.8,
    });
    const tank = new THREE.Mesh(tankGeo, tankMat);
    tank.position.set(-45, 0, 0);
    scene.add(tank);

    // 2. Centrifugal Pump Assembly
    const pumpGeo = new THREE.BoxGeometry(16, 16, 16);
    const pumpMat = new THREE.MeshStandardMaterial({ color: 0xeab308, metalness: 0.8 }); // Yellow industrial pump
    const pump = new THREE.Mesh(pumpGeo, pumpMat);
    pump.position.set(-20, -7, 0);
    scene.add(pump);

    // 3. Pipe Loop from Reservoir -> Pump -> Nozzle
    const pipeMat = new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.9, roughness: 0.2 });

    const pipe1Geo = new THREE.CylinderGeometry(2, 2, 12, 16);
    const pipe1 = new THREE.Mesh(pipe1Geo, pipeMat);
    pipe1.rotation.z = Math.PI / 2;
    pipe1.position.set(-32.5, -7, 0);
    scene.add(pipe1);

    const pipe2Geo = new THREE.CylinderGeometry(2, 2, 40, 16);
    const pipe2 = new THREE.Mesh(pipe2Geo, pipeMat);
    pipe2.rotation.z = Math.PI / 2;
    pipe2.position.set(0, -7, 0);
    scene.add(pipe2);

    // 4. Test Nozzle Mounting Block (Center)
    const nozzleGeo = new THREE.CylinderGeometry(4, 3, 14, 24);
    const nozzleMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.9 });
    const nozzle = new THREE.Mesh(nozzleGeo, nozzleMat);
    nozzle.rotation.z = Math.PI / 2;
    nozzle.position.set(22, -7, 0);
    scene.add(nozzle);

    // 5. Catch Collection Tank with Load Cell Scale (Right)
    const catchGeo = new THREE.CylinderGeometry(14, 14, 25, 32);
    const catchMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.7, transparent: true, opacity: 0.7 });
    const catchTank = new THREE.Mesh(catchGeo, catchMat);
    catchTank.position.set(45, -5, 0);
    scene.add(catchTank);

    // Grid Base
    const grid = new THREE.GridHelper(200, 20, 0x334155, 0x0f172a);
    grid.position.y = -22;
    scene.add(grid);

    // Animation Loop
    let t = 0;
    const animate = () => {
      animFrameRef.current = requestAnimationFrame(animate);

      if (pumpActive) {
        t += flowLmin / 100.0;
        pump.rotation.x += 0.2; // spin pump casing
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      renderer.dispose();
    };
  }, [pumpActive, flowLmin]);

  return (
    <div className="w-full bg-slate-900 rounded-xl border border-slate-800 p-4 flex flex-col gap-4 shadow-xl">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-mono font-bold text-slate-100 flex items-center gap-2">
            <span className={`w-2.5 h-2.5 rounded-full ${pumpActive ? 'bg-emerald-400 animate-ping' : 'bg-slate-600'}`} />
            VIRTUAL FLOW CALIBRATION RIG & BENCH
          </h3>
          <p className="text-xs font-mono text-slate-400">TEST FLUID: {fluidName}</p>
        </div>

        <div className="px-3 py-1 bg-slate-950 rounded border border-slate-800 text-xs font-mono text-emerald-400 font-bold">
          STATUS: {pumpActive ? 'PUMP ACTIVE (FLOWING)' : 'RIG STANDBY'}
        </div>
      </div>

      <div ref={containerRef} className="w-full h-64 rounded-lg overflow-hidden border border-slate-800 relative" />

      {/* Live Test Rig Gauges */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 font-mono text-xs">
        <div className="bg-slate-950 p-2.5 rounded border border-slate-800/80">
          <div className="text-slate-400 text-[10px]">INLET PRESSURE</div>
          <div className="text-sm font-bold text-cyan-400">{pressureBar.toFixed(2)} bar</div>
        </div>
        <div className="bg-slate-950 p-2.5 rounded border border-slate-800/80">
          <div className="text-slate-400 text-[10px]">CORIOLIS FLOW RATE</div>
          <div className="text-sm font-bold text-emerald-400">{flowLmin.toFixed(2)} L/min</div>
        </div>
        <div className="bg-slate-950 p-2.5 rounded border border-slate-800/80">
          <div className="text-slate-400 text-[10px]">FLUID TEMP RTD</div>
          <div className="text-sm font-bold text-amber-400">{tempC.toFixed(1)} °C</div>
        </div>
        <div className="bg-slate-950 p-2.5 rounded border border-slate-800/80">
          <div className="text-slate-400 text-[10px]">WEIGH SCALE CATCH</div>
          <div className="text-sm font-bold text-purple-400">{transferredMassKg.toFixed(2)} kg</div>
        </div>
      </div>
    </div>
  );
};
