'use client';

import React, { useState } from 'react';
import { InspectionDimension, MonteCarloResult, NozzleGeometry, FluidProperty } from '../lib/types';
import { runMonteCarloToleranceAnalysis } from '../lib/toleranceEngine';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { Ruler, Dice5, CheckCircle, AlertTriangle } from 'lucide-react';

interface MetrologyViewProps {
  metrology: InspectionDimension[];
  geometry: NozzleGeometry;
  fluid: FluidProperty;
  inletPressureBar: number;
  outletPressureBar: number;
  tempC: number;
}

export const MetrologyView: React.FC<MetrologyViewProps> = ({
  metrology,
  geometry,
  fluid,
  inletPressureBar,
  outletPressureBar,
  tempC,
}) => {
  const [mcResult, setMcResult] = useState<MonteCarloResult | null>(() =>
    runMonteCarloToleranceAnalysis(geometry, fluid, inletPressureBar, outletPressureBar, tempC)
  );
  const [isSimulating, setIsSimulating] = useState(false);

  const handleRunMonteCarlo = () => {
    setIsSimulating(true);
    setTimeout(() => {
      const res = runMonteCarloToleranceAnalysis(geometry, fluid, inletPressureBar, outletPressureBar, tempC);
      setMcResult(res);
      setIsSimulating(false);
    }, 200);
  };

  return (
    <div className="w-full bg-slate-900/90 backdrop-blur-md rounded-xl border border-slate-800 p-4 font-mono flex flex-col gap-5 text-xs">
      <div className="flex items-center justify-between border-b border-slate-800 pb-2">
        <div className="flex items-center gap-2">
          <Ruler className="w-4 h-4 text-cyan-400" />
          <h3 className="font-bold text-slate-100 text-sm">CMM DIMENSIONAL METROLOGY & TOLERANCE ANALYSIS</h3>
        </div>
        <span className="text-[10px] text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800">
          ZEISS CONTURA CMM PROBE
        </span>
      </div>

      {/* CMM Inspection Table */}
      <div className="space-y-2">
        <div className="text-slate-300 font-bold text-xs uppercase">DIMENSIONAL METROLOGY INSPECTION RECORD</div>
        <div className="overflow-x-auto rounded-lg border border-slate-800">
          <table className="w-full text-left bg-slate-950">
            <thead className="bg-slate-900 text-slate-400 text-[10px] uppercase border-b border-slate-800">
              <tr>
                <th className="p-2.5">INSPECTED FEATURE</th>
                <th className="p-2.5">DESIGN VALUE</th>
                <th className="p-2.5">MEASURED VALUE</th>
                <th className="p-2.5">TOLERANCE</th>
                <th className="p-2.5">DEVIATION</th>
                <th className="p-2.5">QA STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-[11px]">
              {metrology.map((item) => {
                const deviation = item.measuredValue - item.designValue;
                return (
                  <tr key={item.id} className="hover:bg-slate-900/50 transition-colors">
                    <td className="p-2.5 font-bold text-slate-200">{item.feature}</td>
                    <td className="p-2.5 text-slate-400">
                      {item.designValue.toFixed(3)} {item.unit}
                    </td>
                    <td className="p-2.5 font-mono text-cyan-300 font-bold">
                      {item.measuredValue.toFixed(3)} {item.unit}
                    </td>
                    <td className="p-2.5 text-slate-400">± {item.tolerancePlus.toFixed(3)}</td>
                    <td className={`p-2.5 font-mono ${deviation >= 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
                      {deviation > 0 ? `+${deviation.toFixed(3)}` : deviation.toFixed(3)}
                    </td>
                    <td className="p-2.5">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800 flex items-center gap-1 w-fit">
                        <CheckCircle className="w-3 h-3" /> PASS
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Monte Carlo Tolerance Propagation Engine */}
      <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <Dice5 className="w-4 h-4 text-purple-400" />
            <h4 className="font-bold text-slate-100 text-xs uppercase">
              MONTE CARLO TOLERANCE PROPAGATION ENGINE (N = 1,000 SAMPLES)
            </h4>
          </div>

          <button
            onClick={handleRunMonteCarlo}
            disabled={isSimulating}
            className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded font-bold transition-all text-xs border border-purple-500 shadow-md"
          >
            {isSimulating ? 'SIMULATING N=1000...' : 'RE-RUN MONTE CARLO'}
          </button>
        </div>

        {mcResult && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-5 gap-2 text-[11px]">
              <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                <div className="text-slate-500">MEAN FLOW</div>
                <div className="font-bold text-slate-100 text-sm">{mcResult.meanFlowLmin} L/min</div>
              </div>
              <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                <div className="text-slate-500">P5 PERCENTILE</div>
                <div className="font-bold text-cyan-400 text-sm">{mcResult.p5FlowLmin} L/min</div>
              </div>
              <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                <div className="text-slate-500">P50 MEDIAN</div>
                <div className="font-bold text-emerald-400 text-sm">{mcResult.p50FlowLmin} L/min</div>
              </div>
              <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                <div className="text-slate-500">P95 PERCENTILE</div>
                <div className="font-bold text-amber-400 text-sm">{mcResult.p95FlowLmin} L/min</div>
              </div>
              <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                <div className="text-slate-500">DEFECT RISK (%)</div>
                <div className="font-bold text-purple-400 text-sm">{mcResult.defectRiskPercent} %</div>
              </div>
            </div>

            {/* Recharts Distribution Histogram */}
            <div className="w-full h-40 bg-slate-900/80 p-2 rounded border border-slate-800">
              <div className="text-[10px] text-slate-400 font-bold mb-1">
                MONTE CARLO PERFORMANCE DISTRIBUTION (FLOW RATE L/MIN)
              </div>
              <ResponsiveContainer width="100%" height="85%">
                <BarChart data={mcResult.distribution}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="flowBin" stroke="#64748b" tick={{ fontSize: 9 }} />
                  <YAxis stroke="#a855f7" tick={{ fontSize: 9 }} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155' }} />
                  <Bar dataKey="count" fill="#a855f7" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
