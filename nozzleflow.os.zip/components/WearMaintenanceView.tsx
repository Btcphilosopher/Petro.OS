'use client';

import React from 'react';
import { NozzleDigitalTwin, FluidProperty } from '../lib/types';
import { calculateErosionWearIndex } from '../lib/wearEngine';
import { Wrench, ShieldAlert, Clock, Activity } from 'lucide-react';

interface WearMaintenanceViewProps {
  twin: NozzleDigitalTwin;
  fluid: FluidProperty;
  throatVelocityMs: number;
}

export const WearMaintenanceView: React.FC<WearMaintenanceViewProps> = ({
  twin,
  fluid,
  throatVelocityMs,
}) => {
  const wear = calculateErosionWearIndex(twin, fluid, throatVelocityMs);

  return (
    <div className="w-full bg-slate-900/90 backdrop-blur-md rounded-xl border border-slate-800 p-4 font-mono flex flex-col gap-4 text-xs">
      <div className="flex items-center justify-between border-b border-slate-800 pb-2">
        <div className="flex items-center gap-2">
          <Wrench className="w-4 h-4 text-amber-400" />
          <h3 className="font-bold text-slate-100 text-sm">NOZZLE EROSION WEAR & LIFECYCLE DIGITAL TWIN</h3>
        </div>
        <span className="text-[10px] text-amber-400 bg-amber-950 px-2 py-0.5 rounded border border-amber-800 font-bold">
          MODELLED ESTIMATE
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Wear Meter Card */}
        <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col justify-between">
          <div className="text-slate-400 font-bold text-xs uppercase mb-2">ORIFICE EROSION WEAR INDEX</div>

          <div className="space-y-2">
            <div className="flex justify-between items-baseline font-bold">
              <span className="text-3xl text-amber-400">{wear.wearIndexPercent} %</span>
              <span
                className={`px-2 py-0.5 rounded text-[10px] ${
                  wear.maintenanceStatus === 'OPTIMAL'
                    ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                    : 'bg-amber-950 text-amber-400 border border-amber-800'
                }`}
              >
                {wear.maintenanceStatus}
              </span>
            </div>

            <div className="w-full h-3 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
              <div
                className={`h-full transition-all duration-500 ${
                  wear.wearIndexPercent > 75
                    ? 'bg-red-500'
                    : wear.wearIndexPercent > 40
                    ? 'bg-amber-500'
                    : 'bg-emerald-400'
                }`}
                style={{ width: `${wear.wearIndexPercent}%` }}
              />
            </div>
          </div>

          <div className="text-[10px] text-slate-500 mt-3 pt-2 border-t border-slate-800">
            NOTICE: WEAR INDEX IS A COMPUTER MODELLED ESTIMATE BASED ON FLUID VELOCITY AND OPERATING HOURS.
          </div>
        </div>

        {/* Operational Statistics */}
        <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2.5">
          <div className="text-slate-400 font-bold text-xs uppercase">SERVICE HISTORY & COUNTERS</div>

          <div className="grid grid-cols-2 gap-2 text-[11px]">
            <div className="bg-slate-900 p-2 rounded border border-slate-800">
              <div className="text-slate-500 text-[10px]">OPERATING HOURS</div>
              <div className="font-bold text-slate-100">{twin.operatingHours} hrs</div>
            </div>
            <div className="bg-slate-900 p-2 rounded border border-slate-800">
              <div className="text-slate-500 text-[10px]">TOTAL PRESSURE CYCLES</div>
              <div className="font-bold text-cyan-400">{twin.totalCycles} cycles</div>
            </div>
            <div className="bg-slate-900 p-2 rounded border border-slate-800">
              <div className="text-slate-500 text-[10px]">TOTAL MASS TRANSFERRED</div>
              <div className="font-bold text-purple-400">{twin.totalMassTransferredKg} kg</div>
            </div>
            <div className="bg-slate-900 p-2 rounded border border-slate-800">
              <div className="text-slate-500 text-[10px]">EST. REMAINING LIFE</div>
              <div className="font-bold text-emerald-400">{wear.remainingHoursEstimate} hrs</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
