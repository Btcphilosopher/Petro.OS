import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Endpoints for Supermajor Engine
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", engine: "Integrated Energy Supermajor Optimisation Engine", timestamp: new Date().toISOString() });
  });

  // Server-side Gemini proxy if needed for AI executive summaries
  app.post("/api/ai-insight", async (req, res) => {
    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(400).json({ error: "GEMINI_API_KEY environment variable is missing" });
      }
      const { prompt } = req.body;
      const { GoogleGenAI } = await import("@google/genai");
      const ai = new GoogleGenAI({ apiKey });
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt || "Provide a 2-paragraph executive briefing on global energy market dynamics and capital allocation strategy for an integrated supermajor.",
      });
      res.json({ text: response.text });
    } catch (err: any) {
      console.error("AI Insight Error:", err);
      res.status(500).json({ error: err?.message || "Failed to generate AI insight" });
    }
  });

  // Vite middleware for development vs static production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Integrated Supermajor Engine running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
