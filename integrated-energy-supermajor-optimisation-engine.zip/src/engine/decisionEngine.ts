import { UniversalAsset } from "../types/asset";
import { MacroScenarioDefinition } from "../types/simulation";

export interface DecisionAnswer {
  question_id: string;
  question: string;
  recommendation_title: string;
  summary: string;
  key_metrics: { label: string; value: string; highlight?: boolean }[];
  action_plan: string[];
}

export function generateExecutiveDecisions(
  assets: UniversalAsset[],
  scenario: MacroScenarioDefinition,
  carbonTaxUsdTon: number
): DecisionAnswer[] {
  return [
    {
      question_id: "DEC_INVEST",
      question: "WHERE SHOULD THE SUPERMAJOR SPEND THE NEXT $1 BILLION CAPEX?",
      recommendation_title: "Prioritize Permian Infill Pad Expansion & Pasadena Pipeline Loop Debottlenecking",
      summary: "Combining Permian Upstream drilling ($850M, 28.5% IRR) with Pasadena pipeline loop expansion ($380M, 32.1% IRR) maximizes integrated enterprise margin unlock.",
      key_metrics: [
        { label: "Optimal Next Capex", value: "$1,000M" },
        { label: "Incremental Enterprise NPV", value: "+$1,620M", highlight: true },
        { label: "Blended IRR", value: "29.4%" },
        { label: "Payback Period", value: "2.2 Years" },
      ],
      action_plan: [
        "Sanction Permian Delaware 3-mile horizontal pad infills ($620M).",
        "Authorize Pasadena Express Pipeline loop debottlenecking (+100kbpd) ($380M).",
        "Defer lower-margin North Sea EOR polymer project ($450M) until oil exceeds $90/bbl.",
      ],
    },
    {
      question_id: "DEC_PRODUCE",
      question: "WHERE SHOULD THE SUPERMAJOR MAXIMIZE PRODUCTION RATES?",
      recommendation_title: "Max-Out Qatar LNG Gas Wells & Permian Delaware Basin Shale",
      summary: "Qatar North Field Gas lifting costs are under $4.20/MMBtu with TTF/JKM netbacks over $13.90/MMBtu. Permian Delaware yields low-cost light crude at $18.50/bbl lifting cost.",
      key_metrics: [
        { label: "Permian Target Flow", value: "215 kboed" },
        { label: "Qatar Gas Target Flow", value: "1,710 MMscfd", highlight: true },
        { label: "Upstream Free Cash Flow", value: "$3,850M/yr" },
      ],
      action_plan: [
        "Operate Qatar North Field gas wells at 98.5% capacity to supply Ras Laffan Trains 1-4.",
        "Maintain Permian drilling rig fleet at 12 active rigs to maintain plateau.",
      ],
    },
    {
      question_id: "DEC_CRUDE_SLATE",
      question: "WHICH CRUDE SLATE SHOULD EACH REFINERY PROCESS?",
      recommendation_title: "Rotterdam: 65% Brent Sweet / 35% Arab Heavy | Pasadena: 100% Permian Light WTI",
      summary: "Refinery LP optimization reveals Rotterdam maximizes gross cracking margin by blending low-cost Arab Heavy ($72.40/bbl) with North Sea Brent ($82.50/bbl). Pasadena refinery captures full pipeline integration value with 100% Permian Light WTI.",
      key_metrics: [
        { label: "Rotterdam Gross Margin", value: "$14.80/bbl", highlight: true },
        { label: "Pasadena Gross Margin", value: "$16.20/bbl", highlight: true },
        { label: "Combined Daily Margin", value: "$15.1M / Day" },
      ],
      action_plan: [
        "Procure 130kbpd Arab Heavy crude via long-term charter for Rotterdam CDU-2.",
        "Direct 100% of Pasadena Express pipeline crude directly into Pasadena CDU-1.",
      ],
    },
    {
      question_id: "DEC_EXPAND_SHUT",
      question: "WHICH ASSETS SHOULD BE EXPANDED AND WHICH SHUT DOWN?",
      recommendation_title: "Expand Pasadena Pipeline & Ras Laffan LNG; Phase-Out High-Emission Assets",
      summary: "Pasadena pipeline operates at 94.2% capacity constraint with $125k/day shadow price. North Sea Forties field operates near end-of-life with $28/bbl lifting cost and high carbon liability.",
      key_metrics: [
        { label: "Assets to Expand", value: "Pasadena Pipe & Ras Laffan Train 5" },
        { label: "Assets to Rationalize", value: "North Sea Forties Platform A" },
        { label: "Capital Freed", value: "$450M" },
      ],
      action_plan: [
        "Approve $380M Pasadena Pipeline Expansion (+100 kbpd).",
        "Approve $2.4B Ras Laffan LNG Train 5 Expansion (+8 MTPA).",
        "Initiate cessation-of-production review for mature North Sea wells by 2029.",
      ],
    },
    {
      question_id: "DEC_CARBON",
      question: "HOW DOES CARBON TAX (£0-£500/t) ALTER ENTERPRISE VALUATION?",
      recommendation_title: "At $65/t Carbon Tax, CCS Investment Unlocks $740M NPV; At $150/t, Green H2 Dominates",
      summary: `At current $${carbonTaxUsdTon}/t CO2 tax, total enterprise carbon liability is $${Math.round(9.8 * carbonTaxUsdTon)}M/yr. Investing $620M in Rotterdam CCS abates 3.4 MT/yr CO2, providing immediate tax relief and generating carbon credits.`,
      key_metrics: [
        { label: "Current Carbon Liability", value: `$${Math.round(9.8 * carbonTaxUsdTon)}M/yr` },
        { label: "Rotterdam CCS Abatement", value: "3.4 MT CO2/yr", highlight: true },
        { label: "Break-even Carbon Price", value: "$42/ton CO2" },
      ],
      action_plan: [
        "Sanction Rotterdam Refinery CCS & Northern Lights subsea storage integration.",
        "Expand Neom Green Hydrogen Phase 2 electrolysers to hedge future $150/t carbon taxes.",
      ],
    },
  ];
}
