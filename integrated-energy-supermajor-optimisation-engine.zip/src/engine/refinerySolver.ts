import { CrudeAssay, RefinerySlateOptimizationResult } from "../types/refining";
import { CommodityPrices } from "../types/simulation";

export function calculateCrudeRefineryValue(
  crude: CrudeAssay,
  prices: CommodityPrices,
  refineryCapexOpexModifier: number = 1.0
): {
  gross_product_value_per_bbl: number;
  refining_cost_per_bbl: number;
  freight_cost_per_bbl: number;
  netback_refinery_margin_per_bbl: number;
} {
  const { yields } = crude;

  // Commodity price conversions to $/bbl
  const gasolinePrice = prices.brent_crude_usd_bbl + prices.refining_nwe_cracking_margin_usd_bbl * 1.25;
  const dieselPrice = prices.brent_crude_usd_bbl + prices.refining_nwe_cracking_margin_usd_bbl * 1.15;
  const jetPrice = prices.brent_crude_usd_bbl + prices.refining_nwe_cracking_margin_usd_bbl * 1.20;
  const fuelOilPrice = prices.brent_crude_usd_bbl * 0.72;
  const lpgPrice = prices.brent_crude_usd_bbl * 0.65;
  const naphthaPrice = prices.brent_crude_usd_bbl * 0.88;

  // Mass weighted yield value $/bbl
  const grossProductValue =
    (yields.gasoline_blendstock / 100) * gasolinePrice +
    (yields.diesel_gasoil / 100) * dieselPrice +
    (yields.kerosene_jet / 100) * jetPrice +
    (yields.residue / 100) * fuelOilPrice +
    (yields.lpg / 100) * lpgPrice +
    (yields.naphtha / 100) * naphthaPrice +
    (yields.vacuum_gas_oil / 100) * (dieselPrice * 0.85);

  // Desulphurization and heavy processing penalty based on sulphur and API gravity
  const sulphurPenalty = crude.sulphur_weight_pct * 1.45; // $/bbl penalty for hydrotreating
  const heavyProcessingPenalty = Math.max(0, (35.0 - crude.api_gravity) * 0.25);

  const totalProcessingCost = (4.50 + sulphurPenalty + heavyProcessingPenalty) * refineryCapexOpexModifier;
  const freightCost = crude.freight_to_refinery;

  const deliveredCost = crude.purchase_price_fob + freightCost;
  const netbackMargin = grossProductValue - deliveredCost - totalProcessingCost;

  return {
    gross_product_value_per_bbl: grossProductValue,
    refining_cost_per_bbl: totalProcessingCost,
    freight_cost_per_bbl: freightCost,
    netback_refinery_margin_per_bbl: netbackMargin,
  };
}

export function optimizeRefinerySlate(
  refinery_id: string,
  refinery_name: string,
  capacity_bpd: number,
  availableCrudes: CrudeAssay[],
  prices: CommodityPrices,
  carbonTaxUsdTon: number = 65.0
): RefinerySlateOptimizationResult {
  // Rank crudes by Netback Refinery Margin $/bbl
  const evaluatedCrudes = availableCrudes.map((crude) => {
    const calc = calculateCrudeRefineryValue(crude, prices);
    // Carbon penalty per bbl refined (Heavy crudes produce more CO2 in hydrocrackers)
    const carbonPenaltyPerBbl = (0.045 + (38 - crude.api_gravity) * 0.002) * (carbonTaxUsdTon / 1000) * 100;
    const adjustedMargin = calc.netback_refinery_margin_per_bbl - carbonPenaltyPerBbl;
    return {
      crude,
      calc,
      adjustedMargin,
    };
  });

  // Sort descending by adjusted margin
  evaluatedCrudes.sort((a, b) => b.adjustedMargin - a.adjustedMargin);

  // Allocate crude slate (e.g. 60% top crude, 40% second crude for CDU metallurgical constraint)
  const topCrude = evaluatedCrudes[0];
  const secondCrude = evaluatedCrudes[1] || evaluatedCrudes[0];

  const topVol = capacity_bpd * 0.65;
  const secondVol = capacity_bpd * 0.35;

  const purchases = [
    {
      crude_id: topCrude.crude.crude_id,
      volume_bpd: topVol,
      delivered_cost_bbl: topCrude.crude.purchase_price_fob + topCrude.crude.freight_to_refinery,
      gross_margin_contribution_bbl: topCrude.adjustedMargin,
    },
    {
      crude_id: secondCrude.crude.crude_id,
      volume_bpd: secondVol,
      delivered_cost_bbl: secondCrude.crude.purchase_price_fob + secondCrude.crude.freight_to_refinery,
      gross_margin_contribution_bbl: secondCrude.adjustedMargin,
    },
  ];

  const blendedMargin = (topCrude.adjustedMargin * 0.65 + secondCrude.adjustedMargin * 0.35);
  const totalDailyMargin = blendedMargin * capacity_bpd;

  // Estimate yield breakdown
  const blendedGasoline = (topCrude.crude.yields.gasoline_blendstock * 0.65 + secondCrude.crude.yields.gasoline_blendstock * 0.35) / 100 * capacity_bpd;
  const blendedDiesel = (topCrude.crude.yields.diesel_gasoil * 0.65 + secondCrude.crude.yields.diesel_gasoil * 0.35) / 100 * capacity_bpd;
  const blendedJet = (topCrude.crude.yields.kerosene_jet * 0.65 + secondCrude.crude.yields.kerosene_jet * 0.35) / 100 * capacity_bpd;
  const blendedFuelOil = (topCrude.crude.yields.residue * 0.65 + secondCrude.crude.yields.residue * 0.35) / 100 * capacity_bpd;
  const blendedLpg = (topCrude.crude.yields.lpg * 0.65 + secondCrude.crude.yields.lpg * 0.35) / 100 * capacity_bpd;
  const blendedNaphtha = (topCrude.crude.yields.naphtha * 0.65 + secondCrude.crude.yields.naphtha * 0.35) / 100 * capacity_bpd;

  const annualCo2Ktons = (capacity_bpd * 365 * 0.042) / 1000;

  return {
    refinery_id,
    refinery_name,
    crude_purchases: purchases,
    total_crude_intake_bpd: capacity_bpd,
    total_product_yield_bpd: {
      gasoline: blendedGasoline,
      diesel: blendedDiesel,
      jet_fuel: blendedJet,
      fuel_oil: blendedFuelOil,
      lpg: blendedLpg,
      petrochem_feed: blendedNaphtha,
    },
    refinery_gross_margin_per_bbl: blendedMargin,
    total_daily_margin_usd: totalDailyMargin,
    co2_emissions_kton_yr: annualCo2Ktons,
    hydrogen_deficit_scfd: capacity_bpd * 180, // scf/bbl hydrotreater demand
  };
}
