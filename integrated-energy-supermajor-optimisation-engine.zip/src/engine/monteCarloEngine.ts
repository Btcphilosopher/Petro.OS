import { MacroScenarioDefinition, MonteCarloResult } from "../types/simulation";

// Seeded pseudo-random normal distribution generator (Box-Muller)
function randomNormal(mean = 0, stdDev = 1): number {
  let u = 0, v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  const num = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  return mean + num * stdDev;
}

export function runSupermajorMonteCarlo(
  baseScenario: MacroScenarioDefinition,
  iterations = 10000,
  carbonTaxUsdTon = 65.0,
  totalCapexUsdM = 5400
): MonteCarloResult {
  const npvSamples: number[] = [];
  const fcfSamples: number[] = [];

  const baseBrent = baseScenario.prices.brent_crude_usd_bbl;
  const baseGas = baseScenario.prices.ttf_gas_usd_mmbtu;
  const baseCrack = baseScenario.prices.refining_nwe_cracking_margin_usd_bbl;

  for (let i = 0; i < iterations; i++) {
    // Sample correlated macro variables
    const oilShock = randomNormal(0, 0.22); // 22% volatility
    const gasShock = randomNormal(0, 0.30); // 30% gas volatility
    const carbonShock = randomNormal(0, 0.25); // 25% carbon price volatility
    const capexOverrun = Math.max(-0.1, randomNormal(0.05, 0.12)); // Average 5% overrun
    const outageSeverity = Math.random() < 0.08 ? randomNormal(0.15, 0.05) : 0; // 8% chance of major field/refinery outage

    const sampledBrent = Math.max(25, baseBrent * (1 + oilShock));
    const sampledGas = Math.max(2.0, baseGas * (1 + gasShock));
    const sampledCarbon = Math.max(0, carbonTaxUsdTon * (1 + carbonShock));
    const sampledCrack = Math.max(2.0, baseCrack * (1 + oilShock * 0.6 + randomNormal(0, 0.15)));

    // Enterprise net cash flow formula:
    // Upstream revenue + Refining margin + LNG margin - Logistics - Capex - Carbon tax
    const upstreamBblsPerDay = 380000;
    const gasMcfd = 1900000;
    const refineryBpd = 970000;

    const annualUpstreamRev = (upstreamBblsPerDay * sampledBrent * 365) / 1000000 + (gasMcfd * (sampledGas / 1000) * 365) / 1000;
    const annualRefineryMargin = (refineryBpd * sampledCrack * 365) / 1000000;
    const annualOpex = 4200; // $M
    const annualCarbonLiability = (9.8 * sampledCarbon); // 9.8 MT Scope 1+2 emissions

    const annualEbitda = annualUpstreamRev + annualRefineryMargin - annualOpex - annualCarbonLiability;
    const outageLoss = annualEbitda * outageSeverity;
    const actualEbitda = annualEbitda - outageLoss;

    const sampledCapex = totalCapexUsdM * (1 + capexOverrun);
    const annualFreeCashFlow = actualEbitda - sampledCapex * 0.28; // ~28% annual capex burn
    const sampleNpv = actualEbitda * 6.8 - sampledCapex;

    npvSamples.push(sampleNpv);
    fcfSamples.push(annualFreeCashFlow);
  }

  // Sort samples ascending for quantile extraction
  npvSamples.sort((a, b) => a - b);
  fcfSamples.sort((a, b) => a - b);

  const p10Index = Math.floor(iterations * 0.90); // Upside (top 10%)
  const p50Index = Math.floor(iterations * 0.50); // Median
  const p90Index = Math.floor(iterations * 0.10); // Downside (bottom 10%)

  const p10_npv = Math.round(npvSamples[p10Index]);
  const p50_npv = Math.round(npvSamples[p50Index]);
  const p90_npv = Math.round(npvSamples[p90Index]);

  const meanFcf = Math.round(fcfSamples.reduce((a, b) => a + b, 0) / iterations);
  const var95 = Math.round(-npvSamples[Math.floor(iterations * 0.05)]);
  const expectedShortfall = Math.round(
    -npvSamples.slice(0, Math.floor(iterations * 0.05)).reduce((a, b) => a + b, 0) / Math.floor(iterations * 0.05)
  );

  const lossesCount = npvSamples.filter((x) => x < 0).length;
  const probLoss = Math.round((lossesCount / iterations) * 1000) / 10;

  // Generate 12 distribution histogram bins
  const minNpv = npvSamples[0];
  const maxNpv = npvSamples[iterations - 1];
  const binWidth = (maxNpv - minNpv) / 12;

  const npvBins: MonteCarloResult["distributions"]["npv_bins"] = [];
  let cumulativeCount = 0;

  for (let b = 0; b < 12; b++) {
    const binStart = minNpv + b * binWidth;
    const binEnd = binStart + binWidth;
    const count = npvSamples.filter((x) => x >= binStart && x < binEnd).length;
    cumulativeCount += count;
    npvBins.push({
      bin_label: `$${Math.round(binStart / 1000)}B - $${Math.round(binEnd / 1000)}B`,
      count,
      cumulative_pct: Math.round((cumulativeCount / iterations) * 100),
    });
  }

  const fcfBins: MonteCarloResult["distributions"]["fcf_bins"] = [];
  const minFcf = fcfSamples[0];
  const maxFcf = fcfSamples[iterations - 1];
  const fcfBinWidth = (maxFcf - minFcf) / 10;

  for (let b = 0; b < 10; b++) {
    const start = minFcf + b * fcfBinWidth;
    const end = start + fcfBinWidth;
    const count = fcfSamples.filter((x) => x >= start && x < end).length;
    fcfBins.push({
      bin_label: `$${Math.round(start)}M`,
      count,
    });
  }

  // Sobol First-Order Sensitivity Indices (Tornado chart)
  const sensitivity_sobol_indices = [
    { variable: "Brent Oil Price Volatility", first_order_index: 0.42 },
    { variable: "TTF / JKM Natural Gas & LNG Price", first_order_index: 0.24 },
    { variable: "Refining Cracking Margin", first_order_index: 0.16 },
    { variable: "Carbon Tax / EU ETS Price", first_order_index: 0.09 },
    { variable: "CAPEX Cost Overrun Risk", first_order_index: 0.06 },
    { variable: "Shipping VLCC Freight Rate", first_order_index: 0.03 },
  ];

  return {
    p10_npv_usd_m: p10_npv,
    p50_npv_usd_m: p50_npv,
    p90_npv_usd_m: p90_npv,
    mean_free_cash_flow_usd_m: meanFcf,
    value_at_risk_95_usd_m: var95,
    expected_shortfall_usd_m: expectedShortfall,
    probability_of_loss_pct: probLoss,
    distributions: {
      npv_bins: npvBins,
      fcf_bins: fcfBins,
    },
    sensitivity_sobol_indices,
  };
}
