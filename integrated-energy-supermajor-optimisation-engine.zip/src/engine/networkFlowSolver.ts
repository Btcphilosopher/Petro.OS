import { UniversalAsset } from "../types/asset";
import { NetworkEdge, BottleneckAnalysis } from "../types/simulation";

export function solveNetworkFlowAndBottlenecks(
  assets: UniversalAsset[],
  edges: NetworkEdge[]
): {
  bottlenecks: BottleneckAnalysis[];
  total_system_throughput_boe: number;
  total_logistics_cost_usd_m: number;
  unconstrained_value_loss_usd_m: number;
} {
  const bottlenecks: BottleneckAnalysis[] = [];

  // Identify assets operating above 92% capacity utilization or with explicit bottleneck flag
  for (const asset of assets) {
    if (asset.utilisation >= 89.0) {
      let constraintType: BottleneckAnalysis["constraint_type"] = "PHYSICAL_PIPELINE";
      if (asset.asset_type === "PIPELINE") constraintType = "PHYSICAL_PIPELINE";
      else if (asset.asset_type === "REFINERY") constraintType = "REFINERY_UNIT";
      else if (asset.asset_type === "TANKER") constraintType = "TANKER_FLEET";
      else if (asset.asset_type === "STORAGE") constraintType = "STORAGE_CAPACITY";
      else if (asset.asset_type === "POWER_PLANT") constraintType = "POWER_GRID";

      // Calculate shadow value of removing bottleneck
      // If we expand capacity by 10%, how much extra net margin flows through?
      const shadowValuePerDay = asset.capacity * (asset.utilisation / 100) * 8.50 * 0.15; // ~$8.50/bbl net margin unlock
      const expansionCapex = asset.capital_cost * 0.12; // 10% expansion cost
      const annualBenefit = shadowValuePerDay * 365 / 1000000;
      const paybackMonths = Math.round((expansionCapex / Math.max(0.1, annualBenefit)) * 12);
      const npv = annualBenefit * 6.5 - expansionCapex; // 10-year 8% discount factor ~6.5

      bottlenecks.push({
        asset_id: asset.asset_id,
        asset_name: asset.name,
        type: asset.asset_type,
        capacity: asset.capacity,
        current_throughput: Math.round(asset.capacity * (asset.utilisation / 100)),
        utilisation_pct: asset.utilisation,
        constraint_type: constraintType,
        bottleneck_value_usd_per_day: Math.round(shadowValuePerDay),
        expansion_capex_usd_m: Math.round(expansionCapex),
        expansion_payback_months: paybackMonths,
        expansion_npv_usd_m: Math.round(npv),
        recommendation: `Expand ${asset.name} by +15% capacity to capture $${Math.round(shadowValuePerDay / 1000)}k/day incremental flow margin.`,
      });
    }
  }

  // Sort bottlenecks descending by daily shadow value
  bottlenecks.sort((a, b) => b.bottleneck_value_usd_per_day - a.bottleneck_value_usd_per_day);

  const totalThroughput = assets
    .filter((a) => a.asset_type === "OIL_FIELD" || a.asset_type === "GAS_FIELD" || a.asset_type === "REFINERY")
    .reduce((acc, cur) => acc + cur.capacity * (cur.utilisation / 100), 0);

  const totalLogisticsCost = edges.reduce((acc, edge) => acc + (edge.current_flow * edge.cost_per_unit * 365) / 1000000, 0);

  const unconstrainedLoss = bottlenecks.reduce((acc, b) => acc + (b.bottleneck_value_usd_per_day * 365) / 1000000, 0);

  return {
    bottlenecks,
    total_system_throughput_boe: Math.round(totalThroughput),
    total_logistics_cost_usd_m: Math.round(totalLogisticsCost),
    unconstrained_value_loss_usd_m: Math.round(unconstrainedLoss),
  };
}
