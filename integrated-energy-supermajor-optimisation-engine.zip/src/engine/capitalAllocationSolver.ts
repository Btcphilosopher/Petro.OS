import { CapitalProjectCandidate, PortfolioConstraints, PortfolioOptimizationResult } from "../types/portfolio";

export function solvePortfolioCapitalAllocation(
  candidates: CapitalProjectCandidate[],
  constraints: PortfolioConstraints
): PortfolioOptimizationResult {
  const sortedCandidates = [...candidates].sort((a, b) => b.risk_adjusted_npv / b.capex_usd_m - a.risk_adjusted_npv / a.capex_usd_m);

  let allocatedCapex = 0;
  let totalNpv = 0;
  let totalRiskAdjustedNpv = 0;
  let totalAbatement = 0;
  const selectedProjects: CapitalProjectCandidate[] = [];

  const segmentCapex = {
    UPSTREAM_EXPLORATION: 0,
    UPSTREAM_DEVELOPMENT: 0,
    MIDSTREAM_PIPELINE: 0,
    LNG_EXPANSION: 0,
    REFINERY_UPGRADE: 0,
    PETROCHEM_CRACKER: 0,
    RENEWABLE_POWER: 0,
    HYDROGEN_GREEN: 0,
    CARBON_CAPTURE_CCS: 0,
    SHIPPING_FLEET: 0,
  };

  for (const proj of sortedCandidates) {
    if (allocatedCapex + proj.capex_usd_m <= constraints.total_capex_budget_usd_m) {
      allocatedCapex += proj.capex_usd_m;
      totalNpv += proj.npv_usd_m;
      totalRiskAdjustedNpv += proj.risk_adjusted_npv;
      totalAbatement += proj.carbon_abatement_potential_kton_yr;
      segmentCapex[proj.segment] = (segmentCapex[proj.segment] || 0) + proj.capex_usd_m;
      selectedProjects.push({ ...proj, selected: true });
    } else {
      selectedProjects.push({ ...proj, selected: false });
    }
  }

  const portfolioRoic = Math.round(((totalNpv * 0.18) / Math.max(1, allocatedCapex)) * 1000) / 10;
  const totalFcf = Math.round(totalNpv * 0.22);
  const sharpeRatio = Math.round((totalRiskAdjustedNpv / Math.max(1, allocatedCapex * 0.15)) * 100) / 100;

  // Generate Efficient Frontier curve points
  const efficientFrontierPoints: PortfolioOptimizationResult["efficient_frontier_points"] = [];
  const steps = 8;
  const stepBudget = constraints.total_capex_budget_usd_m / steps;

  for (let i = 1; i <= steps; i++) {
    const budget = Math.round(stepBudget * i);
    let cap = 0;
    let npv = 0;
    let risk = 0;
    let em = 0;
    for (const p of sortedCandidates) {
      if (cap + p.capex_usd_m <= budget) {
        cap += p.capex_usd_m;
        npv += p.npv_usd_m;
        risk += p.risk_score * (p.capex_usd_m / budget);
        em -= p.carbon_abatement_potential_kton_yr;
      }
    }
    efficientFrontierPoints.push({
      capex: cap,
      npv: Math.round(npv),
      risk: Math.round(risk * 10) / 10,
      emissions: Math.round(em),
    });
  }

  return {
    total_selected_capex: Math.round(allocatedCapex),
    total_portfolio_npv: Math.round(totalNpv),
    total_portfolio_fcf: totalFcf,
    portfolio_roic: portfolioRoic,
    portfolio_emissions_mt: Math.round((12.5 - totalAbatement / 1000) * 10) / 10,
    risk_adjusted_sharpe_ratio: sharpeRatio,
    capital_allocated_by_segment: segmentCapex,
    selected_projects: selectedProjects,
    efficient_frontier_points: efficientFrontierPoints,
  };
}
