import { FieldDeclineParameters, UpstreamField, WellOpportunity } from "../types/upstream";

export function calculateArpsDeclineProduction(
  params: FieldDeclineParameters,
  year: number
): { rate_kboed: number; cumulative_mmboe: number; water_cut_pct: number; gor_scf_bbl: number } {
  const { initial_production, decline_rate_annual, b_factor, plateau_years, water_cut_initial, water_cut_slope, gor_scf_bbl } = params;

  if (year <= plateau_years) {
    const rate = initial_production;
    const cumulative = (rate * 365 * year) / 1000000;
    const waterCut = Math.min(95, water_cut_initial + water_cut_slope * year);
    return { rate_kboed: rate, cumulative_mmboe: cumulative, water_cut_pct: waterCut, gor_scf_bbl };
  }

  const t = year - plateau_years;
  let rate = initial_production;

  if (b_factor === 0) {
    // Exponential decline: q(t) = q_i * exp(-d * t)
    rate = initial_production * Math.exp(-decline_rate_annual * t);
  } else if (b_factor === 1) {
    // Harmonic decline: q(t) = q_i / (1 + d * t)
    rate = initial_production / (1 + decline_rate_annual * t);
  } else {
    // Hyperbolic decline: q(t) = q_i / (1 + b * d * t)^(1/b)
    rate = initial_production / Math.pow(1 + b_factor * decline_rate_annual * t, 1 / b_factor);
  }

  // Calculate cumulative approximation
  let cumulative = (initial_production * 365 * plateau_years) / 1000000;
  for (let i = 1; i <= t; i++) {
    const r = initial_production / Math.pow(1 + b_factor * decline_rate_annual * i, 1 / Math.max(0.01, b_factor));
    cumulative += (r * 365) / 1000000;
  }

  const waterCut = Math.min(95, water_cut_initial + water_cut_slope * year);
  return { rate_kboed: rate, cumulative_mmboe: cumulative, water_cut_pct: waterCut, gor_scf_bbl };
}

export function generateUpstreamOpportunities(fields: UpstreamField[]): WellOpportunity[] {
  const wells: WellOpportunity[] = [
    {
      well_id: "WEL_DELAWARE_001",
      field_id: "AST_PERMIAN",
      name: "Delaware 3-Mile Lateral High-Density Pad",
      well_capex: 9.2,
      rig_cost_per_day: 32,
      drilling_days: 18,
      completion_cost: 4.8,
      initial_ip_bpd: 2100,
      decline_rate: 0.38,
      success_probability: 0.95,
      npv_10: 18.5,
      irr: 42.1,
      payback_months: 11,
      breakeven_oil_price: 34.5,
      breakeven_gas_price: 1.80,
      rank: 1,
    },
    {
      well_id: "WEL_MIDLAND_002",
      field_id: "AST_PERMIAN",
      name: "Wolfcamp B Horizontal Infill Well",
      well_capex: 8.5,
      rig_cost_per_day: 30,
      drilling_days: 16,
      completion_cost: 4.2,
      initial_ip_bpd: 1750,
      decline_rate: 0.35,
      success_probability: 0.92,
      npv_10: 14.2,
      irr: 36.8,
      payback_months: 14,
      breakeven_oil_price: 38.0,
      breakeven_gas_price: 2.10,
      rank: 2,
    },
    {
      well_id: "WEL_FORTIES_003",
      field_id: "AST_NORTH_SEA",
      name: "Forties Alpha Subsea Tieback Infill",
      well_capex: 42.0,
      rig_cost_per_day: 280,
      drilling_days: 45,
      completion_cost: 18.0,
      initial_ip_bpd: 8500,
      decline_rate: 0.22,
      success_probability: 0.82,
      npv_10: 38.0,
      irr: 28.4,
      payback_months: 22,
      breakeven_oil_price: 46.5,
      breakeven_gas_price: 5.20,
      rank: 3,
    },
    {
      well_id: "WEL_QATAR_004",
      field_id: "AST_QATAR_GAS",
      name: "North Field Deep Khuff Gas Producer",
      well_capex: 35.0,
      rig_cost_per_day: 210,
      drilling_days: 52,
      completion_cost: 14.0,
      initial_ip_bpd: 12000, // boe equivalent
      decline_rate: 0.08,
      success_probability: 0.98,
      npv_10: 84.0,
      irr: 52.0,
      payback_months: 8,
      breakeven_oil_price: 28.0,
      breakeven_gas_price: 1.10,
      rank: 4,
    },
  ];

  return wells.sort((a, b) => b.irr - a.irr);
}
