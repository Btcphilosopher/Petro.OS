import React from "react";
import { Zap, ShieldAlert, Cpu, Leaf, BarChart2 } from "lucide-react";
import { PowerAssetConfig, HydrogenFacilityConfig, CarbonManagementConfig } from "../types/power_hydrogen";

interface EnergyTransitionDashboardProps {
  carbonTax: number;
}

export const EnergyTransitionDashboard: React.FC<EnergyTransitionDashboardProps> = ({ carbonTax }) => {
  const powerAssets: PowerAssetConfig[] = [
    {
      asset_id: "PWR_EEMSHAVEN",
      name: "Eemshaven CCGT Power Station",
      technology: "NATURAL_GAS_CCGT",
      capacity_mw: 800,
      capacity_factor_pct: 78.0,
      marginal_cost_mwh: 68.0,
      co2_intensity_kg_mwh: 380,
    },
    {
      asset_id: "PWR_NORTH_SEA_WIND",
      name: "Dogger Bank Offshore Wind Farm",
      technology: "WIND_OFFSHORE",
      capacity_mw: 1200,
      capacity_factor_pct: 48.5,
      marginal_cost_mwh: 12.0,
      co2_intensity_kg_mwh: 0,
    },
    {
      asset_id: "PWR_TEXAS_SOLAR",
      name: "Permian Basin Solar PV + Battery Hub",
      technology: "SOLAR_PV",
      capacity_mw: 450,
      capacity_factor_pct: 29.0,
      marginal_cost_mwh: 8.5,
      co2_intensity_kg_mwh: 0,
    },
  ];

  const hydrogenFacilities: HydrogenFacilityConfig[] = [
    {
      asset_id: "H2_ROTTERDAM_SMR",
      name: "Rotterdam Refinery SMR Unit",
      type: "GREY",
      capacity_tons_per_day: 450,
      capex_usd_m: 210,
      opex_usd_per_kg: 1.85,
      natural_gas_mcf_per_kg: 0.16,
      lcoh_usd_per_kg: 1.85 + (carbonTax / 1000) * 9.0, // 9kg CO2/kg H2
      allocated_end_use: {
        refining_kbpd_equivalent: 380,
        petrochem_kbpd_equivalent: 70,
        power_blend_pct: 0,
        export_liquid_h2_tpd: 0,
      },
    },
    {
      asset_id: "H2_ROTTERDAM_BLUE",
      name: "Rotterdam Blue H2 + CCS Retrofit",
      type: "BLUE",
      capacity_tons_per_day: 500,
      capex_usd_m: 480,
      opex_usd_per_kg: 2.25,
      ccs_capture_rate_pct: 95,
      lcoh_usd_per_kg: 2.25 + (carbonTax / 1000) * 0.45,
      allocated_end_use: {
        refining_kbpd_equivalent: 420,
        petrochem_kbpd_equivalent: 80,
        power_blend_pct: 5,
        export_liquid_h2_tpd: 0,
      },
    },
    {
      asset_id: "H2_NEOM_GREEN",
      name: "Neom Green H2 Solar/Wind Electrolyser",
      type: "GREEN",
      capacity_tons_per_day: 650,
      capex_usd_m: 2400,
      opex_usd_per_kg: 3.40,
      electricity_kwh_per_kg: 52,
      lcoh_usd_per_kg: 3.40, // Zero carbon tax penalty!
      allocated_end_use: {
        refining_kbpd_equivalent: 150,
        petrochem_kbpd_equivalent: 100,
        power_blend_pct: 15,
        export_liquid_h2_tpd: 400,
      },
    },
  ];

  const carbonMgmt: CarbonManagementConfig = {
    carbon_price_usd_per_ton: carbonTax,
    scope1_emissions_mt_co2e: 7.2,
    scope2_emissions_mt_co2e: 2.6,
    scope3_emissions_mt_co2e: 48.0,
    ccs_projects: [
      {
        project_id: "CCS_NORTHERN_LIGHTS",
        name: "Northern Lights Offshore Saline Aquifer",
        capture_capacity_mt_yr: 3.4,
        capture_cost_usd_ton: 45.0,
        transport_storage_cost_usd_ton: 22.0,
        avoided_cost_usd_ton: carbonTax,
        npv_at_current_carbon_price: (carbonTax - 67.0) * 3.4 * 6.5,
      },
    ],
    total_carbon_tax_liability_usd_m: (7.2 + 2.6) * carbonTax,
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
            <Leaf className="w-4 h-4 text-green-400" />
            Power Systems, Clean Hydrogen & Scope 1/2/3 Carbon Economics
          </h2>
          <p className="text-[11px] text-[#8B949E] mt-0.5">
            Levelised Cost of Hydrogen (LCOH), Power Generation Mix & CCS Abatement Cost Curves.
          </p>
        </div>

        <div className="bg-red-950/40 border border-red-500/40 rounded-lg px-4 py-2 text-xs text-right font-mono">
          <span className="text-red-300 block text-[10px] uppercase font-bold tracking-wider">Total Carbon Tax Liability</span>
          <span className="text-lg font-bold text-red-400">
            ${Math.round(carbonMgmt.total_carbon_tax_liability_usd_m).toLocaleString()}M / yr
          </span>
        </div>
      </div>

      {/* Hydrogen LCOH Stack Section */}
      <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 space-y-4">
        <h3 className="font-bold text-xs uppercase tracking-wider text-white flex items-center gap-2 border-b border-[#30363D] pb-3">
          <Cpu className="w-4 h-4 text-blue-400" />
          Clean Hydrogen Economics & LCOH Comparison at ${carbonTax}/t Carbon Tax
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {hydrogenFacilities.map((h2) => {
            const badgeColor =
              h2.type === "GREY"
                ? "bg-[#21262D] text-[#8B949E] border-[#30363D]"
                : h2.type === "BLUE"
                ? "bg-blue-950/80 text-blue-300 border-blue-800"
                : "bg-green-950/80 text-green-300 border-green-800";

            return (
              <div
                key={h2.asset_id}
                className="bg-[#0D1117] border border-[#30363D] rounded-lg p-4 space-y-3 hover:border-blue-500/40 transition"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${badgeColor}`}>
                      {h2.type} Hydrogen
                    </span>
                    <h4 className="font-bold text-white text-xs mt-2">{h2.name}</h4>
                  </div>
                  <div className="text-right font-mono">
                    <span className="text-xs font-bold text-yellow-400">${h2.lcoh_usd_per_kg.toFixed(2)}</span>
                    <span className="text-[10px] text-[#8B949E] block">/ kg H2</span>
                  </div>
                </div>

                <div className="space-y-1.5 text-xs text-[#8B949E] pt-2 border-t border-[#30363D] font-mono">
                  <div className="flex justify-between">
                    <span>Capacity:</span>
                    <span className="text-white font-bold">{h2.capacity_tons_per_day} tons/day</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Base OPEX:</span>
                    <span className="text-[#E6EDF3]">${h2.opex_usd_per_kg.toFixed(2)}/kg</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Carbon Penalty:</span>
                    <span className={h2.type === "GREEN" ? "text-green-400 font-bold" : "text-red-400 font-bold"}>
                      +${(h2.lcoh_usd_per_kg - h2.opex_usd_per_kg).toFixed(2)}/kg
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Scope 1, 2, 3 Breakdown & Power Generation */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Carbon Scope Breakdown */}
        <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 space-y-4">
          <h3 className="font-bold text-xs uppercase tracking-wider text-white flex items-center gap-2 border-b border-[#30363D] pb-3">
            <ShieldAlert className="w-4 h-4 text-red-400" />
            Corporate Carbon Scope Footprint
          </h3>

          <div className="grid grid-cols-3 gap-3 text-xs font-mono">
            <div className="bg-[#0D1117] border border-[#30363D] p-3 rounded-lg">
              <span className="text-[#8B949E] text-[10px] block uppercase">Scope 1 (Direct)</span>
              <span className="text-base font-bold text-red-400">{carbonMgmt.scope1_emissions_mt_co2e} MT</span>
            </div>
            <div className="bg-[#0D1117] border border-[#30363D] p-3 rounded-lg">
              <span className="text-[#8B949E] text-[10px] block uppercase">Scope 2 (Power)</span>
              <span className="text-base font-bold text-yellow-400">{carbonMgmt.scope2_emissions_mt_co2e} MT</span>
            </div>
            <div className="bg-[#0D1117] border border-[#30363D] p-3 rounded-lg">
              <span className="text-[#8B949E] text-[10px] block uppercase">Scope 3 (Products)</span>
              <span className="text-base font-bold text-[#8B949E]">{carbonMgmt.scope3_emissions_mt_co2e} MT</span>
            </div>
          </div>

          <div className="bg-[#0D1117] border border-[#30363D] rounded-lg p-3 space-y-2 text-xs">
            <div className="font-bold text-white uppercase text-[10px] tracking-wider">CCS Abatement Project Performance:</div>
            {carbonMgmt.ccs_projects.map((p) => (
              <div key={p.project_id} className="flex justify-between items-center text-[#E6EDF3] font-mono">
                <span>{p.name} ({p.capture_capacity_mt_yr} MT/yr)</span>
                <span className={p.npv_at_current_carbon_price >= 0 ? "text-green-400 font-bold" : "text-red-400 font-bold"}>
                  NPV: ${Math.round(p.npv_at_current_carbon_price)}M
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Power Generation Grid Assets */}
        <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 space-y-4">
          <h3 className="font-bold text-xs uppercase tracking-wider text-white flex items-center gap-2 border-b border-[#30363D] pb-3">
            <Zap className="w-4 h-4 text-yellow-400" />
            Power Generation Asset Mix
          </h3>

          <div className="space-y-2 text-xs">
            {powerAssets.map((p) => (
              <div key={p.asset_id} className="bg-[#0D1117] border border-[#30363D] rounded-lg p-3 flex justify-between items-center font-mono">
                <div>
                  <div className="font-bold text-white font-sans">{p.name}</div>
                  <div className="text-[10px] text-[#8B949E]">{p.technology} | {p.capacity_mw} MW</div>
                </div>
                <div className="text-right">
                  <div className="text-green-400 font-bold">${p.marginal_cost_mwh}/MWh</div>
                  <div className="text-[10px] text-[#8B949E]">{p.co2_intensity_kg_mwh} kg CO2/MWh</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
