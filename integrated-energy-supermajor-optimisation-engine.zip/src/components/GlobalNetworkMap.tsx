import React, { useState } from "react";
import { UniversalAsset } from "../types/asset";
import { NetworkEdge, BottleneckAnalysis } from "../types/simulation";
import { AlertTriangle, ChevronRight, Info, Zap } from "lucide-react";

interface GlobalNetworkMapProps {
  assets: UniversalAsset[];
  edges: NetworkEdge[];
  bottlenecks: BottleneckAnalysis[];
  onSelectAsset: (asset: UniversalAsset) => void;
}

export const GlobalNetworkMap: React.FC<GlobalNetworkMapProps> = ({
  assets,
  edges,
  bottlenecks,
  onSelectAsset,
}) => {
  const [selectedRegion, setSelectedRegion] = useState<string>("ALL");
  const [filterType, setFilterType] = useState<string>("ALL");

  const filteredAssets = assets.filter((a) => {
    if (selectedRegion !== "ALL" && a.region !== selectedRegion) return false;
    if (filterType !== "ALL" && a.asset_type !== filterType) return false;
    return true;
  });

  // Calculate coordinates mapping for diagram nodes
  const getNodeCoordinates = (asset: UniversalAsset) => {
    // Map lat/lng roughly to SVG viewbox (0-900, 0-500)
    const [lat, lng] = asset.coordinates;
    const x = ((lng + 130) / 200) * 800 + 50;
    const y = ((65 - lat) / 75) * 400 + 50;
    return { x: Math.max(60, Math.min(840, x)), y: Math.max(50, Math.min(450, y)) };
  };

  const getUtilColor = (util: number) => {
    if (util >= 92) return "#ef4444"; // Red / Bottleneck
    if (util >= 85) return "#f59e0b"; // Yellow / High
    return "#10b981"; // Green / Normal
  };

  return (
    <div className="space-y-6">
      {/* Top Banner Control & Legend */}
      <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
            Global Integrated Energy Flow Topology & Bottleneck Control Map
          </h2>
          <p className="text-[11px] text-[#8B949E] mt-0.5">
            Real-time multi-period physical molecules, electricity, shipping & pipeline network digital twin.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 text-xs">
          <div>
            <label className="text-[#8B949E] mr-2">Region:</label>
            <select
              value={selectedRegion}
              onChange={(e) => setSelectedRegion(e.target.value)}
              className="bg-[#21262D] border border-[#30363D] text-[#E6EDF3] rounded px-2.5 py-1 text-xs"
            >
              <option value="ALL">All Regions</option>
              <option value="NORTH_AMERICA">North America</option>
              <option value="EUROPE">Europe</option>
              <option value="MIDDLE_EAST">Middle East</option>
            </select>
          </div>

          <div>
            <label className="text-[#8B949E] mr-2">Asset Type:</label>
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="bg-[#21262D] border border-[#30363D] text-[#E6EDF3] rounded px-2.5 py-1 text-xs"
            >
              <option value="ALL">All Types</option>
              <option value="OIL_FIELD">Oil Field</option>
              <option value="GAS_FIELD">Gas Field</option>
              <option value="REFINERY">Refinery</option>
              <option value="PIPELINE">Pipeline</option>
              <option value="LNG_FACILITY">LNG Facility</option>
              <option value="PETROCHEMICAL_PLANT">Petrochemical</option>
              <option value="POWER_PLANT">Power Plant</option>
              <option value="HYDROGEN_FACILITY">Hydrogen Facility</option>
            </select>
          </div>

          {/* Color Legend */}
          <div className="flex items-center gap-3 pl-2 border-l border-[#30363D] text-[11px] font-mono">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-green-500"></span>
              <span className="text-[#8B949E]">Optimal (&lt;85%)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-yellow-500"></span>
              <span className="text-[#8B949E]">High Util (85-92%)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
              <span className="text-red-400 font-semibold">Bottleneck (&gt;92%)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main SVG Interactive Graph Map */}
      <div className="bg-[#0D1117] border border-[#30363D] rounded-lg p-4 relative overflow-hidden shadow-xl">
        <svg viewBox="0 0 900 500" className="w-full h-auto max-h-[550px] font-sans">
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#21262D" strokeWidth="0.8" />
            </pattern>
            <linearGradient id="edgeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#58A6FF" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#3FB950" stopOpacity="0.8" />
            </linearGradient>
            <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Grid background */}
          <rect width="900" height="500" fill="url(#grid)" />

          {/* Draw Edges */}
          {edges.map((edge) => {
            const fromAsset = assets.find((a) => a.asset_id === edge.from_asset_id);
            const toAsset = assets.find((a) => a.asset_id === edge.to_asset_id);
            if (!fromAsset || !toAsset) return null;

            const source = getNodeCoordinates(fromAsset);
            const target = getNodeCoordinates(toAsset);

            // Curved quadratic Bezier control point
            const midX = (source.x + target.x) / 2;
            const midY = (source.y + target.y) / 2 - 30;

            const isHighFlow = edge.current_flow / edge.capacity > 0.9;

            return (
              <g key={edge.id} className="group">
                <path
                  d={`M ${source.x} ${source.y} Q ${midX} ${midY} ${target.x} ${target.y}`}
                  fill="none"
                  stroke={isHighFlow ? "#f43f5e" : "url(#edgeGrad)"}
                  strokeWidth={isHighFlow ? 3 : 2}
                  strokeDasharray={isHighFlow ? "4,4" : "none"}
                  className={isHighFlow ? "animate-pulse" : ""}
                />
                {/* Edge Flow Label */}
                <text
                  x={midX}
                  y={midY - 6}
                  fill="#94a3b8"
                  fontSize="10"
                  textAnchor="middle"
                  className="font-mono bg-slate-900 px-1"
                >
                  {edge.current_flow} {edge.unit} (${edge.cost_per_unit}/u)
                </text>
              </g>
            );
          })}

          {/* Draw Asset Nodes */}
          {filteredAssets.map((asset) => {
            const pos = getNodeCoordinates(asset);
            const utilColor = getUtilColor(asset.utilisation);
            const isBottleneck = asset.utilisation >= 92;

            return (
              <g
                key={asset.asset_id}
                transform={`translate(${pos.x}, ${pos.y})`}
                onClick={() => onSelectAsset(asset)}
                className="cursor-pointer group"
              >
                {/* Outer Glow for Bottlenecks */}
                {isBottleneck && (
                  <circle
                    r="24"
                    fill="none"
                    stroke="#ef4444"
                    strokeWidth="2"
                    className="animate-ping opacity-75"
                  />
                )}

                {/* Node Base Circle */}
                <circle
                  r="18"
                  fill="#0f172a"
                  stroke={utilColor}
                  strokeWidth="3"
                  filter={isBottleneck ? "url(#glow)" : undefined}
                  className="transition-transform transform group-hover:scale-125"
                />

                {/* Utilisation Percentage inside Circle */}
                <text
                  y="4"
                  fill="#f8fafc"
                  fontSize="10"
                  fontWeight="bold"
                  textAnchor="middle"
                  className="font-mono"
                >
                  {Math.round(asset.utilisation)}%
                </text>

                {/* Asset Label Box */}
                <g transform="translate(0, 30)">
                  <rect
                    x="-65"
                    y="-12"
                    width="130"
                    height="24"
                    rx="4"
                    fill="#020617"
                    stroke="#334155"
                    strokeWidth="1"
                    className="group-hover:stroke-emerald-400 transition"
                  />
                  <text
                    y="2"
                    fill="#e2e8f0"
                    fontSize="10"
                    fontWeight="600"
                    textAnchor="middle"
                  >
                    {asset.name.length > 18 ? asset.name.substring(0, 16) + ".." : asset.name}
                  </text>
                </g>

                {/* Subtitle Value */}
                <text
                  y="42"
                  fill="#64748b"
                  fontSize="9"
                  textAnchor="middle"
                  className="font-mono"
                >
                  {asset.capacity} {asset.capacity_unit}
                </text>
              </g>
            );
          })}
        </svg>

        <div className="absolute bottom-3 left-4 text-[11px] text-slate-400 flex items-center gap-2">
          <Info className="w-3.5 h-3.5 text-cyan-400" />
          Click on any node to inspect physical, financial, energy, carbon & logistics twin properties.
        </div>
      </div>

      {/* Bottlenecks Summary Panel */}
      <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-[#30363D] pb-3">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-400" />
            <h3 className="font-bold text-white text-xs uppercase tracking-wider">System Bottleneck & Shadow Value Finder</h3>
          </div>
          <span className="text-[10px] text-blue-400 font-mono bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20">
            {bottlenecks.length} Critical System Constraints Detected
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {bottlenecks.map((b) => (
            <div
              key={b.asset_id}
              className="bg-[#0D1117] border border-red-500/30 rounded-lg p-4 space-y-2.5 hover:border-red-500/60 transition"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-xs font-bold text-red-400 font-mono flex items-center gap-1.5 uppercase">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping"></span>
                    {b.asset_name}
                  </div>
                  <div className="text-[11px] text-[#8B949E] mt-0.5">
                    Type: <span className="text-[#E6EDF3]">{b.constraint_type}</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs font-bold text-green-400 font-mono">
                    +${b.bottleneck_value_usd_per_day.toLocaleString()}/day
                  </div>
                  <div className="text-[10px] text-[#8B949E]">Shadow Value</div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 py-2 border-y border-[#30363D] text-[11px] font-mono">
                <div>
                  <span className="text-[#8B949E] block text-[10px]">Utilisation:</span>
                  <span className="font-bold text-red-400">{b.utilisation_pct}%</span>
                </div>
                <div>
                  <span className="text-[#8B949E] block text-[10px]">Capex Needed:</span>
                  <span className="font-bold text-white">${b.expansion_capex_usd_m}M</span>
                </div>
                <div>
                  <span className="text-[#8B949E] block text-[10px]">Payback:</span>
                  <span className="font-bold text-yellow-400">{b.expansion_payback_months} mos</span>
                </div>
              </div>

              <p className="text-[11px] text-[#E6EDF3] flex items-center gap-1 pt-1">
                <ChevronRight className="w-3.5 h-3.5 text-blue-400 flex-shrink-0" />
                {b.recommendation}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
