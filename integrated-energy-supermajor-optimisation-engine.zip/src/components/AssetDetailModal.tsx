import React, { useState } from "react";
import { UniversalAsset } from "../types/asset";
import { X, Save, Layers, AlertCircle, Shield } from "lucide-react";

interface AssetDetailModalProps {
  asset: UniversalAsset | null;
  onClose: () => void;
  onUpdateAsset: (updatedAsset: UniversalAsset) => void;
}

export const AssetDetailModal: React.FC<AssetDetailModalProps> = ({ asset, onClose, onUpdateAsset }) => {
  if (!asset) return null;

  const [capacity, setCapacity] = useState<number>(asset.capacity);
  const [opex, setOpex] = useState<number>(asset.operating_cost);
  const [utilisation, setUtilisation] = useState<number>(asset.utilisation);
  const [emissions, setEmissions] = useState<number>(asset.emissions);
  const [status, setStatus] = useState<UniversalAsset["status"]>(asset.status);

  const handleSave = () => {
    onUpdateAsset({
      ...asset,
      capacity,
      operating_cost: opex,
      utilisation,
      emissions,
      status,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#161B22] border border-[#30363D] rounded-lg w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 space-y-6 shadow-2xl">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-[#30363D] pb-4">
          <div>
            <span className="text-[10px] font-bold text-blue-400 uppercase font-mono">{asset.asset_type}</span>
            <h3 className="text-base font-bold text-white uppercase tracking-wider mt-0.5">{asset.name}</h3>
            <p className="text-xs text-[#8B949E]">{asset.location} ({asset.region})</p>
          </div>
          <button onClick={onClose} className="p-1 text-[#8B949E] hover:text-white rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 18-Property Grid Display & Edit */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs font-mono">
          <div className="bg-[#0D1117] p-3 rounded-lg border border-[#30363D]">
            <span className="text-[#8B949E] text-[10px] block uppercase">Asset ID</span>
            <span className="text-white font-bold">{asset.asset_id}</span>
          </div>
          <div className="bg-[#0D1117] p-3 rounded-lg border border-[#30363D]">
            <span className="text-[#8B949E] text-[10px] block uppercase">Ownership %</span>
            <span className="text-green-400 font-bold">{asset.ownership}%</span>
          </div>
          <div className="bg-[#0D1117] p-3 rounded-lg border border-[#30363D]">
            <span className="text-[#8B949E] text-[10px] block uppercase">Capital Cost</span>
            <span className="text-yellow-400 font-bold">${asset.capital_cost}M</span>
          </div>
          <div className="bg-[#0D1117] p-3 rounded-lg border border-[#30363D]">
            <span className="text-[#8B949E] text-[10px] block uppercase">Remaining Life</span>
            <span className="text-[#E6EDF3] font-bold">{asset.remaining_life} Years</span>
          </div>
          <div className="bg-[#0D1117] p-3 rounded-lg border border-[#30363D]">
            <span className="text-[#8B949E] text-[10px] block uppercase">Availability</span>
            <span className="text-blue-400 font-bold">{asset.availability}%</span>
          </div>
          <div className="bg-[#0D1117] p-3 rounded-lg border border-[#30363D]">
            <span className="text-[#8B949E] text-[10px] block uppercase">Risk Score (1-10)</span>
            <span className="text-red-400 font-bold">{asset.risk} / 10</span>
          </div>
        </div>

        {/* Editable Sliders & Values */}
        <div className="space-y-4 pt-2 border-t border-[#30363D] text-xs">
          <h4 className="font-bold text-white uppercase tracking-wider text-[11px]">Edit Real-Time Digital Twin Parameters:</h4>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between mb-1 text-[#E6EDF3]">
                <span>Capacity ({asset.capacity_unit}):</span>
                <span className="font-bold text-green-400 font-mono">{capacity}</span>
              </div>
              <input
                type="range"
                min={10}
                max={asset.capacity * 2}
                value={capacity}
                onChange={(e) => setCapacity(Number(e.target.value))}
                className="w-full accent-green-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1 text-[#E6EDF3]">
                <span>Operating Cost ($/unit):</span>
                <span className="font-bold text-yellow-400 font-mono">${opex}</span>
              </div>
              <input
                type="range"
                min={1}
                max={opex * 3}
                step={0.5}
                value={opex}
                onChange={(e) => setOpex(Number(e.target.value))}
                className="w-full accent-yellow-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1 text-[#E6EDF3]">
                <span>Utilisation Rate (%):</span>
                <span className="font-bold text-red-400 font-mono">{utilisation}%</span>
              </div>
              <input
                type="range"
                min={10}
                max={100}
                value={utilisation}
                onChange={(e) => setUtilisation(Number(e.target.value))}
                className="w-full accent-red-500 cursor-pointer"
              />
            </div>

            <div>
              <label className="text-[#8B949E] block mb-1">Operational Status:</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as UniversalAsset["status"])}
                className="bg-[#0D1117] border border-[#30363D] text-[#E6EDF3] rounded p-2 w-full font-mono text-xs"
              >
                <option value="OPERATIONAL">OPERATIONAL</option>
                <option value="MAINTENANCE">MAINTENANCE</option>
                <option value="EXPANSION_PLANNED">EXPANSION PLANNED</option>
                <option value="SHUT_DOWN">SHUT DOWN</option>
              </select>
            </div>
          </div>
        </div>

        {/* Footer Buttons */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#30363D]">
          <button onClick={onClose} className="px-4 py-2 rounded text-xs font-semibold text-[#8B949E] hover:text-white">
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="flex items-center gap-1.5 bg-[#238636] hover:bg-[#2ea043] text-white px-4 py-2 rounded text-xs font-bold transition"
          >
            <Save className="w-4 h-4" /> Save Twin State
          </button>
        </div>
      </div>
    </div>
  );
};
