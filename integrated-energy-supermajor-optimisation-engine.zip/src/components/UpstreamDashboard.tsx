import React, { useState } from "react";
import { UpstreamField, WellOpportunity } from "../types/upstream";
import { calculateArpsDeclineProduction, generateUpstreamOpportunities } from "../engine/upstreamEngine";
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { TrendingDown, Pickaxe, DollarSign, Database, Award } from "lucide-react";

interface UpstreamDashboardProps {
  fields: UpstreamField[];
  brentPrice: number;
}

export const UpstreamDashboard: React.FC<UpstreamDashboardProps> = ({ fields, brentPrice }) => {
  const [selectedFieldId, setSelectedFieldId] = useState<string>(fields[0]?.field_id || "AST_PERMIAN");
  const [bFactor, setBFactor] = useState<number>(0.5); // Arps b factor
  const [selectedScenario, setSelectedScenario] = useState<string>("BASE_CASE");

  const activeField = fields.find((f) => f.field_id === selectedFieldId) || fields[0];

  // Generate 20-year decline forecast data
  const chartData = Array.from({ length: 20 }, (_, i) => {
    const yr = i + 1;
    const calc = calculateArpsDeclineProduction(
      { ...activeField.decline_params, b_factor: bFactor },
      yr
    );
    return {
      year: `Yr ${yr}`,
      oil_kboed: Math.round(calc.rate_kboed * 10) / 10,
      cumulative_mmboe: Math.round(calc.cumulative_mmboe * 10) / 10,
      water_cut_pct: Math.round(calc.water_cut_pct),
    };
  });

  const wellOpportunities = generateUpstreamOpportunities(fields);

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
            <Database className="w-4 h-4 text-blue-400" />
            Upstream Reservoir Forecasting & Drilling Economics
          </h2>
          <p className="text-[11px] text-[#8B949E] mt-0.5">
            Arps Decline Model (Exponential, Hyperbolic, Harmonic), Water Cut Progression & Well Portfolio Economics.
          </p>
        </div>

        <div className="flex items-center gap-3 text-xs">
          <div>
            <label className="text-[#8B949E] mr-2">Select Field:</label>
            <select
              value={selectedFieldId}
              onChange={(e) => setSelectedFieldId(e.target.value)}
              className="bg-[#21262D] border border-[#30363D] text-blue-400 font-semibold rounded px-3 py-1.5 text-xs"
            >
              {fields.map((f) => (
                <option key={f.field_id} value={f.field_id}>
                  {f.name} ({f.basin})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[#8B949E] mr-2">Arps b-factor:</label>
            <select
              value={bFactor}
              onChange={(e) => setBFactor(Number(e.target.value))}
              className="bg-[#21262D] border border-[#30363D] text-[#E6EDF3] font-mono rounded px-2.5 py-1.5 text-xs"
            >
              <option value={0.0}>0.0 (Exponential)</option>
              <option value={0.5}>0.5 (Hyperbolic Shales)</option>
              <option value={1.0}>1.0 (Harmonic Waterflood)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Grid Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Field Key Specs Panel */}
        <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 space-y-4">
          <h3 className="font-bold text-xs uppercase tracking-wider text-white border-b border-[#30363D] pb-2 flex items-center gap-2">
            <Pickaxe className="w-4 h-4 text-blue-400" />
            {activeField.name} Overview
          </h3>

          <div className="space-y-3 text-xs font-mono">
            <div className="flex justify-between py-1 border-b border-[#30363D]">
              <span className="text-[#8B949E]">Hydrocarbon Type:</span>
              <span className="font-bold text-yellow-400">{activeField.hydrocarbon_type}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#30363D]">
              <span className="text-[#8B949E]">Initial IP Rate:</span>
              <span className="font-bold text-white">{activeField.decline_params.initial_production} kboed</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#30363D]">
              <span className="text-[#8B949E]">Plateau Duration:</span>
              <span className="font-bold text-blue-400">{activeField.decline_params.plateau_years} Yrs</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#30363D]">
              <span className="text-[#8B949E]">Annual Decline Rate:</span>
              <span className="font-bold text-red-400">
                {(activeField.decline_params.decline_rate_annual * 100).toFixed(1)}% / yr
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#30363D]">
              <span className="text-[#8B949E]">Lifting Cost:</span>
              <span className="font-bold text-green-400">${activeField.decline_params.lifting_cost_per_bbl}/bbl</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#30363D]">
              <span className="text-[#8B949E]">Remaining 2P Reserves:</span>
              <span className="font-bold text-white">{activeField.decline_params.remaining_2p_reserves} MMboe</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-[#8B949E]">Abandonment Liability:</span>
              <span className="font-bold text-[#E6EDF3]">${activeField.decline_params.abandonment_liability}M</span>
            </div>
          </div>

          <div className="pt-2">
            <label className="text-[10px] uppercase font-bold text-[#8B949E] block mb-1">Development Strategy:</label>
            <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
              {["BASE_CASE", "ACCELERATED_INFILL", "EOR_WATERFLOOD", "LOW_CAPEX_HARVEST"].map((sc) => (
                <button
                  key={sc}
                  onClick={() => setSelectedScenario(sc)}
                  className={`p-2 rounded border text-left transition ${
                    selectedScenario === sc
                      ? "border-blue-500 bg-blue-500/10 text-blue-400 font-bold"
                      : "border-[#30363D] bg-[#0D1117] text-[#8B949E] hover:text-[#E6EDF3]"
                  }`}
                >
                  {sc.replace(/_/g, " ")}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* 20-Year Production Profile Chart */}
        <div className="lg:col-span-2 bg-[#161B22] border border-[#30363D] rounded-lg p-5 space-y-3">
          <div className="flex items-center justify-between border-b border-[#30363D] pb-2">
            <h3 className="font-bold text-xs uppercase tracking-wider text-white flex items-center gap-2">
              <TrendingDown className="w-4 h-4 text-blue-400" />
              20-Year Production Decline Profile (kboed)
            </h3>
            <span className="text-xs font-mono text-blue-400">Arps b = {bFactor}</span>
          </div>

          <div className="h-[280px] w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorOil" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#58A6FF" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#58A6FF" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#21262D" />
                <XAxis dataKey="year" stroke="#8B949E" fontSize={11} />
                <YAxis stroke="#8B949E" fontSize={11} unit="k" />
                <Tooltip
                  contentStyle={{ backgroundColor: "#0D1117", borderColor: "#30363D", borderRadius: "6px", fontSize: "12px", color: "#E6EDF3" }}
                />
                <Area type="monotone" dataKey="oil_kboed" stroke="#58A6FF" fillOpacity={1} fill="url(#colorOil)" name="Production (kboed)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Drilling Economics Ranking Table */}
      <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-[#30363D] pb-3">
          <div>
            <h3 className="font-bold text-xs uppercase tracking-wider text-white flex items-center gap-2">
              <Award className="w-4 h-4 text-yellow-400" />
              Ranked Drilling & Field Development Opportunities
            </h3>
            <p className="text-[11px] text-[#8B949E] mt-0.5">Candidate wells sorted by Risk-Adjusted Internal Rate of Return (IRR %).</p>
          </div>
          <span className="text-xs text-blue-400 font-mono font-bold bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20">
            Brent Ref: ${brentPrice}/bbl
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#E6EDF3]">
            <thead className="bg-[#0D1117] text-[#8B949E] uppercase text-[10px] border-b border-[#30363D] font-mono">
              <tr>
                <th className="p-3">Rank</th>
                <th className="p-3">Opportunity Name</th>
                <th className="p-3">Well Capex ($M)</th>
                <th className="p-3">Initial IP (bpd)</th>
                <th className="p-3">IRR (%)</th>
                <th className="p-3">NPV_10 ($M)</th>
                <th className="p-3">Payback (Mo)</th>
                <th className="p-3">Breakeven Oil ($/bbl)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#30363D] font-mono">
              {wellOpportunities.map((well, idx) => (
                <tr key={well.well_id} className="hover:bg-[#21262D]/60 transition">
                  <td className="p-3 font-bold text-blue-400">#{idx + 1}</td>
                  <td className="p-3 font-semibold text-white font-sans">{well.name}</td>
                  <td className="p-3 text-[#E6EDF3]">${well.well_capex}M</td>
                  <td className="p-3 text-white">{well.initial_ip_bpd.toLocaleString()}</td>
                  <td className="p-3 font-bold text-green-400">{well.irr}%</td>
                  <td className="p-3 font-bold text-yellow-400">${well.npv_10}M</td>
                  <td className="p-3 text-[#8B949E]">{well.payback_months} mos</td>
                  <td className="p-3 text-green-400">${well.breakeven_oil_price}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
