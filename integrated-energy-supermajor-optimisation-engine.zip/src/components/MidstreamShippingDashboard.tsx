import React from "react";
import { PipelineSegment, TankerVessel, LNGValueChain, StorageTerminal } from "../types/midstream";
import { Ship, Anchor, GitCommit, Database, ArrowRight } from "lucide-react";

interface MidstreamShippingDashboardProps {
  vlccDayRate: number;
  jkmLngPrice: number;
}

export const MidstreamShippingDashboard: React.FC<MidstreamShippingDashboardProps> = ({ vlccDayRate, jkmLngPrice }) => {
  const pipelines: PipelineSegment[] = [
    {
      pipeline_id: "PPL_PASADENA",
      name: "Permian to Pasadena Express Trunkline",
      origin_node: "West Texas Delaware Basin",
      destination_node: "Pasadena Gulf Coast Refinery",
      capacity_bpd_or_mcfd: 350000,
      current_flow: 330000,
      tariff_per_unit: 2.10,
      energy_loss_pct: 0.15,
      length_km: 780,
      is_bottleneck: true,
      shadow_value_per_unit_expansion: 125000,
    },
    {
      pipeline_id: "PPL_TRANS_EUROPE",
      name: "Trans-European Gas Grid Link",
      origin_node: "Rotterdam Import Terminal",
      destination_node: "Eemshaven Power Grid",
      capacity_bpd_or_mcfd: 1200000, // mcfd
      current_flow: 980000,
      tariff_per_unit: 0.45,
      energy_loss_pct: 0.40,
      length_km: 420,
      is_bottleneck: false,
      shadow_value_per_unit_expansion: 32000,
    },
  ];

  const tankers: TankerVessel[] = [
    {
      vessel_id: "VSL_AURA_TITAN",
      name: "M/T Aura Titan",
      vessel_type: "VLCC",
      capacity_bbl_or_cbm: 2000000,
      charter_rate_per_day: vlccDayRate,
      fuel_consumption_tons_per_day: 52,
      current_location: "Strait of Malacca",
      status: "AT_SEA",
      assigned_cargo: {
        cargo_id: "CRG_0821",
        origin: "Ras Tanura",
        destination: "Rotterdam",
        commodity: "Arab Heavy Crude",
        volume: 1950000,
        demurrage_risk_days: 1.5,
      },
    },
    {
      vessel_id: "VSL_AURA_LNG_1",
      name: "LNG Enterprise Voyager",
      vessel_type: "LNG_CARRIER_174K",
      capacity_bbl_or_cbm: 174000,
      charter_rate_per_day: 95000,
      fuel_consumption_tons_per_day: 48,
      current_location: "Arabian Sea",
      status: "AT_SEA",
      assigned_cargo: {
        cargo_id: "CRG_LNG_904",
        origin: "Ras Laffan, Qatar",
        destination: "Tokyo Bay, Japan",
        commodity: "LNG",
        volume: 168000,
        demurrage_risk_days: 0.0,
      },
    },
  ];

  const lngChain: LNGValueChain = {
    chain_id: "LNG_QATAR_TO_ASIA",
    name: "Ras Laffan Train 1-4 to JKM North Asia Spot Chain",
    liquefaction_plant_id: "AST_LNG_RAS_LAFFAN",
    regas_terminal_id: "TKY_REGAS_01",
    feedgas_cost_mmbtu: 3.40,
    liquefaction_cost_mmbtu: 1.80,
    shipping_cost_mmbtu: 2.10,
    regas_cost_mmbtu: 0.60,
    total_delivered_cost_mmbtu: 7.90,
    destination_market_price_mmbtu: jkmLngPrice,
    netback_margin_mmbtu: jkmLngPrice - 7.90,
    annual_volume_mtpa: 29.4,
  };

  const storageTerminals: StorageTerminal[] = [
    {
      terminal_id: "TRM_CUSHING",
      name: "Cushing Crude Storage Terminal",
      location: "Oklahoma, USA",
      commodity: "Crude Light",
      total_capacity: 12000, // kbbl
      current_inventory: 8400,
      working_capital_locked_usd: 688800000,
      holding_cost_per_unit_month: 0.45,
      price_exposure_risk: 42.0,
      optimal_target_inventory: 7500,
    },
    {
      terminal_id: "TRM_ROTTERDAM_GAS",
      name: "Rotterdam LNG Cryogenic Tank Hub",
      location: "Netherlands",
      commodity: "LNG",
      total_capacity: 480, // kCBM
      current_inventory: 390,
      working_capital_locked_usd: 195000000,
      holding_cost_per_unit_month: 1.20,
      price_exposure_risk: 18.5,
      optimal_target_inventory: 350,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
            <Ship className="w-4 h-4 text-blue-400" />
            Midstream Pipelines, Tanker Shipping & Global LNG Chains
          </h2>
          <p className="text-[11px] text-[#8B949E] mt-0.5">
            Logistics Flow Optimization, Demurrage Risk Mitigation & Delivered LNG Cost Stack.
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="bg-[#0D1117] border border-[#30363D] px-3 py-1.5 rounded">
            <span className="text-[#8B949E] mr-2">VLCC Day Rate:</span>
            <strong className="text-blue-400">${vlccDayRate.toLocaleString()}/day</strong>
          </div>
          <div className="bg-[#0D1117] border border-[#30363D] px-3 py-1.5 rounded">
            <span className="text-[#8B949E] mr-2">JKM LNG Spot:</span>
            <strong className="text-yellow-400">${jkmLngPrice}/MMBtu</strong>
          </div>
        </div>
      </div>

      {/* LNG Chain Cost Stack Breakdown */}
      <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 space-y-4">
        <h3 className="font-bold text-xs uppercase tracking-wider text-white flex items-center gap-2 border-b border-[#30363D] pb-3">
          <Anchor className="w-4 h-4 text-green-400" />
          Global LNG Delivered Cost & Netback Margin Stack
        </h3>

        <div className="bg-[#0D1117] border border-[#30363D] rounded-lg p-4 space-y-3">
          <div className="flex justify-between items-center text-xs font-semibold text-white">
            <span>{lngChain.name}</span>
            <span className="text-green-400 font-mono">
              Deliverable Volume: {lngChain.annual_volume_mtpa} MTPA
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs font-mono">
            <div className="bg-[#161B22] p-2.5 rounded border border-[#30363D]">
              <span className="text-[#8B949E] text-[10px] block uppercase">Feedgas Cost</span>
              <span className="text-[#E6EDF3] font-bold">${lngChain.feedgas_cost_mmbtu.toFixed(2)}</span>
            </div>
            <div className="bg-[#161B22] p-2.5 rounded border border-[#30363D]">
              <span className="text-[#8B949E] text-[10px] block uppercase">+ Liquefaction</span>
              <span className="text-[#E6EDF3] font-bold">${lngChain.liquefaction_cost_mmbtu.toFixed(2)}</span>
            </div>
            <div className="bg-[#161B22] p-2.5 rounded border border-[#30363D]">
              <span className="text-[#8B949E] text-[10px] block uppercase">+ Shipping Freight</span>
              <span className="text-[#E6EDF3] font-bold">${lngChain.shipping_cost_mmbtu.toFixed(2)}</span>
            </div>
            <div className="bg-[#161B22] p-2.5 rounded border border-[#30363D]">
              <span className="text-[#8B949E] text-[10px] block uppercase">+ Regas Terminal</span>
              <span className="text-[#E6EDF3] font-bold">${lngChain.regas_cost_mmbtu.toFixed(2)}</span>
            </div>
            <div className="bg-green-950/40 border border-green-500/40 p-2.5 rounded text-right">
              <span className="text-green-300 text-[10px] block uppercase">Netback Margin</span>
              <span className="text-green-400 font-bold text-sm">
                +${lngChain.netback_margin_mmbtu.toFixed(2)}/MMBtu
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Grid Pipelines & Tanker Fleet */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pipelines List */}
        <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 space-y-4">
          <h3 className="font-bold text-xs uppercase tracking-wider text-white flex items-center gap-2 border-b border-[#30363D] pb-3">
            <GitCommit className="w-4 h-4 text-blue-400" />
            Key Pipeline Trunklines
          </h3>

          <div className="space-y-3 text-xs font-mono">
            {pipelines.map((p) => {
              const util = Math.round((p.current_flow / p.capacity_bpd_or_mcfd) * 100);
              return (
                <div key={p.pipeline_id} className="bg-[#0D1117] border border-[#30363D] rounded-lg p-3 space-y-2">
                  <div className="flex justify-between items-center font-bold text-white font-sans">
                    <span>{p.name}</span>
                    <span className={util >= 90 ? "text-red-400 font-mono" : "text-green-400 font-mono"}>
                      {util}% Utilised
                    </span>
                  </div>
                  <div className="flex items-center text-[11px] text-[#8B949E] gap-1">
                    <span>{p.origin_node}</span>
                    <ArrowRight className="w-3 h-3 text-blue-400" />
                    <span>{p.destination_node}</span>
                  </div>
                  <div className="flex justify-between text-[11px] text-[#E6EDF3] pt-1 border-t border-[#30363D]">
                    <span>Flow: {p.current_flow.toLocaleString()} / {p.capacity_bpd_or_mcfd.toLocaleString()}</span>
                    <span>Tariff: ${p.tariff_per_unit}/u</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Tanker Fleet Tracker */}
        <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 space-y-4">
          <h3 className="font-bold text-xs uppercase tracking-wider text-white flex items-center gap-2 border-b border-[#30363D] pb-3">
            <Anchor className="w-4 h-4 text-yellow-400" />
            Active Tanker Voyages & Demurrage Risk
          </h3>

          <div className="space-y-3 text-xs">
            {tankers.map((v) => (
              <div key={v.vessel_id} className="bg-[#0D1117] border border-[#30363D] rounded-lg p-3 space-y-2">
                <div className="flex justify-between font-bold text-white">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
                    {v.name} ({v.vessel_type})
                  </span>
                  <span className="text-blue-400 font-mono">${v.charter_rate_per_day.toLocaleString()}/day</span>
                </div>
                {v.assigned_cargo && (
                  <div className="bg-[#161B22] p-2 rounded text-[11px] space-y-1">
                    <div className="text-[#E6EDF3]">Cargo: {v.assigned_cargo.commodity} ({v.assigned_cargo.volume.toLocaleString()} bbl)</div>
                    <div className="flex justify-between text-[#8B949E] font-mono">
                      <span>{v.assigned_cargo.origin} &rarr; {v.assigned_cargo.destination}</span>
                      <span className="text-yellow-400">Demurrage Risk: {v.assigned_cargo.demurrage_risk_days} days</span>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
