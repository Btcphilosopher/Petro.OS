import React, { useState } from "react";
import { CrudeAssay, RefinerySlateOptimizationResult } from "../types/refining";
import { CommodityPrices } from "../types/simulation";
import { optimizeRefinerySlate, calculateCrudeRefineryValue } from "../engine/refinerySolver";
import { Factory, Flame, DollarSign, Sliders, CheckCircle2 } from "lucide-react";

interface RefineryDashboardProps {
  crudes: CrudeAssay[];
  prices: CommodityPrices;
  carbonTax: number;
}

export const RefineryDashboard: React.FC<RefineryDashboardProps> = ({ crudes, prices, carbonTax }) => {
  const [selectedRefinery, setSelectedRefinery] = useState<string>("ROTTERDAM");

  const refineryName = selectedRefinery === "ROTTERDAM" ? "Rotterdam Europort Coastal Refinery" : "Pasadena Gulf Coast Mega-Refinery";
  const capacityBpd = selectedRefinery === "ROTTERDAM" ? 420000 : 550000;

  const result: RefinerySlateOptimizationResult = optimizeRefinerySlate(
    selectedRefinery,
    refineryName,
    capacityBpd,
    crudes,
    prices,
    carbonTax
  );

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
            <Factory className="w-4 h-4 text-blue-400" />
            Downstream Refining & Crude Slate Optimization Engine
          </h2>
          <p className="text-[11px] text-[#8B949E] mt-0.5">
            Linear Programming (LP) Crude Assay Evaluation, Yields, Hydrotreating, Freight & Product Blending Specs.
          </p>
        </div>

        <div className="flex items-center gap-3 text-xs">
          <label className="text-[#8B949E]">Target Refinery:</label>
          <select
            value={selectedRefinery}
            onChange={(e) => setSelectedRefinery(e.target.value)}
            className="bg-[#21262D] border border-[#30363D] text-blue-400 font-semibold rounded px-3 py-1.5 text-xs"
          >
            <option value="ROTTERDAM">Rotterdam Europort (420 kbpd)</option>
            <option value="PASADENA">Pasadena US Gulf Coast (550 kbpd)</option>
          </select>
        </div>
      </div>

      {/* Global Crude Assays Table */}
      <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-[#30363D] pb-3">
          <h3 className="font-bold text-xs uppercase tracking-wider text-white flex items-center gap-2">
            <Flame className="w-4 h-4 text-red-400" />
            Global Crude Assay Matrix & Refinery Netback Values
          </h3>
          <span className="text-xs text-blue-400 font-mono font-bold bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20">
            Cracking Margin Ref: ${prices.refining_nwe_cracking_margin_usd_bbl}/bbl
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#E6EDF3]">
            <thead className="bg-[#0D1117] text-[#8B949E] uppercase text-[10px] border-b border-[#30363D] font-mono">
              <tr>
                <th className="p-3">Crude Name</th>
                <th className="p-3">API Gravity</th>
                <th className="p-3">Sulphur (wt%)</th>
                <th className="p-3">TAN Acidity</th>
                <th className="p-3">FOB Price ($/bbl)</th>
                <th className="p-3">Freight ($/bbl)</th>
                <th className="p-3">Gross Value ($/bbl)</th>
                <th className="p-3">Netback Margin ($/bbl)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#30363D] font-mono">
              {crudes.map((c) => {
                const evalRes = calculateCrudeRefineryValue(c, prices);
                return (
                  <tr key={c.crude_id} className="hover:bg-[#21262D]/60 transition">
                    <td className="p-3 font-bold text-white font-sans">{c.name}</td>
                    <td className="p-3 text-blue-400">{c.api_gravity}°</td>
                    <td className="p-3 text-yellow-400">{c.sulphur_weight_pct}%</td>
                    <td className="p-3 text-[#8B949E]">{c.tan_acidity}</td>
                    <td className="p-3 text-white">${c.purchase_price_fob}</td>
                    <td className="p-3 text-[#8B949E]">${c.freight_to_refinery}</td>
                    <td className="p-3 text-green-400">${evalRes.gross_product_value_per_bbl.toFixed(2)}</td>
                    <td className="p-3 font-bold text-green-400 font-mono">
                      +${evalRes.netback_refinery_margin_per_bbl.toFixed(2)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Optimal Crude Slate Allocation Results */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recommended Purchases */}
        <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 space-y-4">
          <h3 className="font-bold text-xs uppercase tracking-wider text-white border-b border-[#30363D] pb-2 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-green-400" />
            Optimal Slate Purchases
          </h3>

          <div className="space-y-3 text-xs">
            {result.crude_purchases.map((p) => (
              <div key={p.crude_id} className="bg-[#0D1117] border border-[#30363D] rounded-lg p-3 space-y-1">
                <div className="flex justify-between font-bold text-white">
                  <span>{p.crude_id.replace("CRU_", "")}</span>
                  <span className="text-green-400 font-mono">{p.volume_bpd.toLocaleString()} bpd</span>
                </div>
                <div className="flex justify-between text-[11px] text-[#8B949E]">
                  <span>Delivered Cost:</span>
                  <span className="font-mono text-[#E6EDF3]">${p.delivered_cost_bbl.toFixed(2)}/bbl</span>
                </div>
                <div className="flex justify-between text-[11px] text-[#8B949E]">
                  <span>Margin Contribution:</span>
                  <span className="font-mono text-green-400">+${p.gross_margin_contribution_bbl.toFixed(2)}/bbl</span>
                </div>
              </div>
            ))}

            <div className="pt-2 border-t border-[#30363D] space-y-2 font-mono">
              <div className="flex justify-between">
                <span className="text-[#8B949E]">Blended Gross Margin:</span>
                <span className="font-bold text-green-400">${result.refinery_gross_margin_per_bbl.toFixed(2)}/bbl</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8B949E]">Total Daily Margin:</span>
                <span className="font-bold text-yellow-400">
                  ${(result.total_daily_margin_usd / 1000000).toFixed(2)}M / Day
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Product Yield Breakdown */}
        <div className="lg:col-span-2 bg-[#161B22] border border-[#30363D] rounded-lg p-5 space-y-4">
          <h3 className="font-bold text-xs uppercase tracking-wider text-white border-b border-[#30363D] pb-2">
            Optimized Product Yield Breakdown (bpd)
          </h3>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs font-mono">
            <div className="bg-[#0D1117] border border-[#30363D] p-3 rounded-lg">
              <span className="text-[#8B949E] block text-[10px] uppercase">Gasoline 95 RON</span>
              <span className="text-lg font-bold text-green-400">
                {Math.round(result.total_product_yield_bpd.gasoline).toLocaleString()} bpd
              </span>
            </div>
            <div className="bg-[#0D1117] border border-[#30363D] p-3 rounded-lg">
              <span className="text-[#8B949E] block text-[10px] uppercase">Ultra Low Sulphur Diesel</span>
              <span className="text-lg font-bold text-blue-400">
                {Math.round(result.total_product_yield_bpd.diesel).toLocaleString()} bpd
              </span>
            </div>
            <div className="bg-[#0D1117] border border-[#30363D] p-3 rounded-lg">
              <span className="text-[#8B949E] block text-[10px] uppercase">Jet A-1 Fuel</span>
              <span className="text-lg font-bold text-yellow-400">
                {Math.round(result.total_product_yield_bpd.jet_fuel).toLocaleString()} bpd
              </span>
            </div>
            <div className="bg-[#0D1117] border border-[#30363D] p-3 rounded-lg">
              <span className="text-[#8B949E] block text-[10px] uppercase">Petrochem Naphtha Feed</span>
              <span className="text-lg font-bold text-purple-400">
                {Math.round(result.total_product_yield_bpd.petrochem_feed).toLocaleString()} bpd
              </span>
            </div>
            <div className="bg-[#0D1117] border border-[#30363D] p-3 rounded-lg">
              <span className="text-[#8B949E] block text-[10px] uppercase">LPG</span>
              <span className="text-lg font-bold text-white">
                {Math.round(result.total_product_yield_bpd.lpg).toLocaleString()} bpd
              </span>
            </div>
            <div className="bg-[#0D1117] border border-[#30363D] p-3 rounded-lg">
              <span className="text-[#8B949E] block text-[10px] uppercase">Fuel Oil</span>
              <span className="text-lg font-bold text-red-400">
                {Math.round(result.total_product_yield_bpd.fuel_oil).toLocaleString()} bpd
              </span>
            </div>
          </div>

          <div className="bg-[#0D1117] border border-[#30363D] rounded-lg p-3 flex flex-wrap justify-between items-center text-xs text-[#E6EDF3]">
            <div>
              <span className="text-[#8B949E] mr-2">Refinery CO2 Footprint:</span>
              <strong className="text-red-400 font-mono">{result.co2_emissions_kton_yr} kton/yr</strong>
            </div>
            <div>
              <span className="text-[#8B949E] mr-2">Hydrotreater H2 Demand:</span>
              <strong className="text-blue-400 font-mono">
                {(result.hydrogen_deficit_scfd / 1000000).toFixed(1)} MMscfd
              </strong>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
