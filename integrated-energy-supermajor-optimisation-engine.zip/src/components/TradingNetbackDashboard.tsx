import React from "react";
import { CommodityPrices } from "../types/simulation";
import { ArrowRight, DollarSign, Globe, TrendingUp } from "lucide-react";

interface TradingNetbackDashboardProps {
  prices: CommodityPrices;
  carbonTax: number;
}

export const TradingNetbackDashboard: React.FC<TradingNetbackDashboardProps> = ({ prices, carbonTax }) => {
  const arbitrageRoutes = [
    {
      id: "ARB_LNG_QATAR_TTF",
      name: "Qatar Gas to TTF Rotterdam LNG Arbitrage",
      commodity: "LNG",
      source_price: prices.henry_hub_gas_usd_mmbtu,
      processing_cost: 1.80, // liquefaction
      transport_cost: 2.10, // LNG carrier
      carbon_cost: (0.012 * carbonTax),
      tax_cost: 0.20,
      delivered_cost: prices.henry_hub_gas_usd_mmbtu + 1.80 + 2.10 + (0.012 * carbonTax) + 0.20,
      delivered_market_value: prices.ttf_gas_usd_mmbtu,
    },
    {
      id: "ARB_CRUDE_PERMIAN_ROTTERDAM",
      name: "Permian WTI Crude to Rotterdam Refinery",
      commodity: "CRUDE_LIGHT",
      source_price: prices.wti_crude_usd_bbl,
      processing_cost: 0.50, // gathering
      transport_cost: 2.10 + 3.20, // pipe + tanker
      carbon_cost: (0.025 * carbonTax),
      tax_cost: 0.50,
      delivered_cost: prices.wti_crude_usd_bbl + 0.50 + 5.30 + (0.025 * carbonTax) + 0.50,
      delivered_market_value: prices.brent_crude_usd_bbl,
    },
    {
      id: "ARB_DIESEL_PASADENA_EUROPE",
      name: "US Gulf Coast ULSD Diesel Export to NWE",
      commodity: "DIESEL",
      source_price: prices.wti_crude_usd_bbl + prices.refining_nwe_cracking_margin_usd_bbl,
      processing_cost: 3.90, // refinery
      transport_cost: 2.80, // Product tanker
      carbon_cost: (0.040 * carbonTax),
      tax_cost: 0.80,
      delivered_cost: prices.wti_crude_usd_bbl + prices.refining_nwe_cracking_margin_usd_bbl + 3.90 + 2.80 + (0.040 * carbonTax) + 0.80,
      delivered_market_value: prices.brent_crude_usd_bbl + prices.refining_nwe_cracking_margin_usd_bbl * 1.35,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
            <Globe className="w-4 h-4 text-blue-400" />
            Global Trading Engine & Molecule Netback Calculator
          </h2>
          <p className="text-[11px] text-[#8B949E] mt-0.5">
            Full Molecule Cost Stack: Source + Processing + Transport + Storage + Trading + Tax + Carbon = Netback Margin.
          </p>
        </div>

        <div className="text-xs font-mono text-green-400 bg-[#0D1117] px-3 py-1.5 rounded border border-[#30363D]">
          Active Carbon Tax Rate: ${carbonTax}/ton CO2
        </div>
      </div>

      {/* Arbitrage Netback Breakdown Cards */}
      <div className="space-y-4">
        {arbitrageRoutes.map((arb) => {
          const netback = arb.delivered_market_value - arb.delivered_cost;
          const unit = arb.commodity === "LNG" ? "/ MMBtu" : "/ bbl";

          return (
            <div key={arb.id} className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#30363D] pb-3">
                <div>
                  <span className="text-[10px] font-bold text-blue-400 uppercase font-mono">{arb.commodity} Route</span>
                  <h3 className="font-bold text-white text-xs uppercase tracking-wider mt-0.5">{arb.name}</h3>
                </div>
                <div className="text-right font-mono">
                  <span className="text-[11px] text-[#8B949E] block">Delivered Netback Margin</span>
                  <span className={`text-base font-bold ${netback >= 0 ? "text-green-400" : "text-red-400"}`}>
                    {netback >= 0 ? "+" : ""}${netback.toFixed(2)} {unit}
                  </span>
                </div>
              </div>

              {/* Molecule Cost Stack Steps */}
              <div className="grid grid-cols-2 sm:grid-cols-7 gap-2 text-xs font-mono text-center">
                <div className="bg-[#0D1117] p-2.5 rounded border border-[#30363D]">
                  <span className="text-[#8B949E] text-[10px] block uppercase">Source Price</span>
                  <span className="text-white font-bold">${arb.source_price.toFixed(2)}</span>
                </div>
                <div className="bg-[#0D1117] p-2.5 rounded border border-[#30363D]">
                  <span className="text-[#8B949E] text-[10px] block uppercase">+ Processing</span>
                  <span className="text-[#E6EDF3]">${arb.processing_cost.toFixed(2)}</span>
                </div>
                <div className="bg-[#0D1117] p-2.5 rounded border border-[#30363D]">
                  <span className="text-[#8B949E] text-[10px] block uppercase">+ Transport</span>
                  <span className="text-[#E6EDF3]">${arb.transport_cost.toFixed(2)}</span>
                </div>
                <div className="bg-[#0D1117] p-2.5 rounded border border-[#30363D]">
                  <span className="text-[#8B949E] text-[10px] block uppercase">+ Carbon Tax</span>
                  <span className="text-red-400">${arb.carbon_cost.toFixed(2)}</span>
                </div>
                <div className="bg-[#0D1117] p-2.5 rounded border border-[#30363D]">
                  <span className="text-[#8B949E] text-[10px] block uppercase">= Delivered Cost</span>
                  <span className="text-yellow-400 font-bold">${arb.delivered_cost.toFixed(2)}</span>
                </div>
                <div className="bg-[#0D1117] p-2.5 rounded border border-[#30363D]">
                  <span className="text-[#8B949E] text-[10px] block uppercase">Market Value</span>
                  <span className="text-blue-400 font-bold">${arb.delivered_market_value.toFixed(2)}</span>
                </div>
                <div className="bg-green-950/40 border border-green-500/40 p-2.5 rounded">
                  <span className="text-green-300 text-[10px] block uppercase">Netback</span>
                  <span className="text-green-400 font-bold">${netback.toFixed(2)}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
