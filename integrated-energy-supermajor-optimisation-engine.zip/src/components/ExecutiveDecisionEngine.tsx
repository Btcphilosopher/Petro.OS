import React, { useState } from "react";
import { DecisionAnswer } from "../engine/decisionEngine";
import { HelpCircle, CheckCircle2, ChevronRight, Sparkles, AlertCircle } from "lucide-react";

interface ExecutiveDecisionEngineProps {
  decisions: DecisionAnswer[];
  onAskAiInsight: () => void;
  aiBriefingText: string | null;
  isLoadingAi: boolean;
}

export const ExecutiveDecisionEngine: React.FC<ExecutiveDecisionEngineProps> = ({
  decisions,
  onAskAiInsight,
  aiBriefingText,
  isLoadingAi,
}) => {
  const [activeDecisionId, setActiveDecisionId] = useState<string>(decisions[0]?.question_id || "DEC_INVEST");

  const activeDecision = decisions.find((d) => d.question_id === activeDecisionId) || decisions[0];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-blue-400" />
            Executive Decision Query Engine & Strategy OS
          </h2>
          <p className="text-[11px] text-[#8B949E] mt-0.5">
            System-wide optimization answers for capital allocation, crude selection, logistics, and carbon strategy.
          </p>
        </div>

        <button
          onClick={onAskAiInsight}
          disabled={isLoadingAi}
          className="flex items-center gap-2 bg-[#238636] hover:bg-[#2ea043] text-white px-4 py-2 rounded-md text-xs font-bold transition shadow-sm disabled:opacity-50"
        >
          <Sparkles className="w-4 h-4" />
          {isLoadingAi ? "Generating AI Briefing..." : "Generate AI Executive Briefing"}
        </button>
      </div>

      {/* AI Briefing Output Box */}
      {aiBriefingText && (
        <div className="bg-[#0D1117] border border-[#30363D] rounded-lg p-5 space-y-3 shadow-md">
          <div className="flex items-center gap-2 text-blue-400 font-bold text-xs uppercase tracking-wider">
            <Sparkles className="w-4 h-4 text-blue-400" />
            Gemini AI Executive Strategy Briefing
          </div>
          <div className="text-xs text-[#E6EDF3] leading-relaxed font-sans space-y-2 whitespace-pre-wrap">
            {aiBriefingText}
          </div>
        </div>
      )}

      {/* Grid: Decision Selector vs Active Decision Detail */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Decision Question Buttons */}
        <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-4 space-y-2">
          <h3 className="text-[10px] font-bold uppercase text-[#8B949E] px-2 tracking-wider mb-2">Core Strategic Questions</h3>
          {decisions.map((d) => {
            const isSelected = d.question_id === activeDecisionId;
            return (
              <button
                key={d.question_id}
                onClick={() => setActiveDecisionId(d.question_id)}
                className={`w-full text-left p-3 rounded-lg text-xs transition flex items-center justify-between border ${
                  isSelected
                    ? "border-blue-500 bg-blue-950/30 text-blue-400 font-bold"
                    : "border-[#30363D] bg-[#0D1117] text-[#E6EDF3] hover:border-[#8B949E]"
                }`}
              >
                <span className="line-clamp-2">{d.question}</span>
                <ChevronRight className="w-4 h-4 text-[#8B949E] flex-shrink-0" />
              </button>
            );
          })}
        </div>

        {/* Active Decision Breakdown */}
        <div className="lg:col-span-2 bg-[#161B22] border border-[#30363D] rounded-lg p-6 space-y-5">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold text-blue-400 font-mono tracking-wider">
              {activeDecision.question_id}
            </span>
            <h3 className="text-base font-bold text-white">{activeDecision.question}</h3>
          </div>

          <div className="bg-[#0D1117] border border-green-500/30 rounded-lg p-4 space-y-2">
            <div className="text-xs font-bold text-green-400 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-green-400" />
              {activeDecision.recommendation_title}
            </div>
            <p className="text-xs text-[#E6EDF3] leading-relaxed">{activeDecision.summary}</p>
          </div>

          {/* Key Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {activeDecision.key_metrics.map((m, idx) => (
              <div key={idx} className="bg-[#0D1117] border border-[#30363D] p-3 rounded-lg text-xs font-mono">
                <span className="text-[#8B949E] text-[10px] block uppercase">{m.label}</span>
                <span className={`text-base font-bold ${m.highlight ? "text-green-400" : "text-white"}`}>
                  {m.value}
                </span>
              </div>
            ))}
          </div>

          {/* Action Plan Checklist */}
          <div className="space-y-3 pt-2 border-t border-[#30363D]">
            <h4 className="font-bold text-xs text-white uppercase tracking-wider">Board Action Plan & Execution Roadmap:</h4>
            <ul className="space-y-2 text-xs text-[#E6EDF3] font-sans">
              {activeDecision.action_plan.map((item, idx) => (
                <li key={idx} className="flex items-start gap-2 bg-[#0D1117] p-2.5 rounded border border-[#30363D]">
                  <span className="text-green-400 font-bold font-mono min-w-[20px]">{idx + 1}.</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
