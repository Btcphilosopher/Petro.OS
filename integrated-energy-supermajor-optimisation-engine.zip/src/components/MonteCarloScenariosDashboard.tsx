import React from "react";
import { MacroScenarioDefinition, MonteCarloResult } from "../types/simulation";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { Dna, ShieldAlert, Sliders, TrendingUp, RefreshCw } from "lucide-react";

interface MonteCarloScenariosDashboardProps {
  currentScenario: MacroScenarioDefinition;
  allScenarios: MacroScenarioDefinition[];
  onSelectScenario: (sc: MacroScenarioDefinition) => void;
  monteCarloResult: MonteCarloResult;
  onRunSimulation: () => void;
  isSimulating: boolean;
}

export const MonteCarloScenariosDashboard: React.FC<MonteCarloScenariosDashboardProps> = ({
  currentScenario,
  allScenarios,
  onSelectScenario,
  monteCarloResult,
  onRunSimulation,
  isSimulating,
}) => {
  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
            <Dna className="w-4 h-4 text-blue-400" />
            10,000-Iteration Monte Carlo Risk & Scenario Engine
          </h2>
          <p className="text-[11px] text-[#8B949E] mt-0.5">
            Correlated Stochastic Distribution Sampling, P10/P50/P90 Quantiles, VaR 95% & Sobol Sensitivity Indices.
          </p>
        </div>

        <button
          onClick={onRunSimulation}
          disabled={isSimulating}
          className="flex items-center gap-2 bg-[#238636] hover:bg-[#2ea043] text-white px-4 py-2 rounded-md text-xs font-bold transition shadow-sm disabled:opacity-50"
        >
          {isSimulating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Dna className="w-4 h-4" />}
          {isSimulating ? "Running 10,000 Simulations..." : "Run 10,000 Monte Carlo Simulations"}
        </button>
      </div>

      {/* Quantile Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs font-mono">
        <div className="bg-[#161B22] border border-[#30363D] p-3.5 rounded-lg">
          <span className="text-[#8B949E] text-[10px] block uppercase">P10 Upside NPV</span>
          <span className="text-lg font-bold text-green-400">${(monteCarloResult.p10_npv_usd_m / 1000).toFixed(1)}B</span>
        </div>
        <div className="bg-[#161B22] border border-[#30363D] p-3.5 rounded-lg">
          <span className="text-[#8B949E] text-[10px] block uppercase">P50 Median NPV</span>
          <span className="text-lg font-bold text-blue-400">${(monteCarloResult.p50_npv_usd_m / 1000).toFixed(1)}B</span>
        </div>
        <div className="bg-[#161B22] border border-[#30363D] p-3.5 rounded-lg">
          <span className="text-[#8B949E] text-[10px] block uppercase">P90 Downside NPV</span>
          <span className="text-lg font-bold text-yellow-400">${(monteCarloResult.p90_npv_usd_m / 1000).toFixed(1)}B</span>
        </div>
        <div className="bg-[#161B22] border border-[#30363D] p-3.5 rounded-lg">
          <span className="text-[#8B949E] text-[10px] block uppercase">Value at Risk 95%</span>
          <span className="text-lg font-bold text-red-400">${monteCarloResult.value_at_risk_95_usd_m}M</span>
        </div>
        <div className="bg-[#161B22] border border-[#30363D] p-3.5 rounded-lg">
          <span className="text-[#8B949E] text-[10px] block uppercase">Expected Shortfall</span>
          <span className="text-lg font-bold text-red-300">${monteCarloResult.expected_shortfall_usd_m}M</span>
        </div>
        <div className="bg-[#161B22] border border-[#30363D] p-3.5 rounded-lg">
          <span className="text-[#8B949E] text-[10px] block uppercase">Prob of Loss %</span>
          <span className="text-lg font-bold text-white">{monteCarloResult.probability_of_loss_pct}%</span>
        </div>
      </div>

      {/* Grid Histogram & Tornado Sensitivity Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* NPV Histogram Chart */}
        <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 space-y-3">
          <h3 className="font-bold text-xs uppercase tracking-wider text-white flex items-center gap-2 border-b border-[#30363D] pb-3">
            <TrendingUp className="w-4 h-4 text-blue-400" />
            NPV Stochastic Frequency Distribution (10,000 Runs)
          </h3>

          <div className="h-[250px] w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monteCarloResult.distributions.npv_bins}>
                <CartesianGrid strokeDasharray="3 3" stroke="#30363D" />
                <XAxis dataKey="bin_label" stroke="#8B949E" fontSize={9} interval={1} />
                <YAxis stroke="#8B949E" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#0D1117", borderColor: "#30363D", borderRadius: "6px", fontSize: "12px", color: "#E6EDF3" }}
                />
                <Bar dataKey="count" fill="#58A6FF" radius={[2, 2, 0, 0]} name="Frequency Count" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Tornado Chart - Sobol Sensitivity */}
        <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 space-y-3">
          <h3 className="font-bold text-xs uppercase tracking-wider text-white flex items-center gap-2 border-b border-[#30363D] pb-3">
            <ShieldAlert className="w-4 h-4 text-red-400" />
            Sobol First-Order Sensitivity Indices (Tornado Sensitivity)
          </h3>

          <div className="space-y-3 pt-2 text-xs">
            {monteCarloResult.sensitivity_sobol_indices.map((item) => {
              const pct = Math.round(item.first_order_index * 100);
              return (
                <div key={item.variable} className="space-y-1 font-mono">
                  <div className="flex justify-between text-[#E6EDF3]">
                    <span className="font-sans font-medium">{item.variable}</span>
                    <span className="text-blue-400 font-bold">{pct}%</span>
                  </div>
                  <div className="w-full h-2.5 bg-[#0D1117] rounded-full overflow-hidden border border-[#30363D]">
                    <div className="h-full bg-gradient-to-r from-blue-500 to-red-500 rounded-full" style={{ width: `${pct}%` }}></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Preset Macro Scenarios Grid */}
      <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 space-y-4">
        <h3 className="font-bold text-xs uppercase tracking-wider text-white flex items-center gap-2 border-b border-[#30363D] pb-3">
          <Sliders className="w-4 h-4 text-blue-400" />
          17 Preset Global Macro Scenarios
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {allScenarios.map((sc) => {
            const isSelected = sc.id === currentScenario.id;
            return (
              <button
                key={sc.id}
                onClick={() => onSelectScenario(sc)}
                className={`p-4 rounded-lg text-left border transition space-y-2 ${
                  isSelected
                    ? "border-blue-500 bg-blue-950/30 text-white shadow-md"
                    : "border-[#30363D] bg-[#0D1117] text-[#E6EDF3] hover:border-[#8B949E]"
                }`}
              >
                <div className="flex justify-between items-start font-bold text-xs">
                  <span className={isSelected ? "text-blue-400 font-sans" : "text-white font-sans"}>{sc.name}</span>
                  {isSelected && <span className="text-[10px] bg-blue-500 text-white font-bold px-1.5 py-0.5 rounded">Active</span>}
                </div>
                <p className="text-[11px] text-[#8B949E] line-clamp-2">{sc.description}</p>
                <div className="flex items-center justify-between text-[10px] font-mono text-[#8B949E] pt-2 border-t border-[#30363D]">
                  <span>Brent: ${sc.prices.brent_crude_usd_bbl}</span>
                  <span>Carbon: ${sc.prices.carbon_price_usd_ton}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
