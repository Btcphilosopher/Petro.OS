import React from "react";
import { Play, Sparkles, Sliders, RefreshCw, Layers } from "lucide-react";
import { MacroScenarioDefinition } from "../types/simulation";

interface HeaderProps {
  currentScenario: MacroScenarioDefinition;
  allScenarios: MacroScenarioDefinition[];
  onSelectScenario: (scenario: MacroScenarioDefinition) => void;
  carbonTax: number;
  onChangeCarbonTax: (val: number) => void;
  capexBudget: number;
  onChangeCapexBudget: (val: number) => void;
  totalProductionKboed: number;
  totalFcfUsdM: number;
  portfolioRoicPct: number;
  totalCo2Mt: number;
  onRunSimulation: () => void;
  isSimulating: boolean;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onAskAiInsight: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentScenario,
  allScenarios,
  onSelectScenario,
  carbonTax,
  onChangeCarbonTax,
  capexBudget,
  onChangeCapexBudget,
  totalProductionKboed,
  totalFcfUsdM,
  portfolioRoicPct,
  totalCo2Mt,
  onRunSimulation,
  isSimulating,
  activeTab,
  setActiveTab,
  onAskAiInsight,
}) => {
  const tabs = [
    { id: "MAP", label: "Global Energy Map" },
    { id: "UPSTREAM", label: "Upstream & Reservoir" },
    { id: "REFINING", label: "Refining & Crude Slate" },
    { id: "MIDSTREAM", label: "Midstream & Shipping" },
    { id: "TRANSITION", label: "Power, H2 & Carbon" },
    { id: "TRADING", label: "Trading & Netbacks" },
    { id: "PORTFOLIO", label: "Capital Allocation & Bottlenecks" },
    { id: "MONTE_CARLO", label: "Monte Carlo & Scenarios" },
    { id: "DECISIONS", label: "Executive Decision Engine" },
  ];

  return (
    <header className="bg-[#161B22] border-b border-[#30363D] text-[#E6EDF3] sticky top-0 z-40 shadow-xl">
      {/* Top Banner */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-4 border-b border-[#30363D]/80">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-blue-500/10 border border-blue-500/30 text-blue-400 rounded flex items-center justify-center font-bold text-lg shadow-sm">
            ∑
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-semibold text-lg tracking-tight text-[#E6EDF3]">
                SUPERMAJOR <span className="text-blue-400 font-mono">OS v4.8</span>
              </h1>
              <span className="px-2 py-0.5 text-[10px] bg-blue-900/30 text-blue-400 border border-blue-500/30 rounded uppercase font-bold tracking-widest flex items-center gap-1.5 font-mono">
                <span className={`w-1.5 h-1.5 rounded-full ${isSimulating ? "bg-amber-400 animate-ping" : "bg-green-400"}`}></span>
                {isSimulating ? "Simulating..." : "System Active"}
              </span>
            </div>
            <p className="text-[11px] text-[#8B949E] tracking-tight">Integrated Enterprise Energy System & Capital Optimisation Engine</p>
          </div>
        </div>

        {/* Global Key Metric Cards */}
        <div className="flex items-center gap-3 text-xs">
          <div className="bg-[#0D1117] border border-[#30363D] rounded-lg px-3.5 py-1.5 min-w-[120px]">
            <div className="text-[#8B949E] text-[10px] uppercase font-bold tracking-wider mb-0.5">Total Production</div>
            <div className="text-sm font-bold text-white font-mono">{totalProductionKboed.toLocaleString()} <span className="text-[10px] text-[#8B949E]">kboed</span></div>
          </div>
          <div className="bg-[#0D1117] border border-[#30363D] rounded-lg px-3.5 py-1.5 min-w-[120px]">
            <div className="text-[#8B949E] text-[10px] uppercase font-bold tracking-wider mb-0.5">Free Cash Flow</div>
            <div className="text-sm font-bold text-green-400 font-mono">${totalFcfUsdM.toLocaleString()} <span className="text-[10px] text-[#8B949E]">M/yr</span></div>
          </div>
          <div className="bg-[#0D1117] border border-[#30363D] rounded-lg px-3.5 py-1.5 min-w-[120px]">
            <div className="text-[#8B949E] text-[10px] uppercase font-bold tracking-wider mb-0.5">Portfolio ROIC</div>
            <div className="text-sm font-bold text-blue-400 font-mono">{portfolioRoicPct}%</div>
          </div>
          <div className="bg-[#0D1117] border border-[#30363D] rounded-lg px-3.5 py-1.5 min-w-[120px]">
            <div className="text-[#8B949E] text-[10px] uppercase font-bold tracking-wider mb-0.5">Scope 1+2 CO2</div>
            <div className="text-sm font-bold text-amber-400 font-mono">{totalCo2Mt} <span className="text-[10px] text-[#8B949E]">MT</span></div>
          </div>
        </div>

        {/* Quick Action Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={onRunSimulation}
            disabled={isSimulating}
            className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white px-3.5 py-1.5 rounded text-xs font-bold uppercase tracking-wider transition shadow disabled:opacity-50"
          >
            {isSimulating ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5 fill-current" />}
            {isSimulating ? "Optimising..." : "Run Optimiser"}
          </button>
          <button
            onClick={onAskAiInsight}
            className="flex items-center gap-1.5 bg-[#21262D] hover:bg-[#30363D] text-[#E6EDF3] border border-[#30363D] px-3.5 py-1.5 rounded text-xs font-bold transition"
          >
            <Sparkles className="w-3.5 h-3.5 text-blue-400" />
            AI Briefing
          </button>
        </div>
      </div>

      {/* Secondary Scenario & Parameter Slider Bar */}
      <div className="max-w-7xl mx-auto px-4 py-2 bg-[#0D1117] flex flex-wrap items-center justify-between text-xs gap-4 border-b border-[#30363D]">
        <div className="flex items-center gap-2 font-mono">
          <span className="text-[#8B949E] uppercase tracking-wider text-[10px] flex items-center gap-1">
            <Sliders className="w-3.5 h-3.5 text-[#8B949E]" />
            Scenario:
          </span>
          <select
            value={currentScenario.id}
            onChange={(e) => {
              const sc = allScenarios.find((s) => s.id === e.target.value);
              if (sc) onSelectScenario(sc);
            }}
            className="bg-[#21262D] border border-[#30363D] text-blue-400 font-semibold px-2.5 py-1 rounded focus:outline-none focus:border-blue-500 text-xs"
          >
            {allScenarios.map((sc) => (
              <option key={sc.id} value={sc.id}>
                {sc.name}
              </option>
            ))}
          </select>
          <span className="text-[#30363D] hidden md:inline">|</span>
          <span className="text-[#8B949E] text-[11px] hidden md:inline">
            Brent: <strong className="text-white">${currentScenario.prices.brent_crude_usd_bbl}</strong> /bbl | TTF Gas:{" "}
            <strong className="text-white">${currentScenario.prices.ttf_gas_usd_mmbtu}</strong> /MMBtu
          </span>
        </div>

        <div className="flex items-center gap-6 font-mono text-xs">
          {/* Carbon Tax Slider */}
          <div className="flex items-center gap-2">
            <span className="text-[#8B949E]">Carbon Tax:</span>
            <input
              type="range"
              min={0}
              max={500}
              step={5}
              value={carbonTax}
              onChange={(e) => onChangeCarbonTax(Number(e.target.value))}
              className="w-24 accent-blue-500 cursor-pointer"
            />
            <span className="text-amber-400 font-bold min-w-[60px]">${carbonTax}/t CO2</span>
          </div>

          {/* CAPEX Budget Slider */}
          <div className="flex items-center gap-2">
            <span className="text-[#8B949E]">CAPEX Budget:</span>
            <input
              type="range"
              min={1000}
              max={10000}
              step={200}
              value={capexBudget}
              onChange={(e) => onChangeCapexBudget(Number(e.target.value))}
              className="w-24 accent-blue-500 cursor-pointer"
            />
            <span className="text-blue-400 font-bold min-w-[65px]">${capexBudget}M</span>
          </div>
        </div>
      </div>

      {/* Main Navigation Tabs */}
      <nav className="max-w-7xl mx-auto px-4 flex items-center overflow-x-auto no-scrollbar">
        {tabs.map((t) => {
          const isActive = activeTab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id)}
              className={`px-3.5 py-2.5 text-xs font-semibold whitespace-nowrap transition-colors border-b-2 uppercase tracking-wider ${
                isActive
                  ? "border-blue-500 text-blue-400 bg-blue-500/10"
                  : "border-transparent text-[#8B949E] hover:text-[#E6EDF3] hover:bg-[#161B22]"
              }`}
            >
              {t.label}
            </button>
          );
        })}
      </nav>
    </header>
  );
};
