import React from "react";
import { CapitalProjectCandidate, PortfolioOptimizationResult } from "../types/portfolio";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { PieChart, DollarSign, Award, CheckCircle, XCircle } from "lucide-react";

interface BottlenecksCapitalDashboardProps {
  candidates: CapitalProjectCandidate[];
  portfolioResult: PortfolioOptimizationResult;
  capexBudget: number;
}

export const BottlenecksCapitalDashboard: React.FC<BottlenecksCapitalDashboardProps> = ({
  candidates,
  portfolioResult,
  capexBudget,
}) => {
  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
            <PieChart className="w-4 h-4 text-blue-400" />
            Corporate Capital Allocation & Markowitz Efficient Frontier Engine
          </h2>
          <p className="text-[11px] text-[#8B949E] mt-0.5">
            Risk-Adjusted NPV Portfolio Optimization subject to CAPEX Budget, Debt Limits, ROIC & Carbon Constraints.
          </p>
        </div>

        <div className="flex items-center gap-3 text-xs font-mono">
          <div className="bg-[#0D1117] border border-[#30363D] px-3 py-1.5 rounded">
            <span className="text-[#8B949E] mr-2">Allocated CAPEX:</span>
            <strong className="text-blue-400">${portfolioResult.total_selected_capex}M / ${capexBudget}M</strong>
          </div>
          <div className="bg-[#0D1117] border border-[#30363D] px-3 py-1.5 rounded">
            <span className="text-[#8B949E] mr-2">Portfolio NPV:</span>
            <strong className="text-green-400">${portfolioResult.total_portfolio_npv}M</strong>
          </div>
          <div className="bg-[#0D1117] border border-[#30363D] px-3 py-1.5 rounded">
            <span className="text-[#8B949E] mr-2">Sharpe Ratio:</span>
            <strong className="text-yellow-400">{portfolioResult.risk_adjusted_sharpe_ratio}</strong>
          </div>
        </div>
      </div>

      {/* Markowitz Efficient Frontier Chart */}
      <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 space-y-3">
        <div className="flex items-center justify-between border-b border-[#30363D] pb-3">
          <h3 className="font-bold text-xs uppercase tracking-wider text-white flex items-center gap-2">
            <Award className="w-4 h-4 text-green-400" />
            Portfolio Efficient Frontier (CAPEX $M vs Expected NPV $M)
          </h3>
          <span className="text-xs text-[#8B949E] font-mono">Mixed-Integer LP Solver</span>
        </div>

        <div className="h-[260px] w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={portfolioResult.efficient_frontier_points}>
              <CartesianGrid strokeDasharray="3 3" stroke="#30363D" />
              <XAxis dataKey="capex" stroke="#8B949E" fontSize={11} unit="M" />
              <YAxis stroke="#8B949E" fontSize={11} unit="M" />
              <Tooltip
                contentStyle={{ backgroundColor: "#0D1117", borderColor: "#30363D", borderRadius: "6px", fontSize: "12px", color: "#E6EDF3" }}
              />
              <Line type="monotone" dataKey="npv" stroke="#3FB950" strokeWidth={3} dot={{ fill: "#3FB950", r: 5 }} name="Portfolio NPV ($M)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Capital Candidate Projects Ranking Table */}
      <div className="bg-[#161B22] border border-[#30363D] rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-[#30363D] pb-3">
          <h3 className="font-bold text-xs uppercase tracking-wider text-white flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-yellow-400" />
            Capital Project Candidates Ranked by Risk-Adjusted NPV / CAPEX Ratio
          </h3>
          <span className="text-xs text-[#8B949E] font-mono">
            {portfolioResult.selected_projects.filter((p) => p.selected).length} Projects Selected
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#E6EDF3]">
            <thead className="bg-[#0D1117] text-[#8B949E] uppercase text-[10px] border-b border-[#30363D] font-mono">
              <tr>
                <th className="p-3">Status</th>
                <th className="p-3">Project Name</th>
                <th className="p-3">Segment</th>
                <th className="p-3">Capex ($M)</th>
                <th className="p-3">IRR (%)</th>
                <th className="p-3">NPV ($M)</th>
                <th className="p-3">Risk-Adj NPV ($M)</th>
                <th className="p-3">Carbon Abatement</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#30363D] font-mono">
              {portfolioResult.selected_projects.map((proj) => (
                <tr key={proj.project_id} className={proj.selected ? "bg-[#21262D]/50" : "opacity-60"}>
                  <td className="p-3">
                    {proj.selected ? (
                      <span className="inline-flex items-center gap-1 text-green-400 font-bold">
                        <CheckCircle className="w-3.5 h-3.5" /> Sanctioned
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[#8B949E]">
                        <XCircle className="w-3.5 h-3.5" /> Deferred
                      </span>
                    )}
                  </td>
                  <td className="p-3 font-semibold text-white font-sans">{proj.name}</td>
                  <td className="p-3 text-blue-400">{proj.segment.replace(/_/g, " ")}</td>
                  <td className="p-3 text-white">${proj.capex_usd_m}M</td>
                  <td className="p-3 text-green-400 font-bold">{proj.irr_pct}%</td>
                  <td className="p-3 text-yellow-400 font-bold">${proj.npv_usd_m}M</td>
                  <td className="p-3 text-green-400 font-bold">${proj.risk_adjusted_npv}M</td>
                  <td className="p-3">
                    {proj.carbon_abatement_potential_kton_yr >= 0 ? (
                      <span className="text-green-400">+{proj.carbon_abatement_potential_kton_yr} kt/yr</span>
                    ) : (
                      <span className="text-red-400">{proj.carbon_abatement_potential_kton_yr} kt/yr</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
