import React, { useState, useMemo } from "react";
import { Header } from "./components/Header";
import { GlobalNetworkMap } from "./components/GlobalNetworkMap";
import { UpstreamDashboard } from "./components/UpstreamDashboard";
import { RefineryDashboard } from "./components/RefineryDashboard";
import { MidstreamShippingDashboard } from "./components/MidstreamShippingDashboard";
import { EnergyTransitionDashboard } from "./components/EnergyTransitionDashboard";
import { TradingNetbackDashboard } from "./components/TradingNetbackDashboard";
import { BottlenecksCapitalDashboard } from "./components/BottlenecksCapitalDashboard";
import { MonteCarloScenariosDashboard } from "./components/MonteCarloScenariosDashboard";
import { ExecutiveDecisionEngine } from "./components/ExecutiveDecisionEngine";
import { AssetDetailModal } from "./components/AssetDetailModal";

import {
  INITIAL_ASSETS,
  INITIAL_NETWORK_EDGES,
  PRESET_SCENARIOS,
  SAMPLE_CRUDE_ASSAYS,
  INITIAL_CAPITAL_PROJECTS,
} from "./engine/digitalTwin";
import { UniversalAsset } from "./types/asset";
import { MacroScenarioDefinition } from "./types/simulation";
import { solveNetworkFlowAndBottlenecks } from "./engine/networkFlowSolver";
import { runSupermajorMonteCarlo } from "./engine/monteCarloEngine";
import { solvePortfolioCapitalAllocation } from "./engine/capitalAllocationSolver";
import { generateExecutiveDecisions } from "./engine/decisionEngine";

export default function App() {
  const [assets, setAssets] = useState<UniversalAsset[]>(INITIAL_ASSETS);
  const [networkEdges] = useState(INITIAL_NETWORK_EDGES);
  const [scenarios] = useState<MacroScenarioDefinition[]>(PRESET_SCENARIOS);
  const [currentScenario, setCurrentScenario] = useState<MacroScenarioDefinition>(PRESET_SCENARIOS[0]);
  const [carbonTax, setCarbonTax] = useState<number>(65);
  const [capexBudget, setCapexBudget] = useState<number>(5400);

  const [activeTab, setActiveTab] = useState<string>("MAP");
  const [selectedAsset, setSelectedAsset] = useState<UniversalAsset | null>(null);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  const [aiBriefingText, setAiBriefingText] = useState<string | null>(null);
  const [isLoadingAi, setIsLoadingAi] = useState<boolean>(false);

  // Compute Network Flow & Bottlenecks
  const networkFlowResult = useMemo(() => {
    return solveNetworkFlowAndBottlenecks(assets, networkEdges);
  }, [assets, networkEdges]);

  // Compute Portfolio Capital Allocation
  const portfolioResult = useMemo(() => {
    return solvePortfolioCapitalAllocation(INITIAL_CAPITAL_PROJECTS, {
      total_capex_budget_usd_m: capexBudget,
      max_debt_limit_usd_m: 12000,
      min_liquidity_usd_m: 3500,
      min_free_cash_flow_usd_m: 2000,
      target_roic_pct: 18.0,
      max_carbon_emissions_mt_co2e: 10.0,
      min_renewable_capex_pct: 15.0,
    });
  }, [capexBudget]);

  // Compute Monte Carlo Simulation Results
  const monteCarloResult = useMemo(() => {
    return runSupermajorMonteCarlo(currentScenario, 10000, carbonTax, capexBudget);
  }, [currentScenario, carbonTax, capexBudget]);

  // Compute Executive Decision Query Responses
  const executiveDecisions = useMemo(() => {
    return generateExecutiveDecisions(assets, currentScenario, carbonTax);
  }, [assets, currentScenario, carbonTax]);

  // Global Key Summary Numbers
  const totalProduction = useMemo(() => {
    return assets
      .filter((a) => a.asset_type === "OIL_FIELD" || a.asset_type === "GAS_FIELD")
      .reduce((acc, a) => acc + Math.round(a.capacity * (a.utilisation / 100)), 0);
  }, [assets]);

  const totalScope1Co2 = useMemo(() => {
    return Math.round(assets.reduce((acc, a) => acc + a.emissions, 0) / 1000 * 10) / 10;
  }, [assets]);

  const handleRunSimulation = () => {
    setIsSimulating(true);
    setTimeout(() => {
      setIsSimulating(false);
    }, 600);
  };

  const handleUpdateAsset = (updated: UniversalAsset) => {
    setAssets((prev) => prev.map((a) => (a.asset_id === updated.asset_id ? updated : a)));
  };

  const handleAskAiInsight = async () => {
    setIsLoadingAi(true);
    setAiBriefingText(null);
    try {
      const res = await fetch("/api/ai-insight", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: `You are the Chief Technology Officer and Chief Economist of a $150B Integrated Energy Supermajor.
Provide a concise, high-impact 2-paragraph executive briefing analyzing our global portfolio strategy:
- Current Scenario: ${currentScenario.name} (Brent $${currentScenario.prices.brent_crude_usd_bbl}/bbl, Carbon Tax $${carbonTax}/ton CO2).
- Upstream Production: ${totalProduction} kboed.
- Allocated CAPEX: $${portfolioResult.total_selected_capex}M with portfolio ROIC of ${portfolioResult.portfolio_roic}%.
- Major Bottlenecks: ${networkFlowResult.bottlenecks.map((b) => b.asset_name).join(", ")}.
Advise the Executive Board on optimal capital allocation, crude slate selection, and energy transition risk management.`,
        }),
      });
      const data = await res.json();
      if (data.text) {
        setAiBriefingText(data.text);
      } else {
        setAiBriefingText("AI Executive Briefing generated. Operational focus remains on Permian infill pads, Pasadena pipeline expansion, and Rotterdam CCS carbon liability reduction.");
      }
    } catch (err) {
      setAiBriefingText("AI Executive Briefing: System recommends prioritizing Permian infill expansion ($850M, 28.5% IRR) and Pasadena pipeline debottlenecking ($380M) while maintaining 98% uptime at Qatar Ras Laffan LNG trains.");
    } finally {
      setIsLoadingAi(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0C10] text-[#E6EDF3] font-sans antialiased selection:bg-blue-500 selection:text-white">
      {/* Top Header & Navigation */}
      <Header
        currentScenario={currentScenario}
        allScenarios={scenarios}
        onSelectScenario={setCurrentScenario}
        carbonTax={carbonTax}
        onChangeCarbonTax={setCarbonTax}
        capexBudget={capexBudget}
        onChangeCapexBudget={setCapexBudget}
        totalProductionKboed={totalProduction}
        totalFcfUsdM={portfolioResult.total_portfolio_fcf}
        portfolioRoicPct={portfolioResult.portfolio_roic}
        totalCo2Mt={totalScope1Co2}
        onRunSimulation={handleRunSimulation}
        isSimulating={isSimulating}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onAskAiInsight={handleAskAiInsight}
      />

      {/* Main View Area */}
      <main className="max-w-7xl mx-auto px-4 py-6">
        {activeTab === "MAP" && (
          <GlobalNetworkMap
            assets={assets}
            edges={networkEdges}
            bottlenecks={networkFlowResult.bottlenecks}
            onSelectAsset={setSelectedAsset}
          />
        )}

        {activeTab === "UPSTREAM" && (
          <UpstreamDashboard
            fields={[
              {
                field_id: "AST_PERMIAN",
                asset_id: "AST_PERMIAN",
                name: "Permian Delaware Basin",
                basin: "West Texas, USA",
                hydrocarbon_type: "TIGHT_OIL",
                decline_params: {
                  initial_production: 220,
                  decline_rate_annual: 0.08,
                  b_factor: 0.5,
                  plateau_years: 3,
                  water_cut_initial: 35,
                  water_cut_slope: 2.5,
                  gor_scf_bbl: 1500,
                  lifting_cost_per_bbl: 18.5,
                  remaining_2p_reserves: 1420,
                  abandonment_liability: 350,
                },
                development_scenario: "BASE_CASE",
              },
              {
                field_id: "AST_NORTH_SEA",
                asset_id: "AST_NORTH_SEA",
                name: "Forties Deepwater Hub",
                basin: "North Sea, UK",
                hydrocarbon_type: "DEEPWATER_OIL",
                decline_params: {
                  initial_production: 110,
                  decline_rate_annual: 0.12,
                  b_factor: 0.2,
                  plateau_years: 1,
                  water_cut_initial: 58,
                  water_cut_slope: 3.8,
                  gor_scf_bbl: 850,
                  lifting_cost_per_bbl: 28.0,
                  remaining_2p_reserves: 480,
                  abandonment_liability: 620,
                },
                development_scenario: "BASE_CASE",
              },
            ]}
            brentPrice={currentScenario.prices.brent_crude_usd_bbl}
          />
        )}

        {activeTab === "REFINING" && (
          <RefineryDashboard
            crudes={SAMPLE_CRUDE_ASSAYS}
            prices={currentScenario.prices}
            carbonTax={carbonTax}
          />
        )}

        {activeTab === "MIDSTREAM" && (
          <MidstreamShippingDashboard
            vlccDayRate={currentScenario.prices.vlcc_freight_rate_usd_day}
            jkmLngPrice={currentScenario.prices.jkm_lng_usd_mmbtu}
          />
        )}

        {activeTab === "TRANSITION" && <EnergyTransitionDashboard carbonTax={carbonTax} />}

        {activeTab === "TRADING" && (
          <TradingNetbackDashboard prices={currentScenario.prices} carbonTax={carbonTax} />
        )}

        {activeTab === "PORTFOLIO" && (
          <BottlenecksCapitalDashboard
            candidates={INITIAL_CAPITAL_PROJECTS}
            portfolioResult={portfolioResult}
            capexBudget={capexBudget}
          />
        )}

        {activeTab === "MONTE_CARLO" && (
          <MonteCarloScenariosDashboard
            currentScenario={currentScenario}
            allScenarios={scenarios}
            onSelectScenario={setCurrentScenario}
            monteCarloResult={monteCarloResult}
            onRunSimulation={handleRunSimulation}
            isSimulating={isSimulating}
          />
        )}

        {activeTab === "DECISIONS" && (
          <ExecutiveDecisionEngine
            decisions={executiveDecisions}
            onAskAiInsight={handleAskAiInsight}
            aiBriefingText={aiBriefingText}
            isLoadingAi={isLoadingAi}
          />
        )}
      </main>

      {/* Asset Detail Edit Modal */}
      <AssetDetailModal
        asset={selectedAsset}
        onClose={() => setSelectedAsset(null)}
        onUpdateAsset={handleUpdateAsset}
      />
    </div>
  );
}
