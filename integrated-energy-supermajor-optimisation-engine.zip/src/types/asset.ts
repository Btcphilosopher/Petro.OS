export type AssetType =
  | "OIL_FIELD"
  | "GAS_FIELD"
  | "LNG_FACILITY"
  | "PIPELINE"
  | "TERMINAL"
  | "STORAGE"
  | "TANKER"
  | "REFINERY"
  | "PETROCHEMICAL_PLANT"
  | "POWER_PLANT"
  | "RENEWABLE_GEN"
  | "HYDROGEN_FACILITY"
  | "CARBON_CAPTURE"
  | "TRADING_DESK"
  | "RETAIL_NETWORK";

export type CommodityType =
  | "CRUDE_LIGHT"
  | "CRUDE_HEAVY"
  | "CRUDE_SOUR"
  | "NATURAL_GAS"
  | "LNG"
  | "GASOLINE"
  | "DIESEL"
  | "JET_FUEL"
  | "FUEL_OIL"
  | "LPG"
  | "NAPHTHA"
  | "ETHYLENE"
  | "PROPYLENE"
  | "AROMATICS"
  | "ELECTRICITY"
  | "HYDROGEN_GREY"
  | "HYDROGEN_BLUE"
  | "HYDROGEN_GREEN"
  | "CARBON_CREDIT";

export interface AssetInputOutput {
  commodity: CommodityType;
  rate: number; // e.g. kboed, ktons/yr, GWh/yr
  unit: string;
}

export interface UniversalAsset {
  asset_id: string;
  name: string;
  asset_type: AssetType;
  location: string;
  region: "NORTH_AMERICA" | "EUROPE" | "MIDDLE_EAST" | "ASIA_PACIFIC" | "LATIN_AMERICA" | "AFRICA";
  coordinates: [number, number]; // [lat, lng]
  ownership: number; // percentage, e.g. 100 or 75
  capacity: number; // max throughput/production rate
  capacity_unit: string; // "kboed", "MTPA", "kbpd", "MW", "kt/yr"
  operating_cost: number; // $/unit or $M/yr
  capital_cost: number; // $M total historical/replacement
  remaining_life: number; // years
  maintenance_schedule: string; // e.g., "Q2 Turnaround - 14 days"
  availability: number; // percentage e.g. 96.5%
  utilisation: number; // percentage e.g. 88.0%
  energy_consumption: number; // MW or GJ/d
  emissions: number; // kton CO2e / yr
  revenue: number; // $M / yr
  risk: number; // scale 1-10 (geopolitical, operational, price)
  dependencies: string[]; // asset_ids this asset feeds from or depends on
  inputs: AssetInputOutput[];
  outputs: AssetInputOutput[];
  // Additional module-specific metadata
  status: "OPERATIONAL" | "MAINTENANCE" | "EXPANSION_PLANNED" | "SHUT_DOWN";
}
