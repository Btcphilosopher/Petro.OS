export interface PipelineSegment {
  pipeline_id: string;
  name: string;
  origin_node: string;
  destination_node: string;
  capacity_bpd_or_mcfd: number;
  current_flow: number;
  tariff_per_unit: number; // $/bbl or $/MMBtu
  energy_loss_pct: number;
  length_km: number;
  is_bottleneck: boolean;
  shadow_value_per_unit_expansion: number; // $/bbl/d per year expansion
}

export interface TankerVessel {
  vessel_id: string;
  name: string;
  vessel_type: "VLCC" | "SUEZMAX" | "AFRAMAX" | "PRODUCT_MR" | "LNG_CARRIER_174K" | "LPG_CARRIER";
  capacity_bbl_or_cbm: number;
  charter_rate_per_day: number; // $/day
  fuel_consumption_tons_per_day: number;
  current_location: string;
  assigned_cargo?: {
    cargo_id: string;
    origin: string;
    destination: string;
    commodity: string;
    volume: number;
    demurrage_risk_days: number;
  };
  status: "AT_SEA" | "LOADING" | "UNLOADING" | "IDLE" | "DRYDOCK";
}

export interface StorageTerminal {
  terminal_id: string;
  name: string;
  location: string;
  commodity: string;
  total_capacity: number; // kbbl or kCBM or ktons
  current_inventory: number;
  working_capital_locked_usd: number;
  holding_cost_per_unit_month: number;
  price_exposure_risk: number; // Value at Risk $M
  optimal_target_inventory: number;
}

export interface LNGValueChain {
  chain_id: string;
  name: string;
  liquefaction_plant_id: string;
  regas_terminal_id: string;
  feedgas_cost_mmbtu: number;
  liquefaction_cost_mmbtu: number;
  shipping_cost_mmbtu: number;
  regas_cost_mmbtu: number;
  total_delivered_cost_mmbtu: number;
  destination_market_price_mmbtu: number; // e.g. JKM $14.50 or TTF $11.80
  netback_margin_mmbtu: number;
  annual_volume_mtpa: number;
}
