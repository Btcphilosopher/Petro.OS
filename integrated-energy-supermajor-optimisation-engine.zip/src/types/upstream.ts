export type DeclineModelType = "EXPONENTIAL" | "HYPERBOLIC" | "HARMONIC" | "USER_DEFINED";

export interface FieldDeclineParameters {
  initial_production: number; // kboed
  decline_rate_annual: number; // e.g. 0.08 = 8% per year
  b_factor: number; // Arps hyperbolic b factor (0 = exponential, 0.5 = hyperbolic, 1 = harmonic)
  plateau_years: number; // years of constant production before decline
  water_cut_initial: number; // % initial water cut
  water_cut_slope: number; // % increase per year
  gor_scf_bbl: number; // Gas-Oil Ratio in scf/bbl
  lifting_cost_per_bbl: number; // $/bbl
  remaining_2p_reserves: number; // MMboe
  abandonment_liability: number; // $M
}

export interface UpstreamField {
  field_id: string;
  asset_id: string;
  name: string;
  basin: string;
  hydrocarbon_type: "LIGHT_OIL" | "HEAVY_OIL" | "DEEPWATER_OIL" | "CONVENTIONAL_GAS" | "SHALE_GAS" | "TIGHT_OIL";
  decline_params: FieldDeclineParameters;
  development_scenario: "BASE_CASE" | "ACCELERATED_INFILL" | "EOR_WATERFLOOD" | "LOW_CAPEX_HARVEST";
}

export interface WellOpportunity {
  well_id: string;
  field_id: string;
  name: string;
  well_capex: number; // $M per well
  rig_cost_per_day: number; // $k/day
  drilling_days: number;
  completion_cost: number; // $M
  initial_ip_bpd: number; // initial production bpd
  decline_rate: number; // annual
  success_probability: number; // 0-1
  npv_10: number; // $M @ 10% WACC
  irr: number; // %
  payback_months: number;
  breakeven_oil_price: number; // $/bbl
  breakeven_gas_price: number; // $/MMBtu
  rank: number;
}
