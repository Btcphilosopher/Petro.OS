export type HydrogenType = "GREY" | "BLUE" | "GREEN";

export interface PowerAssetConfig {
  asset_id: string;
  name: string;
  technology: "NATURAL_GAS_CCGT" | "SOLAR_PV" | "WIND_OFFSHORE" | "NUCLEAR" | "BATTERY_STORAGE" | "GRID_IMPORT";
  capacity_mw: number;
  capacity_factor_pct: number;
  marginal_cost_mwh: number; // $/MWh
  co2_intensity_kg_mwh: number;
  fuel_consumption_mcf_mwh?: number;
}

export interface HydrogenFacilityConfig {
  asset_id: string;
  name: string;
  type: HydrogenType;
  capacity_tons_per_day: number;
  capex_usd_m: number;
  opex_usd_per_kg: number;
  electricity_kwh_per_kg?: number; // for green hydrogen water electrolysis
  natural_gas_mcf_per_kg?: number; // for SMR (grey/blue)
  ccs_capture_rate_pct?: number; // e.g. 95% for blue H2
  lcoh_usd_per_kg: number; // Levelised Cost of Hydrogen
  allocated_end_use: {
    refining_kbpd_equivalent: number;
    petrochem_kbpd_equivalent: number;
    power_blend_pct: number;
    export_liquid_h2_tpd: number;
  };
}

export interface CarbonManagementConfig {
  carbon_price_usd_per_ton: number; // e.g. $0, $25, $50, $100, $200, $500
  scope1_emissions_mt_co2e: number; // Million metric tons
  scope2_emissions_mt_co2e: number;
  scope3_emissions_mt_co2e: number;
  ccs_projects: {
    project_id: string;
    name: string;
    capture_capacity_mt_yr: number;
    capture_cost_usd_ton: number;
    transport_storage_cost_usd_ton: number;
    avoided_cost_usd_ton: number;
    npv_at_current_carbon_price: number;
  }[];
  total_carbon_tax_liability_usd_m: number;
}
