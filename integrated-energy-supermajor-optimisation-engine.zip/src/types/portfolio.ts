export type CapitalProjectSegment =
  | "UPSTREAM_EXPLORATION"
  | "UPSTREAM_DEVELOPMENT"
  | "MIDSTREAM_PIPELINE"
  | "LNG_EXPANSION"
  | "REFINERY_UPGRADE"
  | "PETROCHEM_CRACKER"
  | "RENEWABLE_POWER"
  | "HYDROGEN_GREEN"
  | "CARBON_CAPTURE_CCS"
  | "SHIPPING_FLEET";

export interface CapitalProjectCandidate {
  project_id: string;
  name: string;
  segment: CapitalProjectSegment;
  location: string;
  capex_usd_m: number;
  annual_opex_usd_m: number;
  npv_usd_m: number;
  irr_pct: number;
  payback_period_years: number;
  carbon_abatement_potential_kton_yr: number; // positive = saves carbon
  risk_score: number; // 1-10
  risk_adjusted_npv: number;
  real_option_value_usd_m: number; // Option to delay, expand, or abandon
  strategic_alignment_score: number; // 1-100
  selected: boolean;
  rank: number;
}

export interface PortfolioConstraints {
  total_capex_budget_usd_m: number;
  max_debt_limit_usd_m: number;
  min_liquidity_usd_m: number;
  min_free_cash_flow_usd_m: number;
  target_roic_pct: number;
  max_carbon_emissions_mt_co2e: number;
  min_renewable_capex_pct: number;
}

export interface PortfolioOptimizationResult {
  total_selected_capex: number;
  total_portfolio_npv: number;
  total_portfolio_fcf: number;
  portfolio_roic: number;
  portfolio_emissions_mt: number;
  risk_adjusted_sharpe_ratio: number;
  capital_allocated_by_segment: Record<CapitalProjectSegment, number>;
  selected_projects: CapitalProjectCandidate[];
  efficient_frontier_points: { capex: number; npv: number; risk: number; emissions: number }[];
}
