export interface CrudeAssay {
  crude_id: string;
  name: string;
  origin: string;
  api_gravity: number; // e.g. 38.5 (Brent) vs 22.0 (Maya)
  sulphur_weight_pct: number; // e.g. 0.45% (Sweet) vs 2.8% (Sour)
  metals_ppm: number; // Vanadium + Nickel
  tan_acidity: number; // Total Acid Number mg KOH/g
  yields: {
    lpg: number; // % mass
    naphtha: number;
    gasoline_blendstock: number;
    kerosene_jet: number;
    diesel_gasoil: number;
    vacuum_gas_oil: number; // VGO
    residue: number; // Vacuum Residue
  };
  freight_to_refinery: number; // $/bbl
  purchase_price_fob: number; // $/bbl
}

export interface RefineryUnit {
  unit_id: string;
  name: string;
  type: "CDU" | "VDU" | "FCC" | "HYDROCRACKER" | "REFORMER" | "HYDROTREATER" | "ALKYLATION" | "BLENDING";
  capacity_bpd: number;
  operating_cost_per_bbl: number;
  energy_intensity_gj_bbl: number;
  hydrogen_consumption_scf_bbl: number;
  yield_multiplier: number;
}

export interface ProductBlendSpec {
  product_name: "GASOLINE_95_RON" | "DIESEL_ULSD" | "JET_A1" | "VERY_LOW_SULPHUR_FUEL_OIL";
  min_octane?: number;
  min_cetane?: number;
  max_sulphur_ppm: number;
  max_rvp_psi?: number; // Reid Vapor Pressure
  min_density_kg_m3?: number;
  max_density_kg_m3?: number;
  market_price_per_bbl: number; // $/bbl
}

export interface RefinerySlateOptimizationResult {
  refinery_id: string;
  refinery_name: string;
  crude_purchases: {
    crude_id: string;
    volume_bpd: number;
    delivered_cost_bbl: number;
    gross_margin_contribution_bbl: number;
  }[];
  total_crude_intake_bpd: number;
  total_product_yield_bpd: {
    gasoline: number;
    diesel: number;
    jet_fuel: number;
    fuel_oil: number;
    lpg: number;
    petrochem_feed: number;
  };
  refinery_gross_margin_per_bbl: number; // $/bbl
  total_daily_margin_usd: number; // $ / day
  co2_emissions_kton_yr: number;
  hydrogen_deficit_scfd: number;
}
