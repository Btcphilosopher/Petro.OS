import { UniversalAsset } from "./asset";

export type MacroScenarioId =
  | "BASE_CASE"
  | "OIL_SUPER_CYCLE"
  | "OIL_CRASH"
  | "GAS_CRISIS"
  | "GLOBAL_RECESSION"
  | "HIGH_CARBON_PRICE"
  | "LOW_CARBON_PRICE"
  | "LNG_BOOM"
  | "REFINING_MARGIN_BOOM"
  | "SUPPLY_SHOCK"
  | "SHIPPING_DISRUPTION"
  | "MAJOR_FIELD_FAILURE"
  | "REFINERY_OUTAGE"
  | "HIGH_INTEREST_RATES"
  | "LOW_INTEREST_RATES"
  | "TRANSITION_ACCELERATION"
  | "TRANSITION_DELAY";

export interface CommodityPrices {
  brent_crude_usd_bbl: number;
  wti_crude_usd_bbl: number;
  henry_hub_gas_usd_mmbtu: number;
  ttf_gas_usd_mmbtu: number;
  jkm_lng_usd_mmbtu: number;
  refining_nwe_cracking_margin_usd_bbl: number;
  ethylene_margin_usd_ton: number;
  power_eu_usd_mwh: number;
  carbon_price_usd_ton: number;
  vlcc_freight_rate_usd_day: number;
}

export interface MacroScenarioDefinition {
  id: MacroScenarioId;
  name: string;
  description: string;
  prices: CommodityPrices;
  demand_growth_pct: number;
  inflation_rate_pct: number;
  wacc_pct: number;
}

export interface MonteCarloInputVariables {
  iterations: number; // e.g. 10000
  oil_price_std_dev: number;
  gas_price_std_dev: number;
  carbon_price_std_dev: number;
  capex_cost_overrun_std_dev: number;
  production_outage_prob: number;
}

export interface MonteCarloResult {
  p10_npv_usd_m: number;
  p50_npv_usd_m: number; // Median
  p90_npv_usd_m: number; // Downside
  mean_free_cash_flow_usd_m: number;
  value_at_risk_95_usd_m: number;
  expected_shortfall_usd_m: number;
  probability_of_loss_pct: number;
  distributions: {
    npv_bins: { bin_label: string; count: number; cumulative_pct: number }[];
    fcf_bins: { bin_label: string; count: number }[];
  };
  sensitivity_sobol_indices: {
    variable: string;
    first_order_index: number; // 0 to 1
  }[];
}

export interface BottleneckAnalysis {
  asset_id: string;
  asset_name: string;
  type: string;
  capacity: number;
  current_throughput: number;
  utilisation_pct: number;
  constraint_type: "PHYSICAL_PIPELINE" | "REFINERY_UNIT" | "TANKER_FLEET" | "STORAGE_CAPACITY" | "POWER_GRID";
  bottleneck_value_usd_per_day: number; // Shadow price
  expansion_capex_usd_m: number;
  expansion_payback_months: number;
  expansion_npv_usd_m: number;
  recommendation: string;
}

export interface NetworkEdge {
  id: string;
  from_asset_id: string;
  to_asset_id: string;
  commodity: string;
  capacity: number;
  current_flow: number;
  cost_per_unit: number;
  carbon_intensity_kg_unit: number;
  risk_factor: number;
  unit: string;
}

export interface SupermajorState {
  assets: UniversalAsset[];
  network_edges: NetworkEdge[];
  current_scenario: MacroScenarioDefinition;
  carbon_tax_rate: number; // $/t
  capex_budget_usd_m: number;
  monte_carlo_runs: number;
}
