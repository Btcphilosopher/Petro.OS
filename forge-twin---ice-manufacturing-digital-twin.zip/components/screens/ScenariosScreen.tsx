'use client';

import React, { useState } from 'react';
import { EngineConfig } from '@/types/engine';
import { ScenarioDefinition } from '@/types/scenarios';
import { propagateScenarioImpact } from '@/lib/simulation/scenarioPropagationEngine';
import { GitBranch, Sliders, CheckCircle2, ArrowRight, DollarSign, Activity, ShieldCheck, Zap } from 'lucide-react';

interface ScenariosScreenProps {
  engineConfig: EngineConfig;
}

export default function ScenariosScreen({ engineConfig }: ScenariosScreenProps) {
  // Scenario Preset Definitions
  const baselineScenario: ScenarioDefinition = {
    id: 'baseline',
    name: 'Baseline Standard Production',
    description: 'Standard factory baseline tolerance and speed settings',
    createdAt: '2026-09-02',
    boreToleranceMm: 0.015,
    pistonMaterialId: 'mat_alu_356',
    cycleTimeMultiplier: 1.0,
    machineCountCNC: 4,
    maintenanceIntervalHours: 500,
    targetShiftVolume: 120,
  };

  const tightToleranceScenario: ScenarioDefinition = {
    id: 'tight_tolerance',
    name: 'High-Precision Tight Tolerance (Bore ±0.008mm)',
    description: 'Precision honing tolerance with extended machining cycle time',
    createdAt: '2026-09-02',
    boreToleranceMm: 0.008,
    pistonMaterialId: 'mat_alu_356',
    cycleTimeMultiplier: 1.2,
    machineCountCNC: 4,
    maintenanceIntervalHours: 400,
    targetShiftVolume: 100,
  };

  const highSpeedScenario: ScenarioDefinition = {
    id: 'high_throughput',
    name: 'High-Throughput Fast Cycle (Bore ±0.022mm)',
    description: 'Accelerated machine cycle time for increased shift volume',
    createdAt: '2026-09-02',
    boreToleranceMm: 0.022,
    pistonMaterialId: 'mat_alu_356',
    cycleTimeMultiplier: 0.82,
    machineCountCNC: 4,
    maintenanceIntervalHours: 350,
    targetShiftVolume: 145,
  };

  const [activeScenario, setActiveScenario] = useState<ScenarioDefinition>(tightToleranceScenario);

  const baselineResult = propagateScenarioImpact(baselineScenario, engineConfig);
  const activeResult = propagateScenarioImpact(activeScenario, engineConfig);

  return (
    <div className="p-4 space-y-4 overflow-y-auto h-[calc(100vh-50px)] bg-graphite-950 font-mono-tech text-xs">
      <div className="bg-graphite-900 border border-graphite-800 p-3 rounded flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 rounded">
            <GitBranch className="w-5 h-5" />
          </div>
          <div>
            <span className="font-bold text-gray-100 text-sm">WHAT-IF SCENARIO SIMULATION & PROPAGATION ENGINE</span>
            <p className="text-gray-400 text-[11px]">Tweak Tolerance or Process Speed → Propagate to Quality, Cost & Combustion Power</p>
          </div>
        </div>

        {/* Preset Selector */}
        <div className="flex items-center gap-2">
          {[tightToleranceScenario, highSpeedScenario].map((sc) => (
            <button
              key={sc.id}
              onClick={() => setActiveScenario(sc)}
              className={`px-3 py-1.5 rounded transition text-xs font-bold border ${
                activeScenario.id === sc.id
                  ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50'
                  : 'bg-graphite-950 border-graphite-800 text-gray-400 hover:text-white'
              }`}
            >
              {sc.name}
            </button>
          ))}
        </div>
      </div>

      {/* Scenario Tweaker Controls */}
      <div className="bg-graphite-900 border border-graphite-800 rounded p-4 space-y-3">
        <span className="font-bold text-gray-200 block border-b border-graphite-800 pb-2 flex items-center gap-2">
          <Sliders className="w-4 h-4 text-cyan-400" />
          SCENARIO PARAMETER CONTROLS
        </span>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-graphite-950 border border-graphite-800 p-3 rounded space-y-1">
            <div className="flex justify-between items-center">
              <span className="text-gray-400">CYLINDER BORE TOLERANCE (mm):</span>
              <span className="text-cyan-400 font-bold">±{activeScenario.boreToleranceMm} mm</span>
            </div>
            <input
              type="range"
              min={0.005}
              max={0.035}
              step={0.001}
              value={activeScenario.boreToleranceMm}
              onChange={(e) => setActiveScenario({ ...activeScenario, boreToleranceMm: Number(e.target.value) })}
              className="w-full accent-cyan-400 cursor-pointer"
            />
          </div>

          <div className="bg-graphite-950 border border-graphite-800 p-3 rounded space-y-1">
            <div className="flex justify-between items-center">
              <span className="text-gray-400">CYCLE TIME MULTIPLIER:</span>
              <span className="text-amber-400 font-bold">{activeScenario.cycleTimeMultiplier}x</span>
            </div>
            <input
              type="range"
              min={0.7}
              max={1.5}
              step={0.05}
              value={activeScenario.cycleTimeMultiplier}
              onChange={(e) => setActiveScenario({ ...activeScenario, cycleTimeMultiplier: Number(e.target.value) })}
              className="w-full accent-amber-400 cursor-pointer"
            />
          </div>

          <div className="bg-graphite-950 border border-graphite-800 p-3 rounded space-y-1">
            <div className="flex justify-between items-center">
              <span className="text-gray-400">STATION CNC COUNT:</span>
              <span className="text-emerald-400 font-bold">{activeScenario.machineCountCNC} CNCs</span>
            </div>
            <input
              type="range"
              min={2}
              max={8}
              step={1}
              value={activeScenario.machineCountCNC}
              onChange={(e) => setActiveScenario({ ...activeScenario, machineCountCNC: Number(e.target.value) })}
              className="w-full accent-emerald-400 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Side-by-Side Comparative Propagation Impact Table */}
      <div className="bg-graphite-900 border border-graphite-800 rounded p-4 space-y-3">
        <span className="font-bold text-gray-200 block border-b border-graphite-800 pb-2">
          EXACT ENGINEERING CHAIN REACTION IMPACT COMPARISON
        </span>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono-tech">
            <thead>
              <tr className="bg-graphite-950 border-b border-graphite-800 text-gray-400">
                <th className="p-3">KEY IMPACT METRIC</th>
                <th className="p-3 text-gray-300">BASELINE PRODUCTION</th>
                <th className="p-3 text-cyan-400">SCENARIO PROPAGATED</th>
                <th className="p-3">DELTA / IMPACT</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-graphite-800">
              <tr className="hover:bg-graphite-950">
                <td className="p-3 font-bold text-gray-200">Shift Throughput (Units / 8h)</td>
                <td className="p-3 text-gray-300">{baselineResult.throughputUnitsPerShift} Engines</td>
                <td className="p-3 text-cyan-400 font-bold">{activeResult.throughputUnitsPerShift} Engines</td>
                <td className="p-3">
                  <span className={activeResult.throughputUnitsPerShift >= baselineResult.throughputUnitsPerShift ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                    {activeResult.throughputUnitsPerShift - baselineResult.throughputUnitsPerShift > 0 ? '+' : ''}
                    {activeResult.throughputUnitsPerShift - baselineResult.throughputUnitsPerShift} Units
                  </span>
                </td>
              </tr>

              <tr className="hover:bg-graphite-950">
                <td className="p-3 font-bold text-gray-200">Machining Quality Cpk</td>
                <td className="p-3 text-gray-300">{baselineResult.cpkQuality}</td>
                <td className="p-3 text-cyan-400 font-bold">{activeResult.cpkQuality}</td>
                <td className="p-3">
                  <span className={activeResult.cpkQuality >= baselineResult.cpkQuality ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}>
                    {(activeResult.cpkQuality - baselineResult.cpkQuality).toFixed(2)} Cpk
                  </span>
                </td>
              </tr>

              <tr className="hover:bg-graphite-950">
                <td className="p-3 font-bold text-gray-200">Scrap Rate Probability (%)</td>
                <td className="p-3 text-gray-300">{baselineResult.scrapRatePct}%</td>
                <td className="p-3 text-cyan-400 font-bold">{activeResult.scrapRatePct}%</td>
                <td className="p-3">
                  <span className={activeResult.scrapRatePct <= baselineResult.scrapRatePct ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                    {(activeResult.scrapRatePct - baselineResult.scrapRatePct).toFixed(1)}%
                  </span>
                </td>
              </tr>

              <tr className="hover:bg-graphite-950">
                <td className="p-3 font-bold text-gray-200">Total Unit Manufacture Cost ($)</td>
                <td className="p-3 text-gray-300">${baselineResult.unitCost.totalUnitCostUSD}</td>
                <td className="p-3 text-amber-400 font-bold">${activeResult.unitCost.totalUnitCostUSD}</td>
                <td className="p-3">
                  <span className={activeResult.unitCost.totalUnitCostUSD <= baselineResult.unitCost.totalUnitCostUSD ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                    {activeResult.unitCost.totalUnitCostUSD - baselineResult.unitCost.totalUnitCostUSD > 0 ? '+' : ''}
                    ${(activeResult.unitCost.totalUnitCostUSD - baselineResult.unitCost.totalUnitCostUSD).toFixed(2)}
                  </span>
                </td>
              </tr>

              <tr className="hover:bg-graphite-950">
                <td className="p-3 font-bold text-gray-200">Piston Skirt Clearance Variance</td>
                <td className="p-3 text-gray-300">{baselineResult.pistonRingClearanceMicrons} µm</td>
                <td className="p-3 text-cyan-400 font-bold">{activeResult.pistonRingClearanceMicrons} µm</td>
                <td className="p-3 text-gray-400">
                  {(activeResult.pistonRingClearanceMicrons - baselineResult.pistonRingClearanceMicrons).toFixed(1)} µm
                </td>
              </tr>

              <tr className="hover:bg-graphite-950">
                <td className="p-3 font-bold text-gray-200">Engine Peak Power Output (kW)</td>
                <td className="p-3 text-gray-300">{baselineResult.peakEnginePowerKw} kW</td>
                <td className="p-3 text-rose-400 font-bold">{activeResult.peakEnginePowerKw} kW</td>
                <td className="p-3">
                  <span className={activeResult.peakEnginePowerKw >= baselineResult.peakEnginePowerKw ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                    {activeResult.peakEnginePowerKw - baselineResult.peakEnginePowerKw > 0 ? '+' : ''}
                    {(activeResult.peakEnginePowerKw - baselineResult.peakEnginePowerKw).toFixed(1)} kW
                  </span>
                </td>
              </tr>

              <tr className="hover:bg-graphite-950">
                <td className="p-3 font-bold text-gray-200">Fuel BSFC Efficiency (g/kWh)</td>
                <td className="p-3 text-gray-300">{baselineResult.bsfcGKh} g/kWh</td>
                <td className="p-3 text-amber-400 font-bold">{activeResult.bsfcGKh} g/kWh</td>
                <td className="p-3">
                  <span className={activeResult.bsfcGKh <= baselineResult.bsfcGKh ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                    {(activeResult.bsfcGKh - baselineResult.bsfcGKh).toFixed(1)} g/kWh
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
