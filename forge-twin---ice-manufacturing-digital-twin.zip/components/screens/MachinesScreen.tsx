'use client';

import React, { useState } from 'react';
import { MachineAsset } from '@/types/factory';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { Server, Activity, Wrench, ShieldAlert, Zap, Clock, ChevronRight } from 'lucide-react';

interface MachinesScreenProps {
  machines: MachineAsset[];
}

export default function MachinesScreen({ machines }: MachinesScreenProps) {
  const [selectedMachine, setSelectedMachine] = useState<MachineAsset>(machines[0]);

  // Synthetic vibration FFT spectrum
  const fftData = [
    { freqHz: 10, amplitudeG: 0.02 },
    { freqHz: 50, amplitudeG: 0.15 },
    { freqHz: 100, amplitudeG: 0.08 },
    { freqHz: 150, amplitudeG: 0.85 }, // 3x Harmonics peak
    { freqHz: 200, amplitudeG: 0.12 },
    { freqHz: 300, amplitudeG: 0.35 },
    { freqHz: 500, amplitudeG: 0.05 },
  ];

  return (
    <div className="p-4 space-y-4 overflow-y-auto h-[calc(100vh-50px)] bg-graphite-950 font-mono-tech text-xs">
      {/* Top Banner */}
      <div className="bg-graphite-900 border border-graphite-800 p-3 rounded flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 rounded">
            <Server className="w-5 h-5" />
          </div>
          <div>
            <span className="font-bold text-gray-100 text-sm">CNC & ROBOTIC MACHINE TELEMETRY STUDIO</span>
            <p className="text-gray-400 text-[11px]">Real-time Vibration FFT, Tool Wear & Predictive RUL Health Engine</p>
          </div>
        </div>
      </div>

      {/* Main Grid: Machine Selector (Left) & Telemetry Deep Dive (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Machine Assets List */}
        <div className="lg:col-span-4 bg-graphite-900 border border-graphite-800 rounded p-3 space-y-2">
          <span className="font-bold text-gray-200 block border-b border-graphite-800 pb-1.5">
            PLANT ASSETS ({machines.length})
          </span>

          <div className="space-y-2 max-h-[560px] overflow-y-auto pr-1">
            {machines.map((m) => {
              const isSelected = selectedMachine.id === m.id;
              return (
                <button
                  key={m.id}
                  onClick={() => setSelectedMachine(m)}
                  className={`w-full text-left p-2.5 rounded border transition flex flex-col justify-between ${
                    isSelected
                      ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 font-bold shadow-md'
                      : m.status === 'WARNING'
                      ? 'bg-amber-500/10 border-amber-500/40 text-amber-200'
                      : 'bg-graphite-950 border-graphite-800 text-gray-300 hover:bg-graphite-800'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div
                        className={`w-2.5 h-2.5 rounded-full ${
                          m.status === 'RUNNING' ? 'bg-emerald-400' : m.status === 'WARNING' ? 'bg-amber-400 animate-pulse' : 'bg-rose-500'
                        }`}
                      />
                      <span className="font-bold text-gray-100">{m.id}</span>
                    </div>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-graphite-800 text-cyan-400">
                      OEE {m.oeePct}%
                    </span>
                  </div>

                  <div className="text-[11px] text-gray-300 font-medium mt-1 truncate">{m.name}</div>

                  <div className="flex justify-between items-center text-[10px] text-gray-400 mt-2 pt-1 border-t border-graphite-800">
                    <span>Tool Wear: <strong className={m.toolWearPct > 75 ? 'text-amber-400' : 'text-gray-200'}>{m.toolWearPct}%</strong></span>
                    <span>RUL: <strong className="text-cyan-400">{m.remainingUsefulLifeHours}h</strong></span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Machine Telemetry Workspace */}
        {selectedMachine && (
          <div className="lg:col-span-8 bg-graphite-900 border border-graphite-800 rounded p-4 space-y-4">
            <div className="flex items-center justify-between border-b border-graphite-800 pb-2">
              <div>
                <span className="text-[10px] text-cyan-400 font-bold">{selectedMachine.manufacturer} ({selectedMachine.model})</span>
                <h2 className="text-base font-bold text-gray-100">{selectedMachine.id} — {selectedMachine.name}</h2>
              </div>
              <span className={`px-2.5 py-1 rounded text-xs font-bold border ${
                selectedMachine.status === 'RUNNING' ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300' : 'bg-amber-500/20 border-amber-500 text-amber-300'
              }`}>
                {selectedMachine.status}
              </span>
            </div>

            {/* Live Sensor Metrics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-graphite-950 border border-graphite-800 p-2.5 rounded">
                <span className="text-gray-500 text-[10px] block">SPINDLE SPEED</span>
                <span className="text-cyan-400 text-base font-bold">{selectedMachine.spindleSpeedRpm} RPM</span>
              </div>
              <div className="bg-graphite-950 border border-graphite-800 p-2.5 rounded">
                <span className="text-gray-500 text-[10px] block">STATION CYCLE TIME</span>
                <span className="text-gray-200 text-base font-bold">{selectedMachine.cycleTimeSec}s</span>
              </div>
              <div className="bg-graphite-950 border border-graphite-800 p-2.5 rounded">
                <span className="text-gray-500 text-[10px] block">OPERATING TEMP</span>
                <span className="text-amber-400 text-base font-bold">{selectedMachine.temperatureC}°C</span>
              </div>
              <div className="bg-graphite-950 border border-graphite-800 p-2.5 rounded">
                <span className="text-gray-500 text-[10px] block">TOOL WEAR</span>
                <span className={selectedMachine.toolWearPct > 75 ? 'text-amber-400 text-base font-bold' : 'text-emerald-400 text-base font-bold'}>
                  {selectedMachine.toolWearPct}%
                </span>
              </div>
            </div>

            {/* Vibration FFT Harmonic Spectrum Graph */}
            <div className="bg-graphite-950 border border-graphite-800 rounded p-3 space-y-2">
              <div className="flex items-center justify-between border-b border-graphite-800 pb-1.5">
                <span className="font-bold text-gray-200 flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5 text-cyan-400" />
                  ACCELEROMETER VIBRATION FFT FREQUENCY SPECTRUM (3-AXIS)
                </span>
                <span className="text-[10px] text-amber-400">Peak @ 150 Hz (Spindle Bearing Unbalance)</span>
              </div>

              <div className="h-[200px] w-full pt-1">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={fftData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e232b" />
                    <XAxis dataKey="freqHz" stroke="#718096" tick={{ fontSize: 10 }} unit=" Hz" />
                    <YAxis stroke="#718096" tick={{ fontSize: 10 }} unit=" g" />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0e1116', borderColor: '#2d3748', fontSize: '11px', fontFamily: 'monospace' }}
                    />
                    <Line type="monotone" dataKey="amplitudeG" stroke="#fbbf24" strokeWidth={2} dot={{ r: 4, fill: '#fbbf24' }} name="Vibration Amplitude (g)" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Predictive Maintenance & Actionable Maintenance Recommendation */}
            <div className="bg-graphite-950 border border-graphite-800 p-3.5 rounded space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-amber-400 flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4" />
                  TRANSPARENT PREDICTIVE HEALTH DIAGNOSIS
                </span>
                <span className="text-cyan-400 font-bold text-xs">RUL: {selectedMachine.remainingUsefulLifeHours} Hours</span>
              </div>

              <p className="text-gray-300 text-xs leading-relaxed">
                {selectedMachine.healthDiagnosis}
              </p>

              <div className="pt-2 flex items-center justify-between border-t border-graphite-800">
                <span className="text-gray-400 text-[10px]">RECOMMENDED WORK ORDER:</span>
                <button className="px-3 py-1 bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/50 text-amber-300 rounded font-bold text-xs transition">
                  Trigger Maintenance Work Order
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
