'use client';

import React, { useState } from 'react';
import { EngineConfig } from '@/types/engine';
import { SimulationOperatingState } from '@/types/physics';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { LineChart as ChartIcon, Sliders, Cpu, Activity } from 'lucide-react';

interface PerformanceScreenProps {
  engineConfig: EngineConfig;
  onUpdateEngineConfig: (cfg: EngineConfig) => void;
  simState: SimulationOperatingState;
}

export default function PerformanceScreen({ engineConfig, onUpdateEngineConfig, simState }: PerformanceScreenProps) {
  // Parametric geometry tuning
  const handleBoreChange = (newBore: number) => {
    onUpdateEngineConfig({
      ...engineConfig,
      boreMm: newBore,
      displacementL: Math.round(((Math.PI * Math.pow(newBore / 20, 2) * (engineConfig.strokeMm / 10) * engineConfig.cylinderCount) / 1000) * 10) / 10,
    });
  };

  const handleStrokeChange = (newStroke: number) => {
    onUpdateEngineConfig({
      ...engineConfig,
      strokeMm: newStroke,
      displacementL: Math.round(((Math.PI * Math.pow(engineConfig.boreMm / 20, 2) * (newStroke / 10) * engineConfig.cylinderCount) / 1000) * 10) / 10,
    });
  };

  const handleCompressionChange = (newCR: number) => {
    onUpdateEngineConfig({
      ...engineConfig,
      compressionRatio: newCR,
    });
  };

  // Performance map points
  const mapPoints = [
    { rpm: 1000, torque: 180, power: 18.8, bsfc: 280 },
    { rpm: 2000, torque: 240, power: 50.2, bsfc: 245 },
    { rpm: 3000, torque: 270, power: 84.8, bsfc: 232 },
    { rpm: 4000, torque: 280, power: 117.2, bsfc: 228 },
    { rpm: 5000, torque: 275, power: 143.9, bsfc: 238 },
    { rpm: 6000, torque: 255, power: 160.2, bsfc: 252 },
    { rpm: 7000, torque: 220, power: 161.2, bsfc: 275 },
  ];

  return (
    <div className="p-4 space-y-4 overflow-y-auto h-[calc(100vh-50px)] bg-graphite-950 font-mono-tech text-xs">
      <div className="bg-graphite-900 border border-graphite-800 p-3 rounded flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 rounded">
            <ChartIcon className="w-5 h-5" />
          </div>
          <div>
            <span className="font-bold text-gray-100 text-sm">PARAMETRIC ENGINE PERFORMANCE MAPS</span>
            <p className="text-gray-400 text-[11px]">Real-time Geometry & Thermodynamic Optimization Studio</p>
          </div>
        </div>
      </div>

      {/* Geometry Sliders */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-graphite-900 border border-graphite-800 p-4 rounded">
        <div className="space-y-1 bg-graphite-950 border border-graphite-800 p-3 rounded">
          <div className="flex justify-between items-center">
            <span className="text-gray-400">CYLINDER BORE (mm):</span>
            <span className="text-cyan-400 font-bold">{engineConfig.boreMm} mm</span>
          </div>
          <input
            type="range"
            min={75}
            max={98}
            step={0.5}
            value={engineConfig.boreMm}
            onChange={(e) => handleBoreChange(Number(e.target.value))}
            className="w-full accent-cyan-400 cursor-pointer"
          />
        </div>

        <div className="space-y-1 bg-graphite-950 border border-graphite-800 p-3 rounded">
          <div className="flex justify-between items-center">
            <span className="text-gray-400">PISTON STROKE (mm):</span>
            <span className="text-amber-400 font-bold">{engineConfig.strokeMm} mm</span>
          </div>
          <input
            type="range"
            min={75}
            max={102}
            step={0.5}
            value={engineConfig.strokeMm}
            onChange={(e) => handleStrokeChange(Number(e.target.value))}
            className="w-full accent-amber-400 cursor-pointer"
          />
        </div>

        <div className="space-y-1 bg-graphite-950 border border-graphite-800 p-3 rounded">
          <div className="flex justify-between items-center">
            <span className="text-gray-400">COMPRESSION RATIO:</span>
            <span className="text-emerald-400 font-bold">{engineConfig.compressionRatio}:1</span>
          </div>
          <input
            type="range"
            min={8.0}
            max={14.0}
            step={0.1}
            value={engineConfig.compressionRatio}
            onChange={(e) => handleCompressionChange(Number(e.target.value))}
            className="w-full accent-emerald-400 cursor-pointer"
          />
        </div>
      </div>

      {/* Performance Map Chart */}
      <div className="bg-graphite-900 border border-graphite-800 rounded p-4 space-y-3">
        <span className="font-bold text-gray-200 block border-b border-graphite-800 pb-2">
          FULL ENGINE MAP: TORQUE & BSFC OVER RPM
        </span>

        <div className="h-[340px] w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={mapPoints}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e232b" />
              <XAxis dataKey="rpm" stroke="#718096" tick={{ fontSize: 10 }} unit=" RPM" />
              <YAxis stroke="#718096" tick={{ fontSize: 10 }} />
              <Tooltip contentStyle={{ backgroundColor: '#0e1116', borderColor: '#2d3748', fontSize: '11px', fontFamily: 'monospace' }} />
              <Line type="monotone" dataKey="torque" stroke="#38bdf8" strokeWidth={2.5} name="Torque (Nm)" />
              <Line type="monotone" dataKey="power" stroke="#f87171" strokeWidth={2.5} name="Power (kW)" />
              <Line type="monotone" dataKey="bsfc" stroke="#fbbf24" strokeWidth={1.5} name="BSFC (g/kWh)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
