'use client';

import React, { useState } from 'react';
import { getEngineGenealogy } from '@/lib/simulation/digitalThreadRepository';
import { Network, Search, Cpu, CheckCircle2, AlertTriangle, ArrowDown, ChevronRight, Layers, FileSpreadsheet } from 'lucide-react';

export default function DigitalThreadScreen() {
  const [searchSerial, setSearchSerial] = useState('ICE-V8-2026-0001842');
  const genealogy = getEngineGenealogy(searchSerial);
  const [selectedNodeId, setSelectedNodeId] = useState<string>(genealogy.nodes[0].id);

  const selectedNode = genealogy.nodes.find((n) => n.id === selectedNodeId) || genealogy.nodes[0];

  return (
    <div className="p-4 space-y-4 overflow-y-auto h-[calc(100vh-50px)] bg-graphite-950 font-mono-tech text-xs">
      {/* Top Banner & Search Input */}
      <div className="bg-graphite-900 border border-graphite-800 p-3 rounded flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 rounded">
            <Network className="w-5 h-5" />
          </div>
          <div>
            <span className="font-bold text-gray-100 text-sm">DIGITAL THREAD & SERIAL GENEALOGY EXPLORER</span>
            <p className="text-gray-400 text-[11px]">Traceability from Ingot Melt Heat Batch to End-of-Line Dyno Certification</p>
          </div>
        </div>

        {/* Search Bar */}
        <div className="flex items-center gap-2 bg-graphite-950 border border-graphite-700 px-3 py-1.5 rounded w-full sm:w-80">
          <Search className="w-4 h-4 text-cyan-400" />
          <input
            type="text"
            value={searchSerial}
            onChange={(e) => setSearchSerial(e.target.value)}
            placeholder="Search Serial (e.g. ICE-V8-2026-0001842)..."
            className="bg-transparent text-gray-100 focus:outline-none w-full font-mono-tech text-xs"
          />
        </div>
      </div>

      {/* Main Grid: Genealogy Tree Nodes (Left) & Selected Node Details (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Serialized Digital Thread Graph Hierarchy */}
        <div className="lg:col-span-8 bg-graphite-900 border border-graphite-800 rounded p-4 space-y-4">
          <div className="flex items-center justify-between border-b border-graphite-800 pb-2">
            <div>
              <span className="text-[10px] text-cyan-400 font-bold">SERIAL NUMBER: {genealogy.engineSerial}</span>
              <h2 className="text-sm font-bold text-gray-100">{genealogy.configurationName}</h2>
            </div>
            <span className="text-[10px] text-emerald-400 font-bold px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30">
              BUILD DATE: {genealogy.buildDate}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {genealogy.nodes.map((node) => {
              const isSelected = selectedNodeId === node.id;
              return (
                <button
                  key={node.id}
                  onClick={() => setSelectedNodeId(node.id)}
                  className={`p-3 rounded text-left transition border flex flex-col justify-between h-32 ${
                    isSelected
                      ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 font-bold shadow-md'
                      : node.status === 'Warning'
                      ? 'bg-amber-500/10 border-amber-500/40 text-amber-200 hover:bg-amber-500/20'
                      : 'bg-graphite-950 border-graphite-800 text-gray-300 hover:bg-graphite-800'
                  }`}
                >
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="px-1.5 py-0.5 rounded bg-graphite-800 text-cyan-400 font-bold">
                      {node.type}
                    </span>
                    <span className={node.status === 'Passed' || node.status === 'Completed' ? 'text-emerald-400' : 'text-amber-400'}>
                      {node.status}
                    </span>
                  </div>

                  <div>
                    <div className="font-bold text-gray-100 text-[11px] truncate mt-1">{node.name}</div>
                    <div className="text-[10px] text-gray-500 truncate">{node.serialNumber}</div>
                  </div>

                  <div className="text-[10px] text-gray-500 border-t border-graphite-800 pt-1">
                    {node.timestamp}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Node Detailed Metadata Inspector */}
        {selectedNode && (
          <div className="lg:col-span-4 bg-graphite-900 border border-graphite-800 rounded p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-graphite-800 pb-2">
              <div>
                <span className="text-[10px] text-cyan-400 font-bold">{selectedNode.type} NODE</span>
                <h3 className="font-bold text-gray-100 text-sm">{selectedNode.name}</h3>
              </div>
              <span className="text-[10px] text-emerald-400 font-bold px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30">
                {selectedNode.status}
              </span>
            </div>

            <div className="bg-graphite-950 border border-graphite-800 p-3 rounded space-y-2 text-[11px]">
              <div className="flex justify-between">
                <span className="text-gray-400">SERIAL / BATCH ID:</span>
                <span className="text-cyan-400 font-bold">{selectedNode.serialNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">TIMESTAMP:</span>
                <span className="text-gray-200">{selectedNode.timestamp}</span>
              </div>
            </div>

            {/* Key-Value Attributes List */}
            <div className="bg-graphite-950 border border-graphite-800 p-3 rounded space-y-2">
              <span className="font-bold text-gray-300 text-[11px] block border-b border-graphite-800 pb-1">
                TRACEABILITY METADATA
              </span>

              <div className="space-y-1.5 text-[11px]">
                {Object.entries(selectedNode.details).map(([key, val]) => (
                  <div key={key} className="flex justify-between items-center text-gray-300">
                    <span className="text-gray-400 text-[10px]">{key}:</span>
                    <span className="font-bold text-gray-100">{String(val)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
