'use client';

import React from 'react';
import { DollarSign, PieChart, BarChart as BarIcon, ArrowDownRight, Layers } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function CostScreen() {
  const costBreakdown = [
    { category: 'Raw Materials (Aluminum / Steel)', costUSD: 380.0 },
    { category: 'CNC Machining Operations', costUSD: 285.0 },
    { category: 'Direct Labor & Assembly', costUSD: 165.0 },
    { category: 'Energy & Electrical Utility', costUSD: 42.0 },
    { category: 'Cutting Tool Wear & Insert Replacements', costUSD: 38.0 },
    { category: 'Quality Inspection & CMM Audits', costUSD: 28.0 },
    { category: 'Plant Overhead & Facility Amortization', costUSD: 180.0 },
    { category: 'Scrap & Rework Losses', costUSD: 14.5 },
  ];

  const totalCost = costBreakdown.reduce((acc, c) => acc + c.costUSD, 0);

  return (
    <div className="p-4 space-y-4 overflow-y-auto h-[calc(100vh-50px)] bg-graphite-950 font-mono-tech text-xs">
      <div className="bg-graphite-900 border border-graphite-800 p-3 rounded flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-amber-500/10 border border-amber-500/30 text-amber-400 rounded">
            <DollarSign className="w-5 h-5" />
          </div>
          <div>
            <span className="font-bold text-gray-100 text-sm">MANUFACTURING COST ENGINE & WATERFALL DIGITAL TWIN</span>
            <p className="text-gray-400 text-[11px]">Granular Unit Cost Driver Breakdown per Engine Assembly</p>
          </div>
        </div>

        <div className="bg-graphite-950 border border-graphite-800 px-4 py-2 rounded text-right">
          <span className="text-gray-400 text-[10px] block">TOTAL ENGINE MANUFACTURE COST</span>
          <span className="text-amber-400 font-bold text-base">${totalCost.toFixed(2)} USD</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Waterfall Table */}
        <div className="lg:col-span-6 bg-graphite-900 border border-graphite-800 rounded p-4 space-y-3">
          <span className="font-bold text-gray-200 block border-b border-graphite-800 pb-2">
            UNIT COST WATERFALL ALLOCATION
          </span>

          <div className="space-y-2">
            {costBreakdown.map((item, idx) => (
              <div key={idx} className="bg-graphite-950 border border-graphite-800 p-2.5 rounded flex items-center justify-between">
                <span className="text-gray-300 font-medium">{item.category}</span>
                <span className="text-amber-400 font-bold">${item.costUSD.toFixed(2)}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Cost Bar Chart */}
        <div className="lg:col-span-6 bg-graphite-900 border border-graphite-800 rounded p-4 space-y-3">
          <span className="font-bold text-gray-200 block border-b border-graphite-800 pb-2">
            COST DRIVER COMPARISON ($)
          </span>

          <div className="h-[320px] w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={costBreakdown} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#1e232b" />
                <XAxis type="number" stroke="#718096" tick={{ fontSize: 10 }} unit=" $" />
                <YAxis dataKey="category" type="category" width={180} stroke="#718096" tick={{ fontSize: 9 }} />
                <Tooltip contentStyle={{ backgroundColor: '#0e1116', borderColor: '#2d3748', fontSize: '11px', fontFamily: 'monospace' }} />
                <Bar dataKey="costUSD" fill="#fbbf24" name="Cost ($)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
