'use client';

import React, { useState } from 'react';
import { EngineConfig } from '@/types/engine';
import { SimulationOperatingState } from '@/types/physics';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { Gauge, Activity, CheckCircle2, Flame, ShieldAlert, Award } from 'lucide-react';

interface TestCellScreenProps {
  engineConfig: EngineConfig;
  simState: SimulationOperatingState;
  rpm: number;
  onChangeRpm: (rpm: number) => void;
}

export default function TestCellScreen({
  engineConfig,
  simState,
  rpm,
  onChangeRpm,
}: TestCellScreenProps) {
  const [dynoMode, setDynoMode] = useState<'IDLE' | 'POWER_SWEEP' | 'HOT_MAP'>('POWER_SWEEP');

  // Synthetic Dyno Sweep Curve Data
  const dynoSweepData = [
    { rpm: 1500, torqueNm: 220, powerKw: 34.5, bsfcGKh: 265 },
    { rpm: 2500, torqueNm: 265, powerKw: 69.3, bsfcGKh: 242 },
    { rpm: 3500, torqueNm: 278, powerKw: 101.8, bsfcGKh: 232 },
    { rpm: 4200, torqueNm: 280, powerKw: 123.1, bsfcGKh: 228 }, // Peak Torque
    { rpm: 5000, torqueNm: 272, powerKw: 142.4, bsfcGKh: 235 },
    { rpm: 6000, torqueNm: 255, powerKw: 160.2, bsfcGKh: 248 },
    { rpm: 6500, torqueNm: 240, powerKw: 163.3, bsfcGKh: 260 }, // Peak Power
  ];

  return (
    <div className="p-4 space-y-4 overflow-y-auto h-[calc(100vh-50px)] bg-graphite-950 font-mono-tech text-xs">
      {/* Top Banner */}
      <div className="bg-graphite-900 border border-graphite-800 p-3 rounded flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-rose-500/10 border border-rose-500/30 text-rose-400 rounded">
            <Gauge className="w-5 h-5" />
          </div>
          <div>
            <span className="font-bold text-gray-100 text-sm">AVL 400kW DYNAMOMETER TEST CELL #01</span>
            <p className="text-gray-400 text-[11px]">End-of-Line Hot Testing, Power/Torque Calibration & Acceptance Certificate</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded font-bold text-xs flex items-center gap-1">
            <Award className="w-3.5 h-3.5" /> CERTIFICATE #AVL-9941 READY
          </span>
        </div>
      </div>

      {/* Dyno Live Telemetry Gauges Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
        <div className="bg-graphite-900 border border-graphite-800 p-3 rounded text-center">
          <span className="text-gray-500 text-[10px] block">ENGINE SPEED</span>
          <span className="text-cyan-400 text-xl font-bold">{rpm} RPM</span>
        </div>
        <div className="bg-graphite-900 border border-graphite-800 p-3 rounded text-center">
          <span className="text-gray-500 text-[10px] block">DYNO BRAKE TORQUE</span>
          <span className="text-emerald-400 text-xl font-bold">{simState.torqueNm} Nm</span>
        </div>
        <div className="bg-graphite-900 border border-graphite-800 p-3 rounded text-center">
          <span className="text-gray-500 text-[10px] block">BRAKE POWER</span>
          <span className="text-rose-400 text-xl font-bold">{simState.powerKw} kW</span>
        </div>
        <div className="bg-graphite-900 border border-graphite-800 p-3 rounded text-center">
          <span className="text-gray-500 text-[10px] block">OIL PRESSURE</span>
          <span className="text-gray-200 text-xl font-bold">4.2 bar</span>
        </div>
        <div className="bg-graphite-900 border border-graphite-800 p-3 rounded text-center">
          <span className="text-gray-500 text-[10px] block">BLOWBY LEAKAGE</span>
          <span className="text-emerald-400 text-xl font-bold">8.2 L/min</span>
        </div>
        <div className="bg-graphite-900 border border-graphite-800 p-3 rounded text-center">
          <span className="text-gray-500 text-[10px] block">EXHAUST TEMP</span>
          <span className="text-rose-400 text-xl font-bold">{simState.exhaustTempC} °C</span>
        </div>
      </div>

      {/* Dyno Power & Torque Sweep Graph */}
      <div className="bg-graphite-900 border border-graphite-800 rounded p-4 space-y-3">
        <div className="flex items-center justify-between border-b border-graphite-800 pb-2">
          <span className="font-bold text-gray-200 flex items-center gap-2">
            <Activity className="w-4 h-4 text-cyan-400" />
            FULL-THROTTLE POWER & TORQUE DYNAMOMETER SWEEP CURVE
          </span>
          <span className="text-[10px] text-gray-400">1,500 - 6,500 RPM WOT Sweep</span>
        </div>

        <div className="h-[340px] w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={dynoSweepData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e232b" />
              <XAxis dataKey="rpm" stroke="#718096" tick={{ fontSize: 10 }} unit=" RPM" />
              <YAxis stroke="#718096" tick={{ fontSize: 10 }} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0e1116', borderColor: '#2d3748', fontSize: '11px', fontFamily: 'monospace' }}
              />
              <Line type="monotone" dataKey="torqueNm" stroke="#34d399" strokeWidth={2.5} dot={{ r: 4, fill: '#34d399' }} name="Torque (Nm)" />
              <Line type="monotone" dataKey="powerKw" stroke="#f87171" strokeWidth={2.5} dot={{ r: 4, fill: '#f87171' }} name="Power (kW)" />
              <Line type="monotone" dataKey="bsfcGKh" stroke="#fbbf24" strokeWidth={1.5} dot={false} name="BSFC (g/kWh)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
