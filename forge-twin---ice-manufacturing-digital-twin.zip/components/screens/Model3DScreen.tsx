'use client';

import React, { useState } from 'react';
import { EngineConfig, EngineComponentMeta } from '@/types/engine';
import { DEFAULT_COMPONENTS_META } from '@/lib/simulation/defaults';
import EngineViewer3D, { DisplayMode } from '../3d/EngineViewer3D';
import { Box, Layers, Flame, ShieldAlert, Wrench, Eye, RotateCcw, Info, CheckCircle2 } from 'lucide-react';

interface Model3DScreenProps {
  engineConfig: EngineConfig;
  rpm: number;
  selectedComponent: EngineComponentMeta | null;
  onSelectComponent: (comp: EngineComponentMeta | null) => void;
}

export default function Model3DScreen({
  engineConfig,
  rpm,
  selectedComponent,
  onSelectComponent,
}: Model3DScreenProps) {
  const [displayMode, setDisplayMode] = useState<DisplayMode>('CAD');
  const [explodedFactor, setExplodedFactor] = useState(0.0);
  const [sectionCut, setSectionCut] = useState(false);

  const activeComp = selectedComponent || DEFAULT_COMPONENTS_META[0];

  return (
    <div className="p-4 space-y-4 overflow-y-auto h-[calc(100vh-50px)] bg-graphite-950 font-mono-tech text-xs">
      {/* Top Controls Toolbar */}
      <div className="bg-graphite-900 border border-graphite-800 p-3 rounded flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Box className="w-4 h-4 text-cyan-400" />
          <span className="font-bold text-gray-200">3D CAD / FEA ENGINEERING VISUALIZER</span>
        </div>

        {/* Display Mode Selection */}
        <div className="flex items-center gap-1.5 bg-graphite-950 border border-graphite-800 p-1 rounded">
          <button
            onClick={() => setDisplayMode('CAD')}
            className={`px-2.5 py-1 rounded transition text-xs flex items-center gap-1 ${
              displayMode === 'CAD' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold' : 'text-gray-400 hover:text-white'
            }`}
          >
            <Box className="w-3.5 h-3.5" /> Solid CAD
          </button>
          <button
            onClick={() => setDisplayMode('HEATMAP')}
            className={`px-2.5 py-1 rounded transition text-xs flex items-center gap-1 ${
              displayMode === 'HEATMAP' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold' : 'text-gray-400 hover:text-white'
            }`}
          >
            <Flame className="w-3.5 h-3.5" /> Thermal Map
          </button>
          <button
            onClick={() => setDisplayMode('STRESS')}
            className={`px-2.5 py-1 rounded transition text-xs flex items-center gap-1 ${
              displayMode === 'STRESS' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 font-bold' : 'text-gray-400 hover:text-white'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" /> FEA Stress
          </button>
          <button
            onClick={() => setDisplayMode('MFG_STAGE')}
            className={`px-2.5 py-1 rounded transition text-xs flex items-center gap-1 ${
              displayMode === 'MFG_STAGE' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold' : 'text-gray-400 hover:text-white'
            }`}
          >
            <Wrench className="w-3.5 h-3.5" /> Wireframe
          </button>
        </div>

        {/* Exploded View Slider */}
        <div className="flex items-center gap-2 bg-graphite-950 border border-graphite-800 p-1.5 rounded">
          <span className="text-gray-400 text-[10px]">EXPLODED VIEW:</span>
          <input
            type="range"
            min={0}
            max={1}
            step={0.05}
            value={explodedFactor}
            onChange={(e) => setExplodedFactor(Number(e.target.value))}
            className="w-28 accent-cyan-400 cursor-pointer"
          />
          <span className="text-cyan-400 font-bold w-10">{Math.round(explodedFactor * 100)}%</span>
        </div>

        {/* Section Cut Toggle */}
        <button
          onClick={() => setSectionCut(!sectionCut)}
          className={`px-3 py-1 rounded border transition font-bold flex items-center gap-1 ${
            sectionCut ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50' : 'bg-graphite-950 border-graphite-700 text-gray-400 hover:text-white'
          }`}
        >
          <Eye className="w-3.5 h-3.5" /> Section Cut / X-Ray
        </button>
      </div>

      {/* Main 3D Canvas Viewport (Left) & BOM Component Metadata Inspector (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 h-[620px]">
        <div className="lg:col-span-8 bg-graphite-900 border border-graphite-800 rounded p-2 h-full">
          <EngineViewer3D
            config={engineConfig}
            rpm={rpm}
            isSimulating={true}
            selectedComponentId={activeComp.id}
            onSelectComponent={onSelectComponent}
            displayMode={displayMode}
            explodedFactor={explodedFactor}
            sectionCut={sectionCut}
          />
        </div>

        {/* Component Selector & Detailed Inspection Panel */}
        <div className="lg:col-span-4 bg-graphite-900 border border-graphite-800 rounded p-4 flex flex-col justify-between h-full space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-graphite-800 pb-2">
              <span className="font-bold text-gray-200 flex items-center gap-1.5">
                <Info className="w-4 h-4 text-cyan-400" />
                COMPONENT BOM INSPECTOR
              </span>
              <span className="text-[10px] text-emerald-400 font-bold">DIGITAL THREAD LINKED</span>
            </div>

            {/* List of Major Components to Pick */}
            <div className="space-y-1 max-h-40 overflow-y-auto pr-1">
              {DEFAULT_COMPONENTS_META.map((comp) => (
                <button
                  key={comp.id}
                  onClick={() => onSelectComponent(comp)}
                  className={`w-full text-left p-2 rounded transition flex items-center justify-between border ${
                    activeComp.id === comp.id
                      ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-300 font-bold'
                      : 'bg-graphite-950 border-graphite-800 text-gray-400 hover:text-white'
                  }`}
                >
                  <div className="truncate">
                    <div className="text-gray-200 font-semibold">{comp.name}</div>
                    <div className="text-[10px] text-gray-500">{comp.partNumber}</div>
                  </div>
                  <span className="text-[10px] text-cyan-400 font-mono-tech">{comp.massKg} kg</span>
                </button>
              ))}
            </div>

            {/* Active Component Specification Details */}
            {activeComp && (
              <div className="bg-graphite-950 border border-graphite-800 p-3 rounded space-y-2.5">
                <div className="flex items-center justify-between pb-1.5 border-b border-graphite-800">
                  <span className="font-bold text-cyan-400 text-xs">{activeComp.name}</span>
                  <span className="px-1.5 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px]">
                    {activeComp.simulatedCondition}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px] text-gray-300">
                  <div>
                    <span className="text-gray-500 text-[10px] block">PART NUMBER</span>
                    <span className="font-bold">{activeComp.partNumber}</span>
                  </div>
                  <div>
                    <span className="text-gray-500 text-[10px] block">REVISION</span>
                    <span className="font-bold">{activeComp.revision}</span>
                  </div>
                  <div>
                    <span className="text-gray-500 text-[10px] block">MATERIAL</span>
                    <span className="text-gray-200">{activeComp.material.name}</span>
                  </div>
                  <div>
                    <span className="text-gray-500 text-[10px] block">SUPPLIER</span>
                    <span className="text-gray-200">{activeComp.supplier}</span>
                  </div>
                  <div>
                    <span className="text-gray-500 text-[10px] block">MASS / UNIT COST</span>
                    <span className="text-amber-400 font-bold">{activeComp.massKg} kg / ${activeComp.unitCostUSD}</span>
                  </div>
                  <div>
                    <span className="text-gray-500 text-[10px] block">PRIMARY MFG PROCESS</span>
                    <span className="text-gray-300 text-[10px]">{activeComp.primaryMachiningProcess}</span>
                  </div>
                  <div>
                    <span className="text-gray-500 text-[10px] block">TOLERANCE CLASS</span>
                    <span className="text-emerald-400">{activeComp.nominalDimensionMm}mm {activeComp.toleranceClass}</span>
                  </div>
                  <div>
                    <span className="text-gray-500 text-[10px] block">QUALITY CPK</span>
                    <span className="text-emerald-400 font-bold">{activeComp.qualityCpk}</span>
                  </div>
                  <div>
                    <span className="text-gray-500 text-[10px] block">OPERATING TEMP</span>
                    <span className="text-amber-400 font-bold">{activeComp.operatingTempC} °C</span>
                  </div>
                  <div>
                    <span className="text-gray-500 text-[10px] block">PREDICTED LIFE</span>
                    <span className="text-gray-200">{activeComp.predictedLifeHours} Hours</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
