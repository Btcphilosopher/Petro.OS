'use client';

import React, { useState } from 'react';
import { generateSPCHistory, calculateToleranceStackup } from '@/lib/simulation/spcQualityEngine';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  ReferenceLine,
} from 'recharts';
import { ShieldCheck, AlertTriangle, Activity, Sliders, CheckCircle2, FileSpreadsheet } from 'lucide-react';

export default function QualityScreen() {
  const [featureName, setFeatureName] = useState<'bore' | 'journal' | 'ring_gap'>('bore');
  const [simulateDrift, setSimulateDrift] = useState(true);

  // Dynamic SPC Data
  const targetNominal = featureName === 'bore' ? 86.000 : featureName === 'journal' ? 58.000 : 0.280;
  const tolerance = featureName === 'bore' ? 0.015 : featureName === 'journal' ? 0.008 : 0.050;
  const driftAmount = simulateDrift ? (featureName === 'bore' ? 0.012 : 0.005) : 0;

  const spcPoints = generateSPCHistory(targetNominal, tolerance, 30, driftAmount);
  const stackupDimensions = calculateToleranceStackup();

  // Defect Pareto Data
  const paretoData = [
    { defect: 'Bore Surface Finish Roughness', count: 42, pct: 45 },
    { defect: 'Crank Journal Out-of-Round', count: 22, pct: 68 },
    { defect: 'Deck Flatness Deviation', count: 14, pct: 83 },
    { defect: 'Valve Guide Concentricity', count: 9, pct: 92 },
    { defect: 'Head Gasket Sealing Scratch', count: 7, pct: 100 },
  ];

  return (
    <div className="p-4 space-y-4 overflow-y-auto h-[calc(100vh-50px)] bg-graphite-950 font-mono-tech text-xs">
      {/* Top Banner */}
      <div className="bg-graphite-900 border border-graphite-800 p-3 rounded flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <span className="font-bold text-gray-100 text-sm">STATISTICAL PROCESS CONTROL (SPC) & QUALITY TWIN</span>
            <p className="text-gray-400 text-[11px]">Real-time Cp/Cpk Capability, Tolerance Stack-up & Process Drift Detection</p>
          </div>
        </div>

        {/* Drift Simulation Toggle */}
        <div className="flex items-center gap-3 bg-graphite-950 border border-graphite-800 p-2 rounded">
          <span className="text-gray-300 font-bold">TOOL WEAR DRIFT SIMULATION:</span>
          <button
            onClick={() => setSimulateDrift(!simulateDrift)}
            className={`px-3 py-1 rounded border font-bold transition ${
              simulateDrift ? 'bg-amber-500/20 text-amber-300 border-amber-500/50' : 'bg-graphite-800 border-graphite-700 text-gray-400'
            }`}
          >
            {simulateDrift ? 'DRIFT ACTIVE (+8 microns)' : 'DRIFT OFF'}
          </button>
        </div>
      </div>

      {/* SPC Control Chart Section */}
      <div className="bg-graphite-900 border border-graphite-800 rounded p-4 space-y-3">
        <div className="flex items-center justify-between border-b border-graphite-800 pb-2">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-cyan-400" />
            <span className="font-bold text-gray-200">X-BAR STATISTICAL CONTROL CHART</span>
          </div>

          <div className="flex items-center gap-2">
            {[
              { id: 'bore', label: 'Cylinder Bore (86.000 ±0.015mm)' },
              { id: 'journal', label: 'Crank Journal (58.000 ±0.008mm)' },
              { id: 'ring_gap', label: 'Ring Gap (0.280 ±0.050mm)' },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setFeatureName(f.id as any)}
                className={`px-2.5 py-1 rounded transition text-xs ${
                  featureName === f.id
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold'
                    : 'bg-graphite-800 text-gray-400 hover:text-white'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {/* SPC Chart Area */}
        <div className="h-[320px] w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={spcPoints}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e232b" />
              <XAxis dataKey="timestamp" stroke="#718096" tick={{ fontSize: 10 }} />
              <YAxis domain={['auto', 'auto']} stroke="#718096" tick={{ fontSize: 10 }} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0e1116', borderColor: '#2d3748', fontSize: '11px', fontFamily: 'monospace' }}
              />
              <ReferenceLine y={targetNominal + tolerance} stroke="#f87171" strokeDasharray="4 4" label={{ value: 'USL', fill: '#f87171', fontSize: 10 }} />
              <ReferenceLine y={targetNominal - tolerance} stroke="#f87171" strokeDasharray="4 4" label={{ value: 'LSL', fill: '#f87171', fontSize: 10 }} />
              <ReferenceLine y={targetNominal} stroke="#34d399" label={{ value: 'NOMINAL', fill: '#34d399', fontSize: 10 }} />
              <Line type="monotone" dataKey="meanValue" stroke="#38bdf8" strokeWidth={2.5} dot={{ r: 3, fill: '#38bdf8' }} name="Measured Sample Mean (mm)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Bottom Grid: Tolerance Stack-up Analysis (Left) & Defect Pareto Chart (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Tolerance Stack-up Table */}
        <div className="lg:col-span-7 bg-graphite-900 border border-graphite-800 rounded p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-graphite-800 pb-2">
            <span className="font-bold text-gray-200 flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              1-D & 3-D TOLERANCE STACK-UP ANALYSIS
            </span>
            <span className="text-[10px] text-gray-400">RSS Propagation Method</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-[11px] font-mono-tech">
              <thead>
                <tr className="bg-graphite-950 border-b border-graphite-800 text-gray-400">
                  <th className="p-2">FEATURE</th>
                  <th className="p-2">NOMINAL</th>
                  <th className="p-2">LIMITS (LSL / USL)</th>
                  <th className="p-2">ACTUAL SIMULATED</th>
                  <th className="p-2">CPK</th>
                  <th className="p-2">STATUS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-graphite-800">
                {stackupDimensions.map((dim) => (
                  <tr key={dim.id} className="hover:bg-graphite-950">
                    <td className="p-2 font-bold text-gray-200">{dim.featureName}</td>
                    <td className="p-2 text-gray-300">{dim.nominalMm} mm</td>
                    <td className="p-2 text-gray-400">{dim.lowerLimitMm} - {dim.upperLimitMm} mm</td>
                    <td className="p-2 text-cyan-400 font-bold">{dim.actualSimulatedMm} mm ({dim.deviationMicrons > 0 ? `+${dim.deviationMicrons}` : dim.deviationMicrons} µm)</td>
                    <td className="p-2 text-emerald-400 font-bold">{dim.cpk}</td>
                    <td className="p-2">
                      <span className="px-1.5 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] font-bold">
                        {dim.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Defect Pareto Chart */}
        <div className="lg:col-span-5 bg-graphite-900 border border-graphite-800 rounded p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-graphite-800 pb-2">
            <span className="font-bold text-gray-200">DEFECT PARETO DISTRIBUTION</span>
            <span className="text-[10px] text-amber-400">Top Quality Failure Modes</span>
          </div>

          <div className="h-[220px] w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={paretoData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e232b" />
                <XAxis dataKey="defect" stroke="#718096" tick={{ fontSize: 8 }} />
                <YAxis stroke="#718096" tick={{ fontSize: 10 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0e1116', borderColor: '#2d3748', fontSize: '11px', fontFamily: 'monospace' }}
                />
                <Bar dataKey="count" fill="#fbbf24" name="Defect Count" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
