'use client';

import React, { useState } from 'react';
import { MachineAsset } from '@/types/factory';
import { Factory, Server, Cpu, AlertTriangle, Zap, CheckCircle2, ChevronRight, Activity, Wrench } from 'lucide-react';

interface FactoryScreenProps {
  machines: MachineAsset[];
  onNavigateScreen: (screenId: any) => void;
}

export default function FactoryScreen({ machines, onNavigateScreen }: FactoryScreenProps) {
  const [selectedMachine, setSelectedMachine] = useState<MachineAsset | null>(machines[0]);

  return (
    <div className="p-4 space-y-4 overflow-y-auto h-[calc(100vh-50px)] bg-graphite-950 font-mono-tech text-xs">
      {/* Top Banner */}
      <div className="bg-graphite-900 border border-graphite-800 p-3 rounded flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded">
            <Factory className="w-5 h-5" />
          </div>
          <div>
            <span className="font-bold text-gray-100 text-sm">VIRTUAL FACTORY TOP-DOWN SCADA FLOOR PLAN</span>
            <p className="text-gray-400 text-[11px]">Real-time Machine Monitoring, WIP Buffers & Conveyor Lines</p>
          </div>
        </div>

        <div className="flex items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-graphite-950 border border-graphite-800">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-gray-300">RUNNING ({machines.filter((m) => m.status === 'RUNNING').length})</span>
          </div>
          <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-graphite-950 border border-graphite-800">
            <div className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
            <span className="text-amber-300">WARNING ({machines.filter((m) => m.status === 'WARNING').length})</span>
          </div>
        </div>
      </div>

      {/* Main Floor Plan SCADA Grid (Left) & Selected Machine Inspector (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 h-[600px]">
        {/* Virtual Top-Down Factory Grid Layout */}
        <div className="lg:col-span-8 bg-graphite-900 border border-graphite-800 rounded p-4 flex flex-col justify-between engineering-grid relative">
          <div className="flex items-center justify-between border-b border-graphite-800 pb-2 mb-2">
            <span className="font-bold text-gray-200 flex items-center gap-2">
              <Server className="w-4 h-4 text-cyan-400" />
              PLANT #4 — ENGINE MACHINING & ASSEMBLY SCADA FLOOR
            </span>
            <span className="text-[10px] text-gray-400">Click any machine cell to zoom</span>
          </div>

          {/* Top Down Grid Representation */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 my-auto p-2">
            {machines.map((m) => {
              const isSelected = selectedMachine?.id === m.id;
              return (
                <div
                  key={m.id}
                  onClick={() => setSelectedMachine(m)}
                  className={`p-3 rounded border transition cursor-pointer flex flex-col justify-between h-36 ${
                    isSelected
                      ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 shadow-lg ring-1 ring-cyan-500'
                      : m.status === 'WARNING'
                      ? 'bg-amber-500/10 border-amber-500/40 text-amber-200 hover:bg-amber-500/20'
                      : 'bg-graphite-950 border-graphite-800 text-gray-300 hover:bg-graphite-800'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <div
                        className={`w-2.5 h-2.5 rounded-full ${
                          m.status === 'RUNNING' ? 'bg-emerald-400' : m.status === 'WARNING' ? 'bg-amber-400 animate-pulse' : 'bg-rose-500'
                        }`}
                      />
                      <span className="font-bold text-gray-100">{m.id}</span>
                    </div>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-graphite-800 font-bold text-cyan-400">
                      OEE {m.oeePct}%
                    </span>
                  </div>

                  <div className="text-[11px] text-gray-400 font-semibold my-1 line-clamp-1">{m.name}</div>

                  <div className="space-y-1 text-[10px] text-gray-400 border-t border-graphite-800 pt-1.5">
                    <div className="flex justify-between">
                      <span>Tool Wear:</span>
                      <span className={m.toolWearPct > 75 ? 'text-amber-400 font-bold' : 'text-gray-200'}>{m.toolWearPct}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Spindle Load:</span>
                      <span className="text-gray-200">{m.spindleSpeedRpm} RPM</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Conveyor Belt Status Legend */}
          <div className="flex items-center justify-between border-t border-graphite-800 pt-2 text-[10px] text-gray-400">
            <div className="flex items-center gap-4">
              <span>WIP Conveyor Line A: <strong className="text-emerald-400">ACTIVE (Takt 50s)</strong></span>
              <span>Buffer Capacity: <strong className="text-cyan-400">12 / 20 Units</strong></span>
            </div>
            <button
              onClick={() => onNavigateScreen('machines')}
              className="text-cyan-400 hover:underline flex items-center gap-1"
            >
              Open Full Telemetry Suite <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Selected Machine Telemetry & Prognosis Card */}
        {selectedMachine && (
          <div className="lg:col-span-4 bg-graphite-900 border border-graphite-800 rounded p-4 space-y-3 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between border-b border-graphite-800 pb-2">
                <div>
                  <span className="text-[10px] text-cyan-400 font-bold">MACHINE SCADA NODE</span>
                  <h3 className="font-bold text-gray-100 text-sm">{selectedMachine.id}</h3>
                </div>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                  selectedMachine.status === 'RUNNING' ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300' : 'bg-amber-500/20 border-amber-500 text-amber-300'
                }`}>
                  {selectedMachine.status}
                </span>
              </div>

              <div className="bg-graphite-950 border border-graphite-800 p-2.5 rounded space-y-1">
                <span className="text-gray-500 text-[10px] block">NAME & MODEL</span>
                <span className="text-gray-200 font-bold text-xs">{selectedMachine.name}</span>
                <span className="text-gray-400 text-[10px] block">{selectedMachine.manufacturer} ({selectedMachine.model})</span>
              </div>

              {/* Machine Health Metrics */}
              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div className="bg-graphite-950 border border-graphite-800 p-2 rounded">
                  <span className="text-gray-500 text-[10px] block">CYCLE TIME</span>
                  <span className="text-cyan-400 font-bold">{selectedMachine.cycleTimeSec}s</span>
                </div>
                <div className="bg-graphite-950 border border-graphite-800 p-2 rounded">
                  <span className="text-gray-500 text-[10px] block">TOOL WEAR</span>
                  <span className={selectedMachine.toolWearPct > 75 ? 'text-amber-400 font-bold' : 'text-emerald-400 font-bold'}>
                    {selectedMachine.toolWearPct}%
                  </span>
                </div>
                <div className="bg-graphite-950 border border-graphite-800 p-2 rounded">
                  <span className="text-gray-500 text-[10px] block">VIBRATION RMS</span>
                  <span className="text-gray-200 font-bold">{selectedMachine.vibrationMmS} mm/s</span>
                </div>
                <div className="bg-graphite-950 border border-graphite-800 p-2 rounded">
                  <span className="text-gray-500 text-[10px] block">POWER LOAD</span>
                  <span className="text-amber-400 font-bold">{selectedMachine.energyKw} kW</span>
                </div>
              </div>

              {/* Predictive Maintenance Diagnosis */}
              <div className="bg-graphite-950 border border-graphite-800 p-3 rounded space-y-1">
                <div className="flex items-center gap-1.5 text-amber-400 font-bold text-[11px]">
                  <Activity className="w-3.5 h-3.5" />
                  <span>PREDICTIVE HEALTH PROGNOSIS</span>
                </div>
                <p className="text-gray-300 text-[11px] leading-snug">
                  {selectedMachine.healthDiagnosis}
                </p>
                <div className="text-[10px] text-gray-500 pt-1">
                  Remaining Useful Life (RUL): <strong className="text-cyan-400">{selectedMachine.remainingUsefulLifeHours} Hours</strong>
                </div>
              </div>
            </div>

            <button
              onClick={() => onNavigateScreen('machines')}
              className="w-full py-2 bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/50 text-cyan-300 rounded font-bold text-xs transition flex items-center justify-center gap-1"
            >
              Open Live Telemetry Dashboard <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
