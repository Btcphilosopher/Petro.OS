'use client';

import React from 'react';
import { DEFAULT_AUDIT_LOGS } from '@/lib/simulation/defaults';
import { FileSpreadsheet, CheckCircle2, ShieldCheck, User } from 'lucide-react';

export default function AuditLogScreen() {
  return (
    <div className="p-4 space-y-4 overflow-y-auto h-[calc(100vh-50px)] bg-graphite-950 font-mono-tech text-xs">
      <div className="bg-graphite-900 border border-graphite-800 p-3 rounded flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 rounded">
            <FileSpreadsheet className="w-5 h-5" />
          </div>
          <div>
            <span className="font-bold text-gray-100 text-sm">ENTERPRISE REVISION & AUDIT LOG</span>
            <p className="text-gray-400 text-[11px]">Immutable Change Records for Process, Tolerances & Parameter Tuning</p>
          </div>
        </div>
      </div>

      <div className="bg-graphite-900 border border-graphite-800 rounded p-4">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono-tech">
            <thead>
              <tr className="bg-graphite-950 border-b border-graphite-800 text-gray-400">
                <th className="p-2.5">TIMESTAMP</th>
                <th className="p-2.5">USER / ROLE</th>
                <th className="p-2.5">ACTION</th>
                <th className="p-2.5">ENTITY / FIELD</th>
                <th className="p-2.5">PREVIOUS VALUE</th>
                <th className="p-2.5">NEW VALUE</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-graphite-800">
              {DEFAULT_AUDIT_LOGS.map((log) => (
                <tr key={log.id} className="hover:bg-graphite-950">
                  <td className="p-2.5 text-cyan-400 font-bold">{log.timestamp}</td>
                  <td className="p-2.5 text-gray-200 font-semibold">{log.user}</td>
                  <td className="p-2.5">
                    <span className="px-1.5 py-0.5 rounded bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 font-bold text-[10px]">
                      {log.action}
                    </span>
                  </td>
                  <td className="p-2.5 text-gray-300">{log.entityChanged}</td>
                  <td className="p-2.5 text-rose-400">{log.oldValue}</td>
                  <td className="p-2.5 text-emerald-400 font-bold">{log.newValue}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
