'use client';

import React, { useState } from 'react';
import { EngineConfig } from '@/types/engine';
import { SimulationOperatingState } from '@/types/physics';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from 'recharts';
import { Cpu, Activity, Flame, RotateCcw, Sliders } from 'lucide-react';

interface EngineTwinScreenProps {
  engineConfig: EngineConfig;
  onUpdateEngineConfig: (updated: EngineConfig) => void;
  simState: SimulationOperatingState;
  rpm: number;
  onChangeRpm: (rpm: number) => void;
  throttlePct: number;
  onChangeThrottle: (throttle: number) => void;
}

export default function EngineTwinScreen({
  engineConfig,
  onUpdateEngineConfig,
  simState,
  rpm,
  onChangeRpm,
  throttlePct,
  onChangeThrottle,
}: EngineTwinScreenProps) {
  const [activeTab, setActiveTab] = useState<'CYLINDER_PV' | 'PRESSURE_CRANK' | 'TORQUE_CRANK' | 'HEAT_RELEASE'>('CYLINDER_PV');

  // Format data points for Recharts
  const pvData = simState.crankAngleTrace.map((pt) => ({
    volumeCc: Math.round(pt.cylinderVolumeCc * 10) / 10,
    pressureBar: Math.round(pt.pressureBar * 10) / 10,
    crankAngleDeg: pt.crankAngleDeg,
  }));

  const pressureCrankData = simState.crankAngleTrace.map((pt) => ({
    crankAngleDeg: pt.crankAngleDeg,
    pressureBar: Math.round(pt.pressureBar * 10) / 10,
    temperatureK: Math.round(pt.temperatureK),
    heatReleaseJ: Math.round(pt.heatReleaseRateJDeg * 10) / 10,
  }));

  const torqueCrankData = simState.crankAngleTrace.map((pt) => ({
    crankAngleDeg: pt.crankAngleDeg,
    crankTorqueNm: Math.round(pt.crankTorqueNm * 10) / 10,
    gasForceKn: Math.round((pt.gasForceN / 1000) * 10) / 10,
    inertiaForceKn: Math.round((pt.inertiaForceN / 1000) * 10) / 10,
  }));

  return (
    <div className="p-4 space-y-4 overflow-y-auto h-[calc(100vh-50px)] bg-graphite-950 font-mono-tech text-xs">
      {/* Top Banner: Operating State & Controls */}
      <div className="bg-graphite-900 border border-graphite-800 p-3 rounded flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 rounded">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-gray-100 text-sm">{engineConfig.name}</span>
              <span className="bg-graphite-800 text-cyan-400 px-1.5 py-0.5 rounded text-[10px] font-bold">
                {engineConfig.type} | {engineConfig.displacementL}L | {engineConfig.valvetrainType}
              </span>
            </div>
            <p className="text-gray-400 text-[11px]">Parametric Thermodynamic & Kinematic Digital Twin Engine</p>
          </div>
        </div>

        {/* Dynamic Controls Sliders */}
        <div className="flex flex-wrap items-center gap-4 bg-graphite-950 border border-graphite-800 p-2 rounded">
          <div className="flex items-center gap-2">
            <span className="text-gray-400 text-[10px]">RPM:</span>
            <input
              type="range"
              min={600}
              max={8500}
              step={100}
              value={rpm}
              onChange={(e) => onChangeRpm(Number(e.target.value))}
              className="w-28 accent-cyan-400 cursor-pointer"
            />
            <span className="text-cyan-400 font-bold w-16">{rpm} RPM</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-gray-400 text-[10px]">THROTTLE:</span>
            <input
              type="range"
              min={10}
              max={100}
              step={5}
              value={throttlePct}
              onChange={(e) => onChangeThrottle(Number(e.target.value))}
              className="w-24 accent-amber-400 cursor-pointer"
            />
            <span className="text-amber-400 font-bold w-12">{throttlePct}%</span>
          </div>
        </div>
      </div>

      {/* Thermodynamic Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2.5">
        <div className="bg-graphite-900 border border-graphite-800 p-2.5 rounded text-center">
          <span className="text-gray-500 text-[10px] block">INDICATED POWER</span>
          <span className="text-cyan-400 text-base font-bold">{simState.powerKw} kW</span>
        </div>
        <div className="bg-graphite-900 border border-graphite-800 p-2.5 rounded text-center">
          <span className="text-gray-500 text-[10px] block">BRAKE TORQUE</span>
          <span className="text-cyan-400 text-base font-bold">{simState.torqueNm} Nm</span>
        </div>
        <div className="bg-graphite-900 border border-graphite-800 p-2.5 rounded text-center">
          <span className="text-gray-500 text-[10px] block">BMEP</span>
          <span className="text-gray-200 text-base font-bold">{simState.bmepBar} bar</span>
        </div>
        <div className="bg-graphite-900 border border-graphite-800 p-2.5 rounded text-center">
          <span className="text-gray-500 text-[10px] block">FMEP (FRICTION)</span>
          <span className="text-rose-400 text-base font-bold">{simState.fmepBar} bar</span>
        </div>
        <div className="bg-graphite-900 border border-graphite-800 p-2.5 rounded text-center">
          <span className="text-gray-500 text-[10px] block">VOLUMETRIC EFF.</span>
          <span className="text-emerald-400 text-base font-bold">{simState.volumetricEfficiencyPct}%</span>
        </div>
        <div className="bg-graphite-900 border border-graphite-800 p-2.5 rounded text-center">
          <span className="text-gray-500 text-[10px] block">BSFC</span>
          <span className="text-amber-400 text-base font-bold">{simState.bsfcGKh} g/kWh</span>
        </div>
        <div className="bg-graphite-900 border border-graphite-800 p-2.5 rounded text-center">
          <span className="text-gray-500 text-[10px] block">COOLANT TEMP</span>
          <span className="text-amber-400 text-base font-bold">{simState.coolantTempC} °C</span>
        </div>
        <div className="bg-graphite-900 border border-graphite-800 p-2.5 rounded text-center">
          <span className="text-gray-500 text-[10px] block">EXHAUST TEMP</span>
          <span className="text-rose-400 text-base font-bold">{simState.exhaustTempC} °C</span>
        </div>
      </div>

      {/* Interactive Graph Selector Tabs */}
      <div className="bg-graphite-900 border border-graphite-800 rounded p-3 space-y-3">
        <div className="flex items-center justify-between border-b border-graphite-800 pb-2">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-cyan-400" />
            <span className="font-bold text-gray-200">CYLINDER SIMULATION DIAGRAMS</span>
          </div>

          <div className="flex items-center gap-1.5">
            {[
              { id: 'CYLINDER_PV', label: 'P-V Diagram (Indicator Card)' },
              { id: 'PRESSURE_CRANK', label: 'Pressure vs Crank Angle (0-720°)' },
              { id: 'TORQUE_CRANK', label: 'Crankshaft Torque & Forces' },
              { id: 'HEAT_RELEASE', label: 'Wiebe Heat Release Rate' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-2.5 py-1 rounded text-xs transition ${
                  activeTab === tab.id
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold'
                    : 'bg-graphite-800 text-gray-400 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Chart Viewport */}
        <div className="h-[360px] w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            {activeTab === 'CYLINDER_PV' ? (
              <AreaChart data={pvData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e232b" />
                <XAxis dataKey="volumeCc" stroke="#718096" tick={{ fontSize: 10 }} unit=" cc" />
                <YAxis stroke="#718096" tick={{ fontSize: 10 }} unit=" bar" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0e1116', borderColor: '#2d3748', fontSize: '11px', fontFamily: 'monospace' }}
                />
                <Area type="monotone" dataKey="pressureBar" stroke="#38bdf8" fill="#38bdf8" fillOpacity={0.15} strokeWidth={2} name="Cylinder Pressure (bar)" />
              </AreaChart>
            ) : activeTab === 'PRESSURE_CRANK' ? (
              <LineChart data={pressureCrankData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e232b" />
                <XAxis dataKey="crankAngleDeg" stroke="#718096" tick={{ fontSize: 10 }} unit="°" />
                <YAxis stroke="#718096" tick={{ fontSize: 10 }} unit=" bar" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0e1116', borderColor: '#2d3748', fontSize: '11px', fontFamily: 'monospace' }}
                />
                <Line type="monotone" dataKey="pressureBar" stroke="#38bdf8" strokeWidth={2} dot={false} name="Pressure (bar)" />
                <Line type="monotone" dataKey="temperatureK" stroke="#fbbf24" strokeWidth={1.5} dot={false} name="Temperature (K)" yAxisId={0} />
              </LineChart>
            ) : activeTab === 'TORQUE_CRANK' ? (
              <LineChart data={torqueCrankData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e232b" />
                <XAxis dataKey="crankAngleDeg" stroke="#718096" tick={{ fontSize: 10 }} unit="°" />
                <YAxis stroke="#718096" tick={{ fontSize: 10 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0e1116', borderColor: '#2d3748', fontSize: '11px', fontFamily: 'monospace' }}
                />
                <Line type="monotone" dataKey="crankTorqueNm" stroke="#34d399" strokeWidth={2} dot={false} name="Shaft Torque (Nm)" />
                <Line type="monotone" dataKey="gasForceKn" stroke="#38bdf8" strokeWidth={1} dot={false} name="Gas Force (kN)" />
                <Line type="monotone" dataKey="inertiaForceKn" stroke="#f87171" strokeWidth={1} dot={false} name="Inertia Force (kN)" />
              </LineChart>
            ) : (
              <AreaChart data={pressureCrankData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e232b" />
                <XAxis dataKey="crankAngleDeg" stroke="#718096" tick={{ fontSize: 10 }} unit="°" />
                <YAxis stroke="#718096" tick={{ fontSize: 10 }} unit=" J/°" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0e1116', borderColor: '#2d3748', fontSize: '11px', fontFamily: 'monospace' }}
                />
                <Area type="monotone" dataKey="heatReleaseJ" stroke="#fbbf24" fill="#fbbf24" fillOpacity={0.2} strokeWidth={2} name="Heat Release Rate (J/deg)" />
              </AreaChart>
            )}
          </ResponsiveContainer>
        </div>
      </div>

      {/* Individual Cylinder States Grid */}
      <div className="bg-graphite-900 border border-graphite-800 rounded p-3 space-y-2">
        <div className="flex items-center justify-between border-b border-graphite-800 pb-2">
          <span className="font-bold text-gray-200 flex items-center gap-2">
            <Flame className="w-4 h-4 text-amber-400" />
            INDIVIDUAL CYLINDER TELEMETRY
          </span>
          <span className="text-[10px] text-gray-400">Firing Order: [{engineConfig.firingOrder.join(' - ')}]</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {simState.cylinders.map((cyl) => (
            <div key={cyl.cylinderNumber} className="bg-graphite-950 border border-graphite-800 p-3 rounded space-y-2">
              <div className="flex justify-between items-center pb-1 border-b border-graphite-800">
                <span className="font-bold text-cyan-400">CYLINDER #{cyl.cylinderNumber}</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 font-bold">
                  {cyl.currentStroke}
                </span>
              </div>

              <div className="space-y-1 text-[11px]">
                <div className="flex justify-between text-gray-400">
                  <span>Crank Angle:</span>
                  <span className="text-gray-200 font-bold">{cyl.crankAngleDeg}°</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Pressure:</span>
                  <span className="text-cyan-400 font-bold">{Math.round(cyl.pressureBar * 10) / 10} bar</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Combustion Temp:</span>
                  <span className="text-amber-400 font-bold">{cyl.temperatureC} °C</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Peak Pressure:</span>
                  <span className="text-gray-200">{Math.round(cyl.peakPressureBar * 10) / 10} bar @ {cyl.peakPressureAngleDeg}°</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>AFR Ratio:</span>
                  <span className="text-emerald-400 font-bold">{cyl.airFuelRatio}:1</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
