'use client';

import React, { useState } from 'react';
import { DEFAULT_ASSEMBLY_STATIONS } from '@/lib/simulation/defaults';
import { AssemblyStation } from '@/types/assembly';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
} from 'recharts';
import { Wrench, CheckCircle2, Activity, ShieldCheck, AlertTriangle } from 'lucide-react';

export default function AssemblyScreen() {
  const [selectedStation, setSelectedStation] = useState<AssemblyStation>(DEFAULT_ASSEMBLY_STATIONS[0]);

  // Synthetic Torque-Angle trace curve for bolted joints
  const torqueAngleTrace = [
    { angleDeg: 0, torqueNm: 5 },
    { angleDeg: 30, torqueNm: 25 },
    { angleDeg: 60, torqueNm: 45 },
    { angleDeg: 90, torqueNm: 60 }, // Snug torque threshold
    { angleDeg: 120, torqueNm: 72 },
    { angleDeg: 150, torqueNm: 81 },
    { angleDeg: 180, torqueNm: 85 }, // Final yield point pass
  ];

  return (
    <div className="p-4 space-y-4 overflow-y-auto h-[calc(100vh-50px)] bg-graphite-950 font-mono-tech text-xs">
      {/* Top Banner */}
      <div className="bg-graphite-900 border border-graphite-800 p-3 rounded flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded">
            <Wrench className="w-5 h-5" />
          </div>
          <div>
            <span className="font-bold text-gray-100 text-sm">ASSEMBLY LINE & TORQUE TRACEABILITY TWIN</span>
            <p className="text-gray-400 text-[11px]">DC Tool Fastening Audit, Joint Angle-Yield Verification & Error Proofing (Poka-Yoke)</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[10px] text-gray-400">LINE TAKT TIME:</span>
          <span className="text-cyan-400 font-bold bg-graphite-950 border border-graphite-800 px-2 py-1 rounded">50 SECONDS</span>
        </div>
      </div>

      {/* Assembly Stations Process Strip */}
      <div className="bg-graphite-900 border border-graphite-800 rounded p-4 space-y-3">
        <span className="font-bold text-gray-200 block border-b border-graphite-800 pb-2">
          8-STATION ENGINE ASSEMBLY PIPELINE
        </span>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2">
          {DEFAULT_ASSEMBLY_STATIONS.map((st) => {
            const isSelected = selectedStation.id === st.id;
            return (
              <button
                key={st.id}
                onClick={() => setSelectedStation(st)}
                className={`p-2 rounded text-left transition border flex flex-col justify-between h-24 ${
                  isSelected
                    ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 font-bold shadow-md'
                    : 'bg-graphite-950 border-graphite-800 text-gray-300 hover:bg-graphite-800'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between text-[10px] text-gray-500">
                    <span>STATION {st.stationNumber}</span>
                    <span className="text-emerald-400 font-bold">{st.status}</span>
                  </div>
                  <div className="font-bold text-[11px] truncate mt-1 text-gray-200">{st.name}</div>
                </div>

                <div className="text-[10px] text-gray-400 pt-1 border-t border-graphite-800 flex justify-between">
                  <span>Fasteners:</span>
                  <span className="text-cyan-400 font-bold">{st.fastenersToTorque.length} Bolts</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Assembly Station Details & Torque Trace Curve */}
      {selectedStation && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Station Operations Card */}
          <div className="lg:col-span-5 bg-graphite-900 border border-graphite-800 rounded p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-graphite-800 pb-2">
              <div>
                <span className="text-[10px] text-cyan-400 font-bold">STATION #{selectedStation.stationNumber}</span>
                <h3 className="font-bold text-gray-100 text-sm">{selectedStation.name}</h3>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 border border-emerald-500 text-emerald-300">
                {selectedStation.status}
              </span>
            </div>

            <div className="bg-graphite-950 border border-graphite-800 p-3 rounded space-y-2 text-[11px]">
              <div className="flex justify-between">
                <span className="text-gray-400">ASSIGNED OPERATOR:</span>
                <span className="text-gray-200 font-bold">{selectedStation.assignedOperator}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">CYCLE TIME / TAKT:</span>
                <span className="text-cyan-400 font-bold">{selectedStation.cycleTimeSec}s / {selectedStation.taktTimeSec}s</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">FASTENERS IN STATION:</span>
                <span className="text-amber-400 font-bold">{selectedStation.fastenersToTorque.length} Inspected Joint(s)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">DEFECT COUNT:</span>
                <span className="text-emerald-400 font-bold">{selectedStation.defectsRecordedCount} Defect(s)</span>
              </div>
            </div>

            {/* Fastener Torque Audit Checklist */}
            <div className="bg-graphite-950 border border-graphite-800 p-3 rounded space-y-1.5">
              <span className="font-bold text-gray-300 text-[11px] block border-b border-graphite-800 pb-1">
                FASTENING AUDIT CHECKLIST
              </span>
              {selectedStation.fastenersToTorque.length > 0 ? (
                selectedStation.fastenersToTorque.map((trq) => (
                  <div key={trq.id} className="flex items-center justify-between text-[11px] text-gray-300">
                    <div className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>{trq.fastenerName}</span>
                    </div>
                    <span className="text-cyan-400 font-bold text-[10px]">{trq.actualTorqueNm} Nm ({trq.actualAngleDeg}°)</span>
                  </div>
                ))
              ) : (
                <div className="text-[10px] text-gray-500 py-1">No critical torque fasteners assigned to this station.</div>
              )}
            </div>
          </div>

          {/* DC Tool Torque-Angle Trace Verification Curve */}
          <div className="lg:col-span-7 bg-graphite-900 border border-graphite-800 rounded p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-graphite-800 pb-2">
              <span className="font-bold text-gray-200 flex items-center gap-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                DC ELECTRIC NUTRUNNER TORQUE-ANGLE SIGNATURE TRACE
              </span>
              <span className="text-[10px] text-emerald-400 font-bold">ANGLE YIELD COMPLIANT</span>
            </div>

            <div className="h-[260px] w-full pt-1">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={torqueAngleTrace}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e232b" />
                  <XAxis dataKey="angleDeg" stroke="#718096" tick={{ fontSize: 10 }} unit="°" />
                  <YAxis stroke="#718096" tick={{ fontSize: 10 }} unit=" Nm" />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0e1116', borderColor: '#2d3748', fontSize: '11px', fontFamily: 'monospace' }}
                  />
                  <ReferenceLine y={selectedStation.fastenersToTorque[0]?.targetTorqueNm || 85} stroke="#34d399" label={{ value: 'TARGET TORQUE', fill: '#34d399', fontSize: 10 }} />
                  <Line type="monotone" dataKey="torqueNm" stroke="#38bdf8" strokeWidth={2.5} dot={{ r: 4, fill: '#38bdf8' }} name="Fastener Torque (Nm)" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
