'use client';

import React, { useState } from 'react';
import { DEFAULT_MANUFACTURING_STEPS } from '@/lib/simulation/defaults';
import { ManufacturingFlowStep } from '@/types/manufacturing';
import { Workflow, ChevronRight, Zap, DollarSign, Clock, ShieldAlert, CheckCircle2, Sliders } from 'lucide-react';

interface ManufacturingScreenProps {
  onNavigateScreen: (screenId: any) => void;
}

export default function ManufacturingScreen({ onNavigateScreen }: ManufacturingScreenProps) {
  const [steps, setSteps] = useState<ManufacturingFlowStep[]>(DEFAULT_MANUFACTURING_STEPS);
  const [selectedStep, setSelectedStep] = useState<ManufacturingFlowStep>(DEFAULT_MANUFACTURING_STEPS[4]); // Precision machining

  // Handle parameter tweaking
  const handleUpdateParam = (field: keyof ManufacturingFlowStep, value: number) => {
    const updatedSteps = steps.map((s) => {
      if (s.id === selectedStep.id) {
        return { ...s, [field]: value };
      }
      return s;
    });
    setSteps(updatedSteps);
    setSelectedStep({ ...selectedStep, [field]: value });
  };

  const totalCycleTime = steps.reduce((acc, s) => acc + s.cycleTimeSec, 0);
  const totalCost = steps.reduce((acc, s) => acc + s.costPerUnitUSD, 0);
  const totalEnergy = steps.reduce((acc, s) => acc + s.energyKwhPerUnit, 0);

  return (
    <div className="p-4 space-y-4 overflow-y-auto h-[calc(100vh-50px)] bg-graphite-950 font-mono-tech text-xs">
      {/* Top Banner: Manufacturing Process Overview */}
      <div className="bg-graphite-900 border border-graphite-800 p-3 rounded flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 rounded">
            <Workflow className="w-5 h-5" />
          </div>
          <div>
            <span className="font-bold text-gray-100 text-sm">END-TO-END MANUFACTURING PROCESS DIGITAL TWIN</span>
            <p className="text-gray-400 text-[11px]">Integrated Process Routing & Machine Parameter Tuning</p>
          </div>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono-tech">
          <div className="bg-graphite-950 border border-graphite-800 px-3 py-1.5 rounded">
            <span className="text-gray-400 text-[10px] block">TOTAL CYCLE TIME</span>
            <span className="text-cyan-400 font-bold">{Math.round(totalCycleTime / 60)} min ({totalCycleTime}s)</span>
          </div>
          <div className="bg-graphite-950 border border-graphite-800 px-3 py-1.5 rounded">
            <span className="text-gray-400 text-[10px] block">TOTAL MFG COST</span>
            <span className="text-amber-400 font-bold">${Math.round(totalCost)} / Engine</span>
          </div>
          <div className="bg-graphite-950 border border-graphite-800 px-3 py-1.5 rounded">
            <span className="text-gray-400 text-[10px] block">ENERGY INTENSITY</span>
            <span className="text-emerald-400 font-bold">{Math.round(totalEnergy * 10) / 10} kWh / Engine</span>
          </div>
        </div>
      </div>

      {/* Interactive Horizontal Process Routing Map */}
      <div className="bg-graphite-900 border border-graphite-800 rounded p-4 space-y-3">
        <div className="flex items-center justify-between border-b border-graphite-800 pb-2">
          <span className="font-bold text-gray-200">10-STAGE CONTINUOUS MANUFACTURING PIPELINE</span>
          <span className="text-[10px] text-cyan-400">Click any process node to inspect & modify parameters</span>
        </div>

        {/* Process Steps Line */}
        <div className="grid grid-cols-2 sm:grid-cols-5 lg:grid-cols-10 gap-2">
          {steps.map((step) => {
            const isSelected = selectedStep.id === step.id;
            return (
              <button
                key={step.id}
                onClick={() => setSelectedStep(step)}
                className={`p-2 rounded text-left transition border flex flex-col justify-between h-24 ${
                  isSelected
                    ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 font-bold shadow-md'
                    : step.status === 'BOTTLENECK'
                    ? 'bg-amber-500/10 border-amber-500/40 text-amber-200 hover:bg-amber-500/20'
                    : 'bg-graphite-950 border-graphite-800 text-gray-300 hover:bg-graphite-800'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between text-[10px] text-gray-500">
                    <span>STEP {step.stepNumber}</span>
                    <span className={step.status === 'BOTTLENECK' ? 'text-amber-400 font-bold' : 'text-emerald-400'}>
                      {step.status}
                    </span>
                  </div>
                  <div className="font-bold text-[11px] truncate mt-1 text-gray-200">{step.title}</div>
                </div>

                <div className="text-[10px] text-gray-400 flex items-center justify-between mt-2 pt-1 border-t border-graphite-800">
                  <span>{step.cycleTimeSec}s</span>
                  <span>${step.costPerUnitUSD}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Operation Parameter Tuner & Telemetry Card */}
      {selectedStep && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Operation Details & Description */}
          <div className="lg:col-span-6 bg-graphite-900 border border-graphite-800 rounded p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-graphite-800 pb-2">
              <div>
                <span className="text-[10px] text-cyan-400 font-bold">STEP #{selectedStep.stepNumber} — {selectedStep.stage}</span>
                <h3 className="text-sm font-bold text-gray-100">{selectedStep.title}</h3>
              </div>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                selectedStep.status === 'BOTTLENECK' ? 'bg-amber-500/20 border-amber-500 text-amber-300' : 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
              }`}>
                {selectedStep.status}
              </span>
            </div>

            <p className="text-gray-300 text-xs leading-relaxed bg-graphite-950 border border-graphite-800 p-3 rounded">
              {selectedStep.description}
            </p>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <div className="bg-graphite-950 border border-graphite-800 p-2.5 rounded">
                <span className="text-gray-500 text-[10px] block">STATION MACHINES</span>
                <span className="text-gray-200 font-bold text-sm">{selectedStep.machinesInStation} CNC / Automation Units</span>
              </div>
              <div className="bg-graphite-950 border border-graphite-800 p-2.5 rounded">
                <span className="text-gray-500 text-[10px] block">QUALITY GATES</span>
                <span className="text-emerald-400 font-bold text-sm">{selectedStep.qualityCheckCount} Dimensional Checks</span>
              </div>
            </div>
          </div>

          {/* Interactive Parameter Tuning Sliders */}
          <div className="lg:col-span-6 bg-graphite-900 border border-graphite-800 rounded p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-graphite-800 pb-2">
              <span className="font-bold text-gray-200 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-cyan-400" />
                INTERACTIVE PROCESS PARAMETER TUNING
              </span>
              <span className="text-[10px] text-gray-400">Updates Digital Twin in real time</span>
            </div>

            <div className="space-y-3 pt-1">
              {/* Parameter 1: Cycle Time */}
              <div className="space-y-1 bg-graphite-950 border border-graphite-800 p-2.5 rounded">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-gray-400">Station Cycle Time (sec):</span>
                  <span className="text-cyan-400 font-bold">{selectedStep.cycleTimeSec} seconds</span>
                </div>
                <input
                  type="range"
                  min={30}
                  max={300}
                  step={5}
                  value={selectedStep.cycleTimeSec}
                  onChange={(e) => handleUpdateParam('cycleTimeSec', Number(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              {/* Parameter 2: Scrap Rate */}
              <div className="space-y-1 bg-graphite-950 border border-graphite-800 p-2.5 rounded">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-gray-400">Scrap Rate Probability (%):</span>
                  <span className="text-rose-400 font-bold">{selectedStep.scrapRatePct}%</span>
                </div>
                <input
                  type="range"
                  min={0.0}
                  max={5.0}
                  step={0.1}
                  value={selectedStep.scrapRatePct}
                  onChange={(e) => handleUpdateParam('scrapRatePct', Number(e.target.value))}
                  className="w-full accent-rose-400 cursor-pointer"
                />
              </div>

              {/* Parameter 3: Cost Per Unit */}
              <div className="space-y-1 bg-graphite-950 border border-graphite-800 p-2.5 rounded">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-gray-400">Operation Cost (USD/Unit):</span>
                  <span className="text-amber-400 font-bold">${selectedStep.costPerUnitUSD}</span>
                </div>
                <input
                  type="range"
                  min={10}
                  max={500}
                  step={5}
                  value={selectedStep.costPerUnitUSD}
                  onChange={(e) => handleUpdateParam('costPerUnitUSD', Number(e.target.value))}
                  className="w-full accent-amber-400 cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
