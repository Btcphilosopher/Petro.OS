'use client';

import React from 'react';
import { EngineConfig, EngineComponentMeta } from '@/types/engine';
import { SimulationOperatingState } from '@/types/physics';
import { MachineAsset } from '@/types/factory';
import { SystemAlert } from '@/types/events';
import EngineViewer3D from '../3d/EngineViewer3D';
import { Activity, AlertTriangle, Cpu, Factory, DollarSign, ShieldCheck, Gauge, Zap, ChevronRight, CheckCircle2 } from 'lucide-react';

interface OverviewScreenProps {
  engineConfig: EngineConfig;
  simState: SimulationOperatingState;
  machines: MachineAsset[];
  alerts: SystemAlert[];
  onAcknowledgeAlert: (alertId: string) => void;
  onNavigateScreen: (screenId: any) => void;
  onSelectComponent: (comp: EngineComponentMeta | null) => void;
}

export default function OverviewScreen({
  engineConfig,
  simState,
  machines,
  alerts,
  onAcknowledgeAlert,
  onNavigateScreen,
  onSelectComponent,
}: OverviewScreenProps) {
  const runningMachinesCount = machines.filter((m) => m.status === 'RUNNING').length;
  const totalMachinesCount = machines.length;
  const warningCount = machines.filter((m) => m.status === 'WARNING' || m.status === 'CRITICAL').length;
  const avgOee = Math.round(machines.reduce((acc, m) => acc + m.oeePct, 0) / (totalMachinesCount || 1));

  return (
    <div className="p-4 space-y-4 overflow-y-auto h-[calc(100vh-50px)] bg-[#0a0a0a] font-mono-tech text-xs">
      {/* SCADA Executive KPI Cards Banner */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
        {/* Card 1: Factory OEE */}
        <div className="bg-[#0d0d0d] border border-[#222] p-3 rounded flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#666] text-[9px] uppercase tracking-wider">
            <span>FACTORY OEE</span>
            <Factory className="w-3.5 h-3.5 text-[#00ff9d]" />
          </div>
          <div className="mt-1.5 flex items-baseline justify-between">
            <span className="text-xl font-bold text-[#00ff9d]">{avgOee}%</span>
            <span className="text-[9px] text-[#00ff9d]/80">Target: 85%</span>
          </div>
        </div>

        {/* Card 2: Shift Production Volume */}
        <div className="bg-[#0d0d0d] border border-[#222] p-3 rounded flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#666] text-[9px] uppercase tracking-wider">
            <span>SHIFT SHIPPED</span>
            <CheckCircle2 className="w-3.5 h-3.5 text-[#00ff9d]" />
          </div>
          <div className="mt-1.5 flex items-baseline justify-between">
            <span className="text-xl font-bold text-[#e0e0e0]">142 <span className="text-xs font-normal text-[#666]">ENG</span></span>
            <span className="text-[9px] text-[#00ff9d]">Takt: 50s</span>
          </div>
        </div>

        {/* Card 3: Unit Manufacturing Cost */}
        <div className="bg-[#0d0d0d] border border-[#222] p-3 rounded flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#666] text-[9px] uppercase tracking-wider">
            <span>UNIT COST</span>
            <DollarSign className="w-3.5 h-3.5 text-amber-500" />
          </div>
          <div className="mt-1.5 flex items-baseline justify-between">
            <span className="text-xl font-bold text-amber-500">$1,482.50</span>
            <span className="text-[9px] text-[#666]">Target: $1.5k</span>
          </div>
        </div>

        {/* Card 4: Quality Process Cpk */}
        <div className="bg-[#0d0d0d] border border-[#222] p-3 rounded flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#666] text-[9px] uppercase tracking-wider">
            <span>BORE CPK</span>
            <ShieldCheck className="w-3.5 h-3.5 text-[#00ff9d]" />
          </div>
          <div className="mt-1.5 flex items-baseline justify-between">
            <span className="text-xl font-bold text-[#00ff9d]">1.62</span>
            <span className="text-[9px] text-[#666]">6-Sigma</span>
          </div>
        </div>

        {/* Card 5: Engine Output Power */}
        <div className="bg-[#0d0d0d] border border-[#222] p-3 rounded flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#666] text-[9px] uppercase tracking-wider">
            <span>DYNO POWER</span>
            <Gauge className="w-3.5 h-3.5 text-rose-400" />
          </div>
          <div className="mt-1.5 flex items-baseline justify-between">
            <span className="text-xl font-bold text-rose-400">{simState.powerKw} <span className="text-xs font-normal text-[#666]">kW</span></span>
            <span className="text-[9px] text-[#666]">{simState.torqueNm} Nm</span>
          </div>
        </div>

        {/* Card 6: Factory Power Demand */}
        <div className="bg-[#0d0d0d] border border-[#222] p-3 rounded flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#666] text-[9px] uppercase tracking-wider">
            <span>POWER LOAD</span>
            <Zap className="w-3.5 h-3.5 text-amber-500" />
          </div>
          <div className="mt-1.5 flex items-baseline justify-between">
            <span className="text-xl font-bold text-amber-500">232.5 <span className="text-xs font-normal text-[#666]">kW</span></span>
            <span className="text-[9px] text-[#666]">42 kWh/eng</span>
          </div>
        </div>

        {/* Card 7: Active SCADA Alerts */}
        <div className="bg-[#0d0d0d] border border-[#222] p-3 rounded flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#666] text-[9px] uppercase tracking-wider">
            <span>ALERTS</span>
            <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
          </div>
          <div className="mt-1.5 flex items-baseline justify-between">
            <span className={`text-xl font-bold ${warningCount > 0 ? 'text-amber-500' : 'text-[#00ff9d]'}`}>
              {warningCount} <span className="text-xs font-normal text-[#666]">CELLS</span>
            </span>
            <span className="text-[9px] text-[#666]">{runningMachinesCount}/{totalMachinesCount} Run</span>
          </div>
        </div>
      </div>

      {/* Main Grid: 3D Viewport & SCADA Telemetry Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 h-[580px]">
        {/* Interactive 3D Engine Preview Canvas */}
        <div className="lg:col-span-7 flex flex-col h-full bg-[#0d0d0d] border border-[#222] rounded p-2">
          <div className="flex items-center justify-between pb-2 border-b border-[#222] mb-2 px-1">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-[#00ff9d]" />
              <span className="font-bold text-[#e0e0e0] uppercase tracking-wider text-[11px]">3D PRODUCT DIGITAL TWIN (LIVE CAD)</span>
            </div>
            <button
              onClick={() => onNavigateScreen('model_3d')}
              className="text-[#00ff9d] hover:underline flex items-center gap-1 text-[10px] uppercase font-bold tracking-wider"
            >
              Full CAD Studio <ChevronRight className="w-3 h-3" />
            </button>
          </div>

          <div className="flex-1 w-full relative bg-[#050505] rounded border border-[#1a1a1a] engineering-grid overflow-hidden">
            <EngineViewer3D
              config={engineConfig}
              rpm={simState.rpm}
              isSimulating={true}
              selectedComponentId={null}
              onSelectComponent={onSelectComponent}
              displayMode="CAD"
            />
          </div>
        </div>

        {/* SCADA Factory Line Status & Live Cylinder Thermodynamics */}
        <div className="lg:col-span-5 flex flex-col gap-3 h-full overflow-y-auto">
          {/* Live Cylinder Thermodynamic Balance Meter */}
          <div className="bg-[#0d0d0d] border border-[#222] rounded p-3 space-y-2">
            <div className="flex items-center justify-between border-b border-[#222] pb-1.5">
              <span className="font-bold text-[#e0e0e0] flex items-center gap-1.5 text-[11px] uppercase tracking-wider">
                <Activity className="w-3.5 h-3.5 text-[#00ff9d]" />
                THERMODYNAMIC BALANCE ({simState.rpm} RPM)
              </span>
              <span className="text-[10px] text-[#00ff9d] font-mono">BMEP: {simState.bmepBar} bar</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[11px]">
              {simState.cylinders.map((cyl) => (
                <div key={cyl.cylinderNumber} className="bg-[#050505] border border-[#222] p-2 rounded space-y-1">
                  <div className="flex justify-between items-center text-[#e0e0e0]">
                    <span className="font-bold text-[#00ff9d]">CYL #{cyl.cylinderNumber}</span>
                    <span className="text-[9px] px-1 rounded bg-[#1a1a1a] text-[#888] font-semibold">{cyl.currentStroke}</span>
                  </div>
                  <div className="flex justify-between text-[#666] text-[10px]">
                    <span>Pressure:</span>
                    <span className="text-[#e0e0e0] font-bold">{Math.round(cyl.pressureBar * 10) / 10} bar</span>
                  </div>
                  <div className="flex justify-between text-[#666] text-[10px]">
                    <span>Temp:</span>
                    <span className="text-amber-500">{cyl.temperatureC} °C</span>
                  </div>
                  {/* Miniature stroke progress bar */}
                  <div className="w-full h-1 bg-[#1a1a1a] rounded overflow-hidden">
                    <div
                      className="h-full bg-[#00ff9d] transition-all duration-300"
                      style={{ width: `${(cyl.crankAngleDeg / 720) * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Machine Telemetry Quick Matrix */}
          <div className="bg-[#0d0d0d] border border-[#222] rounded p-3 space-y-2 flex-1">
            <div className="flex items-center justify-between border-b border-[#222] pb-1.5">
              <span className="font-bold text-[#e0e0e0] flex items-center gap-1.5 text-[11px] uppercase tracking-wider">
                <Factory className="w-3.5 h-3.5 text-[#00ff9d]" />
                MACHINING CENTERS
              </span>
              <button
                onClick={() => onNavigateScreen('machines')}
                className="text-[#00ff9d] text-[10px] uppercase tracking-wider font-bold hover:underline"
              >
                Inspect All
              </button>
            </div>

            <div className="space-y-1.5">
              {machines.slice(0, 4).map((m) => (
                <div
                  key={m.id}
                  onClick={() => onNavigateScreen('machines')}
                  className="bg-[#050505] hover:bg-[#1a1a1a] border border-[#222] p-2 rounded flex items-center justify-between cursor-pointer transition"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <div
                        className={`w-2 h-2 rounded-full ${
                          m.status === 'RUNNING' ? 'bg-[#00ff9d]' : m.status === 'WARNING' ? 'bg-amber-500 animate-pulse' : 'bg-rose-500'
                        }`}
                      />
                      <span className="font-bold text-[#e0e0e0]">{m.id}</span>
                    </div>
                    <span className="text-[10px] text-[#666]">{m.name}</span>
                  </div>

                  <div className="text-right">
                    <div className="text-[#00ff9d] font-bold">OEE: {m.oeePct}%</div>
                    <div className="text-[10px] text-[#666]">Tool Wear: {m.toolWearPct}%</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Real-time SCADA System Alert Stream Banner */}
      <div className="bg-[#0d0d0d] border border-[#222] rounded p-3 space-y-2">
        <div className="flex items-center justify-between border-b border-[#222] pb-1.5">
          <span className="font-bold text-[#e0e0e0] flex items-center gap-2 text-[11px] uppercase tracking-wider">
            <AlertTriangle className="w-4 h-4 text-amber-500" />
            DIGITAL THREAD EVENT STREAM
          </span>
          <span className="text-[10px] text-[#666]">Propagated across factory nodes</span>
        </div>

        <div className="space-y-2">
          {alerts.map((alt) => (
            <div
              key={alt.id}
              className={`p-2.5 rounded border flex flex-wrap items-center justify-between gap-3 ${
                alt.severity === 'WARNING'
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-200'
                  : 'bg-[#050505] border-[#222] text-[#e0e0e0]'
              }`}
            >
              <div className="space-y-0.5 max-w-3xl">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-[#00ff9d]">[{alt.timestamp}]</span>
                  <span className="font-bold text-amber-500">[{alt.assetId}]</span>
                  <span className="font-semibold text-[#e0e0e0]">{alt.message}</span>
                </div>
                <div className="text-[11px] text-[#666]">
                  <strong className="text-[#999]">Cause:</strong> {alt.probableCause} |{' '}
                  <strong className="text-[#999]">Action:</strong> {alt.recommendedAction}
                </div>
              </div>

              <div>
                {!alt.acknowledged ? (
                  <button
                    onClick={() => onAcknowledgeAlert(alt.id)}
                    className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/50 text-amber-400 rounded font-bold text-[10px] uppercase tracking-wider"
                  >
                    Acknowledge
                  </button>
                ) : (
                  <span className="text-[10px] text-[#00ff9d] font-bold px-2 py-0.5 rounded bg-[#00ff9d]/10 border border-[#00ff9d]/30">
                    ACKNOWLEDGED ({alt.acknowledgedBy})
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
