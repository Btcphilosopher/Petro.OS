'use client';

import React from 'react';
import { Settings, User, ShieldCheck, Globe, CheckCircle2 } from 'lucide-react';

interface SettingsScreenProps {
  unitSystem: 'SI' | 'Imperial';
  onChangeUnitSystem: (units: 'SI' | 'Imperial') => void;
}

export default function SettingsScreen({ unitSystem, onChangeUnitSystem }: SettingsScreenProps) {
  return (
    <div className="p-4 space-y-4 overflow-y-auto h-[calc(100vh-50px)] bg-graphite-950 font-mono-tech text-xs">
      <div className="bg-graphite-900 border border-graphite-800 p-3 rounded flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 rounded">
            <Settings className="w-5 h-5" />
          </div>
          <div>
            <span className="font-bold text-gray-100 text-sm">ENTERPRISE SETTINGS & ROLE PERMISSIONS</span>
            <p className="text-gray-400 text-[11px]">System Preferences, Display Units & Access Control</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Unit Preferences */}
        <div className="bg-graphite-900 border border-graphite-800 rounded p-4 space-y-3">
          <span className="font-bold text-gray-200 block border-b border-graphite-800 pb-2 flex items-center gap-2">
            <Globe className="w-4 h-4 text-cyan-400" />
            MEASUREMENT UNIT SYSTEM
          </span>

          <div className="space-y-2 pt-1">
            <button
              onClick={() => onChangeUnitSystem('SI')}
              className={`w-full p-3 rounded text-left border transition flex items-center justify-between ${
                unitSystem === 'SI' ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 font-bold' : 'bg-graphite-950 border-graphite-800 text-gray-400'
              }`}
            >
              <div>
                <div className="text-gray-100 font-bold">SI Metric (mm, bar, kW, Nm, °C, g/kWh)</div>
                <div className="text-[10px] text-gray-500">ISO Standard for Global Automotive Engineering</div>
              </div>
              {unitSystem === 'SI' && <CheckCircle2 className="w-4 h-4 text-cyan-400" />}
            </button>

            <button
              onClick={() => onChangeUnitSystem('Imperial')}
              className={`w-full p-3 rounded text-left border transition flex items-center justify-between ${
                unitSystem === 'Imperial' ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 font-bold' : 'bg-graphite-950 border-graphite-800 text-gray-400'
              }`}
            >
              <div>
                <div className="text-gray-100 font-bold">Imperial / US Customary (in, psi, hp, lb-ft, °F)</div>
                <div className="text-[10px] text-gray-500">US Customary Heavy Equipment Standard</div>
              </div>
              {unitSystem === 'Imperial' && <CheckCircle2 className="w-4 h-4 text-cyan-400" />}
            </button>
          </div>
        </div>

        {/* User Roles */}
        <div className="bg-graphite-900 border border-graphite-800 rounded p-4 space-y-3">
          <span className="font-bold text-gray-200 block border-b border-graphite-800 pb-2 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            ACTIVE USER PROFILE & RBAC ROLE
          </span>

          <div className="bg-graphite-950 border border-graphite-800 p-3 rounded space-y-2">
            <div className="flex justify-between items-center text-gray-200 font-bold">
              <span>Dr. Alex Vance</span>
              <span className="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px]">
                CHIEF MANUFACTURING ENGINEER
              </span>
            </div>
            <p className="text-gray-400 text-[11px]">
              Full Read/Write Access: Tolerance Modification, Process Parameter Tuning, Work Order Generation, Scenario Cloning & Digital Thread Export.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
