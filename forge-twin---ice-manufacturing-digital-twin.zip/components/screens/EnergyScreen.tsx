'use client';

import React from 'react';
import { Zap, Activity, Flame, ShieldAlert, Award } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function EnergyScreen() {
  const energyByStation = [
    { station: 'Block Rough Milling (Grob G550)', energyKwh: 18.5 },
    { station: 'Cylinder Bore Honing (Gehring)', energyKwh: 8.2 },
    { station: 'Crankshaft Grinding & Polishing', energyKwh: 12.4 },
    { station: 'Heat Treatment & Tempering Oven', energyKwh: 24.0 },
    { station: 'High-Pressure Engine Washing', energyKwh: 4.8 },
    { station: 'Assembly Line Automation', energyKwh: 3.5 },
    { station: 'Dyno Hot Testing (AVL)', energyKwh: 14.2 },
  ];

  const totalKwh = energyByStation.reduce((acc, e) => acc + e.energyKwh, 0);
  const co2Kg = totalKwh * 0.42; // Grid carbon factor

  return (
    <div className="p-4 space-y-4 overflow-y-auto h-[calc(100vh-50px)] bg-graphite-950 font-mono-tech text-xs">
      <div className="bg-graphite-900 border border-graphite-800 p-3 rounded flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-amber-500/10 border border-amber-500/30 text-amber-400 rounded">
            <Zap className="w-5 h-5" />
          </div>
          <div>
            <span className="font-bold text-gray-100 text-sm">SUSTAINABILITY & FACTORY ENERGY DIGITAL TWIN</span>
            <p className="text-gray-400 text-[11px]">Real-time Electrical Power Intensity, Peak Demand & Carbon Footprint</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="bg-graphite-950 border border-graphite-800 px-3 py-1.5 rounded">
            <span className="text-gray-400 text-[10px] block">ENERGY PER ENGINE</span>
            <span className="text-amber-400 font-bold">{Math.round(totalKwh * 10) / 10} kWh</span>
          </div>
          <div className="bg-graphite-950 border border-graphite-800 px-3 py-1.5 rounded">
            <span className="text-gray-400 text-[10px] block">CO2 FOOTPRINT</span>
            <span className="text-emerald-400 font-bold">{Math.round(co2Kg * 10) / 10} kg CO2</span>
          </div>
        </div>
      </div>

      <div className="bg-graphite-900 border border-graphite-800 rounded p-4 space-y-3">
        <span className="font-bold text-gray-200 block border-b border-graphite-800 pb-2">
          ELECTRICAL CONSUMPTION BREAKDOWN BY MACHINING STATION (kWh / ENGINE)
        </span>

        <div className="h-[320px] w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={energyByStation}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e232b" />
              <XAxis dataKey="station" stroke="#718096" tick={{ fontSize: 9 }} />
              <YAxis stroke="#718096" tick={{ fontSize: 10 }} unit=" kWh" />
              <Tooltip contentStyle={{ backgroundColor: '#0e1116', borderColor: '#2d3748', fontSize: '11px', fontFamily: 'monospace' }} />
              <Bar dataKey="energyKwh" fill="#f59e0b" name="Energy (kWh)" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
