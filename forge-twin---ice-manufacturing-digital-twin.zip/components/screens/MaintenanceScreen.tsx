'use client';

import React from 'react';
import { MachineAsset } from '@/types/factory';
import { Activity, ShieldAlert, Wrench, Clock, AlertTriangle, CheckCircle2 } from 'lucide-react';

interface MaintenanceScreenProps {
  machines: MachineAsset[];
}

export default function MaintenanceScreen({ machines }: MaintenanceScreenProps) {
  return (
    <div className="p-4 space-y-4 overflow-y-auto h-[calc(100vh-50px)] bg-graphite-950 font-mono-tech text-xs">
      <div className="bg-graphite-900 border border-graphite-800 p-3 rounded flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-amber-500/10 border border-amber-500/30 text-amber-400 rounded">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <span className="font-bold text-gray-100 text-sm">PREDICTIVE MAINTENANCE & REMAINING USEFUL LIFE (RUL) TWIN</span>
            <p className="text-gray-400 text-[11px]">Proactive Failure Prevention & Automated Work Order Generation</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {machines.map((m) => (
          <div key={m.id} className="bg-graphite-900 border border-graphite-800 rounded p-4 space-y-3 flex flex-col justify-between">
            <div className="space-y-2">
              <div className="flex items-center justify-between border-b border-graphite-800 pb-2">
                <span className="font-bold text-gray-100">{m.id}</span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                  m.status === 'RUNNING' ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300' : 'bg-amber-500/20 border-amber-500 text-amber-300'
                }`}>
                  {m.status}
                </span>
              </div>

              <div className="text-gray-300 font-semibold">{m.name}</div>

              <div className="bg-graphite-950 border border-graphite-800 p-2.5 rounded space-y-1 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-gray-400">Tool Wear:</span>
                  <span className={m.toolWearPct > 75 ? 'text-amber-400 font-bold' : 'text-emerald-400'}>{m.toolWearPct}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Vibration RMS:</span>
                  <span className="text-gray-200">{m.vibrationMmS} mm/s</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">RUL Countdown:</span>
                  <span className="text-cyan-400 font-bold">{m.remainingUsefulLifeHours} Hours</span>
                </div>
              </div>

              <div className="bg-graphite-950 border border-graphite-800 p-2.5 rounded text-[11px] text-gray-300">
                <strong className="text-amber-400 block mb-0.5">DIAGNOSIS:</strong>
                {m.healthDiagnosis}
              </div>
            </div>

            <button className="w-full py-1.5 bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/50 text-amber-300 rounded font-bold text-xs transition flex items-center justify-center gap-1">
              <Wrench className="w-3.5 h-3.5" /> Trigger Work Order
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
