'use client';

import React from 'react';
import { EngineConfig, EngineType } from '@/types/engine';
import { Play, Pause, RotateCcw, FastForward, Activity, AlertTriangle, ShieldCheck, Flame } from 'lucide-react';
import { SystemAlert } from '@/types/events';

interface HeaderProps {
  engineConfig: EngineConfig;
  onChangeEngineType: (type: EngineType) => void;
  rpm: number;
  onChangeRpm: (rpm: number) => void;
  isSimulating: boolean;
  onToggleSimulate: () => void;
  onResetSimulate: () => void;
  simSpeed: number;
  onChangeSimSpeed: (speed: number) => void;
  alerts: SystemAlert[];
  unitSystem: 'SI' | 'Imperial';
  onChangeUnitSystem: (units: 'SI' | 'Imperial') => void;
}

export default function Header({
  engineConfig,
  onChangeEngineType,
  rpm,
  onChangeRpm,
  isSimulating,
  onToggleSimulate,
  onResetSimulate,
  simSpeed,
  onChangeSimSpeed,
  alerts,
  unitSystem,
  onChangeUnitSystem,
}: HeaderProps) {
  const unackAlertsCount = alerts.filter((a) => !a.acknowledged).length;

  return (
    <header className="w-full bg-[#0d0d0d] border-b border-[#222] px-6 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs font-mono-tech sticky top-0 z-50">
      {/* Brand Identity */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded bg-[#1a1a1a] border border-[#00ff9d]/50 flex items-center flex-shrink-0 justify-center text-[#00ff9d] font-bold text-xs tracking-wider">
            FT
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-[#00ff9d] tracking-[0.2em] text-xs uppercase">FORGE TWIN</span>
              <span className="bg-[#1a1a1a] text-[#00ff9d] border border-[#00ff9d]/30 px-1.5 py-0.2 text-[9px] rounded uppercase font-mono tracking-wider">
                ICE DIGITAL THREAD
              </span>
            </div>
            <p className="text-[10px] text-[#666] hidden sm:block">From raw material to combustion — continuous digital thread.</p>
          </div>
        </div>
      </div>

      {/* Engine Architecture Switcher & Engine Speed Controls */}
      <div className="flex items-center gap-3 bg-[#0a0a0a] border border-[#222] px-3 py-1.5 rounded">
        {/* Engine Configuration Preset Dropdown */}
        <div className="flex items-center gap-1.5">
          <span className="text-[#666] text-[9px] uppercase tracking-widest font-bold">CONFIG:</span>
          <select
            value={engineConfig.type}
            onChange={(e) => onChangeEngineType(e.target.value as EngineType)}
            className="bg-[#141414] text-[#e0e0e0] border border-[#333] rounded px-2 py-0.5 text-xs focus:outline-none focus:border-[#00ff9d] font-mono-tech cursor-pointer"
          >
            <option value="I4">2.0L Inline-4 DOHC</option>
            <option value="I6">3.0L Inline-6 DOHC</option>
            <option value="V6">3.5L V6 Twin-Turbo</option>
            <option value="V8">4.0L V8 Twin-Turbo</option>
          </select>
        </div>

        <div className="h-4 w-[1px] bg-[#222]" />

        {/* Engine RPM Speed Slider */}
        <div className="flex items-center gap-2">
          <span className="text-[#666] text-[9px] uppercase tracking-widest font-bold">RPM:</span>
          <input
            type="range"
            min={600}
            max={8500}
            step={100}
            value={rpm}
            onChange={(e) => onChangeRpm(Number(e.target.value))}
            className="w-24 accent-[#00ff9d] cursor-pointer"
          />
          <span className="text-[#00ff9d] font-bold min-w-[55px] text-right font-mono text-xs">{rpm} RPM</span>
        </div>
      </div>

      {/* Simulation Engine Controls */}
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1 bg-[#0a0a0a] border border-[#222] p-1 rounded">
          <button
            onClick={onToggleSimulate}
            className={`px-3 py-1 rounded flex items-center gap-1 transition text-[10px] uppercase font-bold tracking-tighter ${
              isSimulating
                ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                : 'bg-[#00ff9d] text-black border border-[#00ff9d] hover:bg-[#00e68d]'
            }`}
            title={isSimulating ? 'Pause Simulation' : 'Run Simulation'}
          >
            {isSimulating ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3 fill-black" />}
            <span>{isSimulating ? 'PAUSE' : 'RUN'}</span>
          </button>

          <button
            onClick={onResetSimulate}
            className="px-2.5 py-1 bg-[#1a1a1a] border border-[#333] text-[10px] uppercase font-bold tracking-tighter text-[#e0e0e0] hover:bg-[#222] rounded flex items-center gap-1"
            title="Reset Simulation State"
          >
            <RotateCcw className="w-3 h-3" />
            <span>RESET</span>
          </button>

          <div className="flex items-center gap-1 pl-1 text-[10px] text-[#666]">
            <span className="tracking-widest">SPEED:</span>
            {[1, 5, 20].map((s) => (
              <button
                key={s}
                onClick={() => onChangeSimSpeed(s)}
                className={`px-1.5 py-0.5 rounded text-[10px] font-mono ${
                  simSpeed === s ? 'bg-[#1a1a1a] text-[#00ff9d] border border-[#00ff9d]/40 font-bold' : 'hover:text-white'
                }`}
              >
                {s}x
              </button>
            ))}
          </div>
        </div>

        {/* Units Toggle */}
        <button
          onClick={() => onChangeUnitSystem(unitSystem === 'SI' ? 'Imperial' : 'SI')}
          className="bg-[#1a1a1a] border border-[#333] hover:border-[#00ff9d]/50 text-[#e0e0e0] px-2.5 py-1 rounded text-[10px] font-mono tracking-tighter uppercase font-bold"
        >
          UNITS: <span className="text-[#00ff9d]">{unitSystem}</span>
        </button>

        {/* Live System Status Indicator */}
        <div className="flex items-center gap-2 px-3 py-1 bg-[#0a0a0a] border border-[#222] rounded">
          <div className={`w-2 h-2 rounded-full ${unackAlertsCount > 0 ? 'bg-amber-500 animate-pulse' : 'bg-[#00ff9d] animate-pulse'}`} />
          <span className={`text-[10px] font-mono font-bold ${unackAlertsCount > 0 ? 'text-amber-400' : 'text-[#00ff9d]'}`}>
            {unackAlertsCount > 0 ? `${unackAlertsCount} ALERTS` : 'SYSTEM: NOMINAL'}
          </span>
        </div>
      </div>
    </header>
  );
}
