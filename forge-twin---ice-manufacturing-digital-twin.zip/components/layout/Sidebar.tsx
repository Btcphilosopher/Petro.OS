'use client';

import React from 'react';
import {
  LayoutDashboard,
  Cpu,
  Box,
  Workflow,
  Factory,
  ShieldCheck,
  Server,
  Wrench,
  Gauge,
  LineChart,
  DollarSign,
  Zap,
  Activity,
  GitBranch,
  Network,
  FileSpreadsheet,
  Settings,
} from 'lucide-react';

export type ScreenId =
  | 'overview'
  | 'engine_twin'
  | 'model_3d'
  | 'manufacturing'
  | 'factory'
  | 'quality'
  | 'machines'
  | 'assembly'
  | 'test_cell'
  | 'performance'
  | 'cost'
  | 'energy'
  | 'maintenance'
  | 'scenarios'
  | 'digital_thread'
  | 'audit_log'
  | 'settings';

interface SidebarProps {
  activeScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
}

const NAV_ITEMS: { id: ScreenId; label: string; icon: React.ComponentType<{ className?: string }>; category: string }[] = [
  { id: 'overview', label: 'OVERVIEW', icon: LayoutDashboard, category: 'SYSTEM' },
  { id: 'engine_twin', label: 'ENGINE TWIN', icon: Cpu, category: 'PRODUCT' },
  { id: 'model_3d', label: '3D CAD MODEL', icon: Box, category: 'PRODUCT' },
  { id: 'performance', label: 'PERFORMANCE MAPS', icon: LineChart, category: 'PRODUCT' },
  { id: 'manufacturing', label: 'MANUFACTURING', icon: Workflow, category: 'FACTORY' },
  { id: 'factory', label: 'VIRTUAL FACTORY', icon: Factory, category: 'FACTORY' },
  { id: 'machines', label: 'MACHINES & TELEMETRY', icon: Server, category: 'FACTORY' },
  { id: 'assembly', label: 'ASSEMBLY & TORQUE', icon: Wrench, category: 'FACTORY' },
  { id: 'test_cell', label: 'TEST CELL (DYNO)', icon: Gauge, category: 'FACTORY' },
  { id: 'quality', label: 'QUALITY & SPC', icon: ShieldCheck, category: 'ANALYTICS' },
  { id: 'maintenance', label: 'PREDICTIVE HEALTH', icon: Activity, category: 'ANALYTICS' },
  { id: 'cost', label: 'COST ENGINE', icon: DollarSign, category: 'ANALYTICS' },
  { id: 'energy', label: 'ENERGY DIGITAL TWIN', icon: Zap, category: 'ANALYTICS' },
  { id: 'scenarios', label: 'SCENARIOS (WHAT-IF)', icon: GitBranch, category: 'SIMULATION' },
  { id: 'digital_thread', label: 'DIGITAL THREAD', icon: Network, category: 'DATA' },
  { id: 'audit_log', label: 'AUDIT LOG', icon: FileSpreadsheet, category: 'DATA' },
  { id: 'settings', label: 'SETTINGS & ROLES', icon: Settings, category: 'DATA' },
];

export default function Sidebar({ activeScreen, onNavigate }: SidebarProps) {
  return (
    <aside className="w-56 bg-[#0d0d0d] border-r border-[#222] flex flex-col justify-between h-[calc(100vh-49px)] shrink-0 select-none font-sans">
      {/* Top Header Identity */}
      <div className="p-5 border-b border-[#222]">
        <h1 className="text-xs font-bold tracking-[0.2em] text-[#00ff9d] uppercase">Forge Twin</h1>
        <p className="text-[10px] text-[#666] mt-1">ICE Digital Thread Platform</p>
      </div>

      {/* Scrollable Navigation List */}
      <div className="overflow-y-auto py-3 space-y-3 flex-1">
        {['SYSTEM', 'PRODUCT', 'FACTORY', 'ANALYTICS', 'SIMULATION', 'DATA'].map((cat) => {
          const items = NAV_ITEMS.filter((item) => item.category === cat);
          if (items.length === 0) return null;

          return (
            <div key={cat} className="space-y-0.5">
              <div className="px-4 text-[9px] uppercase font-bold text-[#666] tracking-[0.2em] mb-1">
                {cat}
              </div>

              {items.map((item) => {
                const Icon = item.icon;
                const isActive = activeScreen === item.id;

                return (
                  <button
                    key={item.id}
                    onClick={() => onNavigate(item.id)}
                    className={`w-full flex items-center gap-2.5 px-4 py-2 text-xs transition text-left cursor-pointer ${
                      isActive
                        ? 'bg-[#1a1a1a] border-l-2 border-[#00ff9d] text-white font-medium'
                        : 'text-[#666] hover:text-white hover:bg-[#141414] border-l-2 border-transparent'
                    }`}
                  >
                    <Icon className={`w-3.5 h-3.5 flex-shrink-0 ${isActive ? 'text-[#00ff9d]' : 'text-[#666]'}`} />
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}
            </div>
          );
        })}
      </div>

      {/* Footer System Health Tag */}
      <div className="p-4 border-t border-[#222] bg-[#0d0d0d] font-mono text-[10px]">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-[#00ff9d] animate-pulse"></div>
          <span className="text-[10px] font-mono text-[#00ff9d]">SYSTEM: NOMINAL</span>
        </div>
        <div className="text-[9px] text-[#555] mt-1 truncate">ID: ICE-V8-2026-0001842</div>
      </div>
    </aside>
  );
}
