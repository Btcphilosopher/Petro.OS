'use client';

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { EngineConfig, EngineComponentMeta } from '@/types/engine';
import { DEFAULT_COMPONENTS_META } from '@/lib/simulation/defaults';
import { Layers, RotateCcw, Eye, Flame, ShieldAlert, Cpu, Sparkles, Box } from 'lucide-react';

export type DisplayMode = 'CAD' | 'SECTION' | 'HEATMAP' | 'STRESS' | 'TOLERANCE' | 'MFG_STAGE';

interface EngineViewer3DProps {
  config: EngineConfig;
  rpm: number;
  isSimulating: boolean;
  selectedComponentId: string | null;
  onSelectComponent: (comp: EngineComponentMeta | null) => void;
  displayMode?: DisplayMode;
  explodedFactor?: number; // 0 to 1
  sectionCut?: boolean;
}

export default function EngineViewer3D({
  config,
  rpm,
  isSimulating,
  selectedComponentId,
  onSelectComponent,
  displayMode = 'CAD',
  explodedFactor = 0,
  sectionCut = false,
}: EngineViewer3DProps) {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);

  // Group references for animation & exploded view
  const engineGroupRef = useRef<THREE.Group | null>(null);
  const blockGroupRef = useRef<THREE.Group | null>(null);
  const headGroupRef = useRef<THREE.Group | null>(null);
  const crankGroupRef = useRef<THREE.Group | null>(null);
  const pistonsGroupRef = useRef<THREE.Group[]>([]);
  const rodsGroupRef = useRef<THREE.Group[]>([]);
  const valvetrainGroupRef = useRef<THREE.Group | null>(null);

  const [activeComponentMeta, setActiveComponentMeta] = useState<EngineComponentMeta | null>(DEFAULT_COMPONENTS_META[0]);

  // Orbit control state variables
  const isDragging = useRef(false);
  const previousMousePosition = useRef({ x: 0, y: 0 });
  const rotationAngle = useRef({ x: 0.3, y: 0.8 });
  const cameraDistance = useRef(420);

  // Crank angle state
  const crankAngleDeg = useRef(0);

  // Helper to construct detailed CAD geometries
  function buildProceduralEngineMesh(parentGroup: THREE.Group, cfg: EngineConfig, mode: DisplayMode) {
    pistonsGroupRef.current = [];
    rodsGroupRef.current = [];

    // Material color schemes based on DisplayMode
    const getMaterial = (baseHex: number, opacity: number = 1.0) => {
      let colorHex = baseHex;
      if (mode === 'HEATMAP') {
        colorHex = baseHex === 0x4a5568 ? 0xe53e3e : baseHex === 0x718096 ? 0xdd6b20 : 0x00ff9d;
      } else if (mode === 'STRESS') {
        colorHex = baseHex === 0x4a5568 ? 0xd69e2e : baseHex === 0x2b6cb0 ? 0xe53e3e : 0x00ff9d;
      } else if (mode === 'TOLERANCE') {
        colorHex = 0x00ff9d; // Green (in spec)
      }

      return new THREE.MeshStandardMaterial({
        color: colorHex,
        metalness: mode === 'CAD' ? 0.8 : 0.2,
        roughness: mode === 'CAD' ? 0.3 : 0.6,
        wireframe: mode === 'MFG_STAGE' ? true : false,
        transparent: opacity < 1.0 || sectionCut,
        opacity: sectionCut ? 0.4 : opacity,
      });
    };

    const blockMat = getMaterial(0x3a424e); // Dark cast aluminum
    const headMat = getMaterial(0x5a6578);  // Machined aluminum head
    const crankMat = getMaterial(0x8a99ad); // Forged steel
    const pistonMat = getMaterial(0xa0aec0); // Polished aluminum piston crown
    const rodMat = getMaterial(0x718096);    // Steel rod
    const valveMat = getMaterial(0x00ff9d);  // Valve guides

    const cylCount = cfg.cylinderCount;
    const boreR = (cfg.boreMm / 2) * 1.1; // visual scale factor
    const spacing = cfg.block.cylinderSpacingMm * 1.1;
    const startX = -((cylCount - 1) * spacing) / 2;

    // 1. ENGINE BLOCK
    const blockGroup = new THREE.Group();
    blockGroupRef.current = blockGroup;
    parentGroup.add(blockGroup);

    // Main Block Body Box
    const blockWidth = cylCount * spacing + 40;
    const blockBodyGeo = new THREE.BoxGeometry(blockWidth, 140, 150);
    const blockBodyMesh = new THREE.Mesh(blockBodyGeo, blockMat);
    blockBodyMesh.position.set(0, 0, 0);
    blockGroup.add(blockBodyMesh);

    // Cylinder Bores
    for (let i = 0; i < cylCount; i++) {
      const xPos = startX + i * spacing;
      const boreCylinderGeo = new THREE.CylinderGeometry(boreR, boreR, 142, 32);
      const boreCylinderMat = new THREE.MeshStandardMaterial({
        color: mode === 'CAD' ? 0x111111 : 0xe53e3e,
        metalness: 0.9,
        roughness: 0.1,
      });
      const boreMesh = new THREE.Mesh(boreCylinderGeo, boreCylinderMat);
      boreMesh.position.set(xPos, 0, 0);
      blockGroup.add(boreMesh);
    }

    // 2. CYLINDER HEAD
    const headGroup = new THREE.Group();
    headGroupRef.current = headGroup;
    headGroup.position.set(0, 110, 0);
    parentGroup.add(headGroup);

    const headGeo = new THREE.BoxGeometry(blockWidth, 70, 150);
    const headMesh = new THREE.Mesh(headGeo, headMat);
    headGroup.add(headMesh);

    // Valvetrain (Camshafts & Valves)
    const valvetrainGroup = new THREE.Group();
    valvetrainGroupRef.current = valvetrainGroup;
    valvetrainGroup.position.set(0, 45, 0);
    headGroup.add(valvetrainGroup);

    // Dual Overhead Camshafts (DOHC)
    const camGeo = new THREE.CylinderGeometry(8, 8, blockWidth - 20, 16);
    camGeo.rotateZ(Math.PI / 2);

    const cam1 = new THREE.Mesh(camGeo, crankMat);
    cam1.position.set(0, 15, -35);
    valvetrainGroup.add(cam1);

    const cam2 = new THREE.Mesh(camGeo, crankMat);
    cam2.position.set(0, 15, 35);
    valvetrainGroup.add(cam2);

    // Valves per cylinder
    for (let i = 0; i < cylCount; i++) {
      const xPos = startX + i * spacing;
      for (let v = 0; v < 4; v++) {
        const valveStemGeo = new THREE.CylinderGeometry(3, 12, 45, 16);
        const valveMesh = new THREE.Mesh(valveStemGeo, valveMat);
        const zOffset = v < 2 ? -25 : 25;
        const xOffset = (v % 2 === 0 ? -12 : 12);
        valveMesh.position.set(xPos + xOffset, -10, zOffset);
        valvetrainGroup.add(valveMesh);
      }
    }

    // 3. CRANKSHAFT
    const crankGroup = new THREE.Group();
    crankGroupRef.current = crankGroup;
    crankGroup.position.set(0, -60, 0);
    parentGroup.add(crankGroup);

    // Main shaft axis
    const mainShaftGeo = new THREE.CylinderGeometry(14, 14, blockWidth + 20, 24);
    mainShaftGeo.rotateZ(Math.PI / 2);
    const mainShaftMesh = new THREE.Mesh(mainShaftGeo, crankMat);
    crankGroup.add(mainShaftMesh);

    // Crank Counterweights & Journal Throws
    const crankR = cfg.strokeMm / 2;
    for (let i = 0; i < cylCount; i++) {
      const xPos = startX + i * spacing;
      const throwAngle = (i * (720 / cylCount) * Math.PI) / 180;

      // Counterweight lobe
      const counterweightGeo = new THREE.BoxGeometry(18, 55, 45);
      const cwMesh = new THREE.Mesh(counterweightGeo, crankMat);
      cwMesh.position.set(xPos, -Math.cos(throwAngle) * 15, Math.sin(throwAngle) * 15);
      crankGroup.add(cwMesh);

      // Rod journal offset
      const journalGeo = new THREE.CylinderGeometry(12, 12, 22, 16);
      journalGeo.rotateZ(Math.PI / 2);
      const journalMesh = new THREE.Mesh(journalGeo, crankMat);
      journalMesh.position.set(xPos, Math.sin(throwAngle) * crankR, Math.cos(throwAngle) * crankR);
      crankGroup.add(journalMesh);
    }

    // 4. PISTONS & CONNECTING RODS
    for (let i = 0; i < cylCount; i++) {
      const xPos = startX + i * spacing;

      // Piston Assembly Group
      const pistonGrp = new THREE.Group();
      pistonGrp.position.set(xPos, 80, 0);
      parentGroup.add(pistonGrp);
      pistonsGroupRef.current.push(pistonGrp);

      // Piston Crown
      const pistonGeo = new THREE.CylinderGeometry(boreR - 2, boreR - 2, 42, 32);
      const pistonMesh = new THREE.Mesh(pistonGeo, pistonMat);
      pistonGrp.add(pistonMesh);

      // Piston Ring Grooves
      for (let r = 0; r < 3; r++) {
        const ringGeo = new THREE.TorusGeometry(boreR - 1.5, 1.2, 8, 32);
        ringGeo.rotateX(Math.PI / 2);
        const ringMesh = new THREE.Mesh(ringGeo, valveMat);
        ringMesh.position.y = 12 - r * 6;
        pistonGrp.add(ringMesh);
      }

      // Connecting Rod Group
      const rodGrp = new THREE.Group();
      rodGrp.position.set(xPos, 80, 0);
      parentGroup.add(rodGrp);
      rodsGroupRef.current.push(rodGrp);

      const rodBeamGeo = new THREE.BoxGeometry(12, cfg.connectingRod.lengthMm * 0.7, 18);
      const rodMesh = new THREE.Mesh(rodBeamGeo, rodMat);
      rodMesh.position.y = -cfg.connectingRod.lengthMm * 0.35;
      rodGrp.add(rodMesh);
    }
  }

  useEffect(() => {
    if (!mountRef.current) return;

    const width = mountRef.current.clientWidth;
    const height = mountRef.current.clientHeight;

    // 1. Scene Setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0a0a);
    sceneRef.current = scene;

    // Grid helper
    const gridHelper = new THREE.GridHelper(600, 30, 0x00ff9d, 0x222222);
    gridHelper.position.y = -120;
    scene.add(gridHelper);

    // 2. Camera Setup
    const camera = new THREE.PerspectiveCamera(45, width / height, 1, 2000);
    camera.position.set(0, 100, cameraDistance.current);
    cameraRef.current = camera;

    // 3. Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight1.position.set(200, 400, 300);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x38bdf8, 0.6);
    dirLight2.position.set(-200, -100, -200);
    scene.add(dirLight2);

    // 4. Renderer Setup
    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    rendererRef.current = renderer;

    mountRef.current.innerHTML = '';
    mountRef.current.appendChild(renderer.domElement);

    // 5. Build Procedural Engine CAD Mesh Hierarchy
    const engineGroup = new THREE.Group();
    engineGroupRef.current = engineGroup;
    scene.add(engineGroup);

    buildProceduralEngineMesh(engineGroup, config, displayMode);

    // Animation Loop
    let animationFrameId: number;
    let lastTime = performance.now();

    const animate = (currentTime: number) => {
      animationFrameId = requestAnimationFrame(animate);
      const deltaTime = (currentTime - lastTime) / 1000;
      lastTime = currentTime;

      // Update Engine Animation (Crankshaft & Piston Kinematics)
      if (isSimulating && rpm > 0) {
        const dAngle = (rpm * 360 * deltaTime) / 60;
        crankAngleDeg.current = (crankAngleDeg.current + dAngle) % 720;
      }

      const crankRad = (crankAngleDeg.current * Math.PI) / 180;

      // Rotate Crankshaft
      if (crankGroupRef.current) {
        crankGroupRef.current.rotation.z = -crankRad;
      }

      // Kinematic Piston & Connecting Rod Reciprocation
      const strokeMm = config.strokeMm;
      const rodLenMm = config.connectingRod.lengthMm;
      const crankR = strokeMm / 2;

      pistonsGroupRef.current.forEach((pistonGrp, i) => {
        const cylOffset = (i * (720 / config.cylinderCount)) * (Math.PI / 180);
        const theta = crankRad + cylOffset;
        
        // Piston Position x(theta)
        const lambda = crankR / rodLenMm;
        const sinT = Math.sin(theta);
        const cosT = Math.cos(theta);
        const sqrtTerm = Math.sqrt(Math.max(0, 1 - Math.pow(lambda * sinT, 2)));
        const pistonPosMm = crankR * (1 - cosT) + rodLenMm * (1 - sqrtTerm);

        // Position Piston
        pistonGrp.position.y = 80 - pistonPosMm;

        // Position Connecting Rod & Rotate according to angle phi
        if (rodsGroupRef.current[i]) {
          const rodGrp = rodsGroupRef.current[i];
          const phiRad = Math.asin(lambda * sinT);
          rodGrp.position.y = 80 - pistonPosMm;
          rodGrp.rotation.z = phiRad;
        }
      });

      // Update Camera Orbit Position
      if (cameraRef.current) {
        cameraRef.current.position.x = cameraDistance.current * Math.sin(rotationAngle.current.y) * Math.cos(rotationAngle.current.x);
        cameraRef.current.position.y = cameraDistance.current * Math.sin(rotationAngle.current.x) + 40;
        cameraRef.current.position.z = cameraDistance.current * Math.cos(rotationAngle.current.y) * Math.cos(rotationAngle.current.x);
        cameraRef.current.lookAt(0, 20, 0);
      }

      renderer.render(scene, camera);
    };

    animate(performance.now());

    // Resize Observer
    const resizeObserver = new ResizeObserver(() => {
      if (!mountRef.current || !rendererRef.current || !cameraRef.current) return;
      const newW = mountRef.current.clientWidth;
      const newH = mountRef.current.clientHeight;
      cameraRef.current.aspect = newW / newH;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(newW, newH);
    });
    resizeObserver.observe(mountRef.current);

    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      if (rendererRef.current && rendererRef.current.domElement) {
        rendererRef.current.domElement.remove();
      }
    };
  }, [config, displayMode]);

  // Update Exploded View positions smoothly
  useEffect(() => {
    const factor = explodedFactor;
    if (headGroupRef.current) {
      headGroupRef.current.position.y = 120 + factor * 120;
    }
    if (blockGroupRef.current) {
      blockGroupRef.current.position.y = 0;
    }
    if (crankGroupRef.current) {
      crankGroupRef.current.position.y = -80 - factor * 90;
    }
    if (valvetrainGroupRef.current) {
      valvetrainGroupRef.current.position.y = 180 + factor * 180;
    }
  }, [explodedFactor]);

  // Handle Mouse / Touch Orbit Controls
  const handleMouseDown = (e: React.MouseEvent) => {
    isDragging.current = true;
    previousMousePosition.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging.current) return;
    const deltaX = e.clientX - previousMousePosition.current.x;
    const deltaY = e.clientY - previousMousePosition.current.y;

    rotationAngle.current.y += deltaX * 0.008;
    rotationAngle.current.x = Math.max(-1.4, Math.min(1.4, rotationAngle.current.x + deltaY * 0.008));

    previousMousePosition.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDragging.current = false;
  };

  const handleWheel = (e: React.WheelEvent) => {
    cameraDistance.current = Math.max(120, Math.min(800, cameraDistance.current + e.deltaY * 0.4));
  };

  // Handle component click
  const handleComponentClick = (compMeta: EngineComponentMeta) => {
    setActiveComponentMeta(compMeta);
    onSelectComponent(compMeta);
  };

  return (
    <div className="relative w-full h-full min-h-[500px] bg-graphite-950 border border-graphite-800 rounded-lg overflow-hidden flex flex-col">
      {/* 3D WebGL Canvas Viewport */}
      <div
        ref={mountRef}
        className="w-full h-full cursor-grab active:cursor-grabbing flex-1"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onWheel={handleWheel}
      />

      {/* Top HUD Engineering Control Overlay */}
      <div className="absolute top-3 left-3 right-3 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
        {/* Mode Selector Badges */}
        <div className="flex items-center gap-1 bg-graphite-900/90 backdrop-blur border border-graphite-700 p-1 rounded text-xs pointer-events-auto">
          <span className="text-gray-4 shadow-none font-mono-tech px-2 py-0.5 text-[10px] uppercase text-cyan-accent font-semibold flex items-center gap-1">
            <Cpu className="w-3.5 h-3.5" /> 3D CAD ENGINE TWIN
          </span>
          <div className="h-4 w-[1px] bg-graphite-700 my-auto" />
          <button
            onClick={() => onSelectComponent(DEFAULT_COMPONENTS_META[0])}
            className={`px-2 py-1 rounded transition text-xs font-mono-tech flex items-center gap-1 ${
              displayMode === 'CAD' ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40' : 'text-gray-400 hover:text-white'
            }`}
          >
            <Box className="w-3 h-3" /> CAD Solid
          </button>
          <button
            onClick={() => onSelectComponent(DEFAULT_COMPONENTS_META[0])}
            className={`px-2 py-1 rounded transition text-xs font-mono-tech flex items-center gap-1 ${
              displayMode === 'HEATMAP' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' : 'text-gray-400 hover:text-white'
            }`}
          >
            <Flame className="w-3 h-3" /> Thermal Map
          </button>
          <button
            onClick={() => onSelectComponent(DEFAULT_COMPONENTS_META[2])}
            className={`px-2 py-1 rounded transition text-xs font-mono-tech flex items-center gap-1 ${
              displayMode === 'STRESS' ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40' : 'text-gray-400 hover:text-white'
            }`}
          >
            <ShieldAlert className="w-3 h-3" /> FEA Stress
          </button>
        </div>

        {/* View Angles Quick Reset */}
        <div className="flex items-center gap-1 bg-graphite-900/90 backdrop-blur border border-graphite-700 p-1 rounded text-xs pointer-events-auto">
          <button
            onClick={() => {
              rotationAngle.current = { x: 0.3, y: 0.8 };
              cameraDistance.current = 420;
            }}
            className="px-2 py-1 bg-graphite-800 hover:bg-graphite-700 text-gray-300 rounded text-xs font-mono-tech flex items-center gap-1"
          >
            <RotateCcw className="w-3 h-3" /> Reset ISO View
          </button>
        </div>
      </div>

      {/* Bottom Component Selection & Metadata Cards Overlay */}
      <div className="absolute bottom-3 left-3 right-3 flex flex-wrap items-end justify-between gap-3 pointer-events-none">
        {/* Component Selector Tabs */}
        <div className="flex flex-wrap items-center gap-1.5 bg-graphite-900/95 border border-graphite-700 p-1.5 rounded pointer-events-auto max-w-2xl">
          {DEFAULT_COMPONENTS_META.map((comp) => (
            <button
              key={comp.id}
              onClick={() => handleComponentClick(comp)}
              className={`px-2.5 py-1 text-xs rounded font-mono-tech transition ${
                activeComponentMeta?.id === comp.id
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 font-bold'
                  : 'bg-graphite-800 text-gray-400 hover:text-white hover:bg-graphite-700'
              }`}
            >
              {comp.name}
            </button>
          ))}
        </div>

        {/* Active Component Telemetry Card */}
        {activeComponentMeta && (
          <div className="bg-graphite-900/95 border border-graphite-700 p-3 rounded-lg pointer-events-auto max-w-md w-full shadow-xl">
            <div className="flex items-center justify-between pb-2 border-b border-graphite-800">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-emerald-400 animate-scada-pulse" />
                <span className="font-mono-tech text-xs text-cyan-400 font-bold">{activeComponentMeta.partNumber}</span>
              </div>
              <span className="text-[11px] px-1.5 py-0.5 rounded bg-graphite-800 text-gray-300 font-mono-tech">
                {activeComponentMeta.simulatedCondition}
              </span>
            </div>

            <div className="mt-2 grid grid-cols-2 gap-2 text-xs font-mono-tech">
              <div>
                <span className="text-gray-500 text-[10px] block">NAME</span>
                <span className="text-gray-200 font-medium">{activeComponentMeta.name}</span>
              </div>
              <div>
                <span className="text-gray-500 text-[10px] block">MATERIAL</span>
                <span className="text-gray-200 font-medium">{activeComponentMeta.material.name}</span>
              </div>
              <div>
                <span className="text-gray-500 text-[10px] block">NOMINAL / TOLERANCE</span>
                <span className="text-gray-200">{activeComponentMeta.nominalDimensionMm}mm {activeComponentMeta.toleranceClass}</span>
              </div>
              <div>
                <span className="text-gray-500 text-[10px] block">QUALITY CPK</span>
                <span className="text-emerald-400 font-bold">{activeComponentMeta.qualityCpk}</span>
              </div>
              <div>
                <span className="text-gray-500 text-[10px] block">PRIMARY MFG PROCESS</span>
                <span className="text-gray-300 text-[11px]">{activeComponentMeta.primaryMachiningProcess}</span>
              </div>
              <div>
                <span className="text-gray-500 text-[10px] block">MASS / UNIT COST</span>
                <span className="text-gray-300">{activeComponentMeta.massKg}kg / ${activeComponentMeta.unitCostUSD}</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
