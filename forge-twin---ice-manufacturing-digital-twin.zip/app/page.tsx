'use client';

import React, { useState, useEffect, useRef } from 'react';
import Header from '@/components/layout/Header';
import Sidebar, { ScreenId } from '@/components/layout/Sidebar';

// Screens
import OverviewScreen from '@/components/screens/OverviewScreen';
import EngineTwinScreen from '@/components/screens/EngineTwinScreen';
import Model3DScreen from '@/components/screens/Model3DScreen';
import ManufacturingScreen from '@/components/screens/ManufacturingScreen';
import FactoryScreen from '@/components/screens/FactoryScreen';
import QualityScreen from '@/components/screens/QualityScreen';
import MachinesScreen from '@/components/screens/MachinesScreen';
import AssemblyScreen from '@/components/screens/AssemblyScreen';
import TestCellScreen from '@/components/screens/TestCellScreen';
import PerformanceScreen from '@/components/screens/PerformanceScreen';
import CostScreen from '@/components/screens/CostScreen';
import EnergyScreen from '@/components/screens/EnergyScreen';
import MaintenanceScreen from '@/components/screens/MaintenanceScreen';
import ScenariosScreen from '@/components/screens/ScenariosScreen';
import DigitalThreadScreen from '@/components/screens/DigitalThreadScreen';
import AuditLogScreen from '@/components/screens/AuditLogScreen';
import SettingsScreen from '@/components/screens/SettingsScreen';

// Types & Simulation
import { EngineConfig, EngineType, EngineComponentMeta } from '@/types/engine';
import {
  DEFAULT_ENGINE_CONFIG,
  DEFAULT_PRESET_CONFIGS,
  DEFAULT_MACHINES,
  DEFAULT_ALERTS,
} from '@/lib/simulation/defaults';
import { calculateEngineCycle } from '@/lib/simulation/icePhysicsEngine';
import { SimulationOperatingState } from '@/types/physics';
import { MachineAsset } from '@/types/factory';
import { SystemAlert } from '@/types/events';

export default function HomePage() {
  const [activeScreen, setActiveScreen] = useState<ScreenId>('overview');
  const [engineConfig, setEngineConfig] = useState<EngineConfig>(DEFAULT_ENGINE_CONFIG);
  const [rpm, setRpm] = useState<number>(3500);
  const [throttlePct, setThrottlePct] = useState<number>(100);
  const [isSimulating, setIsSimulating] = useState<boolean>(true);
  const [simSpeed, setSimSpeed] = useState<number>(1);
  const [unitSystem, setUnitSystem] = useState<'SI' | 'Imperial'>('SI');

  const [selectedComponent, setSelectedComponent] = useState<EngineComponentMeta | null>(null);
  const [machines, setMachines] = useState<MachineAsset[]>(DEFAULT_MACHINES);
  const [alerts, setAlerts] = useState<SystemAlert[]>(DEFAULT_ALERTS);

  // Computed live physics state
  const [simState, setSimState] = useState<SimulationOperatingState>(() =>
    calculateEngineCycle(DEFAULT_ENGINE_CONFIG, 3500, 100)
  );

  // Real-time animation tick loop for engine physics state updates
  useEffect(() => {
    if (!isSimulating) return;

    const interval = setInterval(() => {
      // Re-run thermodynamics calculation
      const computed = calculateEngineCycle(engineConfig, rpm, throttlePct);
      setSimState(computed);
    }, 100 / simSpeed);

    return () => clearInterval(interval);
  }, [engineConfig, rpm, throttlePct, isSimulating, simSpeed]);

  // Handle preset config changes
  const handleChangeEngineType = (type: EngineType) => {
    const preset = DEFAULT_PRESET_CONFIGS[type] || DEFAULT_ENGINE_CONFIG;
    setEngineConfig(preset);
  };

  // Alert acknowledgement
  const handleAcknowledgeAlert = (alertId: string) => {
    setAlerts((prev) =>
      prev.map((a) => (a.id === alertId ? { ...a, acknowledged: true, acknowledgedBy: 'Dr. Alex Vance' } : a))
    );
  };

  return (
    <div className="flex flex-col min-h-screen bg-graphite-950 text-gray-100 font-mono-tech select-none overflow-hidden">
      {/* Top Application Header */}
      <Header
        engineConfig={engineConfig}
        onChangeEngineType={handleChangeEngineType}
        rpm={rpm}
        onChangeRpm={setRpm}
        isSimulating={isSimulating}
        onToggleSimulate={() => setIsSimulating(!isSimulating)}
        onResetSimulate={() => {
          setRpm(3500);
          setThrottlePct(100);
          setEngineConfig(DEFAULT_ENGINE_CONFIG);
        }}
        simSpeed={simSpeed}
        onChangeSimSpeed={setSimSpeed}
        alerts={alerts}
        unitSystem={unitSystem}
        onChangeUnitSystem={setUnitSystem}
      />

      {/* Main Workspace Layout (Sidebar + Active Screen) */}
      <div className="flex flex-1 overflow-hidden">
        <Sidebar activeScreen={activeScreen} onNavigate={setActiveScreen} />

        <main className="flex-1 overflow-hidden relative">
          {activeScreen === 'overview' && (
            <OverviewScreen
              engineConfig={engineConfig}
              simState={simState}
              machines={machines}
              alerts={alerts}
              onAcknowledgeAlert={handleAcknowledgeAlert}
              onNavigateScreen={setActiveScreen}
              onSelectComponent={setSelectedComponent}
            />
          )}

          {activeScreen === 'engine_twin' && (
            <EngineTwinScreen
              engineConfig={engineConfig}
              onUpdateEngineConfig={setEngineConfig}
              simState={simState}
              rpm={rpm}
              onChangeRpm={setRpm}
              throttlePct={throttlePct}
              onChangeThrottle={setThrottlePct}
            />
          )}

          {activeScreen === 'model_3d' && (
            <Model3DScreen
              engineConfig={engineConfig}
              rpm={rpm}
              selectedComponent={selectedComponent}
              onSelectComponent={setSelectedComponent}
            />
          )}

          {activeScreen === 'manufacturing' && (
            <ManufacturingScreen onNavigateScreen={setActiveScreen} />
          )}

          {activeScreen === 'factory' && (
            <FactoryScreen machines={machines} onNavigateScreen={setActiveScreen} />
          )}

          {activeScreen === 'quality' && <QualityScreen />}

          {activeScreen === 'machines' && <MachinesScreen machines={machines} />}

          {activeScreen === 'assembly' && <AssemblyScreen />}

          {activeScreen === 'test_cell' && (
            <TestCellScreen
              engineConfig={engineConfig}
              simState={simState}
              rpm={rpm}
              onChangeRpm={setRpm}
            />
          )}

          {activeScreen === 'performance' && (
            <PerformanceScreen
              engineConfig={engineConfig}
              onUpdateEngineConfig={setEngineConfig}
              simState={simState}
            />
          )}

          {activeScreen === 'cost' && <CostScreen />}

          {activeScreen === 'energy' && <EnergyScreen />}

          {activeScreen === 'maintenance' && <MaintenanceScreen machines={machines} />}

          {activeScreen === 'scenarios' && <ScenariosScreen engineConfig={engineConfig} />}

          {activeScreen === 'digital_thread' && <DigitalThreadScreen />}

          {activeScreen === 'audit_log' && <AuditLogScreen />}

          {activeScreen === 'settings' && (
            <SettingsScreen unitSystem={unitSystem} onChangeUnitSystem={setUnitSystem} />
          )}
        </main>
      </div>
    </div>
  );
}
