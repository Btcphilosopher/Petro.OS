import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Forge Twin - ICE Manufacturing Digital Twin',
  description: 'Industrial-grade Internal Combustion Engine Manufacturing Digital Twin Platform integrating parametric 3D CAD visualization, ICE thermodynamics, manufacturing line simulation, SPC quality, predictive maintenance, cost & energy analytics, and digital thread genealogy.',
  openGraph: {
    title: 'Forge Twin - ICE Manufacturing Digital Twin',
    description: 'Industrial-grade Internal Combustion Engine Manufacturing Digital Twin Platform integrating parametric 3D CAD visualization, ICE thermodynamics, manufacturing line simulation, SPC quality, predictive maintenance, cost & energy analytics, and digital thread genealogy.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Forge Twin - ICE Manufacturing Digital Twin',
    description: 'Industrial-grade Internal Combustion Engine Manufacturing Digital Twin Platform integrating parametric 3D CAD visualization, ICE thermodynamics, manufacturing line simulation, SPC quality, predictive maintenance, cost & energy analytics, and digital thread genealogy.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
