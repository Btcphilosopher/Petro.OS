import { EngineConfig } from '@/types/engine';
import { CrankAngleDataPoint, CylinderState, SimulationOperatingState, WiebeParameters } from '@/types/physics';

/**
 * Calculates physics-based ICE thermodynamic cycle and dynamics.
 */
export function calculateEngineCycle(
  config: EngineConfig,
  rpm: number,
  throttlePct: number,
  userWiebe?: WiebeParameters
): SimulationOperatingState {
  const boreM = config.boreMm / 1000;
  const strokeM = config.strokeMm / 1000;
  const crankRadiusM = strokeM / 2;
  const conRodLengthM = config.connectingRod.lengthMm / 1000;
  const cylinderAreaM2 = (Math.PI * Math.pow(boreM, 2)) / 4;
  const singleCylinderDisplacementM3 = cylinderAreaM2 * strokeM;
  const clearanceVolumeM3 = singleCylinderDisplacementM3 / (config.compressionRatio - 1);
  
  // Reciprocating mass (piston + 1/3 connecting rod)
  const pistonMassKg = config.piston.massGrams / 1000;
  const rodMassKg = config.connectingRod.massGrams / 1000;
  const recipMassKg = pistonMassKg + (1 / 3) * rodMassKg;

  // Angular velocity
  const omegaRadS = (2 * Math.PI * rpm) / 60;
  const meanPistonSpeedMS = (2 * strokeM * rpm) / 60;

  // Wiebe parameters for combustion
  const wiebe: WiebeParameters = userWiebe || {
    efficiencyParameterA: 5.0,
    formFactorM: 2.0,
    ignitionTimingDegBTDC: config.fuelSystem.injectionTimingDegBtdc % 360 > 180 ? 15 : 18,
    combustionDurationDeg: 48,
  };

  const ignitionAngleDeg = 360 - wiebe.ignitionTimingDegBTDC; // Combustion starts slightly before TDC at 360°
  
  // Intake pressure dependent on throttle
  const ambientPressureBar = 1.013;
  const intakePressureBar = ambientPressureBar * (0.25 + 0.75 * (throttlePct / 100)) + (config.turbocharged ? config.boostPressureBar : 0);

  const crankAngleTrace: CrankAngleDataPoint[] = [];
  let totalIndicatedWorkJ = 0;
  let maxPressureBar = 0;
  let maxPressureDeg = 0;

  const numPoints = 360; // 2 degree resolution over 720° cycle
  const stepDeg = 720 / numPoints;

  for (let i = 0; i < numPoints; i++) {
    const deg = i * stepDeg; // 0° to 720°
    const rad = (deg * Math.PI) / 180;

    // Kinematics: Piston position x(deg) from TDC
    // x = r*(1 - cos(rad)) + l*(1 - sqrt(1 - (r/l)^2 * sin^2(rad)))
    const lambdaRatio = crankRadiusM / conRodLengthM;
    const sinRad = Math.sin(rad);
    const cosRad = Math.cos(rad);
    const sqrtTerm = Math.sqrt(Math.max(0, 1 - Math.pow(lambdaRatio * sinRad, 2)));

    const pistonPosM = crankRadiusM * (1 - cosRad) + conRodLengthM * (1 - sqrtTerm);
    const pistonPositionMm = pistonPosM * 1000;

    // Velocity & Acceleration
    const velocityMS = omegaRadS * crankRadiusM * (sinRad + (lambdaRatio * Math.sin(2 * rad)) / 2);
    const accelMS2 = Math.pow(omegaRadS, 2) * crankRadiusM * (cosRad + lambdaRatio * Math.cos(2 * rad));

    // Volume
    const currentVolM3 = clearanceVolumeM3 + cylinderAreaM2 * pistonPosM;
    const currentVolCc = currentVolM3 * 1e6;

    // Polytropic exponent
    const gamma = 1.34;

    // Mass fraction burned (Wiebe model) during combustion
    let massBurnedFraction = 0;
    let heatReleaseRateJDeg = 0;

    if (deg >= ignitionAngleDeg && deg <= ignitionAngleDeg + wiebe.combustionDurationDeg) {
      const progress = (deg - ignitionAngleDeg) / wiebe.combustionDurationDeg;
      massBurnedFraction = 1 - Math.exp(-wiebe.efficiencyParameterA * Math.pow(progress, wiebe.formFactorM + 1));
      
      const dXbdTheta = wiebe.efficiencyParameterA * (wiebe.formFactorM + 1) * Math.pow(progress, wiebe.formFactorM) * Math.exp(-wiebe.efficiencyParameterA * Math.pow(progress, wiebe.formFactorM + 1)) / wiebe.combustionDurationDeg;
      
      // Total heat input per cylinder ~ 1100 J at full load
      const fuelHeatJ = 1100 * (throttlePct / 100);
      heatReleaseRateJDeg = fuelHeatJ * dXbdTheta;
    } else if (deg > ignitionAngleDeg + wiebe.combustionDurationDeg) {
      massBurnedFraction = 1.0;
    }

    // Pressure calculation based on stroke
    let pressureBar = intakePressureBar;
    let temperatureK = 310; // Intake temp

    if (deg < 180) {
      // Stroke 1: Intake (0 - 180°)
      pressureBar = intakePressureBar * (1 - 0.05 * Math.sin(rad));
      temperatureK = 310 + 20 * Math.sin(rad);
    } else if (deg >= 180 && deg < 360) {
      // Stroke 2: Compression (180 - 360°)
      const vBDC = clearanceVolumeM3 + singleCylinderDisplacementM3;
      const compRatioLocal = vBDC / currentVolM3;
      
      let baseCompPress = intakePressureBar * Math.pow(compRatioLocal, gamma);
      
      // Early heat release effect before TDC
      if (massBurnedFraction > 0) {
        baseCompPress += (massBurnedFraction * 35 * (throttlePct / 100));
      }
      pressureBar = baseCompPress;
      temperatureK = 310 * Math.pow(compRatioLocal, gamma - 1) + massBurnedFraction * 800;
    } else if (deg >= 360 && deg < 540) {
      // Stroke 3: Expansion / Combustion (360 - 540°)
      const vTDC = clearanceVolumeM3;
      const expRatioLocal = currentVolM3 / vTDC;
      
      // Peak combustion pressure around 372° (12° ATDC)
      const maxPeakFactor = 65 * (0.3 + 0.7 * (throttlePct / 100)) * (config.compressionRatio / 10.5);
      const combustionPressAdded = massBurnedFraction * maxPeakFactor;
      
      pressureBar = (intakePressureBar * Math.pow(config.compressionRatio, gamma) + combustionPressAdded) / Math.pow(expRatioLocal, 1.28);
      temperatureK = 2200 * Math.pow(1 / expRatioLocal, 0.25) * Math.max(0.4, massBurnedFraction);
    } else {
      // Stroke 4: Exhaust (540 - 720°)
      pressureBar = 1.15 + 0.1 * Math.sin((deg - 540) * (Math.PI / 180));
      temperatureK = 750 - 300 * ((deg - 540) / 180);
    }

    if (pressureBar > maxPressureBar) {
      maxPressureBar = pressureBar;
      maxPressureDeg = deg;
    }

    // Forces
    const gasForceN = (pressureBar * 1e5 - 1e5) * cylinderAreaM2;
    const inertiaForceN = -recipMassKg * accelMS2;
    const netPistonForceN = gasForceN + inertiaForceN;

    // Connecting rod force & Crankshaft Torque
    const crankTorqueNm = netPistonForceN * crankRadiusM * (sinRad + (lambdaRatio * Math.sin(2 * rad)) / 2);

    // Work integration (P * dV)
    if (i > 0) {
      const prevPoint = crankAngleTrace[i - 1];
      const dVolM3 = (currentVolCc - prevPoint.cylinderVolumeCc) * 1e-6;
      const avgPressPa = ((pressureBar + prevPoint.pressureBar) / 2) * 1e5;
      totalIndicatedWorkJ += avgPressPa * dVolM3;
    }

    crankAngleTrace.push({
      crankAngleDeg: Math.round(deg),
      pistonPositionMm,
      pistonVelocityMs: velocityMS,
      pistonAccelerationMs2: accelMS2,
      cylinderVolumeCc: currentVolCc,
      pressureBar,
      temperatureK,
      massBurnedFraction,
      heatReleaseRateJDeg,
      gasForceN,
      inertiaForceN,
      connectingRodForceN: netPistonForceN / Math.max(0.2, sqrtTerm),
      crankTorqueNm,
    });
  }

  // Mean Indicated Pressure (IMEP)
  const imepBar = (totalIndicatedWorkJ * 1e-5) / (singleCylinderDisplacementM3 * 1e-6 * 100);

  // Friction Mean Effective Pressure (FMEP) via Chen-Flynn model
  const fmepBar = 0.4 + 0.005 * maxPressureBar + 0.09 * meanPistonSpeedMS + 0.001 * Math.pow(meanPistonSpeedMS, 2);

  // Pumping Losses (PMEP)
  const pmepBar = 0.15 + 0.25 * (1 - throttlePct / 100);

  // Brake Mean Effective Pressure (BMEP)
  const bmepBar = Math.max(0.1, imepBar - fmepBar - pmepBar);

  // Total Torque & Power
  const totalDisplacementM3 = singleCylinderDisplacementM3 * config.cylinderCount;
  const torqueNm = (bmepBar * 1e5 * totalDisplacementM3) / (4 * Math.PI);
  const powerKw = (2 * Math.PI * rpm * torqueNm) / 60000;

  // Volumetric Efficiency %
  const volumetricEfficiencyPct = Math.min(100, Math.max(20, (0.85 + 0.12 * Math.sin((rpm / config.maxRpm) * Math.PI)) * (throttlePct / 100) * 100));

  // Fuel Flow & BSFC
  const airDensityKgM3 = 1.2;
  const airMassFlowKgH = (volumetricEfficiencyPct / 100) * totalDisplacementM3 * (rpm / 2) * 60 * airDensityKgM3;
  const airFuelRatio = 14.7; // Stoichiometric
  const fuelMassFlowKgH = airMassFlowKgH / airFuelRatio;
  const bsfcGKh = powerKw > 1 ? (fuelMassFlowKgH * 1000) / powerKw : 320;

  // Temperatures
  const coolantTempC = 85 + 20 * (powerKw / 180) + (rpm > 5000 ? 5 : 0);
  const oilTempC = 90 + 25 * (powerKw / 180);
  const exhaustTempC = 450 + 350 * (throttlePct / 100) + 100 * (rpm / config.maxRpm);

  // Cylinder states for each cylinder in firing order
  const cylinders: CylinderState[] = [];
  const firingOffsets = config.cylinderCount === 4 ? [0, 180, 540, 360] :
                        config.cylinderCount === 6 ? [0, 120, 240, 360, 480, 600] :
                        [0, 90, 180, 270, 360, 450, 540, 630];

  for (let c = 0; c < config.cylinderCount; c++) {
    const cylAngle = (0 + firingOffsets[c % firingOffsets.length]) % 720;
    const traceIdx = Math.floor((cylAngle / 720) * crankAngleTrace.length);
    const tracePt = crankAngleTrace[Math.min(traceIdx, crankAngleTrace.length - 1)];

    let stroke: 'Intake' | 'Compression' | 'Combustion' | 'Exhaust' = 'Intake';
    if (cylAngle >= 180 && cylAngle < 360) stroke = 'Compression';
    else if (cylAngle >= 360 && cylAngle < 540) stroke = 'Combustion';
    else if (cylAngle >= 540) stroke = 'Exhaust';

    cylinders.push({
      cylinderNumber: c + 1,
      crankAngleDeg: Math.round(cylAngle),
      currentStroke: stroke,
      pistonPositionMm: tracePt.pistonPositionMm,
      pressureBar: tracePt.pressureBar,
      temperatureC: Math.round(tracePt.temperatureK - 273.15),
      airMassGrams: (airMassFlowKgH * 1000) / (config.cylinderCount * (rpm / 2) * 60),
      fuelMassGrams: (fuelMassFlowKgH * 1000) / (config.cylinderCount * (rpm / 2) * 60),
      airFuelRatio: 14.7,
      combustionState: tracePt.massBurnedFraction > 0.8 ? 'Expansion' : tracePt.massBurnedFraction > 0.1 ? 'Peak Combustion' : stroke === 'Compression' ? 'Compression' : 'Scavenging',
      peakPressureBar: maxPressureBar,
      peakPressureAngleDeg: maxPressureDeg,
      indicatedWorkJ: totalIndicatedWorkJ,
    });
  }

  return {
    rpm,
    throttlePct,
    loadPct: throttlePct,
    torqueNm: Math.round(torqueNm * 10) / 10,
    powerKw: Math.round(powerKw * 10) / 10,
    bmepBar: Math.round(bmepBar * 100) / 100,
    fmepBar: Math.round(fmepBar * 100) / 100,
    pmepBar: Math.round(pmepBar * 100) / 100,
    imepBar: Math.round(imepBar * 100) / 100,
    volumetricEfficiencyPct: Math.round(volumetricEfficiencyPct * 10) / 10,
    airMassFlowKgH: Math.round(airMassFlowKgH * 10) / 10,
    fuelMassFlowKgH: Math.round(fuelMassFlowKgH * 10) / 10,
    bsfcGKh: Math.round(bsfcGKh * 10) / 10,
    thermalEfficiencyPct: Math.round((3600 / (bsfcGKh * 44)) * 100 * 10) / 10, // 44 MJ/kg fuel
    mechanicalEfficiencyPct: Math.round((bmepBar / Math.max(0.1, imepBar)) * 1000) / 10,
    coolantTempC: Math.round(coolantTempC),
    oilTempC: Math.round(oilTempC),
    exhaustTempC: Math.round(exhaustTempC),
    oilPressureBar: Math.round((2.2 + 2.5 * (rpm / config.maxRpm)) * 10) / 10,
    vibrationRMS: Math.round((1.2 + 2.4 * Math.pow(rpm / config.maxRpm, 1.8)) * 100) / 100,
    cylinders,
    crankAngleTrace,
  };
}
