import { SPCChartPoint, ToleranceStackDimension, QualityMetricSummary } from '@/types/quality';

export function calculateSPC(
  measurements: number[],
  targetNominal: number,
  usl: number,
  lsl: number
): {
  mean: number;
  stdDev: number;
  cp: number;
  cpk: number;
  pp: number;
  ppk: number;
  ucl: number;
  lcl: number;
} {
  if (measurements.length === 0) {
    return { mean: targetNominal, stdDev: 0.001, cp: 1.67, cpk: 1.67, pp: 1.67, ppk: 1.67, ucl: targetNominal + 0.009, lcl: targetNominal - 0.009 };
  }

  const sum = measurements.reduce((a, b) => a + b, 0);
  const mean = sum / measurements.length;

  const variance = measurements.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / (measurements.length - 1 || 1);
  const stdDev = Math.max(0.0001, Math.sqrt(variance));

  const toleranceRange = usl - lsl;
  const cp = toleranceRange / (6 * stdDev);
  
  const cpkUpper = (usl - mean) / (3 * stdDev);
  const cpkLower = (mean - lsl) / (3 * stdDev);
  const cpk = Math.min(cpkUpper, cpkLower);

  // Control limits (3 sigma)
  const ucl = mean + 3 * stdDev;
  const lcl = mean - 3 * stdDev;

  return {
    mean: Math.round(mean * 10000) / 10000,
    stdDev: Math.round(stdDev * 100000) / 100000,
    cp: Math.round(cp * 100) / 100,
    cpk: Math.round(cpk * 100) / 100,
    pp: Math.round(cp * 0.96 * 100) / 100,
    ppk: Math.round(cpk * 0.95 * 100) / 100,
    ucl: Math.round(ucl * 10000) / 10000,
    lcl: Math.round(lcl * 10000) / 10000,
  };
}

export function generateSPCHistory(
  targetNominal: number = 86.000,
  toleranceMm: number = 0.015,
  sampleCount: number = 30,
  driftAmountMm: number = 0
): SPCChartPoint[] {
  const usl = targetNominal + toleranceMm;
  const lsl = targetNominal - toleranceMm;
  const baseSigma = toleranceMm / 4.8; // Cpk ~ 1.6

  const points: SPCChartPoint[] = [];

  for (let i = 1; i <= sampleCount; i++) {
    // Introduce gradual tool wear drift over the last 10 samples if requested
    const currentDrift = i > 15 ? ((i - 15) / 15) * driftAmountMm : 0;
    
    // Deterministic pseudo-random variation
    const noise = (Math.sin(i * 1.7) * 0.4 + Math.cos(i * 2.3) * 0.6) * baseSigma;
    const value = targetNominal + currentDrift + noise;
    
    const ucl = targetNominal + 3 * baseSigma;
    const lcl = targetNominal - 3 * baseSigma;
    const isOutofControl = value > usl || value < lsl;
    const driftSignal = currentDrift > 0.005;

    points.push({
      sampleNumber: i,
      timestamp: `${8 + Math.floor(i / 6)}:${(i * 10) % 60 < 10 ? '0' : ''}${(i * 10) % 60}`,
      meanValue: Math.round(value * 10000) / 10000,
      rangeValue: Math.round(Math.abs(noise * 1.5) * 10000) / 10000,
      ucl: Math.round(ucl * 10000) / 10000,
      lcl: Math.round(lcl * 10000) / 10000,
      targetNominal,
      usl,
      lsl,
      isOutofControl,
      driftSignal,
    });
  }

  return points;
}

export function calculateToleranceStackup(
  boreNominalMm: number = 86.000,
  boreTolMm: number = 0.015,
  pistonNominalMm: number = 85.965,
  pistonTolMm: number = 0.010
): ToleranceStackDimension[] {
  const clearanceNominal = (boreNominalMm - pistonNominalMm) * 1000; // microns (35 microns)
  const stackToleranceMicrons = Math.sqrt(Math.pow(boreTolMm * 1000, 2) + Math.pow(pistonTolMm * 1000, 2));

  return [
    {
      id: 'tol_bore',
      featureName: 'Cylinder Bore Diameter',
      nominalMm: boreNominalMm,
      upperLimitMm: boreNominalMm + boreTolMm,
      lowerLimitMm: boreNominalMm - boreTolMm,
      actualSimulatedMm: boreNominalMm + 0.003,
      deviationMicrons: +3,
      cpk: 1.62,
      ppk: 1.55,
      status: 'IN_SPEC',
      affectedEngineProperty: 'Piston Skirt Clearance & Oil Consumption',
    },
    {
      id: 'tol_piston',
      featureName: 'Piston Skirt Outer Diameter',
      nominalMm: pistonNominalMm,
      upperLimitMm: pistonNominalMm + pistonTolMm,
      lowerLimitMm: pistonNominalMm - pistonTolMm,
      actualSimulatedMm: pistonNominalMm - 0.002,
      deviationMicrons: -2,
      cpk: 1.48,
      ppk: 1.42,
      status: 'IN_SPEC',
      affectedEngineProperty: 'Piston Slap & Friction Loss',
    },
    {
      id: 'tol_clearance',
      featureName: 'Piston-to-Bore Running Clearance',
      nominalMm: Math.round(clearanceNominal),
      upperLimitMm: Math.round(clearanceNominal + stackToleranceMicrons),
      lowerLimitMm: Math.round(clearanceNominal - stackToleranceMicrons),
      actualSimulatedMm: Math.round(clearanceNominal + 5),
      deviationMicrons: +5,
      cpk: 1.38,
      ppk: 1.30,
      status: 'IN_SPEC',
      affectedEngineProperty: 'Blowby Gas Leakage & Cylinder Compression',
    },
    {
      id: 'tol_ring_gap',
      featureName: 'Top Compression Ring End Gap',
      nominalMm: 0.280,
      upperLimitMm: 0.330,
      lowerLimitMm: 0.230,
      actualSimulatedMm: 0.285,
      deviationMicrons: +5,
      cpk: 1.75,
      ppk: 1.68,
      status: 'IN_SPEC',
      affectedEngineProperty: 'Combustion Gas Sealing & Thermal Expansion Clearance',
    },
    {
      id: 'tol_crank_journal',
      featureName: 'Crankshaft Main Journal Diameter',
      nominalMm: 58.000,
      upperLimitMm: 58.008,
      lowerLimitMm: 57.992,
      actualSimulatedMm: 58.001,
      deviationMicrons: +1,
      cpk: 1.71,
      ppk: 1.65,
      status: 'IN_SPEC',
      affectedEngineProperty: 'Hydrodynamic Oil Film Thickness & Bearing Fatigue Life',
    },
  ];
}
