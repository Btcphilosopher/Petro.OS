import { ScenarioDefinition, ScenarioComparisonResult } from '@/types/scenarios';
import { EngineConfig } from '@/types/engine';
import { calculateEngineCycle } from './icePhysicsEngine';
import { DEFAULT_ENGINE_CONFIG } from './defaults';

export function propagateScenarioImpact(
  scenario: ScenarioDefinition,
  baseConfig: EngineConfig = DEFAULT_ENGINE_CONFIG
): ScenarioComparisonResult {
  // Baseline bore tolerance is 0.015mm
  const tolRatio = scenario.boreToleranceMm / 0.015; // <1 means tighter tolerance, >1 means looser

  // 1. Machining Cycle Time & Tooling Impact
  // Tighter tolerance requires slower cutting speed and more passes
  const cycleTimeFactor = Math.pow(1 / tolRatio, 0.45) * scenario.cycleTimeMultiplier;
  const toolWearRate = Math.pow(1 / tolRatio, 0.6);

  // 2. Quality & Scrap
  // Tighter tolerance increases Cpk if process stays capable, but raises scrap risk if machine capability is strained
  const cpk = Math.max(0.8, Math.min(2.2, 1.62 * Math.pow(1 / tolRatio, 0.3)));
  const scrapRatePct = Math.max(0.2, Math.min(5.0, 0.8 * Math.pow(tolRatio, 0.8)));

  // 3. Costs (Waterfall)
  const baseRawMaterialCost = 140.0;
  const baseMachiningCost = 285.0 * cycleTimeFactor;
  const baseEnergyCost = 42.0 * cycleTimeFactor;
  const baseLaborCost = 65.0;
  const baseToolingCost = 38.0 * toolWearRate;
  const baseMaintenanceCost = 28.0;
  const baseScrapCost = (baseRawMaterialCost + baseMachiningCost) * (scrapRatePct / 100);
  const baseQualityCost = 22.0;
  const baseOverheadCost = 110.0;

  const totalUnitCostUSD = 
    baseRawMaterialCost +
    baseMachiningCost +
    baseEnergyCost +
    baseLaborCost +
    baseToolingCost +
    baseMaintenanceCost +
    baseScrapCost +
    baseQualityCost +
    baseOverheadCost;

  // 4. Engine Physical Clearances & Thermodynamics
  // Tighter bore tolerance means tighter piston skirt running clearance variance
  const pistonRingClearanceMicrons = 35 * Math.pow(tolRatio, 0.5);
  
  // Clearances affect piston friction (FMEP) and blowby
  const frictionFmepDeltaBar = (1 - tolRatio) * 0.03; // tighter tolerance reduces friction & ring flutter
  
  // Modified engine cycle calculation
  const modifiedConfig: EngineConfig = {
    ...baseConfig,
    boreMm: baseConfig.boreMm,
    piston: {
      ...baseConfig.piston,
      skirtClearanceMicrons: pistonRingClearanceMicrons,
    },
  };

  const simResult = calculateEngineCycle(modifiedConfig, 6000, 100);
  
  const peakPowerKw = Math.round((simResult.powerKw + (1 - tolRatio) * 2.2) * 10) / 10;
  const bsfcGKh = Math.round((simResult.bsfcGKh - (1 - tolRatio) * 3.5) * 10) / 10;

  // 5. Throughput & OEE
  const baseShiftCycleTimeSec = 145 * cycleTimeFactor;
  const shiftSeconds = 8 * 3600; // 8-hour shift
  const totalShiftUnits = Math.floor((shiftSeconds / baseShiftCycleTimeSec) * scenario.machineCountCNC);
  const throughputUnitsPerShift = Math.floor(totalShiftUnits * (1 - scrapRatePct / 100));

  const oeePct = Math.round(Math.max(60, Math.min(98, 89.9 / Math.sqrt(cycleTimeFactor))) * 10) / 10;

  return {
    scenarioId: scenario.id,
    scenarioName: scenario.name,
    throughputUnitsPerShift,
    overallOeePct: oeePct,
    cpkQuality: Math.round(cpk * 100) / 100,
    scrapRatePct: Math.round(scrapRatePct * 100) / 100,
    unitCost: {
      rawMaterialCost: Math.round(baseRawMaterialCost * 10) / 10,
      machiningCost: Math.round(baseMachiningCost * 10) / 10,
      energyCost: Math.round(baseEnergyCost * 10) / 10,
      directLaborCost: Math.round(baseLaborCost * 10) / 10,
      toolingCost: Math.round(baseToolingCost * 10) / 10,
      maintenanceCost: Math.round(baseMaintenanceCost * 10) / 10,
      scrapCost: Math.round(baseScrapCost * 10) / 10,
      qualityInspectionCost: Math.round(baseQualityCost * 10) / 10,
      overheadCost: Math.round(baseOverheadCost * 10) / 10,
      totalUnitCostUSD: Math.round(totalUnitCostUSD * 10) / 10,
    },
    pistonRingClearanceMicrons: Math.round(pistonRingClearanceMicrons * 10) / 10,
    frictionFmepBar: Math.round((simResult.fmepBar - frictionFmepDeltaBar) * 100) / 100,
    peakEnginePowerKw: peakPowerKw,
    bsfcGKh,
    toolWearRateMultiplier: Math.round(toolWearRate * 100) / 100,
    co2EmissionsKgPerEngine: Math.round((baseEnergyCost * 0.42 + 24) * 10) / 10,
  };
}
