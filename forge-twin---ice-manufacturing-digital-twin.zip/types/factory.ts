export type MachineStatus = 'RUNNING' | 'IDLE' | 'WARNING' | 'CRITICAL' | 'MAINTENANCE';

export interface MachineTelemetry {
  timestamp: string;
  spindleRpm: number;
  spindleLoadPct: number;
  vibrationMmS: number;
  vibrationFrequencyHz: number;
  temperatureC: number;
  motorCurrentAmps: number;
  coolantPressureBar: number;
  acousticEmissionDb: number;
  energyKw: number;
}

export interface MachineAsset {
  id: string; // e.g., 'CNC-BLOCK-042'
  name: string;
  category: 'Casting' | 'CNC Milling' | 'CNC Turning' | 'Honing' | 'Grinding' | 'Balancing' | 'Washing' | 'CMM Inspection' | 'Robotic Assembly' | 'Dyno Test';
  lineId: string;
  locationGrid: { x: number; y: number };
  manufacturer: string;
  model: string;
  operatingHours: number;
  status: MachineStatus;
  
  cycleTimeSec: number;
  spindleSpeedRpm: number;
  toolWearPct: number;
  energyKw: number;
  temperatureC: number;
  vibrationMmS: number;
  
  availabilityPct: number;
  performancePct: number;
  qualityPct: number;
  oeePct: number;
  
  productionCountToday: number;
  scrapCountToday: number;

  remainingUsefulLifeHours: number;
  healthDiagnosis: string;
  telemetryHistory: MachineTelemetry[];
}

export interface ProductionLine {
  id: string;
  name: string;
  targetTaktTimeSec: number;
  actualTaktTimeSec: number;
  wipBufferUnits: number;
  unitsProducedShift: number;
  defectCountShift: number;
  overallOeePct: number;
  activeBottleneckMachineId?: string;
  machines: MachineAsset[];
}
