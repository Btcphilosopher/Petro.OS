import { UnitCostWaterfall } from './cost_energy';

export interface ScenarioDefinition {
  id: string;
  name: string;
  description: string;
  createdAt: string;
  
  // Modifiable parameters
  boreToleranceMm: number; // e.g., 0.020 vs 0.010
  pistonMaterialId: string;
  cycleTimeMultiplier: number;
  machineCountCNC: number;
  maintenanceIntervalHours: number;
  targetShiftVolume: number;
}

export interface ScenarioComparisonResult {
  scenarioId: string;
  scenarioName: string;
  
  // Output impacts
  throughputUnitsPerShift: number;
  overallOeePct: number;
  cpkQuality: number;
  scrapRatePct: number;
  unitCost: UnitCostWaterfall;
  pistonRingClearanceMicrons: number;
  frictionFmepBar: number;
  peakEnginePowerKw: number;
  bsfcGKh: number;
  toolWearRateMultiplier: number;
  co2EmissionsKgPerEngine: number;
}
