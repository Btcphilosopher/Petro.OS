export interface GenealogyNode {
  id: string; // e.g. ICE-V8-2026-0001842
  serialNumber: string;
  type: 'Engine' | 'Component' | 'MaterialBatch' | 'Machine' | 'Process' | 'Station' | 'Inspection' | 'DynoTest';
  name: string;
  timestamp: string;
  status: 'Completed' | 'Passed' | 'Active' | 'Warning';
  details: Record<string, string | number>;
  parentIds: string[];
  childIds: string[];
}

export interface EngineDigitalGenealogy {
  engineSerial: string;
  buildDate: string;
  configurationName: string;
  engineBlockSerial: string;
  crankshaftSerial: string;
  pistonsBatchId: string;
  materialHeatNumber: string;
  machiningMachineIds: string[];
  assemblyTorqueAudit: string[];
  dynoCertificateId: string;
  nodes: GenealogyNode[];
}
