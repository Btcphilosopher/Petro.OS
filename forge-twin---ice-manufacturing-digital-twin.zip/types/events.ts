export type AlertSeverity = 'INFO' | 'WATCH' | 'WARNING' | 'CRITICAL';

export interface SystemAlert {
  id: string;
  timestamp: string;
  severity: AlertSeverity;
  eventType: 
    | 'MACHINE_OVERHEAT'
    | 'TOOL_WEAR_WARNING'
    | 'BORE_OUT_OF_SPEC'
    | 'ENGINE_TEST_FAIL'
    | 'LOW_OIL_PRESSURE'
    | 'HIGH_VIBRATION'
    | 'QUALITY_DRIFT'
    | 'MACHINE_FAILURE'
    | 'PRODUCTION_BLOCKAGE';
  assetId: string;
  assetName: string;
  message: string;
  probableCause: string;
  affectedProduction: string;
  recommendedAction: string;
  acknowledged: boolean;
  acknowledgedBy?: string;
  acknowledgedAt?: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  userName: string;
  userRole: string;
  action: string;
  entityName: string;
  fieldChanged: string;
  oldValue: string;
  newValue: string;
  revision: string;
}
