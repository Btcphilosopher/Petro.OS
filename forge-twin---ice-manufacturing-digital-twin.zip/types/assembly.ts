export interface TorqueRecord {
  id: string;
  fastenerName: string;
  stationId: string;
  toolId: string;
  operatorId: string;
  timestamp: string;
  targetTorqueNm: number;
  actualTorqueNm: number;
  targetAngleDeg: number;
  actualAngleDeg: number;
  status: 'PASS' | 'HIGH_TORQUE' | 'LOW_TORQUE' | 'REWORK';
}

export interface AssemblyStation {
  id: string;
  stationNumber: number;
  name: string;
  description: string;
  assignedOperator: string;
  automatedRobotsCount: number;
  cycleTimeSec: number;
  taktTimeSec: number;
  fastenersToTorque: TorqueRecord[];
  defectsRecordedCount: number;
  status: 'ACTIVE' | 'BLOCKED' | 'STARVED' | 'MAINTENANCE';
}
