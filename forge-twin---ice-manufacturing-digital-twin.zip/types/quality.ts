export interface ToleranceStackDimension {
  id: string;
  featureName: string;
  nominalMm: number;
  upperLimitMm: number;
  lowerLimitMm: number;
  actualSimulatedMm: number;
  deviationMicrons: number;
  cpk: number;
  ppk: number;
  status: 'IN_SPEC' | 'WARNING' | 'OUT_OF_SPEC';
  affectedEngineProperty: string;
}

export interface SPCChartPoint {
  sampleNumber: number;
  timestamp: string;
  meanValue: number;
  rangeValue: number;
  ucl: number; // Upper Control Limit
  lcl: number; // Lower Control Limit
  targetNominal: number;
  usl: number; // Upper Spec Limit
  lsl: number; // Lower Spec Limit
  isOutofControl: boolean;
  driftSignal: boolean;
}

export interface QualityMetricSummary {
  cpkGlobal: number;
  ppkGlobal: number;
  firstPassYieldPct: number;
  scrapRatePct: number;
  reworkRatePct: number;
  totalMeasurementsToday: number;
  outOfSpecCountToday: number;
  processDriftDetected: boolean;
  driftedFeatureName?: string;
}
