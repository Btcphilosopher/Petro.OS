export interface CrankAngleDataPoint {
  crankAngleDeg: number; // 0 to 720 deg
  pistonPositionMm: number;
  pistonVelocityMs: number;
  pistonAccelerationMs2: number;
  cylinderVolumeCc: number;
  pressureBar: number;
  temperatureK: number;
  massBurnedFraction: number; // 0 to 1 Wiebe
  heatReleaseRateJDeg: number;
  gasForceN: number;
  inertiaForceN: number;
  connectingRodForceN: number;
  crankTorqueNm: number;
}

export interface CylinderState {
  cylinderNumber: number;
  crankAngleDeg: number;
  currentStroke: 'Intake' | 'Compression' | 'Combustion' | 'Exhaust';
  pistonPositionMm: number;
  pressureBar: number;
  temperatureC: number;
  airMassGrams: number;
  fuelMassGrams: number;
  airFuelRatio: number;
  combustionState: 'Scavenging' | 'Compression' | 'Peak Combustion' | 'Expansion' | 'Blowdown';
  peakPressureBar: number;
  peakPressureAngleDeg: number;
  indicatedWorkJ: number;
}

export interface SimulationOperatingState {
  rpm: number;
  throttlePct: number; // 0-100%
  loadPct: number; // 0-100%
  torqueNm: number;
  powerKw: number;
  bmepBar: number; // Brake Mean Effective Pressure
  fmepBar: number; // Friction Mean Effective Pressure
  pmepBar: number; // Pumping Mean Effective Pressure
  imepBar: number; // Indicated Mean Effective Pressure
  volumetricEfficiencyPct: number;
  airMassFlowKgH: number;
  fuelMassFlowKgH: number;
  bsfcGKh: number; // Brake Specific Fuel Consumption (g/kWh)
  thermalEfficiencyPct: number;
  mechanicalEfficiencyPct: number;
  coolantTempC: number;
  oilTempC: number;
  exhaustTempC: number;
  oilPressureBar: number;
  vibrationRMS: number; // m/s²
  cylinders: CylinderState[];
  crankAngleTrace: CrankAngleDataPoint[];
}

export interface WiebeParameters {
  efficiencyParameterA: number; // typically 5.0
  formFactorM: number; // typically 2.0
  ignitionTimingDegBTDC: number; // e.g. 15° BTDC
  combustionDurationDeg: number; // e.g. 45°
}
