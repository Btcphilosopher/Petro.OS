export type EngineType = 'I4' | 'I6' | 'V6' | 'V8';
export type FuelType = 'gasoline' | 'diesel';
export type ValvetrainType = 'DOHC' | 'SOHC' | 'OHV';

export interface ComponentMaterial {
  id: string;
  name: string;
  type: string;
  density: number; // g/cm³
  tensileStrength: number; // MPa
  thermalConductivity: number; // W/m·K
  costPerKg: number; // USD/kg
  machinabilityIndex: number; // 0 - 100
  hardnessHB: number;
}

export interface EngineComponentMeta {
  id: string;
  partNumber: string;
  name: string;
  system: string;
  material: ComponentMaterial;
  supplier: string;
  revision: string;
  massKg: number;
  unitCostUSD: number;
  primaryMachiningProcess: string;
  toleranceClass: string;
  nominalDimensionMm: number;
  toleranceToleranceMm: number;
  qualityCpk: number;
  operatingTempC: number;
  predictedLifeHours: number;
  simulatedCondition: 'Optimal' | 'Normal Wear' | 'Thermal Stress' | 'Out of Spec';
}

export interface EngineConfig {
  id: string;
  name: string;
  revision: string;
  type: EngineType;
  fuelType: FuelType;
  valvetrainType: ValvetrainType;
  displacementL: number;
  cylinderCount: number;
  boreMm: number;
  strokeMm: number;
  compressionRatio: number;
  valvesPerCylinder: number;
  firingOrder: number[];
  maxRpm: number;
  idleRpm: number;
  
  // Component parameters
  block: {
    material: ComponentMaterial;
    deckHeightMm: number;
    cylinderSpacingMm: number;
    wallThicknessMm: number;
    coolantPassageVolumeL: number;
    oilPassageDiameterMm: number;
    bearingJournalDiameterMm: number;
  };
  
  head: {
    material: ComponentMaterial;
    combustionChamberVolumeCc: number;
    intakeValveDiameterMm: number;
    exhaustValveDiameterMm: number;
    intakePortDiameterMm: number;
    exhaustPortDiameterMm: number;
    gasketThicknessMm: number;
  };
  
  crankshaft: {
    material: ComponentMaterial;
    mainJournalDiameterMm: number;
    rodJournalDiameterMm: number;
    strokeMm: number;
    rotationalInertiaKgM2: number;
    counterweightMassKg: number;
    balanceQualityGrade: string;
  };
  
  connectingRod: {
    material: ComponentMaterial;
    lengthMm: number;
    massGrams: number;
    bigEndDiameterMm: number;
    smallEndDiameterMm: number;
    stiffnessKnMm: number;
  };
  
  piston: {
    material: ComponentMaterial;
    boreMm: number;
    crownVolumeCc: number;
    compressionHeightMm: number;
    massGrams: number;
    skirtClearanceMicrons: number;
    topRingGapMm: number;
    secondRingGapMm: number;
    oilRingTensionN: number;
  };
  
  fuelSystem: {
    injectorFlowRateCcMin: number;
    railPressureBar: number;
    injectionTimingDegBtdc: number;
    injectionDurationDeg: number;
  };
  
  turbocharged: boolean;
  boostPressureBar: number;
}
