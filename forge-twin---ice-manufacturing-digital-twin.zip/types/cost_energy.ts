export interface UnitCostWaterfall {
  rawMaterialCost: number;
  machiningCost: number;
  energyCost: number;
  directLaborCost: number;
  toolingCost: number;
  maintenanceCost: number;
  scrapCost: number;
  qualityInspectionCost: number;
  overheadCost: number;
  totalUnitCostUSD: number;
}

export interface FactoryEnergyData {
  totalPowerKw: number;
  electricityKwhPerEngine: number;
  compressedAirKwhPerEngine: number;
  coolantPumpingKwhPerEngine: number;
  thermalEnergyKwhPerEngine: number;
  dailyPeakDemandKw: number;
  dailyTotalCostUSD: number;
  co2EmissionsKgPerEngine: number;
  energyBreakdownByMachine: {
    machineId: string;
    machineName: string;
    powerKw: number;
    kwhPerEngine: number;
  }[];
}
