export type ProcessStage = 
  | 'Raw Material'
  | 'Casting / Forging'
  | 'Heat Treatment'
  | 'Rough Machining'
  | 'Precision Machining'
  | 'Washing & Deburring'
  | 'Inspection'
  | 'Subassembly'
  | 'Engine Assembly'
  | 'Test Cell'
  | 'Final Quality Gate'
  | 'Shipping';

export interface MachiningOperation {
  id: string;
  componentId: string;
  operationNumber: number;
  name: string;
  machineType: string;
  assignedMachineId: string;
  cycleTimeSec: number;
  feedRateMmMin: number;
  cuttingSpeedMMin: number;
  spindleSpeedRpm: number;
  toolDiameterMm: number;
  toolLifeRemainingPct: number;
  coolantFlowLMin: number;
  energyConsumptionKw: number;
  nominalDimensionMm: number;
  toleranceUpperMm: number;
  toleranceLowerMm: number;
  targetCpk: number;
  scrapProbabilityPct: number;
}

export interface ManufacturingFlowStep {
  id: string;
  stepNumber: number;
  stage: ProcessStage;
  title: string;
  description: string;
  cycleTimeSec: number;
  machinesInStation: number;
  scrapRatePct: number;
  qualityCheckCount: number;
  energyKwhPerUnit: number;
  costPerUnitUSD: number;
  status: 'OPTIMAL' | 'RUNNING' | 'BOTTLENECK' | 'WARNING';
}
