package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// BP Corporate & Executive Command Center Palette
val BpDarkForest = Color(0xFF071810)
val BpDeepEmerald = Color(0xFF003B22)
val BpBrandGreen = Color(0xFF007A3D)
val BpLightGreen = Color(0xFF00A859)
val BpNeonGreen = Color(0xFF10E070)
val BpHeliosYellow = Color(0xFFF9D308)
val BpHeliosGold = Color(0xFFE5B800)

// Slate & Graphite Neutral Colors
val DarkBackground = Color(0xFF0A100D)
val DarkSurface = Color(0xFF121B16)
val DarkSurfaceVariant = Color(0xFF1A2620)
val DarkBorder = Color(0xFF26382E)
val DarkCardBg = Color(0xFF141F19)

val LightBackground = Color(0xFFF4F6F5)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE8ECE9)
val LightBorder = Color(0xFFD0D8D3)
val LightCardBg = Color(0xFFFFFFFF)

// Executive Text Colors
val TextWhitePrimary = Color(0xFFF0F4F1)
val TextWhiteSecondary = Color(0xFFA0B3A8)
val TextWhiteMuted = Color(0xFF6E8276)

val TextDarkPrimary = Color(0xFF0E1A14)
val TextDarkSecondary = Color(0xFF4A5C52)
val TextDarkMuted = Color(0xFF82948A)

// Status & Semantic Metrics
val StatusGreen = Color(0xFF10B981)
val StatusAmber = Color(0xFFF59E0B)
val StatusRed = Color(0xFFEF4444)
val StatusBlue = Color(0xFF38BDF8)
val StatusPurple = Color(0xFFA855F7)
val StatusCyan = Color(0xFF06B6D4)

// Data Tag Badges
val TagActualBg = Color(0x2210B981)
val TagActualText = Color(0xFF34D399)
val TagForecastBg = Color(0x2238BDF8)
val TagForecastText = Color(0xFF38BDF8)
val TagModelledBg = Color(0x22A855F7)
val TagModelledText = Color(0xFFC084FC)
val TagSimulatedBg = Color(0x22F59E0B)
val TagSimulatedText = Color(0xFFFBBF24)
val TagSyntheticBg = Color(0x2264748B)
val TagSyntheticText = Color(0xFF94A3B8)
