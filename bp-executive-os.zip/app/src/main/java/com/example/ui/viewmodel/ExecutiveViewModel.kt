package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.EnterpriseRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ExecutiveUiState(
    val currentSection: ExecutiveNavSection = ExecutiveNavSection.OVERVIEW,
    val selectedAsset: GlobalAsset? = null,
    val isCommandPaletteOpen: Boolean = false,
    val isBoardReportOpen: Boolean = false,
    val isAiAssistantOpen: Boolean = false,
    val searchQuery: String = "",
    val activeBusinessFilter: BusinessSegment? = null,
    val activeRegionFilter: String? = null,
    val timePeriod: String = "2025 YTD",
    val isLiveStreaming: Boolean = true,
    val isGeneratingReport: Boolean = false,
    val reportGeneratedText: String? = null,
    val aiAnalystInput: String = ""
)

class ExecutiveViewModel(
    private val repository: EnterpriseRepository = EnterpriseRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(ExecutiveUiState())
    val uiState: StateFlow<ExecutiveUiState> = _uiState.asStateFlow()

    val marketSnapshots = repository.marketSnapshots
    val assets = repository.assets
    val currentScenarioInput = repository.currentScenarioInput
    val scenarioResult = repository.scenarioResult
    val risks = repository.risks
    val anomalies = repository.anomalies
    val refineryUnits = repository.refineryUnits
    val evHubs = repository.evHubs
    val aiAnalystHistory = repository.aiAnalystHistory

    val strategicPriorities = repository.getStrategicPriorities()
    val carbonProgressPoints = repository.getCarbonProgressPoints()
    val cashFlowAllocations = repository.getCashFlowAllocations()
    val executiveBriefings = repository.getExecutiveBriefings()
    val enterpriseHighlights = repository.getEnterpriseHighlights()

    val filteredAssets: StateFlow<List<GlobalAsset>> = combine(
        assets,
        _uiState
    ) { assetList, state ->
        assetList.filter { asset ->
            val matchSearch = if (state.searchQuery.isBlank()) true else {
                asset.name.contains(state.searchQuery, ignoreCase = true) ||
                asset.location.contains(state.searchQuery, ignoreCase = true) ||
                asset.business.displayName.contains(state.searchQuery, ignoreCase = true) ||
                asset.country.contains(state.searchQuery, ignoreCase = true)
            }
            val matchBusiness = state.activeBusinessFilter == null || asset.business == state.activeBusinessFilter
            val matchRegion = state.activeRegionFilter == null || asset.region == state.activeRegionFilter
            matchSearch && matchBusiness && matchRegion
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            repository.startLiveTelemetryPulse().collect {
                // background telemetry flow updates state
            }
        }
    }

    fun selectSection(section: ExecutiveNavSection) {
        _uiState.value = _uiState.value.copy(currentSection = section)
    }

    fun selectAsset(asset: GlobalAsset?) {
        _uiState.value = _uiState.value.copy(selectedAsset = asset)
    }

    fun setCommandPaletteOpen(open: Boolean) {
        _uiState.value = _uiState.value.copy(isCommandPaletteOpen = open)
    }

    fun setBoardReportOpen(open: Boolean) {
        _uiState.value = _uiState.value.copy(isBoardReportOpen = open)
    }

    fun setAiAssistantOpen(open: Boolean) {
        _uiState.value = _uiState.value.copy(isAiAssistantOpen = open)
    }

    fun setSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
    }

    fun setBusinessFilter(business: BusinessSegment?) {
        _uiState.value = _uiState.value.copy(
            activeBusinessFilter = if (_uiState.value.activeBusinessFilter == business) null else business
        )
    }

    fun setRegionFilter(region: String?) {
        _uiState.value = _uiState.value.copy(
            activeRegionFilter = if (_uiState.value.activeRegionFilter == region) null else region
        )
    }

    fun setTimePeriod(period: String) {
        _uiState.value = _uiState.value.copy(timePeriod = period)
    }

    fun updateScenarioInput(input: ScenarioInput) {
        repository.applyScenario(input)
    }

    fun resetScenario() {
        repository.resetScenario()
    }

    fun setAiInput(text: String) {
        _uiState.value = _uiState.value.copy(aiAnalystInput = text)
    }

    fun submitAiQuery(query: String) {
        if (query.isBlank()) return
        viewModelScope.launch {
            repository.askExecutiveAnalyst(query)
            _uiState.value = _uiState.value.copy(aiAnalystInput = "")
        }
    }

    fun generateBoardReport() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isGeneratingReport = true)
            kotlinx.coroutines.delay(1200)
            val scenario = scenarioResult.value
            val report = buildString {
                appendLine("BP EXECUTIVE COMMITTEE & BOARD BRIEFING")
                appendLine("CONFIDENTIAL // FOR EXECUTIVE DISCRETION ONLY")
                appendLine("Period: ${_uiState.value.timePeriod} | Classification: [SYNTHETIC DEMO SYSTEM]")
                appendLine("=".repeat(50))
                appendLine()
                appendLine("1. EXECUTIVE SUMMARY & GROUP PERFORMANCE")
                appendLine("• Underlying RC Profit: $8.2bn (+14% vs LY), delivering strong returns across integrated portfolio.")
                appendLine("• Operating Cash Flow: $13.6bn (+9% vs LY), supporting base dividend resilience and selective buybacks.")
                appendLine("• ROACE: 12.6% (target > 12.0%) reflecting capital discipline in Upstream and Downstream.")
                appendLine("• Safety Performance: Total Recordable Injury Rate (TRIR) reduced by -12% to 0.28.")
                appendLine()
                appendLine("2. STRATEGIC PILLARS & TRANSITION PROGRESS")
                appendLine("• Grow Value: Upstream production at 2.30 mboed; Kaskida FID confirmed in Gulf of Mexico.")
                appendLine("• Transition: bp pulse charging network reached 25,480 active bays worldwide (+28% YoY volume).")
                appendLine("• Net Zero 2050: Operational carbon intensity reduced to 13.3 gCO2e/MJ (-35% vs 2019 baseline).")
                appendLine()
                appendLine("3. ENTERPRISE SCENARIO STRESS-TEST (P10/P50/P90)")
                appendLine("• Simulated EBITDA Base/Shock: \$${scenario.simulatedEbitdaBn}bn (P10: \$${scenario.p10EbitdaBn}bn, P90: \$${scenario.p90EbitdaBn}bn).")
                appendLine("• Free Cash Flow buffer maintains dividend commitments at all crude stress levels > \$55/bbl.")
                appendLine()
                appendLine("4. AUDIT & DATA LINEAGE")
                appendLine("• Authoritative Ledger: Group Controller SAP / S4HANA & Digital Twin SCADA Core.")
                appendLine("• Prepared for: Sarah Mitchell, Group Executive.")
            }
            _uiState.value = _uiState.value.copy(
                isGeneratingReport = false,
                reportGeneratedText = report,
                isBoardReportOpen = true
            )
        }
    }
}
