package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = BpLightGreen,
    onPrimary = Color.Black,
    primaryContainer = BpDeepEmerald,
    onPrimaryContainer = Color(0xFFC7F9D4),
    secondary = BpHeliosYellow,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF423700),
    onSecondaryContainer = Color(0xFFFFEFA8),
    tertiary = StatusBlue,
    background = DarkBackground,
    onBackground = TextWhitePrimary,
    surface = DarkSurface,
    onSurface = TextWhitePrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextWhiteSecondary,
    outline = DarkBorder,
    error = StatusRed,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = BpBrandGreen,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD3F8E2),
    onPrimaryContainer = BpDarkForest,
    secondary = BpHeliosGold,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFFFFF2B2),
    onSecondaryContainer = Color(0xFF332900),
    tertiary = Color(0xFF0284C7),
    background = LightBackground,
    onBackground = TextDarkPrimary,
    surface = LightSurface,
    onSurface = TextDarkPrimary,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = TextDarkSecondary,
    outline = LightBorder,
    error = Color(0xFFDC2626),
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to Executive Dark command center aesthetic
    dynamicColor: Boolean = false, // Keep corporate BP branding intact
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
