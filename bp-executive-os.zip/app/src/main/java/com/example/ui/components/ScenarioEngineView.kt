package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ScenarioInput
import com.example.data.model.ScenarioResult
import com.example.ui.theme.*
import kotlin.math.roundToInt

@Composable
fun ScenarioEngineView(
    scenarioInput: ScenarioInput,
    scenarioResult: ScenarioResult,
    onUpdateInput: (ScenarioInput) -> Unit,
    onResetScenario: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(18.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Enterprise Scenario Laboratory & Monte Carlo",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = TagSimulatedBg
                    ) {
                        Text(
                            text = "SIMULATION MODE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp
                            ),
                            color = TagSimulatedText,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Text(
                    text = "Macroeconomic commodity price shocks, transition rate perturbations and free cash flow stress testing",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            OutlinedButton(
                onClick = onResetScenario,
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Reset",
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Reset Baseline")
            }
        }

        // Quick Preset Shock Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Preset Stress Scenarios:",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            AssistChip(
                onClick = { onUpdateInput(ScenarioInput(crudePriceDeltaDollars = -15.0, refineryUtilizationDeltaPct = -3.0)) },
                label = { Text("Crude Shock -$15/bbl") }
            )
            AssistChip(
                onClick = { onUpdateInput(ScenarioInput(gasPriceDeltaDollars = 2.0, carbonPriceDeltaEuro = 15.0)) },
                label = { Text("EU Gas Spike +$2/MMBtu") }
            )
            AssistChip(
                onClick = { onUpdateInput(ScenarioInput(evAdoptionGrowthDeltaPct = 25.0, fuelDemandDeltaPct = -6.0)) },
                label = { Text("Accelerated Transition +25% EV") }
            )
        }

        // Sliders Card & Outcomes Comparison in Split View
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Left: Parameter Sliders
            Card(
                modifier = Modifier.weight(1.2f),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "Macroeconomic & Operational Levers",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    // 1. Brent Crude Oil Delta
                    ScenarioSliderItem(
                        label = "Brent Crude Benchmark Delta",
                        valueDisplay = "${if (scenarioInput.crudePriceDeltaDollars >= 0) "+" else ""}${String.format("%.1f", scenarioInput.crudePriceDeltaDollars)} $/bbl",
                        sliderValue = scenarioInput.crudePriceDeltaDollars.toFloat(),
                        valueRange = -30f..30f,
                        onValueChange = { onUpdateInput(scenarioInput.copy(crudePriceDeltaDollars = it.toDouble())) }
                    )

                    // 2. Henry Hub Gas Delta
                    ScenarioSliderItem(
                        label = "Natural Gas (Henry Hub / TTF) Delta",
                        valueDisplay = "${if (scenarioInput.gasPriceDeltaDollars >= 0) "+" else ""}${String.format("%.2f", scenarioInput.gasPriceDeltaDollars)} $/MMBtu",
                        sliderValue = scenarioInput.gasPriceDeltaDollars.toFloat(),
                        valueRange = -3f..5f,
                        onValueChange = { onUpdateInput(scenarioInput.copy(gasPriceDeltaDollars = it.toDouble())) }
                    )

                    // 3. bp pulse EV Adoption Growth Delta
                    ScenarioSliderItem(
                        label = "bp pulse EV Fleet Adoption Growth",
                        valueDisplay = "${if (scenarioInput.evAdoptionGrowthDeltaPct >= 0) "+" else ""}${scenarioInput.evAdoptionGrowthDeltaPct.roundToInt()} %",
                        sliderValue = scenarioInput.evAdoptionGrowthDeltaPct.toFloat(),
                        valueRange = -20f..50f,
                        onValueChange = { onUpdateInput(scenarioInput.copy(evAdoptionGrowthDeltaPct = it.toDouble())) }
                    )

                    // 4. Global Refinery Utilization Delta
                    ScenarioSliderItem(
                        label = "Refinery Utilization Capacity Delta",
                        valueDisplay = "${if (scenarioInput.refineryUtilizationDeltaPct >= 0) "+" else ""}${scenarioInput.refineryUtilizationDeltaPct.roundToInt()} %",
                        sliderValue = scenarioInput.refineryUtilizationDeltaPct.toFloat(),
                        valueRange = -15f..10f,
                        onValueChange = { onUpdateInput(scenarioInput.copy(refineryUtilizationDeltaPct = it.toDouble())) }
                    )
                }
            }

            // Right: Enterprise Outcome Summary & Monte Carlo
            Card(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Simulated Financial Outcomes",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    // Metric Comparison Rows
                    OutcomeComparisonRow(
                        label = "Underlying RC EBITDA",
                        base = "$${scenarioResult.originalEbitdaBn} bn",
                        simulated = "$${scenarioResult.simulatedEbitdaBn} bn",
                        delta = "${if (scenarioResult.simulatedEbitdaBn >= scenarioResult.originalEbitdaBn) "+" else ""}${String.format("%.2f", scenarioResult.simulatedEbitdaBn - scenarioResult.originalEbitdaBn)} bn",
                        isPositive = scenarioResult.simulatedEbitdaBn >= scenarioResult.originalEbitdaBn
                    )

                    OutcomeComparisonRow(
                        label = "Operating Cash Flow",
                        base = "$${scenarioResult.originalCashFlowBn} bn",
                        simulated = "$${scenarioResult.simulatedCashFlowBn} bn",
                        delta = "${if (scenarioResult.simulatedCashFlowBn >= scenarioResult.originalCashFlowBn) "+" else ""}${String.format("%.2f", scenarioResult.simulatedCashFlowBn - scenarioResult.originalCashFlowBn)} bn",
                        isPositive = scenarioResult.simulatedCashFlowBn >= scenarioResult.originalCashFlowBn
                    )

                    OutcomeComparisonRow(
                        label = "Return on Avg Capital (ROACE)",
                        base = "${scenarioResult.originalRoacePct}%",
                        simulated = "${scenarioResult.simulatedRoacePct}%",
                        delta = "${if (scenarioResult.simulatedRoacePct >= scenarioResult.originalRoacePct) "+" else ""}${String.format("%.1f", scenarioResult.simulatedRoacePct - scenarioResult.originalRoacePct)}pp",
                        isPositive = scenarioResult.simulatedRoacePct >= scenarioResult.originalRoacePct
                    )

                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

                    // Monte Carlo P10 / P50 / P90 Distribution
                    Text(
                        text = "Monte Carlo 10,000 Iterations (P10 / P50 / P90)",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MonteCarloPill("P10 (Stress)", "$${scenarioResult.p10EbitdaBn}bn", StatusAmber)
                        MonteCarloPill("P50 (Median)", "$${scenarioResult.p50EbitdaBn}bn", BpLightGreen)
                        MonteCarloPill("P90 (Upside)", "$${scenarioResult.p90EbitdaBn}bn", StatusCyan)
                    }
                }
            }
        }

        // Causal Chain Propagation View (Master Section 35)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "Dynamic Causal Propagation Chain",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Step-by-step transmission of macroeconomic price shock through operating divisions",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(14.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    scenarioResult.propagationSteps.forEach { step ->
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Surface(
                                        modifier = Modifier.size(24.dp),
                                        shape = CircleShape,
                                        color = BpBrandGreen
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = "${step.stepOrder}",
                                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                                color = Color.White
                                            )
                                        }
                                    }
                                    Column {
                                        Text(
                                            text = step.nodeName,
                                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = step.impactDescription,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Text(
                                    text = step.deltaAmount,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = if (step.isNegative) StatusRed else StatusGreen
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Executive Strategic Implications:",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(6.dp))

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    scenarioResult.strategicImplications.forEach { impl ->
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Text("•", color = BpLightGreen, fontWeight = FontWeight.Bold)
                            Text(
                                text = impl,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ScenarioSliderItem(
    label: String,
    valueDisplay: String,
    sliderValue: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = valueDisplay,
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = BpLightGreen
            )
        }
        Slider(
            value = sliderValue,
            onValueChange = onValueChange,
            valueRange = valueRange,
            colors = SliderDefaults.colors(
                thumbColor = BpLightGreen,
                activeTrackColor = BpBrandGreen,
                inactiveTrackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
            )
        )
    }
}

@Composable
private fun OutcomeComparisonRow(
    label: String,
    base: String,
    simulated: String,
    delta: String,
    isPositive: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1.4f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "Base: $base",
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
            )
        }
        Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f)) {
            Text(
                text = simulated,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = delta,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = if (isPositive) StatusGreen else StatusRed
                )
            )
        }
    }
}

@Composable
private fun MonteCarloPill(label: String, value: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = color.copy(alpha = 0.15f),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                color = color
            )
        }
    }
}
