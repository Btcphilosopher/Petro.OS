package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BusinessSegment
import com.example.data.model.GlobalAsset
import com.example.ui.theme.*

@Composable
fun GlobalOperationsMap(
    assets: List<GlobalAsset>,
    selectedAsset: GlobalAsset?,
    onSelectAsset: (GlobalAsset) -> Unit,
    onViewOperationsOverview: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "map_pulse")
    val pulseRadius by infiniteTransition.animateFloat(
        initialValue = 4f,
        targetValue = 16f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_r"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_a"
    )

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Global Operations",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = StatusGreen.copy(alpha = 0.2f)
                    ) {
                        Box(
                            modifier = Modifier
                                .padding(4.dp)
                                .size(6.dp)
                                .background(StatusGreen, CircleShape)
                        )
                    }
                    Text(
                        text = "25 Active Basins",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Canvas World Map Area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(assets) {
                            detectTapGestures { tapOffset ->
                                val w = size.width.toFloat()
                                val h = size.height.toFloat()
                                // Find closest asset node
                                val tapped = assets.minByOrNull { asset ->
                                    val (px, py) = latLngToCanvas(asset.lat, asset.lng, w, h)
                                    val distSq = (px - tapOffset.x) * (px - tapOffset.x) + (py - tapOffset.y) * (py - tapOffset.y)
                                    distSq
                                }
                                if (tapped != null) {
                                    val (px, py) = latLngToCanvas(tapped.lat, tapped.lng, w, h)
                                    val dist = Math.hypot((px - tapOffset.x).toDouble(), (py - tapOffset.y).toDouble())
                                    if (dist < 32.0) {
                                        onSelectAsset(tapped)
                                    }
                                }
                            }
                        }
                ) {
                    val w = size.width
                    val h = size.height

                    // Subtle coordinate grid lines
                    val gridColor = Color(0x1870A080)
                    for (i in 1..5) {
                        val y = h * (i / 6f)
                        drawLine(gridColor, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
                    }
                    for (i in 1..8) {
                        val x = w * (i / 9f)
                        drawLine(gridColor, Offset(x, 0f), Offset(x, h), strokeWidth = 1f)
                    }

                    // Stylized vector continent silhouettes
                    val continentColor = Color(0x3580A090)
                    // North America
                    drawPath(
                        path = Path().apply {
                            moveTo(w * 0.12f, h * 0.22f)
                            lineTo(w * 0.28f, h * 0.18f)
                            lineTo(w * 0.32f, h * 0.34f)
                            lineTo(w * 0.26f, h * 0.48f)
                            lineTo(w * 0.18f, h * 0.44f)
                            lineTo(w * 0.12f, h * 0.32f)
                            close()
                        },
                        color = continentColor
                    )
                    // South America
                    drawPath(
                        path = Path().apply {
                            moveTo(w * 0.26f, h * 0.52f)
                            lineTo(w * 0.35f, h * 0.56f)
                            lineTo(w * 0.32f, h * 0.82f)
                            lineTo(w * 0.26f, h * 0.72f)
                            close()
                        },
                        color = continentColor
                    )
                    // Europe & UK
                    drawPath(
                        path = Path().apply {
                            moveTo(w * 0.44f, h * 0.20f)
                            lineTo(w * 0.54f, h * 0.18f)
                            lineTo(w * 0.56f, h * 0.36f)
                            lineTo(w * 0.46f, h * 0.38f)
                            close()
                        },
                        color = continentColor
                    )
                    // Africa
                    drawPath(
                        path = Path().apply {
                            moveTo(w * 0.46f, h * 0.40f)
                            lineTo(w * 0.58f, h * 0.42f)
                            lineTo(w * 0.54f, h * 0.74f)
                            lineTo(w * 0.46f, h * 0.58f)
                            close()
                        },
                        color = continentColor
                    )
                    // Asia & Middle East
                    drawPath(
                        path = Path().apply {
                            moveTo(w * 0.56f, h * 0.20f)
                            lineTo(w * 0.84f, h * 0.22f)
                            lineTo(w * 0.82f, h * 0.48f)
                            lineTo(w * 0.68f, h * 0.50f)
                            lineTo(w * 0.58f, h * 0.38f)
                            close()
                        },
                        color = continentColor
                    )
                    // Australia
                    drawPath(
                        path = Path().apply {
                            moveTo(w * 0.78f, h * 0.64f)
                            lineTo(w * 0.88f, h * 0.66f)
                            lineTo(w * 0.86f, h * 0.82f)
                            lineTo(w * 0.76f, h * 0.78f)
                            close()
                        },
                        color = continentColor
                    )

                    // Draw Asset Pins
                    assets.forEach { asset ->
                        val (px, py) = latLngToCanvas(asset.lat, asset.lng, w, h)
                        val isSel = asset.id == selectedAsset?.id
                        val nodeColor = when (asset.business) {
                            BusinessSegment.UPSTREAM -> BpLightGreen
                            BusinessSegment.DOWNSTREAM -> BpHeliosYellow
                            BusinessSegment.LOW_CARBON -> StatusCyan
                            BusinessSegment.TRADING -> StatusPurple
                            BusinessSegment.CORPORATE -> StatusBlue
                        }

                        // Pulse circle for selected or key assets
                        if (isSel) {
                            drawCircle(
                                color = nodeColor.copy(alpha = pulseAlpha),
                                radius = pulseRadius * 2f,
                                center = Offset(px, py)
                            )
                        }

                        // Outer ring
                        drawCircle(
                            color = if (isSel) Color.White else nodeColor,
                            radius = if (isSel) 6f else 4.5f,
                            center = Offset(px, py)
                        )
                        // Inner core
                        drawCircle(
                            color = if (isSel) nodeColor else Color(0xFF03140C),
                            radius = if (isSel) 3.5f else 2f,
                            center = Offset(px, py)
                        )
                    }
                }

                // Interactive Selected Asset Chip Overlay
                if (selectedAsset != null) {
                    Surface(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(8.dp),
                        shape = RoundedCornerShape(6.dp),
                        color = BpDarkForest.copy(alpha = 0.92f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BpLightGreen)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .background(BpLightGreen, CircleShape)
                            )
                            Text(
                                text = "${selectedAsset.name} • ${selectedAsset.netProductionDisplay}",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                color = Color.White
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Three Key Stats below Map
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                StatColumn(
                    label = "Operations in",
                    value = "25",
                    sub = "Countries"
                )
                StatColumn(
                    label = "Employees",
                    value = "~70,600",
                    sub = "Global workforce"
                )
                StatColumn(
                    label = "Upstream Production",
                    value = "2.3",
                    sub = "mboed"
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            TextButton(
                onClick = onViewOperationsOverview,
                contentPadding = PaddingValues(0.dp)
            ) {
                Text(
                    text = "View operations overview →",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = BpLightGreen
                )
            }
        }
    }
}

private fun latLngToCanvas(lat: Float, lng: Float, width: Float, height: Float): Pair<Float, Float> {
    // Equirectangular projection
    val x = ((lng + 180f) / 360f) * width
    val y = ((90f - lat) / 180f) * height
    return Pair(x.coerceIn(8f, width - 8f), y.coerceIn(8f, height - 8f))
}

@Composable
private fun StatColumn(
    label: String,
    value: String,
    sub: String
) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = sub,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
        )
    }
}
