package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AssetStatus
import com.example.data.model.EVHubNode
import com.example.data.model.RefineryUnit
import com.example.ui.theme.*

@Composable
fun DigitalTwinViewer(
    refineryUnits: List<RefineryUnit>,
    evHubs: List<EVHubNode>,
    modifier: Modifier = Modifier
) {
    var selectedTwinTab by remember { mutableStateOf(0) } // 0 = Whiting Refinery Complex, 1 = bp pulse Mega-Hub
    var selectedUnit by remember { mutableStateOf<RefineryUnit?>(refineryUnits.firstOrNull()) }

    val infiniteTransition = rememberInfiniteTransition(label = "twin_flow")
    val flowOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 60f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "flow_anim"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(18.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Twin Header Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Industrial Digital Twin Core",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = TagModelledBg
                    ) {
                        Text(
                            text = "LIVE SCADA TELEMETRY",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp
                            ),
                            color = TagModelledText,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Text(
                    text = "Physics-based 3D schematic and telemetry state of critical enterprise assets",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Tab Selector
            SingleChoiceSegmentedButtonRow {
                SegmentedButton(
                    selected = selectedTwinTab == 0,
                    onClick = { selectedTwinTab = 0 },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                ) {
                    Text("Whiting Refinery (435k bpd)")
                }
                SegmentedButton(
                    selected = selectedTwinTab == 1,
                    onClick = { selectedTwinTab = 1 },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                ) {
                    Text("bp pulse Mega-Hub")
                }
            }
        }

        if (selectedTwinTab == 0) {
            // WHITING REFINERY DIGITAL TWIN
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Whiting Complex Process Flow Simulation",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Throughput: 412,000 bpd • 94.7% Util",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = BpLightGreen
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 2.5D Animated Process Flow Schematic Canvas
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(240.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF06110B))
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height

                            // Draw process interconnect pipelines
                            val pipeColor = Color(0xFF1B3D2B)
                            val activeFlowColor = BpLightGreen

                            // Main Feed Line
                            drawLine(pipeColor, Offset(w * 0.05f, h * 0.5f), Offset(w * 0.25f, h * 0.5f), strokeWidth = 6f)
                            drawLine(pipeColor, Offset(w * 0.25f, h * 0.5f), Offset(w * 0.5f, h * 0.25f), strokeWidth = 5f)
                            drawLine(pipeColor, Offset(w * 0.25f, h * 0.5f), Offset(w * 0.5f, h * 0.5f), strokeWidth = 5f)
                            drawLine(pipeColor, Offset(w * 0.25f, h * 0.5f), Offset(w * 0.5f, h * 0.75f), strokeWidth = 5f)
                            drawLine(pipeColor, Offset(w * 0.5f, h * 0.25f), Offset(w * 0.8f, h * 0.35f), strokeWidth = 5f)
                            drawLine(pipeColor, Offset(w * 0.5f, h * 0.5f), Offset(w * 0.8f, h * 0.35f), strokeWidth = 5f)
                            drawLine(pipeColor, Offset(w * 0.5f, h * 0.75f), Offset(w * 0.8f, h * 0.65f), strokeWidth = 5f)
                            drawLine(pipeColor, Offset(w * 0.8f, h * 0.35f), Offset(w * 0.95f, h * 0.5f), strokeWidth = 6f)
                            drawLine(pipeColor, Offset(w * 0.8f, h * 0.65f), Offset(w * 0.95f, h * 0.5f), strokeWidth = 6f)

                            // Animated Flow Pulses
                            for (step in 0..5) {
                                val pulseX = (w * 0.05f + (flowOffset + step * 40f) % (w * 0.2f))
                                drawCircle(activeFlowColor, radius = 3.5f, center = Offset(pulseX, h * 0.5f))
                            }

                            // CDU Tower Box (Column 1)
                            drawRoundRect(
                                color = Color(0xFF0F261B),
                                topLeft = Offset(w * 0.20f, h * 0.25f),
                                size = Size(w * 0.12f, h * 0.5f),
                                cornerRadius = CornerRadius(6f, 6f)
                            )
                            drawRoundRect(
                                color = BpLightGreen,
                                topLeft = Offset(w * 0.20f, h * 0.25f),
                                size = Size(w * 0.12f, h * 0.5f),
                                cornerRadius = CornerRadius(6f, 6f),
                                style = Stroke(width = 2f)
                            )

                            // FCC Unit Box (Top middle)
                            drawRoundRect(
                                color = Color(0xFF0F261B),
                                topLeft = Offset(w * 0.44f, h * 0.10f),
                                size = Size(w * 0.12f, h * 0.3f),
                                cornerRadius = CornerRadius(6f, 6f)
                            )
                            drawRoundRect(
                                color = BpHeliosYellow,
                                topLeft = Offset(w * 0.44f, h * 0.10f),
                                size = Size(w * 0.12f, h * 0.3f),
                                cornerRadius = CornerRadius(6f, 6f),
                                style = Stroke(width = 2f)
                            )

                            // Hydrocracker Box (Center middle)
                            drawRoundRect(
                                color = Color(0xFF0F261B),
                                topLeft = Offset(w * 0.44f, h * 0.42f),
                                size = Size(w * 0.12f, h * 0.25f),
                                cornerRadius = CornerRadius(6f, 6f)
                            )
                            drawRoundRect(
                                color = StatusCyan,
                                topLeft = Offset(w * 0.44f, h * 0.42f),
                                size = Size(w * 0.12f, h * 0.25f),
                                cornerRadius = CornerRadius(6f, 6f),
                                style = Stroke(width = 2f)
                            )

                            // Delayed Coker Box (Bottom middle)
                            drawRoundRect(
                                color = Color(0xFF0F261B),
                                topLeft = Offset(w * 0.44f, h * 0.68f),
                                size = Size(w * 0.12f, h * 0.25f),
                                cornerRadius = CornerRadius(6f, 6f)
                            )
                            drawRoundRect(
                                color = StatusAmber,
                                topLeft = Offset(w * 0.44f, h * 0.68f),
                                size = Size(w * 0.12f, h * 0.25f),
                                cornerRadius = CornerRadius(6f, 6f),
                                style = Stroke(width = 2f)
                            )

                            // Product Blending / Storage (Right)
                            drawRoundRect(
                                color = Color(0xFF0F261B),
                                topLeft = Offset(w * 0.74f, h * 0.28f),
                                size = Size(w * 0.14f, h * 0.45f),
                                cornerRadius = CornerRadius(6f, 6f)
                            )
                            drawRoundRect(
                                color = Color.White.copy(alpha = 0.6f),
                                topLeft = Offset(w * 0.74f, h * 0.28f),
                                size = Size(w * 0.14f, h * 0.45f),
                                cornerRadius = CornerRadius(6f, 6f),
                                style = Stroke(width = 2f)
                            )
                        }

                        // Labels overlay
                        Box(
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .padding(start = 12.dp)
                        ) {
                            Text(
                                text = "Crude Intake\n412k bpd",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                ),
                                color = TextWhitePrimary
                            )
                        }

                        Box(
                            modifier = Modifier
                                .align(Alignment.CenterEnd)
                                .padding(end = 12.dp)
                        ) {
                            Text(
                                text = "Finished Fuels\nGasoline / SAF / Diesel",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                ),
                                color = TextWhitePrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Process Units Telemetry Cards Grid
                    Text(
                        text = "Operating Units Live Telemetry",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        refineryUnits.forEach { unit ->
                            val isSel = unit.id == selectedUnit?.id
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { selectedUnit = unit },
                                color = if (isSel) BpDeepEmerald.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(8.dp),
                                border = if (isSel) androidx.compose.foundation.BorderStroke(1.dp, BpLightGreen) else null
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1.5f)) {
                                        Text(
                                            text = unit.name,
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = "Capacity: ${unit.capacityBpd} bpd • RUL: ${unit.remainingUsefulDays} days",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    // Throughput & Util
                                    Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${unit.currentThroughputBpd} bpd",
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = "${unit.utilizationPct}% Util",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.SemiBold,
                                                color = if (unit.utilizationPct > 90) StatusGreen else StatusAmber
                                            )
                                        )
                                    }

                                    // Temp / Pressure Telemetry
                                    Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1.2f)) {
                                        Text(
                                            text = "${unit.temperatureC}°C • ${unit.pressurePsi} psi",
                                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = "Vibration: ${unit.vibrationMmS} mm/s",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = if (unit.vibrationMmS > 3.0) StatusAmber else StatusGreen
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // BP PULSE MEGA-HUB DIGITAL TWIN
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "bp pulse High-Power Superhub Telemetry",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Global Network: 25,480 Active Bays • 99.6% Uptime",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = StatusCyan
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        evHubs.forEach { hub ->
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1.4f)) {
                                        Text(
                                            text = hub.locationName,
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = "${hub.totalBays} Bays (${hub.activeChargingBays} Charging) • ${hub.peakPowerKw} kW Ultra-Fast",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${hub.energyDeliveredMwhToday} MWh",
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                            color = StatusCyan
                                        )
                                        Text(
                                            text = "Today's Energy",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "$${String.format("%,.0f", hub.revenueTodayUsd)}",
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                            color = BpLightGreen
                                        )
                                        Text(
                                            text = "Revenue (YTD Day)",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
