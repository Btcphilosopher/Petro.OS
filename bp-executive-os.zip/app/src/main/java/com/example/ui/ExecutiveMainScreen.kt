package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.ExecutiveViewModel

@Composable
fun ExecutiveMainScreen(
    viewModel: ExecutiveViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val marketSnapshots by viewModel.marketSnapshots.collectAsStateWithLifecycle()
    val assets by viewModel.filteredAssets.collectAsStateWithLifecycle()
    val scenarioInput by viewModel.currentScenarioInput.collectAsStateWithLifecycle()
    val scenarioResult by viewModel.scenarioResult.collectAsStateWithLifecycle()
    val risks by viewModel.risks.collectAsStateWithLifecycle()
    val anomalies by viewModel.anomalies.collectAsStateWithLifecycle()
    val refineryUnits by viewModel.refineryUnits.collectAsStateWithLifecycle()
    val evHubs by viewModel.evHubs.collectAsStateWithLifecycle()
    val aiHistory by viewModel.aiAnalystHistory.collectAsStateWithLifecycle()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Left Sidebar
            ExecutiveSidebar(
                currentSection = uiState.currentSection,
                marketSnapshots = marketSnapshots,
                onSelectSection = { viewModel.selectSection(it) }
            )

            // Right Main Content Canvas
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                // Top Header Bar
                ExecutiveHeaderBar(
                    searchQuery = uiState.searchQuery,
                    onSearchClick = { viewModel.setCommandPaletteOpen(true) },
                    onAiAssistantClick = { viewModel.setAiAssistantOpen(true) },
                    onBoardReportClick = { viewModel.generateBoardReport() },
                    onBriefingsClick = { viewModel.selectSection(ExecutiveNavSection.OVERVIEW) }
                )

                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))

                // Active Workspace Content
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    when (uiState.currentSection) {
                        ExecutiveNavSection.OVERVIEW -> {
                            OverviewDashboard(
                                assets = assets,
                                selectedAsset = uiState.selectedAsset,
                                onSelectAsset = { viewModel.selectAsset(it) },
                                strategicPriorities = viewModel.strategicPriorities,
                                carbonPoints = viewModel.carbonProgressPoints,
                                cashFlowAllocations = viewModel.cashFlowAllocations,
                                highlights = viewModel.enterpriseHighlights,
                                briefings = viewModel.executiveBriefings,
                                onNavigate = { viewModel.selectSection(it) }
                            )
                        }
                        ExecutiveNavSection.STRATEGY -> {
                            OverviewDashboard(
                                assets = assets,
                                selectedAsset = uiState.selectedAsset,
                                onSelectAsset = { viewModel.selectAsset(it) },
                                strategicPriorities = viewModel.strategicPriorities,
                                carbonPoints = viewModel.carbonProgressPoints,
                                cashFlowAllocations = viewModel.cashFlowAllocations,
                                highlights = viewModel.enterpriseHighlights,
                                briefings = viewModel.executiveBriefings,
                                onNavigate = { viewModel.selectSection(it) }
                            )
                        }
                        ExecutiveNavSection.UPSTREAM -> {
                            UpstreamSegmentView(
                                assets = assets,
                                onSelectAsset = { viewModel.selectAsset(it) }
                            )
                        }
                        ExecutiveNavSection.DOWNSTREAM -> {
                            DownstreamSegmentView(
                                assets = assets,
                                onSelectAsset = { viewModel.selectAsset(it) },
                                onOpenDigitalTwin = { viewModel.selectSection(ExecutiveNavSection.DIGITAL_TWIN) }
                            )
                        }
                        ExecutiveNavSection.TRADING -> {
                            TradingTerminalView()
                        }
                        ExecutiveNavSection.LOW_CARBON -> {
                            LowCarbonSegmentView(
                                assets = assets,
                                onSelectAsset = { viewModel.selectAsset(it) }
                            )
                        }
                        ExecutiveNavSection.FINANCE -> {
                            FinancialPnlView(
                                cashFlowAllocations = viewModel.cashFlowAllocations,
                                onGenerateBoardPack = { viewModel.generateBoardReport() }
                            )
                        }
                        ExecutiveNavSection.PEOPLE -> {
                            PeopleAndSafetySegmentView()
                        }
                        ExecutiveNavSection.SAFETY_SUSTAINABILITY -> {
                            PeopleAndSafetySegmentView()
                        }
                        ExecutiveNavSection.RISK -> {
                            RiskHeatmapView(
                                risks = risks,
                                anomalies = anomalies
                            )
                        }
                        ExecutiveNavSection.DIGITAL_TWIN -> {
                            DigitalTwinViewer(
                                refineryUnits = refineryUnits,
                                evHubs = evHubs
                            )
                        }
                        ExecutiveNavSection.SCENARIO -> {
                            ScenarioEngineView(
                                scenarioInput = scenarioInput,
                                scenarioResult = scenarioResult,
                                onUpdateInput = { viewModel.updateScenarioInput(it) },
                                onResetScenario = { viewModel.resetScenario() }
                            )
                        }
                        ExecutiveNavSection.REPORTS -> {
                            FinancialPnlView(
                                cashFlowAllocations = viewModel.cashFlowAllocations,
                                onGenerateBoardPack = { viewModel.generateBoardReport() }
                            )
                        }
                    }
                }
            }
        }

        // Modals & Overlays
        if (uiState.isAiAssistantOpen) {
            AiExecutiveAssistantDialog(
                history = aiHistory,
                inputText = uiState.aiAnalystInput,
                onInputChange = { viewModel.setAiInput(it) },
                onSubmit = { viewModel.submitAiQuery(it) },
                onDismiss = { viewModel.setAiAssistantOpen(false) }
            )
        }

        if (uiState.selectedAsset != null) {
            AssetDetailDialog(
                asset = uiState.selectedAsset!!,
                onOpenDigitalTwin = {
                    viewModel.selectSection(ExecutiveNavSection.DIGITAL_TWIN)
                },
                onDismiss = { viewModel.selectAsset(null) }
            )
        }

        if (uiState.isBoardReportOpen) {
            BoardReportDialog(
                reportText = uiState.reportGeneratedText,
                isGenerating = uiState.isGeneratingReport,
                onGenerate = { viewModel.generateBoardReport() },
                onDismiss = { viewModel.setBoardReportOpen(false) }
            )
        }

        if (uiState.isCommandPaletteOpen) {
            CommandPaletteDialog(
                query = uiState.searchQuery,
                onQueryChange = { viewModel.setSearchQuery(it) },
                assets = assets,
                onSelectAsset = { viewModel.selectAsset(it) },
                onDismiss = { viewModel.setCommandPaletteOpen(false) }
            )
        }
    }
}

@Composable
private fun OverviewDashboard(
    assets: List<GlobalAsset>,
    selectedAsset: GlobalAsset?,
    onSelectAsset: (GlobalAsset) -> Unit,
    strategicPriorities: List<StrategicPriority>,
    carbonPoints: List<CarbonProgressPoint>,
    cashFlowAllocations: List<CashFlowAllocation>,
    highlights: List<EnterpriseHighlight>,
    briefings: List<ExecutiveBriefing>,
    onNavigate: (ExecutiveNavSection) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxSize()
            .padding(18.dp)
            .verticalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Left Column (58% width): Group Performance, Key Highlights, Operations & Projects
        Column(
            modifier = Modifier.weight(1.35f),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            GroupPerformanceCard(
                onViewDetail = { onNavigate(ExecutiveNavSection.FINANCE) }
            )

            KeyHighlightsCard(
                highlights = highlights,
                onViewAllNews = { onNavigate(ExecutiveNavSection.UPSTREAM) }
            )

            OperationsAndProjectsCard(
                assets = assets,
                onSelectAsset = onSelectAsset
            )
        }

        // Right Column (42% width): Global Operations Map, Strategic Priorities, Net Zero, Cash Flow Allocation, My Briefings
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            GlobalOperationsMap(
                assets = assets,
                selectedAsset = selectedAsset,
                onSelectAsset = onSelectAsset,
                onViewOperationsOverview = { onNavigate(ExecutiveNavSection.UPSTREAM) }
            )

            StrategicPrioritiesCard(
                priorities = strategicPriorities,
                onViewDashboard = { onNavigate(ExecutiveNavSection.STRATEGY) }
            )

            NetZeroProgressCard(
                carbonPoints = carbonPoints,
                onViewSustainability = { onNavigate(ExecutiveNavSection.SAFETY_SUSTAINABILITY) }
            )

            CashFlowAllocationCard(
                allocations = cashFlowAllocations,
                onViewFramework = { onNavigate(ExecutiveNavSection.FINANCE) }
            )

            MyBriefingsCard(
                briefings = briefings,
                onViewCalendar = { onNavigate(ExecutiveNavSection.REPORTS) }
            )
        }
    }
}
