package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ExecutiveNavSection
import com.example.data.model.MarketSnapshotItem
import com.example.ui.theme.*

@Composable
fun ExecutiveSidebar(
    currentSection: ExecutiveNavSection,
    marketSnapshots: List<MarketSnapshotItem>,
    onSelectSection: (ExecutiveNavSection) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .width(260.dp)
            .fillMaxHeight(),
        color = BpDarkForest,
        contentColor = TextWhitePrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(vertical = 16.dp, horizontal = 14.dp)
        ) {
            // BP Brand & Helios Logo Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .padding(horizontal = 8.dp, vertical = 6.dp)
                    .clickable { onSelectSection(ExecutiveNavSection.OVERVIEW) }
            ) {
                // Helios Sunburst Emblem
                Surface(
                    modifier = Modifier.size(34.dp),
                    shape = CircleShape,
                    color = Color.Transparent
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Surface(
                            modifier = Modifier.size(28.dp),
                            shape = CircleShape,
                            color = BpBrandGreen
                        ) {}
                        Surface(
                            modifier = Modifier.size(16.dp),
                            shape = CircleShape,
                            color = BpHeliosYellow
                        ) {}
                        Surface(
                            modifier = Modifier.size(8.dp),
                            shape = CircleShape,
                            color = Color.White
                        ) {}
                    }
                }

                Text(
                    text = "bp",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 28.sp,
                        letterSpacing = (-1).sp
                    ),
                    color = BpLightGreen
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Navigation Items Scrollable List
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                NavItemRow(
                    section = ExecutiveNavSection.OVERVIEW,
                    icon = Icons.Filled.Home,
                    isSelected = currentSection == ExecutiveNavSection.OVERVIEW,
                    onClick = { onSelectSection(ExecutiveNavSection.OVERVIEW) }
                )
                NavItemRow(
                    section = ExecutiveNavSection.STRATEGY,
                    icon = Icons.Outlined.TrendingUp,
                    isSelected = currentSection == ExecutiveNavSection.STRATEGY,
                    onClick = { onSelectSection(ExecutiveNavSection.STRATEGY) }
                )
                NavItemRow(
                    section = ExecutiveNavSection.UPSTREAM,
                    icon = Icons.Outlined.Waves,
                    isSelected = currentSection == ExecutiveNavSection.UPSTREAM,
                    onClick = { onSelectSection(ExecutiveNavSection.UPSTREAM) }
                )
                NavItemRow(
                    section = ExecutiveNavSection.DOWNSTREAM,
                    icon = Icons.Outlined.LocalGasStation,
                    isSelected = currentSection == ExecutiveNavSection.DOWNSTREAM,
                    onClick = { onSelectSection(ExecutiveNavSection.DOWNSTREAM) }
                )
                NavItemRow(
                    section = ExecutiveNavSection.TRADING,
                    icon = Icons.Outlined.DirectionsBoat,
                    isSelected = currentSection == ExecutiveNavSection.TRADING,
                    onClick = { onSelectSection(ExecutiveNavSection.TRADING) }
                )
                NavItemRow(
                    section = ExecutiveNavSection.LOW_CARBON,
                    icon = Icons.Outlined.ElectricBolt,
                    isSelected = currentSection == ExecutiveNavSection.LOW_CARBON,
                    onClick = { onSelectSection(ExecutiveNavSection.LOW_CARBON) }
                )
                NavItemRow(
                    section = ExecutiveNavSection.FINANCE,
                    icon = Icons.Outlined.AccountBalance,
                    isSelected = currentSection == ExecutiveNavSection.FINANCE,
                    onClick = { onSelectSection(ExecutiveNavSection.FINANCE) }
                )
                NavItemRow(
                    section = ExecutiveNavSection.PEOPLE,
                    icon = Icons.Outlined.Groups,
                    isSelected = currentSection == ExecutiveNavSection.PEOPLE,
                    onClick = { onSelectSection(ExecutiveNavSection.PEOPLE) }
                )
                NavItemRow(
                    section = ExecutiveNavSection.SAFETY_SUSTAINABILITY,
                    icon = Icons.Outlined.Security,
                    isSelected = currentSection == ExecutiveNavSection.SAFETY_SUSTAINABILITY,
                    onClick = { onSelectSection(ExecutiveNavSection.SAFETY_SUSTAINABILITY) }
                )
                NavItemRow(
                    section = ExecutiveNavSection.RISK,
                    icon = Icons.Outlined.WarningAmber,
                    isSelected = currentSection == ExecutiveNavSection.RISK,
                    onClick = { onSelectSection(ExecutiveNavSection.RISK) }
                )
                NavItemRow(
                    section = ExecutiveNavSection.DIGITAL_TWIN,
                    icon = Icons.Outlined.ViewInAr,
                    isSelected = currentSection == ExecutiveNavSection.DIGITAL_TWIN,
                    onClick = { onSelectSection(ExecutiveNavSection.DIGITAL_TWIN) }
                )
                NavItemRow(
                    section = ExecutiveNavSection.SCENARIO,
                    icon = Icons.Outlined.Tune,
                    isSelected = currentSection == ExecutiveNavSection.SCENARIO,
                    onClick = { onSelectSection(ExecutiveNavSection.SCENARIO) }
                )
                NavItemRow(
                    section = ExecutiveNavSection.REPORTS,
                    icon = Icons.Outlined.Assignment,
                    isSelected = currentSection == ExecutiveNavSection.REPORTS,
                    onClick = { onSelectSection(ExecutiveNavSection.REPORTS) }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Market Snapshot Card at Bottom of Sidebar
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFF03100A),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF132A1E))
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Market Snapshot",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextWhitePrimary,
                                fontSize = 12.sp
                            )
                        )
                        Text(
                            text = "09:30 BST",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextWhiteMuted,
                                fontSize = 10.sp
                            )
                        )
                    }

                    marketSnapshots.take(5).forEach { item ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = item.name,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 11.sp,
                                    color = TextWhiteSecondary
                                )
                            )
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${item.currencySymbol}${String.format("%.2f", item.price)}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 11.sp,
                                        color = TextWhitePrimary
                                    )
                                )
                                Text(
                                    text = "${if (item.changePercent >= 0) "+" else ""}${String.format("%.2f", item.changePercent)}%",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp,
                                        color = if (item.changePercent >= 0) StatusGreen else StatusRed
                                    )
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Footer Motto
            Column(modifier = Modifier.padding(horizontal = 6.dp)) {
                Text(
                    text = "bp",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = BpLightGreen
                    )
                )
                Text(
                    text = "Reimagining energy for people and our planet",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 10.sp,
                        color = TextWhiteMuted
                    )
                )
            }
        }
    }
}

@Composable
private fun NavItemRow(
    section: ExecutiveNavSection,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val bg by animateColorAsState(
        targetValue = if (isSelected) BpBrandGreen else Color.Transparent,
        label = "nav_bg"
    )
    val contentColor by animateColorAsState(
        targetValue = if (isSelected) Color.White else TextWhiteSecondary,
        label = "nav_content"
    )

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() },
        color = bg,
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = section.title,
                tint = contentColor,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = section.title,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                    fontSize = 13.sp
                ),
                color = contentColor
            )
        }
    }
}
