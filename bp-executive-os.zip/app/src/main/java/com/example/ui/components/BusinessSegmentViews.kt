package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.*
import com.example.ui.theme.*

@Composable
fun UpstreamSegmentView(
    assets: List<GlobalAsset>,
    onSelectAsset: (GlobalAsset) -> Unit,
    modifier: Modifier = Modifier
) {
    val upstreamAssets = assets.filter { it.business == BusinessSegment.UPSTREAM }
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(18.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Upstream & Deepwater Production",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "High-margin resilient hydrocarbons across Deepwater Gulf of Mexico, Caspian, and West Africa",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // 4 KPI Summary
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            MetricCard("Net Production", "2.30 mboed", "+2.8% YoY", true, Modifier.weight(1f))
            MetricCard("Cash Lifting Cost", "$5.80 / boe", "-$0.40 vs plan", true, Modifier.weight(1f))
            MetricCard("EBITDA Contribution", "$4,850 M", "+17.7% YoY", true, Modifier.weight(1f))
            MetricCard("Upstream TRIR", "0.14", "-18% YoY", true, Modifier.weight(1f))
        }

        // Assets Table
        OperationsAndProjectsCard(
            assets = upstreamAssets,
            onSelectAsset = onSelectAsset
        )
    }
}

@Composable
fun DownstreamSegmentView(
    assets: List<GlobalAsset>,
    onSelectAsset: (GlobalAsset) -> Unit,
    onOpenDigitalTwin: () -> Unit,
    modifier: Modifier = Modifier
) {
    val downstreamAssets = assets.filter { it.business == BusinessSegment.DOWNSTREAM }
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(18.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Downstream, Refining & Biofuels",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Integrated processing units, commercial lubricants, aviation fuels, and bioenergy transition",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Button(
                onClick = onOpenDigitalTwin,
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BpBrandGreen)
            ) {
                Icon(Icons.Outlined.ViewInAr, contentDescription = "Twin", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Launch Refinery Digital Twin")
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            MetricCard("Refining Throughput", "835 kbd", "94.2% Availability", true, Modifier.weight(1f))
            MetricCard("Refining Marker Margin", "$9.40 / bbl", "-$1.20 vs LY", false, Modifier.weight(1f))
            MetricCard("Bioenergy / SAF Yield", "38 kbd", "+42% YoY", true, Modifier.weight(1f))
            MetricCard("EBITDA Contribution", "$2,430 M", "-8.3% YoY", false, Modifier.weight(1f))
        }

        OperationsAndProjectsCard(
            assets = downstreamAssets,
            onSelectAsset = onSelectAsset
        )
    }
}

@Composable
fun LowCarbonSegmentView(
    assets: List<GlobalAsset>,
    onSelectAsset: (GlobalAsset) -> Unit,
    modifier: Modifier = Modifier
) {
    val lowCarbonAssets = assets.filter { it.business == BusinessSegment.LOW_CARBON }
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(18.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Low Carbon Energy & bp pulse",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Rapid scale of high-speed EV charging, offshore wind, CCUS hubs, and hydrogen power",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            MetricCard("bp pulse Charge Bays", "25,480", "+28% YoY", true, Modifier.weight(1f))
            MetricCard("Renewables Pipeline", "42.5 GW", "+4.2 GW YTD", true, Modifier.weight(1f))
            MetricCard("Delivered Power", "14.2 GWh/day", "+35% YoY", true, Modifier.weight(1f))
            MetricCard("EBITDA Contribution", "$390 M", "+39.2% YoY", true, Modifier.weight(1f))
        }

        OperationsAndProjectsCard(
            assets = lowCarbonAssets,
            onSelectAsset = onSelectAsset
        )
    }
}

@Composable
fun PeopleAndSafetySegmentView(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(18.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "People, Safety & Organizational Culture",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            MetricCard("Global Workforce", "~70,600", "25 Countries", true, Modifier.weight(1f))
            MetricCard("Safety TRIR", "0.28", "-12% YoY (Industry Leader)", true, Modifier.weight(1f))
            MetricCard("Process Safety Tier 1", "4 Events", "-50% vs LY", true, Modifier.weight(1f))
            MetricCard("Engagement Index", "84%", "+3pp vs target", true, Modifier.weight(1f))
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "Safety Culture & Operating Discipline",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Every employee and contractor is empowered with 'Stop Work Authority' on every asset worldwide. Continuous learning loops from SCADA anomaly logs ensure early barrier verification across offshore drilling rigs, refinery processing columns, and logistics forecourts.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    delta: String,
    isPositive: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.onSurface)
            Spacer(modifier = Modifier.height(2.dp))
            Text(delta, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold), color = if (isPositive) StatusGreen else StatusRed)
        }
    }
}
