package com.example.data.model

enum class DataState(val label: String, val description: String) {
    ACTUAL("ACTUAL", "Verified historical or telemetry record"),
    FORECAST("FORECAST", "Statistical & consensus model projection"),
    MODELLED("MODELLED", "Derived engineering/economic calculation"),
    SIMULATED("SIMULATED", "User scenario parameter perturbation"),
    SYNTHETIC("SYNTHETIC", "Deterministic benchmark simulation entity")
}

enum class ExecutiveNavSection(
    val id: String,
    val title: String,
    val subtitle: String
) {
    OVERVIEW("overview", "Overview", "Global Executive Command"),
    STRATEGY("strategy", "Strategy & Performance", "Disciplined Growth & Returns"),
    UPSTREAM("upstream", "Upstream", "Deepwater & Gas Production"),
    DOWNSTREAM("downstream", "Downstream & Refining", "Processing, Logistics & Fuels"),
    TRADING("trading", "Trading & Shipping", "Global Commodity Exposure & VaR"),
    LOW_CARBON("low_carbon", "Low Carbon Energy", "bp pulse, Wind, Solar & Hydrogen"),
    FINANCE("finance", "Finance & P&L", "Capital Allocation, Free Cash Flow & ROACE"),
    PEOPLE("people", "People & Culture", "Workforce, Capability & Safety"),
    SAFETY_SUSTAINABILITY("safety", "Safety & Sustainability", "TRIR & Net Zero 2050 Progress"),
    RISK("risk", "Risk & Compliance", "Enterprise Risk Matrix & Early Warning"),
    DIGITAL_TWIN("twin", "Digital Twin Lab", "Interactive 3D Asset & Process Flow"),
    SCENARIO("scenario", "Scenario Simulator", "Macroeconomic & Monte Carlo Shock Engine"),
    REPORTS("reports", "Reports & Briefings", "Executive Board Briefings & AI Analyst")
}

data class MarketSnapshotItem(
    val name: String,
    val ticker: String,
    val price: Double,
    val currencySymbol: String,
    val changePercent: Double,
    val unit: String
)

data class StrategicPriority(
    val id: String,
    val title: String,
    val description: String,
    val ringSegmentPercent: Float,
    val colorHex: Long
)

data class CarbonProgressPoint(
    val periodLabel: String,
    val carbonIntensity: Double, // gCO2e/MJ
    val targetIntensity: Double,
    val isTarget: Boolean
)

data class CashFlowAllocation(
    val category: String,
    val percentage: Int,
    val amountBn: Double,
    val colorHex: Long
)

enum class AssetStatus {
    ON_TRACK, ATTENTION_REQUIRED, CRITICAL, PLANNED_MAINTENANCE
}

enum class BusinessSegment(val displayName: String) {
    UPSTREAM("Upstream"),
    DOWNSTREAM("Downstream"),
    LOW_CARBON("Low Carbon"),
    TRADING("Trading & Shipping"),
    CORPORATE("Corporate")
}

data class GlobalAsset(
    val id: String,
    val name: String,
    val business: BusinessSegment,
    val location: String,
    val country: String,
    val region: String, // Americas, Europe, Middle East & Asia, Africa, Asia-Pacific
    val lat: Float, // Normalized -90..90
    val lng: Float, // Normalized -180..180
    val status: AssetStatus,
    val netProductionDisplay: String,
    val startUpPhase: String,
    val progressPct: Int,
    val capexBudgetBn: Double,
    val ebitdaContributionM: Double,
    val trirScore: Double,
    val healthScore: Int, // 0..100
    val dataState: DataState = DataState.ACTUAL,
    val keyTelemetry: Map<String, String> = emptyMap(),
    val digitalTwinAvailable: Boolean = true
)

data class ExecutiveBriefing(
    val id: String,
    val day: String,
    val month: String,
    val title: String,
    val timeRange: String,
    val location: String,
    val isUrgent: Boolean = false
)

data class EnterpriseHighlight(
    val id: String,
    val title: String,
    val timeAgo: String,
    val summary: String,
    val business: BusinessSegment,
    val imageResName: String? = null
)

data class FinancialMetric(
    val title: String,
    val valueDisplay: String,
    val subtitle: String,
    val changeVsLy: String,
    val isPositive: Boolean,
    val dataState: DataState = DataState.ACTUAL
)

data class EnterpriseRisk(
    val id: String,
    val code: String,
    val title: String,
    val category: String,
    val probabilityScore: Int, // 1..5
    val impactScore: Int, // 1..5
    val velocity: String, // Fast, Medium, Slow
    val financialExposureM: Double,
    val mitigationStatus: String,
    val methodologyNote: String
)

data class EarlyWarningAnomaly(
    val id: String,
    val title: String,
    val assetName: String,
    val severity: String, // CRITICAL, HIGH, MEDIUM, LOW
    val timestamp: String,
    val description: String,
    val confidencePct: Int,
    val evidenceList: List<String>
)

data class RefineryUnit(
    val id: String,
    val name: String,
    val capacityBpd: Int,
    val currentThroughputBpd: Int,
    val utilizationPct: Int,
    val temperatureC: Double,
    val pressurePsi: Double,
    val vibrationMmS: Double,
    val status: AssetStatus,
    val remainingUsefulDays: Int
)

data class EVHubNode(
    val id: String,
    val locationName: String,
    val totalBays: Int,
    val activeChargingBays: Int,
    val peakPowerKw: Int,
    val energyDeliveredMwhToday: Double,
    val revenueTodayUsd: Double,
    val gridPowerDrawKw: Double,
    val uptimePercent: Double
)

data class ScenarioInput(
    val crudePriceDeltaDollars: Double = 0.0, // e.g. -15.0 $/bbl
    val gasPriceDeltaDollars: Double = 0.0, // e.g. +1.50 $/MMBtu
    val fuelDemandDeltaPct: Double = 0.0, // e.g. -5%
    val evAdoptionGrowthDeltaPct: Double = 0.0, // e.g. +15%
    val refineryUtilizationDeltaPct: Double = 0.0, // e.g. -4%
    val carbonPriceDeltaEuro: Double = 0.0 // e.g. +10 EUR
)

data class ScenarioPropagationStep(
    val stepOrder: Int,
    val nodeName: String,
    val impactDescription: String,
    val deltaAmount: String,
    val isNegative: Boolean
)

data class ScenarioResult(
    val originalEbitdaBn: Double,
    val simulatedEbitdaBn: Double,
    val originalCashFlowBn: Double,
    val simulatedCashFlowBn: Double,
    val originalRoacePct: Double,
    val simulatedRoacePct: Double,
    val originalCapexBn: Double,
    val simulatedCapexBn: Double,
    val p10EbitdaBn: Double,
    val p50EbitdaBn: Double,
    val p90EbitdaBn: Double,
    val propagationSteps: List<ScenarioPropagationStep>,
    val strategicImplications: List<String>
)

data class AiAnalystMessage(
    val id: String,
    val queryText: String,
    val responseSummary: String,
    val dataUsed: List<String>,
    val calculationMethod: String,
    val assumptions: List<String>,
    val confidencePct: Int,
    val recommendedActions: List<String>,
    val timestamp: String
)
