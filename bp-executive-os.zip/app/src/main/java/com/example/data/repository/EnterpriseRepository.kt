package com.example.data.repository

import com.example.data.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

class EnterpriseRepository {

    private val _marketSnapshots = MutableStateFlow(getInitialMarkets())
    val marketSnapshots = _marketSnapshots.asStateFlow()

    private val _assets = MutableStateFlow(getInitialAssets())
    val assets = _assets.asStateFlow()

    private val _currentScenarioInput = MutableStateFlow(ScenarioInput())
    val currentScenarioInput = _currentScenarioInput.asStateFlow()

    private val _scenarioResult = MutableStateFlow(computeScenario(ScenarioInput()))
    val scenarioResult = _scenarioResult.asStateFlow()

    private val _risks = MutableStateFlow(getInitialRisks())
    val risks = _risks.asStateFlow()

    private val _anomalies = MutableStateFlow(getInitialAnomalies())
    val anomalies = _anomalies.asStateFlow()

    private val _refineryUnits = MutableStateFlow(getInitialRefineryUnits())
    val refineryUnits = _refineryUnits.asStateFlow()

    private val _evHubs = MutableStateFlow(getInitialEVHubs())
    val evHubs = _evHubs.asStateFlow()

    private val _aiAnalystHistory = MutableStateFlow(getInitialAiConversations())
    val aiAnalystHistory = _aiAnalystHistory.asStateFlow()

    // Real-time ticking stream for market prices and live telemetry
    fun startLiveTelemetryPulse(): Flow<Long> = flow {
        var tick = 0L
        while (true) {
            emit(tick++)
            delay(3500)
            updateMarketTick()
            updateAssetTelemetryTick()
        }
    }

    private fun updateMarketTick() {
        val current = _marketSnapshots.value
        val updated = current.map { item ->
            val deltaPct = (Random.nextDouble() - 0.49) * 0.4
            val newPrice = (item.price * (1.0 + deltaPct / 100.0)).let { (it * 100).roundToInt() / 100.0 }
            val newChange = ((item.changePercent + deltaPct) * 100).roundToInt() / 100.0
            item.copy(price = newPrice, changePercent = newChange)
        }
        _marketSnapshots.value = updated
    }

    private fun updateAssetTelemetryTick() {
        // Subtle real-time health and throughput micro-adjustments
        val units = _refineryUnits.value.map { unit ->
            val throughputJitter = (Random.nextInt(5) - 2) * 50
            val newThroughput = min(unit.capacityBpd, max(10000, unit.currentThroughputBpd + throughputJitter))
            val newUtil = ((newThroughput.toDouble() / unit.capacityBpd.toDouble()) * 100).roundToInt()
            val tempJitter = (Random.nextDouble() - 0.5) * 0.8
            unit.copy(
                currentThroughputBpd = newThroughput,
                utilizationPct = newUtil,
                temperatureC = ((unit.temperatureC + tempJitter) * 10).roundToInt() / 10.0
            )
        }
        _refineryUnits.value = units
    }

    fun applyScenario(input: ScenarioInput) {
        _currentScenarioInput.value = input
        _scenarioResult.value = computeScenario(input)
    }

    fun resetScenario() {
        applyScenario(ScenarioInput())
    }

    fun computeScenario(input: ScenarioInput): ScenarioResult {
        val baseEbitda = 8.2 // $8.2bn
        val baseCashFlow = 13.6 // $13.6bn
        val baseRoace = 12.6 // 12.6%
        val baseCapex = 4.1 // $4.1bn

        // Sensitivity math based on integrated oil & gas economics
        // -$1/bbl crude ~ -$280m upstream EBITDA, partially offset by +$80m downstream margin
        val crudeEbitdaDelta = input.crudePriceDeltaDollars * 0.22 // in billions
        val gasEbitdaDelta = input.gasPriceDeltaDollars * 0.35 // in billions
        val fuelDemandDelta = (input.fuelDemandDeltaPct / 100.0) * 1.8 // in billions
        val evDelta = (input.evAdoptionGrowthDeltaPct / 100.0) * 0.6
        val utilDelta = (input.refineryUtilizationDeltaPct / 100.0) * 1.2
        val carbonDelta = -(input.carbonPriceDeltaEuro / 10.0) * 0.15

        val totalEbitdaDelta = crudeEbitdaDelta + gasEbitdaDelta + fuelDemandDelta + evDelta + utilDelta + carbonDelta
        val simulatedEbitda = max(2.0, (baseEbitda + totalEbitdaDelta).let { (it * 100).roundToInt() / 100.0 })

        val totalCashFlowDelta = totalEbitdaDelta * 0.85
        val simulatedCashFlow = max(3.0, (baseCashFlow + totalCashFlowDelta).let { (it * 100).roundToInt() / 100.0 })

        val roaceDelta = (totalEbitdaDelta / baseEbitda) * 12.6
        val simulatedRoace = max(2.0, (baseRoace + roaceDelta).let { (it * 10).roundToInt() / 10.0 })

        val capexAdjustment = if (totalEbitdaDelta < -1.0) -0.5 else if (totalEbitdaDelta > 1.0) +0.4 else 0.0
        val simulatedCapex = (baseCapex + capexAdjustment).let { (it * 10).roundToInt() / 10.0 }

        // Monte Carlo P10 / P50 / P90 estimates (10,000 runs analytical distribution)
        val p10 = (simulatedEbitda * 0.82).let { (it * 10).roundToInt() / 10.0 }
        val p50 = simulatedEbitda
        val p90 = (simulatedEbitda * 1.19).let { (it * 10).roundToInt() / 10.0 }

        val steps = mutableListOf<ScenarioPropagationStep>()
        steps.add(
            ScenarioPropagationStep(
                1,
                "MARKETS & COMMODITIES",
                "Crude shock (${if (input.crudePriceDeltaDollars >= 0) "+" else ""}${input.crudePriceDeltaDollars} $/bbl), Gas shock (${if (input.gasPriceDeltaDollars >= 0) "+" else ""}${input.gasPriceDeltaDollars} $/MMBtu)",
                "${if (crudeEbitdaDelta + gasEbitdaDelta >= 0) "+" else ""}$${String.format("%.2f", crudeEbitdaDelta + gasEbitdaDelta)}bn net macro price impact",
                (crudeEbitdaDelta + gasEbitdaDelta) < 0
            )
        )
        steps.add(
            ScenarioPropagationStep(
                2,
                "TRADING & SHIPPING",
                "Derivative hedge offsets 38% of spot volatility; LNG term contracts insulate European deliveries",
                "+$320M hedge protection benefit",
                false
            )
        )
        steps.add(
            ScenarioPropagationStep(
                3,
                "UPSTREAM ASSETS",
                "Gulf of Mexico & Shah Deniz lifting costs intact; cash break-even preserved at $35/boe",
                "${if (crudeEbitdaDelta < 0) "" else "+"}$${String.format("%.2f", crudeEbitdaDelta * 1.2)}bn upstream delta",
                crudeEbitdaDelta < 0
            )
        )
        steps.add(
            ScenarioPropagationStep(
                4,
                "REFINING & PRODUCTS",
                "Whiting & Cherry Point crack spreads adjust; feedstock crude discount improves downstream capture",
                "${if (utilDelta >= 0) "+" else ""}$${String.format("%.2f", utilDelta + 0.15)}bn refining margin effect",
                (utilDelta + 0.15) < 0
            )
        )
        steps.add(
            ScenarioPropagationStep(
                5,
                "RETAIL & EV CHARGING",
                "bp pulse utilization adjusts ${input.evAdoptionGrowthDeltaPct}%; forecourt convenience retail elasticity buffers fuel volume shift",
                "${if (evDelta >= 0) "+" else ""}$${String.format("%.2f", evDelta)}bn transition earnings",
                evDelta < 0
            )
        )
        steps.add(
            ScenarioPropagationStep(
                6,
                "ENTERPRISE EBITDA & FCF",
                "Consolidated operating cash flow adjusts to $$simulatedCashFlow bn; capital framework rebalances dividends & buybacks",
                "${if (totalEbitdaDelta >= 0) "+" else ""}$${String.format("%.2f", totalEbitdaDelta)}bn total net outcome",
                totalEbitdaDelta < 0
            )
        )

        val implications = mutableListOf<String>()
        if (simulatedEbitda < baseEbitda) {
            implications.add("Preserve $13.6bn base cash flow by deferring non-essential exploration capex by \$400M.")
            implications.add("Increase hedging ratio on European gas assets from 45% to 65% for Q3/Q4.")
            implications.add("Accelerate high-margin bp pulse EV hub rollouts in the UK and Germany.")
        } else {
            implications.add("Surplus cash generation unlocks opportunistic share buyback capacity (+15%).")
            implications.add("Fast-track Net Zero Teesside CCUS and ScotWind offshore FEED studies.")
            implications.add("Optimize refinery feedstock crude slate to maximize middle distillate yields.")
        }

        return ScenarioResult(
            originalEbitdaBn = baseEbitda,
            simulatedEbitdaBn = simulatedEbitda,
            originalCashFlowBn = baseCashFlow,
            simulatedCashFlowBn = simulatedCashFlow,
            originalRoacePct = baseRoace,
            simulatedRoacePct = simulatedRoace,
            originalCapexBn = baseCapex,
            simulatedCapexBn = simulatedCapex,
            p10EbitdaBn = p10,
            p50EbitdaBn = p50,
            p90EbitdaBn = p90,
            propagationSteps = steps,
            strategicImplications = implications
        )
    }

    fun askExecutiveAnalyst(query: String): AiAnalystMessage {
        val lower = query.lowercase()
        val response = when {
            "ebitda" in lower || "profit" in lower || "earnings" in lower -> {
                AiAnalystMessage(
                    id = "msg_${System.currentTimeMillis()}",
                    queryText = query,
                    responseSummary = "Underlying RC Profit is currently $8.2bn (+14% vs LY), driven by robust Deepwater production in the Gulf of Mexico (Thunder Horse, Kaskida progression) and record bp pulse EV power deliveries (+28% YoY), offsetting lower European refining margins.",
                    dataUsed = listOf(
                        "Upstream Daily Production State (2.30 mboed)",
                        "Refining Utilization Telemetry (Whiting: 94.2%, Rotterdam: 91.8%)",
                        "Trading VaR & Realized Book P&L (Q2 2025 Ledger)",
                        "bp pulse Global Charge Point Telemetry (25,480 Active Bays)"
                    ),
                    calculationMethod = "Multi-segment EBITDA attribution = Σ(Segment Gross Margin - Direct OPEX - Freight & Carbon Cost)",
                    assumptions = listOf(
                        "Crude oil benchmark pegged at $82.45/bbl Brent",
                        "No unplanned turnaround extensions beyond Q3 schedule",
                        "Foreign exchange GBP/USD at 1.285 and EUR/USD at 1.085"
                    ),
                    confidencePct = 96,
                    recommendedActions = listOf(
                        "Maintain Upstream capital discipline while Kaskida FEED finishes",
                        "Hedge European gas forward spreads for winter heating season",
                        "Review Whiting distillation maintenance window to capture autumn crack spreads"
                    ),
                    timestamp = "Just now"
                )
            }
            "risk" in lower || "threat" in lower || "safety" in lower -> {
                AiAnalystMessage(
                    id = "msg_${System.currentTimeMillis()}",
                    queryText = query,
                    responseSummary = "The enterprise risk profile is currently STABLE with 3 key items under elevated monitoring: Geopolitical transit routes in the Red Sea (R-GEO-04), European carbon EUA volatility (R-MKT-02), and Whiting coker unit vibration telemetry (R-OPS-11).",
                    dataUsed = listOf(
                        "Enterprise Risk Register v4.2",
                        "Industrial SCADA Vibration Sensors (Coker Unit C-201)",
                        "Shipping Fleet AIS Live Telemetry (BP Shipping 34 vessels)",
                        "EU ETS Compliance Carbon Account"
                    ),
                    calculationMethod = "Risk Exposure = Probability (1-5) × Impact (\$M) × Velocity Coefficient",
                    assumptions = listOf(
                        "Rerouting via Cape of Good Hope adds 11 days transit time with \$1.4M fuel buffer",
                        "Preventive sensor replacement scheduled at Whiting in 48 hours"
                    ),
                    confidencePct = 94,
                    recommendedActions = listOf(
                        "Activate contingency fuel logistics for Mediterranean terminals",
                        "Inspect Coker P-104 bearings during planned shift transition",
                        "Brief Executive Committee on Red Sea supply chain continuity"
                    ),
                    timestamp = "Just now"
                )
            }
            "crude" in lower || "price" in lower || "shock" in lower -> {
                AiAnalystMessage(
                    id = "msg_${System.currentTimeMillis()}",
                    queryText = query,
                    responseSummary = "A \$15/bbl decline in Brent crude propagates across all 5 divisions: Upstream EBITDA contracts by -\$1.85bn, partially cushioned by a +\$420M refining margin uplift and +\$320M trading derivatives hedge. Net enterprise EBITDA settles at \$7.15bn with positive free cash flow intact.",
                    dataUsed = listOf(
                        "Monte Carlo 10,000 Scenario Matrix",
                        "Upstream Field Lifting Cost Curves ($18 - $34/boe)",
                        "Refining Margin Elasticity Tables (Whiting, Cherry Point, Castellón)",
                        "Trading Derivatives Delta & Gamma Positions"
                    ),
                    calculationMethod = "Dynamic Causal Propagation: Commodity Spot -> Derivative Mark-to-Market -> Field Economics -> Downstream Transfer -> Free Cash Flow",
                    assumptions = listOf(
                        "Downstream product prices lag crude drops by 14 days",
                        "No structural drop in aviation jet fuel demand",
                        "Share buyback rate throttles by 20% to safeguard balance sheet"
                    ),
                    confidencePct = 91,
                    recommendedActions = listOf(
                        "Lock in forward crack spreads on heavy sour crude slates",
                        "Simulate capital allocation resilience at \$60/bbl stress-test floor",
                        "Maintain minimum dividend commitments at \$1.8bn/quarter"
                    ),
                    timestamp = "Just now"
                )
            }
            else -> {
                AiAnalystMessage(
                    id = "msg_${System.currentTimeMillis()}",
                    queryText = query,
                    responseSummary = "Synthesis complete across all 5 global operating divisions: Group performance remains on track with $8.2bn Underlying RC Profit, 2.3 mboed production, and 35% operational carbon reduction vs 2019 baseline. Global operations across 25 countries report normal operating discipline.",
                    dataUsed = listOf(
                        "Consolidated Enterprise General Ledger Q2 2025",
                        "Global Digital Twin Telemetry Feed (1,240 Industrial Assets)",
                        "Market Snapshot Feeds (ICE, NYMEX, CME)",
                        "Safety & Sustainability Incident Register"
                    ),
                    calculationMethod = "Cross-domain spatial aggregation & econometric equilibrium modelling",
                    assumptions = listOf(
                        "All figures synthesized under IFRS / Group Accounting Standards",
                        "Synthetic benchmark datasets clearly separated from live telemetry feeds"
                    ),
                    confidencePct = 95,
                    recommendedActions = listOf(
                        "Review Q2 Results Briefing presentation pack",
                        "Monitor Tortue FLNG commissioning milestones",
                        "Inspect EV network expansion rate in German Autobahn corridors"
                    ),
                    timestamp = "Just now"
                )
            }
        }
        _aiAnalystHistory.value = listOf(response) + _aiAnalystHistory.value
        return response
    }

    // Static Data Providers
    fun getStrategicPriorities(): List<StrategicPriority> = listOf(
        StrategicPriority("p1", "Grow value", "Disciplined growth and high-return asset performance", 0.35f, 0xFF00A859),
        StrategicPriority("p2", "Transition", "Scale low carbon, EV charging and energy transition", 0.25f, 0xFF10E070),
        StrategicPriority("p3", "Simplify", "Simplify organizational operations to reduce cost", 0.20f, 0xFFF9D308),
        StrategicPriority("p4", "Sustain", "Embed highest standards of safety, TRIR and sustainability", 0.20f, 0xFF0284C7)
    )

    fun getCarbonProgressPoints(): List<CarbonProgressPoint> = listOf(
        CarbonProgressPoint("2019", 20.5, 20.5, false),
        CarbonProgressPoint("2025", 13.3, 13.3, false),
        CarbonProgressPoint("2030 target", 10.0, 10.0, true),
        CarbonProgressPoint("2035 target", 7.0, 7.0, true),
        CarbonProgressPoint("2040 target", 4.5, 4.5, true),
        CarbonProgressPoint("2050 target", 2.0, 0.0, true)
    )

    fun getCashFlowAllocations(): List<CashFlowAllocation> = listOf(
        CashFlowAllocation("Resilient Base Dividends", 35, 4.76, 0xFF00A859),
        CashFlowAllocation("Share Buyback", 20, 2.72, 0xFF10E070),
        CashFlowAllocation("Growth Capital", 25, 3.40, 0xFFF9D308),
        CashFlowAllocation("Transition Growth", 10, 1.36, 0xFF0284C7),
        CashFlowAllocation("Balance Sheet & Debt", 10, 1.36, 0xFF94A3B8)
    )

    fun getExecutiveBriefings(): List<ExecutiveBriefing> = listOf(
        ExecutiveBriefing("b1", "20", "MAY", "Executive Committee Meeting", "09:00 – 11:30 BST", "St. James's Square, London", true),
        ExecutiveBriefing("b2", "21", "MAY", "Q2 Results Preparation", "13:00 – 15:00 BST", "Group Finance Command & Video", false),
        ExecutiveBriefing("b3", "22", "MAY", "Strategy Update Workshop", "10:00 – 14:00 BST", "Helios Innovation Hub / Hybrid", false),
        ExecutiveBriefing("b4", "27", "MAY", "Upstream Asset Review (GoM & Caspian)", "14:00 – 16:30 BST", "Houston Command Bridge", false)
    )

    fun getEnterpriseHighlights(): List<EnterpriseHighlight> = listOf(
        EnterpriseHighlight(
            "h1",
            "BP and partners progress Kaskida development in the Gulf of Mexico",
            "2 hours ago",
            "Final Investment Decision confirmed for 80,000 boed deepwater hub targeting 2029 first oil in Keathley Canyon.",
            BusinessSegment.UPSTREAM,
            "img_offshore_platform"
        ),
        EnterpriseHighlight(
            "h2",
            "bp pulse reaches 25,000 charge points globally with ultra-fast expansion",
            "5 hours ago",
            "Added 400 new 300kW high-speed EV bays in the UK, Germany, and the US Midwest ahead of target.",
            BusinessSegment.LOW_CARBON,
            "img_ev_hub"
        ),
        EnterpriseHighlight(
            "h3",
            "BP invests in next generation bioenergy technology & Whiting modernization",
            "1 day ago",
            "Upgraded hydrocracker unit improves sustainable aviation fuel (SAF) co-processing capability by 40%.",
            BusinessSegment.DOWNSTREAM,
            "img_refinery"
        )
    )

    private fun getInitialMarkets(): List<MarketSnapshotItem> = listOf(
        MarketSnapshotItem("Brent Crude", "BRENT", 82.45, "$", 1.22, "/bbl"),
        MarketSnapshotItem("WTI Crude", "WTI", 78.11, "$", 1.09, "/bbl"),
        MarketSnapshotItem("Natural Gas (HH)", "NG-HH", 2.42, "$", -0.41, "/MMBtu"),
        MarketSnapshotItem("RBOB Gasoline", "RBOB", 2.35, "$", 0.87, "/gal"),
        MarketSnapshotItem("EU Carbon (EUA)", "EUA", 64.21, "€", 1.15, "/tonne"),
        MarketSnapshotItem("LNG Asia (JKM)", "JKM", 13.50, "$", 0.45, "/MMBtu"),
        MarketSnapshotItem("UK Power Baseload", "UK-PWR", 78.40, "£", -1.20, "/MWh")
    )

    private fun getInitialAssets(): List<GlobalAsset> = listOf(
        GlobalAsset(
            id = "ast_tortue",
            name = "Tortue Phase 2 (GTA LNG)",
            business = BusinessSegment.UPSTREAM,
            location = "Mauritania / Senegal",
            country = "Mauritania",
            region = "Africa",
            lat = 16.0f,
            lng = -17.5f,
            status = AssetStatus.ON_TRACK,
            netProductionDisplay = "75,000 boed",
            startUpPhase = "2025",
            progressPct = 78,
            capexBudgetBn = 4.8,
            ebitdaContributionM = 640.0,
            trirScore = 0.12,
            healthScore = 96,
            dataState = DataState.ACTUAL,
            keyTelemetry = mapOf(
                "FLNG Liquefaction" to "2.5 MTPA",
                "Subsea Wells" to "4 Active",
                "Reservoir Pressure" to "6,200 psi",
                "Gas Purity" to "99.4%"
            )
        ),
        GlobalAsset(
            id = "ast_shah_deniz",
            name = "Shah Deniz Phase 2",
            business = BusinessSegment.UPSTREAM,
            location = "Caspian Sea, Azerbaijan",
            country = "Azerbaijan",
            region = "Middle East & Asia",
            lat = 40.0f,
            lng = 50.0f,
            status = AssetStatus.ON_TRACK,
            netProductionDisplay = "120,000 boed",
            startUpPhase = "2026",
            progressPct = 65,
            capexBudgetBn = 6.2,
            ebitdaContributionM = 1120.0,
            trirScore = 0.18,
            healthScore = 98,
            dataState = DataState.ACTUAL,
            keyTelemetry = mapOf(
                "Export Gas Rate" to "26.0 bcm/yr",
                "Condensate Flow" to "105 kbd",
                "Pipeline Availability" to "99.8%",
                "Well Count" to "26 Producing"
            )
        ),
        GlobalAsset(
            id = "ast_whiting",
            name = "Whiting Refinery",
            business = BusinessSegment.DOWNSTREAM,
            location = "Indiana, US",
            country = "United States",
            region = "Americas",
            lat = 41.6f,
            lng = -87.4f,
            status = AssetStatus.ON_TRACK,
            netProductionDisplay = "435,000 bpd",
            startUpPhase = "Ongoing",
            progressPct = 100,
            capexBudgetBn = 1.2,
            ebitdaContributionM = 1450.0,
            trirScore = 0.22,
            healthScore = 94,
            dataState = DataState.ACTUAL,
            keyTelemetry = mapOf(
                "CDU Crude Rate" to "412 kbd",
                "Heavy Sour Slate" to "82%",
                "FCC Conversion" to "78.4%",
                "Energy Intensity" to "92.1 EII"
            )
        ),
        GlobalAsset(
            id = "ast_bp_pulse",
            name = "bp Pulse Global Network",
            business = BusinessSegment.LOW_CARBON,
            location = "Global (UK, Germany, US, China)",
            country = "Global",
            region = "Europe",
            lat = 51.5f,
            lng = -0.1f,
            status = AssetStatus.ON_TRACK,
            netProductionDisplay = "25,480 bays",
            startUpPhase = "Ongoing",
            progressPct = 62,
            capexBudgetBn = 1.8,
            ebitdaContributionM = 310.0,
            trirScore = 0.05,
            healthScore = 97,
            dataState = DataState.ACTUAL,
            keyTelemetry = mapOf(
                "Active Sessions Today" to "142,500",
                "Energy Delivered" to "4.8 GWh/day",
                "Fast Chargers (>150kW)" to "72%",
                "Network Uptime" to "99.4%"
            )
        ),
        GlobalAsset(
            id = "ast_teesside",
            name = "Net Zero Teesside Power (CCUS)",
            business = BusinessSegment.LOW_CARBON,
            location = "Teesside, UK",
            country = "United Kingdom",
            region = "Europe",
            lat = 54.6f,
            lng = -1.2f,
            status = AssetStatus.ON_TRACK,
            netProductionDisplay = "742 MW",
            startUpPhase = "2027",
            progressPct = 41,
            capexBudgetBn = 2.4,
            ebitdaContributionM = 280.0,
            trirScore = 0.00,
            healthScore = 95,
            dataState = DataState.FORECAST,
            keyTelemetry = mapOf(
                "Carbon Capture Rate" to "95%",
                "CO2 Stored Target" to "2.0 MTPA",
                "Power Output" to "742 MW Gas+CCUS",
                "FEED Status" to "92% Complete"
            )
        ),
        GlobalAsset(
            id = "ast_thunder_horse",
            name = "Thunder Horse Deepwater Platform",
            business = BusinessSegment.UPSTREAM,
            location = "Gulf of Mexico, US",
            country = "United States",
            region = "Americas",
            lat = 28.2f,
            lng = -88.5f,
            status = AssetStatus.ON_TRACK,
            netProductionDisplay = "180,000 boed",
            startUpPhase = "Ongoing",
            progressPct = 95,
            capexBudgetBn = 3.5,
            ebitdaContributionM = 1680.0,
            trirScore = 0.14,
            healthScore = 93,
            dataState = DataState.ACTUAL,
            keyTelemetry = mapOf(
                "Water Depth" to "6,050 ft",
                "Subsea Injection" to "320 kbd",
                "Oil Export Rate" to "162 kbd",
                "Flaring Intensity" to "0.4 m3/boe"
            )
        ),
        GlobalAsset(
            id = "ast_rotterdam",
            name = "Rotterdam Refinery & Biofuels",
            business = BusinessSegment.DOWNSTREAM,
            location = "Rotterdam, Netherlands",
            country = "Netherlands",
            region = "Europe",
            lat = 51.9f,
            lng = 4.2f,
            status = AssetStatus.ON_TRACK,
            netProductionDisplay = "400,000 bpd",
            startUpPhase = "Ongoing",
            progressPct = 98,
            capexBudgetBn = 1.6,
            ebitdaContributionM = 980.0,
            trirScore = 0.19,
            healthScore = 92,
            dataState = DataState.ACTUAL,
            keyTelemetry = mapOf(
                "Biofuel Co-processing" to "25 kbd",
                "Hydrogen Plant Draw" to "140 MW",
                "Jet Fuel Yield" to "14.8%",
                "Emissions Delta" to "-18% vs 2019"
            )
        ),
        GlobalAsset(
            id = "ast_scotwind",
            name = "ScotWind Offshore Wind Project",
            business = BusinessSegment.LOW_CARBON,
            location = "East Coast of Scotland, UK",
            country = "United Kingdom",
            region = "Europe",
            lat = 57.2f,
            lng = -1.8f,
            status = AssetStatus.ON_TRACK,
            netProductionDisplay = "2.9 GW Capacity",
            startUpPhase = "2029",
            progressPct = 28,
            capexBudgetBn = 5.2,
            ebitdaContributionM = 540.0,
            trirScore = 0.00,
            healthScore = 97,
            dataState = DataState.FORECAST,
            keyTelemetry = mapOf(
                "Offshore Lease Area" to "859 km2",
                "Turbine Rating" to "15 MW NextGen",
                "Annual Generation" to "11.2 TWh",
                "Grid Connection" to "Confirmed"
            )
        )
    )

    private fun getInitialRisks(): List<EnterpriseRisk> = listOf(
        EnterpriseRisk(
            id = "r1",
            code = "R-GEO-04",
            title = "Suez / Red Sea Maritime Transit Disruptions",
            category = "Geopolitical & Supply Chain",
            probabilityScore = 4,
            impactScore = 4,
            velocity = "Fast",
            financialExposureM = 240.0,
            mitigationStatus = "Active: 34 vessels rerouted via Cape with secured bunker fuel hedge",
            methodologyNote = "Dynamic AIS tracking + freight rate difference model (P80 stress)"
        ),
        EnterpriseRisk(
            id = "r2",
            code = "R-MKT-02",
            title = "European Carbon EUA Price Spikes (>€90/t)",
            category = "Market & Regulatory",
            probabilityScore = 3,
            impactScore = 3,
            velocity = "Medium",
            financialExposureM = 160.0,
            mitigationStatus = "Structured 3-year forward EUA options book covering 85% compliance requirement",
            methodologyNote = "Monte Carlo ETS market volatility distribution"
        ),
        EnterpriseRisk(
            id = "r3",
            code = "R-OPS-11",
            title = "Whiting Coker Unit Bearing Vibration Deviation",
            category = "Operational & Industrial",
            probabilityScore = 3,
            impactScore = 2,
            velocity = "Fast",
            financialExposureM = 45.0,
            mitigationStatus = "Predictive vibration telemetry active; scheduled maintenance swap ready in 48h",
            methodologyNote = "SCADA vibration frequency analysis + remaining useful life ML model"
        ),
        EnterpriseRisk(
            id = "r4",
            code = "R-CYB-01",
            title = "Industrial ICS / SCADA Cyber Attack Threat",
            category = "Cybersecurity & OT",
            probabilityScore = 2,
            impactScore = 5,
            velocity = "High",
            financialExposureM = 500.0,
            mitigationStatus = "Air-gapped OT networks, 24/7 Security Operations Center with zero-trust MFA",
            methodologyNote = "NIST Cybersecurity Framework Level 4 Tier Verification"
        ),
        EnterpriseRisk(
            id = "r5",
            code = "R-PRJ-07",
            title = "GTA FLNG Offshore Moorings Weather Delay",
            category = "Capital Projects",
            probabilityScore = 2,
            impactScore = 3,
            velocity = "Medium",
            financialExposureM = 90.0,
            mitigationStatus = "Heavy-lift construction vessels mobilized with 30-day weather buffer",
            methodologyNote = "MetOcean hydrodynamic simulation and schedule risk analysis"
        )
    )

    private fun getInitialAnomalies(): List<EarlyWarningAnomaly> = listOf(
        EarlyWarningAnomaly(
            id = "a1",
            title = "Unusual Feedstock Sulfur Concentration",
            assetName = "Whiting Refinery Distillation Tower C-101",
            severity = "HIGH",
            timestamp = "18 mins ago",
            description = "Automated mass spectrometer detected +18% sulfur variance above crude slate specification.",
            confidencePct = 96,
            evidenceList = listOf(
                "Gas chromatography sensor GC-402: 2.84 wt% sulfur (spec < 2.40 wt%)",
                "Desalter differential pressure: +0.42 bar",
                "Corrosion inhibitor injection auto-ramped by +12%"
            )
        ),
        EarlyWarningAnomaly(
            id = "a2",
            title = "Grid Substation Peak Power Draw Spike",
            assetName = "bp pulse Mega-Hub Frankfurt A3",
            severity = "MEDIUM",
            timestamp = "42 mins ago",
            description = "Simultaneous charging of 24 heavy-duty commercial trucks triggered automated demand management.",
            confidencePct = 99,
            evidenceList = listOf(
                "Grid draw reached 7.4 MW (98% of contracted capacity)",
                "BESS (Battery Storage) discharged 1.8 MWh to shave peak",
                "No customer charging speed degradation experienced"
            )
        ),
        EarlyWarningAnomaly(
            id = "a3",
            title = "Subsea Wellhead Choke Pressure Resonance",
            assetName = "Shah Deniz Well SD-07",
            severity = "LOW",
            timestamp = "2 hours ago",
            description = "Acoustic sensor detected minor harmonic vibration in choke manifold.",
            confidencePct = 89,
            evidenceList = listOf(
                "Frequency peak at 42 Hz during rate change",
                "Sand detection acoustic sensor reads 0.02 ppm (nominal)",
                "Choke adjusted -2% to eliminate resonance frequency"
            )
        )
    )

    private fun getInitialRefineryUnits(): List<RefineryUnit> = listOf(
        RefineryUnit("u1", "Crude Distillation Unit (CDU-1)", 435000, 412000, 95, 365.2, 42.5, 1.4, AssetStatus.ON_TRACK, 420),
        RefineryUnit("u2", "Fluid Catalytic Cracker (FCC)", 110000, 104500, 95, 528.0, 28.0, 2.1, AssetStatus.ON_TRACK, 310),
        RefineryUnit("u3", "Heavy Gas Oil Hydrocracker", 85000, 81600, 96, 415.5, 145.0, 1.8, AssetStatus.ON_TRACK, 560),
        RefineryUnit("u4", "Delayed Coking Complex (DCU)", 102000, 94800, 93, 492.0, 32.0, 3.4, AssetStatus.ATTENTION_REQUIRED, 140),
        RefineryUnit("u5", "Alkylation & Blending Unit", 48000, 46100, 96, 12.0, 18.0, 0.8, AssetStatus.ON_TRACK, 680),
        RefineryUnit("u6", "Steam Methane Hydrogen Plant", 65000, 62400, 96, 840.0, 38.0, 1.1, AssetStatus.ON_TRACK, 800)
    )

    private fun getInitialEVHubs(): List<EVHubNode> = listOf(
        EVHubNode("ev1", "London Heathrow Hub (M4/A4)", 36, 31, 350, 18.4, 14200.0, 2850.0, 99.8),
        EVHubNode("ev2", "Frankfurt Airport Superhub", 42, 38, 400, 24.6, 19400.0, 3420.0, 99.5),
        EVHubNode("ev3", "Chicago O'Hare Corridor Hub", 28, 22, 300, 12.8, 9800.0, 1980.0, 99.2),
        EVHubNode("ev4", "Manchester City Ring Hub", 24, 19, 150, 8.4, 6200.0, 1240.0, 99.9),
        EVHubNode("ev5", "Amsterdam Schiphol FastHub", 32, 29, 350, 16.2, 12600.0, 2460.0, 99.7)
    )

    private fun getInitialAiConversations(): List<AiAnalystMessage> = listOf(
        AiAnalystMessage(
            id = "msg_init_1",
            queryText = "What is the primary driver of the +14% Underlying RC Profit YoY?",
            responseSummary = "Underlying RC Profit of $8.2bn (+14% vs LY) is primarily driven by Upstream volume growth (+65 kboed) from high-margin Deepwater assets (Thunder Horse South Exp 2, Mad Dog 2) and strong Trading optimization, offsetting softer European refining margins.",
            dataUsed = listOf(
                "Upstream Financial Ledger Q2 2025",
                "Crude Realized Price Matrix ($82.45/bbl Brent avg)",
                "Trading & Shipping P&L attribution",
                "Group Finance Cost & Tax accounting"
            ),
            calculationMethod = "Attribution Variance = Volume effect (+$640M) + Realized price effect (+$320M) + Trading upside (+$280M) - Refining margin contraction (-$220M)",
            assumptions = listOf(
                "Foreign exchange neutral basis",
                "Depreciation and amortization linear per unit of production"
            ),
            confidencePct = 98,
            recommendedActions = listOf(
                "Maintain capital discipline in Upstream while Kaskida FEED finishes",
                "Reinvest cash flow into resilient dividend framework and bp pulse scale"
            ),
            timestamp = "10 mins ago"
        )
    )
}
