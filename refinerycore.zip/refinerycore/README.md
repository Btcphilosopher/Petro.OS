# REFINERYCORE.OS

A Python engineering platform for modelling, simulating, analysing and
optimising a petroleum refinery: a modular digital-twin / process-
simulation framework, not a dashboard, a game, or a 3D visualisation.

> **Fidelity notice.** REFINERYCORE.OS is an educational / conceptual
> engineering simulator. It does **not** reproduce a licensed process
> simulator (Aspen HYSYS, PRO/II, PetroSIM, ...), is **not**
> plant-certified, and is **not** connected to any real refinery control
> system. Every model declares a fidelity level and every simplified
> correlation says so in its docstring. Read
> [`docs/limitations.md`](docs/limitations.md) before using any number
> this repository produces for a real decision.

## Architecture

```
PHYSICAL REFINERY
       |
EQUIPMENT MODEL -> PROCESS STREAM MODEL -> THERMODYNAMIC STATE
       |
PHYSICS / MASS / ENERGY BALANCES -> SOLVER -> DIGITAL TWIN STATE
       |
OPTIMISATION / ANALYTICS / VISUALISATION / API
```

The refinery is the source of truth. Every engineering value shown by
reporting, the CLI, or (a future) API/UI originates from the physics
layer -- nothing above the solver invents an engineering value. See
[`docs/architecture.md`](docs/architecture.md).

Units are strict SI internally (Pa, K, kg/s, W, J/kg, ...); conversion
helpers to bar/psi, degC/degF, t/h/bbl-day, kW/MW, etc. live in
`refinerycore.core.units` and are used only at the boundary (CLI,
config loading, reporting). See [`docs/architecture.md`](docs/architecture.md#units).

## Install

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
```

## Quickstart

```bash
python examples/simple_refinery.py
```

This builds the reference ~100,000 bbl/day demonstration refinery
(`refinerycore.demo`), solves it steady-state, and prints the
material/energy balance and KPI summary.

Or via the CLI:

```bash
refinerycore simulate
refinerycore solve
refinerycore validate
refinerycore report
refinerycore optimise
refinerycore scenario
refinerycore montecarlo
```

## Example scripts

| Script | Demonstrates |
| --- | --- |
| `examples/simple_refinery.py` | End-to-end steady-state solve + report (spec section 61) |
| `examples/cdu_example.py` | Furnace temperature / reflux ratio -> product yield sensitivity |
| `examples/pump_example.py` | Pump curve, operating point, health-driven cavitation risk |
| `examples/exchanger_example.py` | LMTD / effectiveness-NTU heat exchanger duty |
| `examples/exchanger_fouling.py` | Fouling degradation over Day 0/30/60/90/180 -> furnace duty penalty |
| `examples/transient_example.py` | Time-stepped tank inventory (`TransientRunner`) |
| `examples/optimisation_example.py` | Gross-margin optimisation subject to a furnace duty cap |
| `examples/fault_scenario.py` | Cooling-water failure -> condenser loss -> column pressure -> yield change |

## Tests

```bash
pytest
```

## Project structure

```
src/refinerycore/
    core/            ids, units, enums, events, errors, configuration
    fluids/           pseudocomponents, Fluid, property providers, crude assay
    thermodynamics/    ThermodynamicState, material/energy balances
    equipment/        pump, pipe, valve, heat exchanger, furnace, separator, tank, compressor
    units/            ProcessUnit base, desalter, shortcut distillation, CDU, VDU, FCC,
                      hydrocracker, hydrotreater, reformer
    networks/         process graph, hydrogen/steam/electrical/cooling networks
    solver/           sequential-modular steady-state solver, transient runner
    controls/         PID, sensors, alarms (simulation only -- see Safety boundary)
    twin/             digital twin state, equipment health, calibration
    faults/           fault definitions + propagation engine
    optimisation/      optimizer, sensitivity, Monte Carlo, scenarios
    economics/        prices, costs, margin (strictly downstream of physics)
    reporting/        KPIs, JSON/CSV/HTML export
    refinery.py        top-level Refinery digital twin
    cli.py             `refinerycore` command-line interface
```

## Safety boundary

Everything under `refinerycore.controls` (PID, sensors, alarms) is a
**simulation** component. Nothing in this repository connects to, or
issues commands to, a real industrial control system or physical
equipment. See spec section 56 / `docs/limitations.md`.

## License

MIT -- see [`LICENSE`](LICENSE).
