#!/usr/bin/env python3
"""Refinery optimisation example (spec section 64).

Objective: maximise refinery gross margin (product value - feed cost)
by tuning furnace outlet temperature and reflux ratio, subject to a
furnace duty cap, a column-pressure-implied reflux floor, and product
mix limits. All prices are illustrative -- see docs/limitations.md
(the economics layer is downstream of, and never contaminates, the
physical model).
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

import numpy as np  # noqa: E402

from refinerycore.demo import build_demo_refinery, run_demo_refinery  # noqa: E402
from refinerycore.economics.costs import OperatingCosts  # noqa: E402
from refinerycore.economics.margin import MarginCalculator  # noqa: E402
from refinerycore.economics.prices import PriceBook  # noqa: E402
from refinerycore.optimisation.optimizer import Constraint, DecisionVariable, RefineryOptimizer  # noqa: E402

# Illustrative price book -- USD/kg, entirely downstream of the physics.
PRICES = PriceBook(
    feed_prices_per_kg={"Demo Medium Crude": 0.42},
    product_prices_per_kg={
        "lpg": 0.55, "naphtha": 0.58, "kerosene": 0.62, "diesel": 0.60,
        "atm_gas_oil": 0.50, "residue": 0.28,
    },
)
MARGIN = MarginCalculator(operating_costs=OperatingCosts(price_book=PRICES))
DURATION_S = 3600.0  # evaluate on a one-hour basis


def gross_margin_per_hour(x: np.ndarray) -> float:
    furnace_t, reflux = float(x[0]), float(x[1])
    build = build_demo_refinery(furnace_outlet_temperature_K=furnace_t, reflux_ratio=reflux)
    run_demo_refinery(build)
    product_flows = {name: s.mass_flow_kg_s for name, s in build.cdu.product_streams.items()}
    feed_flows = {"Demo Medium Crude": build.crude_feed_stream.mass_flow_kg_s}
    return MARGIN.gross_margin(product_flows, feed_flows, DURATION_S)


def furnace_duty_w(x: np.ndarray) -> float:
    furnace_t, reflux = float(x[0]), float(x[1])
    build = build_demo_refinery(furnace_outlet_temperature_K=furnace_t, reflux_ratio=reflux)
    run_demo_refinery(build)
    return build.cdu.last_result["furnace"]["required_fired_duty_w"]


def main() -> None:
    optimizer = RefineryOptimizer(
        decision_variables=[
            DecisionVariable("furnace_outlet_temperature_K", 650.0, 600.0, 690.0),
            DecisionVariable("reflux_ratio", 2.5, 1.2, 4.5),
        ],
        objective_fn=gross_margin_per_hour,
        # 125 MW: below the ~137 MW the furnace would need at the top of the
        # temperature range, so this constraint is genuinely active (see
        # `python -c "from refinerycore.demo import ..."` sweep in
        # docs/limitations.md-adjacent notes -- baseline duty at 650 K is
        # ~120 MW, so a much lower cap would make the baseline itself
        # infeasible before optimisation even starts).
        constraints=[Constraint("furnace_duty_cap_125MW", furnace_duty_w, 0.0, 1.25e8)],
        maximize=True,
    )
    result = optimizer.optimise()

    print("Refinery gross-margin optimisation")
    print("-" * 50)
    print(f"Status:                    {result.status.value}")
    print(f"Baseline decision vars:    {result.baseline_decision_values}")
    print(f"Optimised decision vars:   {result.decision_values}")
    print(f"Baseline gross margin:     ${result.baseline_objective_value:,.2f} / h")
    print(f"Optimised gross margin:    ${result.objective_value:,.2f} / h")
    improvement = result.objective_value - result.baseline_objective_value
    print(f"Improvement:               ${improvement:,.2f} / h "
          f"({100 * improvement / abs(result.baseline_objective_value):.2f}%)")
    print(f"Constraint status:         {result.constraint_status}")


if __name__ == "__main__":
    main()
