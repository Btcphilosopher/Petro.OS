#!/usr/bin/env python3
"""First reference simulation (spec section 61).

Run with:

    python examples/simple_refinery.py

Builds the ~100,000 bbl/day demonstration refinery (see
``refinerycore.demo``), solves it steady-state, and prints the
spec-mandated summary report.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from refinerycore.core.units import pa_to_bar, w_to_mw  # noqa: E402
from refinerycore.demo import build_demo_refinery, run_demo_refinery  # noqa: E402


def main() -> None:
    build = build_demo_refinery()
    result = run_demo_refinery(build)

    crude = build.crude_feed_stream
    cdu_result = build.cdu.last_result
    products = build.cdu.product_streams
    furnace = cdu_result["furnace"]

    steam = build.refinery.steam_network.to_dict()
    electrical = build.refinery.electrical_network.to_dict()
    hydrogen = build.refinery.hydrogen_network.to_dict()

    mb = build.cdu.material_balance()
    eb = build.cdu.energy_balance(heat_in_w=furnace["required_fired_duty_w"])

    total_energy_w = furnace["required_fired_duty_w"]
    specific_energy_gj_t = (total_energy_w / 1.0e9) / (crude.mass_flow_kg_s / 1000.0)

    print("REFINERYCORE.OS")
    print("================")
    print()
    print(f"Refinery: {build.refinery.name}")
    print()
    print("Crude Feed")
    print("-----------")
    print(f"Flow:              {crude.mass_flow_kg_s:.1f} kg/s")
    print(f"Temperature:       {crude.temperature_K:.1f} K")
    print(f"Pressure:          {pa_to_bar(crude.pressure_Pa):.2f} bar")
    print()
    print("CDU")
    print("---")
    print(f"Furnace Duty:      {w_to_mw(furnace['required_fired_duty_w']):.2f} MW")
    print(f"Column Pressure:   {pa_to_bar(build.cdu.column_pressure_Pa):.2f} bar")
    print()
    print("Products")
    print("--------")
    for name in ("lpg", "naphtha", "kerosene", "diesel", "atm_gas_oil", "residue"):
        stream = products.get(name)
        t_per_h = (stream.mass_flow_kg_s * 3600.0 / 1000.0) if stream else 0.0
        print(f"{name.replace('_', ' ').title():<18} {t_per_h:>8.2f} t/h")
    print()
    print("Utilities")
    print("---------")
    steam_prod_t_h = steam['mp']['production_kg_s'] * 3.6
    print(f"Steam:             {steam_prod_t_h:.2f} t/h")
    print(f"Electricity:       {electrical['total_demand_w'] / 1.0e6:.2f} MW")
    print(f"Hydrogen:          {hydrogen['gross_production_kg_s'] * 3600.0:.2f} kg/h")
    print()
    print("Energy")
    print("------")
    print(f"Specific Energy:   {specific_energy_gj_t:.3f} GJ/t")
    print()
    print("Balances")
    print("--------")
    print(f"Mass residual:     {mb.absolute_residual_kg_s:.6g} kg/s")
    print(f"Energy residual:   {eb.residual_w:.6g} W")
    print()
    print("Solver")
    print("------")
    print(f"Status:            {result['final'].status.value.upper()}")
    print(f"Iterations:        {result['final'].iterations}")
    print(f"Residual norm:     {result['final'].residual_norm:.6g}")
    print()
    print("FIDELITY NOTICE: representative synthetic crude/utility data and")
    print("Level 1 engineering-approximation models. See docs/limitations.md.")


if __name__ == "__main__":
    main()
