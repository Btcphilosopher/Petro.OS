#!/usr/bin/env python3
"""CDU parametric example: furnace outlet temperature / reflux ratio -> yields."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from refinerycore.demo import build_demo_refinery, run_demo_refinery  # noqa: E402


def main() -> None:
    print("CDU sensitivity: furnace outlet temperature -> product yields")
    print("-" * 70)
    header = f"{'T_furnace (K)':>15} {'naphtha':>10} {'kerosene':>10} {'diesel':>10} {'AGO':>10} {'residue':>10}"
    print(header)
    for t in (600.0, 620.0, 640.0, 650.0, 660.0, 680.0, 700.0):
        build = build_demo_refinery(furnace_outlet_temperature_K=t)
        run_demo_refinery(build)
        y = build.cdu.last_result["product_yields_mass_fraction"]
        print(
            f"{t:>15.1f} {y['naphtha']:>10.4f} {y['kerosene']:>10.4f} "
            f"{y['diesel']:>10.4f} {y['atm_gas_oil']:>10.4f} {y['residue']:>10.4f}"
        )

    print()
    print("Reflux ratio -> naphtha/kerosene cut sharpness")
    print("-" * 70)
    for reflux in (1.0, 2.0, 2.5, 3.5, 5.0):
        build = build_demo_refinery(reflux_ratio=reflux)
        run_demo_refinery(build)
        y = build.cdu.last_result["product_yields_mass_fraction"]
        print(f"reflux={reflux:>4.1f}   naphtha={y['naphtha']:.4f}   kerosene={y['kerosene']:.4f}")


if __name__ == "__main__":
    main()
