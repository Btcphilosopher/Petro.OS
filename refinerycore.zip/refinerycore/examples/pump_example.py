#!/usr/bin/env python3
"""Pump curve / operating point / cavitation-risk example (spec section 14)."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from refinerycore.equipment.pump import Pump, PumpCurve  # noqa: E402
from refinerycore.fluids.fluid import Fluid  # noqa: E402
from refinerycore.fluids.properties import SimpleHydrocarbonPropertyProvider  # noqa: E402
from refinerycore.streams import Stream  # noqa: E402


def main() -> None:
    provider = SimpleHydrocarbonPropertyProvider()
    fluid = Fluid.pure("diesel")

    curve = PumpCurve(shutoff_head_m=140.0, rated_flow_m3_s=0.18, rated_head_m=100.0,
                       bep_flow_m3_s=0.16, bep_efficiency=0.78, max_flow_m3_s=0.35)
    pump = Pump(id="P-101", name="Crude feed pump", curve=curve)

    print("Pump P-101 operating point at increasing flow")
    print("-" * 60)
    print(f"{'flow (m3/s)':>12} {'head (m)':>10} {'eff.':>8} {'shaft kW':>10}")
    for flow in (0.05, 0.10, 0.16, 0.20, 0.25, 0.30):
        inlet = Stream(id="S-IN", name="in", fluid=fluid, mass_flow_kg_s=flow * 840.0,
                        pressure_Pa=2.0e5, temperature_K=310.0, provider=provider)
        pump.connect_input("inlet", inlet)
        result = pump.run()
        print(f"{flow:>12.3f} {result['head_m']:>10.2f} {result['efficiency']:>8.3f} "
              f"{result['shaft_power_w'] / 1000.0:>10.1f}")

    print()
    print("Health degradation effect at rated flow:")
    inlet = Stream(id="S-IN2", name="in", fluid=fluid, mass_flow_kg_s=0.16 * 840.0,
                    pressure_Pa=2.0e5, temperature_K=310.0, provider=provider)
    pump.connect_input("inlet", inlet)
    for health in (1.0, 0.85, 0.65, 0.45):
        pump.health.health_score = health
        result = pump.run()
        print(f"  health={health:.2f}  efficiency={result['efficiency']:.3f}  "
              f"shaft_power={result['shaft_power_w']/1000.0:.1f} kW  "
              f"cavitation_risk={result['cavitation_risk']}")


if __name__ == "__main__":
    main()
