#!/usr/bin/env python3
"""Heat exchanger LMTD / effectiveness-NTU example (spec section 12)."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from refinerycore.equipment.heat_exchanger import HeatExchanger  # noqa: E402
from refinerycore.fluids.fluid import Fluid  # noqa: E402
from refinerycore.fluids.properties import SimpleHydrocarbonPropertyProvider  # noqa: E402
from refinerycore.streams import Stream  # noqa: E402


def main() -> None:
    provider = SimpleHydrocarbonPropertyProvider()

    hot_in = Stream(id="HOT-IN", name="hot gas oil", fluid=Fluid.pure("light_gas_oil"),
                     mass_flow_kg_s=25.0, pressure_Pa=3.0e5, temperature_K=480.0, provider=provider)
    cold_in = Stream(id="COLD-IN", name="cold crude", fluid=Fluid.pure("diesel"),
                      mass_flow_kg_s=150.0, pressure_Pa=3.0e5, temperature_K=310.0, provider=provider)

    hx = HeatExchanger(id="HX-101", name="Crude preheat exchanger", ua_clean_w_k=8.0e5, heat_transfer_area_m2=250.0)
    hx.connect_input("hot_in", hot_in)
    hx.connect_input("cold_in", cold_in)
    result = hx.run()

    print("HX-101 -- clean")
    print(f"  UA effective:      {result['ua_effective_w_k']/1000:.1f} kW/K")
    print(f"  Duty:              {result['duty_w']/1.0e6:.3f} MW")
    print(f"  Duty (UA*LMTD):    {result['duty_from_ua_lmtd_w']/1.0e6:.3f} MW")
    print(f"  LMTD:              {result['lmtd_K']:.2f} K")
    print(f"  Effectiveness:     {result['effectiveness']:.3f}")
    print(f"  Hot outlet T:      {result['hot_outlet_temperature_K']:.2f} K")
    print(f"  Cold outlet T:     {result['cold_outlet_temperature_K']:.2f} K")
    print(f"  Approach (hot end):{result['approach_hot_end_K']:.2f} K")
    print(f"  Approach (cold end):{result['approach_cold_end_K']:.2f} K")


if __name__ == "__main__":
    main()
