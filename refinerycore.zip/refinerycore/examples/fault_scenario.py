#!/usr/bin/env python3
"""Fault propagation demonstration (spec section 62):

    NORMAL OPERATION
            v
    COOLING-WATER PUMP DEGRADATION
            v
    REDUCED COOLING FLOW
            v
    CONDENSER PERFORMANCE LOSS
            v
    COLUMN PRESSURE CHANGE
            v
    PRODUCT SEPARATION CHANGE

Every arrow above is a COMPUTED consequence, not narration: the cooling
water flow reduction changes the condenser's effectiveness-NTU duty
(``refinerycore.equipment.heat_exchanger``), the duty shortfall is
translated into a column pressure rise via a documented, simplified
condenser-pressure-control proxy, and the new column pressure is fed
back into the CDU's shortcut distillation model
(``refinerycore.units.distillation``) to get the new product split.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from refinerycore.demo import build_demo_refinery, run_demo_refinery  # noqa: E402
from refinerycore.equipment.heat_exchanger import HeatExchanger  # noqa: E402
from refinerycore.faults.faults import cooling_water_failure  # noqa: E402
from refinerycore.fluids.fluid import Fluid  # noqa: E402
from refinerycore.streams import Stream  # noqa: E402

#: Documented, simplified proxy: a condenser duty shortfall of X% is
#: assumed to require a column pressure rise of K*X% to maintain
#: condensation at the (now warmer) cooling water outlet temperature.
#: This is NOT a rigorous condenser/column pressure-control model.
PRESSURE_RISE_PER_DUTY_SHORTFALL = 0.6


def main() -> None:
    build = build_demo_refinery()
    run_demo_refinery(build)
    provider = build.cdu.provider

    baseline_yields = dict(build.cdu.last_result["product_yields_mass_fraction"])
    baseline_pressure_Pa = build.cdu.column_pressure_Pa

    # Overhead vapour proxy: the CDU's naphtha draw represents the
    # lightest condensing overhead product for this simplified demo.
    # Cooling water flow/UA are chosen so the condenser sits at a
    # moderate NTU (not saturated at effectiveness ~= 1) -- otherwise a
    # cooling-water flow cut would barely move the duty at all, which
    # would make this demonstration's causal chain invisible.
    overhead_vapour = build.cdu.product_streams["naphtha"]
    cooling_water = Stream(
        id="CW-IN", name="cooling water", fluid=Fluid.pure("light_ends"), mass_flow_kg_s=18.0,
        pressure_Pa=4.0e5, temperature_K=301.15, provider=provider,
    )

    condenser = HeatExchanger(id="E-101", name="CDU overhead condenser", ua_clean_w_k=4.5e4, heat_transfer_area_m2=150.0)
    condenser.connect_input("hot_in", overhead_vapour)
    condenser.connect_input("cold_in", cooling_water)
    baseline_condenser = condenser.run()

    print("STEP 1: NORMAL OPERATION")
    print(f"  Condenser duty:            {baseline_condenser['duty_w']/1.0e6:.3f} MW")
    print(f"  Column pressure:           {baseline_pressure_Pa/1.0e5:.3f} bar")
    print(f"  Naphtha yield:             {baseline_yields['naphtha']:.4f}")
    print(f"  Diesel yield:              {baseline_yields['diesel']:.4f}")

    print()
    print("STEP 2: COOLING-WATER PUMP DEGRADATION -> REDUCED COOLING FLOW")
    fault = cooling_water_failure(build.refinery.cooling_network, fraction_lost=0.35)
    fault.apply(build.refinery.cooling_network)
    degraded_cooling_water = cooling_water.with_state(mass_flow_kg_s=cooling_water.mass_flow_kg_s * 0.65)
    print(f"  {fault.description}")
    print(f"  Cooling water flow:        {cooling_water.mass_flow_kg_s:.1f} -> {degraded_cooling_water.mass_flow_kg_s:.1f} kg/s")

    print()
    print("STEP 3: CONDENSER PERFORMANCE LOSS")
    condenser.connect_input("cold_in", degraded_cooling_water)
    degraded_condenser = condenser.run()
    duty_shortfall_fraction = 1.0 - degraded_condenser["duty_w"] / baseline_condenser["duty_w"]
    print(f"  Condenser duty:            {degraded_condenser['duty_w']/1.0e6:.3f} MW "
          f"({-duty_shortfall_fraction:.1%} vs. baseline)")

    print()
    print("STEP 4: COLUMN PRESSURE CHANGE")
    new_pressure_Pa = baseline_pressure_Pa * (1.0 + PRESSURE_RISE_PER_DUTY_SHORTFALL * duty_shortfall_fraction)
    print(f"  Column pressure:           {baseline_pressure_Pa/1.0e5:.3f} -> {new_pressure_Pa/1.0e5:.3f} bar")

    print()
    print("STEP 5: PRODUCT SEPARATION CHANGE")
    faulted_build = build_demo_refinery(column_pressure_Pa=new_pressure_Pa)
    run_demo_refinery(faulted_build)
    faulted_yields = faulted_build.cdu.last_result["product_yields_mass_fraction"]
    print(f"  Naphtha yield:             {baseline_yields['naphtha']:.4f} -> {faulted_yields['naphtha']:.4f}")
    print(f"  Diesel yield:              {baseline_yields['diesel']:.4f} -> {faulted_yields['diesel']:.4f}")
    print(f"  Residue yield:             {baseline_yields['residue']:.4f} -> {faulted_yields['residue']:.4f}")


if __name__ == "__main__":
    main()
