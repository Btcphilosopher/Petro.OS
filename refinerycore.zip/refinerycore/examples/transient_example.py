#!/usr/bin/env python3
"""Transient simulation example (spec section 35): a product tank filling
then drawing down under changing in/out flows, stepped through
:class:`~refinerycore.solver.transient.TransientRunner`."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from refinerycore.equipment.tank import StorageTank  # noqa: E402
from refinerycore.fluids.fluid import Fluid  # noqa: E402
from refinerycore.fluids.properties import SimpleHydrocarbonPropertyProvider  # noqa: E402
from refinerycore.solver.transient import SimulationClock, TransientRunner  # noqa: E402
from refinerycore.streams import Stream  # noqa: E402


def main() -> None:
    provider = SimpleHydrocarbonPropertyProvider()
    fluid = Fluid.pure("diesel")

    tank = StorageTank(id="TK-201", name="Diesel product tank", diameter_m=25.0, height_m=12.0, level_m=6.0)

    def step_fn(clock: SimulationClock) -> dict:
        # Inflow from the CDU diesel draw for the first half of the run,
        # then it's diverted elsewhere (inflow stops) while export continues.
        inflow_kg_s = 8.0 if clock.step_count <= 30 else 0.0
        outflow_kg_s = 6.0

        tank.inputs["inflow"] = Stream(id="in", name="in", fluid=fluid, mass_flow_kg_s=inflow_kg_s,
                                        pressure_Pa=1.0e5, temperature_K=310.0, provider=provider)
        tank.inputs["outflow"] = Stream(id="out", name="out", fluid=fluid, mass_flow_kg_s=outflow_kg_s,
                                         pressure_Pa=1.0e5, temperature_K=310.0, provider=provider)
        return tank.step(clock.dt_s)

    clock = SimulationClock(dt_s=600.0)  # 10-minute steps
    runner = TransientRunner(clock=clock, step_fn=step_fn)
    history = runner.run(n_steps=60)  # 10 hours

    print("Time (h)   Level (m)   Fill fraction")
    for i, snapshot in enumerate(history):
        if i % 6 != 0:  # print hourly
            continue
        print(f"{snapshot.time_s/3600.0:>8.2f}   {snapshot.values['level_m']:>8.3f}   {snapshot.values['fill_fraction']:>6.3f}")


if __name__ == "__main__":
    main()
