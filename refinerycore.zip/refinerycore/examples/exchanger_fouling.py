#!/usr/bin/env python3
"""Exchanger fouling demonstration (spec section 63).

Advances HX-101's fouling model over Day 0/30/60/90/180 and shows the
resulting UA/duty/outlet-temperature degradation and the furnace duty
increase needed to compensate.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from refinerycore.equipment.heat_exchanger import FoulingModel, HeatExchanger  # noqa: E402
from refinerycore.equipment.furnace import Furnace  # noqa: E402
from refinerycore.fluids.fluid import Fluid  # noqa: E402
from refinerycore.fluids.properties import SimpleHydrocarbonPropertyProvider  # noqa: E402
from refinerycore.streams import Stream  # noqa: E402


def main() -> None:
    provider = SimpleHydrocarbonPropertyProvider()

    hot_in = Stream(id="HOT-IN", name="hot gas oil", fluid=Fluid.pure("light_gas_oil"),
                     mass_flow_kg_s=25.0, pressure_Pa=3.0e5, temperature_K=480.0, provider=provider)
    cold_in = Stream(id="COLD-IN", name="cold crude", fluid=Fluid.pure("diesel"),
                      mass_flow_kg_s=150.0, pressure_Pa=3.0e5, temperature_K=310.0, provider=provider)

    hx = HeatExchanger(id="HX-101", name="Crude preheat exchanger", ua_clean_w_k=8.0e5, heat_transfer_area_m2=250.0,
                        fouling=FoulingModel())
    hx.connect_input("hot_in", hot_in)
    hx.connect_input("cold_in", cold_in)

    furnace = Furnace(id="F-100", name="CDU Furnace", target_outlet_temperature_K=650.0)

    print(f"{'Day':>5} {'UA (kW/K)':>10} {'Duty (MW)':>10} {'Cold out (K)':>13} {'Furnace duty (MW)':>18}")
    for day in (0, 30, 60, 90, 180):
        hx.fouling.elapsed_hours = day * 24.0
        hx_result = hx.run()

        preheated_crude = cold_in.with_state(temperature_K=hx_result["cold_outlet_temperature_K"])
        furnace.connect_input("feed", preheated_crude)
        furnace_result = furnace.run()

        print(
            f"{day:>5} {hx_result['ua_effective_w_k']/1000:>10.1f} {hx_result['duty_w']/1.0e6:>10.3f} "
            f"{hx_result['cold_outlet_temperature_K']:>13.2f} {furnace_result['required_fired_duty_w']/1.0e6:>18.3f}"
        )

    print()
    print("As HX-101 fouls, less preheat is delivered to the crude, so the")
    print("furnace must supply more duty (and burn more fuel) to reach the")
    print("same 650 K outlet target -- the causal chain this project models.")


if __name__ == "__main__":
    main()
