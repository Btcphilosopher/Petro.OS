# Equipment models

Each model's governing equation is quoted in its `calculate()` result
dict under the `"equation"` key. Summary:

| Equipment | Key equation(s) | Fidelity |
| --- | --- | --- |
| `Pump` | `P_hydraulic = rho*g*Q*H`; `P_shaft = P_hydraulic/eta`; quadratic head curve, parabolic efficiency curve, NPSH-available check | Level 1 |
| `Pipe` | Darcy-Weisbach `dP = f*(L/D)*0.5*rho*v^2`; Reynolds number; friction factor: laminar `64/Re`, transition blend, Swamee-Jain (turbulent) or Blasius (smooth-pipe helper) | Level 1 |
| `Valve` | Liquid: `Q_gpm = Cv*sqrt(dP_psi/SG)`; gas: choked-flow-limited at a critical pressure ratio of 0.5; linear/equal-%/quick-opening characteristics | Level 1 |
| `HeatExchanger` | `Q = UA*LMTD` cross-checked against effectiveness-NTU; `FoulingModel` reduces UA via Kern-Seaton asymptotic fouling `R_f(t) = R_f_inf*(1-exp(-t/tau))` | Level 1 |
| `Furnace` | `Q_process = m_dot*Cp*dT`; `fuel_flow = (Q_process + losses)/(LHV*eta_comb)`; CO2 from a fixed fuel-gas emission factor | Level 1 |
| `Separator` | Phase split from the property provider's flashed vapour fraction; Souders-Brown terminal-velocity flooding check | Level 1 |
| `StorageTank` | `V = A*level`; explicit mass balance over a time step (`step`) | Level 1 |
| `Compressor` | Isentropic `T2s = T1*r^((k-1)/k)`; actual work via isentropic efficiency; optional linear surge/choke envelope | Level 1 |

## What is NOT modelled

* No mechanical-code (ASME/API) vessel design -- `Separator` sizing
  checks are indicative only.
* No detailed combustion mechanism in `Furnace` -- CO2 comes from a
  single documented emission factor, not a species-balance combustion
  model.
* No compressor/pump vendor curve digitisation -- curves are fit
  through three named points (shutoff, BEP, rated), not vendor data.
* No cavitation/choked-flow *physics* beyond a threshold indicator --
  these are diagnostic flags, not a two-phase flow solver.

See `docs/limitations.md` for the full list.
