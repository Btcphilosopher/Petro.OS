# Limitations and fidelity declarations

Read this before using any number REFINERYCORE.OS produces for a real
decision. Every model in this repository declares a fidelity level
(`refinerycore.core.enums.FidelityLevel`):

* **Level 0 -- conceptual**: captures the right qualitative behaviour
  (direction of change, rough magnitude) with a documented, simplified
  correlation. FCC, Hydrocracker, Hydrotreater, Reformer, Desalter,
  CompressorMap.
* **Level 1 -- engineering approximation**: standard textbook
  correlations (Darcy-Weisbach, LMTD/effectiveness-NTU, isentropic
  compression, Cv sizing, ...) applied with representative, documented
  parameters rather than vendor/plant-specific data. Pump, Pipe, Valve,
  HeatExchanger, Furnace, Separator, StorageTank, Compressor, the
  shortcut CDU/VDU distillation model, MaterialBalance/EnergyBalance.
* **Level 2 -- detailed process model**: none shipped in this
  repository yet (see "What a Level 2 column would add" below).
* **Level 3/4 -- validated / plant-specific / specialist**: **not
  present**. Nothing here is validated against, or certified for, any
  named physical plant.

## Explicitly NOT implemented (do not assume otherwise)

* **Rigorous VLE / K-values / tray-by-tray MESH equations.** The
  distillation model (`refinerycore.units.distillation`) is a
  *shortcut cutpoint-recovery model*: it makes furnace temperature,
  column pressure and reflux ratio move product yields in the right
  direction with the right rough sensitivity, using pseudocomponent
  boiling ranges and a documented pressure/reflux correction -- it does
  **not** solve stage compositions, K-values, or a bubble-point/dew-point
  per tray. A Level 2 follow-on would add: `DistillationColumn` with an
  explicit stage count, K-value correlations (e.g. Wilson/DePriester),
  and per-stage mass/energy balances solved simultaneously.
* **CoolProp / Cantera / real steam tables.** `PropertyProvider` is
  designed so a `CoolPropProvider`/`WaterSteamProvider` can be added
  without touching equipment code, but neither is implemented; the
  steam network uses fixed representative enthalpy constants
  (`refinerycore.networks.steam.STEAM_ENTHALPY_J_KG`) instead of a
  steam-table lookup.
* **Detailed combustion mechanism.** `Furnace` CO2 comes from one fixed
  emission factor (kg CO2 per kg fuel), not a species/O2/excess-air
  combustion balance; `excess_air_fraction` is tracked as a parameter
  but only weakly affects the stack-temperature estimate.
* **Vendor pump/compressor curves.** Curves are fit through three named
  points (shutoff, BEP, rated/max), not digitised manufacturer data.
* **Mechanical-code vessel design.** `Separator`/`StorageTank` sizing
  checks (residence time, Souders-Brown velocity, level) are indicative
  engineering checks, not an ASME/API-code mechanical design.
* **Rigorous reaction kinetics.** FCC/Hydrocracker/Hydrotreater/Reformer
  are fixed-selectivity yield-table models driven by a single
  "conversion"/"severity" correlation -- there is no riser kinetics,
  catalyst deactivation, or multi-lump kinetic model.
* **Fast transients.** The transient solver is explicit-Euler at
  user-chosen step sizes; it is not intended for seconds-scale dynamics
  (water hammer, compressor surge transients, relief-valve response).
* **PDF reporting.** JSON/CSV/HTML export exist; PDF is out of scope
  (spec marks it optional).
* **A FastAPI service, 3D front-end, or `RefineryAnalysisAgent`.** The
  architecture (event bus, serialisable twin state, machine-readable
  state export) is designed so these can be added without touching
  physics, but none is implemented in this initial repository.
* **Real industrial control-system integration.** See the Safety
  boundary in `README.md` -- `refinerycore.controls` is simulation-only.

## Synthetic data disclosure

* The demonstration crude assay (`refinerycore.demo.build_demo_crude_assay`)
  is a synthetic, representative ~35 API medium crude with a
  hand-authored TBP curve -- it is not measurement data for any real
  crude.
* Utility intensities in `refinerycore.demo` (steam per kg crude,
  baseline electrical load, condenser duty fraction) are documented,
  representative estimates for a ~100 kbpd site, not measured plant
  data.
* Prices in `examples/optimisation_example.py` are illustrative only.

## The CDU/VDU energy balance residual is expected to be nonzero

`CDU.energy_balance()` / `VDU.energy_balance()` compare the furnace's
process duty (heat delivered to the crude) against the enthalpy
difference between the crude feed and the product draws. The shortcut
column model does **not** include an explicit overhead
condenser/reflux duty term, so the energy removed to bring the lighter
draws down to their (lower) bubble-point temperatures is not currently
credited anywhere -- the resulting nonzero residual is the balance
*correctly exposing* that missing term (per spec section 9: "do not
silently force balances to zero"), not a solver bug. A Level 2 follow-on
would add an explicit condenser duty to close this balance.

## Correlation applicability

Correlations used outside their documented range warn rather than fail
silently (see `refinerycore.core.errors.CorrelationRangeWarning`,
raised e.g. by `equipment.pipe.blasius_friction_factor` outside
4000 < Re < 1e5). The primary friction-factor path
(`darcy_friction_factor`) always uses the wider-range Swamee-Jain
approximation in the turbulent regime rather than Blasius, precisely to
avoid this limitation in the default flow.
