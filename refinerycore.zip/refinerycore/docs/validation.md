# Validation

## What "validated" means here

Nothing in this repository is validated against a real, named plant
(that would be Level 3/4 fidelity -- see `docs/limitations.md`). "Validated"
in this document means: the unit tests in `tests/` pass, and each
physics module's invariants and dimensional consistency are checked
automatically.

## Test coverage by area

* `tests/test_units.py` -- unit-conversion round trips; the dimensional
  identity `kg/s * J/kg = W`.
* `tests/test_fluids.py` -- composition invariants (mass fractions sum
  to 1, no negative fractions), API-gravity/density round trip, TBP
  interpolation monotonicity, property-provider positivity and
  pressure-scaling (ideal gas).
* `tests/test_balances.py` -- material balance closure/non-closure
  detection, negative-flow rejection, component residuals, composition
  validation; energy balance closure and residual exposure.
* `tests/test_pumps.py` -- `P_hydraulic = rho*g*Q*H` and
  `P_shaft = P_hydraulic/eta` verified numerically against the model's
  own output; efficiency bounded in (0, 1]; health degradation reduces
  efficiency and raises shaft power.
* `tests/test_pipes.py` -- Reynolds number linearity in velocity,
  laminar friction factor `64/Re`, turbulent friction factor positivity
  and Re-trend, pressure drop scaling with length.
* `tests/test_heat_exchangers.py` -- LMTD formula against a known case,
  UA*LMTD vs. effectiveness-NTU duty agreement, fouling monotonically
  reduces UA/duty over time, cleaning resets fouling.
* `tests/test_cdu.py` -- product yields sum to ~1, material balance
  closes, higher furnace temperature recovers more distillate (the
  central causal-chain claim), furnace duty increases with crude rate.
* `tests/test_solver.py` -- sequential-modular execution order,
  failed-block reporting, process-graph cycle detection, recycle solver
  convergence and failure-to-converge raising `ConvergenceError`.
* `tests/test_refinery.py` -- end-to-end demo refinery: converges,
  balances close, process graph is connected, twin-state JSON
  round-trips, fault propagation (pump degradation, HX fouling) changes
  the expected direction, optimiser does not regress the baseline,
  scenario runner produces a comparable table, Monte Carlo is
  reproducible given a fixed seed.

## Property-based invariants exercised

* Mass fractions sum to 1 (`Fluid.__post_init__`, `MaterialBalance.validate`).
* Density, pressure, temperature > 0 (`NonPhysicalStateError` at
  construction / property-evaluation time).
* Mass flow >= 0 (`Stream.__post_init__`, `MaterialBalance.add_*flow`).
* Efficiency in (0, 1] (pump/compressor).

`hypothesis` is listed as a dev dependency for future property-based
tests generalising the above over random valid inputs; the current test
suite exercises these invariants with representative fixed cases.

## Running the suite

```bash
pip install -e ".[dev]"
pytest
python examples/simple_refinery.py
```
