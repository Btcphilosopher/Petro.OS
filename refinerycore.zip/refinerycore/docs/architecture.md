# Architecture

## The central axiom

```
                    REFINERY
                       |
              +--------+--------+
              |                 |
          MATERIAL           ENERGY
          BALANCE             BALANCE
              |                 |
              +--------+--------+
                       |
                THERMODYNAMICS
                       |
                PROCESS SOLVER
                       |
              +--------+--------+
              |                 |
          EQUIPMENT          UTILITIES
              |                 |
              +--------+--------+
                       |
                 DIGITAL TWIN
                       |
        +--------------+--------------+
        |              |              |
     FAULTS       OPTIMISATION    SCENARIOS
        |              |              |
        +--------------+--------------+
                       |
                  ENGINEERING
                    OUTPUT
```

The refinery is the source of truth: `PHYSICAL REALITY -> MATHEMATICAL
MODEL -> NUMERICAL SOLVER -> DIGITAL STATE -> DECISION`. The UI/API/
reporting layer only ever *reads* what the physics layer computed; it
never invents an engineering value.

## Layering

```
refinerycore.core          <- units, ids, enums, events, errors, configuration (no physics)
refinerycore.fluids        <- pseudocomponents, Fluid, PropertyProvider, CrudeAssay
refinerycore.thermodynamics <- ThermodynamicState, MaterialBalance, EnergyBalance
refinerycore.streams        <- Stream (composition + state + topology)
refinerycore.equipment      <- single-unit-op physics (pump, pipe, valve, HX, furnace, ...)
refinerycore.units          <- composite ProcessUnits built from equipment (CDU, VDU, ...)
refinerycore.networks       <- process graph + utility networks (H2/steam/electrical/cooling)
refinerycore.solver         <- steady-state (sequential-modular / recycle) and transient
refinerycore.controls       <- simulated PID/sensors/alarms
refinerycore.twin           <- digital twin state, equipment health, calibration
refinerycore.faults         <- fault definitions + propagation
refinerycore.optimisation   <- optimizer, sensitivity, Monte Carlo, scenarios
refinerycore.economics      <- prices/costs/margin (strictly downstream of physics)
refinerycore.reporting      <- KPIs + JSON/CSV/HTML export
refinerycore.refinery       <- top-level Refinery digital twin orchestrator
```

Each layer only depends on layers above it in this list (`economics`
depends on physical outputs, never the reverse; `equipment` never
imports `economics`). This is enforced by convention and by the
dependency-direction tests, not by a build-time boundary tool.

## Units

Every physical quantity inside `fluids`, `thermodynamics`, `equipment`,
`units`, `networks` and `solver` is SI: Pa, K, kg/s, m^3/s, kg/m^3, J,
W, J/kg, J/(kg K), Pa.s, m, m/s. `refinerycore.core.units` provides
named, tested conversion functions (`bar_to_pa`, `celsius_to_kelvin`,
`kg_per_h_to_kg_per_s`, `bbl_per_day_to_m3_per_s`, `kw_to_w`,
`mj_per_kg_to_j_per_kg`, ...) used only at the CLI/config/reporting
boundary. Gauge and absolute pressure are never conflated silently --
`barg_to_pa`/`pa_to_barg` make the conversion explicit.

## Money never touches physics

`refinerycore.economics` consumes physical outputs (mass/energy flows)
through a `PriceBook`; it has no import path back into `fluids`,
`thermodynamics`, `equipment`, `units`, `networks` or `solver`.

## The process graph and the solver

`refinerycore.networks.process_graph.ProcessGraph` is a thin wrapper
over `networkx.DiGraph`: equipment/unit ids are nodes, streams are
edges. `refinerycore.solver.steady_state.SequentialModularSolver` runs
each unit's `.run()` in topological order -- correct for the acyclic
flowsheets in this repository's examples (no recycle). Where recycle
does exist (e.g. a hydrogen recycle loop), `solve_recycle` tears the
loop and solves the residual with `scipy.optimize.root`, exposing
iterations, residual norm and convergence status, and raising
`ConvergenceError` (never silently returning a bad state) if it fails.

## Digital thread

Every equipment/unit `.calculate()` result dict carries at least an
`"equation"` key naming the governing relation, plus every intermediate
quantity that fed the final answer (e.g. `HeatExchanger` exposes
`ua_effective_w_k`, `fouling_resistance_m2_k_w`, `ntu`, `effectiveness`,
`lmtd_K` alongside `duty_w`) so a caller can inspect *how* a number was
produced, not just read the number.

## Safety boundary

`refinerycore.controls` (PID/sensors/alarms) is a **simulation**
component only. Nothing in this repository issues a command to, or
reads a live value from, a real industrial control system.
