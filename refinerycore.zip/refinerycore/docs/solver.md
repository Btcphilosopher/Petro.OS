# Solver

## Steady state

`refinerycore.solver.steady_state.SequentialModularSolver` runs every
registered block (`equipment.run` / `process_unit.run`) once, in the
topological order given by `refinerycore.networks.process_graph.ProcessGraph`.
This is exact for the acyclic flowsheets shipped in this repository
(feed pump -> CDU -> reformer/hydrotreater, with no recycle). A failed
block is caught and recorded in `SolveResult.failed_equations` rather
than raising immediately, so a solve attempt always returns a result
you can inspect; `SolveResult.converged` is `False` whenever any block
failed.

For a flowsheet WITH recycle (e.g. a torn hydrogen recycle stream),
`solve_recycle(residual_fn, x0)` wraps `scipy.optimize.root` and always
exposes `iterations` and `residual_norm`; on failure it raises
`ConvergenceError` rather than returning an unconverged state silently.
No example in this repository currently exercises a recycle loop end to
end -- it is provided as the extension point spec section 34 asks for.

## Transient

`refinerycore.solver.transient.TransientRunner` is explicit-Euler time
stepping: at each tick it calls a user-supplied `step_fn(clock)` (e.g.
`StorageTank.step`, or advancing a `FoulingModel` and re-running a heat
exchanger). This is adequate for the slow, hours-to-days drift
processes the examples target (tank draw-down, exchanger fouling) --
it is **not** a DAE/ODE solver with adaptive step control, and it is
not intended for fast (seconds-scale) transients like water hammer or
compressor surge dynamics. `SimulationEvent`s can be injected at any
point in the run (`TransientRunner.inject_event`) to record a
discrete disturbance (a pump trip, a valve step change) alongside the
continuous trajectory.

## What "converged" means here

* `SequentialModularSolver`: converged = every registered block ran
  without raising. `iterations` is always 1 by construction (a
  no-recycle sequential pass), documented as such in the result.
* `solve_recycle`: converged = `scipy.optimize.root` reports success
  within `max_iterations` function evaluations and the returned
  residual norm is reported alongside the status.
