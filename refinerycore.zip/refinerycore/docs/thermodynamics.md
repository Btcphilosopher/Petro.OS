# Thermodynamics

## Fluid model

Streams carry a `Fluid` (a mass-fraction mixture of the ten
boiling-range pseudocomponents in `refinerycore.fluids.components`,
from `light_ends` to `residue`). This is a **Level 1 engineering
approximation**: real crude characterisation uses tens to hundreds of
pseudocomponents (or a continuous TBP distribution); ten cuts is enough
to make furnace-temperature / reflux / pressure changes propagate to
product yields in a physically sensible, monotonic way, which is this
project's stated goal -- it is not a substitute for a licensed
simulator's characterisation.

## Property providers

`refinerycore.fluids.properties.PropertyProvider` is the seam between
"what equipment needs" (density, enthalpy, phase, viscosity, ...) and
"how it's computed." Two are implemented:

* `SimpleHydrocarbonPropertyProvider` -- a blended-NBP flash (fully
  liquid below NBP - 15 K, fully vapour above NBP + 15 K, linear
  two-phase ramp between), reciprocal-blended liquid density with a
  constant thermal expansion coefficient, sensible + latent enthalpy,
  and an Arrhenius-type viscosity correlation anchored at 15 degC. No
  rigorous VLE/K-value calculation is performed.
* `IdealGasPropertyProvider` -- for light-gas streams (fuel gas,
  hydrogen network), full ideal-gas law density, constant-Cp enthalpy.

A `CoolPropProvider` or `WaterSteamProvider` is a natural extension
point (see `PropertyProvider` Protocol) but is **not implemented** in
this repository -- see `docs/limitations.md`.

## ThermodynamicState

`refinerycore.thermodynamics.state.ThermodynamicState` provides named
constructors `from_PT`, `from_PH`, `from_PS`, `from_TH`, `from_TS`.
`from_PT` calls the provider directly; `from_PH`/`from_PS` solve a 1-D
root-finding problem (`scipy.optimize.brentq`, bracketed on [150, 1200]
K) rather than guessing. `from_TH`/`from_TS` are provided for interface
completeness but only succeed when the requested pair is already
consistent with the property model (the current providers are
pressure-independent for enthalpy/entropy).

## Balances

`refinerycore.thermodynamics.balances.MaterialBalance` and
`EnergyBalance` never silently force a residual to zero. Both expose
`absolute_residual` / `relative_residual` and a `.validate()` that
raises a typed error (`MaterialBalanceError` / `EnergyBalanceError`) if
the balance does not close within tolerance. `MaterialBalance` also
detects negative flows and compositions that do not sum to 1 at
construction time.
