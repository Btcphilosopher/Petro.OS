"""Unit-conversion round-trip tests (spec section 65-66)."""

from __future__ import annotations

import math

from refinerycore.core import units as u


def test_pressure_round_trips():
    assert math.isclose(u.pa_to_bar(u.bar_to_pa(3.5)), 3.5, rel_tol=1e-9)
    assert math.isclose(u.pa_to_psi(u.psi_to_pa(120.0)), 120.0, rel_tol=1e-9)
    assert math.isclose(u.pa_to_kpa(u.kpa_to_pa(500.0)), 500.0, rel_tol=1e-9)
    assert math.isclose(u.pa_to_mpa(u.mpa_to_pa(2.0)), 2.0, rel_tol=1e-9)


def test_gauge_absolute_pressure_never_conflated():
    absolute = u.barg_to_pa(0.0)
    assert math.isclose(absolute, u.ATMOSPHERIC_PRESSURE_PA, rel_tol=1e-6)
    assert math.isclose(u.pa_to_barg(absolute), 0.0, abs_tol=1e-9)


def test_temperature_round_trips():
    assert math.isclose(u.kelvin_to_celsius(u.celsius_to_kelvin(25.0)), 25.0, abs_tol=1e-9)
    assert math.isclose(u.kelvin_to_fahrenheit(u.fahrenheit_to_kelvin(98.6)), 98.6, abs_tol=1e-6)
    # 0 degC == 273.15 K, never conflated with 0 K
    assert math.isclose(u.celsius_to_kelvin(0.0), 273.15, abs_tol=1e-9)


def test_mass_flow_round_trips():
    assert math.isclose(u.kg_per_s_to_kg_per_h(u.kg_per_h_to_kg_per_s(3600.0)), 3600.0, rel_tol=1e-9)
    assert math.isclose(u.kg_per_s_to_t_per_h(u.t_per_h_to_kg_per_s(10.0)), 10.0, rel_tol=1e-9)


def test_volume_flow_round_trips():
    assert math.isclose(u.m3_per_s_to_bbl_per_day(u.bbl_per_day_to_m3_per_s(100_000.0)), 100_000.0, rel_tol=1e-6)
    assert math.isclose(u.m3_per_s_to_m3_per_day(u.m3_per_day_to_m3_per_s(500.0)), 500.0, rel_tol=1e-9)


def test_power_energy_round_trips():
    assert math.isclose(u.w_to_kw(u.kw_to_w(50.0)), 50.0, rel_tol=1e-9)
    assert math.isclose(u.w_to_mw(u.mw_to_w(12.0)), 12.0, rel_tol=1e-9)
    assert math.isclose(u.w_to_gw(u.gw_to_w(0.5)), 0.5, rel_tol=1e-9)
    assert math.isclose(u.j_to_kwh(u.kwh_to_j(7.0)), 7.0, rel_tol=1e-9)
    assert math.isclose(u.j_per_kg_to_mj_per_kg(u.mj_per_kg_to_j_per_kg(40.0)), 40.0, rel_tol=1e-9)
    assert math.isclose(u.j_per_kg_to_btu_per_lb(u.btu_per_lb_to_j_per_kg(1000.0)), 1000.0, rel_tol=1e-6)


def test_dimensional_check_kg_s_times_j_kg_is_watts():
    # kg/s * J/kg = J/s = W (spec section 65)
    mass_flow_kg_s = 10.0
    specific_enthalpy_j_kg = 500.0
    power_w = u.energy_flow_w(mass_flow_kg_s, specific_enthalpy_j_kg)
    assert power_w == 5000.0
