"""Steady-state solver tests (spec section 34)."""

from __future__ import annotations

import numpy as np
import pytest

from refinerycore.core.enums import ConvergenceStatus
from refinerycore.core.errors import ConvergenceError, ProcessGraphError
from refinerycore.networks.process_graph import ProcessGraph
from refinerycore.solver.steady_state import SequentialModularSolver, solve_recycle


def test_sequential_modular_solver_runs_in_topological_order():
    graph = ProcessGraph()
    graph.add_equipment("A")
    graph.add_equipment("B")
    graph.graph.add_edge("A", "B")

    call_order: list[str] = []
    solver = SequentialModularSolver(graph=graph)
    solver.register("A", lambda: call_order.append("A") or {"ok": True})
    solver.register("B", lambda: call_order.append("B") or {"ok": True})

    result = solver.solve()
    assert result.converged
    assert call_order == ["A", "B"]


def test_sequential_modular_solver_reports_failed_block():
    graph = ProcessGraph()
    graph.add_equipment("A")

    def failing_block():
        raise ValueError("boom")

    solver = SequentialModularSolver(graph=graph)
    solver.register("A", failing_block)
    result = solver.solve()

    assert result.status is ConvergenceStatus.FAILED
    assert result.failed_equations
    assert "boom" in result.failed_equations[0]


def test_process_graph_detects_cycle():
    graph = ProcessGraph()
    graph.graph.add_edge("A", "B")
    graph.graph.add_edge("B", "A")
    with pytest.raises(ProcessGraphError):
        graph.topological_order()


def test_solve_recycle_converges_on_simple_fixed_point():
    # x_new = 0.5 * x_old + 3  ->  residual(x) = (0.5*x + 3) - x = 3 - 0.5*x
    def residual(x: np.ndarray) -> np.ndarray:
        return np.array([3.0 - 0.5 * x[0]])

    result = solve_recycle(residual, x0=np.array([0.0]))
    assert result.converged
    assert result.residual_norm < 1e-4


def test_solve_recycle_raises_on_no_solution():
    def residual(x: np.ndarray) -> np.ndarray:
        return np.array([1.0])  # constant, never zero

    with pytest.raises(ConvergenceError):
        solve_recycle(residual, x0=np.array([0.0]), max_iterations=5)
