"""Heat exchanger and fouling model tests (spec sections 12-13)."""

from __future__ import annotations

from refinerycore.equipment.heat_exchanger import FoulingModel, HeatExchanger, lmtd_counter_current
from refinerycore.fluids.fluid import Fluid
from refinerycore.fluids.properties import SimpleHydrocarbonPropertyProvider
from refinerycore.streams import Stream


def _hx_with_streams(fouling: FoulingModel | None = None) -> HeatExchanger:
    provider = SimpleHydrocarbonPropertyProvider()
    hot_in = Stream(
        id="HOT-IN", name="hot in", fluid=Fluid.pure("light_gas_oil"), mass_flow_kg_s=20.0,
        pressure_Pa=3.0e5, temperature_K=470.0, provider=provider,
    )
    cold_in = Stream(
        id="COLD-IN", name="cold in", fluid=Fluid.pure("diesel"), mass_flow_kg_s=25.0,
        pressure_Pa=3.0e5, temperature_K=320.0, provider=provider,
    )
    hx = HeatExchanger(id="HX-1", name="test hx", ua_clean_w_k=2.0e5, heat_transfer_area_m2=100.0,
                        fouling=fouling or FoulingModel())
    hx.connect_input("hot_in", hot_in)
    hx.connect_input("cold_in", cold_in)
    return hx


def test_heat_exchanger_duty_positive_and_hot_cools_cold_heats():
    hx = _hx_with_streams()
    result = hx.run()
    assert result["duty_w"] > 0
    assert result["hot_outlet_temperature_K"] < 470.0
    assert result["cold_outlet_temperature_K"] > 320.0


def test_heat_exchanger_lmtd_matches_ua_duty_within_tolerance():
    hx = _hx_with_streams()
    result = hx.run()
    # Q = UA * LMTD should approximately match the effectiveness-NTU duty
    assert abs(result["duty_w"] - result["duty_from_ua_lmtd_w"]) / result["duty_w"] < 0.05


def test_lmtd_counter_current_known_case():
    # dT1 = 100-40 = 60, dT2 = 60-20 = 40 -> LMTD = (60-40)/ln(60/40)
    import math

    lmtd = lmtd_counter_current(100.0, 60.0, 20.0, 40.0)
    expected = (60.0 - 40.0) / math.log(60.0 / 40.0)
    assert math.isclose(lmtd, expected, rel_tol=1e-9)


def test_fouling_reduces_effective_ua():
    hx_clean = _hx_with_streams(fouling=FoulingModel(elapsed_hours=0.0))
    hx_fouled = _hx_with_streams(fouling=FoulingModel(elapsed_hours=5000.0))
    assert hx_fouled.ua_effective_w_k < hx_clean.ua_effective_w_k


def test_fouling_reduces_duty_over_time():
    hx = _hx_with_streams()
    day0 = hx.run()
    hx.fouling.advance(24.0 * 180.0)  # 180 days
    day180 = hx.run()
    assert day180["duty_w"] < day0["duty_w"]
    assert day180["fouling_resistance_m2_k_w"] > day0["fouling_resistance_m2_k_w"]


def test_fouling_asymptotic_resistance_bounded():
    model = FoulingModel(r_f_asymptotic_m2_k_w=6.0e-4, tau_hours=1500.0, elapsed_hours=1.0e6)
    assert model.fouling_resistance_m2_k_w <= model.r_f_asymptotic_m2_k_w * 1.0001


def test_cleaning_event_resets_fouling():
    model = FoulingModel(elapsed_hours=5000.0)
    assert model.fouling_resistance_m2_k_w > 0
    model.clean()
    assert model.fouling_resistance_m2_k_w == 0.0
