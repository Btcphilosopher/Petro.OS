"""CDU integration tests -- the core causal chain this project is built
around: crude rate / furnace outlet temperature / reflux ratio -> yields."""

from __future__ import annotations

import pytest

from refinerycore.demo import build_demo_refinery, run_demo_refinery


def _yields(furnace_outlet_temperature_K: float = 650.0, reflux_ratio: float = 2.5) -> dict[str, float]:
    build = build_demo_refinery(furnace_outlet_temperature_K=furnace_outlet_temperature_K, reflux_ratio=reflux_ratio)
    run_demo_refinery(build)
    return build.cdu.last_result["product_yields_mass_fraction"]


def test_cdu_product_yields_sum_to_approximately_one():
    y = _yields()
    assert sum(y.values()) == pytest.approx(1.0, abs=1e-6)


def test_cdu_material_balance_closes():
    build = build_demo_refinery()
    run_demo_refinery(build)
    mb = build.cdu.material_balance()
    assert mb.is_closed()


def test_higher_furnace_temperature_recovers_more_distillate():
    y_cool = _yields(furnace_outlet_temperature_K=600.0)
    y_hot = _yields(furnace_outlet_temperature_K=680.0)
    distillate_cool = y_cool["naphtha"] + y_cool["kerosene"] + y_cool["diesel"] + y_cool["atm_gas_oil"]
    distillate_hot = y_hot["naphtha"] + y_hot["kerosene"] + y_hot["diesel"] + y_hot["atm_gas_oil"]
    assert distillate_hot > distillate_cool
    assert y_hot["residue"] < y_cool["residue"]


def test_all_yields_are_nonnegative():
    y = _yields()
    assert all(v >= -1e-9 for v in y.values())


def test_cdu_furnace_duty_increases_with_crude_rate():
    low_rate = build_demo_refinery(crude_rate_bbl_day=50_000.0)
    high_rate = build_demo_refinery(crude_rate_bbl_day=150_000.0)
    run_demo_refinery(low_rate)
    run_demo_refinery(high_rate)
    low_duty = low_rate.cdu.last_result["furnace"]["required_fired_duty_w"]
    high_duty = high_rate.cdu.last_result["furnace"]["required_fired_duty_w"]
    assert high_duty > low_duty


def test_reflux_ratio_sharpens_separation_between_adjacent_cuts():
    """Higher reflux -> less cross-contamination between adjacent light cuts.
    We check this indirectly: naphtha yield should change monotonically less
    between two high-reflux runs than between two low-reflux runs when the
    furnace temperature is perturbed slightly (sharper cuts -> more sensitive
    to the exact cutpoint, duller cuts -> smoothed out by overlap)."""
    from refinerycore.units.distillation import OVERLAP_CONSTANT

    overlap_low_reflux = OVERLAP_CONSTANT / (1.0 + 1.0)
    overlap_high_reflux = OVERLAP_CONSTANT / (1.0 + 6.0)
    assert overlap_high_reflux < overlap_low_reflux
