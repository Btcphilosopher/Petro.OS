"""Pump model tests (spec section 14)."""

from __future__ import annotations

import math

from refinerycore.equipment.pump import GRAVITY_M_S2, Pump, PumpCurve
from refinerycore.fluids.fluid import Fluid
from refinerycore.fluids.properties import SimpleHydrocarbonPropertyProvider
from refinerycore.streams import Stream


def _make_inlet_stream(mass_flow_kg_s: float = 50.0) -> Stream:
    provider = SimpleHydrocarbonPropertyProvider()
    fluid = Fluid.pure("diesel")
    return Stream(
        id="S-IN", name="inlet", fluid=fluid, mass_flow_kg_s=mass_flow_kg_s,
        pressure_Pa=2.0e5, temperature_K=310.0, provider=provider,
    )


def test_pump_hydraulic_power_equation():
    pump = Pump(id="P-1", name="Test pump", curve=PumpCurve(100.0, 0.1, 80.0, 0.1, 0.75, 0.2))
    inlet = _make_inlet_stream()
    pump.connect_input("inlet", inlet)
    result = pump.run()

    density = inlet.calculate_density()
    q = inlet.calculate_volume_flow_m3_s()
    expected_hydraulic_power = density * GRAVITY_M_S2 * q * result["head_m"]
    assert math.isclose(result["hydraulic_power_w"], expected_hydraulic_power, rel_tol=1e-9)
    assert math.isclose(result["shaft_power_w"], expected_hydraulic_power / result["efficiency"], rel_tol=1e-9)


def test_pump_outlet_pressure_exceeds_inlet():
    pump = Pump(id="P-2", name="Test pump", curve=PumpCurve(100.0, 0.1, 80.0, 0.1, 0.75, 0.2))
    inlet = _make_inlet_stream()
    pump.connect_input("inlet", inlet)
    result = pump.run()
    assert result["outlet_pressure_pa"] > inlet.pressure_Pa
    assert pump.outputs["outlet"].pressure_Pa == result["outlet_pressure_pa"]


def test_pump_efficiency_between_zero_and_one():
    pump = Pump(id="P-3", name="Test pump", curve=PumpCurve(100.0, 0.1, 80.0, 0.1, 0.75, 0.2))
    inlet = _make_inlet_stream()
    pump.connect_input("inlet", inlet)
    result = pump.run()
    assert 0.0 < result["efficiency"] <= 1.0


def test_pump_head_falls_with_flow_beyond_bep():
    curve = PumpCurve(100.0, 0.1, 80.0, 0.1, 0.75, 0.2)
    head_at_bep = curve.head_m(0.1)
    head_beyond_bep = curve.head_m(0.15)
    assert head_beyond_bep < head_at_bep


def test_pump_health_degrades_effective_efficiency():
    pump = Pump(id="P-4", name="Test pump", curve=PumpCurve(100.0, 0.1, 80.0, 0.1, 0.75, 0.2))
    inlet = _make_inlet_stream()
    pump.connect_input("inlet", inlet)
    healthy_result = pump.run()

    pump.health.health_score = 0.5
    degraded_result = pump.run()
    assert degraded_result["efficiency"] < healthy_result["efficiency"]
    assert degraded_result["shaft_power_w"] > healthy_result["shaft_power_w"]
