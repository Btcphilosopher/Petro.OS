"""Fluid / component / crude-assay tests."""

from __future__ import annotations

import math

import pytest

from refinerycore.core.errors import NonPhysicalStateError
from refinerycore.fluids.crude_assay import (
    CrudeAssay,
    CrudeBlend,
    TBPPoint,
    api_gravity_to_density_kg_m3,
    density_kg_m3_to_api_gravity,
)
from refinerycore.fluids.fluid import Fluid
from refinerycore.fluids.properties import IdealGasPropertyProvider, SimpleHydrocarbonPropertyProvider


def test_fluid_requires_fractions_summing_to_one():
    with pytest.raises(NonPhysicalStateError):
        Fluid(name="bad", composition={"diesel": 0.5, "kerosene": 0.3})


def test_fluid_rejects_negative_fraction():
    with pytest.raises(NonPhysicalStateError):
        Fluid(name="bad", composition={"diesel": 1.2, "kerosene": -0.2})


def test_fluid_blending_preserves_mass_fraction_sum():
    a = Fluid.pure("diesel")
    b = Fluid.pure("kerosene")
    blend = a.blended_with(b, self_mass_fraction=0.4)
    assert math.isclose(sum(blend.composition.values()), 1.0, abs_tol=1e-9)
    assert math.isclose(blend.composition["diesel"], 0.4, abs_tol=1e-9)
    assert math.isclose(blend.composition["kerosene"], 0.6, abs_tol=1e-9)


def test_api_gravity_density_round_trip():
    density = api_gravity_to_density_kg_m3(35.0)
    assert density > 0
    assert math.isclose(density_kg_m3_to_api_gravity(density), 35.0, rel_tol=1e-6)


def _demo_assay() -> CrudeAssay:
    return CrudeAssay(
        name="Test Crude",
        api_gravity=35.0,
        sulfur_wt_pct=1.0,
        tbp_curve=[TBPPoint(0.0, 300.0), TBPPoint(0.5, 500.0), TBPPoint(1.0, 900.0)],
    )


def test_crude_assay_pseudocomponent_yields_sum_to_one():
    assay = _demo_assay()
    yields = assay.pseudocomponent_yields()
    assert math.isclose(sum(yields.values()), 1.0, abs_tol=1e-6)
    assert all(v >= 0 for v in yields.values())


def test_crude_assay_tbp_interpolation_monotonic():
    assay = _demo_assay()
    t_low = assay.temperature_at_fraction(0.1)
    t_high = assay.temperature_at_fraction(0.9)
    assert t_high > t_low


def test_crude_blend_requires_fractions_sum_to_one():
    a, b = _demo_assay(), _demo_assay()
    with pytest.raises(NonPhysicalStateError):
        CrudeBlend(name="bad blend", components={"a": 0.6, "b": 0.6}, assays={"a": a, "b": b})


def test_crude_blend_to_fluid_is_valid_fluid():
    a, b = _demo_assay(), _demo_assay()
    blend = CrudeBlend(name="blend", components={"a": 0.7, "b": 0.3}, assays={"a": a, "b": b})
    fluid = blend.to_fluid()
    assert math.isclose(sum(fluid.composition.values()), 1.0, abs_tol=1e-6)


def test_simple_hydrocarbon_provider_density_positive():
    provider = SimpleHydrocarbonPropertyProvider()
    fluid = Fluid.pure("diesel")
    props = provider.properties_at(fluid, 2.0e5, 320.0)
    assert props.density_kg_m3 > 0
    assert props.molecular_weight > 0


def test_simple_hydrocarbon_provider_rejects_nonpositive_pt():
    provider = SimpleHydrocarbonPropertyProvider()
    fluid = Fluid.pure("diesel")
    with pytest.raises(NonPhysicalStateError):
        provider.properties_at(fluid, -1.0, 300.0)
    with pytest.raises(NonPhysicalStateError):
        provider.properties_at(fluid, 1.0e5, -10.0)


def test_ideal_gas_provider_density_scales_with_pressure():
    provider = IdealGasPropertyProvider()
    fluid = Fluid.pure("light_ends")
    low = provider.properties_at(fluid, 1.0e5, 400.0).density_kg_m3
    high = provider.properties_at(fluid, 2.0e5, 400.0).density_kg_m3
    assert math.isclose(high / low, 2.0, rel_tol=1e-6)
