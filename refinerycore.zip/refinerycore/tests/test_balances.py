"""Material/energy balance engine tests (spec section 8-9, 65-66)."""

from __future__ import annotations

import pytest

from refinerycore.core.errors import MaterialBalanceError
from refinerycore.thermodynamics.balances import EnergyBalance, MaterialBalance


def test_material_balance_closes_when_in_equals_out():
    mb = MaterialBalance(unit_id="TEST-1")
    mb.add_inflow("feed", 100.0, {"diesel": 1.0})
    mb.add_outflow("product", 100.0, {"diesel": 1.0})
    assert mb.is_closed()
    mb.validate()  # must not raise


def test_material_balance_detects_mass_creation():
    mb = MaterialBalance(unit_id="TEST-2")
    mb.add_inflow("feed", 100.0, {"diesel": 1.0})
    mb.add_outflow("product", 150.0, {"diesel": 1.0})
    assert not mb.is_closed()
    with pytest.raises(MaterialBalanceError):
        mb.validate()


def test_material_balance_rejects_negative_flow():
    mb = MaterialBalance(unit_id="TEST-3")
    with pytest.raises(MaterialBalanceError):
        mb.add_inflow("feed", -10.0, {"diesel": 1.0})


def test_material_balance_component_residuals():
    mb = MaterialBalance(unit_id="TEST-4")
    mb.add_inflow("feed", 100.0, {"diesel": 0.5, "kerosene": 0.5})
    mb.add_outflow("product", 100.0, {"diesel": 0.4, "kerosene": 0.6})
    residuals = mb.component_residuals_kg_s()
    assert residuals["diesel"] == pytest.approx(10.0)
    assert residuals["kerosene"] == pytest.approx(-10.0)


def test_material_balance_rejects_composition_not_summing_to_one():
    mb = MaterialBalance(unit_id="TEST-5")
    mb.add_inflow("feed", 100.0, {"diesel": 0.5, "kerosene": 0.3})
    mb.add_outflow("product", 100.0, {"diesel": 0.8})
    with pytest.raises(MaterialBalanceError):
        mb.validate()


def test_energy_balance_closes():
    eb = EnergyBalance(unit_id="TEST-6")
    eb.enthalpy_in_w = 1000.0
    eb.heat_in_w = 500.0
    eb.enthalpy_out_w = 1500.0
    assert eb.is_closed()


def test_energy_balance_exposes_nonzero_residual_without_forcing_closure():
    eb = EnergyBalance(unit_id="TEST-7")
    eb.enthalpy_in_w = 1000.0
    eb.enthalpy_out_w = 1200.0
    assert not eb.is_closed()
    assert eb.residual_w == pytest.approx(-200.0)
