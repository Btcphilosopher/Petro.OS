"""Pipe model tests (spec section 16)."""

from __future__ import annotations

import math

import pytest

from refinerycore.equipment.pipe import Pipe, darcy_friction_factor, reynolds_number
from refinerycore.fluids.fluid import Fluid
from refinerycore.fluids.properties import SimpleHydrocarbonPropertyProvider
from refinerycore.streams import Stream


def test_reynolds_number_scales_linearly_with_velocity():
    re_1 = reynolds_number(density_kg_m3=800.0, velocity_m_s=1.0, diameter_m=0.2, viscosity_pa_s=0.003)
    re_2 = reynolds_number(density_kg_m3=800.0, velocity_m_s=2.0, diameter_m=0.2, viscosity_pa_s=0.003)
    assert math.isclose(re_2 / re_1, 2.0, rel_tol=1e-9)


def test_laminar_friction_factor_is_64_over_re():
    f = darcy_friction_factor(reynolds=1000.0, relative_roughness=1e-4)
    assert math.isclose(f, 64.0 / 1000.0, rel_tol=1e-9)


def test_turbulent_friction_factor_positive_and_decreasing_with_re():
    f_low = darcy_friction_factor(reynolds=5000.0, relative_roughness=1e-4)
    f_high = darcy_friction_factor(reynolds=50000.0, relative_roughness=1e-4)
    assert f_low > 0 and f_high > 0
    assert f_high < f_low


def test_pipe_pressure_drop_positive_for_forward_flow():
    provider = SimpleHydrocarbonPropertyProvider()
    fluid = Fluid.pure("diesel")
    inlet = Stream(
        id="S-1", name="in", fluid=fluid, mass_flow_kg_s=40.0, pressure_Pa=3.0e5, temperature_K=310.0, provider=provider,
    )
    pipe = Pipe(id="PIPE-1", name="test pipe", length_m=500.0, diameter_m=0.25)
    pipe.connect_input("inlet", inlet)
    result = pipe.run()

    assert result["total_dp_pa"] > 0
    assert result["outlet_pressure_pa"] < inlet.pressure_Pa
    assert result["reynolds_number"] > 0


def test_pipe_pressure_drop_scales_with_length():
    provider = SimpleHydrocarbonPropertyProvider()
    fluid = Fluid.pure("diesel")
    inlet = Stream(
        id="S-2", name="in", fluid=fluid, mass_flow_kg_s=40.0, pressure_Pa=3.0e5, temperature_K=310.0, provider=provider,
    )
    short_pipe = Pipe(id="PIPE-SHORT", name="short", length_m=100.0, diameter_m=0.25)
    long_pipe = Pipe(id="PIPE-LONG", name="long", length_m=1000.0, diameter_m=0.25)
    short_pipe.connect_input("inlet", inlet)
    long_pipe.connect_input("inlet", inlet)

    short_result = short_pipe.run()
    long_result = long_pipe.run()
    assert long_result["friction_dp_pa"] > short_result["friction_dp_pa"]


def test_reynolds_number_rejects_zero_viscosity():
    with pytest.raises(Exception):
        reynolds_number(density_kg_m3=800.0, velocity_m_s=1.0, diameter_m=0.2, viscosity_pa_s=0.0)
