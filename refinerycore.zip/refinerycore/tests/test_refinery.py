"""End-to-end refinery integration tests (spec sections 88-89)."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

from refinerycore.core.enums import ConvergenceStatus, SteamLevel
from refinerycore.demo import build_demo_refinery, run_demo_refinery
from refinerycore.faults.faults import heat_exchanger_fouling, pump_efficiency_degradation
from refinerycore.optimisation.monte_carlo import MonteCarloEngine, UncertainVariable
from refinerycore.optimisation.optimizer import Constraint, DecisionVariable, RefineryOptimizer
from refinerycore.optimisation.scenarios import Scenario, ScenarioRunner
from refinerycore.reporting.kpis import RefineryKPIs


def test_end_to_end_demo_refinery_converges_and_balances():
    build = build_demo_refinery()
    result = run_demo_refinery(build)

    assert result["final"].status is ConvergenceStatus.CONVERGED
    mb = build.cdu.material_balance()
    assert mb.is_closed()

    kpis = RefineryKPIs(
        crude_flow_kg_s=build.crude_feed_stream.mass_flow_kg_s,
        crude_volumetric_flow_m3_s=build.crude_feed_stream.calculate_volume_flow_m3_s(),
        total_product_flow_kg_s=sum(s.mass_flow_kg_s for s in build.cdu.product_streams.values()),
        total_energy_w=build.cdu.last_result["furnace"]["required_fired_duty_w"],
        steam_flow_kg_s=build.refinery.steam_network.balance_kg_s(SteamLevel.MP),
        electricity_w=build.refinery.electrical_network.total_demand_w,
        hydrogen_flow_kg_s=build.refinery.hydrogen_network.total_consumption_kg_s,
        co2_flow_kg_s=build.cdu.last_result["furnace"]["co2_flow_kg_s"],
    )
    # The declared 100,000 bbl/day rate is converted to mass flow using the
    # pseudocomponent blend's reference-condition (15 degC) density; the
    # stream's actual volumetric flow is recomputed downstream at the
    # feed's real temperature (300 K), so a small thermal-expansion
    # difference (a couple of percent) versus the nominal rate is expected
    # and physically correct -- see the comment in refinerycore.demo.
    assert kpis.crude_throughput_bbl_day == pytest.approx(100_000.0, rel=0.03)
    assert kpis.specific_energy_gj_per_t > 0


def test_refinery_process_graph_is_connected():
    build = build_demo_refinery()
    run_demo_refinery(build)
    assert build.refinery.validate() == []


def test_refinery_export_state_round_trips_json():
    build = build_demo_refinery()
    run_demo_refinery(build)
    state = build.refinery.export_state()
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "state.json"
        state.save_state(path)
        reloaded = type(state).load_state(path)
    assert reloaded.refinery_name == state.refinery_name
    assert json.dumps(reloaded.to_dict(), default=str)  # serialisable


def test_fault_scenario_pump_degradation_reduces_efficiency():
    build = build_demo_refinery()
    run_demo_refinery(build)
    baseline_efficiency = build.feed_pump.last_result["efficiency"]

    fault = pump_efficiency_degradation(build.feed_pump, health_score=0.6)
    fault.apply(build.feed_pump)
    build.feed_pump.run()

    assert build.feed_pump.last_result["efficiency"] < baseline_efficiency


def test_fault_scenario_fouling_increases_furnace_duty_requirement():
    from refinerycore.equipment.heat_exchanger import FoulingModel, HeatExchanger

    build = build_demo_refinery()
    run_demo_refinery(build)

    # ua_clean_w_k is sized to the atm-gas-oil side's own heat capacity
    # rate so this exchanger sits at a moderate NTU rather than a
    # saturated one (see examples/fault_scenario.py for the same choice).
    hx = HeatExchanger(id="HX-101", name="preheat", ua_clean_w_k=3.0e4, fouling=FoulingModel())
    hx.inputs["hot_in"] = build.cdu.product_streams["atm_gas_oil"]
    hx.inputs["cold_in"] = build.crude_feed_stream
    before = hx.run()

    fault = heat_exchanger_fouling(hx, additional_hours=4000.0)
    fault.apply(hx)
    after = hx.run()

    assert after["duty_w"] < before["duty_w"]


def test_optimisation_improves_or_matches_baseline_objective():
    def objective(x):
        furnace_t = float(x[0])
        build = build_demo_refinery(furnace_outlet_temperature_K=furnace_t)
        run_demo_refinery(build)
        y = build.cdu.last_result["product_yields_mass_fraction"]
        return y["naphtha"] + y["kerosene"] + y["diesel"]

    optimizer = RefineryOptimizer(
        decision_variables=[DecisionVariable("furnace_outlet_temperature_K", 630.0, 600.0, 680.0)],
        objective_fn=objective,
        constraints=[],
        maximize=True,
    )
    result = optimizer.optimise()
    assert result.objective_value >= result.baseline_objective_value - 1e-6


def test_scenario_runner_compares_scenarios():
    def model(inputs):
        build = build_demo_refinery(furnace_outlet_temperature_K=inputs["furnace_outlet_temperature_K"])
        run_demo_refinery(build)
        return {"distillate_fraction": sum(
            v for k, v in build.cdu.last_result["product_yields_mass_fraction"].items() if k != "residue"
        )}

    runner = ScenarioRunner(base_inputs={"furnace_outlet_temperature_K": 650.0}, model_fn=model)
    runner.run_all([
        Scenario("baseline", "normal operation"),
        Scenario("high_severity", "hotter furnace", overrides={"furnace_outlet_temperature_K": 680.0}),
    ])
    table = runner.comparison_table()
    assert len(table) == 2
    assert set(table["scenario"]) == {"baseline", "high_severity"}


def test_monte_carlo_reproducible_with_fixed_seed():
    def model(draw):
        return draw["x"] ** 2

    engine_a = MonteCarloEngine([UncertainVariable("x", "model", mean=1.0, std=0.1)], model, seed=7)
    engine_b = MonteCarloEngine([UncertainVariable("x", "model", mean=1.0, std=0.1)], model, seed=7)
    result_a = engine_a.run(200)
    result_b = engine_b.run(200)
    assert result_a.output_stats == result_b.output_stats
