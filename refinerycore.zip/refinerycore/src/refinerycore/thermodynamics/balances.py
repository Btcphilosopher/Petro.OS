"""Material and energy balance engines (spec sections 8-9).

Both balances expose explicit absolute/relative residuals and never
silently force closure. Steady state is defined as ``mass_in == mass_out``
(no accumulation); the transient solver (see :mod:`refinerycore.solver`)
is responsible for the accumulation term when it matters.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from refinerycore.core.errors import MaterialBalanceError

_ABS_TOL_KG_S = 1.0e-6
_REL_TOL = 1.0e-4


@dataclass
class MaterialBalance:
    """Total and per-component mass balance around a control volume.

    ``inflows``/``outflows`` map a stream id to (mass_flow_kg_s,
    {component: mass_fraction}). Residuals are computed on demand so the
    balance can be inspected before deciding whether to raise.
    """

    unit_id: str
    inflows: dict[str, tuple[float, dict[str, float]]] = field(default_factory=dict)
    outflows: dict[str, tuple[float, dict[str, float]]] = field(default_factory=dict)
    accumulation_kg_s: float = 0.0  # 0 for steady state; nonzero for transient control volumes

    def add_inflow(self, stream_id: str, mass_flow_kg_s: float, composition: dict[str, float]) -> None:
        if mass_flow_kg_s < 0:
            raise MaterialBalanceError(f"negative inflow on {self.unit_id}: {stream_id} = {mass_flow_kg_s} kg/s")
        self.inflows[stream_id] = (mass_flow_kg_s, composition)

    def add_outflow(self, stream_id: str, mass_flow_kg_s: float, composition: dict[str, float]) -> None:
        if mass_flow_kg_s < 0:
            raise MaterialBalanceError(f"negative outflow on {self.unit_id}: {stream_id} = {mass_flow_kg_s} kg/s")
        self.outflows[stream_id] = (mass_flow_kg_s, composition)

    @property
    def total_mass_in_kg_s(self) -> float:
        return sum(flow for flow, _ in self.inflows.values())

    @property
    def total_mass_out_kg_s(self) -> float:
        return sum(flow for flow, _ in self.outflows.values())

    @property
    def absolute_residual_kg_s(self) -> float:
        return self.total_mass_in_kg_s - self.total_mass_out_kg_s - self.accumulation_kg_s

    @property
    def relative_residual(self) -> float:
        denom = max(self.total_mass_in_kg_s, 1.0e-9)
        return self.absolute_residual_kg_s / denom

    def component_residuals_kg_s(self) -> dict[str, float]:
        components = set()
        for _, comp in list(self.inflows.values()) + list(self.outflows.values()):
            components.update(comp.keys())
        residuals: dict[str, float] = {}
        for c in components:
            mass_in = sum(flow * comp.get(c, 0.0) for flow, comp in self.inflows.values())
            mass_out = sum(flow * comp.get(c, 0.0) for flow, comp in self.outflows.values())
            residuals[c] = mass_in - mass_out
        return residuals

    def is_closed(self, abs_tol_kg_s: float = _ABS_TOL_KG_S, rel_tol: float = _REL_TOL) -> bool:
        return abs(self.absolute_residual_kg_s) <= abs_tol_kg_s or abs(self.relative_residual) <= rel_tol

    def validate(self, abs_tol_kg_s: float = _ABS_TOL_KG_S, rel_tol: float = _REL_TOL) -> None:
        """Raise :class:`MaterialBalanceError` if the balance does not close,
        or if any composition is structurally invalid."""
        for stream_id, (_, comp) in {**self.inflows, **self.outflows}.items():
            total = sum(comp.values())
            if comp and abs(total - 1.0) > 1.0e-3:
                raise MaterialBalanceError(
                    f"{self.unit_id}: stream {stream_id!r} composition sums to {total:.6f}, expected 1.0"
                )
        if not self.is_closed(abs_tol_kg_s, rel_tol):
            raise MaterialBalanceError(
                f"{self.unit_id}: material balance does not close "
                f"(in={self.total_mass_in_kg_s:.6g} kg/s, out={self.total_mass_out_kg_s:.6g} kg/s, "
                f"absolute residual={self.absolute_residual_kg_s:.6g} kg/s, "
                f"relative residual={self.relative_residual:.3e})"
            )


@dataclass
class EnergyBalance:
    """Steady-state control-volume energy balance.

    ``sum(H_in) + Q + W == sum(H_out) + losses + accumulation``

    where ``H`` terms are enthalpy *flows* (W), ``Q`` is net heat added
    (W, positive = heat into the control volume), ``W`` is net shaft/
    electrical work added (W), and ``losses`` are explicit heat losses
    (W, positive = leaving the control volume). Kinetic and potential
    energy terms are neglected (Level 1 approximation).
    """

    unit_id: str
    enthalpy_in_w: float = 0.0
    enthalpy_out_w: float = 0.0
    heat_in_w: float = 0.0
    work_in_w: float = 0.0
    losses_w: float = 0.0
    accumulation_w: float = 0.0

    @property
    def residual_w(self) -> float:
        return (self.enthalpy_in_w + self.heat_in_w + self.work_in_w) - (
            self.enthalpy_out_w + self.losses_w + self.accumulation_w
        )

    @property
    def relative_residual(self) -> float:
        denom = max(abs(self.enthalpy_in_w) + abs(self.heat_in_w) + abs(self.work_in_w), 1.0e-6)
        return self.residual_w / denom

    def is_closed(self, abs_tol_w: float = 1.0, rel_tol: float = 1.0e-4) -> bool:
        return abs(self.residual_w) <= abs_tol_w or abs(self.relative_residual) <= rel_tol

    def validate(self, abs_tol_w: float = 1.0, rel_tol: float = 1.0e-4) -> None:
        from refinerycore.core.errors import EnergyBalanceError

        if not self.is_closed(abs_tol_w, rel_tol):
            raise EnergyBalanceError(
                f"{self.unit_id}: energy balance does not close "
                f"(residual={self.residual_w:.6g} W, relative={self.relative_residual:.3e})"
            )
