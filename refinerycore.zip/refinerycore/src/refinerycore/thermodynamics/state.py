"""``ThermodynamicState`` (spec section 10).

A coherent state object with named constructors for the common fixed
pairs (PT, PH, PS, TH, TS), built on top of a
:class:`~refinerycore.fluids.properties.PropertyProvider`. Inverse
constructors (PH, PS, TH, TS) solve a 1-D root-finding problem with
``scipy.optimize.brentq`` -- they never guess.
"""

from __future__ import annotations

from dataclasses import dataclass

from scipy.optimize import brentq

from refinerycore.core.enums import Phase
from refinerycore.core.errors import NonPhysicalStateError
from refinerycore.fluids.fluid import Fluid
from refinerycore.fluids.properties import PropertyProvider

_T_MIN_K = 150.0
_T_MAX_K = 1200.0


@dataclass(frozen=True)
class ThermodynamicState:
    """Static thermodynamic state of a fluid at a point (spec section 10).

    All quantities are total (stagnation) properties unless noted
    otherwise at the call site -- REFINERYCORE.OS does not currently
    separate static/total states (kinetic energy terms are neglected,
    consistent with the Level 1 fidelity of the energy balance module).
    """

    fluid: Fluid
    pressure_Pa: float
    temperature_K: float
    specific_enthalpy_j_kg: float
    specific_entropy_j_kg_k: float
    density_kg_m3: float
    phase: Phase
    vapour_fraction: float
    specific_heat_j_kg_k: float
    viscosity_pa_s: float
    molecular_weight: float

    # -- named constructors -------------------------------------------------
    @classmethod
    def from_PT(cls, fluid: Fluid, pressure_Pa: float, temperature_K: float, provider: PropertyProvider) -> "ThermodynamicState":
        props = provider.properties_at(fluid, pressure_Pa, temperature_K)
        return cls(
            fluid=fluid,
            pressure_Pa=pressure_Pa,
            temperature_K=temperature_K,
            specific_enthalpy_j_kg=props.specific_enthalpy_j_kg,
            specific_entropy_j_kg_k=props.specific_entropy_j_kg_k,
            density_kg_m3=props.density_kg_m3,
            phase=props.phase,
            vapour_fraction=props.vapour_fraction,
            specific_heat_j_kg_k=props.specific_heat_j_kg_k,
            viscosity_pa_s=props.viscosity_pa_s,
            molecular_weight=props.molecular_weight,
        )

    @classmethod
    def from_PH(cls, fluid: Fluid, pressure_Pa: float, specific_enthalpy_j_kg: float, provider: PropertyProvider) -> "ThermodynamicState":
        def residual(t: float) -> float:
            return provider.properties_at(fluid, pressure_Pa, t).specific_enthalpy_j_kg - specific_enthalpy_j_kg

        t_solution = _solve_temperature(residual)
        return cls.from_PT(fluid, pressure_Pa, t_solution, provider)

    @classmethod
    def from_PS(cls, fluid: Fluid, pressure_Pa: float, specific_entropy_j_kg_k: float, provider: PropertyProvider) -> "ThermodynamicState":
        def residual(t: float) -> float:
            return provider.properties_at(fluid, pressure_Pa, t).specific_entropy_j_kg_k - specific_entropy_j_kg_k

        t_solution = _solve_temperature(residual)
        return cls.from_PT(fluid, pressure_Pa, t_solution, provider)

    @classmethod
    def from_TH(cls, fluid: Fluid, temperature_K: float, specific_enthalpy_j_kg: float, provider: PropertyProvider, p_guess_Pa: float = 1.0e5) -> "ThermodynamicState":
        # Pressure has a weak effect on enthalpy in the liquid-dominated
        # SimpleHydrocarbonPropertyProvider model; we solve holding T fixed
        # and searching for a consistent pressure only when the provider's
        # enthalpy is pressure-dependent (it currently is not), so this is
        # provided for interface completeness and returns the T,P=p_guess state
        # if the residual is already ~0, else raises.
        props = provider.properties_at(fluid, p_guess_Pa, temperature_K)
        if abs(props.specific_enthalpy_j_kg - specific_enthalpy_j_kg) > 1.0e3:
            raise NonPhysicalStateError(
                "from_TH: current property providers are pressure-independent for enthalpy; "
                "the requested (T, H) pair is inconsistent with any pressure"
            )
        return cls.from_PT(fluid, p_guess_Pa, temperature_K, provider)

    @classmethod
    def from_TS(cls, fluid: Fluid, temperature_K: float, specific_entropy_j_kg_k: float, provider: PropertyProvider, p_guess_Pa: float = 1.0e5) -> "ThermodynamicState":
        props = provider.properties_at(fluid, p_guess_Pa, temperature_K)
        if abs(props.specific_entropy_j_kg_k - specific_entropy_j_kg_k) > 1.0:
            raise NonPhysicalStateError(
                "from_TS: current property providers are pressure-independent for entropy; "
                "the requested (T, S) pair is inconsistent with any pressure"
            )
        return cls.from_PT(fluid, p_guess_Pa, temperature_K, provider)


def _solve_temperature(residual):
    lo, hi = _T_MIN_K, _T_MAX_K
    r_lo, r_hi = residual(lo), residual(hi)
    if r_lo * r_hi > 0:
        raise NonPhysicalStateError(
            f"could not bracket a solution for temperature in [{lo}, {hi}] K "
            f"(residuals {r_lo:.3g}, {r_hi:.3g} have the same sign)"
        )
    return brentq(residual, lo, hi, xtol=1.0e-6, rtol=1.0e-10, maxiter=200)
