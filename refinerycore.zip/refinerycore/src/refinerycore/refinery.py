"""``Refinery`` -- the top-level digital twin (spec section 50).

::

    PHYSICAL REFINERY
            v
    EQUIPMENT MODEL
            v
    PROCESS STREAM MODEL
            v
    THERMODYNAMIC STATE
            v
    PHYSICS / MASS / ENERGY BALANCES
            v
    SOLVER
            v
    DIGITAL TWIN STATE
            v
    OPTIMISATION / ANALYTICS / VISUALISATION / API

The ``Refinery`` object owns process units, the utility networks and the
process graph, and drives the whole chain: :meth:`solve_steady_state`
runs every registered unit (in topological order when the graph has
edges), :meth:`calculate_kpis` reduces the resulting streams to KPIs,
and :meth:`export_state` serialises a :class:`~refinerycore.twin.state.RefineryTwinState`
snapshot. The UI/API layer only ever reads what this object produces.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from refinerycore.controls.alarms import AlarmEngine
from refinerycore.core.enums import ConvergenceStatus
from refinerycore.core.events import EventBus, EventKind
from refinerycore.core.ids import new_id, utc_now_iso
from refinerycore.fluids.properties import PropertyProvider
from refinerycore.networks.cooling import CoolingWaterNetwork
from refinerycore.networks.electrical import ElectricalNetwork
from refinerycore.networks.hydrogen import HydrogenNetwork
from refinerycore.networks.process_graph import ProcessGraph
from refinerycore.networks.steam import SteamNetwork
from refinerycore.reporting.kpis import RefineryKPIs
from refinerycore.solver.steady_state import SequentialModularSolver, SolveResult
from refinerycore.streams import Stream
from refinerycore.twin.state import RefineryTwinState
from refinerycore.units.base import ProcessUnit


@dataclass
class Refinery:
    name: str
    provider: PropertyProvider
    units: dict[str, ProcessUnit] = field(default_factory=dict)
    graph: ProcessGraph = field(default_factory=ProcessGraph)
    hydrogen_network: HydrogenNetwork = field(default_factory=HydrogenNetwork)
    steam_network: SteamNetwork = field(default_factory=SteamNetwork)
    electrical_network: ElectricalNetwork = field(default_factory=ElectricalNetwork)
    cooling_network: CoolingWaterNetwork = field(default_factory=CoolingWaterNetwork)
    alarm_engine: AlarmEngine = field(default_factory=AlarmEngine)
    event_bus: EventBus = field(default_factory=EventBus)
    _last_solve: SolveResult | None = field(default=None, repr=False)

    def add_unit(self, unit: ProcessUnit) -> None:
        self.units[unit.id] = unit
        self.graph.add_equipment(unit.id, type=type(unit).__name__)

    def connect(self, source_unit_id: str, destination_unit_id: str, stream: Stream) -> None:
        stream.source, stream.destination = source_unit_id, destination_unit_id
        self.graph.add_stream(stream)

    def solve_steady_state(self) -> SolveResult:
        """Run every registered unit's ``.run()`` in topological order
        (spec section 34). Publishes SolverConverged/SolverFailed events."""
        self.event_bus.publish(EventKind.SIMULATION_STARTED, source=self.name)

        solver = SequentialModularSolver(graph=self.graph)
        for unit_id, unit in self.units.items():
            solver.register(unit_id, unit.run)
        result = solver.solve()
        self._last_solve = result

        for unit_id, unit in self.units.items():
            self.event_bus.publish(EventKind.EQUIPMENT_STATE_CHANGED, source=unit_id, status=unit.status.value)

        if result.converged:
            self.event_bus.publish(EventKind.SOLVER_CONVERGED, source=self.name, iterations=result.iterations)
        else:
            self.event_bus.publish(EventKind.SOLVER_FAILED, source=self.name, failed=result.failed_equations)

        self.event_bus.publish(EventKind.SIMULATION_COMPLETED, source=self.name)
        return result

    def calculate_kpis(self, crude_stream: Stream, product_streams: dict[str, Stream], total_energy_w: float) -> RefineryKPIs:
        return RefineryKPIs(
            crude_flow_kg_s=crude_stream.mass_flow_kg_s,
            crude_volumetric_flow_m3_s=crude_stream.calculate_volume_flow_m3_s(),
            total_product_flow_kg_s=sum(s.mass_flow_kg_s for s in product_streams.values()),
            total_energy_w=total_energy_w,
            steam_flow_kg_s=sum(self.steam_network.balance_kg_s(level) for level in self.steam_network.production_kg_s),
            electricity_w=self.electrical_network.total_demand_w,
            hydrogen_flow_kg_s=self.hydrogen_network.total_consumption_kg_s,
            co2_flow_kg_s=0.0,
        )

    def validate(self) -> list[str]:
        """Structural validation (spec section 8): disconnected islands,
        missing streams. Returns a list of human-readable problems (empty
        list = valid). Never raises -- callers decide how to react."""
        problems: list[str] = []
        islands = self.graph.islands()
        if len(islands) > 1:
            problems.append(f"process graph has {len(islands)} disconnected islands: {islands}")
        return problems

    def export_state(self, extra_kpis: dict[str, float] | None = None) -> RefineryTwinState:
        state = RefineryTwinState(
            refinery_name=self.name,
            simulation_id=new_id("sim"),
            timestamp=utc_now_iso(),
            equipment_states={uid: u.to_dict() for uid, u in self.units.items()},
            utility_states={
                "hydrogen": self.hydrogen_network.to_dict(),
                "steam": self.steam_network.to_dict(),
                "electrical": self.electrical_network.to_dict(),
                "cooling": self.cooling_network.to_dict(),
            },
            alarms=[a.to_dict() for a in self.alarm_engine.alarms],
            kpis=extra_kpis or {},
            solver_status={
                "status": self._last_solve.status.value if self._last_solve else ConvergenceStatus.NOT_RUN.value,
                "iterations": self._last_solve.iterations if self._last_solve else 0,
                "residual_norm": self._last_solve.residual_norm if self._last_solve else float("nan"),
                "failed_equations": self._last_solve.failed_equations if self._last_solve else [],
            },
        )
        return state

    def to_machine_readable_state(self) -> dict[str, Any]:
        """spec section 76: the whole refinery as structured, machine-readable state."""
        return self.export_state().to_dict()
