"""State/report export helpers (spec section 72).

JSON and CSV are always available (stdlib + pandas). HTML export uses a
minimal, dependency-free template. PDF is deliberately out of scope
(spec section 72 calls it optional) -- see docs/limitations.md.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from refinerycore.twin.state import RefineryTwinState

_HTML_TEMPLATE = """<!doctype html>
<html><head><meta charset="utf-8"><title>{title}</title>
<style>
body {{ font-family: system-ui, sans-serif; margin: 2rem; color: #1a1a1a; }}
h1 {{ font-size: 1.4rem; }}
table {{ border-collapse: collapse; margin-bottom: 1.5rem; }}
td, th {{ border: 1px solid #ccc; padding: 0.3rem 0.6rem; text-align: left; }}
.section {{ margin-top: 1.5rem; }}
</style></head><body>
<h1>{title}</h1>
<p><em>REFINERYCORE.OS engineering report -- Level 1/2 fidelity, synthetic demonstration data.
See docs/limitations.md.</em></p>
{body}
</body></html>
"""


def _dict_table(d: dict[str, Any]) -> str:
    rows = "".join(f"<tr><td>{k}</td><td>{v}</td></tr>" for k, v in d.items())
    return f"<table>{rows}</table>"


def export_json(state: RefineryTwinState, path: str | Path) -> None:
    Path(path).write_text(json.dumps(state.to_dict(), indent=2, default=str))


def export_csv_kpis(state: RefineryTwinState, path: str | Path) -> None:
    state.kpis_to_csv(path)


def export_html_report(state: RefineryTwinState, path: str | Path) -> None:
    sections = [
        "<div class='section'><h2>KPIs</h2>" + _dict_table(state.kpis) + "</div>",
        "<div class='section'><h2>Equipment</h2>" + "".join(
            f"<h3>{eid}</h3>{_dict_table(edata)}" for eid, edata in state.equipment_states.items()
        ) + "</div>",
        "<div class='section'><h2>Alarms</h2>" + (
            "<p>No active alarms.</p>" if not state.alarms else "".join(_dict_table(a) for a in state.alarms)
        ) + "</div>",
    ]
    html = _HTML_TEMPLATE.format(title=f"{state.refinery_name} -- Engineering Report", body="".join(sections))
    Path(path).write_text(html)
