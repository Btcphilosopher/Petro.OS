"""KPI calculation and state export/reporting."""
