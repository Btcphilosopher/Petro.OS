"""Refinery-wide performance KPIs (spec section 43)."""

from __future__ import annotations

from dataclasses import dataclass

from refinerycore.core.units import kg_per_s_to_t_per_h, m3_per_s_to_bbl_per_day, w_to_mw


@dataclass
class RefineryKPIs:
    crude_flow_kg_s: float
    crude_volumetric_flow_m3_s: float
    total_product_flow_kg_s: float
    total_energy_w: float
    steam_flow_kg_s: float
    electricity_w: float
    hydrogen_flow_kg_s: float
    co2_flow_kg_s: float

    @property
    def crude_throughput_bbl_day(self) -> float:
        return m3_per_s_to_bbl_per_day(self.crude_volumetric_flow_m3_s)

    @property
    def crude_throughput_t_day(self) -> float:
        return kg_per_s_to_t_per_h(self.crude_flow_kg_s) * 24.0

    @property
    def product_yield_fraction(self) -> float:
        return self.total_product_flow_kg_s / self.crude_flow_kg_s if self.crude_flow_kg_s > 0 else 0.0

    @property
    def specific_energy_gj_per_t(self) -> float:
        t_per_s = self.crude_flow_kg_s / 1000.0
        return (self.total_energy_w / 1.0e9) / t_per_s if t_per_s > 0 else 0.0

    @property
    def specific_energy_gj_per_bbl(self) -> float:
        bbl_per_s = m3_per_s_to_bbl_per_day(self.crude_volumetric_flow_m3_s) / 86_400.0
        return (self.total_energy_w / 1.0e9) / bbl_per_s if bbl_per_s > 0 else 0.0

    @property
    def hydrogen_intensity_kg_per_t_feed(self) -> float:
        t_per_s = self.crude_flow_kg_s / 1000.0
        return self.hydrogen_flow_kg_s / t_per_s if t_per_s > 0 else 0.0

    @property
    def co2_intensity_kg_per_t_crude(self) -> float:
        t_per_s = self.crude_flow_kg_s / 1000.0
        return self.co2_flow_kg_s / t_per_s if t_per_s > 0 else 0.0

    @property
    def electricity_mw(self) -> float:
        return w_to_mw(self.electricity_w)

    def to_dict(self) -> dict[str, float]:
        return {
            "crude_throughput_bbl_day": self.crude_throughput_bbl_day,
            "crude_throughput_t_day": self.crude_throughput_t_day,
            "product_yield_fraction": self.product_yield_fraction,
            "specific_energy_gj_per_t": self.specific_energy_gj_per_t,
            "specific_energy_gj_per_bbl": self.specific_energy_gj_per_bbl,
            "hydrogen_intensity_kg_per_t_feed": self.hydrogen_intensity_kg_per_t_feed,
            "co2_intensity_kg_per_t_crude": self.co2_intensity_kg_per_t_crude,
            "electricity_mw": self.electricity_mw,
            "steam_flow_kg_s": self.steam_flow_kg_s,
        }
