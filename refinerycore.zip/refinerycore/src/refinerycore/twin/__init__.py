"""Digital twin state, telemetry/calibration and equipment health."""
