"""Digital twin state (spec section 36).

A serialisable snapshot of the whole refinery's simulated state:
equipment, streams, tank inventories, utilities, sensors, alarms,
production, energy and (if computed) economics. This is what a UI, API
or future 3D front-end reads -- it never computes physics itself.
"""

from __future__ import annotations

import csv
import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from refinerycore.core.ids import utc_now_iso


@dataclass
class RefineryTwinState:
    refinery_name: str
    timestamp: str = field(default_factory=utc_now_iso)
    simulation_id: str = ""
    equipment_states: dict[str, dict[str, Any]] = field(default_factory=dict)
    stream_states: dict[str, dict[str, Any]] = field(default_factory=dict)
    tank_inventories: dict[str, dict[str, Any]] = field(default_factory=dict)
    utility_states: dict[str, dict[str, Any]] = field(default_factory=dict)
    sensor_values: dict[str, float] = field(default_factory=dict)
    alarms: list[dict[str, Any]] = field(default_factory=list)
    kpis: dict[str, float] = field(default_factory=dict)
    economic_state: dict[str, float] = field(default_factory=dict)
    solver_status: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RefineryTwinState":
        return cls(**data)

    def save_json(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(self.to_dict(), indent=2, default=str))

    @classmethod
    def load_json(cls, path: str | Path) -> "RefineryTwinState":
        return cls.from_dict(json.loads(Path(path).read_text()))

    def save_state(self, path: str | Path) -> None:
        self.save_json(path)

    @classmethod
    def load_state(cls, path: str | Path) -> "RefineryTwinState":
        return cls.load_json(path)

    def streams_to_csv(self, path: str | Path) -> None:
        rows = list(self.stream_states.values())
        if not rows:
            Path(path).write_text("")
            return
        fieldnames = sorted({k for row in rows for k in row})
        with open(path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)

    def kpis_to_csv(self, path: str | Path) -> None:
        with open(path, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["kpi", "value"])
            for k, v in self.kpis.items():
                writer.writerow([k, v])
