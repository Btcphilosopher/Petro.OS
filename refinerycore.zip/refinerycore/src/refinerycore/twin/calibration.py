"""Digital twin calibration (spec section 38).

Reconciles simulated vs. observed (sensor) values via least-squares bias
correction / parameter fitting. Physics remains the baseline: this
module never substitutes a machine-learned value for a physical
calculation -- it only nudges a *model parameter* (e.g. a pump's
health_score, a heat exchanger's UA) so the model's predictions better
match observations.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np
from scipy.optimize import least_squares


@dataclass
class CalibrationResult:
    parameter_name: str
    fitted_value: float
    initial_value: float
    residual_rms: float
    success: bool


def calibrate_parameter(
    parameter_name: str,
    initial_value: float,
    predict_fn: Callable[[float], np.ndarray],
    observed: np.ndarray,
    bounds: tuple[float, float] = (-np.inf, np.inf),
) -> CalibrationResult:
    """Fit a single scalar model parameter by least squares against
    observed data.

    ``predict_fn(parameter_value) -> predicted array`` (same shape as
    ``observed``); the returned model-discrepancy residual is
    ``predicted - observed``, so it is easy to distinguish structural
    model error (large residual even after fitting) from measurement
    noise (residual within sensor uncertainty).
    """

    def residuals(x: np.ndarray) -> np.ndarray:
        return predict_fn(float(x[0])) - observed

    result = least_squares(residuals, x0=[initial_value], bounds=([bounds[0]], [bounds[1]]))
    rms = float(np.sqrt(np.mean(result.fun**2)))
    return CalibrationResult(
        parameter_name=parameter_name,
        fitted_value=float(result.x[0]),
        initial_value=initial_value,
        residual_rms=rms,
        success=bool(result.success),
    )


def bias_correction(measured: np.ndarray, simulated: np.ndarray) -> float:
    """Simple additive bias estimate: mean(measured - simulated).
    Distinct from model-discrepancy: this is measurement bias only."""
    return float(np.mean(np.asarray(measured) - np.asarray(simulated)))
