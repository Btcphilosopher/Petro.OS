"""Equipment health model (spec section 39).

``health_score`` in [0, 1] scales equipment performance: a pump's
efficiency is multiplied by its health score, a heat exchanger's clean
UA is multiplied by a fouling-derived factor, etc. Health degrades with
runtime via a simple linear-with-age model unless a specific degradation
model (e.g. :class:`~refinerycore.equipment.heat_exchanger.FoulingModel`)
overrides it.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class EquipmentHealth:
    """Tracks the wear state of one piece of equipment.

    ``health_score``: 1.0 = as-new, 0.0 = fully degraded.
    ``degradation_rate_per_hour``: fractional health lost per running hour
    (a named, documented, configurable parameter -- never a bare magic
    number at the call site).
    """

    health_score: float = 1.0
    age_hours: float = 0.0
    runtime_hours: float = 0.0
    degradation_rate_per_hour: float = 2.0e-6  # ~0.5%/month of continuous running
    maintenance_due: bool = False
    maintenance_threshold: float = 0.70
    failure_probability: float = 0.0

    def advance(self, hours: float) -> None:
        """Advance age/runtime and degrade health linearly. Failure
        probability is modelled as a simple increasing function of
        (1 - health_score); this is a Level 0 conceptual model, not a
        reliability-engineering (Weibull/bathtub) analysis."""
        if hours < 0:
            raise ValueError("hours must be >= 0")
        self.age_hours += hours
        self.runtime_hours += hours
        self.health_score = max(0.0, self.health_score - self.degradation_rate_per_hour * hours)
        self.failure_probability = min(1.0, (1.0 - self.health_score) ** 2)
        self.maintenance_due = self.health_score < self.maintenance_threshold

    def perform_maintenance(self, restored_health: float = 1.0) -> None:
        self.health_score = min(1.0, max(self.health_score, restored_health))
        self.maintenance_due = False
        self.failure_probability = min(1.0, (1.0 - self.health_score) ** 2)

    def to_dict(self) -> dict:
        return {
            "health_score": self.health_score,
            "age_hours": self.age_hours,
            "runtime_hours": self.runtime_hours,
            "maintenance_due": self.maintenance_due,
            "failure_probability": self.failure_probability,
        }
