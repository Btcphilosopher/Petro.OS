"""REFINERYCORE.OS

A petroleum refinery digital twin, process simulator and engineering
optimisation engine.

FIDELITY NOTICE
----------------
REFINERYCORE.OS is an educational / conceptual engineering simulation
framework. It is NOT a licensed process simulator (it does not reproduce
Aspen HYSYS, PRO/II, PetroSIM or any commercial package), it is NOT
plant-certified, and it is NOT connected to any real refinery control
system. Every model in this package declares a fidelity level
(see :mod:`refinerycore.core.enums.FidelityLevel`) and every simplified
correlation says so in its docstring. See ``docs/limitations.md``.
"""

from __future__ import annotations

__version__ = "0.1.0"
