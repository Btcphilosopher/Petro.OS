"""REFINERYCORE.OS command-line interface (spec section 58).

::

    refinerycore simulate examples/cdu_example.yaml
    refinerycore solve
    refinerycore optimise
    refinerycore scenario
    refinerycore montecarlo
    refinerycore validate
    refinerycore report
"""

from __future__ import annotations

import json

import click

from refinerycore.core.configuration import load_yaml_config
from refinerycore.demo import build_demo_refinery, run_demo_refinery


@click.group()
def main() -> None:
    """REFINERYCORE.OS -- petroleum refinery digital twin & process simulator."""


@main.command()
@click.argument("config_path", type=click.Path(exists=True), required=False)
def simulate(config_path: str | None) -> None:
    """Run a steady-state simulation, optionally from a YAML config file."""
    if config_path:
        cfg = load_yaml_config(config_path)
        feed = next(iter(cfg.feed.values()))
        cdu_cfg = cfg.cdu
        build = build_demo_refinery(
            furnace_outlet_temperature_K=cdu_cfg.furnace.outlet_temperature_K if cdu_cfg else 650.0,
            column_pressure_Pa=cdu_cfg.column.pressure_Pa if cdu_cfg else 1.8e5,
            reflux_ratio=cdu_cfg.column.reflux_ratio if cdu_cfg else 2.5,
            feed_temperature_K=feed.temperature_K,
            feed_pressure_Pa=feed.pressure_Pa,
        )
    else:
        build = build_demo_refinery()

    run_demo_refinery(build)
    click.echo(f"Simulated {cfg.name if config_path else build.refinery.name}: CONVERGED")
    click.echo(json.dumps(build.cdu.last_result["product_yields_kg_s"], indent=2))


@main.command()
def solve() -> None:
    """Solve the demo refinery's steady state and print solver diagnostics."""
    build = build_demo_refinery()
    result = run_demo_refinery(build)
    click.echo(f"Status: {result['final'].status.value}")
    click.echo(f"Iterations: {result['final'].iterations}")


@main.command()
def validate() -> None:
    """Validate the demo refinery's process graph and material balances."""
    build = build_demo_refinery()
    run_demo_refinery(build)
    problems = build.refinery.validate()
    mb = build.cdu.material_balance()
    if problems:
        for p in problems:
            click.echo(f"PROBLEM: {p}")
    else:
        click.echo("Process graph: OK (fully connected)")
    click.echo(f"CDU material balance relative residual: {mb.relative_residual:.3e}")


@main.command()
def report() -> None:
    """Print a JSON twin-state snapshot of the demo refinery."""
    build = build_demo_refinery()
    run_demo_refinery(build)
    state = build.refinery.export_state()
    click.echo(json.dumps(state.to_dict(), indent=2, default=str))


@main.command()
def optimise() -> None:
    """Maximise CDU distillate yield (naphtha+kerosene+diesel) fraction by
    tuning furnace outlet temperature and reflux ratio, subject to a
    furnace duty cap -- a compact CLI-sized version of
    examples/optimisation_example.py."""
    import numpy as np

    from refinerycore.optimisation.optimizer import Constraint, DecisionVariable, RefineryOptimizer

    def distillate_fraction(x: np.ndarray) -> float:
        furnace_t, reflux = float(x[0]), float(x[1])
        build = build_demo_refinery(furnace_outlet_temperature_K=furnace_t, reflux_ratio=reflux)
        run_demo_refinery(build)
        yields = build.cdu.last_result["product_yields_mass_fraction"]
        return yields["naphtha"] + yields["kerosene"] + yields["diesel"]

    def furnace_duty_w(x: np.ndarray) -> float:
        furnace_t = float(x[0])
        build = build_demo_refinery(furnace_outlet_temperature_K=furnace_t, reflux_ratio=float(x[1]))
        run_demo_refinery(build)
        return build.cdu.last_result["furnace"]["required_fired_duty_w"]

    optimizer = RefineryOptimizer(
        decision_variables=[
            DecisionVariable("furnace_outlet_temperature_K", 650.0, 600.0, 700.0),
            DecisionVariable("reflux_ratio", 2.5, 1.0, 5.0),
        ],
        objective_fn=distillate_fraction,
        constraints=[Constraint("furnace_duty_cap_125MW", furnace_duty_w, 0.0, 1.25e8)],
        maximize=True,
    )
    result = optimizer.optimise()
    click.echo(f"Status: {result.status.value}")
    click.echo(f"Baseline distillate fraction: {result.baseline_objective_value:.4f}")
    click.echo(f"Optimised distillate fraction: {result.objective_value:.4f}")
    click.echo(json.dumps(result.decision_values, indent=2))


@main.command()
def scenario() -> None:
    """Inject a heat-exchanger-fouling fault into the demo refinery and
    report the propagated furnace-duty consequence -- a compact CLI-sized
    version of examples/fault_scenario.py."""
    from refinerycore.equipment.heat_exchanger import FoulingModel, HeatExchanger

    build = build_demo_refinery()
    run_demo_refinery(build)
    baseline_duty = build.cdu.last_result["furnace"]["required_fired_duty_w"]

    # ua_clean_w_k is sized close to the atm-gas-oil side's own heat
    # capacity rate (c_min) rather than the module default, so this small
    # side-draw exchanger sits at a moderate NTU where fouling visibly
    # reduces duty instead of saturating at effectiveness ~= 1.
    hx = HeatExchanger(id="HX-101", name="Crude preheat exchanger", ua_clean_w_k=3.0e4, fouling=FoulingModel())
    hx.inputs["hot_in"] = build.cdu.product_streams["atm_gas_oil"]
    hx.inputs["cold_in"] = build.crude_feed_stream
    before = hx.run()

    hx.fouling.advance(4_000.0)  # ~167 days of fouling buildup
    after = hx.run()

    click.echo(f"Baseline CDU furnace duty: {baseline_duty / 1.0e6:.2f} MW")
    click.echo(f"HX-101 duty before fouling: {before['duty_w'] / 1.0e6:.2f} MW")
    click.echo(f"HX-101 duty after fouling:  {after['duty_w'] / 1.0e6:.2f} MW")
    click.echo(f"Duty lost to fouling: {(before['duty_w'] - after['duty_w']) / 1.0e6:.2f} MW "
               f"(furnace must make this up)")


@main.command()
def montecarlo() -> None:
    """Run a small Monte Carlo uncertainty study on crude API gravity."""
    from refinerycore.optimisation.monte_carlo import MonteCarloEngine, UncertainVariable

    def model(draw: dict[str, float]) -> float:
        # API gravity -> crude density is a cheap, self-contained proxy
        # output for this CLI demo (see refinerycore.fluids.crude_assay
        # for the same correlation used throughout the physics layer).
        return 999.016 * 141.5 / (draw["api_gravity"] + 131.5)

    engine = MonteCarloEngine(
        variables=[UncertainVariable(name="api_gravity", kind="model", mean=35.0, std=1.5)],
        model_fn=model,
        seed=42,
    )
    result = engine.run(n_samples=500)
    click.echo(json.dumps(result.output_stats, indent=2))


if __name__ == "__main__":
    main()
