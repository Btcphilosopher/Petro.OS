"""Refinery-wide hydrogen network (spec section 28)."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class HydrogenNetwork:
    """Tracks hydrogen production and consumption across the refinery.

    Sources/consumers register a named flow (kg/s); purity/losses are
    simple documented fractions applied to production.
    """

    production_kg_s: dict[str, float] = field(default_factory=dict)
    consumption_kg_s: dict[str, float] = field(default_factory=dict)
    purity_fraction: float = 0.95
    loss_fraction: float = 0.02  # fraction of gross production lost to purge/venting

    def register_production(self, source: str, flow_kg_s: float) -> None:
        self.production_kg_s[source] = flow_kg_s

    def register_consumption(self, consumer: str, flow_kg_s: float) -> None:
        self.consumption_kg_s[consumer] = flow_kg_s

    @property
    def gross_production_kg_s(self) -> float:
        return sum(self.production_kg_s.values())

    @property
    def net_production_kg_s(self) -> float:
        return self.gross_production_kg_s * (1.0 - self.loss_fraction)

    @property
    def total_consumption_kg_s(self) -> float:
        return sum(self.consumption_kg_s.values())

    @property
    def balance_kg_s(self) -> float:
        """Positive = surplus (available for export/PSA); negative = deficit
        (must be covered by external supply)."""
        return self.net_production_kg_s - self.total_consumption_kg_s

    @property
    def is_deficit(self) -> bool:
        return self.balance_kg_s < 0

    def to_dict(self) -> dict:
        return {
            "gross_production_kg_s": self.gross_production_kg_s,
            "net_production_kg_s": self.net_production_kg_s,
            "total_consumption_kg_s": self.total_consumption_kg_s,
            "balance_kg_s": self.balance_kg_s,
            "is_deficit": self.is_deficit,
            "purity_fraction": self.purity_fraction,
        }
