"""Refinery process graph (spec section 32).

Nodes are equipment/unit ids; edges are streams. Built on ``networkx``
for topological traversal, dependency analysis, upstream/downstream
lookup and island (disconnected subgraph) detection.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import networkx as nx

from refinerycore.core.errors import ProcessGraphError
from refinerycore.streams import Stream


@dataclass
class ProcessGraph:
    graph: nx.DiGraph = field(default_factory=nx.DiGraph)

    def add_equipment(self, equipment_id: str, **attrs) -> None:
        self.graph.add_node(equipment_id, **attrs)

    def add_stream(self, stream: Stream) -> None:
        if stream.source is None or stream.destination is None:
            raise ProcessGraphError(f"stream {stream.id!r} must have both source and destination set")
        self.graph.add_edge(stream.source, stream.destination, stream_id=stream.id, stream=stream)

    def topological_order(self) -> list[str]:
        try:
            return list(nx.topological_sort(self.graph))
        except nx.NetworkXUnfeasible as exc:
            cycles = list(nx.simple_cycles(self.graph))
            raise ProcessGraphError(f"process graph contains a cycle (not a valid DAG): {cycles}") from exc

    def upstream_of(self, equipment_id: str) -> list[str]:
        return list(nx.ancestors(self.graph, equipment_id))

    def downstream_of(self, equipment_id: str) -> list[str]:
        return list(nx.descendants(self.graph, equipment_id))

    def direct_predecessors(self, equipment_id: str) -> list[str]:
        return list(self.graph.predecessors(equipment_id))

    def direct_successors(self, equipment_id: str) -> list[str]:
        return list(self.graph.successors(equipment_id))

    def islands(self) -> list[set[str]]:
        """Return each weakly-connected component (a fully connected
        refinery has exactly one)."""
        return [set(c) for c in nx.weakly_connected_components(self.graph)]

    def validate_connected(self) -> None:
        island_list = self.islands()
        if len(island_list) > 1:
            raise ProcessGraphError(f"process graph has {len(island_list)} disconnected islands: {island_list}")

    def flow_path(self, source_id: str, destination_id: str) -> list[str]:
        try:
            return nx.shortest_path(self.graph, source_id, destination_id)
        except nx.NetworkXNoPath as exc:
            raise ProcessGraphError(f"no flow path from {source_id!r} to {destination_id!r}") from exc

    def to_dict(self) -> dict:
        return {
            "nodes": list(self.graph.nodes),
            "edges": [
                {"source": u, "destination": v, "stream_id": d.get("stream_id")}
                for u, v, d in self.graph.edges(data=True)
            ],
        }
