"""Cooling water network (spec section 31)."""

from __future__ import annotations

from dataclasses import dataclass, field

WATER_CP_J_KG_K = 4186.0


@dataclass
class CoolingWaterNetwork:
    supply_temperature_K: float = 301.15  # ~28 degC
    return_temperature_K: float = 312.15  # ~39 degC design return
    consumers_kg_s: dict[str, float] = field(default_factory=dict)
    pump_power_w: float = 0.0
    cooling_tower_approach_K: float = 5.0  # tower approach to wet-bulb, documented design value

    def register_consumer(self, consumer: str, flow_kg_s: float) -> None:
        self.consumers_kg_s[consumer] = flow_kg_s

    @property
    def total_flow_kg_s(self) -> float:
        return sum(self.consumers_kg_s.values())

    @property
    def heat_rejection_w(self) -> float:
        return self.total_flow_kg_s * WATER_CP_J_KG_K * (self.return_temperature_K - self.supply_temperature_K)

    def to_dict(self) -> dict:
        return {
            "total_flow_kg_s": self.total_flow_kg_s,
            "heat_rejection_w": self.heat_rejection_w,
            "supply_temperature_K": self.supply_temperature_K,
            "return_temperature_K": self.return_temperature_K,
            "pump_power_w": self.pump_power_w,
        }
