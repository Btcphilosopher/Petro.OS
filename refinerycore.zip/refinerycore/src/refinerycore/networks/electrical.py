"""Refinery-wide electrical network (spec section 30)."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class ElectricalNetwork:
    generation_w: dict[str, float] = field(default_factory=dict)
    import_w: dict[str, float] = field(default_factory=dict)
    loads_w: dict[str, float] = field(default_factory=dict)
    _peak_load_w: float = 0.0
    _load_samples_w: list[float] = field(default_factory=list)

    def register_generation(self, source: str, power_w: float) -> None:
        self.generation_w[source] = power_w

    def register_import(self, source: str, power_w: float) -> None:
        self.import_w[source] = power_w

    def register_load(self, consumer: str, power_w: float) -> None:
        self.loads_w[consumer] = power_w
        self._load_samples_w.append(self.total_demand_w)
        self._peak_load_w = max(self._peak_load_w, self.total_demand_w)

    @property
    def total_generation_w(self) -> float:
        return sum(self.generation_w.values())

    @property
    def total_import_w(self) -> float:
        return sum(self.import_w.values())

    @property
    def total_demand_w(self) -> float:
        return sum(self.loads_w.values())

    @property
    def balance_w(self) -> float:
        return self.total_generation_w + self.total_import_w - self.total_demand_w

    @property
    def peak_load_w(self) -> float:
        return self._peak_load_w

    @property
    def load_factor(self) -> float:
        """Average demand / peak demand over recorded samples, dimensionless."""
        if not self._load_samples_w or self._peak_load_w <= 0:
            return 0.0
        return (sum(self._load_samples_w) / len(self._load_samples_w)) / self._peak_load_w

    def to_dict(self) -> dict:
        return {
            "total_generation_w": self.total_generation_w,
            "total_import_w": self.total_import_w,
            "total_demand_w": self.total_demand_w,
            "balance_w": self.balance_w,
            "peak_load_w": self.peak_load_w,
            "load_factor": self.load_factor,
        }
