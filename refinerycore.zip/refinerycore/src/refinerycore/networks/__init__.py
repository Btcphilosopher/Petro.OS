"""Refinery-wide networks: the process graph plus hydrogen/steam/cooling/electrical utilities."""
