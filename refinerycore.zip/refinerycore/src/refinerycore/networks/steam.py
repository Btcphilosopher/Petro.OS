"""Refinery-wide steam network (spec section 29)."""

from __future__ import annotations

from dataclasses import dataclass, field

from refinerycore.core.enums import SteamLevel

#: Representative specific enthalpy of saturated steam at each header
#: pressure level, J/kg (typical refinery header conditions; NOT a
#: substitute for a steam-table lookup -- see docs/limitations.md for
#: where a WaterSteamProvider would replace these constants).
STEAM_ENTHALPY_J_KG: dict[SteamLevel, float] = {
    SteamLevel.HP: 2.79e6,   # ~42 bar sat. steam
    SteamLevel.MP: 2.80e6,   # ~15 bar sat. steam
    SteamLevel.LP: 2.71e6,   # ~4 bar sat. steam
    SteamLevel.CONDENSATE: 4.2e5,
}


@dataclass
class SteamNetwork:
    production_kg_s: dict[SteamLevel, dict[str, float]] = field(
        default_factory=lambda: {level: {} for level in SteamLevel}
    )
    consumption_kg_s: dict[SteamLevel, dict[str, float]] = field(
        default_factory=lambda: {level: {} for level in SteamLevel}
    )

    def register_production(self, level: SteamLevel, source: str, flow_kg_s: float) -> None:
        self.production_kg_s[level][source] = flow_kg_s

    def register_consumption(self, level: SteamLevel, consumer: str, flow_kg_s: float) -> None:
        self.consumption_kg_s[level][consumer] = flow_kg_s

    def balance_kg_s(self, level: SteamLevel) -> float:
        return sum(self.production_kg_s[level].values()) - sum(self.consumption_kg_s[level].values())

    def energy_w(self, level: SteamLevel) -> float:
        return sum(self.production_kg_s[level].values()) * STEAM_ENTHALPY_J_KG[level]

    def to_dict(self) -> dict:
        return {
            level.value: {
                "production_kg_s": sum(self.production_kg_s[level].values()),
                "consumption_kg_s": sum(self.consumption_kg_s[level].values()),
                "balance_kg_s": self.balance_kg_s(level),
            }
            for level in SteamLevel
        }
