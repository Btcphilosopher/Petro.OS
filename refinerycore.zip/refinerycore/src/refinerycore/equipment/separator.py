"""Two/three-phase separator model (spec section 18).

Splits an inlet stream into vapour and liquid outlets using the inlet's
flashed vapour fraction (from the property provider), and provides
simplified gravity-settling sizing checks (residence time, gas velocity
vs. a Souders-Brown-style terminal velocity). This is a Level 1 sizing
CHECK, not a mechanical-code (e.g. ASME) vessel design.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

from refinerycore.equipment.base import Equipment
from refinerycore.streams import Stream

#: Souders-Brown K factor for a typical vertical separator without a mist
#: eliminator, m/s (representative mid-range value; vendor-specific K
#: factors vary with internals -- see docs/limitations.md).
SOUDERS_BROWN_K_M_S = 0.107


@dataclass
class Separator(Equipment):
    diameter_m: float = 1.5
    length_m: float = 4.5
    liquid_holdup_fraction: float = 0.5  # fraction of vessel volume occupied by liquid at normal level

    def calculate(self) -> dict[str, Any]:
        inlet: Stream = self.inputs["inlet"]
        vf = inlet.state.vapour_fraction
        density_liquid = inlet.fluid.liquid_density_kg_m3
        rho_vapour = max(inlet.state.density_kg_m3, 1.0e-6) if vf > 0 else 1.0

        vapour_mass_flow = inlet.mass_flow_kg_s * vf
        liquid_mass_flow = inlet.mass_flow_kg_s * (1.0 - vf)

        vapour_out = inlet.with_state(mass_flow_kg_s=vapour_mass_flow)
        liquid_out = inlet.with_state(mass_flow_kg_s=liquid_mass_flow)
        vapour_out.id, vapour_out.name = f"{self.id}-vapour", f"{self.name} vapour"
        liquid_out.id, liquid_out.name = f"{self.id}-liquid", f"{self.name} liquid"
        self.outputs["vapour"] = vapour_out
        self.outputs["liquid"] = liquid_out

        cross_section_m2 = math.pi * self.diameter_m**2 / 4.0
        v_terminal = SOUDERS_BROWN_K_M_S * math.sqrt(max(density_liquid - rho_vapour, 1.0) / max(rho_vapour, 1.0e-6))
        vapour_volumetric_flow = vapour_mass_flow / rho_vapour if rho_vapour > 0 else 0.0
        gas_velocity = vapour_volumetric_flow / cross_section_m2 if cross_section_m2 > 0 else 0.0
        flooding_margin = 1.0 - gas_velocity / v_terminal if v_terminal > 0 else 1.0

        liquid_volume_m3 = cross_section_m2 * self.length_m * self.liquid_holdup_fraction
        liquid_volumetric_flow = liquid_mass_flow / density_liquid if density_liquid > 0 else 1.0e-9
        residence_time_s = liquid_volume_m3 / max(liquid_volumetric_flow, 1.0e-9)

        return {
            "equation": "phase split from flashed vapour fraction; Souders-Brown terminal velocity check",
            "vapour_fraction": vf,
            "vapour_mass_flow_kg_s": vapour_mass_flow,
            "liquid_mass_flow_kg_s": liquid_mass_flow,
            "gas_velocity_m_s": gas_velocity,
            "terminal_velocity_m_s": v_terminal,
            "flooding_margin": flooding_margin,
            "liquid_residence_time_s": residence_time_s,
        }
