"""Centrifugal pump model (spec section 14).

Physics
-------
``P_hydraulic = rho * g * Q * H``
``P_shaft = P_hydraulic / eta``

The pump curve ``H(Q)`` is a quadratic fit through shutoff head, the
best-efficiency point (BEP) and a high-flow point; efficiency ``eta(Q)``
is a parabola peaking at the BEP. Both are Level 1 engineering
approximations of a manufacturer's curve, not digitised vendor data.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from refinerycore.core.errors import NonPhysicalStateError
from refinerycore.equipment.base import Equipment
from refinerycore.streams import Stream

GRAVITY_M_S2 = 9.80665


@dataclass
class PumpCurve:
    """A quadratic head-flow curve anchored on three named points.

    ``shutoff_head_m``: head at zero flow.
    ``rated_flow_m3_s`` / ``rated_head_m``: the duty (design) point.
    ``bep_flow_m3_s`` / ``bep_efficiency``: the best-efficiency point.
    ``max_flow_m3_s``: flow at which head has fallen to ~0 (curve envelope).
    """

    shutoff_head_m: float
    rated_flow_m3_s: float
    rated_head_m: float
    bep_flow_m3_s: float
    bep_efficiency: float
    max_flow_m3_s: float

    def head_m(self, flow_m3_s: float) -> float:
        """H(Q) = H0 - a*Q^2, fitted through shutoff and rated points."""
        if flow_m3_s < 0:
            raise NonPhysicalStateError("pump flow must be >= 0")
        a = (self.shutoff_head_m - self.rated_head_m) / max(self.rated_flow_m3_s**2, 1.0e-12)
        return max(self.shutoff_head_m - a * flow_m3_s**2, 0.0)

    def efficiency(self, flow_m3_s: float) -> float:
        """Parabolic efficiency curve peaking at bep_efficiency at bep_flow_m3_s,
        falling to zero at Q=0 and Q=max_flow_m3_s."""
        if flow_m3_s <= 0 or flow_m3_s >= self.max_flow_m3_s:
            return 1.0e-3
        q, qb, qmax = flow_m3_s, self.bep_flow_m3_s, self.max_flow_m3_s
        if q <= qb:
            shape = q / qb
        else:
            shape = max((qmax - q) / (qmax - qb), 0.0)
        return max(self.bep_efficiency * shape, 1.0e-3)


@dataclass
class Pump(Equipment):
    curve: PumpCurve = field(default_factory=lambda: PumpCurve(120.0, 0.30, 90.0, 0.30, 0.78, 0.55))
    speed_fraction: float = 1.0  # fraction of rated speed, affine-law scaling
    valve_throttle_fraction: float = 1.0  # 1.0 = fully open, reduces effective flow

    def _effective_curve_flow(self, requested_flow_m3_s: float) -> float:
        # Affine laws: Q scales with speed; throttling reduces delivered flow.
        return requested_flow_m3_s / max(self.speed_fraction * self.valve_throttle_fraction, 1.0e-6)

    def operating_point(self, volumetric_flow_m3_s: float) -> dict[str, float]:
        q_curve = self._effective_curve_flow(volumetric_flow_m3_s)
        head_m = self.curve.head_m(q_curve) * self.speed_fraction**2
        efficiency = self.curve.efficiency(q_curve) * self.health.health_score
        return {"flow_m3_s": volumetric_flow_m3_s, "head_m": head_m, "efficiency": efficiency}

    def calculate(self) -> dict[str, Any]:
        inlet: Stream = self.inputs["inlet"]
        density = inlet.calculate_density()
        volumetric_flow = inlet.calculate_volume_flow_m3_s()

        point = self.operating_point(volumetric_flow)
        head_m = point["head_m"]
        efficiency = point["efficiency"]

        hydraulic_power_w = density * GRAVITY_M_S2 * volumetric_flow * head_m
        shaft_power_w = hydraulic_power_w / efficiency

        delta_p_pa = density * GRAVITY_M_S2 * head_m
        outlet_pressure_pa = inlet.pressure_Pa + delta_p_pa

        outlet = inlet.with_state(pressure_Pa=outlet_pressure_pa)
        outlet.id, outlet.name = f"{self.id}-outlet", f"{self.name} outlet"
        self.outputs["outlet"] = outlet

        npsh_available_m = max((inlet.pressure_Pa - 3000.0) / (density * GRAVITY_M_S2), 0.0)
        cavitation_risk = npsh_available_m < 0.15 * head_m

        return {
            "equation": "P_hydraulic = rho * g * Q * H; P_shaft = P_hydraulic / eta",
            "inputs": {
                "density_kg_m3": density,
                "volumetric_flow_m3_s": volumetric_flow,
            },
            "head_m": head_m,
            "efficiency": efficiency,
            "delta_p_pa": delta_p_pa,
            "hydraulic_power_w": hydraulic_power_w,
            "shaft_power_w": shaft_power_w,
            "npsh_available_m": npsh_available_m,
            "cavitation_risk": cavitation_risk,
            "outlet_pressure_pa": outlet_pressure_pa,
        }
