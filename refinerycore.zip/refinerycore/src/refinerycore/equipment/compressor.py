"""Compressor model (spec section 15).

Implements isentropic compression work for an ideal gas
(``T2s = T1 * r^((k-1)/k)``), an isentropic efficiency to obtain actual
outlet temperature and shaft power, and a simplified linear surge/choke
envelope so surge margin is derived from the operating point rather than
hard-coded as an alarm.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from refinerycore.core.errors import NonPhysicalStateError
from refinerycore.equipment.base import Equipment
from refinerycore.streams import Stream

#: Ratio of specific heats for a representative light hydrocarbon/H2-rich
#: refinery gas. Documented, configurable -- override per-service.
DEFAULT_HEAT_CAPACITY_RATIO = 1.30


@dataclass
class CompressorMap:
    """A simplified linear surge/choke envelope in (flow, head) space.

    ``surge_flow_m3_s(head)`` and ``choke_flow_m3_s`` bound the flow at
    which surge/choke occurs; both are declared as constants here for
    simplicity (Level 0 conceptual map) rather than digitised vendor data.
    """

    surge_flow_m3_s: float
    choke_flow_m3_s: float

    def surge_margin(self, flow_m3_s: float) -> float:
        if flow_m3_s <= 0:
            return -1.0
        return (flow_m3_s - self.surge_flow_m3_s) / self.surge_flow_m3_s

    def choke_margin(self, flow_m3_s: float) -> float:
        return (self.choke_flow_m3_s - flow_m3_s) / self.choke_flow_m3_s


@dataclass
class Compressor(Equipment):
    pressure_ratio: float = 2.5
    isentropic_efficiency: float = 0.78
    heat_capacity_ratio: float = DEFAULT_HEAT_CAPACITY_RATIO
    compressor_map: CompressorMap | None = None

    def calculate(self) -> dict[str, Any]:
        inlet: Stream = self.inputs["inlet"]
        if self.pressure_ratio <= 1.0:
            raise NonPhysicalStateError("compressor pressure_ratio must be > 1")

        k = self.heat_capacity_ratio
        t1 = inlet.temperature_K
        t2_isentropic = t1 * self.pressure_ratio ** ((k - 1.0) / k)
        cp = inlet.state.specific_heat_j_kg_k

        isentropic_work_j_kg = cp * (t2_isentropic - t1)
        actual_work_j_kg = isentropic_work_j_kg / self.isentropic_efficiency
        t2_actual = t1 + actual_work_j_kg / cp

        shaft_power_w = inlet.mass_flow_kg_s * actual_work_j_kg / self.health.health_score

        outlet_pressure_pa = inlet.pressure_Pa * self.pressure_ratio
        outlet = inlet.with_state(temperature_K=t2_actual, pressure_Pa=outlet_pressure_pa)
        outlet.id, outlet.name = f"{self.id}-outlet", f"{self.name} outlet"
        self.outputs["outlet"] = outlet

        result: dict[str, Any] = {
            "equation": "T2s = T1 * r^((k-1)/k); W_actual = Cp*(T2s-T1) / eta_isentropic",
            "isentropic_outlet_temperature_K": t2_isentropic,
            "actual_outlet_temperature_K": t2_actual,
            "isentropic_work_j_kg": isentropic_work_j_kg,
            "actual_work_j_kg": actual_work_j_kg,
            "shaft_power_w": shaft_power_w,
            "outlet_pressure_pa": outlet_pressure_pa,
        }
        if self.compressor_map is not None:
            flow_m3_s = inlet.calculate_volume_flow_m3_s()
            result["surge_margin"] = self.compressor_map.surge_margin(flow_m3_s)
            result["choke_margin"] = self.compressor_map.choke_margin(flow_m3_s)
            result["in_surge"] = result["surge_margin"] < 0
        return result
