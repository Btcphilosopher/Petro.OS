"""Fired heater / furnace model (spec section 20).

Calculates the process-side duty required to reach a target outlet
temperature, then back-calculates fuel consumption from a combustion
efficiency and fuel heating value. Emissions are estimated from a fixed
carbon-intensity factor for the fuel -- an explicit, documented, Level 1
engineering estimate, NOT a rigorous combustion/kinetic mechanism.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from refinerycore.equipment.base import Equipment
from refinerycore.streams import Stream

#: Representative CO2 emission factor for refinery fuel gas, kg CO2 per kg fuel
#: burned (typical for a light hydrocarbon fuel gas mixture, ~50 MJ/kg,
#: assuming near-complete combustion to CO2 + H2O). Documented estimate,
#: not a plant-specific measured factor.
FUEL_GAS_CO2_FACTOR_KG_PER_KG = 2.75


@dataclass
class Furnace(Equipment):
    target_outlet_temperature_K: float = 650.0
    fuel_heating_value_j_per_kg: float = 45.0e6  # net calorific value, typical refinery fuel gas
    combustion_efficiency: float = 0.90
    radiation_convection_loss_fraction: float = 0.03
    excess_air_fraction: float = 0.15  # fraction excess combustion air above stoichiometric
    ambient_temperature_K: float = 298.15

    def calculate(self) -> dict[str, Any]:
        feed: Stream = self.inputs["feed"]
        cp = feed.state.specific_heat_j_kg_k
        mass_flow = feed.mass_flow_kg_s

        process_duty_w = mass_flow * cp * (self.target_outlet_temperature_K - feed.temperature_K)
        if process_duty_w < 0:
            raise ValueError(
                f"{self.id}: furnace target outlet temperature "
                f"({self.target_outlet_temperature_K} K) is below feed inlet temperature "
                f"({feed.temperature_K} K) -- a furnace only heats"
            )

        losses_w = process_duty_w * self.radiation_convection_loss_fraction
        required_fired_duty_w = (process_duty_w + losses_w) / self.combustion_efficiency

        fuel_flow_kg_s = required_fired_duty_w / (self.fuel_heating_value_j_per_kg * self.combustion_efficiency)
        co2_flow_kg_s = fuel_flow_kg_s * FUEL_GAS_CO2_FACTOR_KG_PER_KG

        # Simplified adiabatic-flame-adjacent stack temperature estimate:
        # excess air carries sensible heat out of the stack, in proportion
        # to the excess-air fraction. Order-of-magnitude only.
        stack_temperature_K = self.ambient_temperature_K + (1.0 - self.combustion_efficiency) * 1200.0 + 50.0 * self.excess_air_fraction

        outlet = feed.with_state(temperature_K=self.target_outlet_temperature_K)
        outlet.id, outlet.name = f"{self.id}-outlet", f"{self.name} outlet"
        self.outputs["outlet"] = outlet

        return {
            "equation": "Q_process = m_dot * Cp * dT; fuel_flow = (Q_process + losses) / (LHV * eta_comb)",
            "process_duty_w": process_duty_w,
            "radiation_convection_losses_w": losses_w,
            "required_fired_duty_w": required_fired_duty_w,
            "fuel_flow_kg_s": fuel_flow_kg_s,
            "co2_flow_kg_s": co2_flow_kg_s,
            "stack_temperature_K": stack_temperature_K,
            "combustion_efficiency": self.combustion_efficiency,
            "outlet_temperature_K": self.target_outlet_temperature_K,
        }
