"""Control valve model (spec section 17).

Liquid service uses the standard Cv sizing equation
``Q_gpm = Cv * sqrt(dP_psi / SG)``; gas service uses a simplified
compressible-flow Cv equation with an explicit choked-flow check at a
critical pressure ratio of 0.5 (a conservative, representative value
for typical valve trims -- not manufacturer-specific).
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

from refinerycore.core.enums import ValveCharacteristic
from refinerycore.core.errors import NonPhysicalStateError
from refinerycore.core.units import pa_to_psi
from refinerycore.equipment.base import Equipment
from refinerycore.streams import Stream

_GPM_PER_M3_S = 15850.323
_CHOKED_PRESSURE_RATIO = 0.5  # P_downstream / P_upstream below which gas flow chokes


def _characteristic_gain(position: float, characteristic: ValveCharacteristic) -> float:
    """Fraction of Cv_max delivered at a given fractional opening (0..1)."""
    position = min(max(position, 0.0), 1.0)
    if characteristic is ValveCharacteristic.LINEAR:
        return position
    if characteristic is ValveCharacteristic.QUICK_OPENING:
        return math.sqrt(position) if position > 0 else 0.0
    if characteristic is ValveCharacteristic.EQUAL_PERCENTAGE:
        rangeability = 50.0
        return rangeability ** (position - 1.0) if position > 0 else 0.0
    raise ValueError(f"unknown valve characteristic {characteristic!r}")


@dataclass
class Valve(Equipment):
    cv_max: float = 100.0
    position: float = 1.0  # fractional opening, 0..1
    characteristic: ValveCharacteristic = ValveCharacteristic.LINEAR
    downstream_pressure_Pa: float = 1.0e5

    def effective_cv(self) -> float:
        return self.cv_max * _characteristic_gain(self.position, self.characteristic)

    def calculate(self) -> dict[str, Any]:
        inlet: Stream = self.inputs["inlet"]
        density = inlet.calculate_density()
        sg = density / 999.016  # relative to water
        cv = self.effective_cv()

        if inlet.state.vapour_fraction < 0.5:
            dp_pa = max(inlet.pressure_Pa - self.downstream_pressure_Pa, 0.0)
            dp_psi = pa_to_psi(dp_pa)
            if cv <= 0 or dp_psi <= 0:
                flow_gpm = 0.0
            else:
                flow_gpm = cv * math.sqrt(dp_psi / max(sg, 1.0e-6))
            volumetric_flow_m3_s = flow_gpm / _GPM_PER_M3_S
            choked = False
        else:
            p1 = inlet.pressure_Pa
            p2 = self.downstream_pressure_Pa
            ratio = p2 / p1 if p1 > 0 else 0.0
            choked = ratio < _CHOKED_PRESSURE_RATIO
            effective_ratio = max(ratio, _CHOKED_PRESSURE_RATIO)
            dp_psi = pa_to_psi(max(p1 - p1 * effective_ratio, 0.0))
            flow_gpm = cv * math.sqrt(dp_psi / max(sg, 1.0e-6)) if cv > 0 else 0.0
            volumetric_flow_m3_s = flow_gpm / _GPM_PER_M3_S

        mass_flow_kg_s = volumetric_flow_m3_s * density
        cavitation_indicator = (
            inlet.state.vapour_fraction < 0.5
            and (inlet.pressure_Pa - self.downstream_pressure_Pa) > 0.5 * inlet.pressure_Pa
        )

        outlet = inlet.with_state(mass_flow_kg_s=mass_flow_kg_s, pressure_Pa=self.downstream_pressure_Pa)
        outlet.id, outlet.name = f"{self.id}-outlet", f"{self.name} outlet"
        self.outputs["outlet"] = outlet

        return {
            "equation": "Q_gpm = Cv * sqrt(dP_psi / SG) (liquid); choked-flow limited (gas)",
            "cv_effective": cv,
            "mass_flow_kg_s": mass_flow_kg_s,
            "volumetric_flow_m3_s": volumetric_flow_m3_s,
            "delta_p_pa": inlet.pressure_Pa - self.downstream_pressure_Pa,
            "choked_flow": choked,
            "cavitation_indicator": cavitation_indicator,
        }
