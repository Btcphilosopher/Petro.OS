"""Pipeline model (spec section 16).

Implements Reynolds number, Darcy-Weisbach pressure drop and friction
factor via the laminar solution, the Blasius approximation (smooth pipe,
4000 < Re < 1e5) or the Swamee-Jain explicit approximation to the
Colebrook equation (turbulent, rough pipe). Minor losses (fittings) are
included via an extensible list of K-factors.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any

from refinerycore.core.errors import NonPhysicalStateError
from refinerycore.equipment.base import Equipment
from refinerycore.streams import Stream

GRAVITY_M_S2 = 9.80665


def reynolds_number(density_kg_m3: float, velocity_m_s: float, diameter_m: float, viscosity_pa_s: float) -> float:
    if viscosity_pa_s <= 0:
        raise NonPhysicalStateError("viscosity must be > 0")
    return density_kg_m3 * abs(velocity_m_s) * diameter_m / viscosity_pa_s


def darcy_friction_factor(reynolds: float, relative_roughness: float) -> float:
    """Piecewise friction factor:

    * Re < 2300: laminar, ``f = 64 / Re``.
    * 2300 <= Re < 4000: linear blend across transition (no single
      accepted correlation exists here; blending avoids a discontinuity).
    * Re >= 4000: Swamee-Jain explicit approximation to Colebrook,
      valid for 4000 < Re < 1e8 and 1e-6 < relative_roughness < 1e-2.
    """
    if reynolds <= 0:
        return 0.0
    if reynolds < 2300:
        return 64.0 / reynolds
    f_turbulent = _swamee_jain(reynolds, relative_roughness)
    if reynolds < 4000:
        f_laminar = 64.0 / reynolds
        blend = (reynolds - 2300.0) / (4000.0 - 2300.0)
        return (1.0 - blend) * f_laminar + blend * f_turbulent
    return f_turbulent


def _swamee_jain(reynolds: float, relative_roughness: float) -> float:
    term = relative_roughness / 3.7 + 5.74 / reynolds**0.9
    return 0.25 / (math.log10(term)) ** 2


def blasius_friction_factor(reynolds: float) -> float:
    """Blasius approximation, smooth pipe, 4000 < Re < 1e5."""
    if not (4000.0 <= reynolds <= 1.0e5):
        import warnings

        from refinerycore.core.errors import CorrelationRangeWarning

        warnings.warn(
            f"Blasius correlation used outside its documented range (Re={reynolds:.3g})",
            CorrelationRangeWarning,
            stacklevel=2,
        )
    return 0.316 / reynolds**0.25


@dataclass
class Fitting:
    """A minor-loss fitting with a fixed resistance coefficient K."""

    name: str
    k_factor: float


@dataclass
class Pipe(Equipment):
    length_m: float = 100.0
    diameter_m: float = 0.3
    roughness_m: float = 4.5e-5  # commercial steel, typical
    elevation_change_m: float = 0.0
    fittings: list[Fitting] = field(default_factory=list)

    @property
    def relative_roughness(self) -> float:
        return self.roughness_m / self.diameter_m

    def calculate(self) -> dict[str, Any]:
        inlet: Stream = self.inputs["inlet"]
        density = inlet.calculate_density()
        viscosity = inlet.state.viscosity_pa_s
        volumetric_flow = inlet.calculate_volume_flow_m3_s()

        area_m2 = math.pi * self.diameter_m**2 / 4.0
        velocity = volumetric_flow / area_m2 if area_m2 > 0 else 0.0

        re = reynolds_number(density, velocity, self.diameter_m, viscosity)
        f = darcy_friction_factor(re, self.relative_roughness)

        friction_dp_pa = f * (self.length_m / self.diameter_m) * 0.5 * density * velocity**2
        minor_k_total = sum(fit.k_factor for fit in self.fittings)
        minor_dp_pa = minor_k_total * 0.5 * density * velocity**2
        elevation_dp_pa = density * GRAVITY_M_S2 * self.elevation_change_m

        total_dp_pa = friction_dp_pa + minor_dp_pa + elevation_dp_pa
        outlet_pressure_pa = inlet.pressure_Pa - total_dp_pa

        outlet = inlet.with_state(pressure_Pa=outlet_pressure_pa)
        outlet.id, outlet.name = f"{self.id}-outlet", f"{self.name} outlet"
        self.outputs["outlet"] = outlet

        return {
            "equation": "Darcy-Weisbach: dP = f * (L/D) * 0.5 * rho * v^2",
            "velocity_m_s": velocity,
            "reynolds_number": re,
            "friction_factor": f,
            "friction_dp_pa": friction_dp_pa,
            "minor_losses_dp_pa": minor_dp_pa,
            "elevation_dp_pa": elevation_dp_pa,
            "total_dp_pa": total_dp_pa,
            "outlet_pressure_pa": outlet_pressure_pa,
        }
