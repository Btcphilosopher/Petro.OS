"""Storage tank model (spec section 19).

Tracks inventory from geometry (a vertical cylindrical tank) and a
running mass balance of in/out flows over a time step. Roof type is
conceptual metadata only (it does not currently change the calculation).
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

from refinerycore.core.errors import MaterialBalanceError
from refinerycore.equipment.base import Equipment
from refinerycore.streams import Stream


@dataclass
class StorageTank(Equipment):
    diameter_m: float = 30.0
    height_m: float = 15.0
    roof_type: str = "fixed"  # "fixed" | "floating" | "generic"
    level_m: float = 7.5
    temperature_K: float = 300.0
    pressure_Pa: float = 1.0e5

    @property
    def cross_section_m2(self) -> float:
        return math.pi * self.diameter_m**2 / 4.0

    @property
    def max_volume_m3(self) -> float:
        return self.cross_section_m2 * self.height_m

    @property
    def volume_m3(self) -> float:
        return self.cross_section_m2 * self.level_m

    def inventory_kg(self, density_kg_m3: float) -> float:
        return self.volume_m3 * density_kg_m3

    def step(self, dt_s: float) -> dict[str, Any]:
        """Advance the tank level by ``dt_s`` seconds given connected
        ``inflow``/``outflow`` streams (either may be absent)."""
        inflow: Stream | None = self.inputs.get("inflow")
        outflow: Stream | None = self.inputs.get("outflow")
        density = (inflow or outflow).calculate_density() if (inflow or outflow) else 800.0

        mass_in = inflow.mass_flow_kg_s * dt_s if inflow else 0.0
        mass_out = outflow.mass_flow_kg_s * dt_s if outflow else 0.0

        current_mass_kg = self.inventory_kg(density)
        new_mass_kg = current_mass_kg + mass_in - mass_out
        if new_mass_kg < -1.0e-6:
            raise MaterialBalanceError(f"{self.id}: tank would be drawn below empty (mass={new_mass_kg:.3g} kg)")
        new_mass_kg = max(new_mass_kg, 0.0)

        new_level_m = new_mass_kg / (density * self.cross_section_m2)
        if new_level_m > self.height_m:
            raise MaterialBalanceError(f"{self.id}: tank overflow (level {new_level_m:.3f} m > height {self.height_m} m)")

        self.level_m = new_level_m
        return {
            "mass_in_kg": mass_in,
            "mass_out_kg": mass_out,
            "level_m": self.level_m,
            "inventory_kg": self.inventory_kg(density),
            "fill_fraction": self.level_m / self.height_m,
        }

    def calculate(self) -> dict[str, Any]:
        """Instantaneous snapshot (no time step): reports current inventory."""
        density = 800.0
        return {
            "equation": "V = A * level; inventory = V * rho",
            "level_m": self.level_m,
            "fill_fraction": self.level_m / self.height_m,
            "volume_m3": self.volume_m3,
            "max_volume_m3": self.max_volume_m3,
            "inventory_kg_estimate": self.inventory_kg(density),
        }
