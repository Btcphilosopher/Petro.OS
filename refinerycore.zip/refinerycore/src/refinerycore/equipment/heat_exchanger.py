"""Shell-and-tube heat exchanger model (spec sections 12-13).

Implements ``Q = UA * LMTD`` for counter-current exchange, plus an
effectiveness-NTU cross-check. Fouling (:class:`FoulingModel`) reduces
the clean UA over time via a first-order fouling-resistance buildup with
an optional cleaning event that resets it.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any

from refinerycore.core.enums import FoulingLevel
from refinerycore.core.errors import NonPhysicalStateError
from refinerycore.equipment.base import Equipment
from refinerycore.streams import Stream


@dataclass
class FoulingModel:
    """Time-dependent fouling resistance R_f(t) (spec section 13).

    ``R_f(t) = R_f_asymptotic * (1 - exp(-t / tau))``, the classical
    Kern-Seaton asymptotic fouling model. ``tau`` (time constant, hours)
    and ``R_f_asymptotic`` (m^2 K / W) are named, documented, and
    configurable -- never hard-coded at the call site.
    """

    r_f_asymptotic_m2_k_w: float = 6.0e-4
    tau_hours: float = 1500.0
    elapsed_hours: float = 0.0

    def advance(self, hours: float) -> None:
        if hours < 0:
            raise ValueError("hours must be >= 0")
        self.elapsed_hours += hours

    def clean(self) -> None:
        self.elapsed_hours = 0.0

    @property
    def fouling_resistance_m2_k_w(self) -> float:
        return self.r_f_asymptotic_m2_k_w * (1.0 - math.exp(-self.elapsed_hours / max(self.tau_hours, 1.0e-9)))

    @property
    def level(self) -> FoulingLevel:
        ratio = self.fouling_resistance_m2_k_w / max(self.r_f_asymptotic_m2_k_w, 1.0e-12)
        if ratio < 0.05:
            return FoulingLevel.CLEAN
        if ratio < 0.5:
            return FoulingLevel.NORMAL
        if ratio < 0.85:
            return FoulingLevel.FOULED
        return FoulingLevel.SEVERELY_FOULED


def lmtd_counter_current(t_hot_in: float, t_hot_out: float, t_cold_in: float, t_cold_out: float) -> float:
    """Log-mean temperature difference, counter-current arrangement."""
    dt1 = t_hot_in - t_cold_out
    dt2 = t_hot_out - t_cold_in
    if dt1 <= 0 or dt2 <= 0:
        raise NonPhysicalStateError(
            f"temperature cross detected (approach temperatures {dt1:.2f} K, {dt2:.2f} K); "
            "counter-current LMTD is undefined"
        )
    if abs(dt1 - dt2) < 1.0e-9:
        return dt1
    return (dt1 - dt2) / math.log(dt1 / dt2)


@dataclass
class HeatExchanger(Equipment):
    ua_clean_w_k: float = 5.0e5  # clean overall UA, W/K
    heat_transfer_area_m2: float = 200.0
    fouling: FoulingModel = field(default_factory=FoulingModel)
    pressure_drop_hot_pa: float = 2.0e4
    pressure_drop_cold_pa: float = 2.0e4

    @property
    def ua_effective_w_k(self) -> float:
        """Fouling reduces the effective overall heat transfer coefficient:
        1/U_dirty = 1/U_clean + R_f (per unit area), then UA_dirty = U_dirty * A."""
        u_clean = self.ua_clean_w_k / self.heat_transfer_area_m2
        u_dirty = 1.0 / (1.0 / u_clean + self.fouling.fouling_resistance_m2_k_w)
        return u_dirty * self.heat_transfer_area_m2

    def calculate(self) -> dict[str, Any]:
        hot_in: Stream = self.inputs["hot_in"]
        cold_in: Stream = self.inputs["cold_in"]

        c_hot = hot_in.mass_flow_kg_s * hot_in.state.specific_heat_j_kg_k
        c_cold = cold_in.mass_flow_kg_s * cold_in.state.specific_heat_j_kg_k
        c_min, c_max = min(c_hot, c_cold), max(c_hot, c_cold)
        c_ratio = c_min / c_max if c_max > 0 else 0.0

        ua = self.ua_effective_w_k
        ntu = ua / c_min if c_min > 0 else 0.0

        if c_ratio < 1.0:
            denom = 1.0 - math.exp(-ntu * (1.0 - c_ratio))
            numer = 1.0 - c_ratio * math.exp(-ntu * (1.0 - c_ratio))
            effectiveness = denom / numer if numer > 0 else 0.0
        else:
            effectiveness = ntu / (1.0 + ntu)
        effectiveness = min(max(effectiveness, 0.0), 1.0)

        q_max = c_min * (hot_in.temperature_K - cold_in.temperature_K)
        duty_w = effectiveness * q_max

        hot_out_temp = hot_in.temperature_K - duty_w / c_hot if c_hot > 0 else hot_in.temperature_K
        cold_out_temp = cold_in.temperature_K + duty_w / c_cold if c_cold > 0 else cold_in.temperature_K

        try:
            lmtd = lmtd_counter_current(hot_in.temperature_K, hot_out_temp, cold_in.temperature_K, cold_out_temp)
            duty_from_ua_w = ua * lmtd
        except NonPhysicalStateError:
            lmtd = float("nan")
            duty_from_ua_w = float("nan")

        approach_hot_end_K = hot_in.temperature_K - cold_out_temp
        approach_cold_end_K = hot_out_temp - cold_in.temperature_K

        hot_out = hot_in.with_state(temperature_K=hot_out_temp, pressure_Pa=hot_in.pressure_Pa - self.pressure_drop_hot_pa)
        cold_out = cold_in.with_state(temperature_K=cold_out_temp, pressure_Pa=cold_in.pressure_Pa - self.pressure_drop_cold_pa)
        hot_out.id, hot_out.name = f"{self.id}-hot-out", f"{self.name} hot outlet"
        cold_out.id, cold_out.name = f"{self.id}-cold-out", f"{self.name} cold outlet"
        self.outputs["hot_out"] = hot_out
        self.outputs["cold_out"] = cold_out

        return {
            "equation": "Q = UA * LMTD (cross-checked against effectiveness-NTU)",
            "ua_clean_w_k": self.ua_clean_w_k,
            "ua_effective_w_k": ua,
            "fouling_resistance_m2_k_w": self.fouling.fouling_resistance_m2_k_w,
            "fouling_level": self.fouling.level.value,
            "ntu": ntu,
            "effectiveness": effectiveness,
            "duty_w": duty_w,
            "duty_from_ua_lmtd_w": duty_from_ua_w,
            "lmtd_K": lmtd,
            "hot_outlet_temperature_K": hot_out_temp,
            "cold_outlet_temperature_K": cold_out_temp,
            "approach_hot_end_K": approach_hot_end_K,
            "approach_cold_end_K": approach_cold_end_K,
        }
