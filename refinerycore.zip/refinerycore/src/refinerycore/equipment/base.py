"""Base class for every physical object in the simulator (spec section 5).

Every piece of equipment has: id, name, description, status, inputs,
outputs, parameters and state. Subclasses implement :meth:`calculate` to
consume ``inputs`` (Stream objects) and populate ``outputs``.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from refinerycore.core.enums import EquipmentStatus, FidelityLevel
from refinerycore.streams import Stream
from refinerycore.twin.health import EquipmentHealth


@dataclass
class Equipment(ABC):
    """Abstract base for all physical equipment models."""

    id: str
    name: str
    description: str = ""
    status: EquipmentStatus = EquipmentStatus.RUNNING
    fidelity: FidelityLevel = FidelityLevel.LEVEL_1_ENGINEERING_APPROXIMATION
    parameters: dict[str, Any] = field(default_factory=dict)
    inputs: dict[str, Stream] = field(default_factory=dict, repr=False)
    outputs: dict[str, Stream] = field(default_factory=dict, repr=False)
    health: EquipmentHealth = field(default_factory=lambda: EquipmentHealth())
    _last_result: dict[str, Any] = field(default_factory=dict, repr=False)

    def connect_input(self, port: str, stream: Stream) -> None:
        self.inputs[port] = stream

    @abstractmethod
    def calculate(self) -> dict[str, Any]:
        """Run this equipment's physics given the currently connected
        ``inputs``, populate ``outputs``, and return a diagnostics dict
        (at minimum the digital-thread lineage for its key output)."""
        raise NotImplementedError

    def run(self) -> dict[str, Any]:
        """Public entry point: calculate and record the result for the
        digital thread / twin state."""
        self._last_result = self.calculate()
        return self._last_result

    @property
    def last_result(self) -> dict[str, Any]:
        return dict(self._last_result)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "type": type(self).__name__,
            "status": self.status.value,
            "fidelity": self.fidelity.name,
            "parameters": dict(self.parameters),
            "health": self.health.to_dict(),
            "last_result": dict(self._last_result),
        }
