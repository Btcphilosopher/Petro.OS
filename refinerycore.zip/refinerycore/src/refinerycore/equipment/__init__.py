"""Equipment models: pump, pipe, valve, heat exchanger, furnace, separator, tank."""
