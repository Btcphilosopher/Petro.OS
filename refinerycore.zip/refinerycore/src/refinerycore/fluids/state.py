"""``FluidState`` -- a :class:`~refinerycore.fluids.fluid.Fluid` evaluated at
a fixed pressure and temperature through a
:class:`~refinerycore.fluids.properties.PropertyProvider`.
"""

from __future__ import annotations

from dataclasses import dataclass

from refinerycore.fluids.fluid import Fluid
from refinerycore.fluids.properties import FluidProperties, PropertyProvider


@dataclass(frozen=True)
class FluidState:
    """A fully-resolved fluid state: composition + thermodynamic conditions."""

    fluid: Fluid
    properties: FluidProperties

    @classmethod
    def at_pt(
        cls, fluid: Fluid, pressure_Pa: float, temperature_K: float, provider: PropertyProvider
    ) -> "FluidState":
        return cls(fluid=fluid, properties=provider.properties_at(fluid, pressure_Pa, temperature_K))

    @property
    def density_kg_m3(self) -> float:
        return self.properties.density_kg_m3

    @property
    def specific_enthalpy_j_kg(self) -> float:
        return self.properties.specific_enthalpy_j_kg

    @property
    def phase(self):
        return self.properties.phase

    @property
    def vapour_fraction(self) -> float:
        return self.properties.vapour_fraction
