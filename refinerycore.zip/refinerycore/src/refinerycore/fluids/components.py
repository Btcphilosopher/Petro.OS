"""Pseudocomponent library (spec section 6).

Each :class:`PseudoComponent` represents a boiling-range hydrocarbon cut,
not a single pure species. Property values are representative,
literature-typical figures for that boiling range -- they are Level 1
engineering approximations, not measured assay data for a specific crude.
Always prefer values from an actual :class:`~refinerycore.fluids.crude_assay.CrudeAssay`
when they are available.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class PseudoComponent:
    """A boiling-range hydrocarbon pseudocomponent.

    Attributes
    ----------
    name:
        Human-readable cut name, e.g. ``"heavy_naphtha"``.
    nbp_low_K, nbp_high_K:
        Normal boiling point range, K.
    molecular_weight:
        Representative molar mass, kg/kmol (g/mol).
    liquid_density_kg_m3:
        Representative liquid density at 288.15 K (15 degC), kg/m^3.
    liquid_cp_j_kg_k:
        Representative liquid specific heat capacity, J/(kg K).
    latent_heat_j_kg:
        Representative latent heat of vaporisation at NBP, J/kg.
    """

    name: str
    nbp_low_K: float
    nbp_high_K: float
    molecular_weight: float
    liquid_density_kg_m3: float
    liquid_cp_j_kg_k: float
    latent_heat_j_kg: float

    @property
    def nbp_mid_K(self) -> float:
        return 0.5 * (self.nbp_low_K + self.nbp_high_K)


# ---------------------------------------------------------------------------
# Representative refinery-cut pseudocomponent library.
# Boiling ranges and properties are typical literature values for the
# named cut; treat as synthetic/representative, NOT measured assay data.
# ---------------------------------------------------------------------------
COMPONENT_LIBRARY: dict[str, PseudoComponent] = {
    "light_ends": PseudoComponent("light_ends", 90.0, 235.0, 30.0, 500.0, 2450.0, 3.6e5),
    "lpg": PseudoComponent("lpg", 231.0, 311.0, 50.0, 550.0, 2500.0, 4.3e5),
    "light_naphtha": PseudoComponent("light_naphtha", 311.0, 383.0, 84.0, 660.0, 2200.0, 3.3e5),
    "heavy_naphtha": PseudoComponent("heavy_naphtha", 383.0, 450.0, 107.0, 730.0, 2100.0, 3.1e5),
    "kerosene": PseudoComponent("kerosene", 450.0, 505.0, 156.0, 790.0, 2050.0, 2.8e5),
    "diesel": PseudoComponent("diesel", 505.0, 615.0, 200.0, 840.0, 2000.0, 2.6e5),
    "light_gas_oil": PseudoComponent("light_gas_oil", 615.0, 650.0, 240.0, 860.0, 1980.0, 2.4e5),
    "heavy_gas_oil": PseudoComponent("heavy_gas_oil", 650.0, 730.0, 330.0, 900.0, 1950.0, 2.2e5),
    "vacuum_gas_oil": PseudoComponent("vacuum_gas_oil", 650.0, 838.0, 400.0, 920.0, 1900.0, 2.0e5),
    "residue": PseudoComponent("residue", 838.0, 1000.0, 700.0, 1000.0, 1850.0, 1.6e5),
}

#: Ordered light -> heavy cut names, used for cut-point logic in the CDU.
CUT_ORDER: tuple[str, ...] = (
    "light_ends",
    "lpg",
    "light_naphtha",
    "heavy_naphtha",
    "kerosene",
    "diesel",
    "light_gas_oil",
    "heavy_gas_oil",
    "vacuum_gas_oil",
    "residue",
)


def get_component(name: str) -> PseudoComponent:
    try:
        return COMPONENT_LIBRARY[name]
    except KeyError as exc:
        raise KeyError(
            f"unknown pseudocomponent {name!r}; known components: {sorted(COMPONENT_LIBRARY)}"
        ) from exc
