"""The :class:`Fluid` abstraction: a mass-fraction mixture of pseudocomponents.

A ``Fluid`` is composition only -- it does not carry a thermodynamic
state (temperature, pressure). Combine a ``Fluid`` with a
:class:`~refinerycore.fluids.properties.PropertyProvider` and a (P, T) to
obtain a :class:`~refinerycore.fluids.state.FluidState`.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from refinerycore.core.errors import NonPhysicalStateError
from refinerycore.fluids.components import COMPONENT_LIBRARY, PseudoComponent, get_component

_FRACTION_TOL = 1.0e-6


@dataclass(frozen=True)
class Fluid:
    """A hydrocarbon mixture defined by mass fractions of pseudocomponents.

    ``composition`` maps component name -> mass fraction and must sum to
    1 within :data:`_FRACTION_TOL`. Use :meth:`Fluid.pure` for a
    single-component stream (e.g. a CDU product cut).
    """

    name: str
    composition: dict[str, float] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.composition:
            raise NonPhysicalStateError(f"Fluid {self.name!r} has no composition")
        total = sum(self.composition.values())
        if any(f < -_FRACTION_TOL for f in self.composition.values()):
            raise NonPhysicalStateError(f"Fluid {self.name!r} has a negative mass fraction")
        if abs(total - 1.0) > 1.0e-4:
            raise NonPhysicalStateError(
                f"Fluid {self.name!r} mass fractions sum to {total:.6f}, expected 1.0"
            )
        for cname in self.composition:
            if cname not in COMPONENT_LIBRARY:
                raise NonPhysicalStateError(f"unknown component {cname!r} in Fluid {self.name!r}")

    @classmethod
    def pure(cls, component_name: str) -> "Fluid":
        get_component(component_name)  # raises if unknown
        return cls(name=component_name, composition={component_name: 1.0})

    @property
    def components(self) -> list[PseudoComponent]:
        return [get_component(name) for name in self.composition]

    @property
    def molecular_weight(self) -> float:
        """Mixture molar mass by mole-averaging approximated via mass-fraction
        weighting of 1/MW (i.e. exact for a mass-fraction composition)."""
        inv_mw = sum(frac / get_component(name).molecular_weight for name, frac in self.composition.items())
        return 1.0 / inv_mw

    @property
    def liquid_density_kg_m3(self) -> float:
        """Ideal (no volume-of-mixing) mass-weighted-reciprocal blend density."""
        inv_rho = sum(frac / get_component(name).liquid_density_kg_m3 for name, frac in self.composition.items())
        return 1.0 / inv_rho

    @property
    def liquid_cp_j_kg_k(self) -> float:
        return sum(frac * get_component(name).liquid_cp_j_kg_k for name, frac in self.composition.items())

    @property
    def latent_heat_j_kg(self) -> float:
        return sum(frac * get_component(name).latent_heat_j_kg for name, frac in self.composition.items())

    def blended_with(self, other: "Fluid", self_mass_fraction: float, name: str | None = None) -> "Fluid":
        """Mass-fraction blend of two fluids (spec section 7, CrudeBlend)."""
        if not 0.0 <= self_mass_fraction <= 1.0:
            raise NonPhysicalStateError("blend mass fraction must be within [0, 1]")
        other_fraction = 1.0 - self_mass_fraction
        merged: dict[str, float] = {}
        for cname, frac in self.composition.items():
            merged[cname] = merged.get(cname, 0.0) + frac * self_mass_fraction
        for cname, frac in other.composition.items():
            merged[cname] = merged.get(cname, 0.0) + frac * other_fraction
        return Fluid(name=name or f"{self.name}+{other.name}", composition=merged)
