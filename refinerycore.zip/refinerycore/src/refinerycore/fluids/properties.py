"""Property provider architecture (spec section 11).

::

    Equipment -> Fluid -> PropertyProvider -> ThermodynamicState

Equipment code never hard-codes a correlation; it asks a
:class:`PropertyProvider` for the properties of a :class:`Fluid` at a
given pressure/temperature. This keeps the rest of the simulator
ignorant of *how* a property was obtained -- swapping
``SimpleHydrocarbonPropertyProvider`` for a future CoolProp-backed
provider requires no change outside this module.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Protocol

from refinerycore.core.enums import Phase
from refinerycore.core.errors import NonPhysicalStateError
from refinerycore.fluids.fluid import Fluid

IDEAL_GAS_CONSTANT_J_PER_MOL_K = 8.314_462_618  #: R, J/(mol K)


@dataclass(frozen=True)
class FluidProperties:
    """A property bundle returned by a :class:`PropertyProvider` at fixed (P, T)."""

    pressure_Pa: float
    temperature_K: float
    phase: Phase
    vapour_fraction: float
    density_kg_m3: float
    specific_enthalpy_j_kg: float
    specific_entropy_j_kg_k: float
    specific_heat_j_kg_k: float
    viscosity_pa_s: float
    molecular_weight: float


class PropertyProvider(Protocol):
    """Protocol every property provider must satisfy."""

    name: str

    def properties_at(self, fluid: Fluid, pressure_Pa: float, temperature_K: float) -> FluidProperties:
        ...

    def bubble_point_K(self, fluid: Fluid, pressure_Pa: float) -> float:
        ...


def _check_pt(pressure_Pa: float, temperature_K: float) -> None:
    if pressure_Pa <= 0:
        raise NonPhysicalStateError(f"absolute pressure must be > 0 Pa, got {pressure_Pa}")
    if temperature_K <= 0:
        raise NonPhysicalStateError(f"temperature must be > 0 K, got {temperature_K}")


class SimpleHydrocarbonPropertyProvider:
    """Level 1 engineering-approximation property provider for hydrocarbon
    pseudocomponent mixtures.

    Model
    -----
    * Liquid density: mass-weighted reciprocal blend of component
      densities at reference conditions, corrected for thermal expansion
      with a constant volumetric expansion coefficient.
    * Vapour fraction: a simplified single-cut boiling-point flash --
      the mixture is treated as fully liquid below its blended normal
      boiling point and fully vapour above it, with a linear two-phase
      ramp of +/- 15 K around the boiling point. This is a deliberate
      simplification (no rigorous VLE/K-values); see
      :mod:`refinerycore.thermodynamics.vle`-equivalent notes in
      docs/limitations.md.
    * Enthalpy: sensible heat from a reference temperature plus latent
      heat of vaporisation applied over the two-phase ramp.
    * Viscosity: a simple Arrhenius-type temperature correlation
      anchored at a reference viscosity, RECOGNISED as an order-of-
      magnitude estimate only.
    """

    name = "SimpleHydrocarbonPropertyProvider"

    #: Reference temperature for density/enthalpy correlations, K (15 degC).
    T_REF_K = 288.15
    #: Typical hydrocarbon liquid thermal expansion coefficient, 1/K.
    THERMAL_EXPANSION_PER_K = 9.0e-4
    #: Reference kinematic viscosity at T_REF_K, Pa.s (representative mid-cut value).
    MU_REF_PA_S = 3.0e-3
    #: Two-phase boiling ramp half-width, K.
    BOILING_RAMP_K = 15.0

    def _boiling_point_K(self, fluid: Fluid) -> float:
        return sum(frac * comp.nbp_mid_K for frac, comp in zip(fluid.composition.values(), fluid.components))

    def properties_at(self, fluid: Fluid, pressure_Pa: float, temperature_K: float) -> FluidProperties:
        _check_pt(pressure_Pa, temperature_K)
        nbp = self._boiling_point_K(fluid)
        ramp_lo, ramp_hi = nbp - self.BOILING_RAMP_K, nbp + self.BOILING_RAMP_K

        if temperature_K <= ramp_lo:
            phase, vf = Phase.LIQUID, 0.0
        elif temperature_K >= ramp_hi:
            phase, vf = Phase.VAPOUR, 1.0
        else:
            vf = (temperature_K - ramp_lo) / (ramp_hi - ramp_lo)
            phase = Phase.TWO_PHASE

        rho_liquid = fluid.liquid_density_kg_m3 * (
            1.0 - self.THERMAL_EXPANSION_PER_K * (temperature_K - self.T_REF_K)
        )
        rho_liquid = max(rho_liquid, 1.0)
        if vf <= 0.0:
            density = rho_liquid
        else:
            mw = fluid.molecular_weight / 1000.0  # kg/mol
            rho_vapour = pressure_Pa * mw / (IDEAL_GAS_CONSTANT_J_PER_MOL_K * temperature_K)
            density = 1.0 / (vf / max(rho_vapour, 1.0e-6) + (1.0 - vf) / rho_liquid)

        cp = fluid.liquid_cp_j_kg_k
        sensible_h = cp * (temperature_K - self.T_REF_K)
        latent_h = vf * fluid.latent_heat_j_kg
        enthalpy = sensible_h + latent_h

        entropy = cp * math.log(max(temperature_K, 1.0) / self.T_REF_K) + vf * fluid.latent_heat_j_kg / max(nbp, 1.0)

        viscosity = self.MU_REF_PA_S * math.exp(1200.0 * (1.0 / temperature_K - 1.0 / self.T_REF_K))
        viscosity = max(viscosity, 1.0e-5)

        return FluidProperties(
            pressure_Pa=pressure_Pa,
            temperature_K=temperature_K,
            phase=phase,
            vapour_fraction=vf,
            density_kg_m3=density,
            specific_enthalpy_j_kg=enthalpy,
            specific_entropy_j_kg_k=entropy,
            specific_heat_j_kg_k=cp,
            viscosity_pa_s=viscosity,
            molecular_weight=fluid.molecular_weight,
        )

    def bubble_point_K(self, fluid: Fluid, pressure_Pa: float) -> float:
        # In this simplified model the blended NBP is treated as pressure
        # independent (Level 1 approximation -- no Clausius-Clapeyron shift).
        _ = pressure_Pa
        return self._boiling_point_K(fluid)


class IdealGasPropertyProvider:
    """Ideal-gas property provider, useful for fuel gas / hydrogen-network
    streams where a hydrocarbon-liquid correlation would not apply."""

    name = "IdealGasPropertyProvider"
    CP_J_KG_K = 2200.0  #: representative light-gas specific heat
    T_REF_K = 298.15

    def properties_at(self, fluid: Fluid, pressure_Pa: float, temperature_K: float) -> FluidProperties:
        _check_pt(pressure_Pa, temperature_K)
        mw = fluid.molecular_weight / 1000.0  # kg/mol
        density = pressure_Pa * mw / (IDEAL_GAS_CONSTANT_J_PER_MOL_K * temperature_K)
        enthalpy = self.CP_J_KG_K * (temperature_K - self.T_REF_K)
        entropy = self.CP_J_KG_K * math.log(max(temperature_K, 1.0) / self.T_REF_K)
        # Sutherland-like viscosity trend, representative order of magnitude only.
        viscosity = 1.1e-5 * (temperature_K / self.T_REF_K) ** 0.7
        return FluidProperties(
            pressure_Pa=pressure_Pa,
            temperature_K=temperature_K,
            phase=Phase.VAPOUR,
            vapour_fraction=1.0,
            density_kg_m3=max(density, 1.0e-6),
            specific_enthalpy_j_kg=enthalpy,
            specific_entropy_j_kg_k=entropy,
            specific_heat_j_kg_k=self.CP_J_KG_K,
            viscosity_pa_s=viscosity,
            molecular_weight=fluid.molecular_weight,
        )

    def bubble_point_K(self, fluid: Fluid, pressure_Pa: float) -> float:
        _ = (fluid, pressure_Pa)
        return 0.0  # an ideal gas has no bubble point in the modelled range
