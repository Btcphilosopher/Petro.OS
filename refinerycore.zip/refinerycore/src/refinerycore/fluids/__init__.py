"""Petroleum fluid abstraction: pseudocomponents, fluids, fluid state,
property providers and crude assays.

FIDELITY NOTICE: the component library represents a crude/refinery
stream as a small set of boiling-range *pseudocomponents* (light ends,
LPG, naphtha cuts, kerosene, diesel, gas-oil cuts, residue). This is a
Level 1 engineering approximation -- it does NOT reproduce a true
multi-hundred-component or continuous-TBP characterisation used by a
licensed simulator. See docs/limitations.md.
"""
