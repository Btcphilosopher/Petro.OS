"""Crude assay engine (spec section 7).

A :class:`CrudeAssay` holds bulk crude properties (API gravity, density,
sulfur, ...) plus a True Boiling Point (TBP) distillation curve. The TBP
curve is interpolated to derive a pseudocomponent yield distribution
(mass fraction of each boiling-range cut in :mod:`refinerycore.fluids.components`),
which is what :meth:`CrudeAssay.to_fluid` returns.

:class:`CrudeBlend` combines multiple crude feeds by mass or volume
fraction, checking that the fractions sum to unity (never silently).
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from refinerycore.core.errors import NonPhysicalStateError
from refinerycore.fluids.components import CUT_ORDER, get_component
from refinerycore.fluids.fluid import Fluid


def api_gravity_to_density_kg_m3(api: float) -> float:
    """Standard API gravity -> density at 60 degF (15.56 degC) correlation.

    ``SG(60F) = 141.5 / (API + 131.5)``; density = SG * 999.016 kg/m^3
    (density of water at 60 degF). Valid for typical crude/product API
    range (roughly 10-70 API); a warning-worthy extrapolation outside that.
    """
    if api <= -131.5:
        raise NonPhysicalStateError("API gravity must be > -131.5")
    sg = 141.5 / (api + 131.5)
    return sg * 999.016


def density_kg_m3_to_api_gravity(density_kg_m3: float) -> float:
    if density_kg_m3 <= 0:
        raise NonPhysicalStateError("density must be > 0")
    sg = density_kg_m3 / 999.016
    return 141.5 / sg - 131.5


@dataclass(frozen=True)
class TBPPoint:
    """One point of a True Boiling Point distillation curve."""

    fraction_recovered: float  # 0..1, volume or mass basis (assay-dependent)
    temperature_K: float


@dataclass
class CrudeAssay:
    """A crude oil assay: bulk properties + a TBP distillation curve.

    ``tbp_curve`` must be sorted by increasing ``fraction_recovered`` and
    cover [0, 1] (or close to it); values are linearly interpolated.
    """

    name: str
    api_gravity: float
    sulfur_wt_pct: float
    tbp_curve: list[TBPPoint]
    viscosity_pa_s_at_311K: float = 5.0e-3
    pour_point_K: float = 258.15
    flash_point_K: float = 233.15
    salt_ptb: float = 5.0  # pounds per thousand barrels -- conventional assay unit, kept as metadata only
    water_vol_pct: float = 0.2
    metals_ppm: dict[str, float] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if len(self.tbp_curve) < 2:
            raise NonPhysicalStateError(f"CrudeAssay {self.name!r} needs at least 2 TBP points")
        fracs = [p.fraction_recovered for p in self.tbp_curve]
        if fracs != sorted(fracs):
            raise NonPhysicalStateError(f"CrudeAssay {self.name!r} TBP curve must be sorted by fraction recovered")
        if fracs[0] < -1.0e-6 or fracs[-1] > 1.0 + 1.0e-6:
            raise NonPhysicalStateError(f"CrudeAssay {self.name!r} TBP fractions must lie within [0, 1]")

    @property
    def density_kg_m3(self) -> float:
        return api_gravity_to_density_kg_m3(self.api_gravity)

    def temperature_at_fraction(self, fraction_recovered: float) -> float:
        """Interpolate the TBP curve: fraction recovered -> temperature."""
        fracs = np.array([p.fraction_recovered for p in self.tbp_curve])
        temps = np.array([p.temperature_K for p in self.tbp_curve])
        f = min(max(fraction_recovered, float(fracs[0])), float(fracs[-1]))
        return float(np.interp(f, fracs, temps))

    def fraction_at_temperature(self, temperature_K: float) -> float:
        """Interpolate the TBP curve: temperature -> fraction recovered."""
        fracs = np.array([p.fraction_recovered for p in self.tbp_curve])
        temps = np.array([p.temperature_K for p in self.tbp_curve])
        t = min(max(temperature_K, float(temps[0])), float(temps[-1]))
        return float(np.interp(t, temps, fracs))

    def pseudocomponent_yields(self) -> dict[str, float]:
        """Derive a mass-fraction yield of each library pseudocomponent
        cut from the TBP curve, by reading off fraction-recovered at each
        cut's boiling-range boundaries.

        This is a Level 1 engineering approximation: it assumes the TBP
        curve is on the same (mass) basis as the returned yields and
        does not correct for TBP/ASTM D86 basis differences.
        """
        yields: dict[str, float] = {}
        prev_fraction = 0.0
        for name in CUT_ORDER:
            comp = get_component(name)
            frac_at_cut_end = self.fraction_at_temperature(comp.nbp_high_K)
            cut_yield = max(frac_at_cut_end - prev_fraction, 0.0)
            yields[name] = cut_yield
            prev_fraction = frac_at_cut_end
        # whatever remains above the heaviest cut boundary is folded into residue
        yields["residue"] += max(1.0 - prev_fraction, 0.0)
        total = sum(yields.values())
        if total <= 0:
            raise NonPhysicalStateError(f"CrudeAssay {self.name!r} produced zero total pseudocomponent yield")
        return {k: v / total for k, v in yields.items()}

    def to_fluid(self) -> Fluid:
        """Convert this assay into a :class:`Fluid` composition."""
        return Fluid(name=self.name, composition=self.pseudocomponent_yields())


@dataclass
class CrudeBlend:
    """A mass-fraction blend of two or more crude assays (spec section 7)."""

    name: str
    components: dict[str, float]  # assay name -> mass fraction
    assays: dict[str, CrudeAssay]

    def __post_init__(self) -> None:
        missing = set(self.components) - set(self.assays)
        if missing:
            raise NonPhysicalStateError(f"CrudeBlend {self.name!r} references unknown assays: {missing}")
        total = sum(self.components.values())
        if abs(total - 1.0) > 1.0e-6:
            raise NonPhysicalStateError(f"CrudeBlend {self.name!r} mass fractions sum to {total:.6f}, expected 1.0")
        if any(f < 0 for f in self.components.values()):
            raise NonPhysicalStateError(f"CrudeBlend {self.name!r} has a negative blend fraction")

    def to_fluid(self) -> Fluid:
        merged: dict[str, float] = {}
        for assay_name, mass_fraction in self.components.items():
            for comp_name, comp_frac in self.assays[assay_name].pseudocomponent_yields().items():
                merged[comp_name] = merged.get(comp_name, 0.0) + comp_frac * mass_fraction
        return Fluid(name=self.name, composition=merged)

    @property
    def blended_api_gravity(self) -> float:
        """Volume-weighted-ish approximation: blend densities by mass
        fraction (reciprocal blending), then convert back to API."""
        inv_rho = sum(f / self.assays[name].density_kg_m3 for name, f in self.components.items())
        density = 1.0 / inv_rho
        return density_kg_m3_to_api_gravity(density)
