"""The reference ~100,000 bbl/day demonstration refinery (spec section 60).

Builds a synthetic, clearly-labelled representative crude assay and
wires up a small but complete flowsheet: feed pump -> desalter -> CDU
(furnace + shortcut column) -> [naphtha -> reformer, diesel ->
hydrotreater] -> hydrogen/steam/electrical/cooling networks. This is
what every example script in ``examples/`` builds on, so the demo data
lives in one place (DRY) rather than being re-typed in every script.

ALL crude assay and utility-intensity figures here are SYNTHETIC,
REPRESENTATIVE data for demonstration purposes -- not measurements of
any real crude or plant. See docs/limitations.md.
"""

from __future__ import annotations

from dataclasses import dataclass

from refinerycore.core.enums import SteamLevel
from refinerycore.core.units import bbl_per_day_to_m3_per_s
from refinerycore.equipment.pump import Pump, PumpCurve
from refinerycore.fluids.crude_assay import CrudeAssay, TBPPoint
from refinerycore.fluids.properties import SimpleHydrocarbonPropertyProvider
from refinerycore.refinery import Refinery
from refinerycore.streams import Stream
from refinerycore.units.cdu import CDU
from refinerycore.units.hydrotreater import Hydrotreater
from refinerycore.units.reformer import Reformer

#: Representative documented utility intensities for the demo refinery
#: (NOT measured plant data -- see module docstring).
STEAM_INTENSITY_KG_PER_KG_CRUDE = 0.045  # stripping + heating steam per kg crude processed
BASELINE_ELECTRICAL_LOAD_W = 8.0e6  # instrumentation, lighting, misc. motors for a ~100 kbpd site
#: Fraction of CDU fired furnace duty rejected downstream as overhead
#: condensing + product cooling duty (documented, representative estimate).
CONDENSER_DUTY_FRACTION_OF_FURNACE_DUTY = 0.55
COOLING_WATER_CP_J_KG_K = 4186.0


def build_demo_crude_assay() -> CrudeAssay:
    """A representative ~35 API medium crude with a synthetic TBP curve."""
    tbp = [
        TBPPoint(0.00, 300.0),
        TBPPoint(0.05, 350.0),
        TBPPoint(0.10, 383.0),
        TBPPoint(0.20, 420.0),
        TBPPoint(0.30, 455.0),
        TBPPoint(0.40, 495.0),
        TBPPoint(0.50, 535.0),
        TBPPoint(0.60, 580.0),
        TBPPoint(0.70, 620.0),
        TBPPoint(0.80, 670.0),
        TBPPoint(0.90, 730.0),
        TBPPoint(0.95, 780.0),
        TBPPoint(1.00, 900.0),
    ]
    return CrudeAssay(
        name="Demo Medium Crude",
        api_gravity=35.0,
        sulfur_wt_pct=1.1,
        tbp_curve=tbp,
    )


@dataclass
class DemoRefineryBuild:
    refinery: Refinery
    feed_pump: Pump
    cdu: CDU
    reformer: Reformer
    hydrotreater: Hydrotreater
    crude_feed_stream: Stream


def build_demo_refinery(
    crude_rate_bbl_day: float = 100_000.0,
    furnace_outlet_temperature_K: float = 650.0,
    column_pressure_Pa: float = 1.8e5,
    reflux_ratio: float = 2.5,
    feed_temperature_K: float = 300.0,
    feed_pressure_Pa: float = 2.5e5,
) -> DemoRefineryBuild:
    provider = SimpleHydrocarbonPropertyProvider()
    assay = build_demo_crude_assay()
    crude_fluid = assay.to_fluid()

    volumetric_flow_m3_s = bbl_per_day_to_m3_per_s(crude_rate_bbl_day)
    # Use the pseudocomponent-blend's own reference-condition density
    # (not the assay's independent API-gravity correlation) so the
    # declared bbl/day rate stays self-consistent with the volumetric
    # flow the property provider recomputes downstream -- the two
    # density models are not required to agree exactly (see
    # docs/limitations.md), so mixing them here would silently bias
    # mass flow away from the requested crude rate.
    mass_flow_kg_s = volumetric_flow_m3_s * crude_fluid.liquid_density_kg_m3

    crude_feed = Stream(
        id="S-CRUDE-FEED",
        name="Crude feed",
        fluid=crude_fluid,
        mass_flow_kg_s=mass_flow_kg_s,
        pressure_Pa=feed_pressure_Pa,
        temperature_K=feed_temperature_K,
        provider=provider,
    )

    feed_pump = Pump(
        id="P-101",
        name="Crude feed pump",
        curve=PumpCurve(
            shutoff_head_m=150.0,
            rated_flow_m3_s=volumetric_flow_m3_s * 1.15,
            rated_head_m=110.0,
            bep_flow_m3_s=volumetric_flow_m3_s * 1.05,
            bep_efficiency=0.78,
            max_flow_m3_s=volumetric_flow_m3_s * 2.0,
        ),
    )
    feed_pump.connect_input("inlet", crude_feed)
    feed_pump.run()
    pumped_crude = feed_pump.outputs["outlet"]

    cdu = CDU(
        id="CDU-100",
        name="Crude Distillation Unit",
        furnace_outlet_temperature_K=furnace_outlet_temperature_K,
        column_pressure_Pa=column_pressure_Pa,
        reflux_ratio=reflux_ratio,
        provider=provider,
    )
    cdu.connect_feed("crude", pumped_crude)

    refinery = Refinery(name="REFINERYCORE.OS Demo Refinery", provider=provider)
    refinery.add_unit(feed_pump)
    refinery.add_unit(cdu)
    refinery.connect(feed_pump.id, cdu.id, pumped_crude)

    # Placeholders wired after the first solve populates CDU product streams.
    reformer = Reformer(id="CCR-100", name="Catalytic Reformer", provider=provider)
    hydrotreater = Hydrotreater(id="HDT-100", name="Diesel Hydrotreater", provider=provider)
    refinery.add_unit(reformer)
    refinery.add_unit(hydrotreater)

    return DemoRefineryBuild(
        refinery=refinery,
        feed_pump=feed_pump,
        cdu=cdu,
        reformer=reformer,
        hydrotreater=hydrotreater,
        crude_feed_stream=crude_feed,
    )


def run_demo_refinery(build: DemoRefineryBuild) -> dict:
    """Solve the CDU first (feed pump + CDU have no recycle so a
    sequential pass converges), wire the downstream conversion units from
    the resulting product streams, then solve those too and populate the
    utility networks from the results."""
    refinery = build.refinery

    # Pass 1: pump + CDU (reformer/hydrotreater feeds don't exist yet).
    solver_pass_1 = _solve_subset(refinery, [build.feed_pump.id, build.cdu.id])

    build.reformer.connect_feed("naphtha", build.cdu.product_streams["naphtha"])
    build.hydrotreater.connect_feed("feed", build.cdu.product_streams["diesel"])
    refinery.connect(build.cdu.id, build.reformer.id, build.cdu.product_streams["naphtha"])
    refinery.connect(build.cdu.id, build.hydrotreater.id, build.cdu.product_streams["diesel"])

    # Pass 2: full topological solve, now that every edge exists.
    result = refinery.solve_steady_state()

    _populate_utilities(refinery, build)

    return {"pass_1": solver_pass_1, "final": result}


def _solve_subset(refinery: Refinery, unit_ids: list[str]):
    from refinerycore.solver.steady_state import SequentialModularSolver

    solver = SequentialModularSolver(graph=refinery.graph)
    for uid in unit_ids:
        solver.register(uid, refinery.units[uid].run)
    return solver.solve()


def _populate_utilities(refinery: Refinery, build: DemoRefineryBuild) -> None:
    crude_flow = build.crude_feed_stream.mass_flow_kg_s

    steam_demand = crude_flow * STEAM_INTENSITY_KG_PER_KG_CRUDE
    refinery.steam_network.register_consumption(SteamLevel.MP, "CDU-stripping", steam_demand)
    refinery.steam_network.register_production(SteamLevel.MP, "Utility-boilers", steam_demand * 1.05)

    refinery.electrical_network.register_load("P-101", build.feed_pump.last_result.get("shaft_power_w", 0.0))
    refinery.electrical_network.register_load("baseline-site-load", BASELINE_ELECTRICAL_LOAD_W)
    refinery.electrical_network.register_import("grid", refinery.electrical_network.total_demand_w)

    refinery.hydrogen_network.register_production("CCR-100", build.reformer.last_result.get("hydrogen_production_kg_s", 0.0))
    refinery.hydrogen_network.register_consumption("HDT-100", build.hydrotreater.last_result.get("hydrogen_consumption_kg_s", 0.0))

    furnace_duty_w = build.cdu.last_result.get("furnace", {}).get("required_fired_duty_w", 0.0)
    condenser_duty_w = furnace_duty_w * CONDENSER_DUTY_FRACTION_OF_FURNACE_DUTY
    cooling_water_dT_K = refinery.cooling_network.return_temperature_K - refinery.cooling_network.supply_temperature_K
    cooling_flow_kg_s = condenser_duty_w / (COOLING_WATER_CP_J_KG_K * cooling_water_dT_K) if cooling_water_dT_K > 0 else 0.0
    refinery.cooling_network.register_consumer("CDU-condenser", cooling_flow_kg_s)
