"""Alarm engine (spec section 41)."""

from __future__ import annotations

from dataclasses import dataclass, field

from refinerycore.core.enums import AlarmSeverity
from refinerycore.core.ids import new_id, utc_now_iso


@dataclass
class Alarm:
    id: str
    source: str
    severity: AlarmSeverity
    condition: str
    actual_value: float
    limit: float
    timestamp: str = field(default_factory=utc_now_iso)
    acknowledged: bool = False

    def acknowledge(self) -> None:
        self.acknowledged = True

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "source": self.source,
            "severity": self.severity.value,
            "condition": self.condition,
            "actual_value": self.actual_value,
            "limit": self.limit,
            "timestamp": self.timestamp,
            "acknowledged": self.acknowledged,
        }


@dataclass
class AlarmEngine:
    alarms: list[Alarm] = field(default_factory=list)

    def check_high(self, source: str, value: float, high: float, high_high: float | None = None) -> Alarm | None:
        if high_high is not None and value >= high_high:
            return self._raise(source, AlarmSeverity.HIGH_HIGH, "value >= high-high limit", value, high_high)
        if value >= high:
            return self._raise(source, AlarmSeverity.HIGH, "value >= high limit", value, high)
        return None

    def check_low(self, source: str, value: float, low: float, low_low: float | None = None) -> Alarm | None:
        if low_low is not None and value <= low_low:
            return self._raise(source, AlarmSeverity.LOW_LOW, "value <= low-low limit", value, low_low)
        if value <= low:
            return self._raise(source, AlarmSeverity.LOW, "value <= low limit", value, low)
        return None

    def check_rate_of_change(self, source: str, delta_per_step: float, limit: float) -> Alarm | None:
        if abs(delta_per_step) > limit:
            return self._raise(source, AlarmSeverity.RATE_OF_CHANGE, "|delta| > limit", delta_per_step, limit)
        return None

    def check_health(self, source: str, health_score: float, threshold: float) -> Alarm | None:
        if health_score < threshold:
            return self._raise(source, AlarmSeverity.HEALTH, "health_score < threshold", health_score, threshold)
        return None

    def _raise(self, source: str, severity: AlarmSeverity, condition: str, actual: float, limit: float) -> Alarm:
        alarm = Alarm(id=new_id("alarm"), source=source, severity=severity, condition=condition, actual_value=actual, limit=limit)
        self.alarms.append(alarm)
        return alarm

    @property
    def active_alarms(self) -> list[Alarm]:
        return [a for a in self.alarms if not a.acknowledged]

    def to_dict(self) -> dict:
        return {"alarms": [a.to_dict() for a in self.alarms]}
