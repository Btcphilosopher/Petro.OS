"""Simulated PID controller (spec section 42).

For use inside the transient simulation engine only -- see the SAFETY
BOUNDARY note in :mod:`refinerycore.controls`.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class PIDController:
    kp: float
    ki: float
    kd: float
    setpoint: float
    output_min: float = float("-inf")
    output_max: float = float("inf")
    _integral: float = 0.0
    _previous_error: float | None = None

    def reset(self) -> None:
        self._integral = 0.0
        self._previous_error = None

    def update(self, measurement: float, dt_s: float) -> float:
        if dt_s <= 0:
            raise ValueError("dt_s must be > 0")
        error = self.setpoint - measurement

        proposed_integral = self._integral + error * dt_s
        derivative = 0.0 if self._previous_error is None else (error - self._previous_error) / dt_s

        output = self.kp * error + self.ki * proposed_integral + self.kd * derivative
        clipped = min(max(output, self.output_min), self.output_max)

        # Anti-windup: only accept the integral update if it does not
        # push the (unclipped) output further past a saturated limit.
        if clipped == output or (output > self.output_max and error < 0) or (output < self.output_min and error > 0):
            self._integral = proposed_integral

        self._previous_error = error
        return clipped
