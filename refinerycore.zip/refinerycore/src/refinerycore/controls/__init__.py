"""Simulated control loops, sensors and alarms.

SAFETY BOUNDARY (spec section 56): everything in this package is a
SIMULATION component. Nothing here connects to, or issues commands to,
real industrial control systems or physical plant equipment.
"""
