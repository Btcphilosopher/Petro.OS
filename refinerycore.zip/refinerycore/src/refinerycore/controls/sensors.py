"""Simulated sensor model (spec section 37).

A sensor reports a *measured* value derived from a *true* simulated
value plus bias, drift and optional Gaussian noise. It never overwrites
the underlying physics -- see :mod:`refinerycore.twin.calibration` for
how measured vs. simulated values are reconciled.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass
class Sensor:
    id: str
    quantity: str  # e.g. "pressure", "temperature", "flow", "level", "vibration", "power", "composition"
    bias: float = 0.0
    noise_std: float = 0.0
    drift_per_hour: float = 0.0
    sample_rate_hz: float = 1.0
    health: float = 1.0  # 1.0 = fully healthy; degrades measurement quality
    _elapsed_hours: float = 0.0
    _rng: np.random.Generator = field(default_factory=lambda: np.random.default_rng())
    seed: int | None = None

    def __post_init__(self) -> None:
        if self.seed is not None:
            self._rng = np.random.default_rng(self.seed)

    def advance(self, hours: float) -> None:
        self._elapsed_hours += hours

    def measure(self, true_value: float) -> float:
        drift = self.drift_per_hour * self._elapsed_hours
        noise = self._rng.normal(0.0, self.noise_std * max(1.0, 2.0 - self.health)) if self.noise_std > 0 else 0.0
        return true_value + self.bias + drift + noise

    def to_dict(self) -> dict:
        return {"id": self.id, "quantity": self.quantity, "bias": self.bias, "health": self.health}
