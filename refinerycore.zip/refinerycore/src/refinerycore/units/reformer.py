"""Catalytic Reformer -- conceptual yield/H2-production model (spec section 27).

FIDELITY NOTICE: Level 0 conceptual model. Reformate yield and hydrogen
production are estimated from a "severity" parameter driven by reactor
temperature; an "octane proxy" tracks severity qualitatively (it is NOT
a calculated RON/MON from detailed reaction pathways).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from refinerycore.fluids.fluid import Fluid
from refinerycore.fluids.properties import PropertyProvider
from refinerycore.streams import Stream
from refinerycore.units.base import ProcessUnit

#: Representative hydrogen yield, kg H2 per kg naphtha feed, at reference
#: severity (documented mid-range estimate for semi-regenerative reforming).
H2_YIELD_KG_PER_KG_FEED_AT_REFERENCE = 0.025
REFERENCE_TEMPERATURE_K = 783.0  # ~510 degC, typical reformer reactor inlet


@dataclass
class Reformer(ProcessUnit):
    reactor_temperature_K: float = 783.0
    reactor_pressure_Pa: float = 1.5e6  # ~15 bar
    severity_octane_proxy_base: float = 60.0  # feed-naphtha research octane proxy
    provider: PropertyProvider = None  # type: ignore[assignment]

    def severity(self) -> float:
        """Dimensionless severity, 0 at reference temperature or below,
        rising linearly above it (documented, capped at 2.0)."""
        return min(max((self.reactor_temperature_K - REFERENCE_TEMPERATURE_K) / 30.0, 0.0), 2.0)

    def calculate(self) -> dict[str, Any]:
        feed: Stream = self.feed_streams["naphtha"]
        sev = self.severity()

        h2_yield_fraction = H2_YIELD_KG_PER_KG_FEED_AT_REFERENCE * (1.0 + 0.4 * sev)
        light_ends_fraction = 0.03 * (1.0 + 0.5 * sev)
        reformate_fraction = 1.0 - h2_yield_fraction - light_ends_fraction

        h2_mass = feed.mass_flow_kg_s * h2_yield_fraction
        light_ends_mass = feed.mass_flow_kg_s * light_ends_fraction
        reformate_mass = feed.mass_flow_kg_s * reformate_fraction

        octane_proxy = self.severity_octane_proxy_base + 25.0 * sev  # qualitative RON proxy, not calculated RON

        self.product_streams = {
            "hydrogen": Stream(
                id=f"{self.id}-h2", name=f"{self.name} hydrogen", fluid=Fluid.pure("light_ends"),
                mass_flow_kg_s=h2_mass, pressure_Pa=self.reactor_pressure_Pa,
                temperature_K=self.reactor_temperature_K, provider=self.provider, source=self.id,
            ),
            "light_ends": Stream(
                id=f"{self.id}-lights", name=f"{self.name} light ends", fluid=Fluid.pure("light_ends"),
                mass_flow_kg_s=light_ends_mass, pressure_Pa=self.reactor_pressure_Pa,
                temperature_K=self.reactor_temperature_K, provider=self.provider, source=self.id,
            ),
            "reformate": Stream(
                id=f"{self.id}-reformate", name=f"{self.name} reformate", fluid=feed.fluid,
                mass_flow_kg_s=reformate_mass, pressure_Pa=self.reactor_pressure_Pa,
                temperature_K=self.reactor_temperature_K, provider=self.provider, source=self.id,
            ),
        }

        return {
            "severity": sev,
            "hydrogen_production_kg_s": h2_mass,
            "reformate_mass_flow_kg_s": reformate_mass,
            "octane_proxy": octane_proxy,
        }
