"""Process units: composite assemblies of equipment (CDU, VDU, FCC, ...)."""
