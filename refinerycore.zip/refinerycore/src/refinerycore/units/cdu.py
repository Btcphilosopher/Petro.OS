"""Crude Distillation Unit (spec section 22).

Assembles desalter -> furnace -> shortcut distillation column into one
composite :class:`ProcessUnit`, and exposes the causal chain the whole
project is built around: crude rate / furnace outlet temperature /
column pressure / reflux ratio -> product yields.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from refinerycore.equipment.furnace import Furnace
from refinerycore.fluids.properties import PropertyProvider
from refinerycore.streams import Stream
from refinerycore.units.base import ProcessUnit
from refinerycore.units.desalter import Desalter
from refinerycore.units.distillation import ProductCut, cutpoint_split, draws_to_fluids

CDU_PRODUCT_CUTS: list[ProductCut] = [
    ProductCut("lpg", ("light_ends", "lpg")),
    ProductCut("naphtha", ("light_naphtha", "heavy_naphtha")),
    ProductCut("kerosene", ("kerosene",)),
    ProductCut("diesel", ("diesel",)),
    ProductCut("atm_gas_oil", ("light_gas_oil",)),
]
CDU_BOTTOMS_CUT = ProductCut("residue", ("heavy_gas_oil", "vacuum_gas_oil", "residue"))


@dataclass
class CDU(ProcessUnit):
    furnace_outlet_temperature_K: float = 650.0
    column_pressure_Pa: float = 1.8e5
    reflux_ratio: float = 2.5
    provider: PropertyProvider = None  # type: ignore[assignment]
    desalter: Desalter = field(default_factory=lambda: Desalter(id="DSLT-100", name="Desalter"))
    furnace: Furnace = field(default_factory=lambda: Furnace(id="F-100", name="CDU Furnace"))

    def calculate(self) -> dict[str, Any]:
        crude: Stream = self.feed_streams["crude"]

        # -- Desalter ---------------------------------------------------
        self.desalter.connect_feed("crude", crude)
        desalter_result = self.desalter.run()
        desalted_crude = self.desalter.product_streams["desalted_crude"]

        # -- Furnace ------------------------------------------------------
        self.furnace.target_outlet_temperature_K = self.furnace_outlet_temperature_K
        self.furnace.connect_input("feed", desalted_crude)
        furnace_result = self.furnace.run()
        furnace_outlet = self.furnace.outputs["outlet"]

        # -- Shortcut column ----------------------------------------------
        draws = cutpoint_split(
            feed=furnace_outlet.fluid,
            cuts=CDU_PRODUCT_CUTS,
            furnace_outlet_temperature_K=self.furnace_outlet_temperature_K,
            column_pressure_Pa=self.column_pressure_Pa,
            reflux_ratio=self.reflux_ratio,
            bottoms_cut=CDU_BOTTOMS_CUT,
        )
        cut_fluids = draws_to_fluids(draws, name_prefix=f"{self.id}-")

        total_feed_mass_flow = furnace_outlet.mass_flow_kg_s
        self.product_streams.clear()
        for cut_name, (fluid, mass_fraction_of_feed) in cut_fluids.items():
            mass_flow = mass_fraction_of_feed * total_feed_mass_flow
            stream = Stream(
                id=f"{self.id}-{cut_name}",
                name=f"{self.name} {cut_name}",
                fluid=fluid,
                mass_flow_kg_s=mass_flow,
                pressure_Pa=self.column_pressure_Pa,
                temperature_K=self._draw_temperature_K(cut_name, fluid),
                provider=self.provider,
                source=self.id,
            )
            self.product_streams[cut_name] = stream

        self.feed_streams["crude"] = crude

        mb = self.material_balance()
        eb = self.energy_balance(heat_in_w=furnace_result["process_duty_w"])

        return {
            "desalter": desalter_result,
            "furnace": furnace_result,
            "furnace_outlet_temperature_K": self.furnace_outlet_temperature_K,
            "column_pressure_Pa": self.column_pressure_Pa,
            "reflux_ratio": self.reflux_ratio,
            "product_yields_kg_s": {name: s.mass_flow_kg_s for name, s in self.product_streams.items()},
            "product_yields_mass_fraction": {
                name: s.mass_flow_kg_s / total_feed_mass_flow for name, s in self.product_streams.items()
            },
            "material_balance": {
                "mass_in_kg_s": mb.total_mass_in_kg_s,
                "mass_out_kg_s": mb.total_mass_out_kg_s,
                "absolute_residual_kg_s": mb.absolute_residual_kg_s,
                "relative_residual": mb.relative_residual,
            },
            "energy_balance": {
                "enthalpy_in_w": eb.enthalpy_in_w,
                "enthalpy_out_w": eb.enthalpy_out_w,
                "heat_in_w": eb.heat_in_w,
                "residual_w": eb.residual_w,
            },
        }

    def _draw_temperature_K(self, cut_name: str, fluid) -> float:
        """Approximate each product draw's temperature as its blended NBP
        (a Level 1 simplification -- real side-draw temperatures are set
        by stripping steam and tray location, not modelled here)."""
        return self.provider.bubble_point_K(fluid, self.column_pressure_Pa) if self.provider else 400.0
