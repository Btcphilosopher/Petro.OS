"""Shortcut cut-point distillation model shared by the CDU and VDU.

FIDELITY NOTICE (Level 1 -- engineering approximation)
-------------------------------------------------------
This is a *shortcut* separation model, not the rigorous stage-by-stage
equilibrium solver described in spec section 21 (K-values, VLE, per-stage
mass/energy balances). It exists so that changing furnace outlet
temperature, column pressure and reflux ratio produces a physically
sensible, monotonic change in product yields -- the central causal
chain this project asks for -- without pretending to reproduce a
licensed simulator's tray-by-tray solution. A full MESH-equation
equilibrium-stage column is a natural Level 2 follow-on (see
docs/limitations.md).

Model
-----
Each product "cut" is defined by a lower/upper normal-boiling-point
(NBP) boundary spanning one or more pseudocomponents. Given an
*effective cutpoint temperature* ``T_cut`` (the furnace outlet
temperature, corrected for column pressure), each pseudocomponent's mass
is distributed between "recovered as distillate" and "left in the
bottoms" in proportion to how much of its boiling range lies below
``T_cut``:

    recovered_fraction = clip((T_cut - nbp_low) / (nbp_high - nbp_low), 0, 1)

Reflux ratio then sharpens or dulls the boundary *between adjacent
distillate cuts* (not between distillate and bottoms) by exchanging a
small "overlap" mass fraction between neighbouring cuts:

    overlap_fraction = OVERLAP_CONSTANT / (1 + reflux_ratio)

Higher reflux -> lower overlap -> sharper separation, consistent with
real column behaviour, without solving the column tray-by-tray.
"""

from __future__ import annotations

from dataclasses import dataclass

from refinerycore.core.errors import NonPhysicalStateError
from refinerycore.fluids.components import get_component
from refinerycore.fluids.fluid import Fluid

#: Reference column pressure for the cutpoint-temperature correction, Pa
#: (roughly atmospheric for the CDU column).
REFERENCE_PRESSURE_PA = 1.8e5

#: Documented sensitivity constant relating cutpoint-temperature shift to
#: ln(P / P_ref), an approximate Clausius-Clapeyron-style correction
#: (higher pressure -> higher effective boiling points -> less recovery
#: for a given furnace temperature). K per unit ln(pressure ratio).
PRESSURE_CUTPOINT_SENSITIVITY_K = 25.0

#: Documented overlap constant controlling how much reflux sharpens
#: adjacent-cut separation (spec section 21/22): higher reflux -> less
#: overlap. Dimensionless.
OVERLAP_CONSTANT = 0.12


@dataclass(frozen=True)
class ProductCut:
    """One draw of a shortcut distillation column."""

    name: str
    components: tuple[str, ...]

    @property
    def nbp_low_K(self) -> float:
        return min(get_component(c).nbp_low_K for c in self.components)

    @property
    def nbp_high_K(self) -> float:
        return max(get_component(c).nbp_high_K for c in self.components)


def effective_cutpoint_temperature_K(furnace_outlet_temperature_K: float, column_pressure_Pa: float) -> float:
    """Correct the furnace outlet temperature for column pressure, using a
    documented log-pressure sensitivity (see module docstring)."""
    import math

    if column_pressure_Pa <= 0:
        raise NonPhysicalStateError("column pressure must be > 0 Pa")
    shift = PRESSURE_CUTPOINT_SENSITIVITY_K * math.log(column_pressure_Pa / REFERENCE_PRESSURE_PA)
    return furnace_outlet_temperature_K - shift


def cutpoint_split(
    feed: Fluid,
    cuts: list[ProductCut],
    furnace_outlet_temperature_K: float,
    column_pressure_Pa: float,
    reflux_ratio: float,
    bottoms_cut: ProductCut,
) -> dict[str, dict[str, float]]:
    """Split ``feed`` composition across ``cuts`` + ``bottoms_cut``.

    Returns ``{cut_name: {component: mass_fraction_of_TOTAL_FEED}}``. The
    caller is responsible for renormalising each cut's own composition
    and multiplying by the feed mass flow.
    """
    if reflux_ratio <= 0:
        raise NonPhysicalStateError("reflux_ratio must be > 0")

    t_cut = effective_cutpoint_temperature_K(furnace_outlet_temperature_K, column_pressure_Pa)

    draws: dict[str, dict[str, float]] = {cut.name: {} for cut in cuts}
    draws[bottoms_cut.name] = {}

    for comp_name, feed_fraction in feed.composition.items():
        comp = get_component(comp_name)
        recovered_fraction = _clip((t_cut - comp.nbp_low_K) / max(comp.nbp_high_K - comp.nbp_low_K, 1.0e-6))
        recovered_mass = feed_fraction * recovered_fraction
        bottoms_mass = feed_fraction - recovered_mass

        target_cut = _cut_for_component(cuts, comp_name)
        if target_cut is not None:
            draws[target_cut.name][comp_name] = draws[target_cut.name].get(comp_name, 0.0) + recovered_mass
        else:
            # Component's whole boiling range is heavier than any named
            # distillate cut -> all of its recovered fraction also reports
            # to bottoms (this only happens if cuts do not cover the
            # component's boiling range, e.g. residue-range components).
            bottoms_mass = feed_fraction
        draws[bottoms_cut.name][comp_name] = draws[bottoms_cut.name].get(comp_name, 0.0) + bottoms_mass

    overlap = OVERLAP_CONSTANT / (1.0 + reflux_ratio)
    ordered = sorted(cuts, key=lambda c: c.nbp_low_K)
    for lighter, heavier in zip(ordered, ordered[1:]):
        _exchange_overlap(draws, lighter.name, heavier.name, overlap)

    return draws


def _clip(x: float) -> float:
    return min(max(x, 0.0), 1.0)


def _cut_for_component(cuts: list[ProductCut], component_name: str) -> ProductCut | None:
    for cut in cuts:
        if component_name in cut.components:
            return cut
    return None


def _exchange_overlap(draws: dict[str, dict[str, float]], lighter_name: str, heavier_name: str, overlap: float) -> None:
    """Move a symmetric small mass fraction between two adjacent cuts to
    represent imperfect fractionation; higher reflux (smaller ``overlap``)
    keeps this exchange small."""
    lighter, heavier = draws[lighter_name], draws[heavier_name]
    for comp_name, mass in list(lighter.items()):
        moved = mass * overlap
        lighter[comp_name] -= moved
        heavier[comp_name] = heavier.get(comp_name, 0.0) + moved
    for comp_name, mass in list(heavier.items()):
        moved = mass * overlap
        heavier[comp_name] -= moved
        lighter[comp_name] = lighter.get(comp_name, 0.0) + moved


def draws_to_fluids(draws: dict[str, dict[str, float]], name_prefix: str = "") -> dict[str, tuple[Fluid, float]]:
    """Normalise each cut's mass distribution into a :class:`Fluid` plus the
    cut's mass fraction of the total feed."""
    result: dict[str, tuple[Fluid, float]] = {}
    for cut_name, comp_masses in draws.items():
        total = sum(comp_masses.values())
        if total <= 1.0e-12:
            continue
        composition = {c: m / total for c, m in comp_masses.items() if m > 1.0e-12}
        result[cut_name] = (Fluid(name=f"{name_prefix}{cut_name}", composition=composition), total)
    return result
