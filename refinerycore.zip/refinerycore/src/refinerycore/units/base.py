"""``ProcessUnit`` base class: a named, composite assembly of equipment.

A process unit (CDU, VDU, FCC, ...) owns a set of :class:`~refinerycore.equipment.base.Equipment`
instances, wires streams between them, and exposes its own aggregate
material/energy balance built from the streams crossing its boundary.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from refinerycore.core.enums import EquipmentStatus, FidelityLevel
from refinerycore.streams import Stream
from refinerycore.thermodynamics.balances import EnergyBalance, MaterialBalance


@dataclass
class ProcessUnit:
    """Base class for a composite process unit."""

    id: str
    name: str
    description: str = ""
    status: EquipmentStatus = EquipmentStatus.RUNNING
    fidelity: FidelityLevel = FidelityLevel.LEVEL_1_ENGINEERING_APPROXIMATION
    feed_streams: dict[str, Stream] = field(default_factory=dict)
    product_streams: dict[str, Stream] = field(default_factory=dict)
    _last_result: dict[str, Any] = field(default_factory=dict, repr=False)

    def connect_feed(self, port: str, stream: Stream) -> None:
        self.feed_streams[port] = stream

    def run(self) -> dict[str, Any]:
        self._last_result = self.calculate()
        return self._last_result

    def calculate(self) -> dict[str, Any]:  # pragma: no cover - overridden by subclasses
        raise NotImplementedError

    @property
    def last_result(self) -> dict[str, Any]:
        return dict(self._last_result)

    def material_balance(self) -> MaterialBalance:
        mb = MaterialBalance(unit_id=self.id)
        for port, stream in self.feed_streams.items():
            mb.add_inflow(port, stream.mass_flow_kg_s, stream.fluid.composition)
        for port, stream in self.product_streams.items():
            mb.add_outflow(port, stream.mass_flow_kg_s, stream.fluid.composition)
        return mb

    def energy_balance(self, heat_in_w: float = 0.0, work_in_w: float = 0.0, losses_w: float = 0.0) -> EnergyBalance:
        eb = EnergyBalance(unit_id=self.id)
        eb.enthalpy_in_w = sum(s.calculate_energy_flow() for s in self.feed_streams.values())
        eb.enthalpy_out_w = sum(s.calculate_energy_flow() for s in self.product_streams.values())
        eb.heat_in_w = heat_in_w
        eb.work_in_w = work_in_w
        eb.losses_w = losses_w
        return eb

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "type": type(self).__name__,
            "status": self.status.value,
            "fidelity": self.fidelity.name,
            "feeds": {k: v.report() for k, v in self.feed_streams.items()},
            "products": {k: v.report() for k, v in self.product_streams.items()},
            "last_result": dict(self._last_result),
        }
