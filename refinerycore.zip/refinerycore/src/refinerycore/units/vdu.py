"""Vacuum Distillation Unit (spec section 23).

Takes the CDU atmospheric residue and further separates it, under
vacuum, into vacuum gas oil (VGO) and vacuum residue, using the same
shortcut cutpoint model as the CDU (see :mod:`refinerycore.units.distillation`).
Operating at low absolute pressure lowers the effective boiling points,
recovering additional gas oil that the atmospheric column could not
without cracking the residue.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from refinerycore.equipment.furnace import Furnace
from refinerycore.fluids.properties import PropertyProvider
from refinerycore.streams import Stream
from refinerycore.units.base import ProcessUnit
from refinerycore.units.distillation import ProductCut, cutpoint_split, draws_to_fluids

VDU_PRODUCT_CUTS: list[ProductCut] = [ProductCut("vacuum_gas_oil", ("heavy_gas_oil", "vacuum_gas_oil"))]
VDU_BOTTOMS_CUT = ProductCut("vacuum_residue", ("residue",))


@dataclass
class VDU(ProcessUnit):
    vacuum_pressure_Pa: float = 6_000.0  # ~45 mmHg, typical VDU flash-zone vacuum
    furnace_outlet_temperature_K: float = 690.0
    reflux_ratio: float = 0.5  # vacuum columns typically run near-total-condenser wash only
    provider: PropertyProvider = None  # type: ignore[assignment]
    furnace: Furnace = field(default_factory=lambda: Furnace(id="F-200", name="VDU Furnace"))

    def calculate(self) -> dict[str, Any]:
        residue_feed: Stream = self.feed_streams["residue"]

        self.furnace.target_outlet_temperature_K = self.furnace_outlet_temperature_K
        self.furnace.connect_input("feed", residue_feed)
        furnace_result = self.furnace.run()
        furnace_outlet = self.furnace.outputs["outlet"]

        draws = cutpoint_split(
            feed=furnace_outlet.fluid,
            cuts=VDU_PRODUCT_CUTS,
            furnace_outlet_temperature_K=self.furnace_outlet_temperature_K,
            column_pressure_Pa=self.vacuum_pressure_Pa,
            reflux_ratio=self.reflux_ratio,
            bottoms_cut=VDU_BOTTOMS_CUT,
        )
        cut_fluids = draws_to_fluids(draws, name_prefix=f"{self.id}-")
        total_feed_mass_flow = furnace_outlet.mass_flow_kg_s

        self.product_streams.clear()
        for cut_name, (fluid, mass_fraction_of_feed) in cut_fluids.items():
            mass_flow = mass_fraction_of_feed * total_feed_mass_flow
            self.product_streams[cut_name] = Stream(
                id=f"{self.id}-{cut_name}",
                name=f"{self.name} {cut_name}",
                fluid=fluid,
                mass_flow_kg_s=mass_flow,
                pressure_Pa=self.vacuum_pressure_Pa,
                temperature_K=self.furnace_outlet_temperature_K,
                provider=self.provider,
                source=self.id,
            )

        mb = self.material_balance()
        eb = self.energy_balance(heat_in_w=furnace_result["process_duty_w"])

        return {
            "furnace": furnace_result,
            "vacuum_pressure_Pa": self.vacuum_pressure_Pa,
            "product_yields_kg_s": {name: s.mass_flow_kg_s for name, s in self.product_streams.items()},
            "material_balance": {
                "mass_in_kg_s": mb.total_mass_in_kg_s,
                "mass_out_kg_s": mb.total_mass_out_kg_s,
                "absolute_residual_kg_s": mb.absolute_residual_kg_s,
            },
            "energy_balance": {"residual_w": eb.residual_w},
        }
