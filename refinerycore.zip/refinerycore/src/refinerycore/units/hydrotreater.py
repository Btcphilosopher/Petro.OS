"""Hydrotreater -- conceptual desulfurisation model (spec section 26).

FIDELITY NOTICE: Level 0 conceptual reaction model. Sulfur conversion is
a saturating function of temperature and (implicitly) catalyst/space
velocity via a single "severity" parameter; hydrogen consumption and H2S
production are derived from a simplified sulfur mass balance
(HDS: R-SH + H2 -> R-H + H2S), not detailed reaction kinetics.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

from refinerycore.fluids.fluid import Fluid
from refinerycore.fluids.properties import PropertyProvider
from refinerycore.streams import Stream
from refinerycore.units.base import ProcessUnit

#: Molar mass ratio for H2 uptake per unit sulfur removed in a simplified
#: R-SH + H2 -> R-H + H2S stoichiometry (H2 MW=2, S MW=32, so 2/32 = 0.0625
#: kg H2 per kg S removed at minimum; real units consume substantially more
#: H2 to side reactions (HDN, aromatics saturation), so a documented
#: multiplier is applied).
_H2_PER_S_STOICHIOMETRIC = 2.0 / 32.0
H2_STOICHIOMETRY_MULTIPLIER = 4.0  # accounts for HDN/aromatics side consumption, documented estimate


@dataclass
class Hydrotreater(ProcessUnit):
    reactor_temperature_K: float = 623.0  # ~350 degC
    reactor_pressure_Pa: float = 5.0e6  # ~50 bar
    feed_sulfur_wt_pct: float = 1.2
    target_product_sulfur_wt_pct: float = 0.001  # ULSD-grade target, 10 wppm
    max_sulfur_conversion: float = 0.999
    severity_temperature_sensitivity_K: float = 50.0
    provider: PropertyProvider = None  # type: ignore[assignment]

    def sulfur_conversion(self) -> float:
        severity = max(self.reactor_temperature_K - 573.0, 0.0) / self.severity_temperature_sensitivity_K
        return min(1.0 - math.exp(-severity), self.max_sulfur_conversion)

    def calculate(self) -> dict[str, Any]:
        feed: Stream = self.feed_streams["feed"]
        conv = self.sulfur_conversion()

        sulfur_in_kg_s = feed.mass_flow_kg_s * self.feed_sulfur_wt_pct / 100.0
        sulfur_removed_kg_s = sulfur_in_kg_s * conv
        product_sulfur_kg_s = sulfur_in_kg_s - sulfur_removed_kg_s
        product_sulfur_wt_pct = 100.0 * product_sulfur_kg_s / feed.mass_flow_kg_s if feed.mass_flow_kg_s > 0 else 0.0

        h2_consumption_kg_s = sulfur_removed_kg_s * _H2_PER_S_STOICHIOMETRIC * H2_STOICHIOMETRY_MULTIPLIER
        h2s_production_kg_s = sulfur_removed_kg_s * (34.0 / 32.0)  # H2S MW=34, S MW=32

        treated = Stream(
            id=f"{self.id}-treated",
            name=f"{self.name} treated product",
            fluid=feed.fluid,
            mass_flow_kg_s=feed.mass_flow_kg_s - h2s_production_kg_s,
            pressure_Pa=self.reactor_pressure_Pa,
            temperature_K=self.reactor_temperature_K,
            provider=self.provider,
            source=self.id,
        )
        off_gas = Stream(
            id=f"{self.id}-h2s",
            name=f"{self.name} H2S off-gas",
            fluid=Fluid.pure("light_ends"),
            mass_flow_kg_s=h2s_production_kg_s,
            pressure_Pa=self.reactor_pressure_Pa,
            temperature_K=self.reactor_temperature_K,
            provider=self.provider,
            source=self.id,
        )
        self.product_streams = {"treated_product": treated, "h2s_off_gas": off_gas}

        return {
            "sulfur_conversion": conv,
            "product_sulfur_wt_pct": product_sulfur_wt_pct,
            "meets_target": product_sulfur_wt_pct <= self.target_product_sulfur_wt_pct,
            "hydrogen_consumption_kg_s": h2_consumption_kg_s,
            "h2s_production_kg_s": h2s_production_kg_s,
        }
