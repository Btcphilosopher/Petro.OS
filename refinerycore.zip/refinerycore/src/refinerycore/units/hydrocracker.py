"""Hydrocracker -- conceptual yield model (spec section 25).

FIDELITY NOTICE: Level 0 conceptual yield model. Conversion is a
saturating function of temperature, pressure and space velocity;
hydrogen consumption is estimated from a fixed, documented specific
consumption rate (kg H2 per kg feed converted), representative of VGO
hydrocracking but NOT unit- or catalyst-specific.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

from refinerycore.core.errors import NonPhysicalStateError
from refinerycore.fluids.fluid import Fluid
from refinerycore.fluids.properties import PropertyProvider
from refinerycore.streams import Stream
from refinerycore.units.base import ProcessUnit

#: Selectivity of CONVERTED feed to light products. Must sum to 1.0.
DEFAULT_SELECTIVITY: dict[str, float] = {
    "light_gases": 0.05,
    "naphtha": 0.25,
    "jet": 0.30,
    "diesel": 0.40,
}

#: Representative hydrogen consumption, kg H2 per kg of feed converted
#: (typical VGO hydrocracking range is 1.5-3.0 wt% on feed; documented
#: mid-range estimate).
SPECIFIC_H2_CONSUMPTION_KG_PER_KG_CONVERTED = 0.025

#: Representative reaction heat release, J per kg of feed converted
#: (hydrocracking is exothermic; typical order-of-magnitude estimate).
HEAT_RELEASE_J_PER_KG_CONVERTED = 2.3e6


@dataclass
class Hydrocracker(ProcessUnit):
    reactor_temperature_K: float = 673.0  # ~400 degC
    reactor_pressure_Pa: float = 1.4e7  # ~140 bar, typical high-pressure hydrocracker
    liquid_hourly_space_velocity_per_h: float = 1.2
    max_conversion: float = 0.92
    selectivity: dict[str, float] = None  # type: ignore[assignment]
    provider: PropertyProvider = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.selectivity is None:
            self.selectivity = dict(DEFAULT_SELECTIVITY)
        total = sum(self.selectivity.values())
        if abs(total - 1.0) > 1.0e-6:
            raise NonPhysicalStateError(f"Hydrocracker selectivity must sum to 1.0, got {total}")

    def conversion(self) -> float:
        temp_term = 1.0 - math.exp(-(self.reactor_temperature_K - 600.0) / 40.0) if self.reactor_temperature_K > 600.0 else 0.0
        pressure_term = min(self.reactor_pressure_Pa / 1.5e7, 1.0)
        lhsv_term = 1.0 / (1.0 + self.liquid_hourly_space_velocity_per_h / 2.0)
        return min(max(temp_term * pressure_term * lhsv_term, 0.0), 1.0) * self.max_conversion

    def calculate(self) -> dict[str, Any]:
        feed: Stream = self.feed_streams["vgo"]
        conv = self.conversion()
        converted_mass = feed.mass_flow_kg_s * conv
        unconverted_mass = feed.mass_flow_kg_s - converted_mass
        h2_consumption_kg_s = converted_mass * SPECIFIC_H2_CONSUMPTION_KG_PER_KG_CONVERTED
        heat_release_w = converted_mass * HEAT_RELEASE_J_PER_KG_CONVERTED

        self.product_streams.clear()
        for product, fraction in self.selectivity.items():
            self.product_streams[product] = Stream(
                id=f"{self.id}-{product}",
                name=f"{self.name} {product}",
                fluid=Fluid.pure(_PRODUCT_TO_COMPONENT[product]),
                mass_flow_kg_s=converted_mass * fraction,
                pressure_Pa=self.reactor_pressure_Pa,
                temperature_K=self.reactor_temperature_K,
                provider=self.provider,
                source=self.id,
            )
        self.product_streams["unconverted_oil"] = Stream(
            id=f"{self.id}-unconverted_oil",
            name=f"{self.name} unconverted oil",
            fluid=feed.fluid,
            mass_flow_kg_s=unconverted_mass,
            pressure_Pa=self.reactor_pressure_Pa,
            temperature_K=self.reactor_temperature_K,
            provider=self.provider,
            source=self.id,
        )

        return {
            "conversion": conv,
            "hydrogen_consumption_kg_s": h2_consumption_kg_s,
            "heat_release_w": heat_release_w,
            "product_yields_kg_s": {k: s.mass_flow_kg_s for k, s in self.product_streams.items()},
        }


_PRODUCT_TO_COMPONENT = {
    "light_gases": "light_ends",
    "naphtha": "light_naphtha",
    "jet": "kerosene",
    "diesel": "diesel",
}
