"""Fluid Catalytic Cracking unit -- conceptual yield model (spec section 24).

FIDELITY NOTICE: this is a Level 0 conceptual yield model. Conversion is
estimated from catalyst-to-oil ratio and reactor temperature via a
simple saturating correlation; once conversion is known, the converted
feed is split into gas/LPG/gasoline/LCO/slurry/coke using FIXED,
DOCUMENTED selectivity fractions representative of a typical VGO FCC
unit. This is NOT a licensed FCC kinetic/yield simulator (e.g. no
riser kinetics, no catalyst deactivation model).
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

from refinerycore.core.errors import NonPhysicalStateError
from refinerycore.fluids.fluid import Fluid
from refinerycore.fluids.properties import PropertyProvider
from refinerycore.streams import Stream
from refinerycore.units.base import ProcessUnit

#: Representative selectivity of CONVERTED feed to each product, at the
#: reference cat/oil and temperature used to calibrate this conceptual
#: model. Must sum to 1.0. Documented, override via `selectivity`.
DEFAULT_SELECTIVITY: dict[str, float] = {
    "dry_gas": 0.06,
    "lpg": 0.16,
    "gasoline": 0.50,
    "lco": 0.16,
    "slurry": 0.07,
    "coke": 0.05,
}


@dataclass
class FCC(ProcessUnit):
    reactor_temperature_K: float = 793.0  # ~520 degC, typical FCC riser outlet
    regenerator_temperature_K: float = 973.0  # ~700 degC, typical regenerator bed
    catalyst_to_oil_ratio: float = 7.0
    max_conversion: float = 0.85  # asymptotic conversion at high severity
    conversion_temperature_sensitivity_K: float = 60.0  # documented shape constant
    selectivity: dict[str, float] = None  # type: ignore[assignment]
    provider: PropertyProvider = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.selectivity is None:
            self.selectivity = dict(DEFAULT_SELECTIVITY)
        total = sum(self.selectivity.values())
        if abs(total - 1.0) > 1.0e-6:
            raise NonPhysicalStateError(f"FCC selectivity must sum to 1.0, got {total}")

    def conversion(self) -> float:
        """Saturating correlation: conversion rises with cat/oil ratio and
        reactor severity, asymptoting to ``max_conversion``. A Level 0
        conceptual shape (logistic-like), not a fitted kinetic model."""
        severity = (self.reactor_temperature_K - 700.0) / self.conversion_temperature_sensitivity_K
        cat_oil_term = self.catalyst_to_oil_ratio / (self.catalyst_to_oil_ratio + 5.0)
        raw = cat_oil_term * (1.0 - math.exp(-max(severity, 0.0)))
        return min(max(raw, 0.0), 1.0) * self.max_conversion

    def calculate(self) -> dict[str, Any]:
        feed: Stream = self.feed_streams["vgo"]
        conv = self.conversion()
        converted_mass = feed.mass_flow_kg_s * conv
        unconverted_mass = feed.mass_flow_kg_s - converted_mass

        self.product_streams.clear()
        for product, fraction in self.selectivity.items():
            mass_flow = converted_mass * fraction
            fluid = Fluid.pure(_PRODUCT_TO_COMPONENT[product])
            self.product_streams[product] = Stream(
                id=f"{self.id}-{product}",
                name=f"{self.name} {product}",
                fluid=fluid,
                mass_flow_kg_s=mass_flow,
                pressure_Pa=feed.pressure_Pa,
                temperature_K=self.reactor_temperature_K,
                provider=self.provider,
                source=self.id,
            )
        self.product_streams["unconverted_oil"] = Stream(
            id=f"{self.id}-unconverted_oil",
            name=f"{self.name} unconverted oil",
            fluid=feed.fluid,
            mass_flow_kg_s=unconverted_mass,
            pressure_Pa=feed.pressure_Pa,
            temperature_K=self.reactor_temperature_K,
            provider=self.provider,
            source=self.id,
        )

        return {
            "conversion": conv,
            "converted_mass_flow_kg_s": converted_mass,
            "unconverted_mass_flow_kg_s": unconverted_mass,
            "coke_mass_flow_kg_s": self.product_streams["coke"].mass_flow_kg_s,
            "product_yields_kg_s": {k: s.mass_flow_kg_s for k, s in self.product_streams.items()},
        }


_PRODUCT_TO_COMPONENT = {
    "dry_gas": "light_ends",
    "lpg": "lpg",
    "gasoline": "light_naphtha",
    "lco": "diesel",
    "slurry": "heavy_gas_oil",
    "coke": "residue",
}
