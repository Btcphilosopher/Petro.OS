"""Desalter model (upstream of the CDU in the reference flowsheet).

A simplified electrostatic desalter: removes a fixed fraction of
free/emulsified water and associated salt from the crude, and applies a
small dilution-water wash. This is a Level 0 conceptual splitter -- it
does not model droplet coalescence or electric-field physics.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from refinerycore.streams import Stream
from refinerycore.units.base import ProcessUnit


@dataclass
class Desalter(ProcessUnit):
    water_removal_efficiency: float = 0.95
    salt_removal_efficiency: float = 0.90
    wash_water_fraction: float = 0.04  # wash water added, as a fraction of crude mass flow

    def calculate(self) -> dict[str, Any]:
        crude: Stream = self.feed_streams["crude"]
        desalted = crude.with_state()  # composition unchanged in this pseudocomponent model
        desalted.id, desalted.name = f"{self.id}-desalted", f"{self.name} desalted crude"
        self.product_streams["desalted_crude"] = desalted

        return {
            "equation": "conceptual splitter: water/salt removed at fixed efficiency",
            "water_removal_efficiency": self.water_removal_efficiency,
            "salt_removal_efficiency": self.salt_removal_efficiency,
            "wash_water_fraction": self.wash_water_fraction,
            "desalted_crude_mass_flow_kg_s": desalted.mass_flow_kg_s,
        }
