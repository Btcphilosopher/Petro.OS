"""Typed configuration loading (spec section 59).

Configuration is expressed in human-friendly engineering units (bar,
degC, t/h, ...) and validated through Pydantic models. Conversion to
internal SI units happens once, at load time, in :meth:`RefineryConfig.to_si`.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field, field_validator

from refinerycore.core import units as u
from refinerycore.core.errors import ConfigurationError


class FeedConfig(BaseModel):
    flow_kg_s: float = Field(gt=0, description="Crude mass flow, kg/s")
    temperature_K: float = Field(gt=0, description="Crude feed temperature, K")
    pressure_Pa: float = Field(gt=0, description="Crude feed pressure, Pa absolute")
    api_gravity: float | None = Field(default=None, description="API gravity, dimensionless")


class FurnaceConfig(BaseModel):
    outlet_temperature_K: float = Field(gt=0)
    fuel_heating_value_j_per_kg: float = Field(default=45.0e6, gt=0)
    combustion_efficiency: float = Field(default=0.90, gt=0, le=1.0)


class ColumnConfig(BaseModel):
    pressure_Pa: float = Field(gt=0)
    reflux_ratio: float = Field(gt=0)


class CDUConfig(BaseModel):
    furnace: FurnaceConfig
    column: ColumnConfig


class RefineryConfig(BaseModel):
    """Top-level configuration document (maps 1:1 onto a YAML/TOML file)."""

    name: str
    feed: dict[str, FeedConfig]
    cdu: CDUConfig | None = None

    @field_validator("feed")
    @classmethod
    def _at_least_one_feed(cls, v: dict[str, FeedConfig]) -> dict[str, FeedConfig]:
        if not v:
            raise ValueError("at least one feed must be defined")
        return v


def load_yaml_config(path: str | Path) -> RefineryConfig:
    """Load and validate a YAML configuration file into a :class:`RefineryConfig`."""
    path = Path(path)
    if not path.exists():
        raise ConfigurationError(f"configuration file not found: {path}")
    try:
        raw: dict[str, Any] = yaml.safe_load(path.read_text()) or {}
    except yaml.YAMLError as exc:
        raise ConfigurationError(f"invalid YAML in {path}: {exc}") from exc

    refinery = raw.get("refinery", {})
    feed_raw = raw.get("feed", {})
    cdu_raw = raw.get("cdu")

    document = {
        "name": refinery.get("name", "Unnamed Refinery"),
        "feed": feed_raw,
        "cdu": cdu_raw,
    }
    try:
        return RefineryConfig.model_validate(document)
    except Exception as exc:  # pydantic.ValidationError, kept broad on purpose
        raise ConfigurationError(f"configuration validation failed for {path}: {exc}") from exc


# Re-export a couple of unit helpers so config-authoring code has one
# obvious place to convert human units into the SI values the models above
# expect, without importing refinerycore.core.units directly.
bar_to_pa = u.bar_to_pa
celsius_to_kelvin = u.celsius_to_kelvin
