"""Strict unit policy (project spec, section 3).

Internally REFINERYCORE.OS uses SI units EXCLUSIVELY:

=============== =========
Quantity        SI unit
=============== =========
Pressure        Pa (absolute, unless a name ends in ``_g`` for gauge)
Temperature     K
Mass flow       kg/s
Volume flow     m^3/s
Density         kg/m^3
Energy          J
Power           W
Enthalpy        J/kg
Entropy         J/(kg K)
Viscosity       Pa.s
Length          m
Diameter        m
Velocity        m/s
=============== =========

Nothing in the physics layer (``fluids``, ``thermodynamics``, ``equipment``,
``units``, ``networks``, ``solver``) may hold a non-SI quantity. All
conversions to/from human-friendly engineering units happen at the
boundary (CLI, configuration loading, reporting) via the functions below.

Every conversion function is named ``<from>_to_<to>`` and is a pure,
dimensionally documented function -- never an implicit multiply buried in
unrelated code.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Pressure
# ---------------------------------------------------------------------------
ATMOSPHERIC_PRESSURE_PA = 101_325.0  #: standard atmosphere, Pa (absolute)


def bar_to_pa(value_bar: float) -> float:
    return value_bar * 1.0e5


def pa_to_bar(value_pa: float) -> float:
    return value_pa / 1.0e5


def kpa_to_pa(value_kpa: float) -> float:
    return value_kpa * 1.0e3


def pa_to_kpa(value_pa: float) -> float:
    return value_pa / 1.0e3


def mpa_to_pa(value_mpa: float) -> float:
    return value_mpa * 1.0e6


def pa_to_mpa(value_pa: float) -> float:
    return value_pa / 1.0e6


def psi_to_pa(value_psi: float) -> float:
    return value_psi * 6_894.757_293_168


def pa_to_psi(value_pa: float) -> float:
    return value_pa / 6_894.757_293_168


def barg_to_pa(value_barg: float) -> float:
    """Gauge bar -> absolute Pa. Never mix gauge and absolute silently."""
    return bar_to_pa(value_barg) + ATMOSPHERIC_PRESSURE_PA


def pa_to_barg(value_pa: float) -> float:
    return pa_to_bar(value_pa - ATMOSPHERIC_PRESSURE_PA)


# ---------------------------------------------------------------------------
# Temperature
# ---------------------------------------------------------------------------
def celsius_to_kelvin(value_c: float) -> float:
    return value_c + 273.15


def kelvin_to_celsius(value_k: float) -> float:
    return value_k - 273.15


def fahrenheit_to_kelvin(value_f: float) -> float:
    return (value_f - 32.0) * 5.0 / 9.0 + 273.15


def kelvin_to_fahrenheit(value_k: float) -> float:
    return (value_k - 273.15) * 9.0 / 5.0 + 32.0


# ---------------------------------------------------------------------------
# Mass flow
# ---------------------------------------------------------------------------
def kg_per_h_to_kg_per_s(value: float) -> float:
    return value / 3_600.0


def kg_per_s_to_kg_per_h(value: float) -> float:
    return value * 3_600.0


def t_per_h_to_kg_per_s(value: float) -> float:
    return value * 1_000.0 / 3_600.0


def kg_per_s_to_t_per_h(value: float) -> float:
    return value * 3_600.0 / 1_000.0


# ---------------------------------------------------------------------------
# Volume flow (bbl/day, m3/day are volumetric -- converting to mass flow
# requires a density and is deliberately NOT provided here; see
# refinerycore.fluids for density-aware conversions).
# ---------------------------------------------------------------------------
BBL_TO_M3 = 0.158_987_294_928  #: 1 barrel of oil (42 US gal) in m^3


def bbl_per_day_to_m3_per_s(value_bbl_day: float) -> float:
    return value_bbl_day * BBL_TO_M3 / 86_400.0


def m3_per_s_to_bbl_per_day(value_m3_s: float) -> float:
    return value_m3_s * 86_400.0 / BBL_TO_M3


def m3_per_day_to_m3_per_s(value: float) -> float:
    return value / 86_400.0


def m3_per_s_to_m3_per_day(value: float) -> float:
    return value * 86_400.0


# ---------------------------------------------------------------------------
# Power / energy
# ---------------------------------------------------------------------------
def kw_to_w(value_kw: float) -> float:
    return value_kw * 1.0e3


def w_to_kw(value_w: float) -> float:
    return value_w / 1.0e3


def mw_to_w(value_mw: float) -> float:
    return value_mw * 1.0e6


def w_to_mw(value_w: float) -> float:
    return value_w / 1.0e6


def gw_to_w(value_gw: float) -> float:
    return value_gw * 1.0e9


def w_to_gw(value_w: float) -> float:
    return value_w / 1.0e9


def kwh_to_j(value_kwh: float) -> float:
    return value_kwh * 3.6e6


def j_to_kwh(value_j: float) -> float:
    return value_j / 3.6e6


def mj_per_kg_to_j_per_kg(value: float) -> float:
    return value * 1.0e6


def j_per_kg_to_mj_per_kg(value: float) -> float:
    return value / 1.0e6


BTU_PER_LB_TO_J_PER_KG = 2_326.0


def btu_per_lb_to_j_per_kg(value: float) -> float:
    return value * BTU_PER_LB_TO_J_PER_KG


def j_per_kg_to_btu_per_lb(value: float) -> float:
    return value / BTU_PER_LB_TO_J_PER_KG


# ---------------------------------------------------------------------------
# Dimensional-check helper (spec section 65: kg/s * J/kg = J/s = W)
# ---------------------------------------------------------------------------
def energy_flow_w(mass_flow_kg_s: float, specific_enthalpy_j_kg: float) -> float:
    """kg/s * J/kg = J/s = W. A tiny helper kept here so the identity is
    documented and tested in one obvious place (see tests/test_units.py)."""
    return mass_flow_kg_s * specific_enthalpy_j_kg
