"""Shared enumerations."""

from __future__ import annotations

from enum import Enum


class FidelityLevel(int, Enum):
    """Declared model fidelity (spec section 55). REFINERYCORE.OS
    primarily implements LEVEL_0 and LEVEL_1, with a handful of LEVEL_2
    models (the equilibrium-stage distillation column). Nothing in this
    repository is LEVEL_3/LEVEL_4 -- it is not validated against, or
    certified for, any specific physical plant.
    """

    LEVEL_0_CONCEPTUAL = 0
    LEVEL_1_ENGINEERING_APPROXIMATION = 1
    LEVEL_2_DETAILED_PROCESS_MODEL = 2
    LEVEL_3_VALIDATED_PLANT_SPECIFIC = 3
    LEVEL_4_HIGH_FIDELITY_SPECIALIST = 4


class Phase(str, Enum):
    LIQUID = "liquid"
    VAPOUR = "vapour"
    TWO_PHASE = "two_phase"
    SOLID = "solid"
    UNKNOWN = "unknown"


class EquipmentStatus(str, Enum):
    OFFLINE = "offline"
    STARTING = "starting"
    RUNNING = "running"
    DEGRADED = "degraded"
    TRIPPED = "tripped"
    MAINTENANCE = "maintenance"


class FoulingLevel(str, Enum):
    CLEAN = "clean"
    NORMAL = "normal"
    FOULED = "fouled"
    SEVERELY_FOULED = "severely_fouled"


class AlarmSeverity(str, Enum):
    LOW = "low"
    LOW_LOW = "low_low"
    HIGH = "high"
    HIGH_HIGH = "high_high"
    RATE_OF_CHANGE = "rate_of_change"
    DEVIATION = "deviation"
    HEALTH = "health"


class ConvergenceStatus(str, Enum):
    CONVERGED = "converged"
    NOT_CONVERGED = "not_converged"
    FAILED = "failed"
    NOT_RUN = "not_run"


class ValveCharacteristic(str, Enum):
    LINEAR = "linear"
    EQUAL_PERCENTAGE = "equal_percentage"
    QUICK_OPENING = "quick_opening"


class SteamLevel(str, Enum):
    HP = "hp"
    MP = "mp"
    LP = "lp"
    CONDENSATE = "condensate"
