"""Identifier utilities.

Every engineering object in REFINERYCORE.OS carries a stable, human
readable ``id``. IDs are plain strings (e.g. ``"P-101"``, ``"HX-101"``)
so they can be used directly as tags in reports, plots and the process
graph. :func:`new_id` is provided for objects that need a generated,
collision-resistant identifier (e.g. simulation runs, snapshots).
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone


def new_id(prefix: str = "id") -> str:
    """Generate a short, collision-resistant identifier.

    Not an engineering tag -- use for simulation runs, events, snapshots.
    """
    return f"{prefix}-{uuid.uuid4().hex[:10]}"


def utc_now_iso() -> str:
    """Return the current UTC time as an ISO-8601 string (for reproducibility records)."""
    return datetime.now(timezone.utc).isoformat()
