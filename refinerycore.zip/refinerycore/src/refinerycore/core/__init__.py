"""Core cross-cutting primitives: ids, units, enums, events, errors, configuration."""
