"""Engineering exceptions.

REFINERYCORE.OS never silently replaces NaN/Inf with zero and never
silently forces a balance to close. Numerically or physically invalid
states raise one of these typed exceptions so callers (and tests) can
distinguish *why* a calculation failed.
"""

from __future__ import annotations


class RefineryCoreError(Exception):
    """Base class for all REFINERYCORE.OS engineering exceptions."""


class UnitPolicyError(RefineryCoreError):
    """Raised when a value violates the strict SI unit policy."""


class NonPhysicalStateError(RefineryCoreError):
    """Raised for negative absolute pressure/temperature, density <= 0,
    a mass fraction outside [0, 1], NaN/Inf, etc."""


class MaterialBalanceError(RefineryCoreError):
    """Raised when a material balance residual exceeds tolerance, or a
    balance is structurally invalid (fractions not summing to 1, mass
    creation/destruction, negative flow)."""


class EnergyBalanceError(RefineryCoreError):
    """Raised when an energy balance residual exceeds tolerance."""


class ConvergenceError(RefineryCoreError):
    """Raised when a solver fails to converge and the caller has not
    opted in to receiving the unconverged state."""


class ConfigurationError(RefineryCoreError):
    """Raised when a configuration file fails validation."""


class ProcessGraphError(RefineryCoreError):
    """Raised for disconnected equipment, islands, or cycles where a
    cycle is not physically permitted (e.g. reflux loops must be marked)."""


class CorrelationRangeWarning(UserWarning):
    """Warned (not raised) when a correlation is evaluated outside its
    documented applicability range (spec section 54)."""
