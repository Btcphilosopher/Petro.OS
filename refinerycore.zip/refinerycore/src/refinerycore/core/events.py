"""Event bus (spec section 51).

Decouples the engineering engine from anything that observes it (API,
UI, logging, telemetry, a future 3D digital twin front-end). The engine
publishes events; it never imports or depends on a subscriber.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from refinerycore.core.ids import utc_now_iso


@dataclass(frozen=True)
class Event:
    """A single, immutable event record."""

    kind: str
    source: str
    payload: dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(default_factory=utc_now_iso)


# Canonical event kinds (spec section 51). Using plain strings (not an
# Enum) keeps the bus open to new event kinds without a core-package
# release, while these constants give call sites a typo-proof name.
class EventKind:
    EQUIPMENT_STATE_CHANGED = "EquipmentStateChanged"
    STREAM_CHANGED = "StreamChanged"
    SENSOR_UPDATED = "SensorUpdated"
    ALARM_RAISED = "AlarmRaised"
    FAULT_INJECTED = "FaultInjected"
    MAINTENANCE_PERFORMED = "MaintenancePerformed"
    SIMULATION_STEP = "SimulationStep"
    SIMULATION_STARTED = "SimulationStarted"
    SIMULATION_COMPLETED = "SimulationCompleted"
    SOLVER_CONVERGED = "SolverConverged"
    SOLVER_FAILED = "SolverFailed"


Subscriber = Callable[[Event], None]


class EventBus:
    """A minimal synchronous publish/subscribe bus.

    Subscribers are called synchronously, in registration order, inside
    :meth:`publish`. An exception in one subscriber does not prevent the
    others from running -- it is logged via the standard ``logging``
    module and re-raised only after all subscribers have been notified,
    so a broken UI subscriber can never corrupt the physics.
    """

    def __init__(self) -> None:
        self._subscribers: dict[str, list[Subscriber]] = {}
        self._history: list[Event] = []

    def subscribe(self, kind: str, callback: Subscriber) -> None:
        self._subscribers.setdefault(kind, []).append(callback)

    def subscribe_all(self, callback: Subscriber) -> None:
        self._subscribers.setdefault("*", []).append(callback)

    def publish(self, kind: str, source: str, **payload: Any) -> Event:
        event = Event(kind=kind, source=source, payload=payload)
        self._history.append(event)
        errors: list[Exception] = []
        for callback in self._subscribers.get(kind, []) + self._subscribers.get("*", []):
            try:
                callback(event)
            except Exception as exc:  # noqa: BLE001 - intentionally broad, isolated below
                errors.append(exc)
        if errors:
            raise errors[0]
        return event

    @property
    def history(self) -> list[Event]:
        return list(self._history)
