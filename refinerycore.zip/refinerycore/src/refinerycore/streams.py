"""The :class:`Stream` object (spec section 33).

A stream is a directed connection between two pieces of equipment,
carrying a fully-resolved thermodynamic state. It is the fundamental
edge type of the process graph (:mod:`refinerycore.networks.process_graph`).
"""

from __future__ import annotations

from dataclasses import dataclass

from refinerycore.core.enums import Phase
from refinerycore.core.errors import NonPhysicalStateError
from refinerycore.core.units import energy_flow_w
from refinerycore.fluids.fluid import Fluid
from refinerycore.fluids.properties import PropertyProvider
from refinerycore.thermodynamics.state import ThermodynamicState


@dataclass
class Stream:
    """A process stream: composition + thermodynamic state + topology.

    All quantities are SI (see :mod:`refinerycore.core.units`).
    """

    id: str
    name: str
    fluid: Fluid
    mass_flow_kg_s: float
    pressure_Pa: float
    temperature_K: float
    provider: PropertyProvider
    source: str | None = None
    destination: str | None = None

    def __post_init__(self) -> None:
        if self.mass_flow_kg_s < 0:
            raise NonPhysicalStateError(f"Stream {self.id!r} has negative mass flow {self.mass_flow_kg_s} kg/s")

    @property
    def state(self) -> ThermodynamicState:
        return ThermodynamicState.from_PT(self.fluid, self.pressure_Pa, self.temperature_K, self.provider)

    def calculate_density(self) -> float:
        return self.state.density_kg_m3

    def calculate_enthalpy(self) -> float:
        """Specific enthalpy, J/kg."""
        return self.state.specific_enthalpy_j_kg

    def calculate_energy_flow(self) -> float:
        """Enthalpy flow, W (= kg/s * J/kg)."""
        return energy_flow_w(self.mass_flow_kg_s, self.calculate_enthalpy())

    def calculate_mass_flow(self) -> float:
        return self.mass_flow_kg_s

    def calculate_volume_flow_m3_s(self) -> float:
        density = self.calculate_density()
        return self.mass_flow_kg_s / density if density > 0 else 0.0

    def phase(self) -> Phase:
        return self.state.phase

    def report(self) -> dict:
        """A complete, human-readable state report for this stream."""
        s = self.state
        return {
            "id": self.id,
            "name": self.name,
            "source": self.source,
            "destination": self.destination,
            "fluid": self.fluid.name,
            "mass_flow_kg_s": self.mass_flow_kg_s,
            "pressure_Pa": self.pressure_Pa,
            "temperature_K": self.temperature_K,
            "density_kg_m3": s.density_kg_m3,
            "specific_enthalpy_j_kg": s.specific_enthalpy_j_kg,
            "phase": s.phase.value,
            "vapour_fraction": s.vapour_fraction,
            "energy_flow_w": self.calculate_energy_flow(),
        }

    def with_state(self, mass_flow_kg_s: float | None = None, pressure_Pa: float | None = None, temperature_K: float | None = None) -> "Stream":
        """Return a copy of this stream with a modified state (streams are
        treated as immutable snapshots so solver iterations never mutate
        shared state)."""
        return Stream(
            id=self.id,
            name=self.name,
            fluid=self.fluid,
            mass_flow_kg_s=self.mass_flow_kg_s if mass_flow_kg_s is None else mass_flow_kg_s,
            pressure_Pa=self.pressure_Pa if pressure_Pa is None else pressure_Pa,
            temperature_K=self.temperature_K if temperature_K is None else temperature_K,
            provider=self.provider,
            source=self.source,
            destination=self.destination,
        )
