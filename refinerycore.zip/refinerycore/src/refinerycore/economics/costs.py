"""Operating cost calculations, built from physical outputs + a :class:`PriceBook`."""

from __future__ import annotations

from dataclasses import dataclass

from refinerycore.economics.prices import PriceBook


@dataclass
class OperatingCosts:
    price_book: PriceBook

    def feed_cost(self, feed_flows_kg_s: dict[str, float], duration_s: float) -> float:
        return sum(flow * duration_s * self.price_book.feed_price(name) for name, flow in feed_flows_kg_s.items())

    def product_value(self, product_flows_kg_s: dict[str, float], duration_s: float) -> float:
        return sum(flow * duration_s * self.price_book.product_price(name) for name, flow in product_flows_kg_s.items())

    def energy_cost(self, electricity_j: float, fuel_gas_j: float) -> float:
        return electricity_j * self.price_book.electricity_price_per_j + fuel_gas_j * self.price_book.fuel_gas_price_per_j

    def hydrogen_cost(self, hydrogen_kg: float) -> float:
        return hydrogen_kg * self.price_book.hydrogen_price_per_kg

    def carbon_cost(self, co2_kg: float) -> float:
        return co2_kg * self.price_book.carbon_price_per_kg_co2

    def total_operating_cost(
        self,
        feed_flows_kg_s: dict[str, float],
        electricity_j: float,
        fuel_gas_j: float,
        hydrogen_kg: float,
        co2_kg: float,
        duration_s: float,
    ) -> float:
        return (
            self.feed_cost(feed_flows_kg_s, duration_s)
            + self.energy_cost(electricity_j, fuel_gas_j)
            + self.hydrogen_cost(hydrogen_kg)
            + self.carbon_cost(co2_kg)
        )
