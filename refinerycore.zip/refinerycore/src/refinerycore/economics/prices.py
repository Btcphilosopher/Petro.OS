"""Price book (spec section 4).

All prices are per-mass ($/kg) or per-energy ($/J) to stay unit-clean
against the SI physical outputs; conversion helpers to $/bbl, $/t etc.
belong in reporting, not here.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class PriceBook:
    currency: str = "USD"
    feed_prices_per_kg: dict[str, float] = field(default_factory=dict)
    product_prices_per_kg: dict[str, float] = field(default_factory=dict)
    electricity_price_per_j: float = 0.0
    fuel_gas_price_per_j: float = 0.0
    hydrogen_price_per_kg: float = 0.0
    carbon_price_per_kg_co2: float = 0.0

    def feed_price(self, name: str) -> float:
        return self.feed_prices_per_kg.get(name, 0.0)

    def product_price(self, name: str) -> float:
        return self.product_prices_per_kg.get(name, 0.0)
