"""Gross/net margin calculation, downstream of physical outputs and :mod:`costs`."""

from __future__ import annotations

from dataclasses import dataclass

from refinerycore.economics.costs import OperatingCosts


@dataclass
class MarginCalculator:
    operating_costs: OperatingCosts
    maintenance_cost_per_s: float = 0.0

    def gross_margin(
        self,
        product_flows_kg_s: dict[str, float],
        feed_flows_kg_s: dict[str, float],
        duration_s: float,
    ) -> float:
        revenue = self.operating_costs.product_value(product_flows_kg_s, duration_s)
        feed_cost = self.operating_costs.feed_cost(feed_flows_kg_s, duration_s)
        return revenue - feed_cost

    def net_margin(
        self,
        product_flows_kg_s: dict[str, float],
        feed_flows_kg_s: dict[str, float],
        electricity_j: float,
        fuel_gas_j: float,
        hydrogen_kg: float,
        co2_kg: float,
        duration_s: float,
    ) -> float:
        gross = self.gross_margin(product_flows_kg_s, feed_flows_kg_s, duration_s)
        operating_cost = self.operating_costs.total_operating_cost(
            feed_flows_kg_s, electricity_j, fuel_gas_j, hydrogen_kg, co2_kg, duration_s
        )
        # feed cost is already subtracted in gross_margin; avoid double-counting it here
        operating_cost_excl_feed = operating_cost - self.operating_costs.feed_cost(feed_flows_kg_s, duration_s)
        maintenance = self.maintenance_cost_per_s * duration_s
        return gross - operating_cost_excl_feed - maintenance
