"""Economics layer -- strictly downstream of the physical model (spec section 4).

Nothing here feeds back into ``fluids``, ``thermodynamics``,
``equipment``, ``units``, ``networks`` or ``solver``. Physical outputs
(mass/energy flows) are consumed by this layer; the reverse dependency
is never permitted.
"""
