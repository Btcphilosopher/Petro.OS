"""Steady-state flowsheet solver (spec section 34).

Two solving strategies are provided:

* :class:`SequentialModularSolver` -- runs a set of calculation "blocks"
  (equipment/unit ``.run()`` calls) in an order that respects the
  process graph's topology. This is how the reference examples solve
  the CDU flowsheet: it has no recycle, so a single topological pass
  converges exactly.
* :func:`solve_recycle` -- a tear-stream fixed-point iteration for
  flowsheets that DO have recycle (e.g. a hydrogen recycle loop), using
  ``scipy.optimize.root`` on the torn-stream residual. Iterations,
  residual norm and convergence status are always exposed; a failed
  solve raises :class:`~refinerycore.core.errors.ConvergenceError`
  rather than silently returning a bad state.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

import numpy as np
from scipy.optimize import root

from refinerycore.core.enums import ConvergenceStatus
from refinerycore.core.errors import ConvergenceError
from refinerycore.networks.process_graph import ProcessGraph


@dataclass
class SolveResult:
    status: ConvergenceStatus
    iterations: int
    residual_norm: float
    failed_equations: list[str] = field(default_factory=list)
    block_results: dict[str, dict] = field(default_factory=dict)

    @property
    def converged(self) -> bool:
        return self.status is ConvergenceStatus.CONVERGED


@dataclass
class SequentialModularSolver:
    """Runs calculation blocks in topological order.

    ``blocks`` maps a node id (matching a :class:`ProcessGraph` node) to
    a zero-argument callable that performs that block's calculation and
    returns its diagnostics dict (e.g. ``equipment.run`` /
    ``process_unit.run``).
    """

    graph: ProcessGraph
    blocks: dict[str, Callable[[], dict]] = field(default_factory=dict)

    def register(self, node_id: str, block: Callable[[], dict]) -> None:
        self.blocks[node_id] = block

    def solve(self) -> SolveResult:
        order = self.graph.topological_order()
        block_results: dict[str, dict] = {}
        failed: list[str] = []
        for node_id in order:
            block = self.blocks.get(node_id)
            if block is None:
                continue
            try:
                block_results[node_id] = block()
            except Exception as exc:  # noqa: BLE001 - captured as a failed-equation diagnostic
                failed.append(f"{node_id}: {exc}")

        status = ConvergenceStatus.CONVERGED if not failed else ConvergenceStatus.FAILED
        return SolveResult(
            status=status,
            iterations=1,  # a no-recycle sequential-modular pass converges in a single pass by construction
            residual_norm=0.0 if not failed else float("nan"),
            failed_equations=failed,
            block_results=block_results,
        )


def solve_recycle(
    residual_fn: Callable[[np.ndarray], np.ndarray],
    x0: np.ndarray,
    tolerance: float = 1.0e-6,
    max_iterations: int = 200,
) -> SolveResult:
    """Solve a torn-recycle-stream residual with ``scipy.optimize.root``.

    ``residual_fn(x) -> residual`` where ``x`` is the guessed tear-stream
    vector (e.g. [mass_flow_kg_s, temperature_K, ...]) and ``residual``
    is the difference between the guess and the recomputed value after
    one pass around the loop.
    """
    solution = root(residual_fn, x0, tol=tolerance, options={"maxfev": max_iterations})
    residual_norm = float(np.linalg.norm(solution.fun))
    status = ConvergenceStatus.CONVERGED if solution.success else ConvergenceStatus.NOT_CONVERGED
    result = SolveResult(
        status=status,
        iterations=int(solution.nfev),
        residual_norm=residual_norm,
        failed_equations=[] if solution.success else [solution.message],
    )
    if not solution.success:
        raise ConvergenceError(
            f"recycle solve failed to converge after {solution.nfev} evaluations "
            f"(residual norm={residual_norm:.3e}): {solution.message}"
        )
    return result
