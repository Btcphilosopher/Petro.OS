"""Transient (time-domain) simulation engine (spec section 35).

A simple explicit time-stepping driver: at each tick it advances
equipment health/fouling models and calls a user-supplied step function
(e.g. re-running the steady-state solver at the new conditions, or
stepping tank inventories). This is Level 1: explicit Euler stepping,
not a full DAE/ODE system with adaptive integration -- adequate for the
slow (hours-to-days) drift processes this project's examples target
(fouling, tank draw-down), not fast transients (seconds-scale water
hammer, compressor surge dynamics).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from refinerycore.core.ids import utc_now_iso


@dataclass
class SimulationClock:
    dt_s: float
    current_time_s: float = 0.0
    step_count: int = 0

    def tick(self) -> float:
        self.current_time_s += self.dt_s
        self.step_count += 1
        return self.current_time_s


@dataclass
class SimulationEvent:
    kind: str
    time_s: float
    payload: dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(default_factory=utc_now_iso)


@dataclass
class SimulationState:
    """A single time-domain snapshot; append these to build a trajectory."""

    time_s: float
    values: dict[str, Any] = field(default_factory=dict)


@dataclass
class TransientRunner:
    clock: SimulationClock
    step_fn: Callable[[SimulationClock], dict[str, Any]]
    history: list[SimulationState] = field(default_factory=list)
    events: list[SimulationEvent] = field(default_factory=list)

    def run(self, n_steps: int) -> list[SimulationState]:
        for _ in range(n_steps):
            self.clock.tick()
            values = self.step_fn(self.clock)
            self.history.append(SimulationState(time_s=self.clock.current_time_s, values=values))
        return self.history

    def inject_event(self, kind: str, **payload: Any) -> SimulationEvent:
        event = SimulationEvent(kind=kind, time_s=self.clock.current_time_s, payload=payload)
        self.events.append(event)
        return event
