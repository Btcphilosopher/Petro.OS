"""Monte Carlo uncertainty engine (spec section 48).

Distinguishes MODEL uncertainty (e.g. an assumed distribution over a
correlation's parameter) from MEASUREMENT uncertainty (e.g. sensor
noise) by requiring the caller to label each uncertain variable's
``kind``. The engine never conflates the two in its summary statistics.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Literal

import numpy as np
import pandas as pd

UncertaintyKind = Literal["model", "measurement"]


@dataclass
class UncertainVariable:
    name: str
    kind: UncertaintyKind
    mean: float
    std: float
    distribution: Literal["normal", "uniform"] = "normal"
    low: float | None = None  # for uniform
    high: float | None = None  # for uniform


@dataclass
class MonteCarloResult:
    samples: pd.DataFrame
    output_stats: dict[str, float]
    seed: int
    n_samples: int
    model_uncertainty_vars: list[str] = field(default_factory=list)
    measurement_uncertainty_vars: list[str] = field(default_factory=list)


class MonteCarloEngine:
    def __init__(self, variables: list[UncertainVariable], model_fn: Callable[[dict[str, float]], float], seed: int = 42):
        self.variables = variables
        self.model_fn = model_fn
        self.seed = seed  # always recorded (spec section 71: reproducibility)

    def run(self, n_samples: int = 1000) -> MonteCarloResult:
        rng = np.random.default_rng(self.seed)
        sample_rows = []
        outputs = np.empty(n_samples)

        for i in range(n_samples):
            draw = {}
            for var in self.variables:
                if var.distribution == "normal":
                    draw[var.name] = rng.normal(var.mean, var.std)
                else:
                    low = var.low if var.low is not None else var.mean - var.std
                    high = var.high if var.high is not None else var.mean + var.std
                    draw[var.name] = rng.uniform(low, high)
            outputs[i] = self.model_fn(draw)
            sample_rows.append({**draw, "output": outputs[i]})

        percentiles = np.percentile(outputs, [5, 25, 50, 75, 95])
        stats = {
            "mean": float(np.mean(outputs)),
            "median": float(np.median(outputs)),
            "std": float(np.std(outputs, ddof=1)),
            "p5": float(percentiles[0]),
            "p25": float(percentiles[1]),
            "p50": float(percentiles[2]),
            "p75": float(percentiles[3]),
            "p95": float(percentiles[4]),
        }
        return MonteCarloResult(
            samples=pd.DataFrame(sample_rows),
            output_stats=stats,
            seed=self.seed,
            n_samples=n_samples,
            model_uncertainty_vars=[v.name for v in self.variables if v.kind == "model"],
            measurement_uncertainty_vars=[v.name for v in self.variables if v.kind == "measurement"],
        )
