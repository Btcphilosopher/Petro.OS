"""Scenario engine (spec section 49)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

import pandas as pd


@dataclass
class Scenario:
    name: str
    description: str
    overrides: dict[str, Any] = field(default_factory=dict)


@dataclass
class ScenarioResult:
    scenario: Scenario
    outputs: dict[str, float]


class ScenarioRunner:
    """Runs a model function once per scenario, applying each scenario's
    ``overrides`` to a base input dict before calling it."""

    def __init__(self, base_inputs: dict[str, Any], model_fn: Callable[[dict[str, Any]], dict[str, float]]):
        self.base_inputs = base_inputs
        self.model_fn = model_fn
        self.results: list[ScenarioResult] = []

    def run(self, scenario: Scenario) -> ScenarioResult:
        inputs = {**self.base_inputs, **scenario.overrides}
        outputs = self.model_fn(inputs)
        result = ScenarioResult(scenario=scenario, outputs=outputs)
        self.results.append(result)
        return result

    def run_all(self, scenarios: list[Scenario]) -> list[ScenarioResult]:
        return [self.run(s) for s in scenarios]

    def comparison_table(self) -> pd.DataFrame:
        rows = [{"scenario": r.scenario.name, **r.outputs} for r in self.results]
        return pd.DataFrame(rows)
