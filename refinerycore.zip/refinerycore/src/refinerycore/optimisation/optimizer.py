"""Refinery optimisation engine (spec section 45).

A thin, deterministic wrapper around ``scipy.optimize.minimize``
(SLSQP, which supports bounds and nonlinear constraints). The objective
and constraint functions are supplied by the caller and MUST be built
from actual simulation calculations -- the optimizer itself contains no
process knowledge.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

import numpy as np
from scipy.optimize import NonlinearConstraint, minimize

from refinerycore.core.enums import ConvergenceStatus


@dataclass
class DecisionVariable:
    name: str
    initial_value: float
    lower_bound: float
    upper_bound: float


@dataclass
class Constraint:
    name: str
    fn: Callable[[np.ndarray], float]
    lower_bound: float = 0.0
    upper_bound: float = float("inf")


@dataclass
class OptimizationResult:
    status: ConvergenceStatus
    objective_value: float
    baseline_objective_value: float
    decision_values: dict[str, float]
    baseline_decision_values: dict[str, float]
    iterations: int
    constraint_status: dict[str, bool]
    message: str = ""


class RefineryOptimizer:
    """Maximise (or minimise) an objective over a set of decision
    variables subject to constraints, built from the simulation."""

    def __init__(
        self,
        decision_variables: list[DecisionVariable],
        objective_fn: Callable[[np.ndarray], float],
        constraints: list[Constraint] | None = None,
        maximize: bool = True,
        seed: int = 0,
    ):
        self.decision_variables = decision_variables
        self.objective_fn = objective_fn
        self.constraints = constraints or []
        self.maximize = maximize
        self.seed = seed  # kept for reproducibility records; SLSQP is deterministic given x0

    def _objective_for_minimizer(self, x: np.ndarray) -> float:
        value = self.objective_fn(x)
        return -value if self.maximize else value

    def optimise(self) -> OptimizationResult:
        x0 = np.array([v.initial_value for v in self.decision_variables])
        bounds = [(v.lower_bound, v.upper_bound) for v in self.decision_variables]

        scipy_constraints = [
            NonlinearConstraint(c.fn, c.lower_bound, c.upper_bound) for c in self.constraints
        ]

        baseline_objective = self.objective_fn(x0)

        solution = minimize(
            self._objective_for_minimizer,
            x0,
            method="SLSQP",
            bounds=bounds,
            constraints=scipy_constraints,
            options={"maxiter": 200, "ftol": 1.0e-9},
        )

        objective_value = -solution.fun if self.maximize else solution.fun
        status = ConvergenceStatus.CONVERGED if solution.success else ConvergenceStatus.NOT_CONVERGED

        constraint_status = {
            c.name: bool(c.lower_bound - 1.0e-6 <= c.fn(solution.x) <= c.upper_bound + 1.0e-6)
            for c in self.constraints
        }

        return OptimizationResult(
            status=status,
            objective_value=float(objective_value),
            baseline_objective_value=float(baseline_objective),
            decision_values={v.name: float(x) for v, x in zip(self.decision_variables, solution.x)},
            baseline_decision_values={v.name: v.initial_value for v in self.decision_variables},
            iterations=int(solution.nit),
            constraint_status=constraint_status,
            message=str(solution.message),
        )
