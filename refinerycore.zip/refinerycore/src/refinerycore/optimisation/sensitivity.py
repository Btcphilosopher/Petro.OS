"""Sensitivity analysis (spec section 47).

Central finite-difference sensitivity of a scalar output with respect
to one or more scalar inputs, computed directly from the simulation
function -- no surrogate model is fitted.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import pandas as pd


@dataclass
class SensitivityResult:
    input_name: str
    output_name: str
    base_input: float
    base_output: float
    derivative: float  # d(output)/d(input), same units as output/input
    normalised_sensitivity: float  # (d output/output) / (d input/input), dimensionless elasticity


def finite_difference_sensitivity(
    model_fn: Callable[[float], float],
    base_input: float,
    input_name: str = "input",
    output_name: str = "output",
    relative_step: float = 1.0e-3,
) -> SensitivityResult:
    step = max(abs(base_input) * relative_step, 1.0e-9)
    base_output = model_fn(base_input)
    plus = model_fn(base_input + step)
    minus = model_fn(base_input - step)
    derivative = (plus - minus) / (2.0 * step)
    elasticity = derivative * base_input / base_output if base_output != 0 else float("nan")
    return SensitivityResult(
        input_name=input_name,
        output_name=output_name,
        base_input=base_input,
        base_output=base_output,
        derivative=derivative,
        normalised_sensitivity=elasticity,
    )


def ranked_sensitivities(
    model_fn: Callable[[dict[str, float]], float],
    base_inputs: dict[str, float],
    output_name: str = "output",
    relative_step: float = 1.0e-3,
) -> pd.DataFrame:
    """Sensitivity of ``model_fn(inputs_dict) -> scalar`` to each named
    input in ``base_inputs``, holding the others at their base value.
    Returns a DataFrame ranked by |normalised_sensitivity| descending.
    """
    base_output = model_fn(base_inputs)
    rows = []
    for name, base_value in base_inputs.items():
        step = max(abs(base_value) * relative_step, 1.0e-9)

        plus_inputs = dict(base_inputs)
        plus_inputs[name] = base_value + step
        minus_inputs = dict(base_inputs)
        minus_inputs[name] = base_value - step

        derivative = (model_fn(plus_inputs) - model_fn(minus_inputs)) / (2.0 * step)
        elasticity = derivative * base_value / base_output if base_output != 0 else float("nan")
        rows.append(
            {
                "input": name,
                "output": output_name,
                "base_input": base_value,
                "base_output": base_output,
                "derivative": derivative,
                "normalised_sensitivity": elasticity,
            }
        )
    df = pd.DataFrame(rows)
    return df.reindex(df["normalised_sensitivity"].abs().sort_values(ascending=False).index).reset_index(drop=True)
