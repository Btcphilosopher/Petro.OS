"""Optimisation, sensitivity, Monte Carlo and scenario engines.

Everything here interrogates the physical simulation -- it never
invents an engineering outcome. Objective/constraint functions must be
built from :mod:`refinerycore.refinery` (or lower-level unit/equipment)
calculations.
"""
