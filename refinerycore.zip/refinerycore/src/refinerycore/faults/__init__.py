"""Fault injection and propagation."""
