"""Fault propagation engine (spec section 40).

Applies a :class:`~refinerycore.faults.faults.Fault`, then re-runs the
:class:`~refinerycore.solver.steady_state.SequentialModularSolver` blocks
that are downstream of the faulted equipment in the process graph,
recording a before/after diagnostic at each affected node -- this is
what makes the causal chain (e.g. cooling-water pump failure -> reduced
cooling flow -> condenser duty loss -> column pressure change -> yield
change) an actual computed consequence rather than a scripted narrative.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from refinerycore.faults.faults import Fault
from refinerycore.networks.process_graph import ProcessGraph
from refinerycore.solver.steady_state import SequentialModularSolver, SolveResult


@dataclass
class PropagationStep:
    node_id: str
    before: dict[str, Any]
    after: dict[str, Any]


@dataclass
class PropagationResult:
    fault: Fault
    affected_nodes: list[str]
    steps: list[PropagationStep] = field(default_factory=list)
    solve_result: SolveResult | None = None


class FaultPropagationEngine:
    def __init__(self, graph: ProcessGraph, solver: SequentialModularSolver):
        self.graph = graph
        self.solver = solver

    def inject_and_propagate(self, fault: Fault, target: Any) -> PropagationResult:
        affected = [fault.target_id] + self.graph.downstream_of(fault.target_id)
        # "before" state comes from whatever the solver last computed (a
        # prior .solve() the caller ran under normal conditions); if none
        # was run yet, before-states are simply empty.
        before = {node: dict(self.solver.blocks[node].__self__._last_result) for node in affected if node in self.solver.blocks and hasattr(self.solver.blocks[node], "__self__")}

        fault.apply(target)

        solve_result = self.solver.solve()
        steps = [
            PropagationStep(node_id=node, before=before.get(node, {}), after=solve_result.block_results.get(node, {}))
            for node in affected
        ]
        return PropagationResult(fault=fault, affected_nodes=affected, steps=steps, solve_result=solve_result)
