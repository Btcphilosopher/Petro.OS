"""Fault definitions (spec section 40).

A :class:`Fault` is a named, reversible mutation applied to one piece of
equipment (or its health/fouling state). Applying a fault does not, by
itself, recompute downstream consequences -- see
:mod:`refinerycore.faults.propagation` for that.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from refinerycore.core.enums import EquipmentStatus
from refinerycore.core.ids import new_id, utc_now_iso


@dataclass
class Fault:
    id: str
    kind: str
    target_id: str
    description: str
    apply_fn: Callable[[Any], None]
    timestamp: str = ""

    def apply(self, target: Any) -> None:
        self.apply_fn(target)


def _set_health(target, health_score: float) -> None:
    target.health.health_score = health_score


def pump_trip(pump) -> Fault:
    def _apply(target):
        target.status = EquipmentStatus.TRIPPED
        target.health.health_score = 0.0

    return Fault(id=new_id("fault"), kind="pump_trip", target_id=pump.id,
                 description=f"{pump.id} tripped (stopped)", apply_fn=_apply, timestamp=utc_now_iso())


def pump_efficiency_degradation(pump, health_score: float) -> Fault:
    return Fault(
        id=new_id("fault"), kind="pump_degradation", target_id=pump.id,
        description=f"{pump.id} efficiency degraded to health_score={health_score:.2f}",
        apply_fn=lambda target: _set_health(target, health_score), timestamp=utc_now_iso(),
    )


def heat_exchanger_fouling(hx, additional_hours: float) -> Fault:
    def _apply(target):
        target.fouling.advance(additional_hours)

    return Fault(
        id=new_id("fault"), kind="heat_exchanger_fouling", target_id=hx.id,
        description=f"{hx.id} fouling advanced by {additional_hours} h", apply_fn=_apply, timestamp=utc_now_iso(),
    )


def valve_stuck(valve, stuck_position: float) -> Fault:
    return Fault(
        id=new_id("fault"), kind="valve_stuck", target_id=valve.id,
        description=f"{valve.id} stuck at position={stuck_position:.2f}",
        apply_fn=lambda target: setattr(target, "position", stuck_position), timestamp=utc_now_iso(),
    )


def cooling_water_failure(cooling_network, fraction_lost: float) -> Fault:
    def _apply(target):
        for consumer in list(target.consumers_kg_s):
            target.consumers_kg_s[consumer] *= (1.0 - fraction_lost)

    return Fault(
        id=new_id("fault"), kind="cooling_water_failure", target_id="cooling-network",
        description=f"cooling water flow reduced by {fraction_lost:.0%}", apply_fn=_apply, timestamp=utc_now_iso(),
    )


def instrument_failure(sensor, bias: float) -> Fault:
    return Fault(
        id=new_id("fault"), kind="instrument_failure", target_id=sensor.id,
        description=f"{sensor.id} bias shifted by {bias}",
        apply_fn=lambda target: setattr(target, "bias", target.bias + bias), timestamp=utc_now_iso(),
    )
