# Correlation reference data

Placeholder directory for future digitised correlation data (e.g. K-value
charts, pump/compressor vendor curves). Currently all correlations used
by REFINERYCORE.OS are implemented directly in code with documented
constants -- see `docs/limitations.md` and each module's docstring for
sources and applicability ranges.
