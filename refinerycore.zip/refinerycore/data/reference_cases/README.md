# Reference cases

Placeholder directory for saved `RefineryTwinState` snapshots (e.g.
baseline vs. scenario comparisons) produced via
`refinerycore.twin.state.RefineryTwinState.save_state`. None are
committed yet; see `examples/` for scripts that generate comparable
states at runtime.
