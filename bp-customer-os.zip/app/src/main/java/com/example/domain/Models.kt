package com.example.domain

import java.util.UUID

enum class CardStatus {
    ACTIVE,
    LOCKED,
    PAYMENT_PENDING,
    PAYMENT_APPROVED,
    PAYMENT_DECLINED,
    OFFLINE,
    EXPIRED,
    REPLACEMENT_REQUIRED
}

enum class FuelType(val displayName: String, val defaultPricePerLitre: Double) {
    UNLEADED("Unleaded 95", 1.499),
    DIESEL("Ultimate Diesel", 1.529),
    PREMIUM("BP Ultimate Unleaded", 1.659)
}

enum class FuelSessionStatus {
    IDLE,
    AUTHORIZING,
    AUTHORIZED,
    PUMP_UNLOCKED,
    FUELING,
    PAUSED,
    COMPLETED,
    DECLINED,
    CANCELLED
}

enum class ChargingSessionStatus {
    AVAILABLE,
    RESERVED,
    CONNECTING,
    CHARGING,
    COMPLETE,
    PAUSED,
    DECLINED
}

enum class PaymentStatus {
    IDLE,
    AUTHENTICATING,
    AUTHORIZED,
    PROCESSING,
    APPROVED,
    SETTLED,
    DECLINED
}

enum class NfcState {
    READY,
    HOLD_NEAR_TERMINAL,
    DETECTED,
    AUTHENTICATING,
    APPROVED,
    FAILED
}

data class Customer(
    val id: String = "CUST-98231",
    val name: String = "Tom Anderson",
    val email: String = "tom.anderson@bp-customer.co.uk",
    val bpIdentityId: String = "BP-ID-884029",
    val avatarUrl: String? = null,
    val memberTier: String = "BP Premier Member"
)

data class BPCard(
    val id: String = "CARD-4821",
    val cardHolder: String = "TOM ANDERSON",
    val lastFour: String = "4821",
    val cardNumberMasked: String = "•••• •••• •••• 4821",
    val expiryDate: String = "08/28",
    val cvv: String = "•••",
    val status: CardStatus = CardStatus.ACTIVE,
    val spendingLimitMonthly: Double = 1000.0,
    val currentSpendMonthly: Double = 392.32,
    val isDefaultPayment: Boolean = true,
    val pinGuidanceEnabled: Boolean = true,
    val contactlessLimit: Double = 100.0
)

enum class VehicleFuelType { PETROL, DIESEL, EV, HYBRID }

data class Vehicle(
    val id: String,
    val make: String,
    val model: String,
    val year: Int,
    val registration: String,
    val fuelType: VehicleFuelType,
    val tankCapacityLitres: Double = 58.0,
    val currentFuelPercent: Double = 0.62, // 62%
    val batteryCapacityKWh: Double = 75.0,
    val currentBatteryPercent: Double = 0.62,
    val estimatedRangeMiles: Int = 286,
    val efficiency: String = "6.2 L/100km",
    val preferredFuel: FuelType = FuelType.UNLEADED,
    val odometerMiles: Int = 34120
)

data class Pump(
    val id: String,
    val number: Int,
    val isAvailable: Boolean = true,
    val supportedFuels: List<FuelType> = listOf(FuelType.UNLEADED, FuelType.DIESEL, FuelType.PREMIUM)
)

data class EVCharger(
    val id: String,
    val chargerNumber: Int,
    val powerKw: Int = 150,
    val connectorType: String = "CCS Type 2",
    val isAvailable: Boolean = true,
    val pricePerKWh: Double = 0.69
)

data class Station(
    val id: String,
    val name: String,
    val address: String,
    val distanceMiles: Double,
    val latitude: Double,
    val longitude: Double,
    val isOpen: Boolean = true,
    val unleadedPrice: Double = 1.499,
    val dieselPrice: Double = 1.529,
    val premiumPrice: Double = 1.659,
    val pumps: List<Pump>,
    val evChargers: List<EVCharger>,
    val totalChargersCount: Int = 12,
    val availableChargersCount: Int = 4,
    val amenities: List<String> = listOf("Wild Bean Cafe", "M&S Simply Food", "Car Wash", "Toilets", "ATM", "Free WiFi")
)

data class FuelSession(
    val id: String = UUID.randomUUID().toString().take(8).uppercase(),
    val customerId: String = "CUST-98231",
    val vehicleId: String = "VEH-AUDI-A4",
    val stationId: String = "ST-SHEFFIELD",
    val pumpId: String = "PUMP-04",
    val pumpNumber: Int = 4,
    val fuelType: FuelType = FuelType.UNLEADED,
    val pricePerLitre: Double = 1.499,
    val litres: Double = 0.0,
    val flowRateLitresPerMin: Double = 22.5,
    val startedAt: String = "Today · 08:42",
    val endedAt: String? = null,
    val totalCost: Double = 0.0,
    val paymentMethod: String = "BP CARD •••• 4821",
    val status: FuelSessionStatus = FuelSessionStatus.IDLE
)

data class ChargingSession(
    val id: String = UUID.randomUUID().toString().take(8).uppercase(),
    val chargerId: String = "CHG-08",
    val chargerNumber: Int = 8,
    val powerKw: Double = 150.0,
    val energyKWh: Double = 0.0,
    val startBatteryPercent: Int = 32,
    val currentBatteryPercent: Int = 32,
    val targetBatteryPercent: Int = 80,
    val pricePerKWh: Double = 0.69,
    val totalCost: Double = 0.0,
    val status: ChargingSessionStatus = ChargingSessionStatus.AVAILABLE
)

data class Transaction(
    val id: String,
    val date: String,
    val time: String,
    val stationName: String,
    val stationLocation: String,
    val type: String, // "Petrol", "EV Charge", "Shop"
    val details: String, // "42.7 L @ £1.499/L" or "34.2 kWh @ 150kW"
    val amount: Double,
    val paymentMethod: String,
    val pumpOrChargerNumber: String,
    val pointsEarned: Int,
    val receiptId: String,
    val status: String = "APPROVED"
)

data class Receipt(
    val id: String,
    val transactionId: String,
    val stationName: String,
    val stationAddress: String,
    val vatNumber: String = "GB 243 5100 82",
    val date: String,
    val time: String,
    val pumpNumber: String,
    val fuelType: String,
    val litres: Double,
    val pricePerLitre: Double,
    val subtotal: Double,
    val vatAmount: Double,
    val total: Double,
    val paymentMethod: String,
    val cardLastFour: String = "4821",
    val pointsEarned: Int,
    val authCode: String = "AUTH-${(100000..999999).random()}"
)

data class RewardAccount(
    val totalPoints: Int = 2840,
    val lifetimePoints: Int = 14250,
    val tierName: String = "BP Premier",
    val pointsToNextTier: Int = 1160
)

data class Offer(
    val id: String,
    val title: String,
    val description: String,
    val discountText: String,
    val validUntil: String,
    val routeContext: String? = null,
    val isActivated: Boolean = false
)

data class Journey(
    val id: String,
    val origin: String,
    val destination: String,
    val distanceMiles: Int,
    val estimatedDurationMins: Int,
    val estimatedFuelCost: Double,
    val requiredFuelLitres: Double,
    val stopStations: List<Station>
)

data class SecurityEvent(
    val id: String,
    val timestamp: String,
    val eventType: String,
    val deviceName: String = "Pixel 8 Pro (NFC Active)",
    val location: String = "Sheffield, UK",
    val status: String = "SUCCESS"
)
