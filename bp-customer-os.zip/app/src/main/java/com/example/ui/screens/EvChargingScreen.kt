package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.ChargingSession
import com.example.domain.ChargingSessionStatus
import com.example.ui.components.LiveChargeMeter
import com.example.ui.theme.*
import com.example.viewmodel.BpCustomerUiState

@Composable
fun EvChargingScreen(
    state: BpCustomerUiState,
    chargingSession: ChargingSession,
    onStartCharging: (Int) -> Unit,
    onStopCharging: () -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp, vertical = 10.dp)
            .testTag("ev_charging_screen_content"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "BP PULSE HIGH-POWER EV NETWORK",
            style = MachineTextStyleSmall,
            color = BpGreen
        )

        // Live Charge Meter Component
        LiveChargeMeter(session = chargingSession)

        // Charger Selection Grid
        Column {
            Text(
                text = "SELECT PULSE DISPENSER",
                style = MachineTextStyleSmall,
                color = TextGraySecondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                (1..6).forEach { chgNum ->
                    val isSelected = state.selectedChargerNumber == chgNum
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) BpGreenContainer else GraphiteCard)
                            .border(1.dp, if (isSelected) BpGreen else SatinBorder, RoundedCornerShape(10.dp))
                            .clickable { onStartCharging(chgNum) }
                            .testTag("charger_select_pill_$chgNum"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "CHG ${String.format("%02d", chgNum)}",
                            style = MachineTextStyleSmall,
                            color = if (isSelected) BpGreen else TextWhitePrimary,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 9.sp
                        )
                    }
                }
            }
        }

        // Charging Action Button
        when (chargingSession.status) {
            ChargingSessionStatus.AVAILABLE, ChargingSessionStatus.CONNECTING -> {
                Button(
                    onClick = { onStartCharging(state.selectedChargerNumber) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("start_ev_charge_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = BpGreen, contentColor = ObsidianBackground),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "START 150kW CCS PULSE CHARGE",
                        style = MachineTextStyleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            ChargingSessionStatus.CHARGING -> {
                Button(
                    onClick = onStopCharging,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("stop_ev_charge_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = BpRed, contentColor = TextWhitePrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "DISCONNECT & SETTLE PAYMENT",
                        style = MachineTextStyleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            ChargingSessionStatus.COMPLETE -> {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(BpGreenContainer)
                        .border(1.dp, BpGreen, RoundedCornerShape(12.dp))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = BpGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "CHARGING COMPLETE · BATTERY 80% REACHED",
                            style = MachineTextStyleSmall,
                            color = BpGreen,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            else -> {}
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}
