package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.Station
import com.example.ui.components.StationCard
import com.example.ui.theme.*
import com.example.viewmodel.AppNavDestination
import com.example.viewmodel.BpCustomerUiState

@Composable
fun StationsScreen(
    state: BpCustomerUiState,
    onStationSelect: (Station) -> Unit,
    onNavigate: (AppNavDestination) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .testTag("stations_screen_content")
    ) {
        // Spatial Map View Simulation Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(210.dp)
                .background(Color(0xFF090B0D))
                .border(1.dp, SatinBorder)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val width = size.width
                val height = size.height

                // Draw Grid & Route Lines (Anglo-futurist spatial design)
                val gridSpacing = 40.dp.toPx()
                var x = 0f
                while (x < width) {
                    drawLine(
                        color = Color(0x1A282C32),
                        start = Offset(x, 0f),
                        end = Offset(x, height),
                        strokeWidth = 1f
                    )
                    x += gridSpacing
                }

                var y = 0f
                while (y < height) {
                    drawLine(
                        color = Color(0x1A282C32),
                        start = Offset(0f, y),
                        end = Offset(width, y),
                        strokeWidth = 1f
                    )
                    y += gridSpacing
                }

                // Highway M1 Route Line
                drawLine(
                    color = Color(0x3300D215),
                    start = Offset(width * 0.2f, height * 0.9f),
                    end = Offset(width * 0.8f, height * 0.1f),
                    strokeWidth = 3f
                )

                // Station Pins
                drawCircle(color = BpGreen, radius = 8f, center = Offset(width * 0.35f, height * 0.65f))
                drawCircle(color = BpGreenGlow, radius = 22f, center = Offset(width * 0.35f, height * 0.65f))

                drawCircle(color = BpAmber, radius = 6f, center = Offset(width * 0.65f, height * 0.35f))
            }

            // Map Overlay Badges
            Box(
                modifier = Modifier
                    .padding(14.dp)
                    .align(Alignment.TopStart)
                    .clip(RoundedCornerShape(8.dp))
                    .background(GraphiteCard)
                    .border(0.5.dp, BpGreenBorder, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "BP NETWORK MAP · 3 STATIONS NEARBY",
                    style = MachineTextStyleSmall,
                    color = BpGreen,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // List Header & Filter Chips
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp)
        ) {
            Text(
                text = "NEARBY BP FORECOURTS",
                style = MachineTextStyleSmall,
                color = TextGraySecondary
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(label = "ALL FUELS", isSelected = true)
                FilterChip(label = "EV PULSE 150kW+", isSelected = false)
                FilterChip(label = "WILD BEAN CAFE", isSelected = false)
            }
        }

        // Stations List
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 20.dp)
        ) {
            items(state.stations) { station ->
                StationCard(
                    station = station,
                    isSelected = station.id == state.selectedStation.id,
                    onSelect = { onStationSelect(station) },
                    onPayAtPumpClick = {
                        onStationSelect(station)
                        onNavigate(AppNavDestination.PAY_AT_PUMP)
                    },
                    onChargeClick = {
                        onStationSelect(station)
                        onNavigate(AppNavDestination.EV_CHARGING)
                    }
                )
            }
        }
    }
}

@Composable
private fun FilterChip(label: String, isSelected: Boolean) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) BpGreenContainer else GraphiteCard)
            .border(0.5.dp, if (isSelected) BpGreen else SatinBorder, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(
            text = label,
            style = MachineTextStyleSmall,
            color = if (isSelected) BpGreen else TextGrayMuted,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
