package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.ChargingSession
import com.example.domain.ChargingSessionStatus
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun LiveChargeMeter(
    session: ChargingSession,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(GraphiteCard)
            .border(1.dp, SatinBorder, RoundedCornerShape(20.dp))
            .padding(20.dp)
            .testTag("live_charge_meter")
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = null,
                        tint = BpGreen,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "BP PULSE ULTRA-FAST CHARGER ${session.chargerNumber}",
                        style = MachineTextStyleSmall,
                        color = TextGraySecondary
                    )
                }

                Text(
                    text = "${session.powerKw.toInt()} kW CCS",
                    style = MachineTextStyleSmall,
                    color = BpGreen,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Percentage Display
            Text(
                text = "${session.currentBatteryPercent}%",
                fontSize = 52.sp,
                fontFamily = MachineFontFamily,
                fontWeight = FontWeight.Bold,
                color = BpGreen
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Battery Progress Bar
            LinearProgressIndicator(
                progress = { session.currentBatteryPercent / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = BpGreen,
                trackColor = SatinBorder
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Energy & Cost Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "DELIVERED", style = MachineTextStyleSmall, color = TextGrayMuted)
                    Text(
                        text = "${String.format(Locale.UK, "%.1f", session.energyKWh)} kWh",
                        fontSize = 18.sp,
                        fontFamily = MachineFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        color = TextWhitePrimary
                    )
                }

                Box(modifier = Modifier.width(1.dp).height(28.dp).background(SatinBorder))

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "RATE", style = MachineTextStyleSmall, color = TextGrayMuted)
                    Text(
                        text = "£${session.pricePerKWh}/kWh",
                        fontSize = 18.sp,
                        fontFamily = MachineFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        color = TextWhitePrimary
                    )
                }

                Box(modifier = Modifier.width(1.dp).height(28.dp).background(SatinBorder))

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "TOTAL COST", style = MachineTextStyleSmall, color = TextGrayMuted)
                    Text(
                        text = "£${String.format(Locale.UK, "%.2f", session.totalCost)}",
                        fontSize = 18.sp,
                        fontFamily = MachineFontFamily,
                        fontWeight = FontWeight.Bold,
                        color = BpGreen
                    )
                }
            }
        }
    }
}
