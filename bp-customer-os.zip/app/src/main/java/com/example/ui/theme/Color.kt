package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// BP Brand Colors
val BpGreen = Color(0xFF00D215)
val BpGreenGlow = Color(0x6600D215)
val BpGreenContainer = Color(0x1A00D215)
val BpGreenBorder = Color(0x4D00D215)

// Accent Colors
val BpAmber = Color(0xFFF27D26)
val BpAmberContainer = Color(0x1AF27D26)
val BpRed = Color(0xFFE53935)
val BpRedContainer = Color(0x1AE53935)

// Surface & Material System (Deep Graphite, Satin Metal, Translucent Glass)
val ObsidianBackground = Color(0xFF050505)
val GraphiteSurface = Color(0xFF101214)
val GraphiteCard = Color(0xFF17191D)
val SatinBorder = Color(0xFF282C32)
val SatinMetalLight = Color(0xFF383E46)

// Text Colors
val TextWhitePrimary = Color(0xFFF4F5F7)
val TextGraySecondary = Color(0xFF8F96A1)
val TextGrayMuted = Color(0xFF5A606A)
val MachineTextGreen = Color(0xFF00D215)

// Legacy Material 3 overrides
val DarkPrimary = BpGreen
val DarkSecondary = Color(0xFF282C32)
val DarkBackground = ObsidianBackground
val DarkSurface = GraphiteSurface
