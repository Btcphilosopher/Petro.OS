package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.BpCustomerUiState

@Composable
fun TripPlannerScreen(
    state: BpCustomerUiState,
    onStartRoute: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(20.dp)
            .testTag("trip_planner_screen_content"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "ARCHITECTURAL TRIP PLANNER",
            style = MachineTextStyleSmall,
            color = BpGreen
        )

        // Route Inputs Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(GraphiteCard)
                .border(1.dp, SatinBorder, RoundedCornerShape(18.dp))
                .padding(20.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(10.dp).clip(RoundedCornerShape(5.dp)).background(BpGreen))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(text = "ORIGIN: Sheffield, UK", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = TextWhitePrimary)
                }

                Box(modifier = Modifier.padding(start = 4.dp).width(2.dp).height(24.dp).background(SatinBorder))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(10.dp).clip(RoundedCornerShape(5.dp)).background(BpAmber))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(text = "DESTINATION: London, UK", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = TextWhitePrimary)
                }
            }
        }

        // Architectural Line Route Graphic
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Color(0xFF090B0E))
                .border(1.dp, SatinBorder, RoundedCornerShape(18.dp))
                .padding(16.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // Draw Architectural Route Node Line
                drawLine(
                    color = BpGreen,
                    start = Offset(w * 0.1f, h * 0.5f),
                    end = Offset(w * 0.9f, h * 0.5f),
                    strokeWidth = 4f
                )

                // Nodes
                drawCircle(color = BpGreen, radius = 10f, center = Offset(w * 0.1f, h * 0.5f))
                drawCircle(color = BpGreen, radius = 14f, center = Offset(w * 0.45f, h * 0.5f)) // BP Station stop
                drawCircle(color = BpAmber, radius = 10f, center = Offset(w * 0.9f, h * 0.5f))
            }

            Column(
                modifier = Modifier.align(Alignment.BottomStart).padding(8.dp)
            ) {
                Text(text = "RECOMMENDED REFUEL NODE: BP London Gateway", style = MachineTextStyleSmall, color = BpGreen)
                Text(text = "Distance: 142 mi · Est. Drive Time: 2h 20m · Fuel Required: 22.8 Litres", fontSize = 11.sp, color = TextGraySecondary)
            }
        }

        // Route Metrics Summary
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            TripMetricBox(label = "EST. DRIVE TIME", value = "2h 20m", modifier = Modifier.weight(1f))
            TripMetricBox(label = "EST. FUEL COST", value = "£34.20", modifier = Modifier.weight(1f))
            TripMetricBox(label = "BP STATIONS ON ROUTE", value = "14 Hubs", modifier = Modifier.weight(1f))
        }

        Button(
            onClick = onStartRoute,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("start_trip_navigation_btn"),
            colors = ButtonDefaults.buttonColors(containerColor = BpGreen, contentColor = ObsidianBackground),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(imageVector = Icons.Default.Navigation, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = "START BP JOURNEY NAVIGATION", style = MachineTextStyleSmall, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun TripMetricBox(label: String, value: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(GraphiteCard)
            .border(1.dp, SatinBorder, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Column {
            Text(text = label, style = MachineTextStyleSmall, color = TextGrayMuted, fontSize = 8.sp)
            Text(text = value, fontSize = 15.sp, fontFamily = MachineFontFamily, fontWeight = FontWeight.Bold, color = BpGreen)
        }
    }
}
