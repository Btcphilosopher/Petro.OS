package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.Vehicle
import com.example.ui.theme.*
import com.example.viewmodel.AppNavDestination

@Composable
fun TopHeaderBar(
    customerName: String,
    vehicle: Vehicle,
    onGarageClick: () -> Unit = {},
    onSecurityClick: () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(ObsidianBackground)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(BpGreen)
                        .shadow(6.dp, CircleShape, spotColor = BpGreen)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "BP IDENTITY ENABLED",
                    style = MachineTextStyleSmall,
                    color = TextGraySecondary
                )
            }
            Text(
                text = "Good morning, $customerName",
                fontSize = 20.sp,
                fontWeight = FontWeight.Normal,
                color = TextWhitePrimary
            )
        }

        // Vehicle Quick Telemetry Badge
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(GraphiteCard)
                .border(1.dp, SatinBorder, RoundedCornerShape(12.dp))
                .clickable { onGarageClick() }
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${vehicle.make} ${vehicle.model.take(6)}",
                    style = MachineTextStyleSmall,
                    color = TextGrayMuted
                )
                Text(
                    text = "${vehicle.estimatedRangeMiles} mi range",
                    fontSize = 13.sp,
                    fontFamily = MachineFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = BpGreen
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
                imageVector = Icons.Default.DirectionsCar,
                contentDescription = "Garage",
                tint = TextGraySecondary,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
fun BottomNavBar(
    currentDestination: AppNavDestination,
    onNavigate: (AppNavDestination) -> Unit,
    onHeroStartJourney: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(ObsidianBackground)
            .border(width = 0.5.dp, color = SatinBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavItem(
                icon = Icons.Default.Home,
                label = "HOME",
                isSelected = currentDestination == AppNavDestination.HOME,
                onClick = { onNavigate(AppNavDestination.HOME) },
                tag = "nav_home"
            )

            NavItem(
                icon = Icons.Default.Map,
                label = "STATIONS",
                isSelected = currentDestination == AppNavDestination.STATIONS,
                onClick = { onNavigate(AppNavDestination.STATIONS) },
                tag = "nav_stations"
            )

            // Central Hero Action Button
            Box(
                modifier = Modifier
                    .offset(y = (-12).dp)
                    .size(58.dp)
                    .shadow(12.dp, CircleShape, spotColor = BpGreenGlow)
                    .clip(CircleShape)
                    .background(BpGreen)
                    .clickable { onHeroStartJourney() }
                    .testTag("nav_hero_start_journey"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.LocalGasStation,
                    contentDescription = "Start BP Journey",
                    tint = ObsidianBackground,
                    modifier = Modifier.size(28.dp)
                )
            }

            NavItem(
                icon = Icons.Default.CreditCard,
                label = "CARD",
                isSelected = currentDestination == AppNavDestination.CARD,
                onClick = { onNavigate(AppNavDestination.CARD) },
                tag = "nav_card"
            )

            NavItem(
                icon = Icons.Default.ReceiptLong,
                label = "ACTIVITY",
                isSelected = currentDestination == AppNavDestination.ACTIVITY,
                onClick = { onNavigate(AppNavDestination.ACTIVITY) },
                tag = "nav_activity"
            )
        }
    }
}

@Composable
private fun NavItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    tag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .testTag(tag)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isSelected) BpGreen else TextGrayMuted,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            style = MachineTextStyleSmall,
            color = if (isSelected) BpGreen else TextGrayMuted,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
