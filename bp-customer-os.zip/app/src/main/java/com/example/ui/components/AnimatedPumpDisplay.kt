package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.FuelSession
import com.example.domain.FuelSessionStatus
import com.example.domain.FuelType
import com.example.ui.theme.*

enum class PumpViewMode { NORMAL, TECHNICAL, NIGHT, SERVICE }

@Composable
fun AnimatedPumpDisplay(
    session: FuelSession,
    onFuelTypeSelected: (FuelType) -> Unit = {},
    modifier: Modifier = Modifier
) {
    var mode by remember { mutableStateOf(PumpViewMode.NORMAL) }

    val modeBg by animateColorAsState(
        targetValue = when (mode) {
            PumpViewMode.NORMAL -> GraphiteCard
            PumpViewMode.TECHNICAL -> Color(0xFF09120B)
            PumpViewMode.NIGHT -> Color(0xFF07080A)
            PumpViewMode.SERVICE -> Color(0xFF1C1309)
        }, label = "pump_mode_bg"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(modeBg)
            .border(1.dp, SatinBorder, RoundedCornerShape(20.dp))
            .padding(18.dp)
            .testTag("animated_pump_display")
    ) {
        Column {
            // Mode Selector Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocalGasStation,
                        contentDescription = null,
                        tint = BpGreen,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "FORECOUR DISPENSER",
                        style = MachineTextStyleSmall,
                        color = TextGraySecondary
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    PumpViewMode.entries.forEach { m ->
                        val isSelected = m == mode
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSelected) BpGreenContainer else Color.Transparent)
                                .border(0.5.dp, if (isSelected) BpGreen else SatinBorder, RoundedCornerShape(4.dp))
                                .clickable { mode = m }
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = m.name.take(3),
                                style = MachineTextStyleSmall,
                                color = if (isSelected) BpGreen else TextGrayMuted
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Graphical Nozzle & Pump Unit
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Pump Tower Visual
                Box(
                    modifier = Modifier
                        .width(90.dp)
                        .height(110.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF0B0D0F))
                        .border(1.dp, SatinBorder, RoundedCornerShape(12.dp))
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "BP PUMP",
                            style = MachineTextStyleSmall,
                            color = BpGreen
                        )
                        Text(
                            text = String.format("%02d", session.pumpNumber),
                            fontSize = 32.sp,
                            fontFamily = MachineFontFamily,
                            fontWeight = FontWeight.Bold,
                            color = TextWhitePrimary
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(if (session.status == FuelSessionStatus.FUELING) BpGreen else SatinBorder)
                        )
                    }
                }

                // Fuel Grade Selector Buttons
                Column(
                    modifier = Modifier.weight(1f).padding(start = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FuelType.entries.forEach { fuel ->
                        val isSelected = session.fuelType == fuel
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) BpGreenContainer else Color(0xFF101215))
                                .border(
                                    1.dp,
                                    if (isSelected) BpGreen else SatinBorder,
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable { onFuelTypeSelected(fuel) }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = fuel.displayName,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isSelected) TextWhitePrimary else TextGraySecondary
                                    )
                                    Text(
                                        text = "£${fuel.defaultPricePerLitre}/L",
                                        style = MachineTextStyleSmall,
                                        color = if (isSelected) BpGreen else TextGrayMuted
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .clip(CircleShape)
                                        .background(if (isSelected) BpGreen else SatinBorder)
                                )
                            }
                        }
                    }
                }
            }

            // Technical details view when mode == TECHNICAL
            if (mode == PumpViewMode.TECHNICAL) {
                Spacer(modifier = Modifier.height(12.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF040A05))
                        .border(0.5.dp, BpGreenBorder, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Column {
                        Text(
                            text = "PUMP CONTROLLER DIAGNOSTICS",
                            style = MachineTextStyleSmall,
                            color = BpGreen
                        )
                        Text(
                            text = "FLOW METER PULSE: OK | SOLENOID VALVE: OPEN | CALIBRATION: BS EN 228",
                            fontSize = 10.sp,
                            fontFamily = MachineFontFamily,
                            color = TextGraySecondary
                        )
                    }
                }
            }
        }
    }
}
