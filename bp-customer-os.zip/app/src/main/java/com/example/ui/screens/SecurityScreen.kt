package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.BpCustomerUiState

@Composable
fun SecurityScreen(
    state: BpCustomerUiState
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 20.dp, vertical = 10.dp)
            .testTag("security_screen_content"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(text = "SECURITY CENTRE", style = MachineTextStyleSmall, color = BpGreen)

        // Status Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SecurityTile(
                icon = Icons.Default.Fingerprint,
                label = "BIOMETRICS",
                status = "ENABLED",
                modifier = Modifier.weight(1f)
            )
            SecurityTile(
                icon = Icons.Default.Nfc,
                label = "NFC ENCRYPTION",
                status = "ACTIVE",
                modifier = Modifier.weight(1f)
            )
            SecurityTile(
                icon = Icons.Default.Shield,
                label = "EVENTS LOGGED",
                status = "4 EVENTS",
                modifier = Modifier.weight(1f)
            )
        }

        Text(text = "RECENT AUTHORISATION AUDIT TRAIL", style = MachineTextStyleSmall, color = TextGraySecondary)

        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(state.securityEvents) { event ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(GraphiteCard)
                        .border(1.dp, SatinBorder, RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = event.timestamp, style = MachineTextStyleSmall, color = TextGrayMuted)
                            Text(text = event.eventType, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TextWhitePrimary)
                            Text(text = "${event.deviceName} · ${event.location}", fontSize = 11.sp, color = TextGraySecondary)
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(BpGreenContainer)
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(text = event.status, style = MachineTextStyleSmall, color = BpGreen, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SecurityTile(
    icon: ImageVector,
    label: String,
    status: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(GraphiteCard)
            .border(1.dp, SatinBorder, RoundedCornerShape(14.dp))
            .padding(12.dp)
    ) {
        Column {
            Icon(imageVector = icon, contentDescription = null, tint = BpGreen, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = label, style = MachineTextStyleSmall, color = TextGrayMuted, fontSize = 8.sp)
            Text(text = status, fontSize = 12.sp, fontFamily = MachineFontFamily, fontWeight = FontWeight.Bold, color = BpGreen)
        }
    }
}
