package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.FuelSessionStatus
import com.example.ui.components.BpCardView
import com.example.ui.theme.*
import com.example.viewmodel.AppNavDestination
import com.example.viewmodel.BpCustomerUiState

@Composable
fun HomeScreen(
    state: BpCustomerUiState,
    onNavigate: (AppNavDestination) -> Unit,
    onHeroStartDemo: () -> Unit,
    onLockCardToggle: () -> Unit,
    onSelectReceipt: (com.example.domain.Receipt?) -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp, vertical = 10.dp)
            .testTag("home_screen_content"),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Hero Demo Banner
        if (state.isDemoRunning) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(BpGreenContainer)
                    .border(1.dp, BpGreen, RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = BpGreen,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(text = "HERO DEMO SEQUENCE ACTIVE", style = MachineTextStyleSmall, color = BpGreen, fontWeight = FontWeight.Bold)
                        Text(text = state.demoStepMessage ?: "Executing BP Journey...", fontSize = 12.sp, color = TextWhitePrimary)
                    }
                }
            }
        }

        // Digital BP Card Object
        Column {
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ACTIVE INSTRUMENT",
                    style = MachineTextStyleSmall,
                    color = TextGraySecondary
                )
                Text(
                    text = "TAP FOR CONTROLS",
                    style = MachineTextStyleSmall,
                    color = BpGreen
                )
            }

            BpCardView(
                card = state.bpCard,
                isLocked = state.isCardLocked,
                onClick = { onNavigate(AppNavDestination.CARD) }
            )
        }

        // Contextual "YOUR NEXT STOP" Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(Color(0xFF1B221C), Color(0xFF101311))
                    )
                )
                .border(1.dp, BpGreenBorder, RoundedCornerShape(20.dp))
                .padding(20.dp)
                .testTag("next_stop_card")
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "YOUR NEXT STOP",
                        style = MachineTextStyleSmall,
                        color = BpGreen,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "1.2 MILES AWAY",
                        style = MachineTextStyleSmall,
                        color = TextGraySecondary
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = state.selectedStation.name,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextWhitePrimary
                )
                Text(
                    text = "${state.selectedStation.address} · Fuel & EV Pulse Available",
                    fontSize = 13.sp,
                    color = TextGraySecondary
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { onNavigate(AppNavDestination.PAY_AT_PUMP) },
                        modifier = Modifier.weight(1f).height(42.dp).testTag("start_journey_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = BpGreen, contentColor = ObsidianBackground),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.LocalGasStation, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "PAY AT PUMP", style = MachineTextStyleSmall, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { onNavigate(AppNavDestination.EV_CHARGING) },
                        modifier = Modifier.weight(1f).height(42.dp).testTag("ev_charge_home_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = SatinBorder, contentColor = TextWhitePrimary),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "CHARGE", style = MachineTextStyleSmall, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Quick Command Toolbar Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            QuickToolChip(
                icon = Icons.Default.Map,
                label = "STATIONS",
                onClick = { onNavigate(AppNavDestination.STATIONS) },
                modifier = Modifier.weight(1f)
            )
            QuickToolChip(
                icon = Icons.Default.AltRoute,
                label = "TRIP PLAN",
                onClick = { onNavigate(AppNavDestination.TRIP_PLANNER) },
                modifier = Modifier.weight(1f)
            )
            QuickToolChip(
                icon = Icons.Default.DirectionsCar,
                label = "GARAGE",
                onClick = { onNavigate(AppNavDestination.GARAGE) },
                modifier = Modifier.weight(1f)
            )
            QuickToolChip(
                icon = Icons.Default.CardGiftcard,
                label = "REWARDS",
                onClick = { onNavigate(AppNavDestination.REWARDS) },
                modifier = Modifier.weight(1f)
            )
        }

        // Data Grid: Last Transaction + Rewards Balance
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Last Transaction Card
            val lastTx = state.transactions.firstOrNull()
            Box(
                modifier = Modifier
                    .weight(1.2f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(GraphiteCard)
                    .border(1.dp, SatinBorder, RoundedCornerShape(16.dp))
                    .clickable { onSelectReceipt(state.latestReceipt) }
                    .padding(16.dp)
            ) {
                Column {
                    Text(text = "LAST TRANSACTION", style = MachineTextStyleSmall, color = TextGrayMuted)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "£${lastTx?.amount ?: 64.21}",
                        fontSize = 22.sp,
                        fontFamily = MachineFontFamily,
                        fontWeight = FontWeight.Bold,
                        color = TextWhitePrimary
                    )
                    Text(
                        text = "${lastTx?.details ?: "42.7 L Petrol"} · ${lastTx?.stationName?.take(12) ?: "BP Sheffield"}",
                        fontSize = 11.sp,
                        color = TextGraySecondary
                    )
                }
            }

            // Rewards Card
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(GraphiteCard)
                    .border(1.dp, BpGreenBorder, RoundedCornerShape(16.dp))
                    .clickable { onNavigate(AppNavDestination.REWARDS) }
                    .padding(16.dp)
            ) {
                Column {
                    Text(text = "BP REWARDS", style = MachineTextStyleSmall, color = BpGreen)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "${state.rewardsAccount.totalPoints}",
                        fontSize = 22.sp,
                        fontFamily = MachineFontFamily,
                        fontWeight = FontWeight.Bold,
                        color = BpGreen
                    )
                    Text(
                        text = "POINTS BALANCE",
                        style = MachineTextStyleSmall,
                        color = TextGrayMuted
                    )
                }
            }
        }

        // Vehicle Summary Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(GraphiteCard)
                .border(1.dp, SatinBorder, RoundedCornerShape(16.dp))
                .clickable { onNavigate(AppNavDestination.GARAGE) }
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "CURRENT VEHICLE", style = MachineTextStyleSmall, color = TextGrayMuted)
                    Text(
                        text = "${state.selectedVehicle.make} ${state.selectedVehicle.model}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextWhitePrimary
                    )
                    Text(
                        text = "Reg: ${state.selectedVehicle.registration} · ${state.selectedVehicle.fuelType.name}",
                        fontSize = 12.sp,
                        color = TextGraySecondary
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${state.selectedVehicle.estimatedRangeMiles} mi",
                        fontSize = 20.sp,
                        fontFamily = MachineFontFamily,
                        fontWeight = FontWeight.Bold,
                        color = BpGreen
                    )
                    Text(
                        text = "RANGE ESTIMATE",
                        style = MachineTextStyleSmall,
                        color = TextGrayMuted
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}

@Composable
private fun QuickToolChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(GraphiteCard)
            .border(1.dp, SatinBorder, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(imageVector = icon, contentDescription = label, tint = BpGreen, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = label, style = MachineTextStyleSmall, color = TextWhitePrimary, fontSize = 8.sp)
        }
    }
}
