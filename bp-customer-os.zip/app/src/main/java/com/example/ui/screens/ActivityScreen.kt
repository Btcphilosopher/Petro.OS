package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.Receipt
import com.example.domain.Transaction
import com.example.ui.theme.*
import com.example.viewmodel.BpCustomerUiState

@Composable
fun ActivityScreen(
    state: BpCustomerUiState,
    onSelectReceipt: (Receipt?) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 20.dp, vertical = 10.dp)
            .testTag("activity_screen_content"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Analytics Summary Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(GraphiteCard)
                .border(1.dp, SatinBorder, RoundedCornerShape(18.dp))
                .padding(20.dp)
        ) {
            Column {
                Text(text = "MY MOBILITY · SPENDING THIS MONTH", style = MachineTextStyleSmall, color = TextGrayMuted)
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "£392.32",
                    fontSize = 36.sp,
                    fontFamily = MachineFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = TextWhitePrimary
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    MetricMini(label = "PETROL FUELS", value = "£284.72")
                    MetricMini(label = "EV CHARGING", value = "£76.40")
                    MetricMini(label = "WILD BEAN SHOP", value = "£31.20")
                }
            }
        }

        Text(
            text = "TRANSACTION LEDGER & RECEIPTS",
            style = MachineTextStyleSmall,
            color = TextGraySecondary
        )

        // Ledger List
        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(state.transactions) { tx ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(GraphiteCard)
                        .border(1.dp, SatinBorder, RoundedCornerShape(14.dp))
                        .clickable { onSelectReceipt(state.latestReceipt) }
                        .padding(16.dp)
                        .testTag("transaction_row_${tx.id}")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${tx.date} · ${tx.time}",
                                style = MachineTextStyleSmall,
                                color = TextGrayMuted
                            )
                            Text(
                                text = tx.stationName,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextWhitePrimary
                            )
                            Text(
                                text = "${tx.details} · ${tx.pumpOrChargerNumber}",
                                fontSize = 12.sp,
                                color = TextGraySecondary
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "£${tx.amount}",
                                fontSize = 16.sp,
                                fontFamily = MachineFontFamily,
                                fontWeight = FontWeight.Bold,
                                color = TextWhitePrimary
                            )
                            Text(
                                text = "+${tx.pointsEarned} PTS",
                                style = MachineTextStyleSmall,
                                color = BpGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricMini(label: String, value: String) {
    Column {
        Text(text = label, style = MachineTextStyleSmall, color = TextGrayMuted, fontSize = 8.sp)
        Text(text = value, fontSize = 14.sp, fontFamily = MachineFontFamily, fontWeight = FontWeight.SemiBold, color = BpGreen)
    }
}
