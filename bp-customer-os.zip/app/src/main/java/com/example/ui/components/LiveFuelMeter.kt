package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.FuelSession
import com.example.domain.FuelSessionStatus
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun LiveFuelMeter(
    session: FuelSession,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(GraphiteCard)
            .border(1.dp, SatinBorder, RoundedCornerShape(16.dp))
            .padding(20.dp)
            .testTag("live_fuel_meter")
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "PUMP ${String.format(Locale.UK, "%02d", session.pumpNumber)} · ${session.fuelType.displayName.uppercase()}",
                    style = MachineTextStyleSmall,
                    color = TextGraySecondary
                )

                val (statusColor, statusText) = when (session.status) {
                    FuelSessionStatus.FUELING -> BpGreen to "FUELING ACTIVE"
                    FuelSessionStatus.PUMP_UNLOCKED -> BpGreen to "READY TO DISPENSE"
                    FuelSessionStatus.AUTHORIZING -> BpAmber to "AUTHORISING..."
                    FuelSessionStatus.COMPLETED -> BpGreen to "FUELING COMPLETE"
                    else -> TextGrayMuted to "PUMP IDLE"
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(statusColor)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = statusText,
                        style = MachineTextStyleSmall,
                        color = statusColor,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Main Cost Readout
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "TOTAL COST",
                    style = MachineTextStyleSmall,
                    color = TextGrayMuted
                )
                Text(
                    text = "£${String.format(Locale.UK, "%.2f", session.totalCost)}",
                    fontSize = 44.sp,
                    fontFamily = MachineFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = if (session.status == FuelSessionStatus.FUELING) BpGreen else TextWhitePrimary
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Litres & Flow Rate Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "VOLUME", style = MachineTextStyleSmall, color = TextGrayMuted)
                    Text(
                        text = "${String.format(Locale.UK, "%.2f", session.litres)} L",
                        fontSize = 20.sp,
                        fontFamily = MachineFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        color = TextWhitePrimary
                    )
                }

                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(32.dp)
                        .background(SatinBorder)
                )

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "UNIT PRICE", style = MachineTextStyleSmall, color = TextGrayMuted)
                    Text(
                        text = "£${String.format(Locale.UK, "%.3f", session.pricePerLitre)}/L",
                        fontSize = 20.sp,
                        fontFamily = MachineFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        color = TextWhitePrimary
                    )
                }

                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(32.dp)
                        .background(SatinBorder)
                )

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "FLOW RATE", style = MachineTextStyleSmall, color = TextGrayMuted)
                    Text(
                        text = if (session.status == FuelSessionStatus.FUELING)
                            "${String.format(Locale.UK, "%.1f", session.flowRateLitresPerMin)} L/m"
                        else "0.0 L/m",
                        fontSize = 20.sp,
                        fontFamily = MachineFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        color = if (session.status == FuelSessionStatus.FUELING) BpGreen else TextGraySecondary
                    )
                }
            }
        }
    }
}
