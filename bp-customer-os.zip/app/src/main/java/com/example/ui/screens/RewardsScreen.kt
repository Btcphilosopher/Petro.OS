package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.Offer
import com.example.ui.theme.*
import com.example.viewmodel.BpCustomerUiState

@Composable
fun RewardsScreen(
    state: BpCustomerUiState,
    onActivateOffer: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 20.dp, vertical = 10.dp)
            .testTag("rewards_screen_content"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Physical Token Inspired Points Balance Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(GraphiteCard)
                .border(1.dp, BpGreenBorder, RoundedCornerShape(20.dp))
                .padding(22.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "BP REWARDS ASSETS", style = MachineTextStyleSmall, color = BpGreen)
                    Text(text = state.rewardsAccount.tierName, style = MachineTextStyleSmall, color = TextWhitePrimary, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = "${state.rewardsAccount.totalPoints}",
                        fontSize = 42.sp,
                        fontFamily = MachineFontFamily,
                        fontWeight = FontWeight.Bold,
                        color = BpGreen
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "POINTS",
                        style = MachineTextStyleSmall,
                        color = TextGraySecondary,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                Text(
                    text = "Lifetime Earned: ${state.rewardsAccount.lifetimePoints} pts · ${state.rewardsAccount.pointsToNextTier} pts to Premier Gold",
                    fontSize = 11.sp,
                    color = TextGraySecondary
                )
            }
        }

        Text(
            text = "INTELLIGENT ROUTE OFFERS",
            style = MachineTextStyleSmall,
            color = TextGraySecondary
        )

        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(state.offers) { offer ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(GraphiteCard)
                        .border(1.dp, SatinBorder, RoundedCornerShape(16.dp))
                        .padding(16.dp)
                        .testTag("offer_card_${offer.id}")
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = offer.title,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhitePrimary
                                )
                                Text(
                                    text = offer.description,
                                    fontSize = 12.sp,
                                    color = TextGraySecondary
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(BpGreenContainer)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = offer.discountText,
                                    style = MachineTextStyleSmall,
                                    color = BpGreen,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "VALID UNTIL ${offer.validUntil}",
                                style = MachineTextStyleSmall,
                                color = TextGrayMuted
                            )

                            Button(
                                onClick = { onActivateOffer(offer.id) },
                                enabled = !offer.isActivated,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (offer.isActivated) SatinBorder else BpGreen,
                                    contentColor = if (offer.isActivated) TextGrayMuted else ObsidianBackground
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = if (offer.isActivated) "ACTIVATED" else "ACTIVATE",
                                    style = MachineTextStyleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
