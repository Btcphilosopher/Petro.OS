package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.Vehicle
import com.example.ui.theme.*
import com.example.viewmodel.BpCustomerUiState

@Composable
fun GarageScreen(
    state: BpCustomerUiState,
    onSelectVehicle: (Vehicle) -> Unit,
    onAddVehicleClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 20.dp, vertical = 10.dp)
            .testTag("garage_screen_content"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = "MY VEHICLE GARAGE", style = MachineTextStyleSmall, color = BpGreen)
                Text(text = "ENERGY & TELEMETRY MODELS", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextWhitePrimary)
            }

            IconButton(
                onClick = onAddVehicleClick,
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(BpGreenContainer)
                    .border(0.5.dp, BpGreen, RoundedCornerShape(10.dp))
                    .testTag("add_vehicle_btn")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Vehicle", tint = BpGreen)
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(state.vehicles) { vehicle ->
                val isSelected = vehicle.id == state.selectedVehicle.id
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(if (isSelected) Color(0xFF1B221D) else GraphiteCard)
                        .border(1.5.dp, if (isSelected) BpGreen else SatinBorder, RoundedCornerShape(18.dp))
                        .clickable { onSelectVehicle(vehicle) }
                        .padding(18.dp)
                        .testTag("vehicle_card_${vehicle.id}")
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column {
                                Text(
                                    text = "${vehicle.make} ${vehicle.model}",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhitePrimary
                                )
                                Text(
                                    text = "Reg: ${vehicle.registration} · Year: ${vehicle.year}",
                                    fontSize = 12.sp,
                                    color = TextGraySecondary
                                )
                            }

                            if (isSelected) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(BpGreen)
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(text = "ACTIVE", style = MachineTextStyleSmall, color = ObsidianBackground, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = "FUEL GRADE", style = MachineTextStyleSmall, color = TextGrayMuted)
                                Text(text = vehicle.preferredFuel.displayName, fontSize = 13.sp, color = TextWhitePrimary)
                            }

                            Column {
                                Text(text = "EFFICIENCY", style = MachineTextStyleSmall, color = TextGrayMuted)
                                Text(text = vehicle.efficiency, fontSize = 13.sp, color = TextWhitePrimary)
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = "EST. RANGE", style = MachineTextStyleSmall, color = TextGrayMuted)
                                Text(
                                    text = "${vehicle.estimatedRangeMiles} mi",
                                    fontSize = 16.sp,
                                    fontFamily = MachineFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    color = BpGreen
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
