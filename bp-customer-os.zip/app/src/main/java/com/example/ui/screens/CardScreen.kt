package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.BpCardView
import com.example.ui.theme.*
import com.example.viewmodel.BpCustomerUiState

@Composable
fun CardScreen(
    state: BpCustomerUiState,
    onLockCardToggle: () -> Unit,
    onShowNotification: (String) -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp, vertical = 10.dp)
            .testTag("card_screen_content"),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Digital BP Card
        Column {
            Text(
                text = "PERSISTENT IDENTITY OBJECT",
                style = MachineTextStyleSmall,
                color = TextGraySecondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            BpCardView(
                card = state.bpCard,
                isLocked = state.isCardLocked,
                onClick = onLockCardToggle
            )
        }

        // Card Control Centre Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(GraphiteCard)
                .border(1.dp, SatinBorder, RoundedCornerShape(18.dp))
                .padding(20.dp)
        ) {
            Column {
                Text(
                    text = "CARD CONTROL CENTRE",
                    style = MachineTextStyleSmall,
                    color = BpGreen,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Card Lock/Unlock Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (state.isCardLocked) "Card is Currently Locked" else "Card Status: Active & Ready",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextWhitePrimary
                        )
                        Text(
                            text = "Instantly freeze all fuel, charging and store payments",
                            fontSize = 12.sp,
                            color = TextGraySecondary
                        )
                    }

                    Switch(
                        checked = !state.isCardLocked,
                        onCheckedChange = { onLockCardToggle() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = ObsidianBackground,
                            checkedTrackColor = BpGreen,
                            uncheckedThumbColor = TextGrayMuted,
                            uncheckedTrackColor = SatinBorder
                        ),
                        modifier = Modifier.testTag("lock_card_toggle")
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = SatinBorder)
                Spacer(modifier = Modifier.height(16.dp))

                // Monthly Spend Progress
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "MONTHLY SPEND LIMIT", style = MachineTextStyleSmall, color = TextGrayMuted)
                    Text(
                        text = "£${state.bpCard.currentSpendMonthly} / £${state.bpCard.spendingLimitMonthly}",
                        fontSize = 14.sp,
                        fontFamily = MachineFontFamily,
                        fontWeight = FontWeight.Bold,
                        color = TextWhitePrimary
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                LinearProgressIndicator(
                    progress = { (state.bpCard.currentSpendMonthly / state.bpCard.spendingLimitMonthly).toFloat() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = BpGreen,
                    trackColor = SatinBorder
                )
            }
        }

        // Wallet & Payment Methods Section
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(GraphiteCard)
                .border(1.dp, SatinBorder, RoundedCornerShape(18.dp))
                .padding(20.dp)
        ) {
            Column {
                Text(
                    text = "MY WALLET & PAYMENT METHODS",
                    style = MachineTextStyleSmall,
                    color = TextGraySecondary
                )

                Spacer(modifier = Modifier.height(14.dp))

                WalletRow(
                    title = "BP Card (•••• 4821)",
                    subtitle = "Default Fuel & EV Payment Method",
                    isSelected = true,
                    onClick = { onShowNotification("BP Card selected as default payment method") }
                )

                Spacer(modifier = Modifier.height(10.dp))

                WalletRow(
                    title = "Barclays Visa Debit (•••• 9102)",
                    subtitle = "Secondary Backup Account",
                    isSelected = false,
                    onClick = { onShowNotification("Switched to Visa Debit backup") }
                )

                Spacer(modifier = Modifier.height(10.dp))

                WalletRow(
                    title = "Google Pay / NFC Express",
                    subtitle = "Contactless Phone Gateway Active",
                    isSelected = false,
                    onClick = { onShowNotification("Google Pay Express activated") }
                )
            }
        }

        // Quick Security & Controls Actions List
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            ControlActionRow(
                icon = Icons.Default.VpnKey,
                title = "View PIN Guidance",
                subtitle = "Encrypted PIN retrieval available via biometrics",
                onClick = { onShowNotification("PIN Guidance: [4 8 2 1] verified by biometrics") }
            )

            ControlActionRow(
                icon = Icons.Default.Shield,
                title = "Biometric Passcode",
                subtitle = "Requires Fingerprint / Face ID for transactions over £100",
                onClick = { onShowNotification("Biometric Authentication Settings updated") }
            )

            ControlActionRow(
                icon = Icons.Default.CreditCardOff,
                title = "Report Lost or Request Replacement",
                subtitle = "Issue a replacement digital token instantly",
                onClick = { onShowNotification("Replacement card token dispatched to digital wallet") }
            )
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}

@Composable
private fun WalletRow(
    title: String,
    subtitle: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) BpGreenContainer else Color(0xFF101215))
            .border(0.5.dp, if (isSelected) BpGreen else SatinBorder, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TextWhitePrimary)
                Text(text = subtitle, fontSize = 11.sp, color = TextGraySecondary)
            }

            if (isSelected) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(BpGreen)
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(text = "DEFAULT", style = MachineTextStyleSmall, color = ObsidianBackground, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun ControlActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(GraphiteCard)
            .border(1.dp, SatinBorder, RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = icon, contentDescription = null, tint = BpGreen, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TextWhitePrimary)
                Text(text = subtitle, fontSize = 11.sp, color = TextGraySecondary)
            }
        }
    }
}
