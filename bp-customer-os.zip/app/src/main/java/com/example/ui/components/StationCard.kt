package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.Station
import com.example.ui.theme.*

@Composable
fun StationCard(
    station: Station,
    isSelected: Boolean = false,
    onSelect: () -> Unit = {},
    onPayAtPumpClick: () -> Unit = {},
    onChargeClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(if (isSelected) Color(0xFF1B201D) else GraphiteCard)
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) BpGreen else SatinBorder,
                shape = RoundedCornerShape(18.dp)
            )
            .clickable { onSelect() }
            .padding(18.dp)
            .testTag("station_card_${station.id}")
    ) {
        Column {
            // Header: Name & Distance
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = station.name,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextWhitePrimary
                    )
                    Text(
                        text = "${station.address} · ${station.distanceMiles} mi",
                        fontSize = 12.sp,
                        color = TextGraySecondary
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(BpGreenContainer)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (station.isOpen) "OPEN 24/7" else "CLOSED",
                        style = MachineTextStyleSmall,
                        color = BpGreen,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Fuel & EV Prices Summary
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Petrol Column
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocalGasStation,
                        contentDescription = null,
                        tint = BpGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(text = "Unleaded", style = MachineTextStyleSmall, color = TextGrayMuted)
                        Text(
                            text = "£${station.unleadedPrice}/L",
                            fontSize = 14.sp,
                            fontFamily = MachineFontFamily,
                            fontWeight = FontWeight.SemiBold,
                            color = TextWhitePrimary
                        )
                    }
                }

                // Diesel Column
                Column {
                    Text(text = "Diesel", style = MachineTextStyleSmall, color = TextGrayMuted)
                    Text(
                        text = "£${station.dieselPrice}/L",
                        fontSize = 14.sp,
                        fontFamily = MachineFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        color = TextWhitePrimary
                    )
                }

                // EV Pulse Column
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = null,
                        tint = BpAmber,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(text = "EV Pulse", style = MachineTextStyleSmall, color = TextGrayMuted)
                        Text(
                            text = "${station.availableChargersCount}/${station.totalChargersCount} Free",
                            fontSize = 14.sp,
                            fontFamily = MachineFontFamily,
                            fontWeight = FontWeight.SemiBold,
                            color = BpAmber
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onPayAtPumpClick,
                    modifier = Modifier.weight(1f).height(40.dp).testTag("card_pay_at_pump_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = BpGreen, contentColor = ObsidianBackground),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(text = "PAY AT PUMP", style = MachineTextStyleSmall, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onChargeClick,
                    modifier = Modifier.weight(1f).height(40.dp).testTag("card_charge_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = SatinBorder, contentColor = TextWhitePrimary),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(text = "CHARGE", style = MachineTextStyleSmall, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
