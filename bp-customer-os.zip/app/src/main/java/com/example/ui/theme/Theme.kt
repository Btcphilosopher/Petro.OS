package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val BpDarkColorScheme = darkColorScheme(
    primary = BpGreen,
    onPrimary = ObsidianBackground,
    primaryContainer = BpGreenContainer,
    onPrimaryContainer = BpGreen,
    secondary = SatinBorder,
    onSecondary = TextWhitePrimary,
    background = ObsidianBackground,
    onBackground = TextWhitePrimary,
    surface = GraphiteSurface,
    onSurface = TextWhitePrimary,
    surfaceVariant = GraphiteCard,
    onSurfaceVariant = TextGraySecondary,
    error = BpRed,
    onError = TextWhitePrimary
)

@Composable
fun BpCustomerOsTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = BpDarkColorScheme,
        typography = BpTypography,
        content = content
    )
}
