package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.domain.Receipt
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun ReceiptDialog(
    receipt: Receipt?,
    onDismiss: () -> Unit,
    onShare: () -> Unit = {},
    onDownload: () -> Unit = {}
) {
    if (receipt == null) return

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF131518))
                .border(1.dp, SatinBorder, RoundedCornerShape(20.dp))
                .padding(22.dp)
                .testTag("digital_receipt_modal")
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // Header & Close
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "bp",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = TextWhitePrimary
                    )

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_receipt_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextGraySecondary
                        )
                    }
                }

                Text(
                    text = "DIGITAL TAX RECEIPT",
                    style = MachineTextStyleSmall,
                    color = BpGreen,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Station Info
                Text(
                    text = receipt.stationName,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextWhitePrimary,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = receipt.stationAddress,
                    fontSize = 12.sp,
                    color = TextGraySecondary,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "VAT REG: ${receipt.vatNumber}",
                    style = MachineTextStyleSmall,
                    color = TextGrayMuted
                )

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = SatinBorder)
                Spacer(modifier = Modifier.height(16.dp))

                // Line Items Table
                ReceiptRow(label = "DATE & TIME", value = "${receipt.date} · ${receipt.time}")
                ReceiptRow(label = "PUMP / DISPENSER", value = receipt.pumpNumber)
                ReceiptRow(label = "FUEL GRADE", value = receipt.fuelType)
                ReceiptRow(
                    label = "QUANTITY",
                    value = "${String.format(Locale.UK, "%.2f", receipt.litres)} Litres"
                )
                ReceiptRow(
                    label = "UNIT PRICE",
                    value = "£${String.format(Locale.UK, "%.3f", receipt.pricePerLitre)}/L"
                )

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = SatinBorder)
                Spacer(modifier = Modifier.height(12.dp))

                ReceiptRow(
                    label = "NET SUBTOTAL",
                    value = "£${String.format(Locale.UK, "%.2f", receipt.subtotal)}"
                )
                ReceiptRow(
                    label = "VAT (20%)",
                    value = "£${String.format(Locale.UK, "%.2f", receipt.vatAmount)}"
                )
                ReceiptRow(
                    label = "TOTAL PAID",
                    value = "£${String.format(Locale.UK, "%.2f", receipt.total)}",
                    isHighlight = true
                )

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = SatinBorder)
                Spacer(modifier = Modifier.height(12.dp))

                ReceiptRow(label = "PAYMENT METHOD", value = receipt.paymentMethod)
                ReceiptRow(label = "AUTH CODE", value = receipt.authCode)
                ReceiptRow(label = "BP REWARDS EARNED", value = "+${receipt.pointsEarned} Points")

                Spacer(modifier = Modifier.height(20.dp))

                // Action Buttons (Share / Download)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onShare,
                        modifier = Modifier.weight(1f).height(44.dp).testTag("share_receipt_btn"),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextWhitePrimary),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(SatinBorder))
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "SHARE", style = MachineTextStyleSmall)
                    }

                    Button(
                        onClick = onDownload,
                        modifier = Modifier.weight(1f).height(44.dp).testTag("download_receipt_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = BpGreen, contentColor = ObsidianBackground)
                    ) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "DOWNLOAD PDF", style = MachineTextStyleSmall, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun ReceiptRow(
    label: String,
    value: String,
    isHighlight: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MachineTextStyleSmall,
            color = if (isHighlight) BpGreen else TextGrayMuted
        )
        Text(
            text = value,
            fontSize = if (isHighlight) 16.sp else 13.sp,
            fontFamily = MachineFontFamily,
            fontWeight = if (isHighlight) FontWeight.Bold else FontWeight.Medium,
            color = if (isHighlight) BpGreen else TextWhitePrimary
        )
    }
}
