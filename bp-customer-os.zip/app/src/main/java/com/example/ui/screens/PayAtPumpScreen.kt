package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.FuelSession
import com.example.domain.FuelSessionStatus
import com.example.domain.FuelType
import com.example.domain.NfcState
import com.example.ui.components.AnimatedPumpDisplay
import com.example.ui.components.LiveFuelMeter
import com.example.ui.theme.*
import com.example.viewmodel.BpCustomerUiState

@Composable
fun PayAtPumpScreen(
    state: BpCustomerUiState,
    fuelSession: FuelSession,
    nfcState: NfcState,
    onSelectPump: (Int) -> Unit,
    onFuelTypeSelected: (FuelType) -> Unit,
    onAuthorizeAndStartFueling: () -> Unit,
    onCompleteAndPay: () -> Unit,
    onViewReceipt: () -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp, vertical = 10.dp)
            .testTag("pay_at_pump_screen_content"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Forecourt Location Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(GraphiteCard)
                .border(1.dp, SatinBorder, RoundedCornerShape(14.dp))
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "CURRENT FORECOURT", style = MachineTextStyleSmall, color = BpGreen)
                    Text(
                        text = state.selectedStation.name,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextWhitePrimary
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(BpGreenContainer)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(text = "GPS VERIFIED", style = MachineTextStyleSmall, color = BpGreen)
                }
            }
        }

        // Pump Selector Pills (PUMP 01 to PUMP 06)
        Column {
            Text(
                text = "SELECT PUMP DISPENSER",
                style = MachineTextStyleSmall,
                color = TextGraySecondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                (1..6).forEach { pumpNum ->
                    val isSelected = state.selectedPumpNumber == pumpNum
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) BpGreenContainer else GraphiteCard)
                            .border(1.dp, if (isSelected) BpGreen else SatinBorder, RoundedCornerShape(10.dp))
                            .clickable { onSelectPump(pumpNum) }
                            .testTag("pump_select_pill_$pumpNum"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "PUMP ${String.format("%02d", pumpNum)}",
                            style = MachineTextStyleSmall,
                            color = if (isSelected) BpGreen else TextWhitePrimary,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 9.sp
                        )
                    }
                }
            }
        }

        // Live Precision Fuel Meter
        LiveFuelMeter(session = fuelSession)

        // Graphical Animated Pump View
        AnimatedPumpDisplay(
            session = fuelSession,
            onFuelTypeSelected = onFuelTypeSelected
        )

        // Contactless NFC / Authorize State Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(GraphiteCard)
                .border(1.dp, SatinBorder, RoundedCornerShape(16.dp))
                .padding(18.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Nfc, contentDescription = null, tint = BpGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "BP CARD CONTACTLESS GATEWAY", style = MachineTextStyleSmall, color = TextWhitePrimary)
                    }

                    Text(
                        text = "•••• 4821",
                        style = MachineTextStyleSmall,
                        color = BpGreen,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                val nfcStatusMessage = when (nfcState) {
                    NfcState.READY -> "TAP TO AUTHORISE PUMP ${String.format("%02d", state.selectedPumpNumber)}"
                    NfcState.HOLD_NEAR_TERMINAL -> "HOLD PHONE NEAR TERMINAL..."
                    NfcState.DETECTED -> "NFC TOKEN DETECTED"
                    NfcState.AUTHENTICATING -> "AUTHENTICATING BP CARD..."
                    NfcState.APPROVED -> "AUTHORISED · PUMP UNLOCKED"
                    NfcState.FAILED -> "NFC AUTHENTICATION FAILED"
                }

                Text(
                    text = nfcStatusMessage,
                    style = MachineTextStyleSmall,
                    color = if (nfcState == NfcState.APPROVED) BpGreen else BpAmber,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Action Buttons Driven by Session State Machine
        when (fuelSession.status) {
            FuelSessionStatus.IDLE -> {
                Button(
                    onClick = onAuthorizeAndStartFueling,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("authorize_and_fuel_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = BpGreen, contentColor = ObsidianBackground),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "AUTHORISE & START FUELING",
                        style = MachineTextStyleSmall,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }

            FuelSessionStatus.AUTHORIZING -> {
                Button(
                    onClick = {},
                    enabled = false,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = ObsidianBackground)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(text = "AUTHORISING PUMP...", style = MachineTextStyleSmall)
                }
            }

            FuelSessionStatus.FUELING -> {
                Button(
                    onClick = onCompleteAndPay,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("complete_and_pay_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = BpGreen, contentColor = ObsidianBackground),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "STOP FUELING & SETTLE PAYMENT (£${String.format("%.2f", fuelSession.totalCost)})",
                        style = MachineTextStyleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            FuelSessionStatus.COMPLETED -> {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(BpGreenContainer)
                            .border(1.dp, BpGreen, RoundedCornerShape(12.dp))
                            .padding(14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "TRANSACTION APPROVED & SETTLED · +128 BP POINTS EARNED",
                            style = MachineTextStyleSmall,
                            color = BpGreen,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = onViewReceipt,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("view_digital_receipt_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = SatinBorder, contentColor = TextWhitePrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Receipt, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "VIEW DIGITAL TAX RECEIPT", style = MachineTextStyleSmall, fontWeight = FontWeight.Bold)
                    }
                }
            }

            else -> {}
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}
