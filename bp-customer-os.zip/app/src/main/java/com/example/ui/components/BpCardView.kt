package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.BPCard
import com.example.domain.CardStatus
import com.example.ui.theme.*

@Composable
fun BpCardView(
    card: BPCard,
    isLocked: Boolean = false,
    onClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var isTapped by remember { mutableStateOf(false) }
    val rotationAngle by animateFloatAsState(
        targetValue = if (isTapped) 2f else 0f,
        animationSpec = tween(durationMillis = 300),
        label = "card_rotation"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1.586f) // Standard card ratio
            .rotate(rotationAngle)
            .shadow(16.dp, RoundedCornerShape(20.dp), spotColor = BpGreenGlow)
            .clip(RoundedCornerShape(20.dp))
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF2C3138),
                        Color(0xFF16181C),
                        Color(0xFF0D0E10)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color(0x80FFFFFF),
                        Color(0x1AFFFFFF),
                        Color(0x4D00D215)
                    )
                ),
                shape = RoundedCornerShape(20.dp)
            )
            .clickable {
                isTapped = !isTapped
                onClick()
            }
            .testTag("bp_digital_card"),
        contentAlignment = Alignment.TopStart
    ) {
        // Subtle Satin Shimmer Line
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0x1FFFFFFF), Color.Transparent),
                        radius = 600f
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(22.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Card Header: BP Branding + NFC Chip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(BpGreen)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "bp",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontFamily = FontFamily.Serif
                        )
                    }
                    Text(
                        text = "MOBILITY & FINANCIAL INSTRUMENT",
                        style = MachineTextStyleSmall,
                        color = TextGraySecondary
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Nfc,
                        contentDescription = "NFC Contactless",
                        tint = TextGraySecondary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    // EMV Chip Representation
                    Box(
                        modifier = Modifier
                            .width(36.dp)
                            .height(26.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(
                                brush = Brush.linearGradient(
                                    colors = listOf(Color(0xFFD4AF37), Color(0xFFAA820A))
                                )
                            )
                            .border(0.5.dp, Color(0x66FFFFFF), RoundedCornerShape(5.dp))
                    )
                }
            }

            // Card Number
            Text(
                text = card.cardNumberMasked,
                fontSize = 20.sp,
                fontFamily = MachineFontFamily,
                fontWeight = FontWeight.Medium,
                letterSpacing = 3.sp,
                color = if (isLocked) TextGrayMuted else TextWhitePrimary
            )

            // Card Footer: Holder Name + Expiry + Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    Text(
                        text = "CARDHOLDER",
                        style = MachineTextStyleSmall,
                        color = TextGrayMuted
                    )
                    Text(
                        text = card.cardHolder,
                        fontSize = 13.sp,
                        fontFamily = MachineFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        color = TextWhitePrimary
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "EXPIRES",
                        style = MachineTextStyleSmall,
                        color = TextGrayMuted
                    )
                    Text(
                        text = card.expiryDate,
                        fontSize = 13.sp,
                        fontFamily = MachineFontFamily,
                        color = TextWhitePrimary
                    )
                }

                // Status Badge
                val (badgeBg, badgeText, badgeColor) = if (isLocked || card.status == CardStatus.LOCKED) {
                    Triple(BpRedContainer, "LOCKED", BpRed)
                } else {
                    Triple(BpGreenContainer, "ACTIVE", BpGreen)
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(badgeBg)
                        .border(0.5.dp, badgeColor.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (isLocked) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = badgeColor,
                                modifier = Modifier.size(10.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                        Text(
                            text = badgeText,
                            style = MachineTextStyleSmall,
                            color = badgeColor,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
