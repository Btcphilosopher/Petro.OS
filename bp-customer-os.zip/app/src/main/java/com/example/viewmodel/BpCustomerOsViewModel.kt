package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SeedData
import com.example.domain.*
import com.example.services.ChargingSessionEngine
import com.example.services.FuelSessionEngine
import com.example.services.PaymentNfcProvider
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class AppNavDestination {
    HOME,
    STATIONS,
    CARD,
    ACTIVITY,
    ACCOUNT,
    PAY_AT_PUMP,
    EV_CHARGING,
    TRIP_PLANNER,
    GARAGE,
    REWARDS,
    SECURITY
}

enum class ContextState {
    NORMAL,
    DRIVING_TO_STATION,
    AT_STATION,
    FUELING,
    CHARGING,
    PAYMENT_COMPLETE
}

data class BpCustomerUiState(
    val customer: Customer = SeedData.defaultCustomer,
    val bpCard: BPCard = SeedData.defaultBPCard,
    val vehicles: List<Vehicle> = SeedData.vehiclesList,
    val selectedVehicle: Vehicle = SeedData.vehiclesList.first(),
    val stations: List<Station> = SeedData.stationsList,
    val selectedStation: Station = SeedData.sheffieldStation,
    val selectedPumpNumber: Int = 4,
    val selectedChargerNumber: Int = 8,
    val transactions: List<Transaction> = SeedData.transactionsList,
    val latestReceipt: Receipt? = SeedData.sampleReceipt,
    val rewardsAccount: RewardAccount = RewardAccount(),
    val offers: List<Offer> = SeedData.offersList,
    val securityEvents: List<SecurityEvent> = SeedData.securityEventsList,
    val currentDestination: AppNavDestination = AppNavDestination.HOME,
    val contextState: ContextState = ContextState.NORMAL,
    val isDemoRunning: Boolean = false,
    val demoStepMessage: String? = null,
    val isCardLocked: Boolean = false,
    val activeReceiptForModal: Receipt? = null,
    val notificationMessage: String? = null
)

class BpCustomerOsViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(BpCustomerUiState())
    val uiState: StateFlow<BpCustomerUiState> = _uiState.asStateFlow()

    val fuelEngine = FuelSessionEngine()
    val chargingEngine = ChargingSessionEngine()
    val paymentNfcProvider = PaymentNfcProvider()

    val fuelSession: StateFlow<FuelSession> = fuelEngine.session
    val chargingSession: StateFlow<ChargingSession> = chargingEngine.session
    val nfcState = paymentNfcProvider.nfcState
    val paymentStatus = paymentNfcProvider.paymentStatus

    init {
        // Collect fuel session state changes
        viewModelScope.launch {
            fuelSession.collect { session ->
                if (session.status == FuelSessionStatus.FUELING) {
                    _uiState.update { it.copy(contextState = ContextState.FUELING) }
                }
            }
        }
    }

    fun navigateTo(destination: AppNavDestination) {
        _uiState.update { it.copy(currentDestination = destination) }
    }

    fun selectVehicle(vehicle: Vehicle) {
        _uiState.update { it.copy(selectedVehicle = vehicle) }
        showNotification("Active vehicle set to ${vehicle.make} ${vehicle.model}")
    }

    fun selectStation(station: Station) {
        _uiState.update { it.copy(selectedStation = station) }
    }

    fun toggleCardLock() {
        val newLocked = !_uiState.value.isCardLocked
        val newStatus = if (newLocked) CardStatus.LOCKED else CardStatus.ACTIVE
        _uiState.update {
            it.copy(
                isCardLocked = newLocked,
                bpCard = it.bpCard.copy(status = newStatus)
            )
        }
        showNotification(if (newLocked) "BP Card Locked securely" else "BP Card Unlocked & Ready")
    }

    fun activateOffer(offerId: String) {
        _uiState.update { state ->
            val updatedOffers = state.offers.map {
                if (it.id == offerId) it.copy(isActivated = true) else it
            }
            state.copy(offers = updatedOffers)
        }
        showNotification("Offer activated! Applied to your BP Identity.")
    }

    fun showReceiptModal(receipt: Receipt?) {
        _uiState.update { it.copy(activeReceiptForModal = receipt) }
    }

    fun showNotification(message: String) {
        _uiState.update { it.copy(notificationMessage = message) }
    }

    fun dismissNotification() {
        _uiState.update { it.copy(notificationMessage = null) }
    }

    // --- PAY AT PUMP MANUAL ACTIONS ---
    fun selectPump(pumpNumber: Int) {
        _uiState.update { it.copy(selectedPumpNumber = pumpNumber) }
        fuelEngine.startNewSession(
            stationId = _uiState.value.selectedStation.id,
            pumpNumber = pumpNumber,
            fuelType = _uiState.value.selectedVehicle.preferredFuel,
            pricePerLitre = _uiState.value.selectedStation.unleadedPrice
        )
    }

    fun authorizeAndStartFueling(targetLitres: Double = 42.7) {
        viewModelScope.launch {
            fuelEngine.authorizeSession {
                fuelEngine.startFueling(targetLitres)
            }
        }
    }

    fun completeFuelSessionAndPay() {
        viewModelScope.launch {
            val session = fuelSession.value
            fuelEngine.completeFueling()

            val amount = session.totalCost.let { if (it <= 0.0) 64.21 else it }
            val litres = session.litres.let { if (it <= 0.0) 42.7 else it }

            paymentNfcProvider.beginNfcFlow(amount, _uiState.value.bpCard.lastFour) {
                // Settle transaction
                val pointsEarned = (amount * 2).toInt()
                val newTx = Transaction(
                    id = "TX-${(100000..999999).random()}",
                    date = "02 SEP 2026",
                    time = "08:42",
                    stationName = _uiState.value.selectedStation.name,
                    stationLocation = "Sheffield, UK",
                    type = "Petrol",
                    details = "${String.format("%.1f", litres)} L @ £${session.pricePerLitre}/L",
                    amount = amount,
                    paymentMethod = "BP CARD •••• ${_uiState.value.bpCard.lastFour}",
                    pumpOrChargerNumber = "Pump ${String.format("%02d", session.pumpNumber)}",
                    pointsEarned = pointsEarned,
                    receiptId = "RCP-${(100000..999999).random()}"
                )

                val newReceipt = Receipt(
                    id = newTx.receiptId,
                    transactionId = newTx.id,
                    stationName = _uiState.value.selectedStation.name,
                    stationAddress = _uiState.value.selectedStation.address,
                    date = "02 SEP 2026",
                    time = "08:42",
                    pumpNumber = "Pump ${String.format("%02d", session.pumpNumber)}",
                    fuelType = session.fuelType.displayName,
                    litres = litres,
                    pricePerLitre = session.pricePerLitre,
                    subtotal = amount / 1.2,
                    vatAmount = amount - (amount / 1.2),
                    total = amount,
                    paymentMethod = newTx.paymentMethod,
                    pointsEarned = pointsEarned
                )

                // Update vehicle range (286 mi -> 542 mi)
                val currentVeh = _uiState.value.selectedVehicle
                val updatedVehicle = currentVeh.copy(
                    currentFuelPercent = 1.0,
                    estimatedRangeMiles = 542
                )
                val updatedVehicles = _uiState.value.vehicles.map {
                    if (it.id == currentVeh.id) updatedVehicle else it
                }

                _uiState.update { state ->
                    state.copy(
                        transactions = listOf(newTx) + state.transactions,
                        latestReceipt = newReceipt,
                        rewardsAccount = state.rewardsAccount.copy(
                            totalPoints = state.rewardsAccount.totalPoints + pointsEarned,
                            lifetimePoints = state.rewardsAccount.lifetimePoints + pointsEarned
                        ),
                        selectedVehicle = updatedVehicle,
                        vehicles = updatedVehicles,
                        contextState = ContextState.PAYMENT_COMPLETE
                    )
                }
            }
        }
    }

    // --- HERO DEMO MODE ("START BP JOURNEY") ---
    fun startHeroDemoJourney() {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isDemoRunning = true,
                    currentDestination = AppNavDestination.HOME,
                    contextState = ContextState.DRIVING_TO_STATION,
                    demoStepMessage = "1/7 · Approaching BP Sheffield (1.2 mi)..."
                )
            }
            delay(2000)

            // Step 2: Navigate to Station detail / Pay at pump
            _uiState.update {
                it.copy(
                    currentDestination = AppNavDestination.PAY_AT_PUMP,
                    contextState = ContextState.AT_STATION,
                    selectedPumpNumber = 4,
                    demoStepMessage = "2/7 · Arrived at BP Sheffield · Pump 04 Selected"
                )
            }
            fuelEngine.startNewSession(
                stationId = "ST-SHEFFIELD",
                pumpNumber = 4,
                fuelType = FuelType.UNLEADED,
                pricePerLitre = 1.499
            )
            delay(1800)

            // Step 3: Present BP Card & NFC Auth
            _uiState.update {
                it.copy(demoStepMessage = "3/7 · Presenting BP Card ••••4821 via NFC...")
            }
            paymentNfcProvider.beginNfcFlow(64.21, "4821")
            delay(2500)

            // Step 4: Pump Unlock
            _uiState.update {
                it.copy(demoStepMessage = "4/7 · NFC Authenticated · Pump 04 Unlocked")
            }
            fuelEngine.authorizeSession()
            delay(1500)

            // Step 5: Start Live Fueling
            _uiState.update {
                it.copy(
                    contextState = ContextState.FUELING,
                    demoStepMessage = "5/7 · Fueling in progress: Live Meter Active..."
                )
            }
            fuelEngine.startFueling(42.7)

            // Wait for fuel meter to simulate
            delay(5000)

            // Step 6: Complete Fueling & Pay
            _uiState.update {
                it.copy(demoStepMessage = "6/7 · Fueling Complete (42.7 L) · Settling £64.21...")
            }
            completeFuelSessionAndPay()
            delay(2500)

            // Step 7: Hero Wrap-up
            _uiState.update {
                it.copy(
                    currentDestination = AppNavDestination.HOME,
                    isDemoRunning = false,
                    demoStepMessage = null,
                    contextState = ContextState.PAYMENT_COMPLETE
                )
            }
            showNotification("BP Journey Complete! Range updated to 542 mi (+128 BP Points earned)")
        }
    }
}
