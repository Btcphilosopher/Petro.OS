package com.example.data

import com.example.domain.*

object SeedData {

    val defaultCustomer = Customer(
        id = "CUST-98231",
        name = "Tom Anderson",
        email = "tom.anderson@bp-customer.co.uk",
        bpIdentityId = "BP-ID-884029",
        memberTier = "BP Premier Member"
    )

    val defaultBPCard = BPCard(
        id = "CARD-4821",
        cardHolder = "TOM ANDERSON",
        lastFour = "4821",
        expiryDate = "08/28",
        status = CardStatus.ACTIVE,
        spendingLimitMonthly = 1000.0,
        currentSpendMonthly = 392.32,
        isDefaultPayment = true
    )

    val vehiclesList = listOf(
        Vehicle(
            id = "VEH-AUDI-A4",
            make = "Audi",
            model = "A4 Avant",
            year = 2024,
            registration = "BP24 LNO",
            fuelType = VehicleFuelType.PETROL,
            tankCapacityLitres = 54.0,
            currentFuelPercent = 0.62,
            estimatedRangeMiles = 286,
            efficiency = "6.2 L/100km",
            preferredFuel = FuelType.UNLEADED,
            odometerMiles = 24150
        ),
        Vehicle(
            id = "VEH-TESLA-3",
            make = "Tesla",
            model = "Model 3 Long Range",
            year = 2025,
            registration = "EV75 BPO",
            fuelType = VehicleFuelType.EV,
            batteryCapacityKWh = 78.0,
            currentBatteryPercent = 0.74,
            estimatedRangeMiles = 241,
            efficiency = "15.4 kWh/100km",
            preferredFuel = FuelType.UNLEADED,
            odometerMiles = 12400
        ),
        Vehicle(
            id = "VEH-FORD-TRANSIT",
            make = "Ford",
            model = "Transit Custom",
            year = 2023,
            registration = "VT23 BPC",
            fuelType = VehicleFuelType.DIESEL,
            tankCapacityLitres = 70.0,
            currentFuelPercent = 0.85,
            estimatedRangeMiles = 402,
            efficiency = "7.8 L/100km",
            preferredFuel = FuelType.DIESEL,
            odometerMiles = 48900
        )
    )

    val sheffieldStation = Station(
        id = "ST-SHEFFIELD",
        name = "BP Sheffield Savile St",
        address = "Savile St East, Sheffield S4 7UQ",
        distanceMiles = 1.2,
        latitude = 53.3883,
        longitude = -1.4582,
        isOpen = true,
        unleadedPrice = 1.499,
        dieselPrice = 1.529,
        premiumPrice = 1.659,
        pumps = listOf(
            Pump("PUMP-01", 1, isAvailable = true),
            Pump("PUMP-02", 2, isAvailable = true),
            Pump("PUMP-03", 3, isAvailable = false),
            Pump("PUMP-04", 4, isAvailable = true),
            Pump("PUMP-05", 5, isAvailable = true),
            Pump("PUMP-06", 6, isAvailable = true)
        ),
        evChargers = listOf(
            EVCharger("CHG-01", 1, 150, "CCS Type 2", isAvailable = false),
            EVCharger("CHG-02", 2, 150, "CCS Type 2", isAvailable = false),
            EVCharger("CHG-03", 3, 300, "Ultra-Fast CCS", isAvailable = true),
            EVCharger("CHG-04", 4, 300, "Ultra-Fast CCS", isAvailable = true),
            EVCharger("CHG-05", 5, 150, "CCS Type 2", isAvailable = true),
            EVCharger("CHG-06", 6, 150, "CCS Type 2", isAvailable = false),
            EVCharger("CHG-07", 7, 50, "CHAdeMO", isAvailable = true),
            EVCharger("CHG-08", 8, 150, "CCS Type 2", isAvailable = true)
        ),
        totalChargersCount = 12,
        availableChargersCount = 4,
        amenities = listOf("Wild Bean Cafe", "M&S Simply Food", "Car Wash", "Toilets", "Free Air & Water", "BP Pulse Hub")
    )

    val londonGatewayStation = Station(
        id = "ST-LONDON-GW",
        name = "BP London Gateway Services",
        address = "M1 Motorway J2-J3, London NW7 3HU",
        distanceMiles = 142.0,
        latitude = 51.6214,
        longitude = -0.2520,
        isOpen = true,
        unleadedPrice = 1.549,
        dieselPrice = 1.589,
        premiumPrice = 1.699,
        pumps = (1..12).map { Pump("PUMP-${String.format("%02d", it)}", it, isAvailable = true) },
        evChargers = (1..16).map { EVCharger("CHG-${String.format("%02d", it)}", it, 300, "Ultra-Fast CCS", isAvailable = it % 2 == 0) },
        totalChargersCount = 16,
        availableChargersCount = 8,
        amenities = listOf("Wild Bean Cafe", "M&S Simply Food", "Starbucks", "Costa Express", "24/7 Rest Lounge", "Truck Stop")
    )

    val leedsWestStation = Station(
        id = "ST-LEEDS-WEST",
        name = "BP Leeds Ring Road West",
        address = "Ring Rd, Wortley, Leeds LS12 6HN",
        distanceMiles = 32.5,
        latitude = 53.7831,
        longitude = -1.5892,
        isOpen = true,
        unleadedPrice = 1.489,
        dieselPrice = 1.519,
        premiumPrice = 1.639,
        pumps = (1..8).map { Pump("PUMP-${String.format("%02d", it)}", it, isAvailable = true) },
        evChargers = (1..6).map { EVCharger("CHG-${String.format("%02d", it)}", it, 150, "CCS Type 2", isAvailable = true) },
        totalChargersCount = 6,
        availableChargersCount = 5,
        amenities = listOf("Wild Bean Cafe", "M&S Simply Food", "Jet Wash")
    )

    val stationsList = listOf(sheffieldStation, londonGatewayStation, leedsWestStation)

    val transactionsList = listOf(
        Transaction(
            id = "TX-882194",
            date = "02 SEP 2026",
            time = "08:42",
            stationName = "BP Sheffield Savile St",
            stationLocation = "Sheffield, UK",
            type = "Petrol",
            details = "42.7 L @ £1.499/L · Ultimate Unleaded",
            amount = 64.21,
            paymentMethod = "BP CARD •••• 4821",
            pumpOrChargerNumber = "Pump 04",
            pointsEarned = 128,
            receiptId = "RCP-99201"
        ),
        Transaction(
            id = "TX-881902",
            date = "28 AUG 2026",
            time = "17:15",
            stationName = "BP Leeds Ring Road West",
            stationLocation = "Leeds, UK",
            type = "EV Charge",
            details = "38.5 kWh @ 150 kW Pulse Charger",
            amount = 26.56,
            paymentMethod = "BP CARD •••• 4821",
            pumpOrChargerNumber = "Charger 03",
            pointsEarned = 53,
            receiptId = "RCP-98744"
        ),
        Transaction(
            id = "TX-879410",
            date = "21 AUG 2026",
            time = "12:30",
            stationName = "BP London Gateway Services",
            stationLocation = "M1 Motorway, UK",
            type = "Petrol & Shop",
            details = "50.1 L @ £1.549/L + Wild Bean Coffee",
            amount = 81.10,
            paymentMethod = "BP CARD •••• 4821",
            pumpOrChargerNumber = "Pump 08",
            pointsEarned = 162,
            receiptId = "RCP-97621"
        ),
        Transaction(
            id = "TX-875102",
            date = "15 AUG 2026",
            time = "09:05",
            stationName = "BP Sheffield Savile St",
            stationLocation = "Sheffield, UK",
            type = "Petrol",
            details = "45.0 L @ £1.499/L · Premium Unleaded",
            amount = 67.45,
            paymentMethod = "BP CARD •••• 4821",
            pumpOrChargerNumber = "Pump 02",
            pointsEarned = 135,
            receiptId = "RCP-95411"
        )
    )

    val sampleReceipt = Receipt(
        id = "RCP-99201",
        transactionId = "TX-882194",
        stationName = "BP Sheffield Savile St",
        stationAddress = "Savile St East, Sheffield S4 7UQ",
        date = "02 SEP 2026",
        time = "08:42",
        pumpNumber = "Pump 04",
        fuelType = "BP Ultimate Unleaded 95",
        litres = 42.7,
        pricePerLitre = 1.499,
        subtotal = 53.51,
        vatAmount = 10.70,
        total = 64.21,
        paymentMethod = "BP CARD •••• 4821",
        pointsEarned = 128
    )

    val offersList = listOf(
        Offer(
            id = "OFFER-10",
            title = "10p/L OFF ULTIMATE FUELS",
            description = "Save 10p per litre when you pay with your BP Card on your frequent route (Sheffield → Leeds).",
            discountText = "10p/L Discount",
            validUntil = "30 SEP 2026",
            routeContext = "Sheffield → Leeds regular route",
            isActivated = true
        ),
        Offer(
            id = "OFFER-20",
            title = "DOUBLE POINTS ON EV PULSE",
            description = "Earn 2x BP Rewards points on ultra-fast charging over 100kW at motorway hubs.",
            discountText = "2x BP Points",
            validUntil = "15 OCT 2026",
            isActivated = false
        ),
        Offer(
            id = "OFFER-30",
            title = "FREE COFFEE WITH 30L+",
            description = "Complimentary Wild Bean Cafe barista beverage on any fuel purchase over 30 Litres.",
            discountText = "Free Barista Beverage",
            validUntil = "31 DEC 2026",
            isActivated = true
        )
    )

    val securityEventsList = listOf(
        SecurityEvent(id = "SEC-01", timestamp = "Today · 08:42", eventType = "NFC Pay at Pump Authorisation", location = "BP Sheffield"),
        SecurityEvent(id = "SEC-02", timestamp = "28 AUG · 17:15", eventType = "Pulse EV Charging Auth", location = "BP Leeds Ring Rd"),
        SecurityEvent(id = "SEC-03", timestamp = "21 AUG · 12:30", eventType = "Biometric Passcode Auth", location = "BP London Gateway"),
        SecurityEvent(id = "SEC-04", timestamp = "01 AUG · 10:00", eventType = "BP Card Pin Guidance Check", location = "App Settings")
    )
}
