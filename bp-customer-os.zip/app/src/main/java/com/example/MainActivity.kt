package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.BottomNavBar
import com.example.ui.components.ReceiptDialog
import com.example.ui.components.TopHeaderBar
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.viewmodel.AppNavDestination
import com.example.viewmodel.BpCustomerOsViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BpCustomerOsTheme {
                BpCustomerOsApp()
            }
        }
    }
}

@Composable
fun BpCustomerOsApp(
    viewModel: BpCustomerOsViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val fuelSession by viewModel.fuelSession.collectAsState()
    val chargingSession by viewModel.chargingSession.collectAsState()
    val nfcState by viewModel.nfcState.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize().testTag("bp_customer_os_app"),
        topBar = {
            TopHeaderBar(
                customerName = uiState.customer.name,
                vehicle = uiState.selectedVehicle,
                onGarageClick = { viewModel.navigateTo(AppNavDestination.GARAGE) },
                onSecurityClick = { viewModel.navigateTo(AppNavDestination.SECURITY) }
            )
        },
        bottomBar = {
            BottomNavBar(
                currentDestination = uiState.currentDestination,
                onNavigate = { viewModel.navigateTo(it) },
                onHeroStartJourney = { viewModel.startHeroDemoJourney() }
            )
        },
        containerColor = ObsidianBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Screen Navigation Router
            when (uiState.currentDestination) {
                AppNavDestination.HOME -> HomeScreen(
                    state = uiState,
                    onNavigate = { viewModel.navigateTo(it) },
                    onHeroStartDemo = { viewModel.startHeroDemoJourney() },
                    onLockCardToggle = { viewModel.toggleCardLock() },
                    onSelectReceipt = { viewModel.showReceiptModal(it) }
                )

                AppNavDestination.STATIONS -> StationsScreen(
                    state = uiState,
                    onStationSelect = { viewModel.selectStation(it) },
                    onNavigate = { viewModel.navigateTo(it) }
                )

                AppNavDestination.CARD -> CardScreen(
                    state = uiState,
                    onLockCardToggle = { viewModel.toggleCardLock() },
                    onShowNotification = { viewModel.showNotification(it) }
                )

                AppNavDestination.PAY_AT_PUMP -> PayAtPumpScreen(
                    state = uiState,
                    fuelSession = fuelSession,
                    nfcState = nfcState,
                    onSelectPump = { viewModel.selectPump(it) },
                    onFuelTypeSelected = { fuel ->
                        viewModel.fuelEngine.startNewSession(
                            stationId = uiState.selectedStation.id,
                            pumpNumber = uiState.selectedPumpNumber,
                            fuelType = fuel,
                            pricePerLitre = fuel.defaultPricePerLitre
                        )
                    },
                    onAuthorizeAndStartFueling = { viewModel.authorizeAndStartFueling() },
                    onCompleteAndPay = { viewModel.completeFuelSessionAndPay() },
                    onViewReceipt = { viewModel.showReceiptModal(uiState.latestReceipt) }
                )

                AppNavDestination.EV_CHARGING -> EvChargingScreen(
                    state = uiState,
                    chargingSession = chargingSession,
                    onStartCharging = { chgNum -> viewModel.chargingEngine.startChargingSession("CHG-$chgNum", chgNum) },
                    onStopCharging = { viewModel.chargingEngine.stopCharging() }
                )

                AppNavDestination.ACTIVITY -> ActivityScreen(
                    state = uiState,
                    onSelectReceipt = { viewModel.showReceiptModal(it) }
                )

                AppNavDestination.TRIP_PLANNER -> TripPlannerScreen(
                    state = uiState,
                    onStartRoute = { viewModel.startHeroDemoJourney() }
                )

                AppNavDestination.GARAGE -> GarageScreen(
                    state = uiState,
                    onSelectVehicle = { viewModel.selectVehicle(it) },
                    onAddVehicleClick = { viewModel.showNotification("Vehicle registration scanner opened") }
                )

                AppNavDestination.REWARDS -> RewardsScreen(
                    state = uiState,
                    onActivateOffer = { viewModel.activateOffer(it) }
                )

                AppNavDestination.SECURITY -> SecurityScreen(
                    state = uiState
                )

                else -> HomeScreen(
                    state = uiState,
                    onNavigate = { viewModel.navigateTo(it) },
                    onHeroStartDemo = { viewModel.startHeroDemoJourney() },
                    onLockCardToggle = { viewModel.toggleCardLock() },
                    onSelectReceipt = { viewModel.showReceiptModal(it) }
                )
            }

            // Toast / Notification Overlay Banner
            AnimatedVisibility(
                visible = uiState.notificationMessage != null,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 10.dp, start = 16.dp, end = 16.dp)
            ) {
                uiState.notificationMessage?.let { msg ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF1B221D))
                            .border(1.dp, BpGreen, RoundedCornerShape(12.dp))
                            .clickable { viewModel.dismissNotification() }
                            .padding(14.dp)
                    ) {
                        Text(
                            text = msg,
                            style = MachineTextStyleSmall,
                            color = BpGreen,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Digital Tax Receipt Modal Overlay
            ReceiptDialog(
                receipt = uiState.activeReceiptForModal,
                onDismiss = { viewModel.showReceiptModal(null) },
                onShare = { viewModel.showNotification("Receipt shareable link generated") },
                onDownload = { viewModel.showNotification("Tax Receipt PDF downloaded to device") }
            )
        }
    }
}
