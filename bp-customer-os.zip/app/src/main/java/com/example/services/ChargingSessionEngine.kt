package com.example.services

import com.example.domain.ChargingSession
import com.example.domain.ChargingSessionStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class ChargingSessionEngine {

    private val _session = MutableStateFlow(ChargingSession())
    val session: StateFlow<ChargingSession> = _session.asStateFlow()

    private var chargingJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    fun startChargingSession(chargerId: String = "CHG-08", chargerNumber: Int = 8, powerKw: Double = 150.0) {
        chargingJob?.cancel()
        _session.value = ChargingSession(
            chargerId = chargerId,
            chargerNumber = chargerNumber,
            powerKw = powerKw,
            energyKWh = 0.0,
            startBatteryPercent = 32,
            currentBatteryPercent = 32,
            targetBatteryPercent = 80,
            pricePerKWh = 0.69,
            totalCost = 0.0,
            status = ChargingSessionStatus.CONNECTING
        )

        scope.launch {
            delay(1500) // Connecting & Handshake with Vehicle
            _session.update { it.copy(status = ChargingSessionStatus.CHARGING) }
            runChargingLoop()
        }
    }

    private fun runChargingLoop() {
        chargingJob?.cancel()
        chargingJob = scope.launch {
            val intervalMs = 100L
            while (_session.value.status == ChargingSessionStatus.CHARGING && _session.value.currentBatteryPercent < 80) {
                delay(intervalMs)
                _session.update { current ->
                    val addedKWh = 0.12
                    val newKWh = current.energyKWh + addedKWh
                    val newCost = newKWh * current.pricePerKWh
                    val newPercent = (current.startBatteryPercent + (newKWh / 0.5)).toInt().coerceAtMost(80)
                    current.copy(
                        energyKWh = newKWh,
                        totalCost = newCost,
                        currentBatteryPercent = newPercent
                    )
                }
            }

            if (_session.value.currentBatteryPercent >= 80) {
                _session.update { it.copy(status = ChargingSessionStatus.COMPLETE) }
            }
        }
    }

    fun stopCharging() {
        chargingJob?.cancel()
        _session.update { it.copy(status = ChargingSessionStatus.COMPLETE) }
    }

    fun reset() {
        chargingJob?.cancel()
        _session.value = ChargingSession()
    }
}
