package com.example.services

import com.example.domain.NfcState
import com.example.domain.PaymentStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class PaymentNfcProvider {

    private val _nfcState = MutableStateFlow(NfcState.READY)
    val nfcState: StateFlow<NfcState> = _nfcState.asStateFlow()

    private val _paymentStatus = MutableStateFlow(PaymentStatus.IDLE)
    val paymentStatus: StateFlow<PaymentStatus> = _paymentStatus.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.Main)

    fun beginNfcFlow(amount: Double, cardLastFour: String = "4821", onApproved: () -> Unit = {}) {
        scope.launch {
            _nfcState.value = NfcState.HOLD_NEAR_TERMINAL
            _paymentStatus.value = PaymentStatus.AUTHENTICATING
            delay(1000)

            _nfcState.value = NfcState.DETECTED
            delay(800)

            _nfcState.value = NfcState.AUTHENTICATING
            _paymentStatus.value = PaymentStatus.PROCESSING
            delay(1200)

            _nfcState.value = NfcState.APPROVED
            _paymentStatus.value = PaymentStatus.APPROVED
            delay(500)

            _paymentStatus.value = PaymentStatus.SETTLED
            onApproved()
        }
    }

    fun reset() {
        _nfcState.value = NfcState.READY
        _paymentStatus.value = PaymentStatus.IDLE
    }
}
