package com.example.services

import com.example.domain.FuelSession
import com.example.domain.FuelSessionStatus
import com.example.domain.FuelType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale

class FuelSessionEngine {

    private val _session = MutableStateFlow(FuelSession())
    val session: StateFlow<FuelSession> = _session.asStateFlow()

    private var fuelingJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    fun startNewSession(
        stationId: String = "ST-SHEFFIELD",
        pumpNumber: Int = 4,
        fuelType: FuelType = FuelType.UNLEADED,
        pricePerLitre: Double = 1.499
    ) {
        fuelingJob?.cancel()
        _session.value = FuelSession(
            stationId = stationId,
            pumpId = "PUMP-${String.format(Locale.UK, "%02d", pumpNumber)}",
            pumpNumber = pumpNumber,
            fuelType = fuelType,
            pricePerLitre = pricePerLitre,
            litres = 0.0,
            totalCost = 0.0,
            status = FuelSessionStatus.IDLE
        )
    }

    fun authorizeSession(onAuthorized: () -> Unit = {}) {
        scope.launch {
            _session.update { it.copy(status = FuelSessionStatus.AUTHORIZING) }
            delay(1200) // Simulate NFC / BP Card Gateway handshake
            _session.update { it.copy(status = FuelSessionStatus.PUMP_UNLOCKED) }
            onAuthorized()
        }
    }

    fun startFueling(targetLitres: Double = 42.7) {
        fuelingJob?.cancel()
        _session.update { it.copy(status = FuelSessionStatus.FUELING) }

        fuelingJob = scope.launch {
            val price = _session.value.pricePerLitre
            val flowRatePerSec = 0.85 // Litres per second
            val intervalMs = 50L
            val stepLitre = flowRatePerSec * (intervalMs / 1000.0)

            while (_session.value.status == FuelSessionStatus.FUELING && _session.value.litres < targetLitres) {
                delay(intervalMs)
                _session.update { current ->
                    val newLitres = (current.litres + stepLitre).coerceAtMost(targetLitres)
                    val newCost = newLitres * price
                    current.copy(
                        litres = newLitres,
                        totalCost = newCost,
                        flowRateLitresPerMin = 22.5 + (Math.random() * 2.0 - 1.0)
                    )
                }
            }

            if (_session.value.litres >= targetLitres) {
                completeFueling()
            }
        }
    }

    fun pauseFueling() {
        fuelingJob?.cancel()
        _session.update { it.copy(status = FuelSessionStatus.PAUSED) }
    }

    fun resumeFueling(targetLitres: Double = 42.7) {
        startFueling(targetLitres)
    }

    fun completeFueling() {
        fuelingJob?.cancel()
        _session.update { current ->
            current.copy(
                status = FuelSessionStatus.COMPLETED,
                endedAt = "Today · 08:43"
            )
        }
    }

    fun reset() {
        fuelingJob?.cancel()
        _session.value = FuelSession()
    }
}
