package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.PumpState
import com.example.ui.admin.AdminDashboard
import com.example.ui.admin.SimulationControlBar
import com.example.ui.components.AssistanceCard
import com.example.ui.components.FillUpAndGoCard
import com.example.ui.components.FooterBar
import com.example.ui.components.FuelOptionsGrid
import com.example.ui.components.HeaderBar
import com.example.ui.components.LoyaltyCard
import com.example.ui.components.PaymentMethodCard
import com.example.ui.components.PromoCard
import com.example.ui.components.PumpNumberCard
import com.example.ui.components.ThisSaleCard
import com.example.ui.modals.AccessibilityDialog
import com.example.ui.modals.LanguageDialog
import com.example.ui.modals.LiveFuelingOverlay
import com.example.ui.modals.NfcPaymentModal
import com.example.ui.modals.ReceiptModal
import com.example.ui.theme.BpBackgroundGray
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun MainScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val pumpState by viewModel.pumpStateMachine.state.collectAsState()
    val selectedFuel by viewModel.pumpStateMachine.selectedFuel.collectAsState()
    val telemetry by viewModel.dispenserSimulator.telemetry.collectAsState()
    val fuelGrades by viewModel.forecourtController.fuelPrices.collectAsState()
    val loyaltyAccount by viewModel.loyaltyManager.account.collectAsState()
    val isAdminMode by viewModel.isAdminMode.collectAsState()
    val isSimControlVisible by viewModel.isSimControlVisible.collectAsState()
    val isAccessibilityDialogVisible by viewModel.isAccessibilityDialogVisible.collectAsState()
    val isLanguageDialogVisible by viewModel.isLanguageDialogVisible.collectAsState()
    val isAssistanceActive by viewModel.isAssistanceActive.collectAsState()
    val currentReceipt by viewModel.currentReceipt.collectAsState()
    val currentLanguage by viewModel.localizationManager.currentLanguage.collectAsState()

    val highContrastMode by viewModel.highContrastMode.collectAsState()
    val largeTextMode by viewModel.largeTextMode.collectAsState()
    val audioGuidanceActive by viewModel.audioGuidanceActive.collectAsState()

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("main_screen_scaffold"),
        topBar = {
            Column {
                if (isSimControlVisible) {
                    SimulationControlBar(
                        onSimulateNfcTap = { viewModel.simulateNfcTap() },
                        onRemoveNozzle = { viewModel.simulateRemoveNozzle() },
                        onReturnNozzle = { viewModel.simulateReturnNozzle() },
                        onEmergencyStop = { viewModel.triggerEmergencyStop() },
                        onRunAutoSequence = { viewModel.runAutoSimulatorSequence() },
                        onResetTerminal = { viewModel.resetTerminal() },
                        onOpenAdminDashboard = { viewModel.toggleAdminMode() }
                    )
                }
                HeaderBar(
                    welcomeText = viewModel.localizationManager.getString("welcome"),
                    taglineText = viewModel.localizationManager.getString("fuel_your_journey")
                )
            }
        },
        bottomBar = {
            FooterBar(
                helpLabel = viewModel.localizationManager.getString("help"),
                languageLabel = viewModel.localizationManager.getString("language"),
                accessibilityLabel = viewModel.localizationManager.getString("accessibility"),
                taglineLabel = viewModel.localizationManager.getString("every_journey_matters"),
                onHelpClick = { viewModel.requestAssistance() },
                onLanguageClick = { viewModel.toggleLanguageDialog() },
                onAccessibilityClick = { viewModel.toggleAccessibilityDialog() }
            )
        },
        containerColor = if (highContrastMode) Color.White else BpBackgroundGray
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Main Customer Forecourt Layout Grid (3 Columns)
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // LEFT COLUMN: Pump Number + Payment Method + Loyalty + Fill up & Go
                    Column(
                        modifier = Modifier.weight(0.9f),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        PumpNumberCard(pumpNumber = 4)

                        PaymentMethodCard(
                            paymentMethodText = viewModel.localizationManager.getString("payment_method"),
                            instructionText = viewModel.localizationManager.getString("tap_or_insert_card"),
                            onClick = { viewModel.startNfcPaymentFlow() }
                        )

                        LoyaltyCard(
                            pointsBalance = loyaltyAccount.pointsBalance,
                            pointsLabel = viewModel.localizationManager.getString("pts"),
                            viewBenefitsLabel = viewModel.localizationManager.getString("view_benefits"),
                            onViewBenefitsClick = { viewModel.requestAssistance() }
                        )

                        FillUpAndGoCard(
                            title = viewModel.localizationManager.getString("fill_up_go"),
                            description = viewModel.localizationManager.getString("fill_up_go_desc"),
                            onClick = { viewModel.startNfcPaymentFlow() }
                        )
                    }

                    // MIDDLE COLUMN: Fuel Options Cards
                    Column(
                        modifier = Modifier.weight(1.3f)
                    ) {
                        FuelOptionsGrid(
                            fuelGrades = fuelGrades,
                            selectedGradeId = selectedFuel?.id,
                            perLitreLabel = viewModel.localizationManager.getString("per_litre"),
                            onFuelSelected = { fuel -> viewModel.onSelectFuel(fuel) }
                        )
                    }

                    // RIGHT COLUMN: This Sale + Promo App Banner + Assistance
                    Column(
                        modifier = Modifier.weight(1.0f),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ThisSaleCard(
                            totalAmount = telemetry.totalValueAmount,
                            litresDispensed = telemetry.volumeDispensedLitres
                        )

                        PromoCard(
                            onDownloadClick = {}
                        )

                        AssistanceCard(
                            title = viewModel.localizationManager.getString("need_assistance"),
                            description = viewModel.localizationManager.getString("assistance_desc"),
                            isAssistanceActive = isAssistanceActive,
                            onHelpClick = { viewModel.requestAssistance() }
                        )
                    }
                }
            }

            // MODAL / STATE OVERLAYS

            // 1. NFC Payment Pre-Authorization Modal
            if (pumpState in listOf(
                    PumpState.NFC_WAITING,
                    PumpState.PAYMENT_SELECTION,
                    PumpState.PAYMENT_AUTHORIZING,
                    PumpState.PAYMENT_APPROVED,
                    PumpState.PAYMENT_DECLINED,
                    PumpState.PAYMENT_TIMEOUT,
                    PumpState.NFC_ERROR
                )
            ) {
                NfcPaymentModal(
                    pumpState = pumpState,
                    selectedFuel = selectedFuel,
                    onSimulateTap = { viewModel.simulateNfcTap() },
                    onCancel = { viewModel.resetTerminal() }
                )
            }

            // 2. Live Fueling Telemetry Dispenser Screen Overlay
            if (pumpState == PumpState.NOZZLE_REMOVED || pumpState == PumpState.FUELING || pumpState == PumpState.FUELING_COMPLETE || pumpState == PumpState.EMERGENCY_STOP) {
                LiveFuelingOverlay(
                    telemetry = telemetry,
                    selectedFuel = selectedFuel,
                    pumpState = pumpState,
                    isTriggerSqueezed = viewModel.dispenserSimulator.isTriggerSqueezed,
                    onToggleTrigger = { viewModel.toggleSqueezeTrigger() },
                    onFinishFueling = { viewModel.simulateReturnNozzle() },
                    onEmergencyStop = { viewModel.triggerEmergencyStop() }
                )
            }

            // 3. Receipt & Done Modal
            if (pumpState == PumpState.TRANSACTION_COMPLETE || pumpState == PumpState.RECEIPT) {
                ReceiptModal(
                    receipt = currentReceipt,
                    onDone = { viewModel.resetTerminal() }
                )
            }

            // 4. Accessibility & Language Dialogs
            if (isAccessibilityDialogVisible) {
                AccessibilityDialog(
                    highContrastMode = highContrastMode,
                    largeTextMode = largeTextMode,
                    audioGuidanceActive = audioGuidanceActive,
                    onToggleHighContrast = { viewModel.toggleHighContrast() },
                    onToggleLargeText = { viewModel.toggleLargeText() },
                    onToggleAudioGuidance = { viewModel.toggleAudioGuidance() },
                    onDismiss = { viewModel.toggleAccessibilityDialog() }
                )
            }

            if (isLanguageDialogVisible) {
                LanguageDialog(
                    currentLanguage = currentLanguage,
                    onSelectLanguage = { lang -> viewModel.setLanguage(lang) },
                    onDismiss = { viewModel.toggleLanguageDialog() }
                )
            }

            // 5. Enterprise Admin Forecourt Dashboard Overlay
            if (isAdminMode) {
                AdminDashboard(
                    viewModel = viewModel,
                    onClose = { viewModel.toggleAdminMode() }
                )
            }
        }
    }
}
