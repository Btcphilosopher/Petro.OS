package com.example.data.pump

import com.example.data.model.FuelGrade
import com.example.data.model.PumpState
import com.example.data.model.TelemetryData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class PumpDispenserSimulator(
    private val scope: CoroutineScope
) {
    private val _telemetry = MutableStateFlow(TelemetryData())
    val telemetry: StateFlow<TelemetryData> = _telemetry.asStateFlow()

    private var fuelingJob: Job? = null
    var isTriggerSqueezed: Boolean = true // Simulates nozzle lever state

    fun startFueling(fuelGrade: FuelGrade, pumpState: PumpState = PumpState.FUELING) {
        stopFueling()
        
        fuelingJob = scope.launch(Dispatchers.Default) {
            var currentVolume = _telemetry.value.volumeDispensedLitres
            val flowRateLpm = 32.5 // ~32.5 Litres per minute typical pump flow
            val stepSeconds = 0.1
            val volumePerStep = (flowRateLpm / 60.0) * stepSeconds

            while (true) {
                if (isTriggerSqueezed) {
                    currentVolume += volumePerStep
                    val roundedVol = (currentVolume * 100.0).roundToInt() / 100.0
                    val totalVal = ((roundedVol * fuelGrade.pricePerLitre) * 100.0).roundToInt() / 100.0
                    val temp = 18.5 + ((roundedVol * 0.05) % 3.0)

                    _telemetry.value = TelemetryData(
                        timestamp = System.currentTimeMillis(),
                        stationId = "ST-001",
                        pumpId = "PUMP-04",
                        nozzleId = "NOZZLE-0" + fuelGrade.id,
                        fuelGrade = fuelGrade.name,
                        flowRateLpm = if (isTriggerSqueezed) flowRateLpm else 0.0,
                        volumeDispensedLitres = roundedVol,
                        pricePerLitre = fuelGrade.pricePerLitre,
                        totalValueAmount = totalVal,
                        temperatureCelsius = (temp * 10.0).roundToInt() / 10.0,
                        pumpStatus = pumpState
                    )
                }
                delay((stepSeconds * 1000).toLong())
            }
        }
    }

    fun stopFueling() {
        fuelingJob?.cancel()
        fuelingJob = null
    }

    fun resetTelemetry() {
        stopFueling()
        _telemetry.value = TelemetryData()
    }

    fun setVolume(litres: Double, pricePerLitre: Double) {
        val roundedVol = (litres * 100.0).roundToInt() / 100.0
        val totalVal = ((roundedVol * pricePerLitre) * 100.0).roundToInt() / 100.0
        _telemetry.value = _telemetry.value.copy(
            volumeDispensedLitres = roundedVol,
            totalValueAmount = totalVal
        )
    }
}
