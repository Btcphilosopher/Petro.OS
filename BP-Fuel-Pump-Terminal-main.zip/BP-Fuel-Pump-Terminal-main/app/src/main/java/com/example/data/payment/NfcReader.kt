package com.example.data.payment

import com.example.data.model.NfcSessionState
import com.example.data.model.PaymentToken
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

interface NfcReader {
    val sessionState: Flow<NfcSessionState>
    suspend fun startSession()
    suspend fun detectPaymentDevice(): Boolean
    suspend fun readToken(): PaymentToken
    suspend fun cancelSession()
    suspend fun closeSession()
}

class MockNfcReader : NfcReader {
    private val _sessionState = MutableStateFlow<NfcSessionState>(NfcSessionState.Idle)
    override val sessionState: Flow<NfcSessionState> = _sessionState.asStateFlow()

    private var isCancelled = false

    override suspend fun startSession() {
        isCancelled = false
        _sessionState.value = NfcSessionState.WaitingForDevice
    }

    override suspend fun detectPaymentDevice(): Boolean {
        if (isCancelled) return false
        _sessionState.value = NfcSessionState.DeviceDetected("NFC Device / Contactless Card")
        delay(400)
        return true
    }

    override suspend fun readToken(): PaymentToken {
        _sessionState.value = NfcSessionState.ReadingToken(30)
        delay(300)
        _sessionState.value = NfcSessionState.ReadingToken(75)
        delay(300)

        // Generate tokenized payment identifier - NO RAW PAN / CVV
        val token = PaymentToken(
            tokenId = "TOKEN-NFC-" + UUID.randomUUID().toString().take(8).uppercase(),
            maskedPan = "•••• " + (1000..9999).random(),
            cardType = listOf("Visa Contactless", "Mastercard NFC", "Apple Pay", "Google Pay").random(),
            authCode = "AUTH-" + (100000..999999).random(),
            isDemo = true
        )

        _sessionState.value = NfcSessionState.TokenReceived(token)
        return token
    }

    override suspend fun cancelSession() {
        isCancelled = true
        _sessionState.value = NfcSessionState.Idle
    }

    override suspend fun closeSession() {
        _sessionState.value = NfcSessionState.Idle
    }
}
