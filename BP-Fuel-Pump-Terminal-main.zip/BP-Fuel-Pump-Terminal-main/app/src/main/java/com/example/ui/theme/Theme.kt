package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = BpDeepGreen,
    onPrimary = Color.White,
    primaryContainer = BpLightGreenBg,
    onPrimaryContainer = BpDeepGreen,
    secondary = BpBrightGreen,
    onSecondary = Color.White,
    background = BpBackgroundGray,
    onBackground = BpTextDark,
    surface = BpSurfaceWhite,
    onSurface = BpTextDark,
    surfaceVariant = Color(0xFFEBF0EB),
    onSurfaceVariant = BpTextMuted,
    outline = BpBorderGray,
    error = BpRedError
)

private val DarkColorScheme = darkColorScheme(
    primary = BpBrightGreen,
    onPrimary = BpDarkCharcoal,
    background = BpDarkCharcoal,
    onBackground = Color.White,
    surface = Color(0xFF282D29),
    onSurface = Color.White
)

@Composable
fun BpTerminalTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
