package com.example.data.health

import com.example.data.model.DeviceHealthComponent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class DeviceHealthMonitor {
    private val defaultComponents = listOf(
        DeviceHealthComponent("Touchscreen", "HEALTHY", 8L, details = "15.6\" High-Res Display OK"),
        DeviceHealthComponent("NFC Reader", "HEALTHY", 12L, details = "ISO 14443 Type A/B Contactless Antenna OK"),
        DeviceHealthComponent("Card Reader", "HEALTHY", 15L, details = "EMV Chip/Pin Sensor Online"),
        DeviceHealthComponent("Thermal Printer", "HEALTHY", 5L, details = "Paper Roll 85% Remaining"),
        DeviceHealthComponent("Network Gateway", "HEALTHY", 18L, details = "TLS 1.3 Enterprise Ethernet Connected"),
        DeviceHealthComponent("Pump Controller", "HEALTHY", 4L, details = "Flow Meter Calibration Verified"),
        DeviceHealthComponent("System Temp", "HEALTHY", 0L, details = "Core Temp: 38°C (Normal)"),
        DeviceHealthComponent("Storage", "HEALTHY", 0L, details = "32GB Industrial NVMe (12% Used)")
    )

    private val _health = MutableStateFlow(defaultComponents)
    val health: StateFlow<List<DeviceHealthComponent>> = _health.asStateFlow()

    fun updateComponentStatus(componentName: String, newStatus: String, details: String) {
        _health.value = _health.value.map { item ->
            if (item.name == componentName) {
                item.copy(status = newStatus, details = details, lastPing = System.currentTimeMillis())
            } else item
        }
    }

    fun getOverallStatus(): String {
        return when {
            _health.value.any { it.status == "ERROR" } -> "ERROR"
            _health.value.any { it.status == "WARNING" } -> "WARNING"
            _health.value.any { it.status == "OFFLINE" } -> "OFFLINE"
            else -> "HEALTHY"
        }
    }
}
