package com.example.data.forecourt

import com.example.data.model.ConnectivityState
import com.example.data.model.FuelGrade
import com.example.data.model.PumpState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ForecourtPumpSummary(
    val pumpNumber: Int,
    val pumpId: String,
    val status: PumpState,
    val activeFuel: String? = null,
    val litresThisSession: Double = 0.0,
    val valueThisSession: Double = 0.0,
    val healthStatus: String = "HEALTHY"
)

class ForecourtController {
    private val defaultPrices = listOf(
        FuelGrade(id = "1", name = "Ultimate", subName = "with ACTIVE technology", pricePerLitre = 1.759, colorHex = "#005F2E", isPremium = true),
        FuelGrade(id = "2", name = "Ultimate", subName = "with ACTIVE technology", pricePerLitre = 1.659, colorHex = "#6DB327", isPremium = true),
        FuelGrade(id = "3", name = "Regular Unleaded", subName = "standard unleaded petrol", pricePerLitre = 1.559, colorHex = "#007A3D", isPremium = false),
        FuelGrade(id = "4", name = "Diesel", subName = "standard forecourt diesel", pricePerLitre = 1.599, colorHex = "#1F2320", isPremium = false)
    )

    private val _fuelPrices = MutableStateFlow(defaultPrices)
    val fuelPrices: StateFlow<List<FuelGrade>> = _fuelPrices.asStateFlow()

    private val _pumps = MutableStateFlow(
        listOf(
            ForecourtPumpSummary(1, "PUMP-01", PumpState.IDLE, healthStatus = "HEALTHY"),
            ForecourtPumpSummary(2, "PUMP-02", PumpState.IDLE, healthStatus = "HEALTHY"),
            ForecourtPumpSummary(3, "PUMP-03", PumpState.FUELING, activeFuel = "Regular Unleaded", litresThisSession = 24.5, valueThisSession = 38.20, healthStatus = "HEALTHY"),
            ForecourtPumpSummary(4, "PUMP-04", PumpState.WELCOME, healthStatus = "HEALTHY"),
            ForecourtPumpSummary(5, "PUMP-05", PumpState.WARNING, healthStatus = "WARNING"),
            ForecourtPumpSummary(6, "PUMP-06", PumpState.OFFLINE, healthStatus = "OFFLINE")
        )
    )
    val pumps: StateFlow<List<ForecourtPumpSummary>> = _pumps.asStateFlow()

    private val _connectivity = MutableStateFlow(ConnectivityState.ONLINE)
    val connectivity: StateFlow<ConnectivityState> = _connectivity.asStateFlow()

    fun updatePrice(gradeId: String, newPrice: Double) {
        _fuelPrices.value = _fuelPrices.value.map { grade ->
            if (grade.id == gradeId) grade.copy(pricePerLitre = newPrice) else grade
        }
    }

    fun updatePumpStatus(pumpNumber: Int, newStatus: PumpState, litres: Double = 0.0, value: Double = 0.0) {
        _pumps.value = _pumps.value.map { pump ->
            if (pump.pumpNumber == pumpNumber) {
                pump.copy(
                    status = newStatus,
                    litresThisSession = litres,
                    valueThisSession = value
                )
            } else pump
        }
    }

    fun setConnectivity(state: ConnectivityState) {
        _connectivity.value = state
    }
}
