package com.example.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(txn: TransactionEntity)
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM audit_events ORDER BY timestamp DESC LIMIT 100")
    fun getRecentAuditLogs(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity)
}

@Dao
interface TelemetryDao {
    @Query("SELECT * FROM telemetry ORDER BY timestamp DESC LIMIT 50")
    fun getRecentTelemetry(): Flow<List<TelemetryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTelemetry(telemetry: TelemetryEntity)
}

@Dao
interface DeviceHealthDao {
    @Query("SELECT * FROM device_health")
    fun getDeviceHealth(): Flow<List<DeviceHealthEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun updateDeviceHealth(health: DeviceHealthEntity)
}

@Dao
interface FuelPriceDao {
    @Query("SELECT * FROM fuel_prices")
    fun getFuelPrices(): Flow<List<FuelPriceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFuelPrices(prices: List<FuelPriceEntity>)
}
