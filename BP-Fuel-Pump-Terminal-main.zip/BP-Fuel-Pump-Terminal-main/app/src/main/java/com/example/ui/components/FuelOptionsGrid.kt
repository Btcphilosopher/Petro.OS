package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FuelGrade
import com.example.ui.theme.BpTextMuted

@Composable
fun PricePerLitreFormatted(price: Double, color: Color = Color.White) {
    val priceStr = String.format("%.3f", price) // e.g. 1.759
    val base = "£" + priceStr.substring(0, 4) // "£1.75"
    val ninth = priceStr.substring(4) // "9"

    val annotatedStr = buildAnnotatedString {
        withStyle(style = SpanStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold, color = color)) {
            append(base)
        }
        withStyle(
            style = SpanStyle(
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                baselineShift = BaselineShift.Superscript,
                color = color
            )
        ) {
            append(ninth)
        }
    }

    Text(text = annotatedStr)
}

@Composable
fun FuelGradeCard(
    grade: FuelGrade,
    isSelected: Boolean = false,
    perLitreLabel: String = "per litre",
    onSelect: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgColor = when (grade.id) {
        "1" -> Color(0xFF005F2E) // Deep Green
        "2" -> Color(0xFF6DB327) // Bright Green
        "3" -> Color(0xFF007A3D) // Medium Green
        else -> Color(0xFF1F2320) // Charcoal Diesel
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(72.dp)
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onSelect)
            .testTag("fuel_card_${grade.id}"),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 4.dp else 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = grade.name,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                if (grade.hasActiveTech) {
                    val subStr = buildAnnotatedString {
                        withStyle(style = SpanStyle(color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp)) {
                            append("with ")
                        }
                        withStyle(
                            style = SpanStyle(
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontStyle = FontStyle.Italic
                            )
                        ) {
                            append("ACTIVE")
                        }
                        withStyle(style = SpanStyle(color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp)) {
                            append(" technology")
                        }
                    }
                    Text(text = subStr)
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.End) {
                    PricePerLitreFormatted(price = grade.pricePerLitre, color = Color.White)
                    Text(
                        text = perLitreLabel,
                        fontSize = 10.sp,
                        color = Color.White.copy(alpha = 0.8f)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "Select " + grade.name,
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

@Composable
fun FuelOptionsGrid(
    fuelGrades: List<FuelGrade>,
    selectedGradeId: String?,
    perLitreLabel: String = "per litre",
    onFuelSelected: (FuelGrade) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = "FUEL OPTIONS",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = BpTextMuted,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        fuelGrades.forEach { grade ->
            FuelGradeCard(
                grade = grade,
                isSelected = selectedGradeId == grade.id,
                perLitreLabel = perLitreLabel,
                onSelect = { onFuelSelected(grade) },
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }
    }
}
