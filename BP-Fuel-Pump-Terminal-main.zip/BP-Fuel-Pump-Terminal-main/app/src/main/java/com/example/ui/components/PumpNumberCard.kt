package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BpBorderGray
import com.example.ui.theme.BpDeepGreen
import com.example.ui.theme.BpTextMuted

@Composable
fun PumpNumberCard(
    pumpNumber: Int = 4,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, BpBorderGray, RoundedCornerShape(12.dp))
            .testTag("pump_number_card"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "PUMP",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = BpTextMuted,
                letterSpacing = 1.sp,
                modifier = Modifier.align(Alignment.Start)
            )

            Text(
                text = "$pumpNumber",
                fontSize = 72.sp,
                fontWeight = FontWeight.Black,
                color = BpDeepGreen,
                lineHeight = 72.sp
            )
        }
    }
}
