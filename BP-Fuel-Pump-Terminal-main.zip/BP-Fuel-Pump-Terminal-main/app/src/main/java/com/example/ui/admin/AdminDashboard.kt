package com.example.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.AuditLogEntity
import com.example.data.database.TransactionEntity
import com.example.data.forecourt.ForecourtPumpSummary
import com.example.data.model.DeviceHealthComponent
import com.example.ui.theme.BpBrightGreen
import com.example.ui.theme.BpDeepGreen
import com.example.ui.theme.BpRedError
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun AdminStatCard(title: String, value: String, subtitle: String = "") {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF333D33), RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E261E))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = title, fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, fontSize = 20.sp, fontWeight = FontWeight.Black, color = BpBrightGreen)
            if (subtitle.isNotEmpty()) {
                Text(text = subtitle, fontSize = 10.sp, color = Color.LightGray)
            }
        }
    }
}

@Composable
fun PumpGridTile(pump: ForecourtPumpSummary) {
    val statusColor = when (pump.status.name) {
        "FUELING" -> BpBrightGreen
        "IDLE", "WELCOME" -> Color(0xFF4CAF50)
        "WARNING" -> Color(0xFFFF9800)
        "OFFLINE" -> Color(0xFFF44336)
        else -> Color(0xFF2196F3)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF333D33), RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E261E))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "PUMP 0${pump.pumpNumber}", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                Box(
                    modifier = Modifier
                        .background(statusColor.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(text = pump.status.name, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = statusColor)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "Fuel: ${pump.activeFuel ?: "None"}", fontSize = 11.sp, color = Color.LightGray)
            Text(text = "Litres: ${String.format("%.1f", pump.litresThisSession)} L", fontSize = 11.sp, color = Color.LightGray)
        }
    }
}

@Composable
fun AdminDashboard(
    viewModel: TerminalViewModel,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pumps by viewModel.forecourtController.pumps.collectAsState()
    val healthComponents by viewModel.deviceHealthMonitor.health.collectAsState()
    val auditLogs by viewModel.recentAuditLogs.collectAsState(initial = emptyList())
    val transactions by viewModel.recentTransactions.collectAsState(initial = emptyList())
    val fuelPrices by viewModel.forecourtController.fuelPrices.collectAsState()

    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("FORECOURT OVERVIEW", "DEVICE HEALTH", "AUDIT LOGS", "PRICING & FAILURES")

    Surface(
        modifier = modifier.fillMaxSize(),
        color = Color(0xFF141A14)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Settings, contentDescription = null, tint = BpBrightGreen, modifier = Modifier.size(28.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "FORECOURT ENTERPRISE MANAGEMENT CONTROLLER",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }

                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color(0xFF1E261E),
                contentColor = BpBrightGreen
            ) {
                tabs.forEachIndexed { idx, title ->
                    Tab(
                        selected = selectedTab == idx,
                        onClick = { selectedTab = idx },
                        text = { Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            when (selectedTab) {
                0 -> {
                    // Overview Tab
                    Column(modifier = Modifier.fillMaxSize()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(modifier = Modifier.weight(1f)) { AdminStatCard("PUMPS ONLINE", "5 / 6", "1 Offline for maint") }
                            Box(modifier = Modifier.weight(1f)) { AdminStatCard("TODAY'S VOLUME", "1,842.5 L", "+12% vs yesterday") }
                            Box(modifier = Modifier.weight(1f)) { AdminStatCard("TODAY'S REVENUE", "£2,948.10", "128 Transactions") }
                            Box(modifier = Modifier.weight(1f)) { AdminStatCard("NFC PAYMENTS", "94.2%", "High contactless usage") }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Text("FORECOURT PUMP NETWORK GRID", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(10.dp))

                        LazyVerticalGrid(
                            columns = GridCells.Fixed(3),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            items(pumps) { pump ->
                                PumpGridTile(pump = pump)
                            }
                        }
                    }
                }

                1 -> {
                    // Device Health Tab
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(healthComponents) { component ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .border(1.dp, Color(0xFF333D33), RoundedCornerShape(8.dp)),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E261E))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(text = component.name, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                        Text(text = component.details, fontSize = 12.sp, color = Color.LightGray)
                                    }
                                    Box(
                                        modifier = Modifier
                                            .background(BpBrightGreen.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(text = component.status, color = BpBrightGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                2 -> {
                    // Audit Logs Tab
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(auditLogs) { log ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C221C))
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(text = log.eventType, fontWeight = FontWeight.Bold, color = BpBrightGreen, fontSize = 12.sp)
                                        Text(text = "Corr: ${log.correlationId}", fontSize = 10.sp, color = Color.Gray)
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(text = log.details, fontSize = 11.sp, color = Color.White)
                                }
                            }
                        }
                    }
                }

                3 -> {
                    // Pricing & Failures Tab
                    Column(modifier = Modifier.fillMaxSize()) {
                        Text("SIMULATE FORECOURT FAILURES", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = { viewModel.setFailureMode(decline = true) },
                                colors = ButtonDefaults.buttonColors(containerColor = BpRedError)
                            ) {
                                Text("FORCE CARD DECLINE")
                            }

                            Button(
                                onClick = { viewModel.setFailureMode(timeout = true) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9800))
                            ) {
                                Text("FORCE NETWORK TIMEOUT")
                            }

                            Button(
                                onClick = { viewModel.setFailureMode(offline = true) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9C27B0))
                            ) {
                                Text("TOGGLE OFFLINE MODE")
                            }

                            Button(
                                onClick = { viewModel.setFailureMode(decline = false, timeout = false, offline = false) },
                                colors = ButtonDefaults.buttonColors(containerColor = BpDeepGreen)
                            ) {
                                Text("RESET NORMAL MODE")
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Text("LIVE FUEL PRICES", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(10.dp))

                        fuelPrices.forEach { grade ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .background(Color(0xFF1E261E), RoundedCornerShape(8.dp))
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = grade.name, color = Color.White, fontWeight = FontWeight.Bold)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(text = "£${String.format("%.3f", grade.pricePerLitre)}/L", color = BpBrightGreen, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    OutlinedButton(
                                        onClick = {
                                            viewModel.forecourtController.updatePrice(grade.id, grade.pricePerLitre + 0.01)
                                        }
                                    ) {
                                        Text("+1p", color = Color.White)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
