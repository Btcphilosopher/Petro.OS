package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AuditLogEntity
import com.example.data.database.TerminalDatabase
import com.example.data.database.TransactionEntity
import com.example.data.forecourt.ForecourtController
import com.example.data.health.DeviceHealthMonitor
import com.example.data.localization.LocalizationManager
import com.example.data.loyalty.LoyaltyManager
import com.example.data.model.ConnectivityState
import com.example.data.model.FuelGrade
import com.example.data.model.Language
import com.example.data.model.NfcSessionState
import com.example.data.model.PaymentToken
import com.example.data.model.PreAuthRequest
import com.example.data.model.PumpState
import com.example.data.model.ReceiptInfo
import com.example.data.model.TelemetryData
import com.example.data.payment.MockNfcReader
import com.example.data.payment.MockPaymentProvider
import com.example.data.payment.PaymentTerminal
import com.example.data.pump.PumpDispenserSimulator
import com.example.data.pump.PumpStateMachine
import com.example.data.receipt.ReceiptGenerator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class TerminalViewModel(application: Application) : AndroidViewModel(application) {

    private val db = TerminalDatabase.getDatabase(application)
    
    // Core Managers & Engines
    val pumpStateMachine = PumpStateMachine(viewModelScope, db.auditLogDao())
    val dispenserSimulator = PumpDispenserSimulator(viewModelScope)
    
    val mockNfcReader = MockNfcReader()
    val mockPaymentProvider = MockPaymentProvider()
    val paymentTerminal = PaymentTerminal(mockNfcReader, mockPaymentProvider)

    val forecourtController = ForecourtController()
    val loyaltyManager = LoyaltyManager()
    val deviceHealthMonitor = DeviceHealthMonitor()
    val localizationManager = LocalizationManager()

    // UI View State Flags
    private val _isAdminMode = MutableStateFlow(false)
    val isAdminMode: StateFlow<Boolean> = _isAdminMode.asStateFlow()

    private val _isSimControlVisible = MutableStateFlow(true)
    val isSimControlVisible: StateFlow<Boolean> = _isSimControlVisible.asStateFlow()

    private val _isAccessibilityDialogVisible = MutableStateFlow(false)
    val isAccessibilityDialogVisible: StateFlow<Boolean> = _isAccessibilityDialogVisible.asStateFlow()

    private val _isLanguageDialogVisible = MutableStateFlow(false)
    val isLanguageDialogVisible: StateFlow<Boolean> = _isLanguageDialogVisible.asStateFlow()

    private val _isAssistanceActive = MutableStateFlow(false)
    val isAssistanceActive: StateFlow<Boolean> = _isAssistanceActive.asStateFlow()

    private val _currentReceipt = MutableStateFlow<ReceiptInfo?>(null)
    val currentReceipt: StateFlow<ReceiptInfo?> = _currentReceipt.asStateFlow()

    private val _highContrastMode = MutableStateFlow(false)
    val highContrastMode: StateFlow<Boolean> = _highContrastMode.asStateFlow()

    private val _largeTextMode = MutableStateFlow(false)
    val largeTextMode: StateFlow<Boolean> = _largeTextMode.asStateFlow()

    private val _audioGuidanceActive = MutableStateFlow(false)
    val audioGuidanceActive: StateFlow<Boolean> = _audioGuidanceActive.asStateFlow()

    private var currentTxnId: String = ""
    private var currentPaymentToken: PaymentToken? = null

    // Audit logs & Recent transactions from DB
    val recentAuditLogs = db.auditLogDao().getRecentAuditLogs()
    val recentTransactions = db.transactionDao().getAllTransactions()
    val dbDeviceHealth = db.deviceHealthDao().getDeviceHealth()

    init {
        // Wire state machine listener
        pumpStateMachine.onStateChangedListener = { oldState, newState ->
            forecourtController.updatePumpStatus(
                pumpNumber = 4,
                newStatus = newState,
                litres = dispenserSimulator.telemetry.value.volumeDispensedLitres,
                value = dispenserSimulator.telemetry.value.totalValueAmount
            )
        }
    }

    fun toggleAdminMode() {
        _isAdminMode.value = !_isAdminMode.value
    }

    fun toggleSimControlBar() {
        _isSimControlVisible.value = !_isSimControlVisible.value
    }

    fun toggleAccessibilityDialog() {
        _isAccessibilityDialogVisible.value = !_isAccessibilityDialogVisible.value
    }

    fun toggleLanguageDialog() {
        _isLanguageDialogVisible.value = !_isLanguageDialogVisible.value
    }

    fun setLanguage(language: Language) {
        localizationManager.setLanguage(language)
        _isLanguageDialogVisible.value = false
    }

    fun toggleHighContrast() {
        _highContrastMode.value = !_highContrastMode.value
    }

    fun toggleLargeText() {
        _largeTextMode.value = !_largeTextMode.value
    }

    fun toggleAudioGuidance() {
        _audioGuidanceActive.value = !_audioGuidanceActive.value
    }

    fun requestAssistance() {
        _isAssistanceActive.value = true
        viewModelScope.launch {
            db.auditLogDao().insertAuditLog(
                AuditLogEntity(
                    id = java.util.UUID.randomUUID().toString(),
                    timestamp = System.currentTimeMillis(),
                    stationId = "ST-001",
                    pumpId = "PUMP-04",
                    transactionId = currentTxnId,
                    eventType = "ASSISTANCE_REQUESTED",
                    eventSource = "CUSTOMER_UI",
                    result = "SUCCESS",
                    correlationId = pumpStateMachine.correlationId.value,
                    details = "Customer pressed HELP button on touchscreen"
                )
            )
        }
    }

    fun dismissAssistance() {
        _isAssistanceActive.value = false
    }

    // Customer Actions in State Machine
    fun onSelectFuel(fuelGrade: FuelGrade) {
        pumpStateMachine.selectFuelGrade(fuelGrade)
        pumpStateMachine.transitionTo(PumpState.PAYMENT_SELECTION, "Customer selected ${fuelGrade.name}")
    }

    fun startNfcPaymentFlow() {
        pumpStateMachine.transitionTo(PumpState.NFC_WAITING, "Waiting for NFC tap")
        viewModelScope.launch {
            mockNfcReader.startSession()
        }
    }

    // Hardware Simulation Triggers
    fun simulateNfcTap() {
        if (pumpStateMachine.state.value != PumpState.NFC_WAITING &&
            pumpStateMachine.state.value != PumpState.PAYMENT_SELECTION) {
            // Auto jump to NFC waiting if needed
            startNfcPaymentFlow()
        }

        viewModelScope.launch {
            val detected = mockNfcReader.detectPaymentDevice()
            if (detected) {
                pumpStateMachine.transitionTo(PumpState.PAYMENT_AUTHORIZING, "Reading NFC Token")
                val token = mockNfcReader.readToken()
                currentPaymentToken = token

                val req = PreAuthRequest(
                    pumpId = "PUMP-04",
                    fuelGradeId = pumpStateMachine.selectedFuel.value?.id ?: "1",
                    maxAmount = 99.00
                )
                val response = mockPaymentProvider.authorizePreAuth(req, token)

                if (response.isApproved) {
                    currentTxnId = response.transactionId
                    pumpStateMachine.transitionTo(PumpState.PAYMENT_APPROVED, "Pre-auth approved £99.00 (Txn: ${response.transactionId})")
                } else {
                    if (response.errorMessage?.contains("TIMEOUT") == true) {
                        pumpStateMachine.transitionTo(PumpState.PAYMENT_TIMEOUT, response.errorMessage)
                    } else {
                        pumpStateMachine.transitionTo(PumpState.PAYMENT_DECLINED, response.errorMessage ?: "Card Declined")
                    }
                }
            }
        }
    }

    fun simulateRemoveNozzle() {
        val currentState = pumpStateMachine.state.value
        if (currentState == PumpState.PAYMENT_APPROVED || currentState == PumpState.WELCOME || currentState == PumpState.IDLE) {
            pumpStateMachine.transitionTo(PumpState.NOZZLE_REMOVED, "Nozzle removed from cradle")
            val fuel = pumpStateMachine.selectedFuel.value ?: forecourtController.fuelPrices.value.first()
            if (pumpStateMachine.selectedFuel.value == null) {
                pumpStateMachine.selectFuelGrade(fuel)
            }
            dispenserSimulator.resetTelemetry()
            pumpStateMachine.transitionTo(PumpState.FUELING, "Fuel dispenser motor active, ready to pump")
            dispenserSimulator.startFueling(fuel, PumpState.FUELING)
        }
    }

    fun toggleSqueezeTrigger() {
        dispenserSimulator.isTriggerSqueezed = !dispenserSimulator.isTriggerSqueezed
    }

    fun simulateReturnNozzle() {
        if (pumpStateMachine.state.value == PumpState.FUELING || pumpStateMachine.state.value == PumpState.NOZZLE_REMOVED) {
            dispenserSimulator.stopFueling()
            val telemetry = dispenserSimulator.telemetry.value
            val litres = telemetry.volumeDispensedLitres
            val totalVal = telemetry.totalValueAmount
            val fuel = pumpStateMachine.selectedFuel.value ?: forecourtController.fuelPrices.value.first()

            pumpStateMachine.transitionTo(PumpState.FUELING_COMPLETE, "Nozzle returned to cradle. Dispensed: ${litres}L")
            
            // Capture pre-auth
            viewModelScope.launch {
                mockPaymentProvider.captureTransaction(currentTxnId, totalVal)
                val pts = loyaltyManager.calculatePoints(litres)
                loyaltyManager.addPoints(pts)

                val receipt = ReceiptGenerator.generateReceipt(
                    transactionId = if (currentTxnId.isNotEmpty()) currentTxnId else "DEMO-TXN-" + System.currentTimeMillis().toString().takeLast(6),
                    fuelName = fuel.name,
                    pricePerLitre = fuel.pricePerLitre,
                    litres = litres,
                    totalAmount = totalVal,
                    maskedCard = currentPaymentToken?.maskedPan ?: "•••• 8821",
                    authCode = currentPaymentToken?.authCode ?: "AUTH-991823",
                    pointsEarned = pts
                )
                _currentReceipt.value = receipt

                // Save to Room DB
                db.transactionDao().insertTransaction(
                    TransactionEntity(
                        txnId = receipt.transactionId,
                        stationId = "ST-001",
                        pumpId = "PUMP-04",
                        fuelGradeName = fuel.name,
                        pricePerLitre = fuel.pricePerLitre,
                        volumeLitres = litres,
                        totalAmount = totalVal,
                        paymentToken = currentPaymentToken?.tokenId ?: "TOK-DEMO",
                        authCode = receipt.authCode,
                        status = "CAPTURED",
                        timestamp = System.currentTimeMillis()
                    )
                )

                pumpStateMachine.transitionTo(PumpState.TRANSACTION_COMPLETE, "Transaction captured: £$totalVal")
            }
        }
    }

    fun showReceiptScreen() {
        pumpStateMachine.transitionTo(PumpState.RECEIPT, "Customer selected receipt view")
    }

    fun resetTerminal() {
        dispenserSimulator.resetTelemetry()
        currentTxnId = ""
        currentPaymentToken = null
        _currentReceipt.value = null
        pumpStateMachine.transitionTo(PumpState.IDLE, "Terminal reset to IDLE")
        pumpStateMachine.transitionTo(PumpState.WELCOME, "Terminal ready for next customer")
    }

    fun triggerEmergencyStop() {
        dispenserSimulator.stopFueling()
        pumpStateMachine.transitionTo(PumpState.EMERGENCY_STOP, "EMERGENCY STOP PRESSED BY OPERATOR / CUSTOMER")
    }

    fun setFailureMode(decline: Boolean = false, timeout: Boolean = false, offline: Boolean = false) {
        mockPaymentProvider.forceDecline = decline
        mockPaymentProvider.forceTimeout = timeout
        if (offline) {
            forecourtController.setConnectivity(ConnectivityState.OFFLINE)
            pumpStateMachine.transitionTo(PumpState.COMMUNICATION_ERROR, "Network connection lost")
        } else {
            forecourtController.setConnectivity(ConnectivityState.ONLINE)
            if (pumpStateMachine.state.value == PumpState.COMMUNICATION_ERROR) {
                pumpStateMachine.transitionTo(PumpState.WELCOME, "Network connection restored")
            }
        }
    }

    fun runAutoSimulatorSequence() {
        viewModelScope.launch {
            resetTerminal()
            kotlinx.coroutines.delay(1000)
            val fuels = forecourtController.fuelPrices.value
            onSelectFuel(fuels[0]) // Ultimate Unleaded
            kotlinx.coroutines.delay(1200)
            startNfcPaymentFlow()
            kotlinx.coroutines.delay(800)
            simulateNfcTap()
            kotlinx.coroutines.delay(2000)
            simulateRemoveNozzle()
            kotlinx.coroutines.delay(4000) // Fuel for 4 sec
            simulateReturnNozzle()
            kotlinx.coroutines.delay(1500)
            showReceiptScreen()
        }
    }
}
