package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BpBrightGreen
import com.example.ui.theme.BpDeepGreen
import com.example.ui.theme.BpTextDark
import com.example.ui.theme.BpTextMuted
import com.example.ui.theme.BpYellowAccent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun BpFlowerLogo(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.size(42.dp)) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val petCount = 12
        val radius = size.width * 0.38f
        val petalRadius = size.width * 0.16f

        // Draw radial sunburst petals (Yellow outer, bright green mid, deep green inner)
        for (i in 0 until petCount) {
            val angle = (i * 360f / petCount) * (Math.PI / 180f)
            val px = center.x + cos(angle).toFloat() * radius * 0.7f
            val py = center.y + sin(angle).toFloat() * radius * 0.7f

            val color = when (i % 3) {
                0 -> BpYellowAccent
                1 -> BpBrightGreen
                else -> BpDeepGreen
            }

            drawCircle(
                color = color,
                radius = petalRadius,
                center = Offset(px, py)
            )
        }
        // Center white circle
        drawCircle(
            color = Color.White,
            radius = size.width * 0.18f,
            center = center
        )
    }
}

@Composable
fun HeaderBar(
    welcomeText: String = "Welcome",
    taglineText: String = "Fuel your journey",
    isDemoMode: Boolean = true,
    modifier: Modifier = Modifier
) {
    var currentTimeStr by remember { mutableStateOf("") }
    var currentDateStr by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        while (true) {
            val now = Date()
            currentTimeStr = SimpleDateFormat("HH:mm", Locale.UK).format(now)
            currentDateStr = SimpleDateFormat("EEE, dd MMM", Locale.UK).format(now)
            kotlinx.coroutines.delay(1000)
        }
    }

    Column(modifier = modifier.fillMaxWidth()) {
        if (isDemoMode) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFE8F5E9))
                    .padding(vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "• DEMO MODE — SIMULATED FORECOURT TERMINAL & NFC PROVIDER •",
                    color = BpDeepGreen,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                BpFlowerLogo()
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "bp",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = BpDeepGreen,
                    modifier = Modifier.testTag("bp_logo_text")
                )

                Spacer(modifier = Modifier.width(36.dp))

                Column {
                    Text(
                        text = welcomeText,
                        fontSize = 14.sp,
                        color = BpTextMuted
                    )
                    Text(
                        text = taglineText,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = BpDeepGreen
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = currentTimeStr,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = BpTextDark
                )
                Text(
                    text = currentDateStr,
                    fontSize = 13.sp,
                    color = BpTextMuted
                )
            }
        }
    }
}
