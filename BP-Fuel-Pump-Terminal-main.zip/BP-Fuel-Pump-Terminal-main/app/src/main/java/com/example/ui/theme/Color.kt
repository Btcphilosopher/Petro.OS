package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// BP Brand Colors
val BpDeepGreen = Color(0xFF006F3B)
val BpBrightGreen = Color(0xFF76B82A)
val BpMediumGreen = Color(0xFF008744)
val BpDarkCharcoal = Color(0xFF1E2420)
val BpLightGreenBg = Color(0xFFEAF5E9)
val BpBackgroundGray = Color(0xFFF3F5F3)
val BpSurfaceWhite = Color(0xFFFFFFFF)
val BpTextDark = Color(0xFF111411)
val BpTextMuted = Color(0xFF606660)
val BpBorderGray = Color(0xFFE0E4E0)
val BpYellowAccent = Color(0xFFFFC72C)
val BpRedError = Color(0xFFD32F2F)
