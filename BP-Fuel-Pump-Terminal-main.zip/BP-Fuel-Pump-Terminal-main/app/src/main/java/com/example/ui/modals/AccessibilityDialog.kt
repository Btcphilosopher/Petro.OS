package com.example.ui.modals

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BpBrightGreen
import com.example.ui.theme.BpDeepGreen

@Composable
fun AccessibilityDialog(
    highContrastMode: Boolean,
    largeTextMode: Boolean,
    audioGuidanceActive: Boolean,
    onToggleHighContrast: () -> Unit,
    onToggleLargeText: () -> Unit,
    onToggleAudioGuidance: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = Color.Black.copy(alpha = 0.75f)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Card(
                modifier = Modifier
                    .width(420.dp)
                    .padding(24.dp)
                    .testTag("accessibility_dialog"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                ) {
                    Text(
                        text = "ACCESSIBILITY FEATURES",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = BpDeepGreen
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "High Contrast Display", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(text = "Sharpen borders & colors", fontSize = 12.sp, color = Color.Gray)
                        }
                        Switch(
                            checked = highContrastMode,
                            onCheckedChange = { onToggleHighContrast() },
                            colors = SwitchDefaults.colors(checkedThumbColor = BpBrightGreen)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "Large Text Scale", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(text = "Increase font sizes for visibility", fontSize = 12.sp, color = Color.Gray)
                        }
                        Switch(
                            checked = largeTextMode,
                            onCheckedChange = { onToggleLargeText() },
                            colors = SwitchDefaults.colors(checkedThumbColor = BpBrightGreen)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "Audio Guidance Prompts", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(text = "Spoken text-to-speech cues", fontSize = 12.sp, color = Color.Gray)
                        }
                        Switch(
                            checked = audioGuidanceActive,
                            onCheckedChange = { onToggleAudioGuidance() },
                            colors = SwitchDefaults.colors(checkedThumbColor = BpBrightGreen)
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = BpDeepGreen),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("CLOSE")
                    }
                }
            }
        }
    }
}
