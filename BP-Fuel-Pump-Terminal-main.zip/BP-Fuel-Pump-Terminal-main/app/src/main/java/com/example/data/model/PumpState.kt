package com.example.data.model

/**
 * Deterministic finite state machine states for the Fuel Pump Terminal.
 */
enum class PumpState {
    IDLE,
    CUSTOMER_DETECTED,
    WELCOME,
    FUEL_SELECTION,
    PAYMENT_SELECTION,
    NFC_WAITING,
    PAYMENT_AUTHORIZING,
    PAYMENT_APPROVED,
    NOZZLE_REMOVED,
    FUELING,
    FUELING_COMPLETE,
    TRANSACTION_COMPLETE,
    RECEIPT,
    RESET,
    
    // Exception / Error States
    WARNING,
    OFFLINE,
    PAYMENT_DECLINED,
    PAYMENT_TIMEOUT,
    NFC_ERROR,
    PUMP_ERROR,
    NOZZLE_ERROR,
    COMMUNICATION_ERROR,
    EMERGENCY_STOP,
    OUT_OF_SERVICE,
    MAINTENANCE_MODE
}

enum class ConnectivityState {
    ONLINE,
    DEGRADED,
    OFFLINE,
    MAINTENANCE
}

enum class Language(val code: String, val displayName: String, val flag: String) {
    ENGLISH("en", "English", "🇬🇧"),
    WELSH("cy", "Cymraeg", "🏴󠁧󠁢󠁷󠁬󠁳󠁿"),
    FRENCH("fr", "Français", "🇫🇷"),
    GERMAN("de", "Deutsch", "🇩🇪")
}
