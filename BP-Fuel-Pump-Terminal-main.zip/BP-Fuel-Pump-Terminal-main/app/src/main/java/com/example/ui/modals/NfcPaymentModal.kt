package com.example.ui.modals

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Contactless
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FuelGrade
import com.example.data.model.PumpState
import com.example.ui.theme.BpBrightGreen
import com.example.ui.theme.BpDeepGreen
import com.example.ui.theme.BpRedError

@Composable
fun NfcPulseAnimation(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "nfcPulse")
    val radiusRatio by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "nfcRadius"
    )
    val alphaRatio by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "nfcAlpha"
    )

    Box(
        modifier = modifier.size(160.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val maxR = size.width / 2f
            drawCircle(
                color = BpBrightGreen.copy(alpha = alphaRatio),
                radius = maxR * radiusRatio,
                style = Stroke(width = 6.dp.toPx())
            )
        }

        Box(
            modifier = Modifier
                .size(80.dp)
                .background(BpDeepGreen, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Contactless,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(48.dp)
            )
        }
    }
}

@Composable
fun NfcPaymentModal(
    pumpState: PumpState,
    selectedFuel: FuelGrade?,
    onSimulateTap: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxSize(),
        color = Color.Black.copy(alpha = 0.75f)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Card(
                modifier = Modifier
                    .width(480.dp)
                    .padding(24.dp)
                    .testTag("nfc_payment_modal"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "HOW WOULD YOU LIKE TO PAY?",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    selectedFuel?.let { fuel ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFFF3F5F3), RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = fuel.name, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = BpDeepGreen)
                                Text(text = "Pre-Authorization hold: £99.00 max", fontSize = 12.sp, color = Color.Gray)
                            }
                            Text(
                                text = "£${String.format("%.3f", fuel.pricePerLitre)}/L",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = BpDeepGreen
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    when (pumpState) {
                        PumpState.NFC_WAITING, PumpState.PAYMENT_SELECTION -> {
                            NfcPulseAnimation()
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "TAP TO PAY",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                color = BpDeepGreen
                            )
                            Text(
                                text = "Hold contactless card or mobile wallet against screen",
                                fontSize = 13.sp,
                                color = Color.Gray,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }

                        PumpState.PAYMENT_AUTHORIZING -> {
                            CircularProgressIndicator(
                                color = BpBrightGreen,
                                strokeWidth = 4.dp,
                                modifier = Modifier.size(60.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "AUTHORIZING PAYMENT...",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = BpDeepGreen
                            )
                            Text(
                                text = "Tokenizing credentials & checking bank pre-authorization",
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                        }

                        PumpState.PAYMENT_APPROVED -> {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = BpBrightGreen,
                                modifier = Modifier.size(72.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "PAYMENT APPROVED",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                color = BpDeepGreen
                            )
                            Text(
                                text = "Pump 04 Enabled. Please lift nozzle to begin fueling.",
                                fontSize = 13.sp,
                                color = Color.Gray
                            )
                        }

                        PumpState.PAYMENT_DECLINED, PumpState.PAYMENT_TIMEOUT, PumpState.NFC_ERROR -> {
                            Icon(
                                imageVector = Icons.Default.Error,
                                contentDescription = null,
                                tint = BpRedError,
                                modifier = Modifier.size(72.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = if (pumpState == PumpState.PAYMENT_TIMEOUT) "PAYMENT TIMEOUT" else "PAYMENT DECLINED",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = BpRedError
                            )
                            Text(
                                text = "Transaction was not authorized. Please try another card or pay inside.",
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                        }

                        else -> {}
                    }

                    Spacer(modifier = Modifier.height(28.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        OutlinedButton(
                            onClick = onCancel,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = BpDeepGreen),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("CANCEL")
                        }

                        if (pumpState == PumpState.NFC_WAITING || pumpState == PumpState.PAYMENT_SELECTION) {
                            Spacer(modifier = Modifier.width(12.dp))
                            Button(
                                onClick = onSimulateTap,
                                colors = ButtonDefaults.buttonColors(containerColor = BpDeepGreen),
                                modifier = Modifier
                                    .weight(1.4f)
                                    .testTag("simulate_nfc_tap_button")
                            ) {
                                Icon(Icons.Default.Smartphone, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("TAP PHONE / CARD")
                            }
                        }
                    }
                }
            }
        }
    }
}
