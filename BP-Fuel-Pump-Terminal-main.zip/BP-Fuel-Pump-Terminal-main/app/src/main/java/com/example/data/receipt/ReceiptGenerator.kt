package com.example.data.receipt

import com.example.data.model.ReceiptInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ReceiptGenerator {
    fun generateReceipt(
        transactionId: String,
        fuelName: String,
        pricePerLitre: Double,
        litres: Double,
        totalAmount: Double,
        maskedCard: String,
        authCode: String,
        pointsEarned: Int
    ): ReceiptInfo {
        val dateStr = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.UK).format(Date())
        val qrPayload = "BP-FORECOURT-RECEIPT|$transactionId|$totalAmount|$litres|$dateStr"
        return ReceiptInfo(
            transactionId = transactionId,
            timestamp = System.currentTimeMillis(),
            stationName = "BP Mayfair Forecourt 001",
            pumpNumber = 4,
            fuelName = fuelName,
            pricePerLitre = pricePerLitre,
            litresDispensed = litres,
            totalAmount = totalAmount,
            paymentMaskedCard = maskedCard,
            authCode = authCode,
            pointsEarned = pointsEarned,
            qrPayload = qrPayload
        )
    }
}
