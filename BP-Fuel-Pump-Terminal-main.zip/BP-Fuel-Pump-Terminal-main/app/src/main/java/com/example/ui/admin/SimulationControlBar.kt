package com.example.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BpBrightGreen
import com.example.ui.theme.BpDeepGreen
import com.example.ui.theme.BpRedError

@Composable
fun SimulationControlBar(
    onSimulateNfcTap: () -> Unit,
    onRemoveNozzle: () -> Unit,
    onReturnNozzle: () -> Unit,
    onEmergencyStop: () -> Unit,
    onRunAutoSequence: () -> Unit,
    onResetTerminal: () -> Unit,
    onOpenAdminDashboard: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(50.dp)
            .background(Color(0xFF1B221B))
            .border(1.dp, Color(0xFF333D33))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "HARDWARE SIM:",
                fontSize = 11.sp,
                fontWeight = FontWeight.Black,
                color = BpBrightGreen,
                letterSpacing = 0.5.sp
            )

            Spacer(modifier = Modifier.width(10.dp))

            Button(
                onClick = onSimulateNfcTap,
                colors = ButtonDefaults.buttonColors(containerColor = BpDeepGreen),
                modifier = Modifier
                    .height(36.dp)
                    .testTag("sim_bar_nfc_tap")
            ) {
                Icon(Icons.Default.Smartphone, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("TAP NFC", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.width(6.dp))

            Button(
                onClick = onRemoveNozzle,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                modifier = Modifier
                    .height(36.dp)
                    .testTag("sim_bar_lift_nozzle")
            ) {
                Icon(Icons.Default.LocalGasStation, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("LIFT NOZZLE", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.width(6.dp))

            Button(
                onClick = onReturnNozzle,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF388E3C)),
                modifier = Modifier
                    .height(36.dp)
                    .testTag("sim_bar_return_nozzle")
            ) {
                Text("FINISH / RETURN", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.width(6.dp))

            Button(
                onClick = onRunAutoSequence,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2)),
                modifier = Modifier
                    .height(36.dp)
                    .testTag("sim_bar_auto_demo")
            ) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("AUTO DEMO", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(
                onClick = onEmergencyStop,
                colors = ButtonDefaults.buttonColors(containerColor = BpRedError),
                modifier = Modifier.height(36.dp)
            ) {
                Icon(Icons.Default.Warning, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("STOP", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.width(6.dp))

            OutlinedButton(
                onClick = onResetTerminal,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                modifier = Modifier.height(36.dp)
            ) {
                Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("RESET", fontSize = 11.sp)
            }

            Spacer(modifier = Modifier.width(6.dp))

            Button(
                onClick = onOpenAdminDashboard,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF424242)),
                modifier = Modifier
                    .height(36.dp)
                    .testTag("sim_bar_admin_dashboard")
            ) {
                Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("ADMIN", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
