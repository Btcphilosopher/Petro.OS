package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BpBorderGray
import com.example.ui.theme.BpBrightGreen
import com.example.ui.theme.BpDeepGreen
import com.example.ui.theme.BpTextDark
import com.example.ui.theme.BpTextMuted

@Composable
fun AssistanceCard(
    title: String = "NEED ASSISTANCE?",
    description: String = "Press the help button on the screen or contact staff",
    isAssistanceActive: Boolean = false,
    onHelpClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val containerBg by animateColorAsState(
        targetValue = if (isAssistanceActive) Color(0xFFFFF3E0) else Color(0xFFF7F9F7),
        label = "assistanceBg"
    )

    val borderClr by animateColorAsState(
        targetValue = if (isAssistanceActive) Color(0xFFFF9800) else BpBorderGray,
        label = "assistanceBorder"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, borderClr, RoundedCornerShape(12.dp))
            .clickable(onClick = onHelpClick)
            .testTag("assistance_card"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = containerBg),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isAssistanceActive) Color(0xFFE65100) else BpTextDark,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isAssistanceActive) "STAFF NOTIFIED — ATTENDANT COMING" else description,
                    fontSize = 11.sp,
                    color = if (isAssistanceActive) Color(0xFFE65100) else BpTextMuted
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Icon(
                imageVector = Icons.Default.HeadsetMic,
                contentDescription = "Help",
                tint = if (isAssistanceActive) Color(0xFFFF9800) else BpBrightGreen,
                modifier = Modifier.size(36.dp)
            )
        }
    }
}
