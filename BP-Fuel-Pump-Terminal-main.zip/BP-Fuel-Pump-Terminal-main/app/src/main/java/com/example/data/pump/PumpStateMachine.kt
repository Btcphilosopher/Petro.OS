package com.example.data.pump

import com.example.data.database.AuditLogDao
import com.example.data.database.AuditLogEntity
import com.example.data.model.AuditRecord
import com.example.data.model.FuelGrade
import com.example.data.model.PumpState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class PumpStateMachine(
    private val scope: CoroutineScope,
    private val auditLogDao: AuditLogDao? = null
) {
    private val _state = MutableStateFlow(PumpState.IDLE)
    val state: StateFlow<PumpState> = _state.asStateFlow()

    private val _selectedFuel = MutableStateFlow<FuelGrade?>(null)
    val selectedFuel: StateFlow<FuelGrade?> = _selectedFuel.asStateFlow()

    private val _correlationId = MutableStateFlow(UUID.randomUUID().toString().take(12))
    val correlationId: StateFlow<String> = _correlationId.asStateFlow()

    var onStateChangedListener: ((PumpState, PumpState) -> Unit)? = null

    fun transitionTo(newState: PumpState, details: String = "") {
        val oldState = _state.value
        if (oldState == newState) return

        if (newState == PumpState.IDLE || newState == PumpState.WELCOME) {
            _correlationId.value = UUID.randomUUID().toString().take(12)
        }

        _state.value = newState

        // Log audit record
        logAudit(
            eventType = "STATE_TRANSITION_${oldState.name}_TO_${newState.name}",
            details = if (details.isNotEmpty()) details else "Transitioned from $oldState to $newState"
        )

        onStateChangedListener?.invoke(oldState, newState)
    }

    fun selectFuelGrade(fuelGrade: FuelGrade) {
        _selectedFuel.value = fuelGrade
        logAudit("FUEL_SELECTED", "Selected fuel grade: ${fuelGrade.name} (£${fuelGrade.pricePerLitre}/L)")
    }

    private fun logAudit(eventType: String, details: String) {
        val record = AuditRecord(
            timestamp = System.currentTimeMillis(),
            stationId = "ST-001",
            pumpId = "PUMP-04",
            eventType = eventType,
            correlationId = _correlationId.value,
            details = details
        )
        auditLogDao?.let { dao ->
            scope.launch(Dispatchers.IO) {
                dao.insertAuditLog(
                    AuditLogEntity(
                        id = record.id,
                        timestamp = record.timestamp,
                        stationId = record.stationId,
                        pumpId = record.pumpId,
                        transactionId = record.transactionId,
                        eventType = record.eventType,
                        eventSource = record.eventSource,
                        result = record.result,
                        correlationId = record.correlationId,
                        details = record.details
                    )
                )
            }
        }
    }
}
