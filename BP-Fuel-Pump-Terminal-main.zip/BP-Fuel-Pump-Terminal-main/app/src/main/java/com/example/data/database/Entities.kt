package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stations")
data class StationEntity(
    @PrimaryKey val stationId: String,
    val name: String,
    val address: String,
    val currencySymbol: String = "£"
)

@Entity(tableName = "pumps")
data class PumpEntity(
    @PrimaryKey val pumpId: String,
    val stationId: String,
    val pumpNumber: Int,
    val state: String,
    val activeFuelId: String?,
    val connectivityState: String
)

@Entity(tableName = "fuel_prices")
data class FuelPriceEntity(
    @PrimaryKey val gradeId: String,
    val name: String,
    val subName: String,
    val pricePerLitre: Double,
    val colorHex: String,
    val isPremium: Boolean
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val txnId: String,
    val stationId: String,
    val pumpId: String,
    val fuelGradeName: String,
    val pricePerLitre: Double,
    val volumeLitres: Double,
    val totalAmount: Double,
    val paymentToken: String,
    val authCode: String,
    val status: String,
    val timestamp: Long
)

@Entity(tableName = "audit_events")
data class AuditLogEntity(
    @PrimaryKey val id: String,
    val timestamp: Long,
    val stationId: String,
    val pumpId: String,
    val transactionId: String,
    val eventType: String,
    val eventSource: String,
    val result: String,
    val correlationId: String,
    val details: String
)

@Entity(tableName = "telemetry")
data class TelemetryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val pumpId: String,
    val flowRateLpm: Double,
    val volumeDispensedLitres: Double,
    val totalValueAmount: Double,
    val temperatureCelsius: Double,
    val pumpStatus: String
)

@Entity(tableName = "device_health")
data class DeviceHealthEntity(
    @PrimaryKey val componentId: String,
    val pumpId: String,
    val name: String,
    val status: String,
    val latencyMs: Long,
    val lastPing: Long,
    val details: String
)
