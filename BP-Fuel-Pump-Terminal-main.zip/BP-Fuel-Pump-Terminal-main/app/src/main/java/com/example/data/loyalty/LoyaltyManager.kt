package com.example.data.loyalty

import com.example.data.model.CustomerLoyaltyAccount
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class LoyaltyManager {
    private val _account = MutableStateFlow(CustomerLoyaltyAccount())
    val account: StateFlow<CustomerLoyaltyAccount> = _account.asStateFlow()

    fun calculatePoints(litres: Double): Int {
        return litres.toInt() // 1 point per litre
    }

    fun addPoints(points: Int) {
        val current = _account.value
        _account.value = current.copy(pointsBalance = current.pointsBalance + points)
    }
}
