package com.example.data.model

import java.util.UUID

sealed class NfcSessionState {
    object Idle : NfcSessionState()
    object WaitingForDevice : NfcSessionState()
    data class DeviceDetected(val deviceType: String = "NFC Smartphone / Apple Pay") : NfcSessionState()
    data class ReadingToken(val progressPercent: Int = 50) : NfcSessionState()
    data class TokenReceived(val token: PaymentToken) : NfcSessionState()
    data class Error(val message: String) : NfcSessionState()
}

data class FuelGrade(
    val id: String,
    val name: String,
    val subName: String = "with ACTIVE technology",
    val pricePerLitre: Double, // e.g. 1.759
    val colorHex: String,
    val isPremium: Boolean = false,
    val hasActiveTech: Boolean = true
)

enum class PaymentMethodType {
    NFC_TAP,
    CONTACTLESS_CARD,
    CHIP_PIN,
    BPME_APP
}

data class PaymentToken(
    val tokenId: String = "TOK-" + UUID.randomUUID().toString().take(8).uppercase(),
    val maskedPan: String = "•••• " + (1000..9999).random(),
    val cardType: String = "VISA Contactless",
    val authCode: String = "AUTH-" + (100000..999999).random(),
    val timestamp: Long = System.currentTimeMillis(),
    val isDemo: Boolean = true
)

data class PreAuthRequest(
    val pumpId: String,
    val fuelGradeId: String,
    val maxAmount: Double = 99.00,
    val paymentMethod: PaymentMethodType = PaymentMethodType.NFC_TAP
)

data class PreAuthResponse(
    val isApproved: Boolean,
    val authCode: String?,
    val token: PaymentToken?,
    val authorizedAmount: Double,
    val transactionId: String,
    val errorMessage: String? = null
)

data class TelemetryData(
    val timestamp: Long = System.currentTimeMillis(),
    val stationId: String = "ST-001",
    val pumpId: String = "PUMP-04",
    val nozzleId: String = "NOZZLE-01",
    val fuelGrade: String = "Regular Unleaded",
    val flowRateLpm: Double = 0.0, // Litres per minute
    val volumeDispensedLitres: Double = 0.0,
    val pricePerLitre: Double = 1.559,
    val totalValueAmount: Double = 0.0,
    val temperatureCelsius: Double = 19.5,
    val pumpStatus: PumpState = PumpState.IDLE,
    val communicationStatus: ConnectivityState = ConnectivityState.ONLINE
)

data class DeviceHealthComponent(
    val name: String, // Touchscreen, NFC Reader, Card Reader, Printer, Network, Pump Controller, Temperature, Storage
    val status: String, // HEALTHY, WARNING, ERROR, OFFLINE
    val latencyMs: Long = 12L,
    val lastPing: Long = System.currentTimeMillis(),
    val details: String = "Operational"
)

data class AuditRecord(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val stationId: String = "ST-001",
    val pumpId: String = "PUMP-04",
    val transactionId: String = "",
    val eventType: String,
    val eventSource: String = "PUMP_TERMINAL",
    val result: String = "SUCCESS",
    val correlationId: String = UUID.randomUUID().toString().take(12),
    val details: String = ""
)

data class CustomerLoyaltyAccount(
    val accountId: String = "BPME-998241",
    val memberName: String = "Valued Customer",
    val pointsBalance: Int = 1254,
    val tier: String = "Platinum Member"
)

data class ReceiptInfo(
    val transactionId: String,
    val timestamp: Long,
    val stationName: String = "BP Forecourt - London Mayfair",
    val pumpNumber: Int = 4,
    val fuelName: String,
    val pricePerLitre: Double,
    val litresDispensed: Double,
    val totalAmount: Double,
    val paymentMaskedCard: String,
    val authCode: String,
    val pointsEarned: Int,
    val qrPayload: String
)
