package com.example.data.payment

import com.example.data.model.PaymentToken
import com.example.data.model.PreAuthRequest
import com.example.data.model.PreAuthResponse
import kotlinx.coroutines.delay
import java.util.UUID

interface PaymentProvider {
    val providerName: String
    val isDemoProvider: Boolean
    suspend fun authorizePreAuth(request: PreAuthRequest, token: PaymentToken): PreAuthResponse
    suspend fun captureTransaction(transactionId: String, finalAmount: Double): Boolean
    suspend fun cancelPreAuth(transactionId: String): Boolean
}

class MockPaymentProvider : PaymentProvider {
    override val providerName: String = "Enterprise Forecourt Mock Payment Provider (DEMO ONLY)"
    override val isDemoProvider: Boolean = true

    // Simulation toggle flags
    var forceDecline: Boolean = false
    var forceTimeout: Boolean = false

    override suspend fun authorizePreAuth(request: PreAuthRequest, token: PaymentToken): PreAuthResponse {
        delay(800) // Simulate banking host network roundtrip latency

        if (forceTimeout) {
            return PreAuthResponse(
                isApproved = false,
                authCode = null,
                token = null,
                authorizedAmount = 0.0,
                transactionId = "TXN-" + UUID.randomUUID().toString().take(8).uppercase(),
                errorMessage = "PAYMENT PROCESSOR TIMEOUT (SIMULATED)"
            )
        }

        if (forceDecline) {
            return PreAuthResponse(
                isApproved = false,
                authCode = null,
                token = null,
                authorizedAmount = 0.0,
                transactionId = "TXN-" + UUID.randomUUID().toString().take(8).uppercase(),
                errorMessage = "CARD DECLINED BY ISSUER (SIMULATED 51)"
            )
        }

        val txnId = "TXN-BP-" + System.currentTimeMillis().toString().takeLast(8)
        return PreAuthResponse(
            isApproved = true,
            authCode = token.authCode,
            token = token,
            authorizedAmount = request.maxAmount,
            transactionId = txnId,
            errorMessage = null
        )
    }

    override suspend fun captureTransaction(transactionId: String, finalAmount: Double): Boolean {
        delay(400)
        return true
    }

    override suspend fun cancelPreAuth(transactionId: String): Boolean {
        delay(200)
        return true
    }
}

class PaymentTerminal(
    private val nfcReader: NfcReader,
    private val paymentProvider: PaymentProvider
) {
    fun getNfcReader(): NfcReader = nfcReader
    fun getPaymentProvider(): PaymentProvider = paymentProvider
}
