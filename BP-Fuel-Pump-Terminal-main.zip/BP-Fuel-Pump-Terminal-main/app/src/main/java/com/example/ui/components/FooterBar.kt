package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Language
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BpBrightGreen
import com.example.ui.theme.BpDeepGreen

@Composable
fun FooterBarButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    testTagStr: String
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(24.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .testTag(testTagStr),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(28.dp)
                .background(Color.White.copy(alpha = 0.2f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = label.uppercase(),
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun FooterBar(
    helpLabel: String = "HELP",
    languageLabel: String = "LANGUAGE",
    accessibilityLabel: String = "ACCESSIBILITY",
    taglineLabel: String = "Every journey matters",
    onHelpClick: () -> Unit,
    onLanguageClick: () -> Unit,
    onAccessibilityClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp)
            .background(BpDeepGreen),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.padding(start = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FooterBarButton(
                icon = Icons.Default.HelpOutline,
                label = helpLabel,
                onClick = onHelpClick,
                testTagStr = "footer_help_button"
            )

            Spacer(modifier = Modifier.width(12.dp))

            FooterBarButton(
                icon = Icons.Default.Language,
                label = languageLabel,
                onClick = onLanguageClick,
                testTagStr = "footer_language_button"
            )

            Spacer(modifier = Modifier.width(12.dp))

            FooterBarButton(
                icon = Icons.Default.Accessibility,
                label = accessibilityLabel,
                onClick = onAccessibilityClick,
                testTagStr = "footer_accessibility_button"
            )
        }

        // Right side stylized banner ribbon
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .width(260.dp)
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            BpDeepGreen,
                            BpBrightGreen
                        )
                    )
                )
                .padding(horizontal = 20.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Text(
                text = taglineLabel,
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
