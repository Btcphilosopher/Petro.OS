package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BpBorderGray
import com.example.ui.theme.BpDeepGreen
import com.example.ui.theme.BpTextDark
import com.example.ui.theme.BpTextMuted

@Composable
fun ContactlessIcon(
    color: Color = BpTextDark,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.size(40.dp)) {
        val center = size.width / 2f
        val maxRadius = size.width * 0.45f
        
        // Draw 4 contactless concentric arcs
        for (i in 1..4) {
            val r = maxRadius * (i / 4f)
            drawArc(
                color = color,
                startAngle = -45f,
                sweepAngle = 90f,
                useCenter = false,
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )
        }
    }
}

@Composable
fun PaymentMethodCard(
    paymentMethodText: String = "PAYMENT METHOD",
    instructionText: String = "Tap or insert card",
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, BpBorderGray, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .testTag("payment_method_card"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = paymentMethodText,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = BpTextMuted,
                letterSpacing = 1.sp,
                modifier = Modifier.align(Alignment.Start)
            )

            Spacer(modifier = Modifier.height(12.dp))

            ContactlessIcon(color = BpDeepGreen)

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = instructionText,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = BpTextDark
            )
        }
    }
}
