package com.example.ui.modals

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ReceiptInfo
import com.example.ui.theme.BpBrightGreen
import com.example.ui.theme.BpDeepGreen
import com.example.ui.theme.BpTextDark
import com.example.ui.theme.BpTextMuted

@Composable
fun SimulatedQrCodeCanvas(
    payload: String,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.size(160.dp)) {
        val gridSize = 17
        val cellSize = size.width / gridSize

        drawRect(color = Color.White)

        val hash = payload.hashCode()

        for (r in 0 until gridSize) {
            for (c in 0 until gridSize) {
                val isCorner = (r < 5 && c < 5) || (r < 5 && c >= gridSize - 5) || (r >= gridSize - 5 && c < 5)

                val drawBlack = if (isCorner) {
                    (r == 0 || r == 4 || c == 0 || c == 4) || (r in 1..3 && c in 1..3)
                } else {
                    ((r * 31 + c * 17 + hash) % 3) == 0
                }

                if (drawBlack) {
                    drawRect(
                        color = Color.Black,
                        topLeft = Offset(c * cellSize, r * cellSize),
                        size = Size(cellSize, cellSize)
                    )
                }
            }
        }
    }
}

@Composable
fun ReceiptModal(
    receipt: ReceiptInfo?,
    onDone: () -> Unit,
    modifier: Modifier = Modifier
) {
    var deliveryOptionSelected by remember { mutableStateOf("QR") }
    var printStatusText by remember { mutableStateOf<String?>(null) }

    Surface(
        modifier = modifier.fillMaxSize(),
        color = Color.Black.copy(alpha = 0.75f)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Card(
                modifier = Modifier
                    .width(520.dp)
                    .padding(24.dp)
                    .testTag("receipt_modal"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = BpBrightGreen,
                        modifier = Modifier.size(56.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "TRANSACTION COMPLETE",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = BpDeepGreen
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    receipt?.let { r ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFFF4F6F4), RoundedCornerShape(12.dp))
                                .padding(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "Transaction ID:", fontSize = 12.sp, color = BpTextMuted)
                                Text(text = r.transactionId, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BpTextDark)
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "Fuel Grade:", fontSize = 12.sp, color = BpTextMuted)
                                Text(text = r.fuelName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BpDeepGreen)
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "Volume Dispensed:", fontSize = 14.sp, color = BpTextMuted)
                                Text(text = String.format("%.2f L", r.litresDispensed), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = BpTextDark)
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "Total Paid:", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = BpTextDark)
                                Text(text = String.format("£%.2f", r.totalAmount), fontSize = 22.sp, fontWeight = FontWeight.Black, color = BpDeepGreen)
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "BPme Points Earned:", fontSize = 12.sp, color = BpTextMuted)
                                Text(text = "+${r.pointsEarned} pts", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = BpBrightGreen)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "CHOOSE RECEIPT OPTION",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = BpTextMuted,
                            letterSpacing = 1.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    deliveryOptionSelected = "QR"
                                    printStatusText = null
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (deliveryOptionSelected == "QR") BpDeepGreen else Color(0xFFE0E4E0),
                                    contentColor = if (deliveryOptionSelected == "QR") Color.White else BpTextDark
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.QrCode2, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("DIGITAL QR", fontSize = 11.sp)
                            }

                            Button(
                                onClick = {
                                    deliveryOptionSelected = "PRINT"
                                    printStatusText = "Printing thermal receipt..."
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (deliveryOptionSelected == "PRINT") BpDeepGreen else Color(0xFFE0E4E0),
                                    contentColor = if (deliveryOptionSelected == "PRINT") Color.White else BpTextDark
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("PRINT", fontSize = 11.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        if (deliveryOptionSelected == "QR") {
                            SimulatedQrCodeCanvas(payload = r.qrPayload)
                            Text(
                                text = "Scan with smartphone camera for e-receipt",
                                fontSize = 11.sp,
                                color = BpTextMuted,
                                modifier = Modifier.padding(top = 6.dp)
                            )
                        } else if (printStatusText != null) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFFFFF8E1), RoundedCornerShape(8.dp))
                                    .padding(12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = printStatusText!!,
                                    color = Color(0xFFF57F17),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = onDone,
                        colors = ButtonDefaults.buttonColors(containerColor = BpDeepGreen),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("receipt_done_button")
                    ) {
                        Text("FINISH / THANK YOU", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
