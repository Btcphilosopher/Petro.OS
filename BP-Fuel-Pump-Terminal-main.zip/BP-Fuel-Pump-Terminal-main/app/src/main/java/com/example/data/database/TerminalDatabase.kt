package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        StationEntity::class,
        PumpEntity::class,
        FuelPriceEntity::class,
        TransactionEntity::class,
        AuditLogEntity::class,
        TelemetryEntity::class,
        DeviceHealthEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class TerminalDatabase : RoomDatabase() {
    abstract fun transactionDao(): TransactionDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun telemetryDao(): TelemetryDao
    abstract fun deviceHealthDao(): DeviceHealthDao
    abstract fun fuelPriceDao(): FuelPriceDao

    companion object {
        @Volatile
        private var INSTANCE: TerminalDatabase? = null

        fun getDatabase(context: Context): TerminalDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TerminalDatabase::class.java,
                    "fuel_terminal_db"
                ).fallbackToDestructiveMigration()
                 .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
