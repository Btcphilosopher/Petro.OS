package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BpBorderGray
import com.example.ui.theme.BpTextDark
import com.example.ui.theme.BpTextMuted

@Composable
fun ThisSaleCard(
    totalAmount: Double = 25.00,
    litresDispensed: Double = 15.20,
    modifier: Modifier = Modifier
) {
    val animatedAmount by animateFloatAsState(targetValue = totalAmount.toFloat(), label = "amountAnim")
    val animatedLitres by animateFloatAsState(targetValue = litresDispensed.toFloat(), label = "litresAnim")

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, BpBorderGray, RoundedCornerShape(12.dp))
            .testTag("this_sale_card"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "THIS SALE",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = BpTextMuted,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Amount Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFF7F9F7), RoundedCornerShape(8.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "£",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = BpTextDark
                    )
                    Text(
                        text = String.format("%.2f", animatedAmount),
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Black,
                        color = BpTextDark
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Litres Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFF7F9F7), RoundedCornerShape(8.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "LITRES",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = BpTextMuted,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = String.format("%.2f", animatedLitres),
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = BpTextDark
                    )
                }
            }
        }
    }
}
