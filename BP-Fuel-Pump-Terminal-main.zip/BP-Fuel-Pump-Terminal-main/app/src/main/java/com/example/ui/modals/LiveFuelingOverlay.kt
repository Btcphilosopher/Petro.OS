package com.example.ui.modals

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FuelGrade
import com.example.data.model.PumpState
import com.example.data.model.TelemetryData
import com.example.ui.theme.BpBrightGreen
import com.example.ui.theme.BpDeepGreen
import com.example.ui.theme.BpRedError

@Composable
fun FlowIndicatorLight(isFlowing: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "flowPulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "flowAlpha"
    )

    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(14.dp)
                .background(
                    if (isFlowing) BpBrightGreen.copy(alpha = alpha) else Color.Gray,
                    CircleShape
                )
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = if (isFlowing) "FUEL FLOW ACTIVE" else "FUEL FLOW PAUSED",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = if (isFlowing) BpBrightGreen else Color.Gray,
            letterSpacing = 1.sp
        )
    }
}

@Composable
fun LiveFuelingOverlay(
    telemetry: TelemetryData,
    selectedFuel: FuelGrade?,
    pumpState: PumpState,
    isTriggerSqueezed: Boolean,
    onToggleTrigger: () -> Unit,
    onFinishFueling: () -> Unit,
    onEmergencyStop: () -> Unit,
    modifier: Modifier = Modifier
) {
    val animLitres by animateFloatAsState(
        targetValue = telemetry.volumeDispensedLitres.toFloat(),
        label = "liveLitres"
    )
    val animTotal by animateFloatAsState(
        targetValue = telemetry.totalValueAmount.toFloat(),
        label = "liveTotal"
    )

    Surface(
        modifier = modifier.fillMaxSize(),
        color = Color(0xFF141814) // Dark industrial background for high contrast during fueling
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocalGasStation,
                        contentDescription = null,
                        tint = BpBrightGreen,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "PUMP 04",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Text(
                            text = selectedFuel?.name ?: "Regular Unleaded",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = BpBrightGreen
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "PRICE PER LITRE",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "£${String.format("%.3f", selectedFuel?.pricePerLitre ?: 1.559)} / L",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Flow Status Bar
            FlowIndicatorLight(isFlowing = isTriggerSqueezed && pumpState == PumpState.FUELING)

            Spacer(modifier = Modifier.height(24.dp))

            // Main Telemetry Displays
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Litres Display Card
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxSize()
                        .border(1.dp, Color(0xFF2C352C), RoundedCornerShape(16.dp)),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1D241D))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "LITRES DISPENSED",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Gray,
                            letterSpacing = 1.sp
                        )

                        Text(
                            text = String.format("%.2f", animLitres),
                            fontSize = 64.sp,
                            fontWeight = FontWeight.Black,
                            color = BpBrightGreen,
                            modifier = Modifier.align(Alignment.End)
                        )

                        Text(
                            text = "VOLUME (L)",
                            fontSize = 12.sp,
                            color = Color.Gray,
                            modifier = Modifier.align(Alignment.End)
                        )
                    }
                }

                // Total Value Display Card
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxSize()
                        .border(1.dp, Color(0xFF2C352C), RoundedCornerShape(16.dp)),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1D241D))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "TOTAL AMOUNT",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Gray,
                            letterSpacing = 1.sp
                        )

                        Text(
                            text = "£" + String.format("%.2f", animTotal),
                            fontSize = 64.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            modifier = Modifier.align(Alignment.End)
                        )

                        Text(
                            text = "FINAL CAPTURE VALUE",
                            fontSize = 12.sp,
                            color = Color.Gray,
                            modifier = Modifier.align(Alignment.End)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Interactive Controls Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Emergency Stop Button
                Button(
                    onClick = onEmergencyStop,
                    colors = ButtonDefaults.buttonColors(containerColor = BpRedError),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .height(54.dp)
                        .testTag("emergency_stop_button")
                ) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "EMERGENCY STOP",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 14.sp
                    )
                }

                Row {
                    // Squeeze Trigger Simulation Toggle
                    Button(
                        onClick = onToggleTrigger,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isTriggerSqueezed) Color(0xFF388E3C) else Color(0xFF616161)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .height(54.dp)
                            .testTag("squeeze_trigger_button")
                    ) {
                        Text(
                            text = if (isTriggerSqueezed) "RELEASE LEVER (PAUSE)" else "SQUEEZE LEVER (FLOW)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Return Nozzle Button
                    Button(
                        onClick = onFinishFueling,
                        colors = ButtonDefaults.buttonColors(containerColor = BpDeepGreen),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .height(54.dp)
                            .testTag("return_nozzle_button")
                    ) {
                        Icon(Icons.Default.StopCircle, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "REPLACE NOZZLE (FINISH)",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}
