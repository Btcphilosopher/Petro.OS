use ice_optimisation::sweep::ParameterSweepEngine;

fn main() {
    println!("=== ICE-RS Example: Compression Ratio Parameter Sweep ===");
    let cr_grid = ParameterSweepEngine::generate_grid(9.0, 13.0, 8);
    for cr in cr_grid {
        println!("Evaluating Compression Ratio: {:.2}:1", cr);
    }
}
