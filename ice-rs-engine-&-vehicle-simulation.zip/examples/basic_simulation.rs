use ice_core::simulation::simulator::Simulator;

fn main() {
    println!("=== ICE-RS Example: Basic 30-Second Acceleration ===");
    let mut sim = Simulator::new(0.001);

    for step in 0..30_000 {
        let throttle = if step < 1000 { 0.1 } else { 1.0 }; // Idle then WOT
        let state = sim.step(throttle);

        if step % 5000 == 0 {
            println!(
                "Time: {:5.2}s | RPM: {:6.1} | Torque: {:5.1} Nm | Power: {:5.1} HP | Speed: {:5.1} km/h",
                state.time_s, state.rpm, state.indicated_torque_nm, state.power_hp, sim.vehicle.speed_kmh()
            );
        }
    }
}
