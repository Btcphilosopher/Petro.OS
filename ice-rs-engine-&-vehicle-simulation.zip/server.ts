import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Endpoints
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", service: "ICE-RS Simulation Engine API", timestamp: new Date().toISOString() });
  });

  // Get available engine configurations
  app.get("/api/configs/engines", (req, res) => {
    const configDir = path.join(process.cwd(), "configs", "engines");
    if (fs.existsSync(configDir)) {
      const files = fs.readdirSync(configDir).filter(f => f.endsWith(".toml"));
      const configs = files.map(file => {
        const content = fs.readFileSync(path.join(configDir, file), "utf-8");
        return { filename: file, content };
      });
      return res.json({ configs });
    }
    res.json({ configs: [] });
  });

  // Validate TOML configuration endpoint
  app.post("/api/validate-config", (req, res) => {
    const { tomlContent } = req.body;
    if (!tomlContent) {
      return res.status(400).json({ valid: false, error: "Missing configuration content" });
    }

    // Basic TOML validation rules
    try {
      const hasEngine = tomlContent.includes("[engine]");
      const hasBore = tomlContent.includes("bore_m");
      const hasStroke = tomlContent.includes("stroke_m");
      const hasCylinders = tomlContent.includes("cylinders");

      if (!hasEngine || !hasBore || !hasStroke || !hasCylinders) {
        return res.status(400).json({
          valid: false,
          error: "Invalid configuration: Missing required fields (bore_m, stroke_m, cylinders under [engine])"
        });
      }

      res.json({ valid: true, message: "Engine configuration validated successfully" });
    } catch (err: any) {
      res.status(400).json({ valid: false, error: err.message });
    }
  });

  // Simulate endpoint for server-side batch runs or telemetry export
  app.post("/api/export-telemetry", (req, res) => {
    const { format, data } = req.body;
    if (format === "csv") {
      const headers = Object.keys(data[0] || {}).join(",");
      const rows = data.map((row: any) => Object.values(row).join(",")).join("\n");
      const csv = `${headers}\n${rows}`;
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", 'attachment; filename="ice_telemetry.csv"');
      return res.send(csv);
    }
    res.json({ status: "success", count: data?.length || 0 });
  });

  // Serve Vite in development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[ICE-RS] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
