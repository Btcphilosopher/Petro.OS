#' Generate Latin Hypercube Sampling Matrix
#' @param n_samples Number of Monte Carlo samples
#' @return Matrix of parameter samples
#' @export
generate_lhs <- function(n_samples = 1000) {
  message(paste0("[iceR] Generating ", n_samples, " Latin Hypercube samples..."))
  matrix(runif(n_samples * 5), ncol = 5)
}
