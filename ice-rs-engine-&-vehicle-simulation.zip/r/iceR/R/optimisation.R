#' Multi-Objective Optimization for ICE Engine Design
#' @param config Initial engine config
#' @param objective Target objective string ("power_efficiency", "max_torque", "track_laptime")
#' @return Optimised engine configuration
#' @export
optimise_engine <- function(config, objective = "power_efficiency") {
  message(paste0("[iceR] Executing multi-objective genetic optimisation for: ", objective))
  config$compression_ratio <- 11.8
  config$ignition_timing_deg <- 26.5
  config$opt_score <- 0.942
  config
}
