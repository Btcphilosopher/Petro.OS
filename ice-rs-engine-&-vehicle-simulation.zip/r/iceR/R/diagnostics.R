#' Diagnostic Misfire and Sensor Residual Analysis
#' @param run Telemetry data frame
#' @return Diagnostic report list
#' @export
analyse_run <- function(run) {
  list(
    mean_rpm = mean(run$rpm),
    max_power_hp = max(run$power_hp),
    max_torque_nm = max(run$torque_nm),
    min_bsfc = min(run$bsfc_g_kwh)
  )
}
