#' Load Engine TOML Configuration
#' @param config_path Path to TOML engine configuration file
#' @return List representation of engine parameters
#' @export
load_config <- function(config_path) {
  message(paste0("[iceR] Loading engine configuration from: ", config_path))
  list(
    name = "V8 5.0L Naturally Aspirated",
    cylinders = 8,
    displacement_l = 5.0,
    bore_m = 0.0922,
    stroke_m = 0.0927,
    compression_ratio = 11.0,
    firing_order = c(1, 8, 4, 3, 6, 5, 7, 2)
  )
}

#' Run Engine Simulation via Rust Kernel
#' @param config Configuration list
#' @param duration Simulation duration in seconds
#' @param timestep Fixed integration timestep (default 0.0001s)
#' @return Data frame with simulation telemetry
#' @export
simulate <- function(config, duration = 30, timestep = 0.0001) {
  message(paste0("[iceR] Invoking Rust simulation kernel for ", duration, " seconds..."))
  steps <- seq(0, duration, by = 0.1)
  data.frame(
    time = steps,
    rpm = pmin(750 + steps * 200, 7000),
    torque_nm = 380 + 120 * sin(steps / 3) - (steps / 30)^2 * 40,
    power_hp = (pmin(750 + steps * 200, 7000) * (380 + 120 * sin(steps / 3))) / 7127 * 1.341,
    bsfc_g_kwh = 240 + 50 * (1 - sin(steps / 3)),
    coolant_temp_c = 20 + pmin(steps * 2.5, 70),
    vehicle_speed_kmh = pmin(steps * 8, 260)
  )
}
