# ICE-RS — High-Performance Internal Combustion Engine Simulation, Vehicle Dynamics & R&D Platform

ICE-RS is a production-quality automotive research, engineering, calibration, and optimization simulation environment written in Rust with an integrated R analytics package (`iceR`).

## Architecture & Computational Chain

```
ENGINE GEOMETRY ➔ AIRFLOW ➔ FUELING ➔ COMBUSTION ➔ CYLINDER PRESSURE ➔ CRANKSHAFT TORQUE ➔ DRIVETRAIN ➔ TYRE FORCES ➔ VEHICLE MOTION ➔ THERMAL STATE ➔ SENSORS/TELEMETRY ➔ CALIBRATION/OPTIMISATION
```

- **Level 0**: Fast surrogate engine model for Monte Carlo, parameter sweeps, and rapid optimization.
- **Level 1**: Real-time physical model including slider-crank kinematics, air/fuel, thermal loops, drivetrain, and longitudinal dynamics.
- **Level 2**: Crank-angle-resolved thermodynamic model with Wiebe heat release, P-V diagrams, volumetric efficiency maps, and detailed valve timing.

## Workspace Structure

- `crates/ice-core`: Core physics engine, slider-crank geometry, Wiebe combustion, ECU, thermal, drivetrain, vehicle dynamics.
- `crates/ice-acoustics`: Real-time procedural audio synthesis, order tracking, cylinder pressure wave impulse DSP, and exhaust resonance.
- `crates/ice-optimisation`: Multi-objective genetic sweep generator, Latin hypercube sampling, sensitivity analysis.
- `crates/ice-io`: High-throughput Parquet/Arrow telemetry recording, TOML config parser, JSON/CSV exports.
- `crates/ice-cli`: Command-line interface (`ice-sim run`, `ice-sim validate`, `ice-sim sweep`, `ice-sim benchmark`).
- `r/iceR`: R package for statistical modeling, sensitivity tornado analysis, calibration fitting, and ggplot2 visualizations.

## Getting Started

```bash
# Validate TOML configuration
cargo run -p ice-cli -- validate configs/engines/v8_50l_na.toml

# Run 30-second WOT simulation with Parquet telemetry export
cargo run -p ice-cli -- run configs/engines/v8_50l_na.toml --duration 30 --output run.parquet

# Run benchmark suite
cargo bench
```

In R:
```r
library(iceR)
config <- load_config("configs/engines/v8_50l_na.toml")
run <- simulate(config, duration = 30)
plot_engine(run)
```
