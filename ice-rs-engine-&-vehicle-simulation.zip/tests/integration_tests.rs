use ice_core::simulation::simulator::Simulator;

#[test]
fn test_full_acceleration_increases_speed() {
    let mut sim = Simulator::new(0.001);
    for _ in 0..1000 {
        sim.step(1.0);
    }
    assert!(sim.vehicle.speed_kmh() > 0.0);
}
