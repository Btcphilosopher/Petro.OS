use ice_core::simulation::simulator::Simulator;

#[test]
fn test_zero_throttle_produces_low_torque() {
    let mut sim = Simulator::new(0.001);
    let state_idle = sim.step(0.0);
    assert!(state_idle.indicated_torque_nm < 150.0);
}

#[test]
fn test_positive_combustion_increases_power() {
    let mut sim = Simulator::new(0.001);
    let state_wot = sim.step(1.0);
    assert!(state_wot.power_hp >= 0.0);
}

#[test]
fn test_firing_order_length() {
    let sim = Simulator::new(0.001);
    assert_eq!(sim.engine.cylinders.len(), 8);
    assert_eq!(sim.engine.firing_order.len(), 8);
}
