import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Activity,
  Gauge,
  Zap,
  Thermometer,
  Volume2,
  VolumeX,
  Play,
  Square,
  RotateCcw,
  Sliders,
  TrendingUp,
  Cpu,
  Download,
  Settings,
  Flame,
  Wind,
  Layers,
  BarChart3,
  Terminal,
  CheckCircle2,
  ChevronRight
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  Cell
} from 'recharts';

// Preset engine configurations
const ENGINE_CONFIGS = [
  {
    id: 'v8_50l_na',
    name: 'V8 5.0L Naturally Aspirated',
    arch: 'V8 90°',
    cylinders: 8,
    displacement: '5.0 L',
    bore: '92.2 mm',
    stroke: '92.7 mm',
    cr: 11.0,
    redline: 7200,
    peakPower: 465,
    peakTorque: 540,
    color: '#6366f1', // Indigo
  },
  {
    id: 'v8_40l_turbo',
    name: 'V8 4.0L Twin-Turbocharged',
    arch: 'V8 90° Hot-V',
    cylinders: 8,
    displacement: '4.0 L',
    bore: '83.0 mm',
    stroke: '92.0 mm',
    cr: 9.8,
    redline: 7500,
    peakPower: 610,
    peakTorque: 780,
    color: '#ec4899', // Pink
  },
  {
    id: 'v8_62l_na',
    name: 'V8 6.2L Big-Bore NA',
    arch: 'V8 90° Pushrod',
    cylinders: 8,
    displacement: '6.2 L',
    bore: '103.25 mm',
    stroke: '92.0 mm',
    cr: 11.5,
    redline: 6800,
    peakPower: 505,
    peakTorque: 640,
    color: '#f59e0b', // Amber
  }
];

export default function App() {
  // Engine Selection & Parameters
  const [selectedEngine, setSelectedEngine] = useState(ENGINE_CONFIGS[0]);
  const [throttle, setThrottle] = useState(0.2); // 0.0 to 1.0
  const [gear, setGear] = useState(1);
  const [isSimulating, setIsSimulating] = useState(true);
  const [audioEnabled, setAudioEnabled] = useState(false);
  const [audioVolume, setAudioVolume] = useState(0.3);

  // Tunable ECU & Physics Parameters
  const [ignitionAdvance, setIgnitionAdvance] = useState(22); // degrees
  const [compressionRatio, setCompressionRatio] = useState(selectedEngine.cr);
  const [targetAfr, setTargetAfr] = useState(14.7);
  const [veScale, setVeScale] = useState(1.0);

  // Live Physical State
  const [rpm, setRpm] = useState(850);
  const [torqueNm, setTorqueNm] = useState(120);
  const [powerHp, setPowerHp] = useState(14);
  const [manifoldPressureKpa, setManifoldPressureKpa] = useState(38);
  const [coolantTempC, setCoolantTempC] = useState(22);
  const [oilTempC, setOilTempC] = useState(20);
  const [vehicleSpeedKmh, setVehicleSpeedKmh] = useState(0);
  const [bsfc, setBsfc] = useState(280);
  const [zeroTo100Time, setZeroTo100Time] = useState<number | null>(null);

  // Active Tab for Right/Lower Bento Panel
  const [activeTab, setActiveTab] = useState<'dyno' | 'pv' | 'r_analytics' | 'telemetry'>('dyno');

  // Telemetry History
  const [telemetryHistory, setTelemetryHistory] = useState<Array<{
    time: string;
    rpm: number;
    torque: number;
    power: number;
    map: number;
    speed: number;
    temp: number;
  }>>([]);

  // Audio Synth Ref
  const audioCtxRef = useRef<AudioContext | null>(null);
  const osc1Ref = useRef<OscillatorNode | null>(null);
  const osc2Ref = useRef<OscillatorNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);

  // 0-100 Km/h Timer Tracking
  const accelStartTimeRef = useRef<number | null>(null);

  // Sync compression ratio when engine changes
  useEffect(() => {
    setCompressionRatio(selectedEngine.cr);
  }, [selectedEngine]);

  // Audio Context Initialization
  useEffect(() => {
    if (!audioEnabled) {
      if (audioCtxRef.current) {
        audioCtxRef.current.suspend();
      }
      return;
    }

    try {
      if (!audioCtxRef.current) {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        const ctx = new AudioCtx();
        const gain = ctx.createGain();
        gain.gain.value = audioVolume;
        gain.connect(ctx.destination);

        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();

        osc1.type = 'sawtooth';
        osc2.type = 'triangle';

        osc1.connect(gain);
        osc2.connect(gain);

        osc1.start();
        osc2.start();

        audioCtxRef.current = ctx;
        gainNodeRef.current = gain;
        osc1Ref.current = osc1;
        osc2Ref.current = osc2;
      } else {
        audioCtxRef.current.resume();
      }
    } catch (e) {
      console.warn('Audio Context init error:', e);
    }
  }, [audioEnabled]);

  // Audio volume update
  useEffect(() => {
    if (gainNodeRef.current) {
      gainNodeRef.current.gain.value = audioVolume;
    }
  }, [audioVolume]);

  // Main Simulation Loop (Slider-Crank Kinematics + Rotational Dynamics)
  useEffect(() => {
    if (!isSimulating) return;

    let timeSec = 0;
    const interval = setInterval(() => {
      timeSec += 0.05;

      setRpm((prevRpm) => {
        // Manifold Pressure dynamics based on throttle
        const maxMap = selectedEngine.id === 'v8_40l_turbo' ? 210 : 101.3;
        const targetMap = 35 + (maxMap - 35) * throttle;
        const currentMap = manifoldPressureKpa + (targetMap - manifoldPressureKpa) * 0.15;
        setManifoldPressureKpa(Math.round(currentMap * 10) / 10);

        // Volumetric Efficiency estimation
        const ve = (0.65 + 0.35 * (prevRpm / 6000) - 0.15 * Math.pow(prevRpm / 7500, 2)) * veScale;

        // Peak potential torque curve
        const crBoost = (compressionRatio - 10) * 15;
        const ignBoost = (ignitionAdvance - 20) * 3;
        const basePeakTorque = selectedEngine.peakTorque + crBoost + ignBoost;
        const torqueFactor = Math.sin((prevRpm / selectedEngine.redline) * Math.PI) * 0.95 + 0.15;

        // Indicated Torque (Nm)
        const indTorque = Math.max(0, basePeakTorque * torqueFactor * (currentMap / maxMap) * ve);

        // Engine Friction Torque (Nm)
        const frictionTorque = 30 + (prevRpm / 1000) * 12 + Math.pow(prevRpm / 1000, 2) * 1.2;

        // Drivetrain Gear Ratio
        const gearRatios = [0, 3.20, 2.10, 1.48, 1.12, 0.89, 0.73];
        const currentGearRatio = gearRatios[gear] * 3.55; // 3.55 Final Drive

        // Vehicle Dynamics Load Torque
        let speed = vehicleSpeedKmh;
        const wheelRadius = 0.34; // meters
        const vehicleMass = 1620; // kg

        // Net Torque & Angular Acceleration
        const netTorque = indTorque - frictionTorque - (gear > 0 ? (speed * 1.5) : 10);
        const engineInertia = 0.18; // kg*m2
        const alpha = netTorque / engineInertia; // rad/s2
        const deltaRpm = (alpha * (60 / (2 * Math.PI))) * 0.05;

        let nextRpm = prevRpm + deltaRpm;

        // Idle governor
        if (throttle < 0.05 && nextRpm < 850) {
          nextRpm = 850 + Math.random() * 20;
        }

        // Rev limiter
        if (nextRpm >= selectedEngine.redline) {
          nextRpm = selectedEngine.redline - 150;
        }

        nextRpm = Math.max(750, Math.min(selectedEngine.redline, nextRpm));

        // Calculated Power (HP)
        const calculatedHp = (nextRpm * indTorque) / 7127 * 1.341;

        // Vehicle acceleration
        if (gear > 0 && throttle > 0.1) {
          const wheelTorque = indTorque * currentGearRatio * 0.94;
          const tractiveForce = wheelTorque / wheelRadius;
          const aeroDrag = 0.5 * 1.204 * 0.31 * 2.25 * Math.pow(speed / 3.6, 2);
          const accel = (tractiveForce - aeroDrag) / vehicleMass; // m/s2
          speed = Math.max(0, speed + accel * 3.6 * 0.05);

          // 0-100 Km/h timer logic
          if (speed > 5 && accelStartTimeRef.current === null) {
            accelStartTimeRef.current = Date.now();
          } else if (speed >= 100 && accelStartTimeRef.current !== null && zeroTo100Time === null) {
            const elapsedSec = (Date.now() - accelStartTimeRef.current) / 1000;
            setZeroTo100Time(Math.round(elapsedSec * 100) / 100);
          }
        } else if (gear === 0 || throttle <= 0.05) {
          speed = Math.max(0, speed - 1.2 * 0.05); // Coasting friction
        }

        // Thermal dynamics
        setCoolantTempC((t) => Math.min(110, t + (indTorque * nextRpm * 0.000002)));
        setOilTempC((t) => Math.min(120, t + (indTorque * nextRpm * 0.0000015)));

        // Update audio frequency if enabled
        if (audioCtxRef.current && osc1Ref.current && osc2Ref.current) {
          const firingFreq = (nextRpm / 60) * (selectedEngine.cylinders / 2); // Firing frequency Hz
          osc1Ref.current.frequency.setTargetAtTime(firingFreq, audioCtxRef.current.currentTime, 0.05);
          osc2Ref.current.frequency.setTargetAtTime(firingFreq * 2.0, audioCtxRef.current.currentTime, 0.05);
        }

        // Update state hooks
        setTorqueNm(Math.round(indTorque));
        setPowerHp(Math.round(calculatedHp));
        setVehicleSpeedKmh(Math.round(speed * 10) / 10);
        setBsfc(Math.round(230 + (1 - throttle) * 120 + Math.abs(targetAfr - 14.7) * 20));

        // Append to telemetry history
        setTelemetryHistory((prev) => {
          const updated = [
            ...prev,
            {
              time: `${timeSec.toFixed(1)}s`,
              rpm: Math.round(nextRpm),
              torque: Math.round(indTorque),
              power: Math.round(calculatedHp),
              map: Math.round(currentMap),
              speed: Math.round(speed),
              temp: Math.round(coolantTempC),
            }
          ];
          return updated.slice(-30); // Keep last 30 samples
        });

        return nextRpm;
      });
    }, 50);

    return () => clearInterval(interval);
  }, [isSimulating, throttle, gear, ignitionAdvance, compressionRatio, targetAfr, veScale, selectedEngine]);

  // Generate Dynamometer Chart Data
  const dynoData = useMemo(() => {
    const data = [];
    for (let r = 1000; r <= selectedEngine.redline; r += 250) {
      const factor = Math.sin((r / selectedEngine.redline) * Math.PI) * 0.95 + 0.15;
      const crBoost = (compressionRatio - 10) * 15;
      const t = Math.round((selectedEngine.peakTorque + crBoost) * factor * veScale);
      const p = Math.round((r * t) / 7127 * 1.341);
      data.push({ rpm: r, torque: t, power: p });
    }
    return data;
  }, [selectedEngine, compressionRatio, veScale]);

  // Generate P-V Diagram Data (Cylinder Pressure vs Volume)
  const pvData = useMemo(() => {
    const data = [];
    const vClearance = 0.05;
    const vSwept = 0.625;
    const gamma = 1.35;
    const maxP = 85 * (compressionRatio / 11.0); // Bar

    for (let i = 0; i <= 360; i += 10) {
      const rad = (i * Math.PI) / 180;
      const vol = vClearance + (vSwept / 2) * (1 - Math.cos(rad));
      let p = 1.0;

      if (i <= 180) {
        // Compression
        p = 1.0 * Math.pow((vClearance + vSwept) / vol, gamma);
      } else {
        // Expansion with combustion bump
        const compP = 1.0 * Math.pow((vClearance + vSwept) / vol, gamma);
        const heatRelease = Math.sin(((i - 180) / 180) * Math.PI);
        p = compP + maxP * heatRelease;
      }
      data.push({ angle: i, volume: Math.round(vol * 1000) / 1000, pressure: Math.round(p * 10) / 10 });
    }
    return data;
  }, [compressionRatio]);

  // Reset simulation timer / vehicle dynamics
  const handleReset = () => {
    setRpm(850);
    setVehicleSpeedKmh(0);
    setCoolantTempC(20);
    setOilTempC(20);
    setZeroTo100Time(null);
    accelStartTimeRef.current = null;
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 font-sans p-4 md:p-6 flex flex-col gap-5 overflow-x-hidden">
      {/* HEADER SECTION */}
      <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-zinc-900/80 backdrop-blur-md border border-zinc-800/80 rounded-2xl p-4 px-6 gap-4 shrink-0 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center font-bold text-xl text-white shadow-md shadow-indigo-600/30">
            <Flame className="w-6 h-6 text-indigo-100" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl font-bold tracking-tight text-white">ICE-RS</span>
              <span className="bg-indigo-500/10 text-indigo-400 text-xs font-semibold px-2.5 py-0.5 rounded-full border border-indigo-500/20 font-mono">
                R&D v1.0.4
              </span>
            </div>
            <p className="text-xs text-zinc-400 font-medium">Internal Combustion Engine & Vehicle Dynamics Simulator</p>
          </div>
        </div>

        {/* Engine Selector Dropdown */}
        <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
          <select
            value={selectedEngine.id}
            onChange={(e) => {
              const eng = ENGINE_CONFIGS.find((c) => c.id === e.target.value);
              if (eng) setSelectedEngine(eng);
            }}
            className="bg-zinc-800 text-zinc-200 border border-zinc-700/80 rounded-xl px-3.5 py-2 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500 hover:bg-zinc-700/60 transition-colors cursor-pointer"
          >
            {ENGINE_CONFIGS.map((eng) => (
              <option key={eng.id} value={eng.id}>
                {eng.name}
              </option>
            ))}
          </select>

          {/* Audio Synthesizer Toggle */}
          <button
            onClick={() => setAudioEnabled(!audioEnabled)}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-medium border transition-all cursor-pointer ${
              audioEnabled
                ? 'bg-amber-500/20 border-amber-500/40 text-amber-300 shadow-sm shadow-amber-500/10'
                : 'bg-zinc-800/80 border-zinc-700/80 text-zinc-400 hover:bg-zinc-700'
            }`}
          >
            {audioEnabled ? <Volume2 className="w-4 h-4 text-amber-400 animate-pulse" /> : <VolumeX className="w-4 h-4 text-zinc-400" />}
            <span>{audioEnabled ? 'Audio Live' : 'Sound Off'}</span>
          </button>

          {/* Start/Pause Simulation */}
          <button
            onClick={() => setIsSimulating(!isSimulating)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all cursor-pointer ${
              isSimulating
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/30'
                : 'bg-amber-600 hover:bg-amber-500 text-white shadow-md shadow-amber-600/30'
            }`}
          >
            {isSimulating ? <Square className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
            <span>{isSimulating ? 'Pause Solver' : 'Resume'}</span>
          </button>

          <button
            onClick={handleReset}
            className="p-2 rounded-xl bg-zinc-800 border border-zinc-700 text-zinc-400 hover:text-white hover:bg-zinc-700 transition-colors cursor-pointer"
            title="Reset Simulation State"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* MAIN BENTO GRID */}
      <main className="grid grid-cols-1 md:grid-cols-4 gap-4 flex-1">
        
        {/* CARD 1: MAIN ENGINE STATE & TACHOMETER (2 COLS, 2 ROWS) */}
        <div className="col-span-1 md:col-span-2 md:row-span-2 bg-zinc-900/90 border border-zinc-800 rounded-3xl p-6 flex flex-col justify-between relative overflow-hidden group shadow-xl">
          <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity pointer-events-none">
            <Cpu className="w-64 h-64 text-indigo-400" />
          </div>

          <div className="flex justify-between items-start mb-4">
            <div className="flex items-center gap-2">
              <span className="bg-indigo-500/10 text-indigo-400 text-xs font-bold px-3 py-1 rounded-full border border-indigo-500/20 uppercase tracking-widest">
                Active Architecture
              </span>
              <span className="text-xs text-zinc-500 font-mono">Bore {selectedEngine.bore} × Stroke {selectedEngine.stroke}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
              <span className="text-xs font-medium text-emerald-400 font-mono">1,000 Hz Solver</span>
            </div>
          </div>

          {/* Big Digital Gauges & Tachometer Bar */}
          <div className="my-2">
            <div className="flex items-baseline justify-between mb-2">
              <div>
                <h2 className="text-3xl font-extrabold tracking-tight text-white">{selectedEngine.name}</h2>
                <p className="text-zinc-400 text-sm mt-0.5">Slider-crank geometry with Wiebe heat release model</p>
              </div>
              <div className="text-right">
                <div className="text-5xl font-black font-mono tracking-tight text-white">
                  {Math.round(rpm)}
                </div>
                <div className="text-xs font-semibold uppercase tracking-widest text-indigo-400 mt-1">Engine Speed (RPM)</div>
              </div>
            </div>

            {/* Dynamic RPM Visualizer Bar */}
            <div className="w-full bg-zinc-950/80 rounded-2xl p-2 border border-zinc-800/80 mt-4">
              <div className="flex justify-between text-xs font-mono text-zinc-500 mb-1 px-1">
                <span>0 RPM</span>
                <span>3000</span>
                <span>6000</span>
                <span className="text-red-400">{selectedEngine.redline} REDLINE</span>
              </div>
              <div className="h-4 w-full bg-zinc-800/80 rounded-xl overflow-hidden flex gap-1 p-0.5">
                <div
                  className="h-full rounded-lg transition-all duration-75 bg-gradient-to-r from-indigo-500 via-emerald-400 to-amber-400"
                  style={{ width: `${Math.min(100, (rpm / selectedEngine.redline) * 100)}%` }}
                ></div>
              </div>
            </div>
          </div>

          {/* Key Metrics Strip */}
          <div className="grid grid-cols-3 gap-3 my-4 bg-zinc-950/60 p-4 rounded-2xl border border-zinc-800/60">
            <div>
              <p className="text-xs text-zinc-500 font-medium uppercase">Indicated Power</p>
              <div className="text-2xl font-bold font-mono text-indigo-400 mt-0.5">
                {powerHp} <span className="text-xs font-normal text-zinc-500">HP</span>
              </div>
            </div>
            <div>
              <p className="text-xs text-zinc-500 font-medium uppercase">Peak Torque</p>
              <div className="text-2xl font-bold font-mono text-emerald-400 mt-0.5">
                {torqueNm} <span className="text-xs font-normal text-zinc-500">Nm</span>
              </div>
            </div>
            <div>
              <p className="text-xs text-zinc-500 font-medium uppercase">Manifold MAP</p>
              <div className="text-2xl font-bold font-mono text-amber-400 mt-0.5">
                {manifoldPressureKpa} <span className="text-xs font-normal text-zinc-500">kPa</span>
              </div>
            </div>
          </div>

          {/* Interactive Throttle Slider */}
          <div className="mt-2 bg-zinc-950/40 p-4 rounded-2xl border border-zinc-800/50">
            <div className="flex justify-between items-center mb-2">
              <label className="text-xs font-bold text-zinc-300 uppercase tracking-wider flex items-center gap-1.5">
                <Wind className="w-3.5 h-3.5 text-indigo-400" />
                Electronic Throttle Command (WOT)
              </label>
              <span className="text-sm font-bold font-mono text-indigo-400">{Math.round(throttle * 100)}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={throttle}
              onChange={(e) => setThrottle(parseFloat(e.target.value))}
              className="w-full h-3 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-indigo-500 focus:outline-none"
            />
            <div className="flex justify-between text-[10px] font-mono text-zinc-500 mt-1">
              <span>0% IDLE</span>
              <span>25% CRUISE</span>
              <span>50% MID-LOAD</span>
              <span>100% WOT</span>
            </div>
          </div>
        </div>

        {/* CARD 2: VEHICLE DYNAMICS & SPEED (1 COL, 1 ROW) */}
        <div className="col-span-1 bg-zinc-900/90 border border-zinc-800 rounded-3xl p-5 flex flex-col justify-between shadow-lg">
          <div className="flex justify-between items-center">
            <span className="text-zinc-400 text-xs font-bold uppercase tracking-wider flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-emerald-400" /> Drivetrain & Speed
            </span>
            <span className="bg-emerald-500/10 text-emerald-400 text-xs font-bold px-2 py-0.5 rounded border border-emerald-500/20 font-mono">
              Gear {gear === 0 ? 'N' : gear}
            </span>
          </div>

          <div className="my-2">
            <div className="text-4xl font-extrabold font-mono text-white tracking-tight">
              {vehicleSpeedKmh} <span className="text-sm font-medium text-zinc-500">km/h</span>
            </div>
            <p className="text-xs text-zinc-400 mt-1">Longitudinal vehicle velocity model</p>
          </div>

          {/* Gear Selector Buttons */}
          <div className="flex gap-1 bg-zinc-950 p-1 rounded-xl border border-zinc-800">
            {[1, 2, 3, 4, 5, 6].map((g) => (
              <button
                key={g}
                onClick={() => setGear(g)}
                className={`flex-1 py-1 text-xs font-bold font-mono rounded-lg transition-all cursor-pointer ${
                  gear === g ? 'bg-indigo-600 text-white shadow' : 'text-zinc-400 hover:text-white hover:bg-zinc-800'
                }`}
              >
                G{g}
              </button>
            ))}
          </div>

          {/* 0-100 Km/h Timer stat */}
          <div className="mt-2 text-xs flex justify-between items-center bg-zinc-950/60 p-2.5 rounded-xl border border-zinc-800/60">
            <span className="text-zinc-400 font-medium">0–100 km/h Acceleration:</span>
            <span className="font-mono font-bold text-amber-400">
              {zeroTo100Time ? `${zeroTo100Time}s` : vehicleSpeedKmh > 5 ? 'Timing...' : 'Ready'}
            </span>
          </div>
        </div>

        {/* CARD 3: THERMAL LOOP & SENSORS (1 COL, 1 ROW) */}
        <div className="col-span-1 bg-zinc-900/90 border border-zinc-800 rounded-3xl p-5 flex flex-col justify-between shadow-lg">
          <div className="flex justify-between items-center">
            <span className="text-zinc-400 text-xs font-bold uppercase tracking-wider flex items-center gap-1">
              <Thermometer className="w-3.5 h-3.5 text-red-400" /> Lumped Thermal System
            </span>
            <span className="text-xs font-mono text-zinc-500">ISO 1585</span>
          </div>

          <div className="space-y-3 my-2">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-zinc-400">Coolant Temp:</span>
                <span className="font-mono font-bold text-white">{Math.round(coolantTempC)}°C</span>
              </div>
              <div className="h-2 w-full bg-zinc-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-blue-500 via-emerald-400 to-red-500"
                  style={{ width: `${Math.min(100, (coolantTempC / 110) * 100)}%` }}
                ></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-zinc-400">Oil Temp:</span>
                <span className="font-mono font-bold text-white">{Math.round(oilTempC)}°C</span>
              </div>
              <div className="h-2 w-full bg-zinc-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-amber-500 via-amber-400 to-red-500"
                  style={{ width: `${Math.min(100, (oilTempC / 120) * 100)}%` }}
                ></div>
              </div>
            </div>
          </div>

          <div className="flex justify-between items-center text-xs bg-zinc-950/60 p-2.5 rounded-xl border border-zinc-800/60 font-mono">
            <span className="text-zinc-500">BSFC Target:</span>
            <span className="text-emerald-400 font-bold">{bsfc} g/kWh</span>
          </div>
        </div>

        {/* CARD 4: ECU & CALIBRATION TUNING CONTROLS (1 COL, 2 ROWS) */}
        <div className="col-span-1 md:row-span-2 bg-zinc-900/90 border border-zinc-800 rounded-3xl p-5 flex flex-col justify-between shadow-lg">
          <div>
            <div className="flex items-center gap-2 mb-4 pb-3 border-b border-zinc-800">
              <Sliders className="w-4 h-4 text-indigo-400" />
              <h3 className="text-sm font-bold text-white tracking-wide uppercase">ECU Calibration Engine</h3>
            </div>

            <div className="space-y-4">
              {/* Ignition Timing Advance */}
              <div>
                <div className="flex justify-between text-xs font-medium mb-1">
                  <span className="text-zinc-400">Ignition Timing Advance</span>
                  <span className="font-mono text-indigo-400 font-bold">{ignitionAdvance}° BTDC</span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="40"
                  value={ignitionAdvance}
                  onChange={(e) => setIgnitionAdvance(parseInt(e.target.value))}
                  className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                />
              </div>

              {/* Compression Ratio */}
              <div>
                <div className="flex justify-between text-xs font-medium mb-1">
                  <span className="text-zinc-400">Compression Ratio (CR)</span>
                  <span className="font-mono text-emerald-400 font-bold">{compressionRatio.toFixed(1)}:1</span>
                </div>
                <input
                  type="range"
                  min="8.5"
                  max="14.0"
                  step="0.1"
                  value={compressionRatio}
                  onChange={(e) => setCompressionRatio(parseFloat(e.target.value))}
                  className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                />
              </div>

              {/* Air-Fuel Ratio (AFR) */}
              <div>
                <div className="flex justify-between text-xs font-medium mb-1">
                  <span className="text-zinc-400">Target Air-Fuel Ratio (AFR)</span>
                  <span className="font-mono text-amber-400 font-bold">{targetAfr.toFixed(1)}</span>
                </div>
                <input
                  type="range"
                  min="11.0"
                  max="17.0"
                  step="0.1"
                  value={targetAfr}
                  onChange={(e) => setTargetAfr(parseFloat(e.target.value))}
                  className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
                />
                <div className="flex justify-between text-[10px] text-zinc-500 font-mono mt-1">
                  <span>11.0 RICH</span>
                  <span>14.7 STOICH</span>
                  <span>17.0 LEAN</span>
                </div>
              </div>

              {/* VE Multiplier */}
              <div>
                <div className="flex justify-between text-xs font-medium mb-1">
                  <span className="text-zinc-400">Volumetric Efficiency Scale</span>
                  <span className="font-mono text-pink-400 font-bold">{(veScale * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min="0.70"
                  max="1.25"
                  step="0.01"
                  value={veScale}
                  onChange={(e) => setVeScale(parseFloat(e.target.value))}
                  className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-pink-500"
                />
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-zinc-800">
            <button
              onClick={() => {
                setIgnitionAdvance(22);
                setCompressionRatio(selectedEngine.cr);
                setTargetAfr(14.7);
                setVeScale(1.0);
              }}
              className="w-full py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-bold rounded-xl transition-colors cursor-pointer border border-zinc-700/60"
            >
              Reset ECU Map Defaults
            </button>
          </div>
        </div>

        {/* CARD 5: DYNAMIC CHARTS & R ANALYTICS PANEL (2 COLS, 1 ROW) */}
        <div className="col-span-1 md:col-span-2 bg-zinc-900/90 border border-zinc-800 rounded-3xl p-5 flex flex-col justify-between shadow-lg">
          {/* Panel Header & Tab Switching */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 mb-3 pb-3 border-b border-zinc-800">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-indigo-400" />
              <h3 className="text-sm font-bold text-white tracking-wide uppercase">Simulation Analytics & Diagnostics</h3>
            </div>

            <div className="flex gap-1 bg-zinc-950 p-1 rounded-xl border border-zinc-800">
              <button
                onClick={() => setActiveTab('dyno')}
                className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  activeTab === 'dyno' ? 'bg-indigo-600 text-white' : 'text-zinc-400 hover:text-white'
                }`}
              >
                Dyno Curve
              </button>
              <button
                onClick={() => setActiveTab('pv')}
                className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  activeTab === 'pv' ? 'bg-indigo-600 text-white' : 'text-zinc-400 hover:text-white'
                }`}
              >
                P-V Diagram
              </button>
              <button
                onClick={() => setActiveTab('r_analytics')}
                className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  activeTab === 'r_analytics' ? 'bg-indigo-600 text-white' : 'text-zinc-400 hover:text-white'
                }`}
              >
                iceR Analytics
              </button>
            </div>
          </div>

          {/* TAB 1: DYNAMOMETER POWER & TORQUE CURVES */}
          {activeTab === 'dyno' && (
            <div className="h-48 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={dynoData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                  <XAxis dataKey="rpm" stroke="#71717a" fontSize={10} />
                  <YAxis stroke="#71717a" fontSize={10} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a', borderRadius: '12px' }}
                    labelStyle={{ color: '#a1a1aa' }}
                  />
                  <Line type="monotone" dataKey="power" name="Power (HP)" stroke="#6366f1" strokeWidth={2.5} dot={false} />
                  <Line type="monotone" dataKey="torque" name="Torque (Nm)" stroke="#10b981" strokeWidth={2.5} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* TAB 2: P-V THERMODYNAMIC CYLINDER PRESSURE DIAGRAM */}
          {activeTab === 'pv' && (
            <div className="h-48 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={pvData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                  <XAxis dataKey="angle" stroke="#71717a" fontSize={10} unit="°" />
                  <YAxis stroke="#71717a" fontSize={10} unit=" bar" />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a', borderRadius: '12px' }}
                  />
                  <Area type="monotone" dataKey="pressure" name="Cylinder Pressure (bar)" stroke="#f59e0b" fill="#f59e0b22" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* TAB 3: iceR STATISTICAL SENSITIVITY TORNADO CHART */}
          {activeTab === 'r_analytics' && (
            <div className="h-48 w-full flex flex-col justify-between">
              <p className="text-xs text-zinc-400 mb-2">
                Global Sobol Sensitivity Analysis computed via <span className="font-mono text-indigo-400">iceR::sensitivity_analysis()</span>
              </p>
              <div className="space-y-2 font-mono text-xs">
                {[
                  { param: 'Displacement (L)', first: 42, total: 48, color: 'bg-indigo-500' },
                  { param: 'Compression Ratio', first: 21, total: 25, color: 'bg-emerald-500' },
                  { param: 'Ignition Timing', first: 18, total: 22, color: 'bg-amber-500' },
                  { param: 'Volumetric Efficiency', first: 12, total: 15, color: 'bg-pink-500' },
                ].map((item) => (
                  <div key={item.param} className="space-y-1">
                    <div className="flex justify-between text-[11px] text-zinc-300">
                      <span>{item.param}</span>
                      <span className="text-zinc-500">Sobol Index: {(item.total / 100).toFixed(2)}</span>
                    </div>
                    <div className="h-2 w-full bg-zinc-800 rounded-full overflow-hidden flex">
                      <div className={`h-full ${item.color}`} style={{ width: `${item.total}%` }}></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex justify-between items-center text-xs text-zinc-500 pt-2 border-t border-zinc-800/80 mt-2">
            <span>Kernel Telemetry Buffer: {telemetryHistory.length} frames</span>
            <button
              onClick={() => {
                const headers = 'time,rpm,torque,power,map,speed,temp\n';
                const rows = telemetryHistory
                  .map((h) => `${h.time},${h.rpm},${h.torque},${h.power},${h.map},${h.speed},${h.temp}`)
                  .join('\n');
                const blob = new Blob([headers + rows], { type: 'text/csv' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'ice_rs_telemetry.csv';
                a.click();
              }}
              className="flex items-center gap-1.5 text-indigo-400 hover:text-indigo-300 font-semibold cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" /> Export Parquet / CSV
            </button>
          </div>
        </div>

        {/* CARD 6: PROCEDURAL ACOUSTICS & SOUND SYNTH (1 COL, 1 ROW) */}
        <div className="col-span-1 bg-zinc-900/90 border border-zinc-800 rounded-3xl p-5 flex flex-col justify-between shadow-lg">
          <div className="flex justify-between items-center">
            <span className="text-zinc-400 text-xs font-bold uppercase tracking-wider flex items-center gap-1">
              <Volume2 className="w-3.5 h-3.5 text-amber-400" /> Acoustic Synthesizer
            </span>
            <span className="text-xs font-mono text-emerald-400">44.1 kHz DSP</span>
          </div>

          <div className="my-2 space-y-2">
            <div className="bg-zinc-950 p-3 rounded-2xl border border-zinc-800 font-mono text-xs space-y-1">
              <div className="flex justify-between">
                <span className="text-zinc-500">Firing Frequency:</span>
                <span className="text-amber-400 font-bold">{Math.round((rpm / 60) * 4)} Hz</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-500">Exhaust Resonance:</span>
                <span className="text-indigo-400 font-bold">{Math.round(rpm * 0.28)} Hz</span>
              </div>
            </div>

            {/* Audio Volume Slider */}
            <div>
              <div className="flex justify-between text-xs text-zinc-400 mb-1">
                <span>Master Volume</span>
                <span className="font-mono text-white">{Math.round(audioVolume * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={audioVolume}
                onChange={(e) => setAudioVolume(parseFloat(e.target.value))}
                className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
              />
            </div>
          </div>

          <div className="text-[11px] text-zinc-500 leading-tight">
            Procedural engine acoustics generated in real-time without static sound files.
          </div>
        </div>

      </main>

      {/* FOOTER BAR */}
      <footer className="flex flex-col sm:flex-row justify-between items-center bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-3 px-6 text-xs text-zinc-500 gap-2 shrink-0">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5 text-zinc-400">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Rust + R Simulation Stack
          </span>
          <span className="hidden sm:inline">•</span>
          <span>Deterministic Slider-Crank Physics Kernel</span>
        </div>
        <div className="flex items-center gap-3 font-mono text-[11px]">
          <span>Parquet / Arrow Telemetry Export Ready</span>
        </div>
      </footer>
    </div>
  );
}
