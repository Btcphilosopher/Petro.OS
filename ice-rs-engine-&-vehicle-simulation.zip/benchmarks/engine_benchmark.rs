use ice_core::simulation::simulator::Simulator;
use std::time::Instant;

fn main() {
    println!("=== ICE-RS Benchmark: 1,000,000 Physics Steps ===");
    let mut sim = Simulator::new(0.0001);
    let start = Instant::now();

    for _ in 0..1_000_000 {
        sim.step(1.0);
    }

    let elapsed = start.elapsed();
    let steps_per_sec = 1_000_000.0 / elapsed.as_secs_f64();
    println!("Completed 1,000,000 steps in {:.3}s ({:.1} steps/sec)", elapsed.as_secs_f64(), steps_per_sec);
}
