#[derive(Debug, Clone)]
pub struct TractionControl {
    pub max_allowed_slip: f64,
}
