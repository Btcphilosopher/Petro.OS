#[derive(Debug, Clone)]
pub struct PacejkaTyreModel {
    pub stiffness_b: f64,
    pub shape_c: f64,
    pub peak_mu: f64,
}

impl Default for PacejkaTyreModel {
    fn default() -> Self {
        Self {
            stiffness_b: 10.0,
            shape_c: 1.65,
            peak_mu: 1.15,
        }
    }
}

impl PacejkaTyreModel {
    pub fn force_from_slip(&self, slip_ratio: f64, normal_force_n: f64) -> f64 {
        let mu = self.peak_mu * (self.shape_c * (self.stiffness_b * slip_ratio).atan()).sin();
        mu * normal_force_n
    }
}
