#[derive(Debug, Clone)]
pub struct Vehicle {
    pub name: String,
    pub mass_kg: f64,
    pub wheel_radius_m: f64,
    pub frontal_area_m2: f64,
    pub drag_coefficient: f64,
    pub rolling_resistance_coeff: f64,
    pub velocity_m_s: f64,
    pub position_m: f64,
    pub acceleration_m_s2: f64,
    pub tyre_friction_coeff: f64,
}

impl Default for Vehicle {
    fn default() -> Self {
        Self {
            name: "GT Sports Coupe".to_string(),
            mass_kg: 1620.0,
            wheel_radius_m: 0.34,
            frontal_area_m2: 2.25,
            drag_coefficient: 0.31,
            rolling_resistance_coeff: 0.015,
            velocity_m_s: 0.0,
            position_m: 0.0,
            acceleration_m_s2: 0.0,
            tyre_friction_coeff: 1.15,
        }
    }
}

impl Vehicle {
    pub fn step(&mut self, wheel_torque_nm: f64, air_density_kg_m3: f64, dt_s: f64) {
        let drive_force = wheel_torque_nm / self.wheel_radius_m;

        // Traction limit (Pacejka approximation max force)
        let normal_force = self.mass_kg * 9.81;
        let max_traction = normal_force * self.tyre_friction_coeff;
        let traction_force = drive_force.clamp(-max_traction, max_traction);

        // Aerodynamic drag
        let aero_drag = 0.5 * air_density_kg_m3 * self.drag_coefficient * self.frontal_area_m2 * self.velocity_m_s.powi(2);

        // Rolling resistance
        let rolling_resistance = normal_force * self.rolling_resistance_coeff;

        let net_force = traction_force - aero_drag - rolling_resistance;
        self.acceleration_m_s2 = net_force / self.mass_kg;

        self.velocity_m_s += self.acceleration_m_s2 * dt_s;
        if self.velocity_m_s < 0.0 {
            self.velocity_m_s = 0.0;
        }

        self.position_m += self.velocity_m_s * dt_s;
    }

    pub fn speed_kmh(&self) -> f64 {
        self.velocity_m_s * 3.6
    }
}
