#[derive(Debug, Clone)]
pub struct DynamicsState {
    pub pitch_rad: f64,
}
