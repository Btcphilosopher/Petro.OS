#[derive(Debug, Clone)]
pub struct Aerodynamics {
    pub cd: f64,
    pub frontal_area_m2: f64,
}
