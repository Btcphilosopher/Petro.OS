/// Ignition system controller.
#[derive(Debug, Clone)]
pub struct IgnitionModel {
    pub base_timing_deg: f64,
    pub current_timing_deg: f64,
}

impl IgnitionModel {
    pub fn new(base_timing_deg: f64) -> Self {
        Self {
            base_timing_deg,
            current_timing_deg: base_timing_deg,
        }
    }

    /// Calculate ignition advance based on RPM and load
    pub fn advance_deg(&mut self, rpm: f64, load_ratio: f64) -> f64 {
        let rpm_advance = (rpm / 1000.0) * 3.5;
        let load_retard = load_ratio * 12.0;
        self.current_timing_deg = (self.base_timing_deg + rpm_advance - load_retard).clamp(5.0, 45.0);
        self.current_timing_deg
    }
}
