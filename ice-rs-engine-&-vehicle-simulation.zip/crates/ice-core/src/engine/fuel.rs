/// Fuel injection and AFR model.
#[derive(Debug, Clone)]
pub struct FuelModel {
    pub stoich_afr: f64,
    pub fuel_lhv_j_kg: f64,
    pub commanded_afr: f64,
    pub fuel_mass_flow_kg_s: f64,
}

impl FuelModel {
    pub fn new(stoich_afr: f64, fuel_lhv_j_kg: f64) -> Self {
        Self {
            stoich_afr,
            fuel_lhv_j_kg,
            commanded_afr: stoich_afr,
            fuel_mass_flow_kg_s: 0.0,
        }
    }

    pub fn calculate_fuel_mass_per_cylinder_cycle(
        &mut self,
        cylinder_air_mass_kg: f64,
        target_afr: f64,
    ) -> f64 {
        self.commanded_afr = target_afr.max(10.0);
        cylinder_air_mass_kg / self.commanded_afr
    }
}
