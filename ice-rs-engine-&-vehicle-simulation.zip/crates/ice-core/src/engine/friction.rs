/// Engine mechanical friction and pumping losses model.
#[derive(Debug, Clone)]
pub struct EngineFrictionModel {
    pub c1_bar: f64,
    pub c2_bar: f64,
    pub c3_bar: f64,
}

impl Default for EngineFrictionModel {
    fn default() -> Self {
        Self {
            c1_bar: 0.4, // Boundary friction component
            c2_bar: 0.05, // Hydrodynamic friction component
            c3_bar: 0.008, // Viscous windage component
        }
    }
}

impl EngineFrictionModel {
    /// Calculate friction torque in Nm as a function of RPM, displacement, and oil temperature
    pub fn friction_torque_nm(&self, rpm: f64, displacement_m3: f64, oil_temp_c: f64) -> f64 {
        let speed_k = rpm / 1000.0;
        let fmep_bar = self.c1_bar + self.c2_bar * speed_k + self.c3_bar * speed_k.powi(2);
        let fmep_pa = fmep_bar * 100000.0;

        // Viscosity temperature multiplier (cold oil has higher friction)
        let temp_factor = if oil_temp_c < 90.0 {
            1.0 + (90.0 - oil_temp_c) * 0.015
        } else {
            1.0
        };

        (fmep_pa * displacement_m3 / (4.0 * std::f64::consts::PI)) * temp_factor
    }
}
