/// Valvetrain timing and lift model.
#[derive(Debug, Clone, Copy)]
pub struct ValvetrainModel {
    pub intake_open_deg: f64,
    pub intake_close_deg: f64,
    pub exhaust_open_deg: f64,
    pub exhaust_close_deg: f64,
    pub max_lift_m: f64,
}

impl Default for ValvetrainModel {
    fn default() -> Self {
        Self {
            intake_open_deg: 350.0,
            intake_close_deg: 580.0,
            exhaust_open_deg: 130.0,
            exhaust_close_deg: 370.0,
            max_lift_m: 0.0105, // 10.5 mm lift
        }
    }
}
