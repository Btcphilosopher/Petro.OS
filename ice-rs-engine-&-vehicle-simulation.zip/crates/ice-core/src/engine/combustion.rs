/// Wiebe combustion function parameters and heat release solver.
#[derive(Debug, Clone, Copy)]
pub struct WiebeCombustionModel {
    pub a: f64,              // Efficiency parameter (typically 5.0 for 99% burn)
    pub m: f64,              // Form factor (typically 1.5 - 3.0)
    pub burn_duration_rad: f64, // Burn duration in radians (~40-50 deg)
}

impl Default for WiebeCombustionModel {
    fn default() -> Self {
        Self {
            a: 5.0,
            m: 2.0,
            burn_duration_rad: 45.0 * std::f64::consts::PI / 180.0,
        }
    }
}

impl WiebeCombustionModel {
    /// Calculate mass fraction burned x_b (0.0 to 1.0) at current crank angle.
    pub fn mass_fraction_burned(&self, current_angle_rad: f64, spark_angle_rad: f64) -> f64 {
        let delta = current_angle_rad - spark_angle_rad;
        if delta <= 0.0 {
            return 0.0;
        }
        if delta >= self.burn_duration_rad {
            return 1.0;
        }

        let y = delta / self.burn_duration_rad;
        1.0 - (-self.a * y.powf(self.m + 1.0)).exp()
    }

    /// Calculate rate of heat release (dx_b/dtheta).
    pub fn heat_release_rate(&self, current_angle_rad: f64, spark_angle_rad: f64) -> f64 {
        let delta = current_angle_rad - spark_angle_rad;
        if delta <= 0.0 || delta >= self.burn_duration_rad {
            return 0.0;
        }

        let y = delta / self.burn_duration_rad;
        let d_exp = (-self.a * y.powf(self.m + 1.0)).exp();
        (self.a * (self.m + 1.0) / self.burn_duration_rad) * y.powf(self.m) * d_exp
    }
}
