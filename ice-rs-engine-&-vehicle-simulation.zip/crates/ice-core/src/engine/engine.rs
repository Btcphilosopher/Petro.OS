use super::geometry::SliderCrankGeometry;
use super::crankshaft::Crankshaft;
use super::cylinder::Cylinder;
use super::airflow::AirflowModel;
use super::fuel::FuelModel;
use super::ignition::IgnitionModel;
use super::friction::EngineFrictionModel;
use super::engine_state::EngineState;

#[derive(Debug, Clone)]
pub struct Engine {
    pub name: String,
    pub cylinders_count: usize,
    pub geometry: SliderCrankGeometry,
    pub crankshaft: Crankshaft,
    pub cylinders: Vec<Cylinder>,
    pub airflow: AirflowModel,
    pub fuel: FuelModel,
    pub ignition: IgnitionModel,
    pub friction: EngineFrictionModel,
    pub coolant_temp_c: f64,
    pub oil_temp_c: f64,
    pub firing_order: Vec<usize>,
}

impl Engine {
    pub fn new_v8_5l() -> Self {
        let cylinders_count = 8;
        let bore = 0.0922;
        let stroke = 0.0927;
        let rod = 0.1507;
        let cr = 11.0;
        let geometry = SliderCrankGeometry::new(bore, stroke, rod, cr);
        let crankshaft = Crankshaft::new(0.18, 750.0);

        // Firing order 1-8-4-3-6-5-7-2 -> offsets in radians across 720 deg (4pi)
        let firing_order = vec![1, 8, 4, 3, 6, 5, 7, 2];
        let mut cylinders = Vec::with_capacity(cylinders_count);
        for i in 0..cylinders_count {
            let offset_rad = (i as f64) * (4.0 * std::f64::consts::PI / 8.0);
            cylinders.push(Cylinder::new(i + 1, offset_rad));
        }

        Self {
            name: "V8 5.0L NA".to_string(),
            cylinders_count,
            geometry,
            crankshaft,
            cylinders,
            airflow: AirflowModel::new(101325.0, 101325.0),
            fuel: FuelModel::new(14.7, 44_000_000.0),
            ignition: IgnitionModel::new(22.0),
            friction: EngineFrictionModel::default(),
            coolant_temp_c: 20.0,
            oil_temp_c: 20.0,
            firing_order,
        }
    }

    /// Step the entire engine state by dt_s
    pub fn step(&mut self, throttle_pos: f64, load_torque_nm: f64, dt_s: f64) -> EngineState {
        let rpm = self.crankshaft.rpm();
        let displacement = self.geometry.swept_volume_m3 * (self.cylinders_count as f64);

        // Update airflow
        self.airflow.step(throttle_pos, rpm, displacement, dt_s);

        // Update ignition advance
        let ignition_deg = self.ignition.advance_deg(rpm, throttle_pos);

        // Calculate fuel per cylinder cycle
        let cyl_air_mass = (self.airflow.air_mass_flow_kg_s * 2.0 / (self.cylinders_count as f64 * (rpm / 60.0).max(1.0))).max(1e-7);
        let fuel_mass_cyl = self.fuel.calculate_fuel_mass_per_cylinder_cycle(cyl_air_mass, 14.7);

        // Step each cylinder and sum indicated torque
        let crank_angle = self.crankshaft.crank_angle_rad;
        let mut total_indicated_torque = 0.0;
        for cyl in &mut self.cylinders {
            cyl.step(crank_angle, &self.geometry, self.airflow.current_manifold_pressure_pa, ignition_deg, fuel_mass_cyl, self.fuel.fuel_lhv_j_kg);
            total_indicated_torque += cyl.indicated_torque_nm;
        }

        // Calculate friction torque
        let friction_torque = self.friction.friction_torque_nm(rpm, displacement, self.oil_temp_c);

        // Net torque acting on crankshaft
        let net_torque = total_indicated_torque - friction_torque - load_torque_nm;

        // Step crankshaft dynamics
        self.crankshaft.step(net_torque, dt_s);

        // Update thermal state slightly
        let heat_gen = (total_indicated_torque.max(0.0) * self.crankshaft.angular_velocity_rad_s) * 0.0001;
        self.coolant_temp_c = (self.coolant_temp_c + heat_gen * dt_s).min(115.0);
        self.oil_temp_c = (self.oil_temp_c + heat_gen * 0.8 * dt_s).min(125.0);

        let power_w = total_indicated_torque.max(0.0) * self.crankshaft.angular_velocity_rad_s;
        let power_kw = power_w / 1000.0;
        let power_hp = power_kw * 1.34102;

        let fuel_flow_kg_h = (fuel_mass_cyl * (self.cylinders_count as f64) * (rpm / 60.0 / 2.0)) * 3600.0;
        let bsfc_g_kwh = if power_kw > 1.0 { (fuel_flow_kg_h * 1000.0) / power_kw } else { 350.0 };

        EngineState {
            time_s: 0.0,
            rpm: self.crankshaft.rpm(),
            angular_velocity_rad_s: self.crankshaft.angular_velocity_rad_s,
            crank_angle_rad: self.crankshaft.crank_angle_rad,
            net_torque_nm: net_torque,
            indicated_torque_nm: total_indicated_torque,
            friction_torque_nm: friction_torque,
            power_kw,
            power_hp,
            manifold_pressure_pa: self.airflow.current_manifold_pressure_pa,
            air_mass_flow_kg_s: self.airflow.air_mass_flow_kg_s,
            fuel_mass_flow_kg_s: fuel_flow_kg_h / 3600.0,
            volumetric_efficiency: self.airflow.volumetric_efficiency,
            afr: 14.7,
            ignition_timing_deg: ignition_deg,
            coolant_temp_c: self.coolant_temp_c,
            oil_temp_c: self.oil_temp_c,
            oil_pressure_bar: 1.5 + (rpm / 1000.0) * 0.8,
            bsfc_g_kwh,
        }
    }
}
