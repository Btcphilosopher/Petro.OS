/// Complete physical state of the engine at a single simulation timestep.
#[derive(Debug, Clone)]
pub struct EngineState {
    pub time_s: f64,
    pub rpm: f64,
    pub angular_velocity_rad_s: f64,
    pub crank_angle_rad: f64,
    pub net_torque_nm: f64,
    pub indicated_torque_nm: f64,
    pub friction_torque_nm: f64,
    pub power_kw: f64,
    pub power_hp: f64,
    pub manifold_pressure_pa: f64,
    pub air_mass_flow_kg_s: f64,
    pub fuel_mass_flow_kg_s: f64,
    pub volumetric_efficiency: f64,
    pub afr: f64,
    pub ignition_timing_deg: f64,
    pub coolant_temp_c: f64,
    pub oil_temp_c: f64,
    pub oil_pressure_bar: f64,
    pub bsfc_g_kwh: f64,
}
