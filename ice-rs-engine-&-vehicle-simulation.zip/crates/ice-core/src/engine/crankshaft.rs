/// Crankshaft rotational dynamics model.
#[derive(Debug, Clone)]
pub struct Crankshaft {
    pub inertia_kg_m2: f64,
    pub crank_angle_rad: f64,
    pub angular_velocity_rad_s: f64,
    pub angular_acceleration_rad_s2: f64,
}

impl Crankshaft {
    pub fn new(inertia_kg_m2: f64, initial_rpm: f64) -> Self {
        let initial_omega = initial_rpm * (2.0 * std::f64::consts::PI / 60.0);
        Self {
            inertia_kg_m2,
            crank_angle_rad: 0.0,
            angular_velocity_rad_s: initial_omega,
            angular_acceleration_rad_s2: 0.0,
        }
    }

    pub fn rpm(&self) -> f64 {
        self.angular_velocity_rad_s * (60.0 / (2.0 * std::f64::consts::PI))
    }

    /// Step the rotational dynamics given net torque and timestep dt.
    pub fn step(&mut self, net_torque_nm: f64, dt_s: f64) {
        self.angular_acceleration_rad_s2 = net_torque_nm / self.inertia_kg_m2;
        self.angular_velocity_rad_s += self.angular_acceleration_rad_s2 * dt_s;

        // Prevent negative rotation or extreme runaway
        if self.angular_velocity_rad_s < 0.0 {
            self.angular_velocity_rad_s = 0.0;
        }

        self.crank_angle_rad += self.angular_velocity_rad_s * dt_s;
        self.crank_angle_rad %= 4.0 * std::f64::consts::PI; // 720 degrees cycle
    }
}
