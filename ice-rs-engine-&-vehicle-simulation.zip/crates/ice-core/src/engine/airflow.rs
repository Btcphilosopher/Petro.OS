/// Airflow and volumetric efficiency (VE) model.
#[derive(Debug, Clone)]
pub struct AirflowModel {
    pub max_manifold_pressure_pa: f64,
    pub atmospheric_pressure_pa: f64,
    pub current_manifold_pressure_pa: f64,
    pub volumetric_efficiency: f64,
    pub air_mass_flow_kg_s: f64,
}

impl AirflowModel {
    pub fn new(max_manifold_pressure_pa: f64, atmospheric_pressure_pa: f64) -> Self {
        Self {
            max_manifold_pressure_pa,
            atmospheric_pressure_pa,
            current_manifold_pressure_pa: 35000.0, // Idle vacuum ~35 kPa
            volumetric_efficiency: 0.85,
            air_mass_flow_kg_s: 0.0,
        }
    }

    /// Estimate VE from RPM (500 to 7500) and MAP
    pub fn lookup_ve(&self, rpm: f64, load_ratio: f64) -> f64 {
        let base_ve = 0.65 + 0.30 * (rpm / 5000.0).min(1.0) - 0.15 * (rpm / 7500.0).powi(2);
        (base_ve * (0.4 + 0.6 * load_ratio)).clamp(0.40, 1.15)
    }

    /// Step manifold pressure and airflow rate based on throttle position (0.0 - 1.0)
    pub fn step(&mut self, throttle_pos: f64, rpm: f64, displacement_m3: f64, dt_s: f64) {
        let target_map = self.atmospheric_pressure_pa * (0.35 + 0.65 * throttle_pos.clamp(0.0, 1.0));
        let tau = 0.05; // 50ms manifold filling time constant

        self.current_manifold_pressure_pa += (target_map - self.current_manifold_pressure_pa) * (dt_s / tau);
        self.volumetric_efficiency = self.lookup_ve(rpm, throttle_pos);

        let air_density = self.current_manifold_pressure_pa / (287.05 * 300.0);
        let displacement_rate = (displacement_m3 * (rpm / 60.0)) / 2.0; // 4-stroke
        self.air_mass_flow_kg_s = displacement_rate * air_density * self.volumetric_efficiency;
    }
}
