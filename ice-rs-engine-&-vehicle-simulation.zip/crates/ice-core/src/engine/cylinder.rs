use super::geometry::SliderCrankGeometry;
use super::combustion::WiebeCombustionModel;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum StrokePhase {
    Intake,
    Compression,
    CombustionPower,
    Exhaust,
}

#[derive(Debug, Clone)]
pub struct Cylinder {
    pub id: usize,
    pub crank_offset_rad: f64,
    pub pressure_pa: f64,
    pub temperature_k: f64,
    pub volume_m3: f64,
    pub mass_air_kg: f64,
    pub mass_fuel_kg: f64,
    pub combustion_progress: f64,
    pub indicated_torque_nm: f64,
    pub stroke_phase: StrokePhase,
    pub wiebe: WiebeCombustionModel,
}

impl Cylinder {
    pub fn new(id: usize, crank_offset_rad: f64) -> Self {
        Self {
            id,
            crank_offset_rad,
            pressure_pa: 101325.0,
            temperature_k: 300.0,
            volume_m3: 0.0006,
            mass_air_kg: 0.0006,
            mass_fuel_kg: 0.00004,
            combustion_progress: 0.0,
            indicated_torque_nm: 0.0,
            stroke_phase: StrokePhase::Intake,
            wiebe: WiebeCombustionModel::default(),
        }
    }

    /// Calculate cylinder angle in 0..720 deg (0..4pi) cycle reference
    pub fn cycle_angle_rad(&self, engine_crank_angle_rad: f64) -> f64 {
        let raw = (engine_crank_angle_rad + self.crank_offset_rad) % (4.0 * std::f64::consts::PI);
        if raw < 0.0 { raw + 4.0 * std::f64::consts::PI } else { raw }
    }

    /// Step the thermodynamic state of the cylinder
    pub fn step(
        &mut self,
        engine_crank_angle_rad: f64,
        geometry: &SliderCrankGeometry,
        manifold_pressure_pa: f64,
        ignition_timing_deg: f64,
        fuel_mass_per_cycle_kg: f64,
        lhv_j_kg: f64,
    ) {
        let cycle_angle = self.cycle_angle_rad(engine_crank_angle_rad);
        let cycle_deg = cycle_angle * (180.0 / std::f64::consts::PI);

        let new_vol = geometry.instantaneous_volume_m3(cycle_angle);
        let gamma = 1.35; // Specific heat ratio for air-fuel gas mix

        // Determine phase
        if cycle_deg < 180.0 {
            self.stroke_phase = StrokePhase::Intake;
            self.pressure_pa = manifold_pressure_pa;
            self.combustion_progress = 0.0;
            self.mass_fuel_kg = fuel_mass_per_cycle_kg;
            self.mass_air_kg = (manifold_pressure_pa * new_vol) / (287.0 * 300.0);
        } else if cycle_deg < 360.0 {
            self.stroke_phase = StrokePhase::Compression;
            // Isentropic compression: P2 = P1 * (V1/V2)^gamma
            let p_comp = manifold_pressure_pa * (geometry.instantaneous_volume_m3(std::f64::consts::PI) / new_vol).powf(gamma);
            self.pressure_pa = p_comp;
        } else if cycle_deg < 540.0 {
            self.stroke_phase = StrokePhase::CombustionPower;
            let spark_angle_rad = (360.0 - ignition_timing_deg) * (std::f64::consts::PI / 180.0);
            self.combustion_progress = self.wiebe.mass_fraction_burned(cycle_angle, spark_angle_rad);

            let base_comp = manifold_pressure_pa * (geometry.instantaneous_volume_m3(std::f64::consts::PI) / new_vol).powf(gamma);
            let total_energy = self.mass_fuel_kg * lhv_j_kg * 0.95; // 95% combustion efficiency
            let added_pressure = (self.combustion_progress * total_energy * (gamma - 1.0)) / new_vol;

            self.pressure_pa = base_comp + added_pressure;
        } else {
            self.stroke_phase = StrokePhase::Exhaust;
            self.pressure_pa = 101325.0 * 1.1; // Slightly above atmospheric during blowdown
            self.combustion_progress = 1.0;
        }

        self.volume_m3 = new_vol;

        // Calculate instantaneous torque acting on crank
        let r = geometry.crank_radius_m;
        let l = geometry.connecting_rod_m;
        let sin_t = cycle_angle.sin();
        let cos_t = cycle_angle.cos();
        let sqrt_term = (l.powi(2) - r.powi(2) * sin_t.powi(2)).max(1e-9).sqrt();

        let net_gauge_pressure = (self.pressure_pa - 101325.0).max(0.0);
        let piston_force = net_gauge_pressure * geometry.piston_area_m2;
        self.indicated_torque_nm = piston_force * r * sin_t * (1.0 + (r * cos_t) / sqrt_term);
    }
}
