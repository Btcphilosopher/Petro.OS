use std::f64::consts::PI;

/// Slider-crank piston/connecting-rod geometry model.
#[derive(Debug, Clone, Copy)]
pub struct SliderCrankGeometry {
    pub bore_m: f64,
    pub stroke_m: f64,
    pub crank_radius_m: f64,
    pub connecting_rod_m: f64,
    pub compression_ratio: f64,
    pub piston_area_m2: f64,
    pub swept_volume_m3: f64,
    pub clearance_volume_m3: f64,
}

impl SliderCrankGeometry {
    pub fn new(bore_m: f64, stroke_m: f64, connecting_rod_m: f64, compression_ratio: f64) -> Self {
        let crank_radius_m = stroke_m / 2.0;
        let piston_area_m2 = PI * (bore_m / 2.0).powi(2);
        let swept_volume_m3 = piston_area_m2 * stroke_m;
        let clearance_volume_m3 = swept_volume_m3 / (compression_ratio - 1.0);

        Self {
            bore_m,
            stroke_m,
            crank_radius_m,
            connecting_rod_m,
            compression_ratio,
            piston_area_m2,
            swept_volume_m3,
            clearance_volume_m3,
        }
    }

    /// Calculate instantaneous piston position from TDC (0 = TDC, metres).
    pub fn piston_position_m(&self, crank_angle_rad: f64) -> f64 {
        let r = self.crank_radius_m;
        let l = self.connecting_rod_m;
        let theta = crank_angle_rad;

        let term1 = r * theta.cos();
        let term2 = (l.powi(2) - r.powi(2) * theta.sin().powi(2)).max(0.0).sqrt();
        let dist_from_crank_center = term1 + term2;
        let max_dist = r + l;

        max_dist - dist_from_crank_center
    }

    /// Calculate instantaneous cylinder volume in cubic metres.
    pub fn instantaneous_volume_m3(&self, crank_angle_rad: f64) -> f64 {
        let pos = self.piston_position_m(crank_angle_rad);
        self.clearance_volume_m3 + self.piston_area_m2 * pos
    }

    /// Calculate instantaneous piston velocity (m/s) given angular velocity omega (rad/s).
    pub fn piston_velocity_m_s(&self, crank_angle_rad: f64, omega_rad_s: f64) -> f64 {
        let r = self.crank_radius_m;
        let l = self.connecting_rod_m;
        let theta = crank_angle_rad;

        let sin_t = theta.sin();
        let cos_t = theta.cos();
        let sqrt_term = (l.powi(2) - r.powi(2) * sin_t.powi(2)).max(1e-9).sqrt();

        omega_rad_s * r * sin_t * (1.0 + (r * cos_t) / sqrt_term)
    }
}
