#[derive(Debug, Clone)]
pub struct CylinderThermal {
    pub wall_temp_c: f64,
}
