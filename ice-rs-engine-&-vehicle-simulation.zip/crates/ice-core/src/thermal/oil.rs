#[derive(Debug, Clone)]
pub struct OilSystem {
    pub capacity_l: f64,
    pub target_temp_c: f64,
}
