#[derive(Debug, Clone)]
pub struct CoolantLoop {
    pub capacity_l: f64,
    pub target_temp_c: f64,
}
