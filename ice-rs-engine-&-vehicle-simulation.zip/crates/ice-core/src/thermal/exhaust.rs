#[derive(Debug, Clone)]
pub struct ExhaustThermal {
    pub runner_temp_c: f64,
}
