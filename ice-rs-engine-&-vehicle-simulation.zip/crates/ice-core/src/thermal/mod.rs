pub mod coolant;
pub mod oil;
pub mod cylinder;
pub mod exhaust;

#[derive(Debug, Clone)]
pub struct LumpedThermalSystem {
    pub coolant_temp_c: f64,
    pub oil_temp_c: f64,
    pub cylinder_head_temp_c: f64,
    pub exhaust_temp_c: f64,
}

impl Default for LumpedThermalSystem {
    fn default() -> Self {
        Self {
            coolant_temp_c: 20.0,
            oil_temp_c: 20.0,
            cylinder_head_temp_c: 20.0,
            exhaust_temp_c: 20.0,
        }
    }
}
