#[derive(Debug, Clone)]
pub struct IdleGovernor {
    pub target_rpm: f64,
}
