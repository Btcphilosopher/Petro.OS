#[derive(Debug, Clone)]
pub struct ThermalProtection {
    pub max_coolant_temp_c: f64,
}
