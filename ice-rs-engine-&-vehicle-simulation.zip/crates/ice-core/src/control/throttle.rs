#[derive(Debug, Clone)]
pub struct ElectronicThrottleControl {
    pub position: f64,
}
