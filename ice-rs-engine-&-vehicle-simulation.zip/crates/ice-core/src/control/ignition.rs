#[derive(Debug, Clone)]
pub struct IgnitionControlMap {
    pub base_advance_deg: f64,
}
