#[derive(Debug, Clone)]
pub struct FuelControlMap {
    pub target_lambda: f64,
}
