#[derive(Debug, Clone)]
pub struct ECU {
    pub target_idle_rpm: f64,
    pub redline_rpm: f64,
    pub soft_cut_rpm: f64,
    pub hard_cut_rpm: f64,
    pub is_rev_limiting: bool,
    pub coolant_protection_temp_c: f64,
}

impl Default for ECU {
    fn default() -> Self {
        Self {
            target_idle_rpm: 750.0,
            redline_rpm: 7000.0,
            soft_cut_rpm: 7000.0,
            hard_cut_rpm: 7200.0,
            is_rev_limiting: false,
            coolant_protection_temp_c: 115.0,
        }
    }
}

impl ECU {
    pub fn process(&mut self, rpm: f64, driver_throttle: f64, coolant_temp: f64) -> (f64, bool) {
        // Rev limiter check
        if rpm >= self.hard_cut_rpm {
            self.is_rev_limiting = true;
            return (0.0, true);
        } else if rpm < self.soft_cut_rpm {
            self.is_rev_limiting = false;
        }

        // Thermal protection retard
        let mut final_throttle = driver_throttle;
        if coolant_temp > self.coolant_protection_temp_c {
            final_throttle *= 0.5; // Limp mode
        }

        // Idle governor PID approximation
        if driver_throttle < 0.05 && rpm < self.target_idle_rpm + 200.0 {
            let error = self.target_idle_rpm - rpm;
            let idle_adder = (error * 0.001).clamp(0.0, 0.25);
            final_throttle = idle_adder;
        }

        (final_throttle, self.is_rev_limiting)
    }
}
