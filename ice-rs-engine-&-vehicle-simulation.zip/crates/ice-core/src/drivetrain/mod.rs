pub mod clutch;
pub mod transmission;
pub mod driveshaft;
pub mod differential;
pub mod wheel;

#[derive(Debug, Clone)]
pub struct Drivetrain {
    pub clutch_capacity_nm: f64,
    pub gear_ratios: Vec<f64>,
    pub current_gear: usize, // 1-indexed
    pub final_drive_ratio: f64,
    pub efficiency: f64,
}

impl Default for Drivetrain {
    fn default() -> Self {
        Self {
            clutch_capacity_nm: 750.0,
            gear_ratios: vec![3.20, 2.10, 1.48, 1.12, 0.89, 0.73],
            current_gear: 1,
            final_drive_ratio: 3.55,
            efficiency: 0.94,
        }
    }
}

impl Drivetrain {
    pub fn total_ratio(&self) -> f64 {
        if self.current_gear == 0 || self.current_gear > self.gear_ratios.len() {
            0.0 // Neutral
        } else {
            self.gear_ratios[self.current_gear - 1] * self.final_drive_ratio
        }
    }

    pub fn wheel_torque_nm(&self, engine_torque_nm: f64) -> f64 {
        engine_torque_nm * self.total_ratio() * self.efficiency
    }

    pub fn engine_rpm_from_wheel_speed(&self, wheel_speed_m_s: f64, wheel_radius_m: f64) -> f64 {
        let wheel_rad_s = wheel_speed_m_s / wheel_radius_m;
        let engine_rad_s = wheel_rad_s * self.total_ratio();
        engine_rad_s * (60.0 / (2.0 * std::f64::consts::PI))
    }
}
