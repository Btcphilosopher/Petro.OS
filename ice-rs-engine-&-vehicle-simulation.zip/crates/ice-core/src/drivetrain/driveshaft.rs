#[derive(Debug, Clone)]
pub struct Driveshaft {
    pub stiffness: f64,
}
