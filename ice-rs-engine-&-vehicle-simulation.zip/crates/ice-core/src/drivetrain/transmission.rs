#[derive(Debug, Clone)]
pub struct Transmission {
    pub ratios: Vec<f64>,
    pub selected_gear: usize,
}
