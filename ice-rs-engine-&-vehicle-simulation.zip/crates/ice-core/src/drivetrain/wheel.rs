#[derive(Debug, Clone)]
pub struct Wheel {
    pub radius_m: f64,
}
