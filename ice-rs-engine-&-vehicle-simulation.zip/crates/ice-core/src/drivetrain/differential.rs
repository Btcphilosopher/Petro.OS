#[derive(Debug, Clone)]
pub struct Differential {
    pub ratio: f64,
}
