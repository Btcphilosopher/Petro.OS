#[derive(Debug, Clone)]
pub struct Clutch {
    pub engagement: f64, // 0.0 disengaged to 1.0 engaged
    pub max_torque_nm: f64,
}
