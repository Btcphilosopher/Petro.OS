//! # ICE-Core: Computational Physics Kernel for ICE-RS
//!
//! Provides slider-crank kinematics, Wiebe combustion, thermodynamic pressure resolution,
//! crankshaft rotational dynamics, lumped thermal systems, drivetrain, and vehicle dynamics.

pub mod engine;
pub mod thermal;
pub mod drivetrain;
pub mod vehicle;
pub mod control;
pub mod simulation;
pub mod telemetry;

pub use engine::geometry::SliderCrankGeometry;
pub use engine::engine::Engine;
pub use simulation::simulator::Simulator;
