#[derive(Debug, Clone)]
pub struct FixedTimestep {
    pub dt_s: f64,
}
