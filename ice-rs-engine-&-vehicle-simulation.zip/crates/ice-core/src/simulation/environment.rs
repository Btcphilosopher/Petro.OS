#[derive(Debug, Clone)]
pub struct AmbientEnvironment {
    pub temperature_c: f64,
    pub pressure_pa: f64,
    pub air_density_kg_m3: f64,
}

impl Default for AmbientEnvironment {
    fn default() -> Self {
        Self {
            temperature_c: 20.0,
            pressure_pa: 101325.0,
            air_density_kg_m3: 1.204,
        }
    }
}
