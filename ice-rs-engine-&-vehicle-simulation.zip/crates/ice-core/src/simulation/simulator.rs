use crate::engine::engine::Engine;
use crate::engine::engine_state::EngineState;
use crate::drivetrain::Drivetrain;
use crate::vehicle::Vehicle;
use crate::control::ECU;

#[derive(Debug, Clone)]
pub struct Simulator {
    pub engine: Engine,
    pub drivetrain: Drivetrain,
    pub vehicle: Vehicle,
    pub ecu: ECU,
    pub current_time_s: f64,
    pub fixed_dt_s: f64,
    pub step_count: u64,
}

impl Simulator {
    pub fn new(fixed_dt_s: f64) -> Self {
        Self {
            engine: Engine::new_v8_5l(),
            drivetrain: Drivetrain::default(),
            vehicle: Vehicle::default(),
            ecu: ECU::default(),
            current_time_s: 0.0,
            fixed_dt_s,
            step_count: 0,
        }
    }

    pub fn step(&mut self, driver_throttle: f64) -> EngineState {
        let (ecu_throttle, _rev_limit) = self.ecu.process(self.engine.crankshaft.rpm(), driver_throttle, self.engine.coolant_temp_c);

        // Load torque from vehicle speed & gear
        let wheel_speed = self.vehicle.velocity_m_s / self.vehicle.wheel_radius_m;
        let load_torque = 15.0 + (wheel_speed * 0.8) + (driver_throttle * 5.0);

        let mut state = self.engine.step(ecu_throttle, load_torque, self.fixed_dt_s);

        // Update drivetrain and vehicle dynamics
        let wheel_torque = self.drivetrain.wheel_torque_nm(state.net_torque_nm.max(0.0));
        self.vehicle.step(wheel_torque, 1.204, self.fixed_dt_s);

        self.current_time_s += self.fixed_dt_s;
        self.step_count += 1;
        state.time_s = self.current_time_s;

        state
    }
}
