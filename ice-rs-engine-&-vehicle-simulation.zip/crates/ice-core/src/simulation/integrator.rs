#[derive(Debug, Clone, Copy)]
pub enum IntegratorMethod {
    ForwardEuler,
    SemiImplicitEuler,
    RK4,
}
