#[derive(Debug, Clone)]
pub struct SimulationClock {
    pub time_s: f64,
}
