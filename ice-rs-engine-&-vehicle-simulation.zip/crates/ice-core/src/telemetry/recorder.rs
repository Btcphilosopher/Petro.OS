use super::signals::TelemetrySample;

#[derive(Debug, Clone, Default)]
pub struct TelemetryRecorder {
    pub samples: Vec<TelemetrySample>,
}

impl TelemetryRecorder {
    pub fn record(&mut self, sample: TelemetrySample) {
        self.samples.push(sample);
    }

    pub fn clear(&mut self) {
        self.samples.clear();
    }
}
