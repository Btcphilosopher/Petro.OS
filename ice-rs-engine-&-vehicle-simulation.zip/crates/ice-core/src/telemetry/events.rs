#[derive(Debug, Clone)]
pub enum SimulationEvent {
    CylinderFired { cylinder_id: usize, crank_angle_deg: f64, pressure_pa: f64 },
    GearShift { from_gear: usize, to_gear: usize },
    RevLimiterTriggered { rpm: f64 },
    CoolantWarning { temp_c: f64 },
}
