#[derive(Debug, Clone)]
pub struct TelemetrySample {
    pub time_s: f64,
    pub rpm: f64,
    pub torque_nm: f64,
    pub power_hp: f64,
    pub manifold_pressure_kpa: f64,
    pub vehicle_speed_kmh: f64,
    pub coolant_temp_c: f64,
    pub bsfc_g_kwh: f64,
}
