#[derive(Debug, Clone, Default)]
pub struct ExhaustResonancePipe {
    pub fundamental_hz: f64,
}
