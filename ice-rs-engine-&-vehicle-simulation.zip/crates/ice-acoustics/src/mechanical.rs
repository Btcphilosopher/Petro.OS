#[derive(Debug, Clone, Default)]
pub struct MechanicalNoise {
    pub valve_clatter: f64,
}
