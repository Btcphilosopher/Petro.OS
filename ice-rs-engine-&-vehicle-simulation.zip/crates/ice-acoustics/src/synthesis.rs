#[derive(Debug, Clone)]
pub struct AcousticSynthesizer {
    pub sample_rate_hz: u32,
    pub firing_frequency_hz: f64,
}

impl Default for AcousticSynthesizer {
    fn default() -> Self {
        Self {
            sample_rate_hz: 44100,
            firing_frequency_hz: 50.0,
        }
    }
}

impl AcousticSynthesizer {
    pub fn update(&mut self, rpm: f64, cylinders: usize) {
        // Firing frequency f = (RPM / 60) * (cylinders / 2)
        self.firing_frequency_hz = (rpm / 60.0) * (cylinders as f64 / 2.0);
    }

    pub fn generate_frame(&self, time_s: f64, load: f64) -> f64 {
        let f0 = self.firing_frequency_hz;
        let p1 = (2.0 * std::f64::consts::PI * f0 * time_s).sin();
        let p2 = 0.5 * (2.0 * std::f64::consts::PI * f0 * 2.0 * time_s).sin();
        let p3 = 0.25 * (2.0 * std::f64::consts::PI * f0 * 4.0 * time_s).sin();

        (p1 + p2 + p3) * (0.3 + 0.7 * load)
    }
}
