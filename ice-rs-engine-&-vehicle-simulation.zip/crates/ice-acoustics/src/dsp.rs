#[derive(Debug, Clone)]
pub struct BiquadFilter {
    pub cutoff_hz: f64,
}
