pub mod combustion;
pub mod exhaust;
pub mod intake;
pub mod mechanical;
pub mod resonance;
pub mod synthesis;
pub mod dsp;

pub use synthesis::AcousticSynthesizer;
