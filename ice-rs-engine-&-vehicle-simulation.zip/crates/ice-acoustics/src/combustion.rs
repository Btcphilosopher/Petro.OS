#[derive(Debug, Clone, Default)]
pub struct CombustionAcousticPulse {
    pub energy: f64,
}
