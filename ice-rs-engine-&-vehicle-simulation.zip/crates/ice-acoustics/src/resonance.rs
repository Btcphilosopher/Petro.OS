#[derive(Debug, Clone, Default)]
pub struct ResonatorBank {
    pub frequencies: Vec<f64>,
}
