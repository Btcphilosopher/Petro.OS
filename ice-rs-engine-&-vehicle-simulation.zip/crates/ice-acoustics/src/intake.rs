#[derive(Debug, Clone, Default)]
pub struct IntakeInductionSound {
    pub throttle_rumble: f64,
}
