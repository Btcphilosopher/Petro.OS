#[derive(Debug, Clone)]
pub struct MonteCarloExperiment {
    pub seed: u64,
    pub iterations: usize,
}
