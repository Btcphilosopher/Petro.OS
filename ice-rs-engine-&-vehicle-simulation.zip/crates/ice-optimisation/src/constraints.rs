pub struct OptimizationConstraints {
    pub max_rpm: f64,
    pub max_temp_c: f64,
    pub min_afr: f64,
}
