#[derive(Debug, Clone)]
pub struct SweepCandidate {
    pub compression_ratio: f64,
    pub ignition_timing_deg: f64,
    pub peak_power_hp: f64,
    pub min_bsfc_g_kwh: f64,
}

pub struct ParameterSweepEngine;

impl ParameterSweepEngine {
    pub fn generate_grid(cr_min: f64, cr_max: f64, steps: usize) -> Vec<f64> {
        let step_size = (cr_max - cr_min) / (steps.max(1) as f64);
        (0..=steps).map(|i| cr_min + (i as f64) * step_size).collect()
    }
}
