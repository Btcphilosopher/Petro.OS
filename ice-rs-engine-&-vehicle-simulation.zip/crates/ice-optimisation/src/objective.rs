pub struct ObjectiveWeights {
    pub power_weight: f64,
    pub bsfc_weight: f64,
    pub thermal_weight: f64,
}

impl ObjectiveWeights {
    pub fn evaluate(&self, power_hp: f64, bsfc_g_kwh: f64, temp_c: f64) -> f64 {
        self.power_weight * (power_hp / 500.0)
            - self.bsfc_weight * (bsfc_g_kwh / 300.0)
            - self.thermal_weight * (temp_c / 100.0)
    }
}
