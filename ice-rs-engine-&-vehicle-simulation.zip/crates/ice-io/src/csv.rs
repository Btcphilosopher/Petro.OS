pub struct CsvExporter;

impl CsvExporter {
    pub fn format_row(time: f64, rpm: f64, torque: f64, power_hp: f64) -> String {
        format!("{:.4},{:.1},{:.1},{:.1}", time, rpm, torque, power_hp)
    }
}
