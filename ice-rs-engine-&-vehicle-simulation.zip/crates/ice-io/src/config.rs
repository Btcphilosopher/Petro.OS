use serde::Deserialize;

#[derive(Debug, Clone, Deserialize)]
pub struct EngineTomlConfig {
    pub engine: EngineSection,
}

#[derive(Debug, Clone, Deserialize)]
pub struct EngineSection {
    pub name: String,
    pub architecture: String,
    pub cylinders: usize,
    pub displacement_l: f64,
    pub bore_m: f64,
    pub stroke_m: f64,
    pub compression_ratio: f64,
}

pub struct EngineConfigParser;

impl EngineConfigParser {
    pub fn parse_toml(content: &str) -> Result<EngineTomlConfig, toml::de::Error> {
        toml::from_str(content)
    }
}
