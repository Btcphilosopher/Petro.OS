pub struct ParquetTelemetryWriter;

impl ParquetTelemetryWriter {
    pub fn schema_columns() -> Vec<&'static str> {
        vec!["time_s", "rpm", "torque_nm", "power_hp", "manifold_pa", "vehicle_speed_kmh"]
    }
}
