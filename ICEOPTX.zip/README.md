# ICEOPT-X

**A physics-first internal combustion engine performance, efficiency and
thermal optimisation engine.**

> Given an internal combustion engine, its fuel, its thermal state and
> its required output, what operating conditions extract the maximum
> useful work from every unit of fuel?

ICEOPT-X is not a vehicle simulator. It is an engineering optimisation
platform: given a configured engine (geometry, fuel, constraints), it
computes the complete, traceable physics chain from fuel input to brake
power, thermal losses, and exhaust energy, and searches operating
conditions (AFR, ignition/injection timing, boost, intake/coolant
temperature) for the best result under explicit, never-violated
constraints.

Supports petrol, diesel, natural-gas, hydrogen, ethanol, methanol and
synthetic-fuel spark- and compression-ignition engines, naturally
aspirated or turbocharged, two- or four-stroke.

## Quick start

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
pytest iceopt_x/tests -q                       # 73 tests: conservation, combustion,
                                                 # airflow, friction, thermal, turbo,
                                                 # optimisation convergence, constraints
python examples/run_demo.py                     # a walk through every major capability
uvicorn iceopt_x.dashboard.app:app --reload     # the engineering command centre, http://127.0.0.1:8000/
```

## The core chain (Section 1/31)

```
FUEL -> AIR INTAKE -> COMPRESSION -> COMBUSTION -> EXPANSION -> EXHAUST
     -> TURBO / HEAT RECOVERY -> USEFUL MECHANICAL POWER -> GENERATOR/TRANSMISSION
```

`core.engine.Engine.evaluate(operating_point)` walks this chain exactly
once, in exactly one place, for every optimiser in the codebase:

```
INPUTS -> AIRFLOW -> MIXTURE -> COMBUSTION -> THERMODYNAMIC WORK ->
MECHANICAL LOSSES -> BRAKE OUTPUT -> EXHAUST / THERMAL -> EXERGY ->
EFFICIENCY -> CONSTRAINT CHECK
```

The returned `EvaluationResult` carries every intermediate quantity
(airflow, mixture, combustion trace, mechanical loss breakdown, thermal
balance, exergy breakdown, energy balance, efficiency summary,
constraint violations) so a result can always be traced back to its
inputs -- nothing is computed twice, and nothing is hidden behind a
single "magic efficiency" number.

## Project layout

```
iceopt_x/
├── core/            engine orchestrator, simulation/map generation, real-time loop, events
├── engine/          geometry, displacement, kinematics, compression, degradation
├── intake/          airflow, manifold, throttle, turbocharger, intercooler, VE
├── combustion/      fuel database, AFR, ignition/injection timing, Wiebe burn rate, combustion efficiency
├── thermodynamics/  crank-resolved closed-cycle simulation (P-V/T-S), exergy, energy balance
├── exhaust/         exhaust flow/temperature/backpressure, heat recovery
├── thermal/         wall heat transfer split, cooling, oil viscosity, thermal state
├── mechanical/      Chen-Flynn friction, bearings, crankshaft, mechanical loss breakdown
├── optimisation/    global optimiser, Pareto frontier, marginal-gain ranking, scenarios, constraint engine
├── dashboard/       FastAPI backend + static live dashboard
└── tests/           73 tests: conservation, combustion, airflow, friction, thermal, turbo, optimisation, constraints, regression
```

## Combustion model sophistication (Section 8)

ICEOPT-X implements **LEVEL 2: finite-rate heat release** via the Wiebe
function integrated crank-angle-by-crank-angle through a first-law
energy balance (`thermodynamics/cycle.py`), including Woschni in-cylinder
wall heat transfer in the same integration -- not LEVEL 1 (instantaneous
idealised combustion) and explicitly not a claim of LEVEL 3/4 (CFD or
experimentally-calibrated) accuracy. Every function that returns a
number is labelled in its docstring as one of:

- **PHYSICS MODEL** -- an exact or near-exact physical relation (ideal
  gas law, crank-slider kinematics, conservation of mass/energy).
- **EMPIRICAL MODEL** -- a published engineering correlation (Woschni
  heat transfer, Chen-Flynn friction, Wiebe combustion shape,
  compressor/turbine efficiency maps) calibrated against a broad range
  of engines, not this specific one.
- **CALIBRATION DATA** -- illustrative representative values (fuel
  properties, scenario ambient conditions, friction breakdown fractions)
  that should be replaced with measured data for a specific engine.
- **ASSUMPTION** -- an explicit simplification, stated inline, made to
  keep the model tractable at engineering scale.

## Validation philosophy (Section 31)

Every `EvaluationResult` is the single source of truth: the dashboard,
the optimisers, the marginal-gain engine, and the test suite all read
from the same `Engine.evaluate()` chain, so there is no separate
"reporting" path that could silently disagree with the "optimisation"
path.

**On energy balance closure**: ICEOPT-X assembles brake power, wall heat
loss, and exhaust energy from several independently-published
correlations (Woschni, Chen-Flynn, a compressor/turbine shaft power
balance) rather than one jointly-fitted model. The wall heat loss used
in the thermal balance is taken directly from the same crank-resolved
combustion cycle that produces the indicated work, so those two numbers
are exactly consistent by construction. The exhaust energy term is
computed independently (it is what is actually useful for turbocharger
and heat-recovery sizing) and is **not** forced to close the ledger
artificially -- `EnergyBalance.residual_fraction` is reported honestly
and the test suite asserts it stays within an explicit ~20% engineering
tolerance, not zero. A tighter closure is a natural LEVEL 3/4 upgrade
(joint calibration against dyno data) rather than something to fake with
an extra fudge term.

**On exhaust gas temperature**: the model estimates exhaust manifold
temperature from the crank-resolved closed-cycle end-of-expansion state
(an energy-conservative "stagnation-equivalent" temperature) rather than
an isentropic pressure-ratio scaling to manifold pressure, which would
fictitiously convert pressure drop into "work" that was never delivered
to the piston. This can run hotter than a real EGT thermocouple, which
also sees real heat losses this simplified single-zone model does not
resolve -- an explicit, disclosed simplification, not a hidden one. The
constraint engine's exhaust temperature limit is deliberately active
here as a guardrail on realistic operating envelopes.

## Marginal-gain engine (Section 23)

`optimisation.marginal_gain.rank_marginal_gains()` answers "what single
change would produce the largest improvement?" by applying seven
concrete, physically wired perturbations -- +1% volumetric efficiency,
+1% combustion efficiency, +1% compressor efficiency, +1% turbine
efficiency, -1°C intake temperature, -1% friction, +1% heat recovery
effectiveness -- through `EngineModel.calibration_multipliers`, which
are read at exactly the point in `core.engine.Engine.evaluate()` where
each physical quantity is computed, then ranks the resulting change in
brake efficiency (or any other KPI).

## What this is not

- Not a transient/driving-cycle vehicle simulator (Section 1).
- Not a CFD or chemical-kinetics combustion solver -- the finite-rate
  heat release model is a widely used engineering approximation
  (Section 8's explicit LEVEL 2/3/4 ladder).
- Not calibrated to any single real engine's dyno data -- fuel
  properties, friction/heat-transfer correlations and scenario
  conditions are representative literature values; swap in measured
  data via `EngineModel` for a production analysis.

## License

MIT.
