#!/usr/bin/env python3
"""
ICEOPT-X end-to-end demo: walks through every major capability of the
engine on a representative 2.0L turbocharged petrol engine and a 2.2L
turbocharged diesel engine. Run with:

    python examples/run_demo.py
"""
from __future__ import annotations

from iceopt_x.combustion.fuel import FuelType
from iceopt_x.core.engine import Engine
from iceopt_x.core.generator import find_optimal_generator_setpoint
from iceopt_x.core.simulation import DEFAULT_MAP_AXES, generate_engine_map, pivot_map
from iceopt_x.core.state import AmbientConditions, OperatingPoint, ThermalState
from iceopt_x.engine.degradation import degrade_engine_model
from iceopt_x.engine.engine_model import EngineModel, default_geometry_2p0l_turbo_petrol
from iceopt_x.engine.geometry import summarise
from iceopt_x.optimisation.marginal_gain import rank_marginal_gains
from iceopt_x.optimisation.optimizer import GlobalOptimizer
from iceopt_x.optimisation.pareto import build_pareto_frontier
from iceopt_x.optimisation.scenarios import Scenario, build_scenario


def section(title: str) -> None:
    print(f"\n{'=' * 78}\n{title}\n{'=' * 78}")


def main() -> None:
    model = EngineModel.from_fuel_type("Demo 2.0L Turbo Petrol", default_geometry_2p0l_turbo_petrol(), FuelType.PETROL)
    engine = Engine(model)

    section("1. GEOMETRY (Section 5)")
    g = summarise(model.geometry)
    print(f"Displacement: {g.total_displacement_cc:.0f} cc, bore/stroke ratio: {g.bore_stroke_ratio:.3f}")

    section("2. SINGLE OPERATING POINT -- FULL TRACEABLE CHAIN (Section 31)")
    op = OperatingPoint(rpm=3500, load_fraction=0.6, boost_pressure_kpa=60.0, lambda_target=1.0, ignition_timing_btdc_deg=16.0)
    r = engine.evaluate(op, AmbientConditions(), ThermalState())
    print(f"Brake power:        {r.brake_power_kw:6.1f} kW")
    print(f"Brake torque:       {r.brake_torque_nm:6.1f} Nm")
    print(f"BSFC:               {r.efficiency.bsfc_g_per_kwh:6.1f} g/kWh")
    print(f"Brake efficiency:   {r.efficiency.brake_thermal_efficiency * 100:6.1f} %")
    print(f"Peak cyl. pressure: {r.combustion.peak_cylinder_pressure_bar:6.1f} bar")
    print(f"Exhaust temp:       {r.exhaust_temperature_k - 273.15:6.1f} degC")
    print(f"Feasible:           {r.is_feasible}")
    if not r.is_feasible:
        print("  -> constraint engine (Section 25) rejects this point:", [str(v) for v in r.constraint_violations])
    print("Exergy breakdown:  ", {k: round(v, 1) for k, v in r.exergy.as_percentages().items()})

    section("3. GLOBAL OPTIMISATION (Section 21)")
    print("(the hand-picked point above is infeasible -- watch the optimiser back off boost/lambda/timing")
    print(" to find the best *feasible* efficiency instead, exactly what Section 25 requires)")
    optimizer = GlobalOptimizer(engine)
    opt = optimizer.optimize(rpm=3500, load_fraction=0.6, objective="brake_thermal_efficiency", maxiter=40, popsize=14)
    print(f"Optimised brake efficiency: {opt.objective_value * 100:.2f}% (feasible={opt.evaluation.is_feasible})")
    print(f"Optimal variables: { {k: round(v, 3) for k, v in opt.variables.items()} }")

    section("4. MARGINAL-GAIN RANKING (Section 23)")
    for i, gain in enumerate(rank_marginal_gains(engine, op), start=1):
        print(f"{i}. {gain.description:38s} -> {gain.delta_percentage_points:+.4f} pp")

    section("5. MULTI-OBJECTIVE PARETO FRONTIER (Section 22)")
    frontier = build_pareto_frontier(engine, rpm=3500, load_fraction=0.6, objectives=["power_kw", "brake_thermal_efficiency"], n_lambda=5, n_timing=5, n_boost=3)
    for p in sorted(frontier, key=lambda x: x.objectives["power_kw"]):
        print(f"  power={p.objectives['power_kw']:6.1f} kW   efficiency={p.objectives['brake_thermal_efficiency']*100:5.1f} %")

    section("6. PERFORMANCE MAP (Section 20)")
    df = generate_engine_map(engine, DEFAULT_MAP_AXES)
    print(pivot_map(df, "brake_thermal_efficiency").round(3))

    section("7. SCENARIO COMPARISON (Section 27)")
    for scenario in [Scenario.COLD_START, Scenario.HOT_WEATHER, Scenario.HIGH_ALTITUDE, Scenario.STEADY_CRUISE]:
        ctx = build_scenario(scenario)
        scenario_op = OperatingPoint(rpm=ctx.rpm_hint, load_fraction=ctx.load_fraction_hint, boost_pressure_kpa=30.0)
        sr = engine.evaluate(scenario_op, ctx.ambient, ctx.thermal_state)
        print(f"{scenario.value:22s} eff={sr.efficiency.brake_thermal_efficiency*100:5.1f}%  power={sr.brake_power_kw:6.1f} kW  ({ctx.notes})")

    section("8. ENGINE-AS-GENERATOR MODE (Section 28)")
    gen = find_optimal_generator_setpoint(engine, target_electrical_kw=40.0, rpm_candidates=[1800, 2200, 2600])
    print(f"Best RPM: {gen.rpm:.0f}, load: {gen.load_fraction*100:.0f}%")
    print(f"Electrical power: {gen.electrical_power_kw:.1f} kW, thermal recovery: {gen.thermal_recovery_kw:.1f} kW")
    print(f"Electrical efficiency: {gen.electrical_efficiency*100:.1f}%, total useful efficiency: {gen.total_useful_efficiency*100:.1f}%")

    section("9. DEGRADATION (Section 26)")
    aged_model = degrade_engine_model(model, operating_hours=8000.0)
    aged_engine = Engine(aged_model)
    aged_r = aged_engine.evaluate(op, AmbientConditions(), ThermalState())
    print(f"Fresh engine brake efficiency: {r.efficiency.brake_thermal_efficiency*100:.2f}%")
    print(f"8000h-aged brake efficiency:   {aged_r.efficiency.brake_thermal_efficiency*100:.2f}%")

    print("\nDone. Run `uvicorn iceopt_x.dashboard.app:app --reload` for the live dashboard.")


if __name__ == "__main__":
    main()
