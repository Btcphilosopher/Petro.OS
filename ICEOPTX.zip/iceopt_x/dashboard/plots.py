"""
dashboard.plots
=================

Matplotlib/Plotly figure generation for the engineering command centre
(Section 30/12/20): P-V diagram, T-S diagram, and heatmap-style
performance maps.
"""
from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import plotly.graph_objects as go

from iceopt_x.core.engine import EvaluationResult
from iceopt_x.core.simulation import pivot_map


def pv_diagram_figure(result: EvaluationResult):
    v, p = result.combustion.cycle.pv_diagram_xy()
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.plot(v * 1.0e6, p, color="#c1440e", linewidth=1.6)
    ax.set_xlabel("Cylinder volume [cm^3]")
    ax.set_ylabel("Cylinder pressure [bar]")
    ax.set_title("P-V diagram (single cylinder, IVC-EVO)")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    return fig


def ts_diagram_figure(result: EvaluationResult):
    s, t = result.combustion.cycle.ts_diagram_xy()
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.plot(s, t, color="#1f6f8b", linewidth=1.6)
    ax.set_xlabel("Relative entropy [J/K]")
    ax.set_ylabel("Cylinder gas temperature [K]")
    ax.set_title("T-S diagram (single cylinder, IVC-EVO)")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    return fig


def map_heatmap_plotly(df, value_col: str, title: str, colorscale: str = "Inferno") -> go.Figure:
    """Section 20: an interactive RPM x load performance-map heatmap."""
    table = pivot_map(df, value_col)
    fig = go.Figure(
        data=go.Heatmap(
            z=table.values,
            x=[f"{int(r)}" for r in table.columns],
            y=[f"{int(l*100)}%" for l in table.index],
            colorscale=colorscale,
            colorbar=dict(title=value_col),
        )
    )
    fig.update_layout(
        title=title,
        xaxis_title="RPM",
        yaxis_title="Load",
        template="plotly_white",
        height=420,
    )
    return fig


def pareto_frontier_figure(frontier, x_key: str, y_key: str):
    fig, ax = plt.subplots(figsize=(6, 5))
    xs = [p.objectives[x_key] for p in frontier]
    ys = [p.objectives[y_key] for p in frontier]
    ax.scatter(xs, ys, color="#2a6f4e")
    ax.set_xlabel(x_key)
    ax.set_ylabel(y_key)
    ax.set_title("Pareto frontier")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    return fig
