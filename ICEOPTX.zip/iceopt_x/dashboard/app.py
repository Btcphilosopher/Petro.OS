"""
dashboard.app
==============

ICEOPT-X engineering command centre (Section 30) -- a FastAPI backend
serving:

    /engine/evaluate        one operating point, full traceable chain
    /engine/map              a RPM x load performance map (JSON records)
    /engine/pv               P-V diagram data for one operating point
    /engine/ts               T-S diagram data for one operating point
    /optimise                global optimisation result
    /optimise/pareto         multi-objective Pareto frontier
    /optimise/marginal-gain  marginal-gain ranking
    /exergy                  exergy breakdown for one operating point
    /scenarios                list of standard scenarios + a quick evaluation
    /generator/optimise       engine-as-generator optimal setpoint

Run with:  uvicorn iceopt_x.dashboard.app:app --reload
Then open http://127.0.0.1:8000/ for the live static dashboard, or
http://127.0.0.1:8000/docs for interactive API docs.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from iceopt_x.combustion.fuel import FuelType
from iceopt_x.core.engine import Engine
from iceopt_x.core.simulation import DEFAULT_MAP_AXES, MapAxes, generate_engine_map
from iceopt_x.core.state import AmbientConditions, OperatingPoint, ThermalState
from iceopt_x.engine.engine_model import (
    EngineModel,
    default_geometry_2p0l_turbo_petrol,
    default_geometry_2p2l_diesel,
)
from iceopt_x.optimisation.marginal_gain import rank_marginal_gains
from iceopt_x.optimisation.optimizer import GlobalOptimizer
from iceopt_x.optimisation.pareto import build_pareto_frontier
from iceopt_x.optimisation.scenarios import Scenario, build_scenario

app = FastAPI(title="ICEOPT-X", description="Internal combustion engine performance optimisation engine")

_STATIC_DIR = Path(__file__).parent / "static"
if _STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(_STATIC_DIR)), name="static")

_ENGINES: dict[str, Engine] = {
    "petrol_2.0T": Engine(EngineModel.from_fuel_type("Petrol 2.0T", default_geometry_2p0l_turbo_petrol(), FuelType.PETROL)),
    "diesel_2.2": Engine(EngineModel.from_fuel_type("Diesel 2.2", default_geometry_2p2l_diesel(), FuelType.DIESEL)),
}


def _get_engine(engine_id: str) -> Engine:
    if engine_id not in _ENGINES:
        raise HTTPException(404, f"Unknown engine_id '{engine_id}'. Available: {list(_ENGINES)}")
    return _ENGINES[engine_id]


class OperatingPointRequest(BaseModel):
    engine_id: str = "petrol_2.0T"
    rpm: float = 3500
    load_fraction: float = 0.6
    boost_pressure_kpa: float = 60.0
    lambda_target: float = 1.0
    ignition_timing_btdc_deg: float = 16.0
    injection_timing_btdc_deg: float = 10.0
    intake_temperature_k: float = 313.15
    coolant_temperature_k: float = 363.15
    oil_temperature_k: float = 363.15
    ambient_pressure_kpa: float = 101.325
    ambient_temperature_k: float = 298.15


def _build(req: OperatingPointRequest) -> tuple[Engine, OperatingPoint, AmbientConditions, ThermalState]:
    engine = _get_engine(req.engine_id)
    op = OperatingPoint(
        rpm=req.rpm,
        load_fraction=req.load_fraction,
        boost_pressure_kpa=req.boost_pressure_kpa,
        lambda_target=req.lambda_target,
        ignition_timing_btdc_deg=req.ignition_timing_btdc_deg,
        injection_timing_btdc_deg=req.injection_timing_btdc_deg,
        intake_temperature_k=req.intake_temperature_k,
        coolant_temperature_k=req.coolant_temperature_k,
        oil_temperature_k=req.oil_temperature_k,
    )
    ambient = AmbientConditions(pressure_kpa=req.ambient_pressure_kpa, temperature_k=req.ambient_temperature_k)
    thermal = ThermalState(coolant_temp_k=req.coolant_temperature_k, oil_temp_k=req.oil_temperature_k)
    return engine, op, ambient, thermal


@app.get("/", response_class=HTMLResponse)
def index() -> str:
    index_file = _STATIC_DIR / "index.html"
    if index_file.exists():
        return index_file.read_text()
    return "<h1>ICEOPT-X</h1><p>Static dashboard not found -- see /docs for the API.</p>"


@app.get("/engines")
def list_engines():
    return {name: {"combustion_type": e.model.geometry.combustion_type.value, "fuel": e.model.fuel.name} for name, e in _ENGINES.items()}


@app.post("/engine/evaluate")
def evaluate(req: OperatingPointRequest):
    engine, op, ambient, thermal = _build(req)
    r = engine.evaluate(op, ambient, thermal)
    return {
        "rpm": r.inputs.rpm,
        "load_fraction": r.inputs.load_fraction,
        "torque_nm": r.brake_torque_nm,
        "power_kw": r.brake_power_kw,
        "fuel_flow_kg_h": r.mixture.fuel_mass_flow_kg_h,
        "bsfc_g_per_kwh": r.efficiency.bsfc_g_per_kwh,
        "brake_thermal_efficiency": r.efficiency.brake_thermal_efficiency,
        "indicated_thermal_efficiency": r.efficiency.indicated_thermal_efficiency,
        "mechanical_efficiency": r.efficiency.mechanical_efficiency,
        "volumetric_efficiency": r.efficiency.volumetric_efficiency,
        "combustion_efficiency": r.efficiency.combustion_efficiency,
        "boost_pressure_kpa": r.inputs.boost_pressure_kpa,
        "peak_cylinder_pressure_bar": r.combustion.peak_cylinder_pressure_bar,
        "peak_cylinder_temp_k": r.combustion.peak_temperature_k,
        "exhaust_temperature_k": r.exhaust_temperature_k,
        "coolant_temperature_k": r.thermal_state_in.coolant_temp_k,
        "energy_balance_pct": r.energy_balance.as_percentages(),
        "exergy_pct": r.exergy.as_percentages(),
        "is_feasible": r.is_feasible,
        "violations": [str(v) for v in r.constraint_violations],
    }


@app.post("/engine/pv")
def pv_diagram(req: OperatingPointRequest):
    engine, op, ambient, thermal = _build(req)
    r = engine.evaluate(op, ambient, thermal)
    v, p = r.combustion.cycle.pv_diagram_xy()
    return {"volume_cm3": (v * 1.0e6).tolist(), "pressure_bar": p.tolist()}


@app.post("/engine/ts")
def ts_diagram(req: OperatingPointRequest):
    engine, op, ambient, thermal = _build(req)
    r = engine.evaluate(op, ambient, thermal)
    s, t = r.combustion.cycle.ts_diagram_xy()
    return {"entropy_j_k": s.tolist(), "temperature_k": t.tolist()}


class MapRequest(BaseModel):
    engine_id: str = "petrol_2.0T"
    rpm_values: list[float] = DEFAULT_MAP_AXES.rpm_values
    load_values: list[float] = DEFAULT_MAP_AXES.load_values


@app.post("/engine/map")
def engine_map(req: MapRequest):
    engine = _get_engine(req.engine_id)
    df = generate_engine_map(engine, MapAxes(req.rpm_values, req.load_values))
    return df.to_dict(orient="records")


class OptimiseRequest(BaseModel):
    engine_id: str = "petrol_2.0T"
    rpm: float = 3500
    load_fraction: float = 0.6
    objective: str = "brake_thermal_efficiency"
    maxiter: int = 40
    popsize: int = 12


@app.post("/optimise")
def optimise(req: OptimiseRequest):
    engine = _get_engine(req.engine_id)
    optimizer = GlobalOptimizer(engine)
    result = optimizer.optimize(req.rpm, req.load_fraction, req.objective, maxiter=req.maxiter, popsize=req.popsize)
    return {
        "objective": result.objective_name,
        "objective_value": result.objective_value,
        "variables": result.variables,
        "brake_power_kw": result.evaluation.brake_power_kw,
        "brake_thermal_efficiency": result.evaluation.efficiency.brake_thermal_efficiency,
        "bsfc_g_per_kwh": result.evaluation.efficiency.bsfc_g_per_kwh,
        "n_evaluations": result.n_evaluations,
        "converged": result.converged,
        "is_feasible": result.evaluation.is_feasible,
    }


class ParetoRequest(BaseModel):
    engine_id: str = "petrol_2.0T"
    rpm: float = 3500
    load_fraction: float = 0.6
    objectives: list[str] = ["power_kw", "brake_thermal_efficiency"]


@app.post("/optimise/pareto")
def pareto(req: ParetoRequest):
    engine = _get_engine(req.engine_id)
    frontier = build_pareto_frontier(engine, req.rpm, req.load_fraction, req.objectives, n_lambda=5, n_timing=5, n_boost=3)
    return [p.objectives for p in frontier]


@app.post("/optimise/marginal-gain")
def marginal_gain(req: OperatingPointRequest):
    engine, op, ambient, thermal = _build(req)
    ranking = rank_marginal_gains(engine, op, ambient, thermal)
    return [
        {
            "intervention": r.intervention,
            "description": r.description,
            "delta_percentage_points": r.delta_percentage_points,
        }
        for r in ranking
    ]


@app.get("/scenarios")
def scenarios():
    return {
        s.value: {
            "rpm_hint": build_scenario(s).rpm_hint,
            "load_fraction_hint": build_scenario(s).load_fraction_hint,
            "notes": build_scenario(s).notes,
        }
        for s in Scenario
    }
