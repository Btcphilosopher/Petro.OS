"""
combustion.combustion_efficiency
==================================

Fraction of the fuel's chemical energy actually released as heat
(Section 8/10). Real combustion is never 100% complete: some fuel exits
as CO, unburned hydrocarbons, soot (rich) or fails to find an ignition
source in time (very lean / near flame-out).

EMPIRICAL MODEL: a smooth penalty curve centred on lambda ~ 1.0 (SI) or
tuned rich/lean bounds (CI, H2), built from published combustion
efficiency trends (Heywood Ch.3/9). Not a substitute for engine-specific
emissions-bench calibration (LEVEL 3/4 upgrade path).
"""
from __future__ import annotations

import numpy as np


def combustion_efficiency(lambda_value: float, is_compression_ignition: bool = False) -> float:
    """Returns combustion efficiency in [0, 1]."""
    if is_compression_ignition:
        # Diesel: efficiency high across a wide lean range, falls off only
        # when running very rich (soot-limited, lambda -> ~1.1-1.2 min in practice)
        if lambda_value >= 1.05:
            eta = 0.995 - 0.01 * max(lambda_value - 3.0, 0.0)
        else:
            deficiency = max(1.05 - lambda_value, 0.0)
            eta = 0.995 - 1.4 * deficiency**1.5
        return float(np.clip(eta, 0.55, 0.995))

    # Spark ignition: peak near stoichiometric/slightly lean, falls off
    # both rich (incomplete oxidation, CO/HC) and very lean (slow/partial
    # burn, misfire risk)
    if lambda_value <= 1.0:
        richness = 1.0 - lambda_value
        eta = 0.99 - 0.55 * richness**1.3
    else:
        leanness = lambda_value - 1.0
        eta = 0.99 - 0.9 * leanness**1.6
    return float(np.clip(eta, 0.35, 0.99))


def hydrogen_combustion_efficiency(lambda_value: float) -> float:
    """Hydrogen burns essentially completely across a very wide lambda
    range (fast flame speed, wide flammability limits) except very close
    to flame-out at high lambda where cycle-to-cycle misfire begins."""
    if lambda_value <= 1.6:
        return float(np.clip(0.995 - 0.01 * max(1.0 - lambda_value, 0.0), 0.9, 0.995))
    leanness = lambda_value - 1.6
    return float(np.clip(0.995 - 0.6 * leanness**1.5, 0.5, 0.995))
