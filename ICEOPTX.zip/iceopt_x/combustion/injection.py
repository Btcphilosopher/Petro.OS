"""
combustion.injection
=====================

Injection timing/duration/pressure model for CI and GDI engines
(Section 11).

PHYSICS MODEL: injection duration from required fuel mass and injector
flow-rate physics (pressure-driven orifice flow).
EMPIRICAL MODEL: ignition-delay correlation (Arrhenius-type, simplified
Hardenberg-Hase-style) used to place start-of-combustion relative to
start-of-injection for CI engines.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class InjectionEvent:
    start_btdc_deg: float
    duration_deg: float
    duration_ms: float
    fuel_mass_kg: float


def injector_mass_flow_rate_kg_s(
    injection_pressure_bar: float,
    chamber_pressure_bar: float,
    discharge_coeff: float,
    orifice_area_m2: float,
    fuel_density_kg_m3: float,
) -> float:
    """Bernoulli orifice flow: m_dot = Cd * A * sqrt(2 * rho * dP)."""
    dp_pa = max(injection_pressure_bar - chamber_pressure_bar, 0.0) * 1.0e5
    return discharge_coeff * orifice_area_m2 * np.sqrt(2.0 * fuel_density_kg_m3 * dp_pa)


def injection_duration_s(fuel_mass_kg: float, injector_mass_flow_kg_s: float) -> float:
    if injector_mass_flow_kg_s <= 0:
        return 0.0
    return fuel_mass_kg / injector_mass_flow_kg_s


def ignition_delay_ms(
    chamber_pressure_bar: float,
    chamber_temperature_k: float,
    cetane_number: float,
) -> float:
    """Simplified Arrhenius-form ignition-delay correlation (structurally
    following Hardenberg & Hase 1979): delay shortens with pressure,
    temperature and cetane number. EMPIRICAL MODEL -- coefficients are
    illustrative, not a specific-fuel calibration."""
    activation_term = 618840.0 / (chamber_temperature_k + 25.0)
    cetane_term = 0.36 + 0.22 * max(cetane_number - 45.0, -20.0) / 45.0
    pressure_term = chamber_pressure_bar**-0.5 * 100.0
    delay_deg_equiv_ms = (activation_term / 1.0e5) * pressure_term * (1.0 - cetane_term * 0.3)
    return float(np.clip(delay_deg_equiv_ms, 0.15, 6.0))


def compute_injection_event(
    fuel_mass_kg: float,
    injection_pressure_bar: float,
    chamber_pressure_bar: float,
    rpm: float,
    start_btdc_deg: float,
    discharge_coeff: float = 0.7,
    orifice_area_m2: float = 3.5e-7,
    fuel_density_kg_m3: float = 832.0,
) -> InjectionEvent:
    m_dot = injector_mass_flow_rate_kg_s(
        injection_pressure_bar, chamber_pressure_bar, discharge_coeff, orifice_area_m2, fuel_density_kg_m3
    )
    duration_s = injection_duration_s(fuel_mass_kg, m_dot)
    deg_per_s = rpm * 6.0  # 360 deg / (60/rpm) s = 6*rpm deg/s
    duration_deg = duration_s * deg_per_s
    return InjectionEvent(
        start_btdc_deg=start_btdc_deg,
        duration_deg=duration_deg,
        duration_ms=duration_s * 1000.0,
        fuel_mass_kg=fuel_mass_kg,
    )
