"""
combustion.fuel
================

Fuel abstraction and property database (Section 9).

CALIBRATION DATA: numeric property values below are literature reference
values (typical published figures for each fuel family: SAE/EPA
handbooks, Heywood "Internal Combustion Engine Fundamentals", NIST
WebBook for pure species). Real fuels vary batch-to-batch; treat these as
representative defaults, override with measured data where available.
"""
from __future__ import annotations

from enum import Enum
from pydantic import BaseModel, Field


class FuelType(str, Enum):
    PETROL = "petrol"
    DIESEL = "diesel"
    NATURAL_GAS = "natural_gas"
    HYDROGEN = "hydrogen"
    ETHANOL = "ethanol"
    METHANOL = "methanol"
    SYNTHETIC_PETROL = "synthetic_petrol"   # e-gasoline / synthetic paraffinic gasoline analogue
    SYNTHETIC_DIESEL = "synthetic_diesel"   # e-diesel / HVO / Fischer-Tropsch diesel


class FuelProperties(BaseModel):
    """Physical/chemical properties needed by the combustion and
    thermodynamic models."""

    name: str
    fuel_type: FuelType
    lower_heating_value_mj_kg: float = Field(gt=0, description="LHV [MJ/kg]")
    higher_heating_value_mj_kg: float = Field(gt=0, description="HHV [MJ/kg]")
    density_kg_m3: float = Field(gt=0, description="Liquid density (or gas density @ NTP for gaseous fuels)")
    stoichiometric_afr: float = Field(gt=0, description="Stoichiometric air:fuel mass ratio")
    specific_heat_kj_kgk: float = Field(gt=0, description="Approx. specific heat of the fuel [kJ/kgK]")
    autoignition_temp_k: float = Field(gt=0)
    laminar_flame_speed_ref_m_s: float = Field(gt=0, description="Reference laminar flame speed @ stoich, 1 atm, 300K")
    carbon_fraction_mass: float = Field(ge=0.0, le=1.0)
    hydrogen_fraction_mass: float = Field(ge=0.0, le=1.0)
    octane_or_cetane: float = Field(gt=0, description="RON for SI fuels, Cetane Number for CI fuels")
    default_combustion_type: str = "spark_ignition"  # or "compression_ignition"
    exergy_factor: float = Field(
        default=1.04,
        gt=0,
        description="Chemical exergy / LHV ratio (~1.04-1.06 for hydrocarbons, ~0.99 for hydrogen, ASSUMPTION where not measured)",
    )

    @property
    def afr_stoich(self) -> float:
        return self.stoichiometric_afr


FUEL_DATABASE: dict[FuelType, FuelProperties] = {
    FuelType.PETROL: FuelProperties(
        name="Petrol (gasoline, EN228/E10 approx.)",
        fuel_type=FuelType.PETROL,
        lower_heating_value_mj_kg=43.4,
        higher_heating_value_mj_kg=46.5,
        density_kg_m3=745.0,
        stoichiometric_afr=14.7,
        specific_heat_kj_kgk=2.22,
        autoignition_temp_k=530.0,
        laminar_flame_speed_ref_m_s=0.33,
        carbon_fraction_mass=0.855,
        hydrogen_fraction_mass=0.145,
        octane_or_cetane=95.0,
        default_combustion_type="spark_ignition",
        exergy_factor=1.03,
    ),
    FuelType.DIESEL: FuelProperties(
        name="Diesel (EN590 approx.)",
        fuel_type=FuelType.DIESEL,
        lower_heating_value_mj_kg=42.8,
        higher_heating_value_mj_kg=45.6,
        density_kg_m3=832.0,
        stoichiometric_afr=14.5,
        specific_heat_kj_kgk=2.05,
        autoignition_temp_k=483.0,
        laminar_flame_speed_ref_m_s=0.30,
        carbon_fraction_mass=0.865,
        hydrogen_fraction_mass=0.135,
        octane_or_cetane=51.0,
        default_combustion_type="compression_ignition",
        exergy_factor=1.06,
    ),
    FuelType.NATURAL_GAS: FuelProperties(
        name="Compressed natural gas (methane surrogate)",
        fuel_type=FuelType.NATURAL_GAS,
        lower_heating_value_mj_kg=50.0,
        higher_heating_value_mj_kg=55.5,
        density_kg_m3=0.72,  # @ NTP, gaseous
        stoichiometric_afr=17.2,
        specific_heat_kj_kgk=2.22,
        autoignition_temp_k=810.0,
        laminar_flame_speed_ref_m_s=0.38,
        carbon_fraction_mass=0.75,
        hydrogen_fraction_mass=0.25,
        octane_or_cetane=120.0,
        default_combustion_type="spark_ignition",
        exergy_factor=1.04,
    ),
    FuelType.HYDROGEN: FuelProperties(
        name="Hydrogen (gaseous)",
        fuel_type=FuelType.HYDROGEN,
        lower_heating_value_mj_kg=120.0,
        higher_heating_value_mj_kg=141.9,
        density_kg_m3=0.0838,  # @ NTP, gaseous
        stoichiometric_afr=34.3,
        specific_heat_kj_kgk=14.3,
        autoignition_temp_k=858.0,
        laminar_flame_speed_ref_m_s=2.0,
        carbon_fraction_mass=0.0,
        hydrogen_fraction_mass=1.0,
        octane_or_cetane=130.0,
        default_combustion_type="spark_ignition",
        exergy_factor=0.985,
    ),
    FuelType.ETHANOL: FuelProperties(
        name="Ethanol (E100)",
        fuel_type=FuelType.ETHANOL,
        lower_heating_value_mj_kg=26.8,
        higher_heating_value_mj_kg=29.7,
        density_kg_m3=789.0,
        stoichiometric_afr=9.0,
        specific_heat_kj_kgk=2.44,
        autoignition_temp_k=636.0,
        laminar_flame_speed_ref_m_s=0.42,
        carbon_fraction_mass=0.522,
        hydrogen_fraction_mass=0.131,
        octane_or_cetane=109.0,
        default_combustion_type="spark_ignition",
        exergy_factor=1.02,
    ),
    FuelType.METHANOL: FuelProperties(
        name="Methanol (M100)",
        fuel_type=FuelType.METHANOL,
        lower_heating_value_mj_kg=19.9,
        higher_heating_value_mj_kg=22.7,
        density_kg_m3=792.0,
        stoichiometric_afr=6.47,
        specific_heat_kj_kgk=2.51,
        autoignition_temp_k=737.0,
        laminar_flame_speed_ref_m_s=0.45,
        carbon_fraction_mass=0.375,
        hydrogen_fraction_mass=0.125,
        octane_or_cetane=107.0,
        default_combustion_type="spark_ignition",
        exergy_factor=1.01,
    ),
    FuelType.SYNTHETIC_PETROL: FuelProperties(
        name="Synthetic petrol (e-gasoline, paraffinic analogue)",
        fuel_type=FuelType.SYNTHETIC_PETROL,
        lower_heating_value_mj_kg=43.0,
        higher_heating_value_mj_kg=46.0,
        density_kg_m3=740.0,
        stoichiometric_afr=14.7,
        specific_heat_kj_kgk=2.20,
        autoignition_temp_k=520.0,
        laminar_flame_speed_ref_m_s=0.34,
        carbon_fraction_mass=0.84,
        hydrogen_fraction_mass=0.16,
        octane_or_cetane=98.0,
        default_combustion_type="spark_ignition",
        exergy_factor=1.03,
    ),
    FuelType.SYNTHETIC_DIESEL: FuelProperties(
        name="Synthetic diesel (e-diesel / HVO / Fischer-Tropsch analogue)",
        fuel_type=FuelType.SYNTHETIC_DIESEL,
        lower_heating_value_mj_kg=44.0,
        higher_heating_value_mj_kg=47.0,
        density_kg_m3=780.0,
        stoichiometric_afr=14.9,
        specific_heat_kj_kgk=2.10,
        autoignition_temp_k=470.0,
        laminar_flame_speed_ref_m_s=0.31,
        carbon_fraction_mass=0.85,
        hydrogen_fraction_mass=0.15,
        octane_or_cetane=70.0,
        default_combustion_type="compression_ignition",
        exergy_factor=1.07,
    ),
}


def get_fuel(fuel_type: FuelType | str) -> FuelProperties:
    """Look up a fuel from the built-in database."""
    if isinstance(fuel_type, str):
        fuel_type = FuelType(fuel_type)
    return FUEL_DATABASE[fuel_type]
