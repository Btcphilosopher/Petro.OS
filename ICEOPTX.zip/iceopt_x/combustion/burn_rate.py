"""
combustion.burn_rate
=====================

Finite-rate heat release via the Wiebe function (Section 8, LEVEL 2).

PHYSICS-INFORMED EMPIRICAL MODEL: the Wiebe function is the standard,
widely validated engineering representation of mass-fraction-burned vs
crank angle. Its shape parameters (a, m) are calibration constants
tuned per fuel/combustion-system family; defaults below are
representative literature values (Heywood; Ghojel 2010 review of the
Wiebe function), not measurements of a specific engine.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class WiebeParameters:
    a: float = 5.0  # efficiency parameter (a=5 => ~99.3% burned at end of burn duration)
    m: float = 2.0  # shape factor (m~2 typical SI; ~1.0-1.5 typical CI, faster initial rise)
    start_deg: float = -10.0  # crank angle at start of combustion, deg ATDC (negative = BTDC)
    duration_deg: float = 40.0  # total burn duration, deg


def mass_fraction_burned(theta_deg: np.ndarray, params: WiebeParameters) -> np.ndarray:
    """x(theta) = 1 - exp(-a * ((theta - theta0)/dtheta)^(m+1)), clipped
    to [0, 1] outside the combustion window."""
    theta_deg = np.asarray(theta_deg, dtype=float)
    x = np.zeros_like(theta_deg)
    within = (theta_deg >= params.start_deg) & (theta_deg <= params.start_deg + params.duration_deg)
    frac = (theta_deg[within] - params.start_deg) / params.duration_deg
    x[within] = 1.0 - np.exp(-params.a * frac ** (params.m + 1.0))
    x[theta_deg > params.start_deg + params.duration_deg] = 1.0 - np.exp(-params.a)
    return x


def heat_release_rate(theta_deg: np.ndarray, params: WiebeParameters, total_heat_release_j: float) -> np.ndarray:
    """dQ/dtheta, analytic derivative of the Wiebe function scaled by the
    total chemical heat released this cycle."""
    theta_deg = np.asarray(theta_deg, dtype=float)
    dqdtheta = np.zeros_like(theta_deg)
    within = (theta_deg >= params.start_deg) & (theta_deg <= params.start_deg + params.duration_deg)
    frac = (theta_deg[within] - params.start_deg) / params.duration_deg
    frac = np.clip(frac, 1e-9, None)
    a, m, dtheta = params.a, params.m, params.duration_deg
    dqdtheta[within] = (
        total_heat_release_j * a * (m + 1.0) / dtheta * frac**m * np.exp(-a * frac ** (m + 1.0))
    )
    return dqdtheta


def burn_duration_10_90_deg(params: WiebeParameters) -> float:
    """CA10-90 burn duration derived from the Wiebe shape (rapid-burn
    metric commonly reported for combustion quality)."""
    def theta_for_fraction(x_target: float) -> float:
        frac = (-np.log(1.0 - x_target) / params.a) ** (1.0 / (params.m + 1.0))
        return params.start_deg + frac * params.duration_deg

    return theta_for_fraction(0.9) - theta_for_fraction(0.1)


def timing_to_wiebe_params(
    ignition_or_injection_timing_btdc_deg: float,
    base_duration_deg: float,
    rpm: float,
    rpm_reference: float = 2000.0,
    m: float = 2.0,
    a: float = 5.0,
) -> WiebeParameters:
    """Maps an actuator timing (spark advance / start of injection) to
    Wiebe start angle, and lets burn duration lengthen mildly with RPM
    (less time per degree available for flame development/mixing at
    higher speed). EMPIRICAL MODEL."""
    start_deg = -ignition_or_injection_timing_btdc_deg  # BTDC -> negative crank angle
    duration_deg = base_duration_deg * (1.0 + 0.15 * (rpm / rpm_reference - 1.0))
    duration_deg = max(duration_deg, 10.0)
    return WiebeParameters(a=a, m=m, start_deg=start_deg, duration_deg=duration_deg)
