"""
combustion.air_fuel_ratio
==========================

Lambda / AFR / fuel-flow relationships (Section 10).
PHYSICS MODEL: definitional relations from fuel chemistry.
"""
from __future__ import annotations

from dataclasses import dataclass

from iceopt_x.combustion.fuel import FuelProperties


@dataclass
class MixtureResult:
    lambda_value: float
    afr: float
    fuel_mass_flow_kg_s: float
    fuel_mass_flow_kg_h: float
    oxygen_mass_flow_kg_s: float


AIR_OXYGEN_MASS_FRACTION = 0.2314  # PHYSICS MODEL: O2 mass fraction of dry air


def fuel_flow_from_air_and_lambda(air_mass_flow_kg_s: float, fuel: FuelProperties, lambda_value: float) -> MixtureResult:
    """lambda = AFR_actual / AFR_stoich  =>  AFR_actual = lambda * AFR_stoich
    fuel_flow = air_flow / AFR_actual
    """
    afr = lambda_value * fuel.stoichiometric_afr
    fuel_flow = air_mass_flow_kg_s / afr if afr > 0 else 0.0
    o2_flow = air_mass_flow_kg_s * AIR_OXYGEN_MASS_FRACTION
    return MixtureResult(
        lambda_value=lambda_value,
        afr=afr,
        fuel_mass_flow_kg_s=fuel_flow,
        fuel_mass_flow_kg_h=fuel_flow * 3600.0,
        oxygen_mass_flow_kg_s=o2_flow,
    )


def lambda_from_afr(afr: float, fuel: FuelProperties) -> float:
    return afr / fuel.stoichiometric_afr


def afr_from_lambda(lambda_value: float, fuel: FuelProperties) -> float:
    return lambda_value * fuel.stoichiometric_afr


def oxygen_availability_ratio(air_mass_flow_kg_s: float, fuel_mass_flow_kg_s: float, fuel: FuelProperties) -> float:
    """Ratio of available O2 to stoichiometrically required O2 -- >1 is
    lean (excess oxygen), <1 is rich (oxygen-limited combustion, where
    combustion efficiency starts to fall -- see combustion_efficiency).
    This is algebraically identical to lambda: the stoichiometric fuel
    flow the current air flow could support, divided by the fuel flow
    actually being burned."""
    if fuel_mass_flow_kg_s <= 0:
        return float("inf")
    stoich_fuel_flow = air_mass_flow_kg_s / fuel.stoichiometric_afr
    return stoich_fuel_flow / fuel_mass_flow_kg_s
