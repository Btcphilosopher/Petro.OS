"""
combustion.ignition
====================

Spark timing optimisation for SI engines (Section 11).

EMPIRICAL MODEL: MBT (minimum spark advance for best torque) search.
Real MBT is found experimentally per engine; here it is derived from
the peak-pressure-location heuristic (peak cylinder pressure should
land ~12-20 deg ATDC for near-optimal work extraction), which is a
well-established rule of thumb, not a first-principles result.
"""
from __future__ import annotations

from dataclasses import dataclass

TARGET_PEAK_PRESSURE_LOCATION_ATDC_DEG = 15.0  # ASSUMPTION: classic "peak pressure ~15 deg ATDC" MBT heuristic
KNOCK_MARGIN_DEG = 3.0  # ASSUMPTION: timing retard margin kept versus the knock-limited spark advance


@dataclass
class IgnitionSearchResult:
    mbt_timing_btdc_deg: float
    knock_limited_timing_btdc_deg: float
    applied_timing_btdc_deg: float
    knock_limited: bool


def knock_limited_spark_advance_btdc_deg(
    compression_ratio: float,
    octane_number: float,
    intake_temperature_k: float,
    boost_pressure_kpa: float,
) -> float:
    """EMPIRICAL MODEL: higher CR, boost, and intake temperature all
    reduce the knock-limited spark advance; higher octane raises it.
    Calibrated to give plausible values (roughly 10-35 deg BTDC) across
    the normal operating envelope of a road-car SI engine."""
    base = 38.0
    cr_penalty = 1.7 * (compression_ratio - 9.0)
    octane_bonus = 0.28 * (octane_number - 91.0)
    temp_penalty = 0.05 * max(intake_temperature_k - 298.15, 0.0)
    boost_penalty = 0.09 * boost_pressure_kpa
    limit = base - cr_penalty + octane_bonus - temp_penalty - boost_penalty
    return max(limit, 4.0)


def search_mbt_timing(
    base_mbt_btdc_deg: float,
    compression_ratio: float,
    octane_number: float,
    intake_temperature_k: float,
    boost_pressure_kpa: float,
) -> IgnitionSearchResult:
    """Applied timing = min(MBT, knock-limited - margin). The optimiser
    never assumes a fixed timing; it always checks the knock boundary."""
    knock_limit = knock_limited_spark_advance_btdc_deg(
        compression_ratio, octane_number, intake_temperature_k, boost_pressure_kpa
    )
    knock_safe_limit = knock_limit - KNOCK_MARGIN_DEG
    knock_limited = knock_safe_limit < base_mbt_btdc_deg
    applied = min(base_mbt_btdc_deg, knock_safe_limit)
    applied = max(applied, 2.0)
    return IgnitionSearchResult(
        mbt_timing_btdc_deg=base_mbt_btdc_deg,
        knock_limited_timing_btdc_deg=knock_safe_limit,
        applied_timing_btdc_deg=applied,
        knock_limited=knock_limited,
    )
