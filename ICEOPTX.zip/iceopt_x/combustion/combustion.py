"""
combustion.combustion
=======================

Combustion orchestrator (Section 8): given fuel, fuel mass, air mass,
charge conditions, compression ratio and timing, produce heat release,
combustion efficiency, peak pressure/temperature, burn duration and
timing, and the full crank-resolved closed-cycle trace.

Ties together: combustion.fuel, combustion.air_fuel_ratio,
combustion.burn_rate (Wiebe, LEVEL 2), combustion.combustion_efficiency,
and thermodynamics.cycle (first-law closed-cycle integration).
"""
from __future__ import annotations

from dataclasses import dataclass

from iceopt_x.combustion.burn_rate import timing_to_wiebe_params
from iceopt_x.combustion.combustion_efficiency import combustion_efficiency as si_ci_combustion_efficiency
from iceopt_x.combustion.combustion_efficiency import hydrogen_combustion_efficiency
from iceopt_x.combustion.fuel import FuelProperties, FuelType
from iceopt_x.core.state import CombustionType, EngineGeometry
from iceopt_x.thermodynamics.cycle import CycleResult, simulate_closed_cycle


@dataclass
class CombustionResult:
    heat_released_j: float
    combustion_efficiency: float
    peak_cylinder_pressure_bar: float
    peak_cylinder_pressure_location_deg: float
    peak_temperature_k: float
    burn_start_btdc_deg: float
    burn_duration_deg: float
    gross_indicated_work_j: float
    wall_heat_loss_j: float
    cycle: CycleResult


def _select_combustion_efficiency_fn(fuel: FuelProperties):
    if fuel.fuel_type == FuelType.HYDROGEN:
        return lambda lam, is_ci: hydrogen_combustion_efficiency(lam)
    return si_ci_combustion_efficiency


def evaluate_combustion(
    geometry: EngineGeometry,
    fuel: FuelProperties,
    air_mass_per_cycle_kg: float,
    fuel_mass_per_cycle_kg: float,
    lambda_value: float,
    ivc_pressure_kpa: float,
    ivc_temperature_k: float,
    rpm: float,
    timing_btdc_deg: float,
    base_burn_duration_deg: float = 45.0,
    wiebe_m: float | None = None,
    wall_temperature_k: float = 460.0,
    combustion_efficiency_multiplier: float = 1.0,
    residual_gas_fraction: float = 0.0,
) -> CombustionResult:
    """Compute the full combustion event for one cycle."""
    is_ci = geometry.combustion_type == CombustionType.COMPRESSION_IGNITION
    eff_fn = _select_combustion_efficiency_fn(fuel)
    eta_comb = min(eff_fn(lambda_value, is_ci) * combustion_efficiency_multiplier, 0.999)

    heat_released_j = fuel_mass_per_cycle_kg * fuel.lower_heating_value_mj_kg * 1.0e6 * eta_comb

    m = wiebe_m if wiebe_m is not None else (1.1 if is_ci else 2.0)
    wiebe = timing_to_wiebe_params(
        ignition_or_injection_timing_btdc_deg=timing_btdc_deg,
        base_duration_deg=base_burn_duration_deg,
        rpm=rpm,
        m=m,
    )

    # Residual (hot, inert) exhaust gas trapped from the previous cycle
    # dilutes and adds thermal mass to the fresh charge -- physically
    # significant at light throttle (Section 7/8), where it is the main
    # reason real part-load peak/exhaust temperatures run well below
    # full-load values despite similar lambda. Adding it as extra inert
    # mass (not extra heat-releasing fuel/air) is a standard simplified
    # way to capture that cooling effect without a full gas-exchange model.
    fresh_charge_mass_kg = air_mass_per_cycle_kg + fuel_mass_per_cycle_kg
    trapped_mass_kg = fresh_charge_mass_kg * (1.0 + max(residual_gas_fraction, 0.0))

    cycle = simulate_closed_cycle(
        geometry=geometry,
        ivc_pressure_kpa=ivc_pressure_kpa,
        ivc_temperature_k=ivc_temperature_k,
        trapped_mass_kg=trapped_mass_kg,
        heat_released_j=heat_released_j,
        wiebe=wiebe,
        rpm=rpm,
        wall_temperature_k=wall_temperature_k,
    )

    return CombustionResult(
        heat_released_j=heat_released_j,
        combustion_efficiency=eta_comb,
        peak_cylinder_pressure_bar=cycle.peak_pressure_bar,
        peak_cylinder_pressure_location_deg=cycle.peak_pressure_location_deg,
        peak_temperature_k=cycle.peak_temperature_k,
        burn_start_btdc_deg=timing_btdc_deg,
        burn_duration_deg=wiebe.duration_deg,
        gross_indicated_work_j=cycle.gross_indicated_work_j,
        wall_heat_loss_j=cycle.wall_heat_loss_j,
        cycle=cycle,
    )
