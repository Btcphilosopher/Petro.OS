"""combustion subpackage of ICEOPT-X."""
