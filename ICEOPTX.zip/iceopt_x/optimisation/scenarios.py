"""
optimisation.scenarios
========================

Scenario engine (Section 27): standard operating scenarios expressed as
concrete (AmbientConditions, ThermalState, OperatingPoint-template)
combinations, so the optimiser can compare strategies across them
rather than only ever tuning for one fixed condition.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from iceopt_x.core.state import AmbientConditions, ThermalState


class Scenario(str, Enum):
    COLD_START = "cold_start"
    HOT_WEATHER = "hot_weather"
    COLD_WEATHER = "cold_weather"
    HIGH_ALTITUDE = "high_altitude"
    FULL_LOAD = "full_load"
    PART_LOAD = "part_load"
    IDLE = "idle"
    TRANSIENT_ACCELERATION = "transient_acceleration"
    STEADY_CRUISE = "steady_cruise"
    GENERATOR_OPERATION = "generator_operation"
    HYBRID_OPERATION = "hybrid_operation"


@dataclass
class ScenarioContext:
    scenario: Scenario
    ambient: AmbientConditions
    thermal_state: ThermalState
    rpm_hint: float
    load_fraction_hint: float
    notes: str


def build_scenario(scenario: Scenario) -> ScenarioContext:
    """CALIBRATION DATA: representative ambient/thermal conditions and a
    plausible (RPM, load) starting point for each named scenario --
    illustrative defaults, not measured fleet data."""
    sea_level = AmbientConditions(pressure_kpa=101.325, temperature_k=298.15, altitude_m=0.0)

    table: dict[Scenario, ScenarioContext] = {
        Scenario.COLD_START: ScenarioContext(
            Scenario.COLD_START,
            AmbientConditions(pressure_kpa=101.325, temperature_k=263.15, altitude_m=0.0),
            ThermalState(coolant_temp_k=263.15, oil_temp_k=263.15, block_temp_k=263.15, head_temp_k=263.15),
            rpm_hint=1200.0,
            load_fraction_hint=0.15,
            notes="Cold metal and cold, viscous oil: friction dominates; combustion efficiency is penalised by cold walls/charge.",
        ),
        Scenario.HOT_WEATHER: ScenarioContext(
            Scenario.HOT_WEATHER,
            AmbientConditions(pressure_kpa=100.5, temperature_k=316.15, altitude_m=0.0, relative_humidity=0.3),
            ThermalState(coolant_temp_k=368.15, oil_temp_k=373.15, block_temp_k=363.15, head_temp_k=373.15),
            rpm_hint=2500.0,
            load_fraction_hint=0.5,
            notes="Hot intake air reduces air density (less VE mass flow) and raises knock risk (SI timing must retard).",
        ),
        Scenario.COLD_WEATHER: ScenarioContext(
            Scenario.COLD_WEATHER,
            AmbientConditions(pressure_kpa=102.0, temperature_k=258.15, altitude_m=0.0),
            ThermalState(coolant_temp_k=310.15, oil_temp_k=305.15, block_temp_k=305.15, head_temp_k=310.15),
            rpm_hint=2500.0,
            load_fraction_hint=0.5,
            notes="Dense cold air raises VE mass flow (more torque available) but oil viscosity raises friction until warmed up.",
        ),
        Scenario.HIGH_ALTITUDE: ScenarioContext(
            Scenario.HIGH_ALTITUDE,
            AmbientConditions(pressure_kpa=70.0, temperature_k=278.15, altitude_m=3000.0),
            ThermalState(),
            rpm_hint=3000.0,
            load_fraction_hint=0.6,
            notes="Low ambient pressure starves NA engines of air (VE mass flow drops ~1:1 with pressure); boosted engines compensate via the compressor.",
        ),
        Scenario.FULL_LOAD: ScenarioContext(
            Scenario.FULL_LOAD, sea_level, ThermalState(), rpm_hint=5000.0, load_fraction_hint=1.0,
            notes="Maximum power point: thermal and pressure constraints are usually the binding limits, not fuel supply.",
        ),
        Scenario.PART_LOAD: ScenarioContext(
            Scenario.PART_LOAD, sea_level, ThermalState(), rpm_hint=2000.0, load_fraction_hint=0.3,
            notes="Where most road-going operation actually happens: pumping and friction losses dominate the efficiency picture.",
        ),
        Scenario.IDLE: ScenarioContext(
            Scenario.IDLE, sea_level, ThermalState(), rpm_hint=800.0, load_fraction_hint=0.05,
            notes="Near-zero useful output; efficiency metrics are not meaningful, only stability/emissions matter.",
        ),
        Scenario.TRANSIENT_ACCELERATION: ScenarioContext(
            Scenario.TRANSIENT_ACCELERATION, sea_level, ThermalState(), rpm_hint=3500.0, load_fraction_hint=0.9,
            notes="Turbo lag / enrichment for transient AFR protection typically overrides the steady-state optimum.",
        ),
        Scenario.STEADY_CRUISE: ScenarioContext(
            Scenario.STEADY_CRUISE, sea_level, ThermalState(), rpm_hint=2200.0, load_fraction_hint=0.25,
            notes="The classic lean/high-efficiency search region for fuel economy optimisation.",
        ),
        Scenario.GENERATOR_OPERATION: ScenarioContext(
            Scenario.GENERATOR_OPERATION, sea_level, ThermalState(), rpm_hint=1800.0, load_fraction_hint=0.75,
            notes="Fixed-speed operation (Section 28): the optimiser searches load only, not RPM.",
        ),
        Scenario.HYBRID_OPERATION: ScenarioContext(
            Scenario.HYBRID_OPERATION, sea_level, ThermalState(), rpm_hint=2500.0, load_fraction_hint=0.8,
            notes="ICE runs only at its efficiency-optimal points; the electric path covers everything else.",
        ),
    }
    return table[scenario]


def all_scenarios() -> list[ScenarioContext]:
    return [build_scenario(s) for s in Scenario]
