"""optimisation subpackage of ICEOPT-X."""
