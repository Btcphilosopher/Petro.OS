"""
optimisation.pareto
=====================

Multi-objective optimisation / Pareto frontier (Section 22): sample the
free-variable space (lambda, timing, boost) at a fixed (RPM, load), keep
only feasible points, and extract the non-dominated set across two or
more objectives (e.g. power vs efficiency).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from iceopt_x.core.engine import Engine, EvaluationResult
from iceopt_x.core.state import AmbientConditions, CombustionType, OperatingPoint, ThermalState

OBJECTIVE_EXTRACTORS = {
    "power_kw": lambda r: r.brake_power_kw,
    "brake_thermal_efficiency": lambda r: r.efficiency.brake_thermal_efficiency,
    "minimum_fuel_kg_h": lambda r: -r.mixture.fuel_mass_flow_kg_h,  # maximize the negative == minimize fuel
    "minimum_thermal_stress_k": lambda r: -r.combustion.peak_temperature_k,
    "minimum_exhaust_energy_loss_kw": lambda r: -r.exhaust_heat_leftover_kw,
    "maximum_total_useful_energy_kw": lambda r: r.brake_power_kw + 0.35 * r.thermal_balance.coolant_heat_kw,
}


@dataclass
class ParetoPoint:
    operating_point: OperatingPoint
    evaluation: EvaluationResult
    objectives: dict[str, float]  # always in "higher is better" orientation


def sample_candidates(
    engine: Engine,
    rpm: float,
    load_fraction: float,
    ambient: AmbientConditions,
    thermal_state: ThermalState,
    n_lambda: int = 6,
    n_timing: int = 6,
    n_boost: int = 4,
) -> list[EvaluationResult]:
    geometry = engine.model.geometry
    constraints = engine.model.constraints
    is_ci = geometry.combustion_type == CombustionType.COMPRESSION_IGNITION
    is_turbo = geometry.aspiration.value == "turbocharged"

    lambdas = np.linspace(constraints.min_lambda, constraints.max_lambda, n_lambda)
    timings = np.linspace(6.0, 32.0, n_timing)
    boosts = np.linspace(0.0, constraints.max_boost_kpa, n_boost) if is_turbo else [0.0]

    results = []
    for lam in lambdas:
        for timing in timings:
            for boost in boosts:
                kwargs = dict(
                    rpm=rpm,
                    load_fraction=load_fraction,
                    lambda_target=float(lam),
                    boost_pressure_kpa=float(boost),
                )
                if is_ci:
                    kwargs["injection_timing_btdc_deg"] = float(timing)
                else:
                    kwargs["ignition_timing_btdc_deg"] = float(timing)
                op = OperatingPoint(**kwargs)
                results.append(engine.evaluate(op, ambient, thermal_state))
    return results


def non_dominated_set(points: list[ParetoPoint]) -> list[ParetoPoint]:
    """A point is Pareto-optimal if no other point is at least as good on
    every objective and strictly better on at least one (all objectives
    pre-oriented so higher == better)."""
    keys = list(points[0].objectives.keys()) if points else []
    frontier = []
    for i, p in enumerate(points):
        dominated = False
        for j, q in enumerate(points):
            if i == j:
                continue
            at_least_as_good = all(q.objectives[k] >= p.objectives[k] for k in keys)
            strictly_better = any(q.objectives[k] > p.objectives[k] for k in keys)
            if at_least_as_good and strictly_better:
                dominated = True
                break
        if not dominated:
            frontier.append(p)
    return frontier


def build_pareto_frontier(
    engine: Engine,
    rpm: float,
    load_fraction: float,
    objectives: list[str],
    ambient: AmbientConditions | None = None,
    thermal_state: ThermalState | None = None,
    n_lambda: int = 6,
    n_timing: int = 6,
    n_boost: int = 4,
) -> list[ParetoPoint]:
    ambient = ambient or AmbientConditions()
    thermal_state = thermal_state or ThermalState()
    for name in objectives:
        if name not in OBJECTIVE_EXTRACTORS:
            raise ValueError(f"Unknown objective '{name}'. Choose from {sorted(OBJECTIVE_EXTRACTORS)}")

    raw_results = sample_candidates(engine, rpm, load_fraction, ambient, thermal_state, n_lambda, n_timing, n_boost)
    feasible = [r for r in raw_results if r.is_feasible]

    points = [
        ParetoPoint(
            operating_point=r.inputs,
            evaluation=r,
            objectives={name: OBJECTIVE_EXTRACTORS[name](r) for name in objectives},
        )
        for r in feasible
    ]
    return non_dominated_set(points)
