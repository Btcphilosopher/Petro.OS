"""
optimisation.marginal_gain
============================

The marginal-gain engine (Section 23): "what single change would
produce the largest improvement in engine performance?"

Each candidate intervention is applied as a real, physically meaningful
perturbation (a calibration multiplier on volumetric/combustion/friction
efficiency wired through core.engine, a compressor/turbine efficiency
bump wired through the turbo shaft balance, or a direct operating-point
change for intake temperature) -- never a hard-coded "this many percent"
answer.
"""
from __future__ import annotations

from dataclasses import dataclass

from iceopt_x.core.engine import Engine, EvaluationResult
from iceopt_x.core.state import AmbientConditions, OperatingPoint, ThermalState
from iceopt_x.exhaust.heat_recovery import recoverable_exhaust_heat

KPI_EXTRACTORS = {
    "brake_thermal_efficiency": lambda r: r.efficiency.brake_thermal_efficiency,
    "brake_power_kw": lambda r: r.brake_power_kw,
    "bsfc_g_per_kwh": lambda r: -r.efficiency.bsfc_g_per_kwh,  # lower BSFC is better -> negate so "higher is better" holds
}


@dataclass
class Intervention:
    name: str
    description: str


@dataclass
class MarginalGainRanking:
    intervention: str
    description: str
    baseline_value: float
    new_value: float
    delta: float
    delta_percentage_points: float  # for percentage-based KPIs (efficiency); raw delta otherwise


STANDARD_INTERVENTIONS: list[Intervention] = [
    Intervention("ve_plus_1pct", "+1% volumetric efficiency"),
    Intervention("combustion_eff_plus_1pct", "+1% combustion efficiency"),
    Intervention("compressor_eff_plus_1pct", "+1% compressor efficiency"),
    Intervention("turbine_eff_plus_1pct", "+1% turbine efficiency"),
    Intervention("intake_temp_minus_1c", "-1 degC intake temperature"),
    Intervention("friction_minus_1pct", "-1% friction"),
    Intervention("heat_recovery_plus_1pct", "+1% heat recovery effectiveness"),
]


def _apply_intervention(
    engine: Engine,
    op: OperatingPoint,
    ambient: AmbientConditions,
    thermal_state: ThermalState,
    intervention_name: str,
) -> tuple[Engine, OperatingPoint]:
    """Returns a (possibly) modified Engine and OperatingPoint reflecting
    the named intervention; original objects are never mutated."""
    model = engine.model
    mult = dict(model.calibration_multipliers)
    new_op = op

    if intervention_name == "ve_plus_1pct":
        mult["volumetric_efficiency"] *= 1.01
    elif intervention_name == "combustion_eff_plus_1pct":
        mult["combustion_efficiency"] *= 1.01
    elif intervention_name == "compressor_eff_plus_1pct":
        mult["compressor_efficiency"] *= 1.01
    elif intervention_name == "turbine_eff_plus_1pct":
        mult["turbine_efficiency"] *= 1.01
    elif intervention_name == "friction_minus_1pct":
        mult["friction"] *= 0.99
    elif intervention_name == "intake_temp_minus_1c":
        new_op = op.model_copy(update={"intake_temperature_k": op.intake_temperature_k - 1.0})
    elif intervention_name == "heat_recovery_plus_1pct":
        pass  # handled outside the main evaluate() chain -- see heat_recovery_gain_kw below
    else:
        raise ValueError(f"Unknown intervention '{intervention_name}'")

    new_model = model.model_copy(update={"calibration_multipliers": mult})
    return Engine(new_model), new_op


def heat_recovery_gain_kw(baseline: EvaluationResult, effectiveness_boost: float = 0.01) -> float:
    """The "+1% heat recovery" intervention doesn't change engine
    operation at all -- it changes how much of the (unavoidable) exhaust
    heat stream downstream equipment can capture. Evaluated directly via
    exhaust.heat_recovery rather than through Engine.evaluate()."""
    base = recoverable_exhaust_heat(
        baseline.exhaust_mass_flow_kg_s, baseline.exhaust_temperature_k, baseline.ambient.temperature_k
    )
    boosted = recoverable_exhaust_heat(
        baseline.exhaust_mass_flow_kg_s,
        baseline.exhaust_temperature_k,
        baseline.ambient.temperature_k,
        heat_exchanger_effectiveness=base.recovery_effectiveness + effectiveness_boost,
    )
    return boosted.recoverable_heat_kw - base.recoverable_heat_kw


def rank_marginal_gains(
    engine: Engine,
    op: OperatingPoint,
    ambient: AmbientConditions | None = None,
    thermal_state: ThermalState | None = None,
    kpi: str = "brake_thermal_efficiency",
    interventions: list[Intervention] | None = None,
) -> list[MarginalGainRanking]:
    ambient = ambient or AmbientConditions()
    thermal_state = thermal_state or ThermalState()
    interventions = interventions or STANDARD_INTERVENTIONS
    extractor = KPI_EXTRACTORS[kpi]

    baseline = engine.evaluate(op, ambient, thermal_state)
    baseline_value = extractor(baseline)

    results: list[MarginalGainRanking] = []
    for interv in interventions:
        if interv.name == "heat_recovery_plus_1pct":
            gain_kw = heat_recovery_gain_kw(baseline)
            # Report as an equivalent addition to "total useful energy" rather
            # than the (unaffected) brake-efficiency KPI.
            results.append(
                MarginalGainRanking(
                    intervention=interv.name,
                    description=interv.description,
                    baseline_value=0.0,
                    new_value=gain_kw,
                    delta=gain_kw,
                    delta_percentage_points=0.0,
                )
            )
            continue

        mod_engine, mod_op = _apply_intervention(engine, op, ambient, thermal_state, interv.name)
        result = mod_engine.evaluate(mod_op, ambient, thermal_state)
        new_value = extractor(result)
        delta = new_value - baseline_value
        delta_pp = delta * 100.0 if kpi == "brake_thermal_efficiency" else delta

        results.append(
            MarginalGainRanking(
                intervention=interv.name,
                description=interv.description,
                baseline_value=baseline_value,
                new_value=new_value,
                delta=delta,
                delta_percentage_points=delta_pp,
            )
        )

    results.sort(key=lambda r: r.delta, reverse=True)
    return results
