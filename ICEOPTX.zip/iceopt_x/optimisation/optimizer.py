"""
optimisation.optimizer
========================

Global optimisation (Section 21): search across AFR (lambda), ignition /
injection timing, boost, intake temperature and coolant temperature to
find the setpoint that best satisfies a chosen objective at a given
(RPM, load), subject to the constraint engine (Section 25).

The search is a global, derivative-free optimiser (scipy differential
evolution) over a penalised objective -- infeasible candidates are
pushed far into the tail rather than evaluated as if they were legal,
which is what "the optimiser must reject infeasible states" means in
practice for a continuous search (Section 25).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np
from scipy.optimize import differential_evolution

from iceopt_x.core.engine import Engine, EvaluationResult
from iceopt_x.core.state import AmbientConditions, CombustionType, OperatingPoint, ThermalState
from iceopt_x.optimisation.constraints import feasibility_penalty

OBJECTIVES: dict[str, tuple[Callable[[EvaluationResult], float], bool]] = {
    # name -> (extractor, maximize?)
    "brake_thermal_efficiency": (lambda r: r.efficiency.brake_thermal_efficiency, True),
    "brake_power_kw": (lambda r: r.brake_power_kw, True),
    "bsfc_g_per_kwh": (lambda r: r.efficiency.bsfc_g_per_kwh, False),
    "minimum_thermal_stress": (lambda r: r.combustion.peak_temperature_k, False),
    "minimum_fuel_flow": (lambda r: r.mixture.fuel_mass_flow_kg_h, False),
    "maximum_total_useful_energy": (
        lambda r: r.brake_power_kw + r.thermal_balance.coolant_heat_kw * 0.35,  # ASSUMPTION: 35% of coolant heat is usefully recoverable
        True,
    ),
}


@dataclass
class OptimizationVariable:
    name: str
    low: float
    high: float


@dataclass
class OptimizationResult:
    objective_name: str
    objective_value: float
    variables: dict[str, float]
    evaluation: EvaluationResult
    n_evaluations: int
    converged: bool


class GlobalOptimizer:
    def __init__(self, engine: Engine):
        self.engine = engine

    def _default_variables(self, rpm: float) -> list[OptimizationVariable]:
        geometry = self.engine.model.geometry
        constraints = self.engine.model.constraints
        variables = [OptimizationVariable("lambda_target", constraints.min_lambda, constraints.max_lambda)]

        if geometry.combustion_type == CombustionType.COMPRESSION_IGNITION:
            variables.append(OptimizationVariable("injection_timing_btdc_deg", 2.0, 30.0))
        else:
            variables.append(OptimizationVariable("ignition_timing_btdc_deg", 4.0, 40.0))

        if geometry.aspiration.value == "turbocharged":
            variables.append(OptimizationVariable("boost_pressure_kpa", 0.0, constraints.max_boost_kpa))

        variables.append(OptimizationVariable("intake_temperature_k", 288.15, 328.15))
        variables.append(OptimizationVariable("coolant_temperature_k", 353.15, 373.15))
        return variables

    def optimize(
        self,
        rpm: float,
        load_fraction: float,
        objective: str = "brake_thermal_efficiency",
        ambient: AmbientConditions | None = None,
        variables: list[OptimizationVariable] | None = None,
        maxiter: int = 60,
        popsize: int = 12,
        seed: int | None = 42,
    ) -> OptimizationResult:
        if objective not in OBJECTIVES:
            raise ValueError(f"Unknown objective '{objective}'. Choose from {sorted(OBJECTIVES)}")
        extractor, maximize = OBJECTIVES[objective]

        ambient = ambient or AmbientConditions()
        variables = variables or self._default_variables(rpm)
        n_eval = {"count": 0}

        def build_op(x: np.ndarray) -> OperatingPoint:
            kwargs = dict(zip((v.name for v in variables), x))
            op_kwargs = dict(rpm=rpm, load_fraction=load_fraction)
            op_kwargs.update({k: v for k, v in kwargs.items() if k not in ("intake_temperature_k", "coolant_temperature_k")})
            if "intake_temperature_k" in kwargs:
                op_kwargs["intake_temperature_k"] = kwargs["intake_temperature_k"]
            return OperatingPoint(**op_kwargs)

        def build_thermal_state(x: np.ndarray) -> ThermalState:
            kwargs = dict(zip((v.name for v in variables), x))
            coolant_t = kwargs.get("coolant_temperature_k", 363.15)
            return ThermalState(coolant_temp_k=coolant_t, oil_temp_k=coolant_t, block_temp_k=coolant_t - 5.0, head_temp_k=coolant_t + 5.0)

        def objective_fn(x: np.ndarray) -> float:
            n_eval["count"] += 1
            op = build_op(x)
            thermal_state = build_thermal_state(x)
            result = self.engine.evaluate(op, ambient, thermal_state)
            value = extractor(result)
            penalty = feasibility_penalty(result, scale=1.0e4)
            score = -value if maximize else value
            return score + penalty

        bounds = [(v.low, v.high) for v in variables]
        de_result = differential_evolution(
            objective_fn,
            bounds,
            maxiter=maxiter,
            popsize=popsize,
            seed=seed,
            polish=True,
            tol=1e-6,
            mutation=(0.4, 1.2),
            recombination=0.8,
        )

        best_op = build_op(de_result.x)
        best_thermal = build_thermal_state(de_result.x)
        best_result = self.engine.evaluate(best_op, ambient, best_thermal)

        return OptimizationResult(
            objective_name=objective,
            objective_value=extractor(best_result),
            variables=dict(zip((v.name for v in variables), de_result.x)),
            evaluation=best_result,
            n_evaluations=n_eval["count"],
            converged=bool(de_result.success),
        )
