"""
optimisation.constraints
==========================

The constraint engine (Section 25): a thin, explicit gate the optimiser
must pass every candidate through. "Never optimise outside safe
configured limits" -- infeasible candidates are rejected, never
silently clipped into feasibility.
"""
from __future__ import annotations

from iceopt_x.core.engine import EvaluationResult


def is_feasible(result: EvaluationResult) -> bool:
    return result.is_feasible


def describe_violations(result: EvaluationResult) -> list[str]:
    return [str(v) for v in result.constraint_violations]


def feasibility_penalty(result: EvaluationResult, scale: float = 1.0) -> float:
    """A smooth penalty (0 if feasible, growing with the size of the
    worst violation) usable by penalty-method optimisers. Kept separate
    from the hard reject-if-infeasible logic (`is_feasible`) so callers
    can choose a soft (penalised search) or hard (reject candidate)
    constraint-handling strategy."""
    if result.is_feasible:
        return 0.0
    penalty = 0.0
    for v in result.constraint_violations:
        relative_excess = abs(v.value - v.limit) / max(abs(v.limit), 1e-9)
        penalty += relative_excess
    return scale * penalty
