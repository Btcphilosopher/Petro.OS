"""
exhaust.backpressure
======================

PHYSICS MODEL: quadratic compressible-flow restriction (exhaust system +
catalyst/muffler + turbine) as a function of exhaust mass flow.
"""
from __future__ import annotations


def exhaust_system_backpressure_kpa(
    exhaust_mass_flow_kg_s: float,
    restriction_coeff_kpa_s2_kg2: float = 2200.0,
) -> float:
    """EMPIRICAL MODEL: restriction_coeff bundles catalyst + muffler +
    piping losses (ASSUMPTION default for a moderately restrictive
    road-car exhaust system, excludes any turbine restriction which is
    modelled separately in intake.turbo). Calibrated to give ~15-25 kPa
    at a typical full-load exhaust mass flow of ~0.10 kg/s for a 2.0L
    engine, consistent with published road-car exhaust backpressure
    measurements."""
    return restriction_coeff_kpa_s2_kg2 * exhaust_mass_flow_kg_s**2


def total_backpressure_kpa(exhaust_system_kpa: float, turbine_pressure_drop_kpa: float) -> float:
    return exhaust_system_kpa + turbine_pressure_drop_kpa
