"""
exhaust.exhaust_temperature
=============================

PHYSICS MODEL: exhaust gas temperature from the closed-cycle EVO
(exhaust-valve-open) state, corrected for blowdown expansion to exhaust
manifold pressure and port/manifold heat loss.
"""
from __future__ import annotations

GAMMA_EXHAUST = 1.33  # PHYSICS MODEL: representative ratio of specific heats for hot exhaust gas


def blowdown_expansion_temperature_k(
    evo_temperature_k: float,
    evo_pressure_pa: float,
    exhaust_manifold_pressure_pa: float,
    gamma: float = GAMMA_EXHAUST,
) -> float:
    """Isentropic expansion of the trapped gas from the EVO state down to
    exhaust manifold pressure during blowdown (Section 16)."""
    if evo_pressure_pa <= 0:
        return evo_temperature_k
    pr = exhaust_manifold_pressure_pa / evo_pressure_pa
    return evo_temperature_k * pr ** ((gamma - 1.0) / gamma)


def exhaust_port_manifold_temperature_k(
    blowdown_temperature_k: float,
    port_heat_loss_fraction: float = 0.06,
    ambient_temperature_k: float = 298.15,
) -> float:
    """EMPIRICAL MODEL: port/manifold wall heat loss removes a fraction
    of the enthalpy above ambient before the gas reaches the exhaust
    manifold flange / turbine inlet."""
    delta_above_ambient = blowdown_temperature_k - ambient_temperature_k
    return ambient_temperature_k + delta_above_ambient * (1.0 - port_heat_loss_fraction)
