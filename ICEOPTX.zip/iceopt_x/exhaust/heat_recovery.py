"""
exhaust.heat_recovery
=======================

Exhaust treated as an energy stream, not simply waste (Section 16/18).

PHYSICS MODEL: enthalpy-flow-based recoverable heat, bounded by a
realistic heat-exchanger approach temperature (recovery cannot cool the
exhaust below the downstream fluid's temperature, and practical
exchangers never hit the ideal effectiveness=1 limit).
"""
from __future__ import annotations

from dataclasses import dataclass

CP_EXHAUST_KJ_KGK = 1.10


@dataclass
class HeatRecoveryResult:
    recoverable_heat_kw: float
    exhaust_outlet_temp_k: float
    recovery_effectiveness: float


def recoverable_exhaust_heat(
    exhaust_mass_flow_kg_s: float,
    exhaust_temperature_k: float,
    downstream_fluid_temp_k: float,
    heat_exchanger_effectiveness: float = 0.65,
    min_stack_temperature_k: float = 393.15,  # ASSUMPTION: ~120 C acid dew-point floor to avoid condensation/corrosion
) -> HeatRecoveryResult:
    """Recoverable heat = m_dot * cp * effectiveness * (T_exhaust - T_downstream),
    but never cool the exhaust below min_stack_temperature_k -- this is
    a real, physically motivated recovery limit (Section 16: "without
    imposing unrealistic recovery assumptions"), not an arbitrary cap."""
    max_delta_t = max(exhaust_temperature_k - max(downstream_fluid_temp_k, min_stack_temperature_k), 0.0)
    q_max = exhaust_mass_flow_kg_s * CP_EXHAUST_KJ_KGK * max_delta_t
    q_recovered = heat_exchanger_effectiveness * q_max
    delta_t_actual = q_recovered / (exhaust_mass_flow_kg_s * CP_EXHAUST_KJ_KGK) if exhaust_mass_flow_kg_s > 0 else 0.0
    outlet_temp = exhaust_temperature_k - delta_t_actual
    return HeatRecoveryResult(
        recoverable_heat_kw=q_recovered,
        exhaust_outlet_temp_k=outlet_temp,
        recovery_effectiveness=heat_exchanger_effectiveness,
    )


def orc_electrical_output_kw(recoverable_heat_kw: float, orc_thermal_efficiency: float = 0.12) -> float:
    """ASSUMPTION: a small-scale Organic Rankine Cycle unit recovering
    low-grade exhaust heat typically converts ~8-15% of the recovered
    heat to electricity; 12% is a representative mid-range figure."""
    return recoverable_heat_kw * orc_thermal_efficiency
