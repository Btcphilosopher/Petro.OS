"""
exhaust.exhaust_flow
======================

PHYSICS MODEL: mass conservation across the cylinder -- what goes in
(air + fuel) must come out (exhaust), Section 16/29.
"""
from __future__ import annotations


def exhaust_mass_flow_kg_s(air_mass_flow_kg_s: float, fuel_mass_flow_kg_s: float) -> float:
    """Conservation of mass: m_dot_exhaust = m_dot_air + m_dot_fuel."""
    return air_mass_flow_kg_s + fuel_mass_flow_kg_s
