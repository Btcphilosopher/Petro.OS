"""exhaust subpackage of ICEOPT-X."""
