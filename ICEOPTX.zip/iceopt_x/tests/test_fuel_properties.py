import pytest

from iceopt_x.combustion.fuel import FUEL_DATABASE, FuelType, get_fuel


@pytest.mark.parametrize("fuel_type", list(FuelType))
def test_every_fuel_has_positive_physical_properties(fuel_type):
    fuel = get_fuel(fuel_type)
    assert fuel.lower_heating_value_mj_kg > 0
    assert fuel.higher_heating_value_mj_kg >= fuel.lower_heating_value_mj_kg
    assert fuel.density_kg_m3 > 0
    assert fuel.stoichiometric_afr > 0
    assert 0.0 <= fuel.carbon_fraction_mass <= 1.0
    assert 0.0 <= fuel.hydrogen_fraction_mass <= 1.0


def test_hydrogen_has_by_far_the_highest_lhv_and_stoichiometric_afr():
    h2 = get_fuel(FuelType.HYDROGEN)
    petrol = get_fuel(FuelType.PETROL)
    assert h2.lower_heating_value_mj_kg > 2.5 * petrol.lower_heating_value_mj_kg
    assert h2.stoichiometric_afr > 2.0 * petrol.stoichiometric_afr


def test_hydrogen_has_zero_carbon_content():
    h2 = get_fuel(FuelType.HYDROGEN)
    assert h2.carbon_fraction_mass == 0.0


def test_alcohol_fuels_have_lower_lhv_than_hydrocarbons():
    ethanol = get_fuel(FuelType.ETHANOL)
    methanol = get_fuel(FuelType.METHANOL)
    petrol = get_fuel(FuelType.PETROL)
    assert ethanol.lower_heating_value_mj_kg < petrol.lower_heating_value_mj_kg
    assert methanol.lower_heating_value_mj_kg < ethanol.lower_heating_value_mj_kg


def test_database_covers_every_declared_fuel_type():
    assert set(FUEL_DATABASE.keys()) == set(FuelType)


def test_get_fuel_accepts_string_key():
    assert get_fuel("diesel").fuel_type == FuelType.DIESEL
