import math


def test_exhaust_mass_flow_equals_air_plus_fuel(petrol_engine, mid_load_op, ambient, thermal_state):
    r = petrol_engine.evaluate(mid_load_op, ambient, thermal_state)
    expected = r.airflow.air_mass_flow_kg_s + r.mixture.fuel_mass_flow_kg_s
    assert math.isclose(r.exhaust_mass_flow_kg_s, expected, rel_tol=1e-9)


def test_fuel_flow_consistent_with_lambda_and_afr(petrol_engine, mid_load_op, ambient, thermal_state):
    r = petrol_engine.evaluate(mid_load_op, ambient, thermal_state)
    fuel = petrol_engine.model.fuel
    implied_afr = r.airflow.air_mass_flow_kg_s / r.mixture.fuel_mass_flow_kg_s
    implied_lambda = implied_afr / fuel.stoichiometric_afr
    assert math.isclose(implied_lambda, mid_load_op.lambda_target, rel_tol=1e-6)


def test_air_mass_per_cycle_matches_flow_rate_and_engine_speed(petrol_engine, mid_load_op, ambient, thermal_state):
    r = petrol_engine.evaluate(mid_load_op, ambient, thermal_state)
    n_r = 2.0  # four-stroke
    cycles_per_second = mid_load_op.rpm / 60.0 / n_r
    implied_flow = r.airflow.air_mass_per_cycle_kg * cycles_per_second
    assert math.isclose(implied_flow, r.airflow.air_mass_flow_kg_s, rel_tol=1e-9)
