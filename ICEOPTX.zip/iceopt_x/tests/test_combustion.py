import numpy as np
import pytest

from iceopt_x.combustion.burn_rate import WiebeParameters, mass_fraction_burned, timing_to_wiebe_params
from iceopt_x.combustion.combustion_efficiency import combustion_efficiency, hydrogen_combustion_efficiency


def test_wiebe_function_reaches_near_completion_by_end_of_duration():
    params = WiebeParameters(a=5.0, m=2.0, start_deg=-10.0, duration_deg=40.0)
    x_end = mass_fraction_burned(np.array([params.start_deg + params.duration_deg]), params)[0]
    # a=5 -> 1 - exp(-5) ~= 0.9933
    assert x_end == pytest.approx(1.0 - np.exp(-5.0), rel=1e-6)


def test_wiebe_function_is_zero_before_combustion_starts():
    params = WiebeParameters(start_deg=-10.0, duration_deg=40.0)
    x = mass_fraction_burned(np.array([-20.0]), params)[0]
    assert x == 0.0


def test_wiebe_function_is_monotonically_increasing():
    params = WiebeParameters(start_deg=-10.0, duration_deg=40.0)
    theta = np.linspace(-10.0, 30.0, 200)
    x = mass_fraction_burned(theta, params)
    assert np.all(np.diff(x) >= -1e-12)


def test_timing_to_wiebe_maps_btdc_timing_to_negative_start_angle():
    params = timing_to_wiebe_params(ignition_or_injection_timing_btdc_deg=15.0, base_duration_deg=40.0, rpm=2000)
    assert params.start_deg == -15.0


def test_combustion_efficiency_peaks_near_stoichiometric():
    eta_stoich = combustion_efficiency(1.0, is_compression_ignition=False)
    eta_rich = combustion_efficiency(0.7, is_compression_ignition=False)
    eta_lean = combustion_efficiency(1.4, is_compression_ignition=False)
    assert eta_stoich >= eta_rich
    assert eta_stoich >= eta_lean
    assert 0.0 <= eta_rich <= 1.0
    assert 0.0 <= eta_lean <= 1.0


def test_hydrogen_combustion_efficiency_stays_high_across_wide_lambda_range():
    for lam in [0.8, 1.0, 1.3, 1.6]:
        eta = hydrogen_combustion_efficiency(lam)
        assert eta > 0.85


def test_full_combustion_event_produces_physically_ordered_pressures(petrol_engine, mid_load_op, ambient, thermal_state):
    r = petrol_engine.evaluate(mid_load_op, ambient, thermal_state)
    c = r.combustion
    ivc_pressure_bar = r.manifold_pressure_kpa / 100.0
    assert c.peak_cylinder_pressure_bar > ivc_pressure_bar  # combustion must raise pressure above intake
    assert c.peak_temperature_k > mid_load_op.intake_temperature_k
    assert 0.0 < c.combustion_efficiency <= 1.0
    assert c.burn_duration_deg > 0
