"""
Section 29: regression cases anchored to plausible, published-order-of-
magnitude operating points for common engine classes. These are sanity
bounds (the model is not calibrated to any one real engine's dyno
sheet), not a claim of measured accuracy -- see README "Validation
philosophy". If a future change moves these numbers outside
well-established real-world engineering ranges, that is a signal
something broke, not a coincidence to "fix" by loosening the bounds.
"""
from iceopt_x.core.state import OperatingPoint


def test_turbo_petrol_midload_point_is_in_plausible_range(petrol_engine, ambient, thermal_state):
    op = OperatingPoint(rpm=3500, load_fraction=0.6, boost_pressure_kpa=60.0, lambda_target=1.05, ignition_timing_btdc_deg=16.0)
    r = petrol_engine.evaluate(op, ambient, thermal_state)

    # Modern turbo-petrol road engines: BSFC roughly 190-320 g/kWh, brake
    # thermal efficiency roughly 25-45% away from their single best point.
    assert 150.0 < r.efficiency.bsfc_g_per_kwh < 400.0
    assert 0.20 < r.efficiency.brake_thermal_efficiency < 0.50
    assert r.brake_power_kw > 0
    assert r.brake_torque_nm > 0


def test_diesel_has_higher_peak_efficiency_than_petrol_at_comparable_conditions(petrol_engine, diesel_engine, ambient, thermal_state):
    petrol_op = OperatingPoint(rpm=2500, load_fraction=0.5, boost_pressure_kpa=40.0, lambda_target=1.0, ignition_timing_btdc_deg=18.0)
    diesel_op = OperatingPoint(rpm=2200, load_fraction=0.5, boost_pressure_kpa=60.0, lambda_target=1.5, injection_timing_btdc_deg=10.0)

    r_petrol = petrol_engine.evaluate(petrol_op, ambient, thermal_state)
    r_diesel = diesel_engine.evaluate(diesel_op, ambient, thermal_state)

    # Diesel's higher compression ratio and unthrottled, lean operation
    # is a textbook-level efficiency advantage over SI (Heywood Ch.1).
    assert r_diesel.efficiency.brake_thermal_efficiency > r_petrol.efficiency.brake_thermal_efficiency


def test_diesel_bsfc_is_in_plausible_range(diesel_engine, ambient, thermal_state):
    op = OperatingPoint(rpm=2000, load_fraction=0.6, boost_pressure_kpa=80.0, lambda_target=1.4, injection_timing_btdc_deg=9.0)
    r = diesel_engine.evaluate(op, ambient, thermal_state)
    # Modern turbo-diesel: BSFC roughly 180-260 g/kWh near the efficient region
    assert 160.0 < r.efficiency.bsfc_g_per_kwh < 320.0


def test_idle_point_produces_low_but_positive_power(petrol_engine, ambient, thermal_state):
    op = OperatingPoint(rpm=800, load_fraction=0.05, boost_pressure_kpa=0.0)
    r = petrol_engine.evaluate(op, ambient, thermal_state)
    assert 0.0 <= r.brake_power_kw < 15.0
