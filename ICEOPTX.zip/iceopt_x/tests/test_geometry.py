import math

from iceopt_x.core.state import EngineGeometry, StrokeCycle
from iceopt_x.engine.displacement import (
    clearance_volume_m3,
    mean_piston_speed_m_s,
    swept_volume_m3,
    total_displacement_cc,
)
from iceopt_x.engine.kinematics import instantaneous_cylinder_volume_m3
import numpy as np


def make_2p0l_geometry() -> EngineGeometry:
    return EngineGeometry(
        cylinder_count=4, bore_m=0.086, stroke_m=0.086, rod_length_m=0.145,
        compression_ratio=10.5, valve_area_m2=0.0011, stroke_cycle=StrokeCycle.FOUR_STROKE,
    )


def test_total_displacement_matches_known_2_litre_engine():
    geometry = make_2p0l_geometry()
    disp_cc = total_displacement_cc(geometry)
    # bore=stroke=86mm, 4 cylinders -> ~1998cc, the well-known "2.0L" reference engine geometry
    assert 1950 < disp_cc < 2050


def test_clearance_volume_consistent_with_compression_ratio():
    geometry = make_2p0l_geometry()
    v_s = swept_volume_m3(geometry)
    v_c = clearance_volume_m3(geometry)
    # by definition, r_c = (V_s + V_c) / V_c
    r_c = (v_s + v_c) / v_c
    assert math.isclose(r_c, geometry.compression_ratio, rel_tol=1e-9)


def test_mean_piston_speed_scales_linearly_with_rpm():
    geometry = make_2p0l_geometry()
    sp_1000 = mean_piston_speed_m_s(geometry, 1000)
    sp_2000 = mean_piston_speed_m_s(geometry, 2000)
    assert math.isclose(sp_2000, 2.0 * sp_1000, rel_tol=1e-9)


def test_cylinder_volume_at_tdc_equals_clearance_volume():
    geometry = make_2p0l_geometry()
    v_tdc = instantaneous_cylinder_volume_m3(geometry, np.array([0.0]))[0]
    assert math.isclose(v_tdc, clearance_volume_m3(geometry), rel_tol=1e-6)


def test_cylinder_volume_at_bdc_equals_total_volume():
    geometry = make_2p0l_geometry()
    v_bdc = instantaneous_cylinder_volume_m3(geometry, np.array([math.pi]))[0]
    expected = clearance_volume_m3(geometry) + swept_volume_m3(geometry)
    assert math.isclose(v_bdc, expected, rel_tol=1e-6)


def test_rod_length_must_exceed_half_stroke():
    import pytest
    from pydantic import ValidationError

    with pytest.raises(ValidationError):
        EngineGeometry(
            cylinder_count=4, bore_m=0.086, stroke_m=0.086, rod_length_m=0.03,  # too short
            compression_ratio=10.5, valve_area_m2=0.0011,
        )
