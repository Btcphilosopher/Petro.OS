"""
Section 29: energy conservation tests.

ICEOPT-X assembles brake power, wall heat, and exhaust heat from
several independently-validated engineering correlations (Woschni,
Chen-Flynn, a compressor/turbine shaft balance, ...) rather than one
jointly-fitted model, so the energy ledger is not expected to close to
machine precision -- see core.engine's module docstring and
README "Validation philosophy". This test asserts it closes to within
an honest engineering tolerance and, critically, that every term is
non-negative and the ledger does not silently drop a whole category.
"""
import itertools

import pytest


OPERATING_POINTS = [
    dict(rpm=2000, load_fraction=0.3, boost_pressure_kpa=20.0, lambda_target=1.0, ignition_timing_btdc_deg=20.0),
    dict(rpm=3500, load_fraction=0.6, boost_pressure_kpa=60.0, lambda_target=1.05, ignition_timing_btdc_deg=16.0),
    dict(rpm=5000, load_fraction=0.9, boost_pressure_kpa=100.0, lambda_target=0.92, ignition_timing_btdc_deg=12.0),
]


@pytest.mark.parametrize("op_kwargs", OPERATING_POINTS)
def test_energy_balance_closes_within_engineering_tolerance(petrol_engine, ambient, thermal_state, op_kwargs):
    from iceopt_x.core.state import OperatingPoint

    op = OperatingPoint(**op_kwargs)
    r = petrol_engine.evaluate(op, ambient, thermal_state)
    eb = r.energy_balance

    assert eb.fuel_energy_kw > 0
    assert abs(eb.residual_fraction) < 0.20, f"energy balance residual too large: {eb.residual_fraction:.3f}"


@pytest.mark.parametrize("op_kwargs", OPERATING_POINTS)
def test_every_energy_term_is_non_negative(petrol_engine, ambient, thermal_state, op_kwargs):
    from iceopt_x.core.state import OperatingPoint

    op = OperatingPoint(**op_kwargs)
    r = petrol_engine.evaluate(op, ambient, thermal_state)
    eb = r.energy_balance

    for name, value in [
        ("brake_power_kw", eb.brake_power_kw),
        ("exhaust_heat_kw", eb.exhaust_heat_kw),
        ("coolant_heat_kw", eb.coolant_heat_kw),
        ("oil_radiative_heat_kw", eb.oil_radiative_heat_kw),
        ("friction_heat_kw", eb.friction_heat_kw),
        ("pumping_heat_kw", eb.pumping_heat_kw),
        ("combustion_loss_kw", eb.combustion_loss_kw),
    ]:
        assert value >= 0, f"{name} went negative: {value}"


def test_wall_heat_loss_is_self_consistent_with_combustion_cycle(petrol_engine, mid_load_op, ambient, thermal_state):
    """The wall heat loss reported in the thermal balance must come
    directly from the same crank-resolved cycle that produced the
    indicated work (core.engine's design note) -- not a second,
    independently-derived Woschni estimate."""
    r = petrol_engine.evaluate(mid_load_op, ambient, thermal_state)
    n_r = 2.0
    cycles_per_second = mid_load_op.rpm / 60.0 / n_r
    expected_kw = (
        r.combustion.wall_heat_loss_j * petrol_engine.model.geometry.cylinder_count * cycles_per_second / 1000.0
    )
    assert r.thermal_balance.wall_heat_loss_kw == pytest.approx(expected_kw, rel=1e-9)


def test_combustion_loss_matches_1_minus_combustion_efficiency(petrol_engine, mid_load_op, ambient, thermal_state):
    r = petrol_engine.evaluate(mid_load_op, ambient, thermal_state)
    expected = r.energy_balance.fuel_energy_kw * (1.0 - r.combustion.combustion_efficiency)
    assert r.energy_balance.combustion_loss_kw == pytest.approx(expected, rel=1e-6)
