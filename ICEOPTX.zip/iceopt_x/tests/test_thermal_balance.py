import pytest


def test_thermal_balance_terms_are_positive(petrol_engine, mid_load_op, ambient, thermal_state):
    r = petrol_engine.evaluate(mid_load_op, ambient, thermal_state)
    tb = r.thermal_balance
    assert tb.wall_heat_loss_kw > 0
    assert tb.coolant_heat_kw > 0
    assert tb.oil_heat_kw > 0
    assert tb.radiative_misc_loss_kw > 0


def test_coolant_and_oil_split_sums_to_wall_heat(petrol_engine, mid_load_op, ambient, thermal_state):
    r = petrol_engine.evaluate(mid_load_op, ambient, thermal_state)
    tb = r.thermal_balance
    assert tb.coolant_heat_kw + tb.oil_heat_kw == pytest.approx(tb.wall_heat_loss_kw, rel=1e-9)


def test_higher_load_increases_wall_heat_loss(petrol_engine, ambient, thermal_state):
    from iceopt_x.core.state import OperatingPoint

    low = petrol_engine.evaluate(OperatingPoint(rpm=3000, load_fraction=0.2, boost_pressure_kpa=10.0), ambient, thermal_state)
    high = petrol_engine.evaluate(OperatingPoint(rpm=3000, load_fraction=0.9, boost_pressure_kpa=10.0), ambient, thermal_state)
    assert high.thermal_balance.wall_heat_loss_kw > low.thermal_balance.wall_heat_loss_kw
