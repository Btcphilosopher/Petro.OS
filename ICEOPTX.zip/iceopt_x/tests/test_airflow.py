import pytest

from iceopt_x.core.state import AmbientConditions
from iceopt_x.intake.manifold import air_density_kg_m3
from iceopt_x.intake.volumetric_efficiency import volumetric_efficiency


def test_air_density_matches_ideal_gas_law_at_sea_level():
    rho = air_density_kg_m3(101.325, 288.15)
    # Standard sea-level dry air density ~1.225 kg/m^3
    assert 1.20 < rho < 1.25


def test_boost_increases_volumetric_efficiency(petrol_model):
    ve_na = volumetric_efficiency(petrol_model.geometry, 3500, 0.7, boost_pressure_kpa=0.0)
    ve_boosted = volumetric_efficiency(petrol_model.geometry, 3500, 0.7, boost_pressure_kpa=100.0)
    assert ve_boosted > ve_na


def test_calibration_multiplier_scales_ve_linearly(petrol_model):
    ve = volumetric_efficiency(petrol_model.geometry, 3500, 0.5, 0.0)
    ve_calibrated = volumetric_efficiency(petrol_model.geometry, 3500, 0.5, 0.0, calibration_multiplier=1.05)
    assert ve_calibrated == pytest.approx(ve * 1.05)


def test_airflow_scales_with_load_for_naturally_aspirated_si(petrol_engine, ambient, thermal_state):
    from iceopt_x.core.state import OperatingPoint

    low = petrol_engine.evaluate(OperatingPoint(rpm=3000, load_fraction=0.2, boost_pressure_kpa=0.0), ambient, thermal_state)
    high = petrol_engine.evaluate(OperatingPoint(rpm=3000, load_fraction=0.9, boost_pressure_kpa=0.0), ambient, thermal_state)
    assert high.airflow.air_mass_flow_kg_s > low.airflow.air_mass_flow_kg_s
