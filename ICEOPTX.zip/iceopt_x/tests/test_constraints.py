from iceopt_x.core.state import ConstraintLimits, OperatingPoint
from iceopt_x.optimisation.constraints import describe_violations, feasibility_penalty, is_feasible


def test_extreme_lambda_is_rejected(petrol_engine, ambient, thermal_state):
    op = OperatingPoint(rpm=3000, load_fraction=0.5, lambda_target=1.95)  # far outside default [0.75, 1.6], within the pydantic hard cap of 2.0
    r = petrol_engine.evaluate(op, ambient, thermal_state)
    assert not is_feasible(r)
    assert any("lambda" in v for v in describe_violations(r))


def test_overspeed_rpm_is_rejected(petrol_engine, ambient, thermal_state):
    op = OperatingPoint(rpm=9000, load_fraction=0.5)  # default max_rpm is 6500
    r = petrol_engine.evaluate(op, ambient, thermal_state)
    assert not is_feasible(r)


def test_reasonable_part_load_point_is_feasible(petrol_engine, ambient, thermal_state):
    op = OperatingPoint(rpm=2000, load_fraction=0.2, boost_pressure_kpa=0.0, lambda_target=1.15, ignition_timing_btdc_deg=24.0)
    r = petrol_engine.evaluate(op, ambient, thermal_state)
    assert is_feasible(r)
    assert feasibility_penalty(r) == 0.0


def test_tighter_constraint_limits_reject_previously_feasible_point(petrol_model, ambient, thermal_state):
    from iceopt_x.core.engine import Engine

    tight_limits = ConstraintLimits(max_boost_kpa=10.0)  # much tighter than default
    tight_model = petrol_model.model_copy(update={"constraints": tight_limits})
    engine = Engine(tight_model)

    op = OperatingPoint(rpm=3000, load_fraction=0.5, boost_pressure_kpa=50.0)
    r = engine.evaluate(op, ambient, thermal_state)
    assert not is_feasible(r)
    assert any("boost" in v for v in describe_violations(r))


def test_feasibility_penalty_grows_with_violation_severity(petrol_engine, ambient, thermal_state):
    mild = petrol_engine.evaluate(OperatingPoint(rpm=3000, load_fraction=0.5, lambda_target=1.62), ambient, thermal_state)
    severe = petrol_engine.evaluate(OperatingPoint(rpm=3000, load_fraction=0.5, lambda_target=1.95), ambient, thermal_state)
    assert feasibility_penalty(severe) > feasibility_penalty(mild)
