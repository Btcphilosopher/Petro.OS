from iceopt_x.optimisation.marginal_gain import rank_marginal_gains
from iceopt_x.optimisation.optimizer import GlobalOptimizer
from iceopt_x.optimisation.pareto import build_pareto_frontier


def test_optimizer_returns_a_feasible_result(petrol_engine, ambient):
    optimizer = GlobalOptimizer(petrol_engine)
    result = optimizer.optimize(rpm=3000, load_fraction=0.5, objective="brake_thermal_efficiency", ambient=ambient, maxiter=15, popsize=8)
    assert result.evaluation.is_feasible
    assert 0.0 < result.objective_value < 0.60  # sane efficiency bound


def test_optimizer_bsfc_objective_minimises_bsfc(petrol_engine, ambient):
    optimizer = GlobalOptimizer(petrol_engine)
    result = optimizer.optimize(rpm=3000, load_fraction=0.5, objective="bsfc_g_per_kwh", ambient=ambient, maxiter=15, popsize=8)
    assert result.evaluation.efficiency.bsfc_g_per_kwh < 400  # comfortably below a badly-tuned baseline


def test_optimizer_respects_constraint_envelope(petrol_engine, ambient):
    optimizer = GlobalOptimizer(petrol_engine)
    result = optimizer.optimize(rpm=5500, load_fraction=1.0, objective="brake_power_kw", ambient=ambient, maxiter=20, popsize=10)
    assert result.evaluation.is_feasible
    assert len(result.evaluation.constraint_violations) == 0


def test_pareto_frontier_is_non_dominated(petrol_engine, ambient, thermal_state):
    frontier = build_pareto_frontier(
        petrol_engine, rpm=3500, load_fraction=0.6, objectives=["power_kw", "brake_thermal_efficiency"],
        ambient=ambient, thermal_state=thermal_state, n_lambda=4, n_timing=4, n_boost=3,
    )
    assert len(frontier) >= 1
    # no point in the frontier should be dominated by another point in the frontier
    for i, p in enumerate(frontier):
        for j, q in enumerate(frontier):
            if i == j:
                continue
            at_least_as_good = all(q.objectives[k] >= p.objectives[k] for k in p.objectives)
            strictly_better = any(q.objectives[k] > p.objectives[k] for k in p.objectives)
            assert not (at_least_as_good and strictly_better)


def test_marginal_gain_ranking_is_sorted_descending(petrol_engine, mid_load_op, ambient, thermal_state):
    ranking = rank_marginal_gains(petrol_engine, mid_load_op, ambient, thermal_state)
    deltas = [r.delta for r in ranking]
    assert deltas == sorted(deltas, reverse=True)
    assert len(ranking) == 7  # the 7 canonical Section 23 interventions
