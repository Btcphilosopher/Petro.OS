"""tests subpackage of ICEOPT-X."""
