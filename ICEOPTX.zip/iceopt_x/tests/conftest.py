"""Shared pytest fixtures for the ICEOPT-X test suite."""
from __future__ import annotations

import pytest

from iceopt_x.combustion.fuel import FuelType
from iceopt_x.core.engine import Engine
from iceopt_x.core.state import AmbientConditions, OperatingPoint, ThermalState
from iceopt_x.engine.engine_model import (
    EngineModel,
    default_geometry_2p0l_turbo_petrol,
    default_geometry_2p2l_diesel,
)


@pytest.fixture
def petrol_model() -> EngineModel:
    return EngineModel.from_fuel_type("test 2.0T petrol", default_geometry_2p0l_turbo_petrol(), FuelType.PETROL)


@pytest.fixture
def diesel_model() -> EngineModel:
    return EngineModel.from_fuel_type("test 2.2 diesel", default_geometry_2p2l_diesel(), FuelType.DIESEL)


@pytest.fixture
def petrol_engine(petrol_model) -> Engine:
    return Engine(petrol_model)


@pytest.fixture
def diesel_engine(diesel_model) -> Engine:
    return Engine(diesel_model)


@pytest.fixture
def ambient() -> AmbientConditions:
    return AmbientConditions()


@pytest.fixture
def thermal_state() -> ThermalState:
    return ThermalState()


@pytest.fixture
def mid_load_op() -> OperatingPoint:
    return OperatingPoint(
        rpm=3500,
        load_fraction=0.6,
        boost_pressure_kpa=60.0,
        lambda_target=1.05,
        ignition_timing_btdc_deg=16.0,
    )
