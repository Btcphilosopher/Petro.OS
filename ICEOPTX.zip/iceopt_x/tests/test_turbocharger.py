import pytest

from iceopt_x.intake.turbo import compressor_outlet_state, solve_shaft_balance, turbine_extraction_state


def test_compressor_raises_temperature_with_pressure_ratio():
    low_pr = compressor_outlet_state(298.15, 101.325, 1.3, 0.1)
    high_pr = compressor_outlet_state(298.15, 101.325, 2.2, 0.1)
    assert high_pr.outlet_temperature_k > low_pr.outlet_temperature_k > 298.15


def test_compressor_efficiency_calibration_multiplier_changes_outlet_temp():
    baseline = compressor_outlet_state(298.15, 101.325, 1.8, 0.1, efficiency_calibration_multiplier=1.0)
    improved = compressor_outlet_state(298.15, 101.325, 1.8, 0.1, efficiency_calibration_multiplier=1.05)
    # a more efficient compressor produces a lower outlet temperature for the same pressure ratio
    assert improved.outlet_temperature_k < baseline.outlet_temperature_k


def test_turbine_extracts_positive_work_and_cools_the_gas():
    result = turbine_extraction_state(1000.0, 1.6, 0.1)
    assert result.power_kw > 0
    assert result.outlet_temperature_k < 1000.0


def test_shaft_balance_finds_an_expansion_ratio_that_meets_compressor_demand():
    compressor = compressor_outlet_state(298.15, 101.325, 1.8, 0.09)
    turbine = solve_shaft_balance(compressor, turbine_inlet_temperature_k=950.0, exhaust_mass_flow_kg_s=0.10)
    assert turbine.expansion_ratio > 1.0
    # power should very nearly balance (mechanical_efficiency default 0.97)
    assert turbine.power_kw == pytest.approx(compressor.power_kw / 0.97, rel=0.05)


def test_turbocharged_engine_delivers_more_torque_than_naturally_aspirated_equivalent(petrol_engine, ambient, thermal_state):
    from iceopt_x.core.state import OperatingPoint

    boosted = petrol_engine.evaluate(
        OperatingPoint(rpm=3500, load_fraction=0.7, boost_pressure_kpa=100.0), ambient, thermal_state
    )
    unboosted = petrol_engine.evaluate(
        OperatingPoint(rpm=3500, load_fraction=0.7, boost_pressure_kpa=0.0), ambient, thermal_state
    )
    assert boosted.brake_torque_nm > unboosted.brake_torque_nm
    assert boosted.compressor is not None
    assert boosted.turbine is not None
