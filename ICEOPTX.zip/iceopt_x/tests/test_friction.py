from iceopt_x.mechanical.friction import chen_flynn_fmep_kpa, oil_viscosity_correction
from iceopt_x.thermal.oil import oil_dynamic_viscosity_pa_s


def test_fmep_increases_with_mean_piston_speed():
    fmep_low = chen_flynn_fmep_kpa(peak_cylinder_pressure_kpa=8000, mean_piston_speed_m_s_=8.0)
    fmep_high = chen_flynn_fmep_kpa(peak_cylinder_pressure_kpa=8000, mean_piston_speed_m_s_=16.0)
    assert fmep_high > fmep_low


def test_fmep_increases_with_peak_pressure():
    fmep_low = chen_flynn_fmep_kpa(peak_cylinder_pressure_kpa=6000, mean_piston_speed_m_s_=12.0)
    fmep_high = chen_flynn_fmep_kpa(peak_cylinder_pressure_kpa=12000, mean_piston_speed_m_s_=12.0)
    assert fmep_high > fmep_low


def test_oil_viscosity_drops_with_temperature():
    mu_cold = oil_dynamic_viscosity_pa_s(298.15)
    mu_hot = oil_dynamic_viscosity_pa_s(363.15)
    assert mu_hot < mu_cold


def test_viscosity_correction_increases_friction_when_oil_is_cold():
    corr_cold = oil_viscosity_correction(oil_dynamic_viscosity_pa_s(288.15))
    corr_hot = oil_viscosity_correction(oil_dynamic_viscosity_pa_s(363.15))
    assert corr_cold > corr_hot


def test_cold_oil_increases_overall_friction_power(petrol_engine, mid_load_op, ambient):
    from iceopt_x.core.state import ThermalState

    cold = petrol_engine.evaluate(mid_load_op, ambient, ThermalState(oil_temp_k=283.15))
    hot = petrol_engine.evaluate(mid_load_op, ambient, ThermalState(oil_temp_k=363.15))
    assert cold.mechanical.total_friction_power_kw > hot.mechanical.total_friction_power_kw
