import math

import pytest


def test_power_equals_torque_times_angular_velocity(petrol_engine, mid_load_op, ambient, thermal_state):
    r = petrol_engine.evaluate(mid_load_op, ambient, thermal_state)
    omega = mid_load_op.rpm * 2.0 * math.pi / 60.0
    implied_power_kw = r.brake_torque_nm * omega / 1000.0
    assert implied_power_kw == pytest.approx(r.brake_power_kw, rel=1e-9)


def test_brake_power_never_exceeds_indicated_power(petrol_engine, mid_load_op, ambient, thermal_state):
    r = petrol_engine.evaluate(mid_load_op, ambient, thermal_state)
    assert r.brake_power_kw <= r.indicated_power_kw + 1e-9


def test_fmep_equals_imep_minus_bmep(petrol_engine, mid_load_op, ambient, thermal_state):
    r = petrol_engine.evaluate(mid_load_op, ambient, thermal_state)
    assert r.mechanical.fmep_check_kpa == pytest.approx(r.mechanical.fmep_kpa, rel=1e-6)


def test_mechanical_loss_breakdown_sums_to_total(petrol_engine, mid_load_op, ambient, thermal_state):
    r = petrol_engine.evaluate(mid_load_op, ambient, thermal_state)
    m = r.mechanical
    total_breakdown = m.piston_rings_kw + m.valvetrain_kw + m.bearings_kw + m.oil_pump_kw + m.accessories_kw
    assert total_breakdown == pytest.approx(m.total_friction_power_kw, rel=1e-6)


def test_torque_increases_with_load_at_fixed_rpm(petrol_engine, ambient, thermal_state):
    from iceopt_x.core.state import OperatingPoint

    low = petrol_engine.evaluate(OperatingPoint(rpm=3000, load_fraction=0.2, boost_pressure_kpa=10.0), ambient, thermal_state)
    high = petrol_engine.evaluate(OperatingPoint(rpm=3000, load_fraction=0.8, boost_pressure_kpa=10.0), ambient, thermal_state)
    assert high.brake_torque_nm > low.brake_torque_nm
