"""mechanical subpackage of ICEOPT-X."""
