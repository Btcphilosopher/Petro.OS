"""
mechanical.bearings
=====================

Journal-bearing friction contribution (Section 14), via a Petroff-law
hydrodynamic friction estimate: PHYSICS MODEL for the functional form,
EMPIRICAL for the specific geometric constants.
"""
from __future__ import annotations


def petroff_friction_power_kw(
    oil_viscosity_pa_s: float,
    rpm: float,
    journal_diameter_m: float = 0.052,
    journal_length_m: float = 0.022,
    radial_clearance_m: float = 30e-6,
    bearing_count: int = 5,
) -> float:
    """Petroff's equation for hydrodynamic journal-bearing friction
    torque: T = 2*pi^2 * mu * N * r^3 * L / c, N in rev/s. Summed over
    main + big-end bearings (bearing_count)."""
    import math

    n_rev_s = rpm / 60.0
    r = journal_diameter_m / 2.0
    torque_per_bearing_nm = (
        2.0 * math.pi**2 * oil_viscosity_pa_s * n_rev_s * r**3 * journal_length_m / max(radial_clearance_m, 1e-6)
    )
    total_torque_nm = torque_per_bearing_nm * bearing_count
    omega = 2.0 * math.pi * n_rev_s
    power_w = total_torque_nm * omega
    return power_w / 1000.0
