"""
mechanical.crankshaft
=======================

PHYSICS MODEL: torque/power conversion, and the fundamental relation
tying indicated work to torque and power (Section 13).
"""
from __future__ import annotations

import math


def torque_from_mean_effective_pressure_nm(mep_kpa: float, total_displacement_m3: float, revolutions_per_power_stroke: float) -> float:
    """T = MEP * V_d / (2*pi*n_r), n_r = 2 for 4-stroke, 1 for 2-stroke.
    (Standard MEP definition: work per cycle = MEP * V_d; work per
    revolution = work per cycle / n_r; T = work per revolution / (2*pi).)"""
    work_per_cycle_j = mep_kpa * 1000.0 * total_displacement_m3
    work_per_revolution_j = work_per_cycle_j / revolutions_per_power_stroke
    return work_per_revolution_j / (2.0 * math.pi)


def power_from_torque_kw(torque_nm: float, rpm: float) -> float:
    """P = T * omega."""
    omega = rpm * 2.0 * math.pi / 60.0
    return torque_nm * omega / 1000.0


def mep_from_power_kpa(power_kw: float, rpm: float, total_displacement_m3: float, revolutions_per_power_stroke: float) -> float:
    """Inverse relation, useful for reporting BMEP/IMEP from a computed
    power figure."""
    cycles_per_second = rpm / 60.0 / revolutions_per_power_stroke
    work_per_cycle_j = power_kw * 1000.0 / cycles_per_second
    return work_per_cycle_j / (1000.0 * total_displacement_m3)
