"""
mechanical.mechanical_losses
==============================

Section 13/14: separate indicated power from brake power, and break the
total mechanical loss (FMEP) down into its physical contributors rather
than hiding it inside one arbitrary efficiency number.

    Brake Power = Indicated Power - Mechanical Losses

EMPIRICAL MODEL: total FMEP comes from the Chen-Flynn correlation
(mechanical.friction); it is then apportioned across rings, bearings,
valvetrain, oil pump and accessories using representative literature
fractions (Heywood Ch.13 friction breakdown for a modern SI engine),
which is a reasonable typical split rather than a component-resolved
measurement.
"""
from __future__ import annotations

from dataclasses import dataclass

from iceopt_x.core.state import EngineGeometry
from iceopt_x.mechanical.bearings import petroff_friction_power_kw
from iceopt_x.mechanical.friction import FrictionResult, compute_friction

# ASSUMPTION: representative breakdown fractions of total FMEP (sum to 1.0)
FRICTION_BREAKDOWN_FRACTIONS = {
    "piston_rings_and_skirt": 0.42,
    "valvetrain": 0.20,
    "bearings": 0.15,
    "oil_pump": 0.13,
    "accessories": 0.10,
}


@dataclass
class MechanicalLossBreakdown:
    fmep_kpa: float
    total_friction_power_kw: float
    piston_rings_kw: float
    valvetrain_kw: float
    bearings_kw: float
    oil_pump_kw: float
    accessories_kw: float
    bearings_petroff_estimate_kw: float  # independent cross-check via Petroff's law
    indicated_power_kw: float
    brake_power_kw: float
    imep_kpa: float
    bmep_kpa: float
    fmep_check_kpa: float


def compute_mechanical_losses(
    geometry: EngineGeometry,
    rpm: float,
    peak_cylinder_pressure_kpa: float,
    oil_viscosity_pa_s: float,
    total_displacement_m3: float,
    indicated_power_kw: float,
    imep_kpa: float,
    friction_calibration_multiplier: float = 1.0,
) -> MechanicalLossBreakdown:
    friction: FrictionResult = compute_friction(
        geometry, rpm, peak_cylinder_pressure_kpa, oil_viscosity_pa_s, total_displacement_m3, friction_calibration_multiplier
    )
    total_kw = friction.friction_power_kw

    breakdown = {k: total_kw * frac for k, frac in FRICTION_BREAKDOWN_FRACTIONS.items()}

    bearings_check_kw = petroff_friction_power_kw(oil_viscosity_pa_s, rpm)

    brake_power_kw = max(indicated_power_kw - total_kw, 0.0)
    bmep_kpa = imep_kpa - friction.fmep_kpa
    # Consistency identity: FMEP = IMEP - BMEP (should reproduce friction.fmep_kpa exactly)
    fmep_check_kpa = imep_kpa - bmep_kpa

    return MechanicalLossBreakdown(
        fmep_kpa=friction.fmep_kpa,
        total_friction_power_kw=total_kw,
        piston_rings_kw=breakdown["piston_rings_and_skirt"],
        valvetrain_kw=breakdown["valvetrain"],
        bearings_kw=breakdown["bearings"],
        oil_pump_kw=breakdown["oil_pump"],
        accessories_kw=breakdown["accessories"],
        bearings_petroff_estimate_kw=bearings_check_kw,
        indicated_power_kw=indicated_power_kw,
        brake_power_kw=brake_power_kw,
        imep_kpa=imep_kpa,
        bmep_kpa=bmep_kpa,
        fmep_check_kpa=fmep_check_kpa,
    )
