"""
mechanical.friction
=====================

Friction mean effective pressure (FMEP) via the Chen-Flynn correlation
(Section 14): a well-established, widely used engineering correlation
relating total engine friction to peak cylinder pressure and mean
piston speed.

EMPIRICAL MODEL: Chen & Flynn (1965), "Development of a Single Cylinder
Compression Ignition Research Engine". Coefficients here are
representative for a modern automotive engine (roller-finger valvetrain,
low-tension rings); a specific engine requires motoring-test
calibration (LEVEL 3/4 upgrade path).
"""
from __future__ import annotations

from dataclasses import dataclass

from iceopt_x.engine.displacement import mean_piston_speed_m_s
from iceopt_x.core.state import EngineGeometry

# Chen-Flynn constants: FMEP = A + B*Pmax + C*Vp + D*Vp^2  [kPa]
CHEN_FLYNN_A_KPA = 25.0    # constant term (accessories, base friction)
CHEN_FLYNN_B = 0.0090      # coefficient on peak cylinder pressure [-]
CHEN_FLYNN_C_KPA_S_M = 0.070  # coefficient on mean piston speed [kPa / (m/s)]
CHEN_FLYNN_D_KPA_S2_M2 = 0.0135  # coefficient on mean piston speed^2 [kPa / (m/s)^2]


def oil_viscosity_correction(oil_viscosity_pa_s: float, reference_viscosity_pa_s: float = 0.010) -> float:
    """EMPIRICAL MODEL: friction scales sub-linearly with oil viscosity
    ratio (hydrodynamic friction ~ sqrt(mu) for many bearing regimes)."""
    ratio = max(oil_viscosity_pa_s / reference_viscosity_pa_s, 0.05)
    return ratio**0.5


@dataclass
class FrictionResult:
    fmep_kpa: float
    friction_power_kw: float
    viscosity_correction: float


def chen_flynn_fmep_kpa(
    peak_cylinder_pressure_kpa: float,
    mean_piston_speed_m_s_: float,
) -> float:
    return (
        CHEN_FLYNN_A_KPA
        + CHEN_FLYNN_B * peak_cylinder_pressure_kpa
        + CHEN_FLYNN_C_KPA_S_M * mean_piston_speed_m_s_
        + CHEN_FLYNN_D_KPA_S2_M2 * mean_piston_speed_m_s_**2
    )


def compute_friction(
    geometry: EngineGeometry,
    rpm: float,
    peak_cylinder_pressure_kpa: float,
    oil_viscosity_pa_s: float,
    total_displacement_m3: float,
    friction_calibration_multiplier: float = 1.0,
) -> FrictionResult:
    sp = mean_piston_speed_m_s(geometry, rpm)
    fmep_base = chen_flynn_fmep_kpa(peak_cylinder_pressure_kpa, sp)
    visc_corr = oil_viscosity_correction(oil_viscosity_pa_s)
    fmep = fmep_base * visc_corr * friction_calibration_multiplier

    from iceopt_x.engine.displacement import revolutions_per_power_stroke

    n_r = revolutions_per_power_stroke(geometry)
    cycles_per_second = rpm / 60.0 / n_r
    friction_work_per_cycle_j = fmep * 1000.0 * total_displacement_m3
    friction_power_kw = friction_work_per_cycle_j * cycles_per_second / 1000.0

    return FrictionResult(fmep_kpa=fmep, friction_power_kw=friction_power_kw, viscosity_correction=visc_corr)
