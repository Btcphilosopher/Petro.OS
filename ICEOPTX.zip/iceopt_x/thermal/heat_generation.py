"""
thermal.heat_generation
=========================

In-cylinder wall heat transfer (Section 15). This is what actually
splits the released combustion heat between "stays in the gas -> does
work / leaves as exhaust enthalpy" and "leaves through the cylinder
walls -> coolant/oil".

EMPIRICAL MODEL: Woschni (1967) convective heat-transfer correlation --
the standard engineering correlation for in-cylinder heat transfer,
calibrated against a broad range of engines but not this specific one.
"""
from __future__ import annotations

import math

from iceopt_x.core.state import EngineGeometry
from iceopt_x.engine.displacement import mean_piston_speed_m_s

WOSCHNI_C1 = 2.28  # PHYSICS-CALIBRATED: standard Woschni constants (compression/expansion, no swirl)
WOSCHNI_C2 = 0.00324


def woschni_heat_transfer_coefficient_w_m2k(
    cylinder_pressure_kpa: float,
    cylinder_gas_temp_k: float,
    bore_m: float,
    mean_piston_speed_m_s_: float,
) -> float:
    """h = 3.26 * B^-0.2 * P^0.8 * T^-0.55 * w^0.8  (Woschni correlation,
    SI units with P in kPa, B in m, T in K, w in m/s -- this is the
    widely used engineering form)."""
    p = max(cylinder_pressure_kpa, 1.0)
    t = max(cylinder_gas_temp_k, 1.0)
    w = max(mean_piston_speed_m_s_, 0.1)
    return 3.26 * bore_m**-0.2 * p**0.8 * t**-0.55 * w**0.8


def cylinder_wall_heat_loss_kw(
    geometry: EngineGeometry,
    rpm: float,
    avg_cylinder_pressure_kpa: float,
    avg_cylinder_gas_temp_k: float,
    wall_temp_k: float,
    exposed_area_m2: float,
) -> float:
    """Q_dot_wall = h * A * (T_gas - T_wall), applied per cylinder then
    scaled by cylinder count. Uses cycle-averaged gas conditions as a
    representative state (a full crank-resolved integral would use the
    instantaneous h(theta), P(theta), T(theta) trace -- an available
    LEVEL-3 refinement)."""
    sp = mean_piston_speed_m_s(geometry, rpm)
    h = woschni_heat_transfer_coefficient_w_m2k(avg_cylinder_pressure_kpa, avg_cylinder_gas_temp_k, geometry.bore_m, sp)
    q_per_cyl_w = h * exposed_area_m2 * max(avg_cylinder_gas_temp_k - wall_temp_k, 0.0)
    return q_per_cyl_w * geometry.cylinder_count / 1000.0


def exposed_wall_area_estimate_m2(geometry: EngineGeometry) -> float:
    """ASSUMPTION: representative average in-cylinder exposed area
    (piston crown + head + a fraction of liner) ~ 2.3x the bore area,
    averaged across the cycle."""
    bore_area = math.pi / 4.0 * geometry.bore_m**2
    return 2.3 * bore_area
