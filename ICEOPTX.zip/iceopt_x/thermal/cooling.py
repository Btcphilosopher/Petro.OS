"""
thermal.cooling
=================

Coolant-side heat rejection and radiator capacity (Section 15).
PHYSICS MODEL: sensible heat balance on the coolant loop.
"""
from __future__ import annotations

from dataclasses import dataclass

CP_COOLANT_KJ_KGK = 3.7  # ASSUMPTION: ~50/50 water-glycol mixture


@dataclass
class CoolingResult:
    coolant_heat_rejected_kw: float
    coolant_outlet_temp_k: float
    radiator_effectiveness: float


def coolant_temperature_rise_k(heat_kw: float, coolant_mass_flow_kg_s: float) -> float:
    if coolant_mass_flow_kg_s <= 0:
        return 0.0
    return heat_kw / (coolant_mass_flow_kg_s * CP_COOLANT_KJ_KGK)


def radiator_heat_rejection_kw(
    coolant_inlet_temp_k: float,
    ambient_temp_k: float,
    coolant_mass_flow_kg_s: float,
    effectiveness: float = 0.55,
) -> CoolingResult:
    """effectiveness-NTU treatment of the radiator: rejects a fraction of
    the maximum possible (coolant cooled all the way to ambient)."""
    max_delta_t = max(coolant_inlet_temp_k - ambient_temp_k, 0.0)
    q = effectiveness * coolant_mass_flow_kg_s * CP_COOLANT_KJ_KGK * max_delta_t
    outlet_temp = coolant_inlet_temp_k - coolant_temperature_rise_k(q, coolant_mass_flow_kg_s)
    return CoolingResult(coolant_heat_rejected_kw=q, coolant_outlet_temp_k=outlet_temp, radiator_effectiveness=effectiveness)
