"""
thermal.cylinder_head
=======================

Lumped thermal mass of the cylinder head (Section 15). PHYSICS MODEL:
first-order lumped-capacitance thermal balance, dT/dt = (Q_in - Q_out)/C.
"""
from __future__ import annotations

HEAD_THERMAL_MASS_J_K_PER_CYL = 2800.0  # ASSUMPTION: representative aluminium head thermal capacitance per cylinder


def head_temperature_step_k(
    current_temp_k: float,
    heat_in_kw: float,
    heat_to_coolant_kw: float,
    dt_s: float,
    cylinder_count: int,
) -> float:
    thermal_mass = HEAD_THERMAL_MASS_J_K_PER_CYL * cylinder_count
    d_energy_j = (heat_in_kw - heat_to_coolant_kw) * 1000.0 * dt_s
    return current_temp_k + d_energy_j / thermal_mass
