"""
thermal.thermal_state
=======================

Complete thermal balance orchestrator (Section 15): takes the wall heat
loss already computed self-consistently inside the crank-resolved
combustion cycle (thermodynamics.cycle, Woschni-based) and splits it
into coolant / oil / radiative destinations.

Deliberately does NOT recompute wall heat transfer independently from a
separately-derived "average" cylinder state -- that would produce a
second, inconsistent estimate of the same physical quantity and break
the energy balance (Section 29/31). See thermal.heat_generation for a
standalone Woschni utility usable in contexts where no crank-resolved
cycle has been run (e.g. quick scenario screening).
"""
from __future__ import annotations

from dataclasses import dataclass

OIL_HEAT_FRACTION_OF_WALL_LOSS = 0.28  # ASSUMPTION: share of cylinder-wall heat picked up by oil (piston cooling jets, splash) vs coolant
RADIATIVE_MISC_LOSS_FRACTION = 0.03    # ASSUMPTION: radiation + convection from block/exhaust surfaces to ambient, off the fuel energy


@dataclass
class ThermalBalanceResult:
    wall_heat_loss_kw: float
    coolant_heat_kw: float
    oil_heat_kw: float
    radiative_misc_loss_kw: float
    coolant_outlet_temp_k: float


def compute_thermal_balance(
    wall_heat_loss_kw: float,
    coolant_inlet_temp_k: float,
    ambient_temp_k: float,
    fuel_energy_kw: float,
    coolant_mass_flow_kg_s: float = 0.5,
) -> ThermalBalanceResult:
    from iceopt_x.thermal.cooling import radiator_heat_rejection_kw

    q_oil = wall_heat_loss_kw * OIL_HEAT_FRACTION_OF_WALL_LOSS
    q_coolant_from_walls = wall_heat_loss_kw * (1.0 - OIL_HEAT_FRACTION_OF_WALL_LOSS)

    cooling = radiator_heat_rejection_kw(coolant_inlet_temp_k, ambient_temp_k, coolant_mass_flow_kg_s)

    q_radiative = fuel_energy_kw * RADIATIVE_MISC_LOSS_FRACTION

    return ThermalBalanceResult(
        wall_heat_loss_kw=wall_heat_loss_kw,
        coolant_heat_kw=q_coolant_from_walls,
        oil_heat_kw=q_oil,
        radiative_misc_loss_kw=q_radiative,
        coolant_outlet_temp_k=cooling.coolant_outlet_temp_k,
    )
