"""
thermal.block
==============

Lumped thermal mass of the engine block/liners (Section 15).
PHYSICS MODEL: first-order lumped-capacitance thermal balance.
"""
from __future__ import annotations

BLOCK_THERMAL_MASS_J_K_PER_CYL = 4200.0  # ASSUMPTION: representative cast-iron/aluminium block capacitance per cylinder


def block_temperature_step_k(
    current_temp_k: float,
    heat_in_kw: float,
    heat_to_coolant_kw: float,
    dt_s: float,
    cylinder_count: int,
) -> float:
    thermal_mass = BLOCK_THERMAL_MASS_J_K_PER_CYL * cylinder_count
    d_energy_j = (heat_in_kw - heat_to_coolant_kw) * 1000.0 * dt_s
    return current_temp_k + d_energy_j / thermal_mass
