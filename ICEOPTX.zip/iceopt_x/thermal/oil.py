"""
thermal.oil
============

Oil thermal state and viscosity model (Section 14/15).
PHYSICS MODEL: Vogel/Walther-style exponential viscosity-temperature
relation, EMPIRICAL for the specific calibration constants of a given
oil grade.
"""
from __future__ import annotations

import math

OIL_THERMAL_MASS_J_K = 3200.0  # ASSUMPTION: representative sump oil thermal capacitance (typical road-car sump volume)
CP_OIL_KJ_KGK = 2.0


def oil_dynamic_viscosity_pa_s(temperature_k: float, grade: str = "5W-30") -> float:
    """Vogel equation: mu = A * exp(B / (T - C)). EMPIRICAL MODEL:
    (A, B, C) below are illustrative constants tuned to give a
    representative 5W-30 viscosity of ~50 mPa.s at 40C and ~9.5 mPa.s at
    100C (typical SAE 5W-30 HTHS behaviour); swap in measured
    (A, B, C) for a specific oil for higher fidelity."""
    grade_constants = {
        "5W-30": (0.00006, 1200.0, 155.0),
        "0W-20": (0.00005, 1150.0, 150.0),
        "15W-40": (0.00009, 1300.0, 160.0),
    }
    a, b, c = grade_constants.get(grade, grade_constants["5W-30"])
    return a * math.exp(b / max(temperature_k - c, 1.0))


def oil_temperature_step_k(
    current_temp_k: float,
    heat_in_kw: float,
    heat_rejected_kw: float,
    dt_s: float,
) -> float:
    d_energy_j = (heat_in_kw - heat_rejected_kw) * 1000.0 * dt_s
    return current_temp_k + d_energy_j / OIL_THERMAL_MASS_J_K
