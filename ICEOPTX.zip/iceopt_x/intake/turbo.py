"""
intake.turbo
============

Turbocharger model: compressor, turbine, shaft, wastegate (Section 17).

PHYSICS MODEL: isentropic compression/expansion relations with
component efficiencies.
EMPIRICAL MODEL: efficiency values as a function of pressure ratio use a
simple peaked map (real turbos need supplier compressor/turbine maps).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

GAMMA_AIR = 1.4
CP_AIR_KJ_KGK = 1.005
CP_EXHAUST_KJ_KGK = 1.10  # ASSUMPTION: slightly higher than air due to CO2/H2O content


def compressor_isentropic_efficiency(pressure_ratio: float, calibration_multiplier: float = 1.0) -> float:
    """EMPIRICAL MODEL: peaked efficiency map, typical small automotive
    turbo compressor, peak ~78% near PR ~ 2.0. `calibration_multiplier`
    is the Section 23 marginal-gain hook ("+1% compressor efficiency")."""
    pr_peak = 2.0
    eta_peak = 0.78
    width = 1.3
    eta = eta_peak - 0.5 * ((pressure_ratio - pr_peak) / width) ** 2 * 0.30
    return float(np.clip(eta * calibration_multiplier, 0.35, 0.95))


def turbine_isentropic_efficiency(expansion_ratio: float, calibration_multiplier: float = 1.0) -> float:
    """EMPIRICAL MODEL: peaked efficiency map for radial turbine.
    `calibration_multiplier` is the Section 23 marginal-gain hook
    ("+1% turbine efficiency")."""
    er_peak = 1.8
    eta_peak = 0.72
    width = 1.2
    eta = eta_peak - 0.5 * ((expansion_ratio - er_peak) / width) ** 2 * 0.30
    return float(np.clip(eta * calibration_multiplier, 0.30, 0.92))


@dataclass
class CompressorResult:
    pressure_ratio: float
    outlet_temperature_k: float
    isentropic_efficiency: float
    specific_work_kj_kg: float
    power_kw: float


def compressor_outlet_state(
    inlet_temperature_k: float,
    inlet_pressure_kpa: float,
    pressure_ratio: float,
    air_mass_flow_kg_s: float,
    efficiency_calibration_multiplier: float = 1.0,
) -> CompressorResult:
    """Real (non-isentropic) compressor outlet temperature:
    T2 = T1 * (1 + (PR^((g-1)/g) - 1) / eta_c)
    """
    eta_c = compressor_isentropic_efficiency(pressure_ratio, efficiency_calibration_multiplier)
    t2s_ratio = pressure_ratio ** ((GAMMA_AIR - 1.0) / GAMMA_AIR)
    t2_real = inlet_temperature_k * (1.0 + (t2s_ratio - 1.0) / eta_c)
    specific_work = CP_AIR_KJ_KGK * (t2_real - inlet_temperature_k)  # kJ/kg
    power_kw = specific_work * air_mass_flow_kg_s
    return CompressorResult(
        pressure_ratio=pressure_ratio,
        outlet_temperature_k=t2_real,
        isentropic_efficiency=eta_c,
        specific_work_kj_kg=specific_work,
        power_kw=power_kw,
    )


@dataclass
class TurbineResult:
    expansion_ratio: float
    outlet_temperature_k: float
    isentropic_efficiency: float
    specific_work_kj_kg: float
    power_kw: float


def turbine_extraction_state(
    inlet_temperature_k: float,
    expansion_ratio: float,
    exhaust_mass_flow_kg_s: float,
    gamma_exhaust: float = 1.33,
    efficiency_calibration_multiplier: float = 1.0,
) -> TurbineResult:
    """Real turbine outlet temperature / extracted power:
    T4 = T3 * (1 - eta_t * (1 - (1/ER)^((g-1)/g)))
    """
    eta_t = turbine_isentropic_efficiency(expansion_ratio, efficiency_calibration_multiplier)
    t4s_ratio = 1.0 - (1.0 / expansion_ratio) ** ((gamma_exhaust - 1.0) / gamma_exhaust)
    t4_real = inlet_temperature_k * (1.0 - eta_t * t4s_ratio)
    specific_work = CP_EXHAUST_KJ_KGK * (inlet_temperature_k - t4_real)  # kJ/kg
    power_kw = specific_work * exhaust_mass_flow_kg_s
    return TurbineResult(
        expansion_ratio=expansion_ratio,
        outlet_temperature_k=t4_real,
        isentropic_efficiency=eta_t,
        specific_work_kj_kg=specific_work,
        power_kw=power_kw,
    )


def solve_shaft_balance(
    compressor: CompressorResult,
    turbine_inlet_temperature_k: float,
    exhaust_mass_flow_kg_s: float,
    mechanical_efficiency: float = 0.97,
    gamma_exhaust: float = 1.33,
    er_bounds: tuple[float, float] = (1.02, 4.0),
    turbine_efficiency_calibration_multiplier: float = 1.0,
) -> TurbineResult:
    """Find the turbine expansion ratio whose extracted (mechanical-loss
    adjusted) power matches the compressor power demand -- i.e. shaft
    power balance at steady state (Section 17)."""
    from scipy.optimize import brentq

    target_power = compressor.power_kw / mechanical_efficiency

    def residual(er: float) -> float:
        t = turbine_extraction_state(
            turbine_inlet_temperature_k, er, exhaust_mass_flow_kg_s, gamma_exhaust, turbine_efficiency_calibration_multiplier
        )
        return t.power_kw - target_power

    lo, hi = er_bounds
    f_lo, f_hi = residual(lo), residual(hi)
    if f_lo * f_hi > 0:
        # No exact balance in range (e.g. very small compressor demand) --
        # return the closest feasible bound rather than raising.
        er = lo if abs(f_lo) < abs(f_hi) else hi
    else:
        er = brentq(residual, lo, hi, xtol=1e-4)
    return turbine_extraction_state(
        turbine_inlet_temperature_k, er, exhaust_mass_flow_kg_s, gamma_exhaust, turbine_efficiency_calibration_multiplier
    )


def wastegate_bypass_fraction(exhaust_mass_flow_kg_s: float, required_turbine_flow_kg_s: float) -> float:
    """Fraction of exhaust flow bypassed around the turbine to limit
    boost. 0 = fully closed wastegate."""
    if exhaust_mass_flow_kg_s <= 0:
        return 0.0
    excess = max(exhaust_mass_flow_kg_s - required_turbine_flow_kg_s, 0.0)
    return float(np.clip(excess / exhaust_mass_flow_kg_s, 0.0, 1.0))
