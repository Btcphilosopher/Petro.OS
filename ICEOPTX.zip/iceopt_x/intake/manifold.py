"""
intake.manifold
================

Manifold air density and intake restriction (Section 7).
PHYSICS MODEL: ideal gas law for charge air density.
"""
from __future__ import annotations

R_SPECIFIC_AIR_J_KGK = 287.05  # PHYSICS MODEL: specific gas constant for dry air


def air_density_kg_m3(pressure_kpa: float, temperature_k: float) -> float:
    """rho = P / (R*T), ideal gas law."""
    return (pressure_kpa * 1000.0) / (R_SPECIFIC_AIR_J_KGK * temperature_k)


def intake_restriction_loss_kpa(air_mass_flow_kg_s: float, restriction_coeff_kpa_s2_kg2: float = 1200.0) -> float:
    """Pressure drop across filter/ducting, quadratic in mass flow
    (turbulent orifice loss). EMPIRICAL MODEL: restriction_coeff is a
    part-specific calibration constant (ASSUMPTION default for a
    moderately restrictive road-car air filter/ducting system)."""
    return restriction_coeff_kpa_s2_kg2 * air_mass_flow_kg_s**2
