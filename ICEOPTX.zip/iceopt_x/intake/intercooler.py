"""
intake.intercooler
===================

Charge-air cooling after compression (Section 7/17).
PHYSICS MODEL: effectiveness-NTU style heat exchanger model.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class IntercoolerResult:
    outlet_temperature_k: float
    pressure_drop_kpa: float
    heat_rejected_kw: float


def intercooler_outlet_state(
    compressor_outlet_temp_k: float,
    coolant_or_ambient_temp_k: float,
    air_mass_flow_kg_s: float,
    effectiveness: float = 0.75,
    cp_air_kj_kgk: float = 1.005,
    pressure_drop_fraction: float = 0.03,
    inlet_pressure_kpa: float = 200.0,
) -> IntercoolerResult:
    """effectiveness = (T_in - T_out) / (T_in - T_coolant), the classic
    effectiveness-NTU definition for a cross-flow air-to-air or
    air-to-water charge cooler. EMPIRICAL MODEL: effectiveness and
    pressure_drop_fraction are calibration constants for a representative
    front-mount intercooler."""
    t_out = compressor_outlet_temp_k - effectiveness * (compressor_outlet_temp_k - coolant_or_ambient_temp_k)
    heat_rejected_kw = cp_air_kj_kgk * air_mass_flow_kg_s * (compressor_outlet_temp_k - t_out)
    dp = pressure_drop_fraction * inlet_pressure_kpa
    return IntercoolerResult(outlet_temperature_k=t_out, pressure_drop_kpa=dp, heat_rejected_kw=heat_rejected_kw)
