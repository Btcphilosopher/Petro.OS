"""
intake.throttle
================

Throttling / pumping loss model (Section 7/13/23).

PHYSICS MODEL: compressible orifice flow gives the pressure drop
character; pumping mean effective pressure (PMEP) is derived from the
manifold vacuum, which is what actually costs the engine work each
cycle (Section 13 -- never folded into a single opaque efficiency).
"""
from __future__ import annotations

from iceopt_x.core.state import AmbientConditions


def manifold_pressure_from_throttle_kpa(
    ambient: AmbientConditions,
    throttle_fraction: float,
    boost_pressure_kpa: float = 0.0,
) -> float:
    """A simple monotonic throttle-position -> manifold absolute pressure
    (MAP) map. throttle_fraction in [0, 1] (0 = closed, 1 = wide open).
    EMPIRICAL MODEL: real throttle bodies have a nonlinear, geometry
    specific Cd(angle) curve; this uses a smooth approximation."""
    throttle_fraction = max(min(throttle_fraction, 1.0), 0.001)
    idle_map_kpa = 25.0  # ASSUMPTION: typical closed-throttle MAP
    wide_open_map_kpa = ambient.pressure_kpa + boost_pressure_kpa
    # Nonlinear opening curve (approximates the butterfly-valve flow area law)
    import math

    shape = 1.0 - math.cos(throttle_fraction * math.pi / 2.0)
    return idle_map_kpa + (wide_open_map_kpa - idle_map_kpa) * shape


def pumping_mean_effective_pressure_kpa(
    ambient: AmbientConditions,
    manifold_pressure_kpa: float,
    exhaust_backpressure_kpa: float,
) -> float:
    """PMEP = P_exhaust_back - P_manifold (work done pumping gas in/out
    of the cylinder over the intake+exhaust strokes of a 4-stroke cycle).
    Positive PMEP is a loss (throttled/naturally aspirated engines);
    boosted engines can show negative PMEP (net pumping *gain*) when
    manifold pressure exceeds exhaust backpressure."""
    return exhaust_backpressure_kpa - manifold_pressure_kpa
