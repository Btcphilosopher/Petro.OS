"""
intake.volumetric_efficiency
=============================

Volumetric efficiency model (Section 7/20).

EMPIRICAL MODEL: VE as a function of engine speed and load is a smooth
parametric curve (broad, tunable "bell" centred on a nominal RPM, scaled
by load-dependent throttling and boost). Real VE requires steady-flow
bench mapping; this is a calibratable stand-in, clearly not a
measurement.
"""
from __future__ import annotations

import numpy as np

from iceopt_x.core.state import AspirationType, EngineGeometry


def volumetric_efficiency(
    geometry: EngineGeometry,
    rpm: float,
    load_fraction: float,
    boost_pressure_kpa: float = 0.0,
    calibration_multiplier: float = 1.0,
) -> float:
    """Returns VE as a fraction (typ. 0.55-1.15).

    Base VE peaks near a "tuned" RPM band and falls off at low/high speed
    due to poor manifold dynamics / valve flow limits. Load reduces VE
    mainly through throttling (SI, part-load); boost raises VE above 1.0
    for turbocharged engines.
    """
    rpm_peak = 4200.0  # ASSUMPTION: intake/exhaust tuned length peak, representative of a road-car engine
    spread = 2600.0
    base = 0.92 * np.exp(-0.5 * ((rpm - rpm_peak) / spread) ** 2) + 0.35

    # Throttling penalises VE roughly proportional to (1 - load) for SI engines;
    # CI/turbo engines are typically unthrottled so load has a much weaker effect.
    if geometry.combustion_type.value == "spark_ignition" and geometry.aspiration == AspirationType.NATURALLY_ASPIRATED:
        throttling_factor = 0.55 + 0.45 * load_fraction
    else:
        throttling_factor = 0.85 + 0.15 * load_fraction

    boost_factor = 1.0 + max(boost_pressure_kpa, 0.0) / 101.325 * 0.92  # ASSUMPTION: boost delivery efficiency ~92%

    ve = base * throttling_factor * boost_factor * calibration_multiplier
    return float(np.clip(ve, 0.05, 1.45))
