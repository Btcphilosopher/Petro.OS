"""
intake.airflow
===============

Air mass flow orchestration (Section 7): combines geometry, volumetric
efficiency, and manifold air density into the fundamental "speed-density"
airflow equation.

PHYSICS MODEL for the mass-flow equation; VE itself is EMPIRICAL (see
intake.volumetric_efficiency).
"""
from __future__ import annotations

from dataclasses import dataclass

from iceopt_x.core.state import AmbientConditions, EngineGeometry
from iceopt_x.engine.displacement import revolutions_per_power_stroke, total_displacement_m3
from iceopt_x.intake.manifold import air_density_kg_m3
from iceopt_x.intake.volumetric_efficiency import volumetric_efficiency


@dataclass
class AirflowResult:
    volumetric_efficiency: float
    manifold_air_density_kg_m3: float
    air_mass_flow_kg_s: float
    air_mass_flow_kg_h: float
    air_mass_per_cycle_kg: float


def compute_airflow(
    geometry: EngineGeometry,
    ambient: AmbientConditions,
    rpm: float,
    load_fraction: float,
    manifold_pressure_kpa: float,
    manifold_temperature_k: float,
    boost_pressure_kpa: float = 0.0,
    ve_calibration_multiplier: float = 1.0,
) -> AirflowResult:
    """Speed-density equation:
        m_dot_air = VE * V_displacement * rho_manifold * (N / (60 * n_r))
    where n_r = 2 for four-stroke (one intake event per two revolutions),
    1 for two-stroke.
    """
    ve = volumetric_efficiency(geometry, rpm, load_fraction, boost_pressure_kpa, ve_calibration_multiplier)
    rho = air_density_kg_m3(manifold_pressure_kpa, manifold_temperature_k)
    v_disp = total_displacement_m3(geometry)
    n_r = revolutions_per_power_stroke(geometry)

    cycles_per_second = rpm / 60.0 / n_r
    air_mass_per_cycle = ve * v_disp * rho
    m_dot = air_mass_per_cycle * cycles_per_second

    return AirflowResult(
        volumetric_efficiency=ve,
        manifold_air_density_kg_m3=rho,
        air_mass_flow_kg_s=m_dot,
        air_mass_flow_kg_h=m_dot * 3600.0,
        air_mass_per_cycle_kg=air_mass_per_cycle,
    )
