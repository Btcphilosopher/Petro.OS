"""
ICEOPT-X
========

A physics-first internal combustion engine performance, efficiency and
thermal optimisation engine.

Central question: given an internal combustion engine, its fuel, its
thermal state and its required output, what operating conditions extract
the maximum useful work from every unit of fuel?

This package models the full chain:

    FUEL -> AIR INTAKE -> COMPRESSION -> COMBUSTION -> EXPANSION ->
    EXHAUST -> TURBO / HEAT RECOVERY -> USEFUL MECHANICAL POWER ->
    GENERATOR / TRANSMISSION

and exposes an optimisation layer (global search, Pareto frontier,
marginal-gain ranking) on top of it. See README.md for the validation
philosophy: every number in a result is traceable back to inputs and is
labelled as PHYSICS MODEL, EMPIRICAL MODEL, CALIBRATION DATA, or
ASSUMPTION.
"""

__version__ = "0.1.0"
