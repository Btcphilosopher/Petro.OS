"""
thermodynamics.entropy
========================

PHYSICS MODEL: ideal-gas entropy change relations, used for the T-S
diagram and exergy destruction calculations.
"""
from __future__ import annotations

import numpy as np


def ideal_gas_entropy_change_j_kgk(
    temperature_ratio: float,
    pressure_ratio: float,
    cp_j_kgk: float,
    r_specific_j_kgk: float,
) -> float:
    """ds = cp*ln(T2/T1) - R*ln(P2/P1)"""
    return cp_j_kgk * np.log(temperature_ratio) - r_specific_j_kgk * np.log(pressure_ratio)


def entropy_generation_from_heat_transfer_j_k(heat_transferred_j: float, source_temp_k: float, sink_temp_k: float) -> float:
    """Entropy generated when heat Q flows from a hot source to a cooler
    sink (e.g. cylinder gas -> coolant): sigma = Q/T_sink - Q/T_source >= 0."""
    if source_temp_k <= 0 or sink_temp_k <= 0:
        return 0.0
    return heat_transferred_j * (1.0 / sink_temp_k - 1.0 / source_temp_k)
