"""thermodynamics subpackage of ICEOPT-X."""
