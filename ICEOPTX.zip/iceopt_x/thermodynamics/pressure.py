"""
thermodynamics.pressure
========================

PHYSICS MODEL: ideal-gas and polytropic pressure relations. Uses
CoolProp for real-gas air properties when installed (more accurate at
high pressure/temperature); falls back to the ideal gas law otherwise.
"""
from __future__ import annotations

try:
    import CoolProp.CoolProp as _CP  # type: ignore

    _HAS_COOLPROP = True
except ImportError:  # pragma: no cover - optional dependency
    _HAS_COOLPROP = False

R_SPECIFIC_AIR_J_KGK = 287.05


def ideal_gas_pressure_pa(mass_kg: float, temperature_k: float, volume_m3: float, r_specific: float = R_SPECIFIC_AIR_J_KGK) -> float:
    return mass_kg * r_specific * temperature_k / volume_m3


def polytropic_pressure_ratio(volume_ratio: float, polytropic_index: float) -> float:
    """P2/P1 = (V1/V2)^n"""
    return (1.0 / volume_ratio) ** polytropic_index


def air_density_real_kg_m3(pressure_pa: float, temperature_k: float) -> float:
    """Real-gas density of dry air via CoolProp if available, else ideal
    gas law. CALIBRATION DATA: CoolProp uses the NIST/REFPROP-consistent
    Lemmon et al. air EOS."""
    if _HAS_COOLPROP:
        try:
            return float(_CP.PropsSI("D", "P", pressure_pa, "T", temperature_k, "Air"))
        except Exception:  # pragma: no cover - fall through on solver failure
            pass
    return pressure_pa / (R_SPECIFIC_AIR_J_KGK * temperature_k)


def has_coolprop() -> bool:
    return _HAS_COOLPROP
