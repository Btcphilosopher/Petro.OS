"""
thermodynamics.energy_balance
================================

First-law closure check across the whole plant (Section 15/29/31):

    fuel energy = brake work + exhaust heat + coolant heat + oil/radiative
                  heat + friction heat + unaccounted (should -> 0)

PHYSICS MODEL: strict energy conservation. This module is also the
backbone of the automated conservation tests (Section 29).
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class EnergyBalance:
    fuel_energy_kw: float
    brake_power_kw: float
    exhaust_heat_kw: float
    coolant_heat_kw: float
    oil_radiative_heat_kw: float
    friction_heat_kw: float
    pumping_heat_kw: float
    combustion_loss_kw: float  # energy never released due to incomplete combustion

    @property
    def accounted_kw(self) -> float:
        return (
            self.brake_power_kw
            + self.exhaust_heat_kw
            + self.coolant_heat_kw
            + self.oil_radiative_heat_kw
            + self.friction_heat_kw
            + max(self.pumping_heat_kw, 0.0)
            + self.combustion_loss_kw
        )

    @property
    def residual_kw(self) -> float:
        """Should be ~0 for a physically consistent evaluation; large
        residuals indicate a bug in one of the loss models, not a
        physical result."""
        return self.fuel_energy_kw - self.accounted_kw

    @property
    def residual_fraction(self) -> float:
        if self.fuel_energy_kw <= 0:
            return 0.0
        return self.residual_kw / self.fuel_energy_kw

    def is_closed(self, tolerance_fraction: float = 0.02) -> bool:
        return abs(self.residual_fraction) <= tolerance_fraction

    def as_percentages(self) -> dict[str, float]:
        total = max(self.fuel_energy_kw, 1e-9)
        return {
            "brake_work": 100.0 * self.brake_power_kw / total,
            "exhaust": 100.0 * self.exhaust_heat_kw / total,
            "coolant": 100.0 * self.coolant_heat_kw / total,
            "oil_radiative": 100.0 * self.oil_radiative_heat_kw / total,
            "friction": 100.0 * self.friction_heat_kw / total,
            "pumping": 100.0 * max(self.pumping_heat_kw, 0.0) / total,
            "incomplete_combustion": 100.0 * self.combustion_loss_kw / total,
        }
