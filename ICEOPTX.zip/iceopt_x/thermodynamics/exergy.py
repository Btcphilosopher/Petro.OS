"""
thermodynamics.exergy
=======================

Second-law (exergy) analysis (Section 19).

PHYSICS MODEL: exergy (availability) relations relative to a dead state
(ambient). Chemical exergy of the fuel is estimated via a published
exergy factor (exergy/LHV ratio) rather than computed from full Gibbs
free energy of each combustion product -- CALIBRATION DATA (see
combustion.fuel.FuelProperties.exergy_factor), adequate for engineering
exergy accounting and consistent with Szargut-style approximations for
hydrocarbon and hydrogen fuels.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ExergyBreakdown:
    fuel_exergy_kw: float
    useful_work_exergy_kw: float
    exhaust_exergy_kw: float
    coolant_exergy_kw: float
    friction_exergy_destroyed_kw: float
    pumping_exergy_destroyed_kw: float
    combustion_exergy_destroyed_kw: float

    def as_percentages(self) -> dict[str, float]:
        total = max(self.fuel_exergy_kw, 1e-9)
        return {
            "useful_work": 100.0 * self.useful_work_exergy_kw / total,
            "exhaust": 100.0 * self.exhaust_exergy_kw / total,
            "coolant": 100.0 * self.coolant_exergy_kw / total,
            "friction": 100.0 * self.friction_exergy_destroyed_kw / total,
            "pumping": 100.0 * self.pumping_exergy_destroyed_kw / total,
            "combustion_irreversibility": 100.0 * self.combustion_exergy_destroyed_kw / total,
        }


def fuel_exergy_kw(fuel_mass_flow_kg_s: float, lhv_mj_kg: float, exergy_factor: float) -> float:
    return fuel_mass_flow_kg_s * lhv_mj_kg * 1000.0 * exergy_factor  # MJ/kg * kg/s * 1000 = kW


def thermal_stream_exergy_kw(
    heat_flow_kw: float,
    stream_temperature_k: float,
    ambient_temperature_k: float,
) -> float:
    """Exergy of a heat stream at temperature T relative to ambient T0:
    Ex = Q * (1 - T0/T), the Carnot factor. For a stream that itself
    cools from T_stream to T0 (e.g. exhaust dumped to atmosphere), this
    is evaluated using the stream's flow-averaged (log-mean-ish)
    temperature; callers pass an appropriately averaged temperature."""
    if stream_temperature_k <= 0:
        return 0.0
    carnot_factor = max(1.0 - ambient_temperature_k / stream_temperature_k, 0.0)
    return heat_flow_kw * carnot_factor


def exergy_destroyed_from_entropy_kw(entropy_generation_rate_w_k: float, ambient_temperature_k: float) -> float:
    """Gouy-Stodola theorem: Ex_destroyed = T0 * Sigma_dot."""
    return entropy_generation_rate_w_k * ambient_temperature_k / 1000.0


def build_exergy_breakdown(
    fuel_mass_flow_kg_s: float,
    lhv_mj_kg: float,
    exergy_factor: float,
    brake_power_kw: float,
    exhaust_heat_kw: float,
    exhaust_avg_temp_k: float,
    coolant_heat_kw: float,
    coolant_avg_temp_k: float,
    friction_power_kw: float,
    pumping_power_kw: float,
    ambient_temperature_k: float,
) -> ExergyBreakdown:
    fuel_ex = fuel_exergy_kw(fuel_mass_flow_kg_s, lhv_mj_kg, exergy_factor)
    exhaust_ex = thermal_stream_exergy_kw(exhaust_heat_kw, exhaust_avg_temp_k, ambient_temperature_k)
    coolant_ex = thermal_stream_exergy_kw(coolant_heat_kw, coolant_avg_temp_k, ambient_temperature_k)
    useful_work_ex = brake_power_kw  # mechanical work is 100% exergy
    friction_ex_destroyed = friction_power_kw  # all frictional work degrades directly to destroyed exergy
    pumping_ex_destroyed = max(pumping_power_kw, 0.0)

    accounted = useful_work_ex + exhaust_ex + coolant_ex + friction_ex_destroyed + pumping_ex_destroyed
    combustion_ex_destroyed = max(fuel_ex - accounted, 0.0)

    return ExergyBreakdown(
        fuel_exergy_kw=fuel_ex,
        useful_work_exergy_kw=useful_work_ex,
        exhaust_exergy_kw=exhaust_ex,
        coolant_exergy_kw=coolant_ex,
        friction_exergy_destroyed_kw=friction_ex_destroyed,
        pumping_exergy_destroyed_kw=pumping_ex_destroyed,
        combustion_exergy_destroyed_kw=combustion_ex_destroyed,
    )
