"""
thermodynamics.cycle
=====================

Crank-angle-resolved closed-cycle (high-pressure loop) simulation:
compression -> combustion -> expansion, IVC to EVO (Section 12).

PHYSICS MODEL: first-law energy balance on a single-zone ideal-gas
closed system,

    dU = dQ_combustion - dQ_wall - P*dV,   P = m*R*T/V (ideal gas law)

integrated stepwise over crank angle. Wall heat transfer dQ_wall is
included directly in this integration (via the Woschni correlation,
EMPIRICAL MODEL) so that peak pressure/temperature, indicated work, and
the wall heat loss reported to thermal.thermal_state are all mutually
consistent -- the same combustion event, not two independently
re-derived numbers (Section 29/31: energy conservation must close).

LEVEL 2 (Section 8): heat release comes from the finite-rate Wiebe
function (combustion.burn_rate), not an instantaneous idealised release
(LEVEL 1) and not a full CFD/chemistry solve (LEVEL 3/4).

ASSUMPTION: a single effective ratio-of-specific-heats is used for the
whole closed cycle rather than temperature/composition-dependent
properties -- adequate for engineering-level peak P/T and indicated
work, not for detailed emissions chemistry.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from iceopt_x.combustion.burn_rate import WiebeParameters, heat_release_rate
from iceopt_x.core.state import EngineGeometry
from iceopt_x.engine.displacement import mean_piston_speed_m_s
from iceopt_x.engine.kinematics import instantaneous_cylinder_volume_m3

R_SPECIFIC_GAS_J_KGK = 290.0  # ASSUMPTION: effective specific gas constant, air/combustion-product blend
GAMMA_EFFECTIVE = 1.32       # ASSUMPTION: single effective gamma for the whole closed cycle (compression ~1.4, burned gas ~1.25-1.3)
CV_EFFECTIVE_J_KGK = R_SPECIFIC_GAS_J_KGK / (GAMMA_EFFECTIVE - 1.0)

# Woschni (1967) in-cylinder convective heat transfer correlation constants.
# EMPIRICAL MODEL: h = 3.26 * B^-0.2 * P[kPa]^0.8 * T^-0.55 * w[m/s]^0.8
WALL_AREA_FACTOR = 2.3  # ASSUMPTION: exposed area ~ 2.3x bore area (piston crown + head + liner fraction), cycle-averaged


@dataclass
class CycleResult:
    theta_deg: np.ndarray
    volume_m3: np.ndarray
    pressure_pa: np.ndarray
    temperature_k: np.ndarray
    entropy_j_k: np.ndarray  # relative entropy trace (for T-S diagram), integrated dS = dQ/T along the heat-addition path
    peak_pressure_bar: float
    peak_pressure_location_deg: float
    peak_temperature_k: float
    gross_indicated_work_j: float
    heat_released_j: float
    wall_heat_loss_j: float  # per cylinder, per cycle -- consistent with gross_indicated_work_j

    def pv_diagram_xy(self) -> tuple[np.ndarray, np.ndarray]:
        return self.volume_m3, self.pressure_pa / 1.0e5  # volume [m^3], pressure [bar]

    def ts_diagram_xy(self) -> tuple[np.ndarray, np.ndarray]:
        return self.entropy_j_k, self.temperature_k


def simulate_closed_cycle(
    geometry: EngineGeometry,
    ivc_pressure_kpa: float,
    ivc_temperature_k: float,
    trapped_mass_kg: float,
    heat_released_j: float,
    wiebe: WiebeParameters,
    rpm: float,
    wall_temperature_k: float = 460.0,
    ivc_deg: float = -150.0,
    evo_deg: float = 130.0,
    n_steps: int = 720,
) -> CycleResult:
    """Integrate the closed high-pressure loop from IVC to EVO, including
    Woschni wall heat transfer in the first law at every step."""
    theta_deg = np.linspace(ivc_deg, evo_deg, n_steps)
    dtheta_deg = theta_deg[1] - theta_deg[0]
    dt_s = dtheta_deg / (6.0 * rpm)  # deg/s = 6*rpm  =>  s/deg = 1/(6*rpm)

    volume = instantaneous_cylinder_volume_m3(geometry, np.deg2rad(theta_deg))
    dqdtheta = heat_release_rate(theta_deg, wiebe, heat_released_j)

    pressure = np.empty_like(theta_deg)
    temperature = np.empty_like(theta_deg)
    entropy = np.empty_like(theta_deg)

    pressure[0] = ivc_pressure_kpa * 1000.0
    temperature[0] = ivc_temperature_k
    entropy[0] = 0.0
    m = trapped_mass_kg

    sp = mean_piston_speed_m_s(geometry, rpm)
    area_m2 = WALL_AREA_FACTOR * (math.pi / 4.0) * geometry.bore_m**2

    wall_heat_loss_j = 0.0

    for i in range(1, len(theta_deg)):
        dv = volume[i] - volume[i - 1]
        dq_comb = 0.5 * (dqdtheta[i] + dqdtheta[i - 1]) * dtheta_deg

        p_prev_kpa = pressure[i - 1] / 1000.0
        h_w = 3.26 * geometry.bore_m**-0.2 * max(p_prev_kpa, 1.0) ** 0.8 * max(temperature[i - 1], 1.0) ** -0.55 * max(sp, 0.1) ** 0.8
        dq_wall = h_w * area_m2 * max(temperature[i - 1] - wall_temperature_k, 0.0) * dt_s
        wall_heat_loss_j += dq_wall

        p_prev = pressure[i - 1]
        dt = (dq_comb - dq_wall - p_prev * dv) / (m * CV_EFFECTIVE_J_KGK)
        temperature[i] = temperature[i - 1] + dt
        pressure[i] = m * R_SPECIFIC_GAS_J_KGK * temperature[i] / volume[i]
        entropy[i] = entropy[i - 1] + (dq_comb - dq_wall) / max(temperature[i - 1], 1.0)

    _trapz = getattr(np, "trapezoid", None) or np.trapz  # numpy >=2.0 renamed trapz -> trapezoid
    gross_indicated_work_j = float(_trapz(pressure, volume))
    peak_idx = int(np.argmax(pressure))

    return CycleResult(
        theta_deg=theta_deg,
        volume_m3=volume,
        pressure_pa=pressure,
        temperature_k=temperature,
        entropy_j_k=entropy,
        peak_pressure_bar=float(pressure[peak_idx] / 1.0e5),
        peak_pressure_location_deg=float(theta_deg[peak_idx]),
        peak_temperature_k=float(np.max(temperature)),
        gross_indicated_work_j=gross_indicated_work_j,
        heat_released_j=heat_released_j,
        wall_heat_loss_j=wall_heat_loss_j,
    )
