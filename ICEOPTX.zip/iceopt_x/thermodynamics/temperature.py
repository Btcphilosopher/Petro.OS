"""
thermodynamics.temperature
============================

PHYSICS MODEL: polytropic/isentropic temperature relations.
"""
from __future__ import annotations


def polytropic_temperature_ratio(volume_ratio: float, polytropic_index: float) -> float:
    """T2/T1 = (V1/V2)^(n-1)"""
    return (1.0 / volume_ratio) ** (polytropic_index - 1.0)


def isentropic_temperature_ratio(pressure_ratio: float, gamma: float) -> float:
    """T2/T1 = (P2/P1)^((gamma-1)/gamma)"""
    return pressure_ratio ** ((gamma - 1.0) / gamma)


def adiabatic_flame_temperature_estimate_k(
    initial_temperature_k: float,
    lower_heating_value_j_kg: float,
    fuel_mass_kg: float,
    total_mass_kg: float,
    cv_j_kgk: float = 850.0,
    combustion_efficiency: float = 0.98,
) -> float:
    """A first-law estimate: all released chemical energy raises the
    trapped-mass internal energy at constant volume. ASSUMPTION:
    constant cv (no dissociation, no temperature-dependent properties) --
    a conservative engineering upper-bound estimate, not a chemical
    equilibrium flame temperature."""
    q = lower_heating_value_j_kg * fuel_mass_kg * combustion_efficiency
    return initial_temperature_k + q / (total_mass_kg * cv_j_kgk)
