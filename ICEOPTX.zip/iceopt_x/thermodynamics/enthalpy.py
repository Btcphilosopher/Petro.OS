"""
thermodynamics.enthalpy
=========================

PHYSICS MODEL: ideal-gas sensible enthalpy relations (h = cp*T, taking a
common reference of 0 K for relative comparisons across the plant --
absolute enthalpy datum is arbitrary and cancels in every balance used
here).
"""
from __future__ import annotations

CP_AIR_KJ_KGK = 1.005
CP_EXHAUST_KJ_KGK = 1.10  # ASSUMPTION: representative of hot combustion-product mixture (CO2/H2O-enriched)


def sensible_enthalpy_kj_kg(temperature_k: float, cp_kj_kgk: float) -> float:
    return cp_kj_kgk * temperature_k


def enthalpy_flow_kw(mass_flow_kg_s: float, temperature_k: float, cp_kj_kgk: float, reference_temperature_k: float = 298.15) -> float:
    """Enthalpy flow rate relative to a reference temperature (ambient by
    default) -- this is what is actually "available" thermally."""
    return mass_flow_kg_s * cp_kj_kgk * (temperature_k - reference_temperature_k)
