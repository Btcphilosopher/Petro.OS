"""
engine.kinematics
==================

Crank-slider kinematics (Section 5). Exact geometric relations for
piston position, velocity and acceleration and the instantaneous
cylinder volume as a function of crank angle.

PHYSICS MODEL.

Convention: theta = 0 at TDC (firing), increasing with crank rotation.
"""
from __future__ import annotations

import numpy as np

from iceopt_x.core.state import EngineGeometry
from iceopt_x.engine.displacement import clearance_volume_m3


def crank_radius_m(geometry: EngineGeometry) -> float:
    return geometry.stroke_m / 2.0


def piston_position_from_tdc_m(geometry: EngineGeometry, theta_rad: np.ndarray) -> np.ndarray:
    """Distance of the piston crown from TDC, exact crank-slider solution.

    x(theta) = r*(1 - cos(theta)) + l - sqrt(l^2 - r^2*sin^2(theta))
    where r = crank radius, l = connecting rod length.
    """
    theta_rad = np.asarray(theta_rad, dtype=float)
    r = crank_radius_m(geometry)
    l = geometry.rod_length_m
    return r * (1.0 - np.cos(theta_rad)) + l - np.sqrt(np.clip(l**2 - r**2 * np.sin(theta_rad) ** 2, 0.0, None))


def piston_velocity_m_s(geometry: EngineGeometry, theta_rad: np.ndarray, omega_rad_s: float) -> np.ndarray:
    """dx/dt = omega * dx/dtheta, differentiated analytically."""
    theta_rad = np.asarray(theta_rad, dtype=float)
    r = crank_radius_m(geometry)
    l = geometry.rod_length_m
    sin_t, cos_t = np.sin(theta_rad), np.cos(theta_rad)
    denom = np.sqrt(np.clip(l**2 - r**2 * sin_t**2, 1e-12, None))
    dx_dtheta = r * sin_t + (r**2 * sin_t * cos_t) / denom
    return omega_rad_s * dx_dtheta


def instantaneous_cylinder_volume_m3(geometry: EngineGeometry, theta_rad: np.ndarray) -> np.ndarray:
    """V(theta) = V_clearance + piston-swept volume at this crank angle."""
    import math

    v_c = clearance_volume_m3(geometry)
    area = (math.pi / 4.0) * geometry.bore_m**2
    x = piston_position_from_tdc_m(geometry, theta_rad)
    return v_c + area * x


def angular_velocity_rad_s(rpm: float) -> float:
    return rpm * 2.0 * np.pi / 60.0
