"""engine subpackage of ICEOPT-X."""
