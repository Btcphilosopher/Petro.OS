"""
engine.degradation
====================

Long-term degradation model (Section 26): wear, friction increase,
compression loss, turbo degradation, injector degradation, thermal
degradation and lubrication degradation, all expressed as functions of
accumulated operating hours and folded back into EngineModel's
calibration multipliers + effective compression ratio -- so the
optimiser can be asked "how does the optimal setpoint change as the
engine ages?" using the exact same evaluate() chain as a new engine.

EMPIRICAL MODEL: degradation rates are illustrative first-order
(exponential approach to an end-of-life plateau) trends consistent with
qualitative wear literature, not measured field data for any specific
engine.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from iceopt_x.engine.engine_model import EngineModel


@dataclass
class DegradationRates:
    friction_increase_per_1000h: float = 0.06       # +6% friction per 1000h, asymptotic
    compression_ratio_loss_per_1000h: float = 0.015  # -1.5% effective CR per 1000h (ring/valve seat wear), asymptotic
    turbo_efficiency_loss_per_1000h: float = 0.03    # -3% compressor+turbine efficiency per 1000h (bearing wear, fouling)
    ve_loss_per_1000h: float = 0.02                  # -2% volumetric efficiency per 1000h (deposit build-up, valve wear)
    combustion_efficiency_loss_per_1000h: float = 0.01  # -1% combustion efficiency per 1000h (injector spray degradation)
    plateau_fraction: float = 0.65                   # degradation saturates at this fraction of the naive linear extrapolation


def _saturating_curve(hours: float, rate_per_1000h: float, tau_hours: float = 4000.0) -> float:
    """A smooth, saturating degradation curve: change grows roughly
    linearly at first (matching `rate_per_1000h`) then flattens out as
    worn components stabilise rather than degrading forever. Returns a
    NEGATIVE fraction (a loss) to be added to a multiplier baseline of
    1.0."""
    max_loss = rate_per_1000h * (tau_hours / 1000.0)  # total loss reached asymptotically
    return -max_loss * (1.0 - np.exp(-hours / tau_hours))


def degrade_engine_model(
    model: EngineModel,
    operating_hours: float,
    rates: DegradationRates | None = None,
) -> EngineModel:
    """Return a NEW EngineModel with calibration multipliers (and
    effective compression ratio) adjusted for the given accumulated
    operating hours. The original model is never mutated."""
    rates = rates or DegradationRates()
    hours = max(operating_hours, 0.0)

    friction_mult = 1.0 - _saturating_curve(hours, rates.friction_increase_per_1000h, 4000.0)  # loss is negative -> friction increases
    ve_mult = 1.0 + _saturating_curve(hours, rates.ve_loss_per_1000h, 4000.0)
    comb_mult = 1.0 + _saturating_curve(hours, rates.combustion_efficiency_loss_per_1000h, 4000.0)
    turbo_mult = 1.0 + _saturating_curve(hours, rates.turbo_efficiency_loss_per_1000h, 4000.0)
    cr_factor = 1.0 + _saturating_curve(hours, rates.compression_ratio_loss_per_1000h, 4000.0)

    new_mult = dict(model.calibration_multipliers)
    new_mult["friction"] = new_mult.get("friction", 1.0) * friction_mult
    new_mult["volumetric_efficiency"] = new_mult.get("volumetric_efficiency", 1.0) * ve_mult
    new_mult["combustion_efficiency"] = new_mult.get("combustion_efficiency", 1.0) * comb_mult
    new_mult["compressor_efficiency"] = new_mult.get("compressor_efficiency", 1.0) * turbo_mult
    new_mult["turbine_efficiency"] = new_mult.get("turbine_efficiency", 1.0) * turbo_mult

    new_geometry = model.geometry.model_copy(update={"compression_ratio": model.geometry.compression_ratio * cr_factor})

    return model.model_copy(update={"geometry": new_geometry, "calibration_multipliers": new_mult})
