"""
engine.displacement
====================

PHYSICS MODEL: exact geometric relations for swept/clearance/total
displacement volumes.
"""
from __future__ import annotations

import math

from iceopt_x.core.state import EngineGeometry


def swept_volume_m3(geometry: EngineGeometry) -> float:
    """Single-cylinder swept volume V_s = (pi/4) * bore^2 * stroke."""
    return (math.pi / 4.0) * geometry.bore_m**2 * geometry.stroke_m


def clearance_volume_m3(geometry: EngineGeometry) -> float:
    """V_c = V_s / (r_c - 1), from r_c = (V_s + V_c) / V_c."""
    v_s = swept_volume_m3(geometry)
    return v_s / (geometry.compression_ratio - 1.0)


def total_cylinder_volume_m3(geometry: EngineGeometry) -> float:
    """V_s + V_c, the volume at BDC."""
    return swept_volume_m3(geometry) + clearance_volume_m3(geometry)


def total_displacement_m3(geometry: EngineGeometry) -> float:
    """Sum of swept volume across all cylinders."""
    return swept_volume_m3(geometry) * geometry.cylinder_count


def total_displacement_cc(geometry: EngineGeometry) -> float:
    return total_displacement_m3(geometry) * 1.0e6


def mean_piston_speed_m_s(geometry: EngineGeometry, rpm: float) -> float:
    """S_p = 2 * stroke * N / 60  [m/s], N in rev/min."""
    return 2.0 * geometry.stroke_m * rpm / 60.0


def revolutions_per_power_stroke(geometry: EngineGeometry) -> float:
    """1.0 for a two-stroke engine (one power stroke per revolution),
    2.0 for a four-stroke engine (one power stroke per two revolutions)."""
    from iceopt_x.core.state import StrokeCycle

    return 1.0 if geometry.stroke_cycle == StrokeCycle.TWO_STROKE else 2.0
