"""
engine.geometry
================

Convenience geometry summaries built on engine.displacement.
PHYSICS MODEL.
"""
from __future__ import annotations

from dataclasses import dataclass

from iceopt_x.core.state import EngineGeometry
from iceopt_x.engine.displacement import (
    clearance_volume_m3,
    swept_volume_m3,
    total_cylinder_volume_m3,
    total_displacement_cc,
    total_displacement_m3,
)


@dataclass
class GeometrySummary:
    swept_volume_m3: float
    clearance_volume_m3: float
    total_cylinder_volume_m3: float
    total_displacement_m3: float
    total_displacement_cc: float
    bore_stroke_ratio: float
    compression_ratio: float
    cylinder_count: int


def summarise(geometry: EngineGeometry) -> GeometrySummary:
    return GeometrySummary(
        swept_volume_m3=swept_volume_m3(geometry),
        clearance_volume_m3=clearance_volume_m3(geometry),
        total_cylinder_volume_m3=total_cylinder_volume_m3(geometry),
        total_displacement_m3=total_displacement_m3(geometry),
        total_displacement_cc=total_displacement_cc(geometry),
        bore_stroke_ratio=geometry.bore_m / geometry.stroke_m,
        compression_ratio=geometry.compression_ratio,
        cylinder_count=geometry.cylinder_count,
    )
