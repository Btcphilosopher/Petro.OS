"""
engine.compression
===================

Effect of compression ratio on the ideal (air-standard) thermodynamic
limit, used as a reference ceiling for the real cycle.

PHYSICS MODEL: air-standard Otto/Diesel efficiency limits.
"""
from __future__ import annotations

from iceopt_x.core.state import CombustionType, EngineGeometry

GAMMA_AIR = 1.35  # ASSUMPTION: effective ratio of specific heats for hot in-cylinder gas (air ~1.4, combustion products lower)


def otto_air_standard_efficiency(compression_ratio: float, gamma: float = GAMMA_AIR) -> float:
    """eta_otto = 1 - r_c^(1-gamma). Upper bound for SI engines (Section 6.12)."""
    return 1.0 - compression_ratio ** (1.0 - gamma)


def diesel_air_standard_efficiency(compression_ratio: float, cutoff_ratio: float, gamma: float = GAMMA_AIR) -> float:
    """eta_diesel = 1 - (1/r_c^(gamma-1)) * (rho^gamma - 1) / (gamma*(rho-1))
    where rho is the cutoff ratio (V3/V2, constant-pressure heat addition
    portion). rho -> 1 recovers the Otto limit."""
    if abs(cutoff_ratio - 1.0) < 1e-9:
        return otto_air_standard_efficiency(compression_ratio, gamma)
    term = (cutoff_ratio**gamma - 1.0) / (gamma * (cutoff_ratio - 1.0))
    return 1.0 - (compression_ratio ** (1.0 - gamma)) * term


def air_standard_efficiency_limit(geometry: EngineGeometry, cutoff_ratio: float = 1.05) -> float:
    """Route to the correct air-standard limit based on combustion type.
    This is a theoretical ceiling only -- real cycles achieve 55-65% of
    this owing to heat transfer, finite burn duration, exhaust blowdown
    and friction (all modelled explicitly elsewhere, never folded into a
    single fudge factor)."""
    if geometry.combustion_type == CombustionType.COMPRESSION_IGNITION:
        return diesel_air_standard_efficiency(geometry.compression_ratio, cutoff_ratio)
    return otto_air_standard_efficiency(geometry.compression_ratio)
