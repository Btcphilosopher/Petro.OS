"""
engine.engine_model
====================

EngineModel: the configurable "hardware" description -- geometry + fuel
+ aspiration + constraint envelope. This is the object every calculation
module receives; core.engine.Engine wraps it with the calculation chain.
"""
from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from iceopt_x.combustion.fuel import FuelProperties, FuelType, get_fuel
from iceopt_x.core.state import ConstraintLimits, EngineGeometry


DEFAULT_CALIBRATION_MULTIPLIERS: dict[str, float] = {
    "volumetric_efficiency": 1.0,
    "combustion_efficiency": 1.0,
    "friction": 1.0,
    "compressor_efficiency": 1.0,
    "turbine_efficiency": 1.0,
    "heat_recovery_effectiveness": 1.0,
}


class EngineModel(BaseModel):
    """A named, fully specified engine hardware configuration.

    `calibration_multipliers` are the explicit CALIBRATION DATA knobs
    (Section 31) that the marginal-gain engine (optimisation.marginal_gain,
    Section 23) perturbs by +/-1% to answer "what single change would
    produce the largest improvement" -- they are never silently baked
    into the physics functions themselves.
    """

    name: str
    geometry: EngineGeometry
    fuel: FuelProperties
    constraints: ConstraintLimits = Field(default_factory=ConstraintLimits)
    calibration_multipliers: dict[str, float] = Field(default_factory=lambda: dict(DEFAULT_CALIBRATION_MULTIPLIERS))

    model_config = ConfigDict(arbitrary_types_allowed=True)

    @classmethod
    def from_fuel_type(
        cls,
        name: str,
        geometry: EngineGeometry,
        fuel_type: FuelType,
        constraints: ConstraintLimits | None = None,
    ) -> "EngineModel":
        return cls(
            name=name,
            geometry=geometry,
            fuel=get_fuel(fuel_type),
            constraints=constraints or ConstraintLimits(),
        )


def default_geometry_2p0l_turbo_petrol() -> EngineGeometry:
    """A representative 2.0 L turbocharged 4-cylinder petrol engine,
    used as the reference/demo configuration throughout tests and docs."""
    from iceopt_x.core.state import AspirationType, CombustionType, StrokeCycle

    return EngineGeometry(
        cylinder_count=4,
        bore_m=0.086,
        stroke_m=0.086,
        rod_length_m=0.145,
        compression_ratio=10.5,
        valve_area_m2=0.0011,
        stroke_cycle=StrokeCycle.FOUR_STROKE,
        combustion_type=CombustionType.SPARK_IGNITION,
        aspiration=AspirationType.TURBOCHARGED,
    )


def default_geometry_2p2l_diesel() -> EngineGeometry:
    """A representative 2.2 L turbocharged 4-cylinder diesel engine."""
    from iceopt_x.core.state import AspirationType, CombustionType, StrokeCycle

    return EngineGeometry(
        cylinder_count=4,
        bore_m=0.085,
        stroke_m=0.0964,
        rod_length_m=0.155,
        compression_ratio=16.5,
        valve_area_m2=0.0010,
        stroke_cycle=StrokeCycle.FOUR_STROKE,
        combustion_type=CombustionType.COMPRESSION_IGNITION,
        aspiration=AspirationType.TURBOCHARGED,
    )
