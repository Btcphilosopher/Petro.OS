"""
core.events
============

Lightweight event log used by the real-time loop (core.timestep) and the
optimisers to record constraint violations, setpoint changes, and
degradation milestones without coupling every module to a full logging
framework.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum


class EventKind(str, Enum):
    SETPOINT_CHANGE = "setpoint_change"
    CONSTRAINT_VIOLATION = "constraint_violation"
    CONSTRAINT_REJECTED_CANDIDATE = "constraint_rejected_candidate"
    DEGRADATION_MILESTONE = "degradation_milestone"
    SCENARIO_CHANGE = "scenario_change"
    OPTIMISATION_RESULT = "optimisation_result"


@dataclass
class Event:
    kind: EventKind
    message: str
    timestamp_s: float = field(default_factory=time.time)
    data: dict = field(default_factory=dict)


class EventLog:
    def __init__(self) -> None:
        self._events: list[Event] = []

    def record(self, kind: EventKind, message: str, **data) -> Event:
        event = Event(kind=kind, message=message, data=data)
        self._events.append(event)
        return event

    @property
    def events(self) -> list[Event]:
        return list(self._events)

    def filter(self, kind: EventKind) -> list[Event]:
        return [e for e in self._events if e.kind == kind]

    def clear(self) -> None:
        self._events.clear()
