"""
core.simulation
=================

Engine operating-map generation (Section 6/20): evaluate every
(RPM, load) cell of a map and collect the results into a tidy
pandas.DataFrame -- the basis for every performance map (torque, power,
BSFC, brake/thermal efficiency, exhaust temperature, ...).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from iceopt_x.core.engine import Engine
from iceopt_x.core.state import AmbientConditions, OperatingPoint, ThermalState


@dataclass
class MapAxes:
    rpm_values: list[float]
    load_values: list[float]  # fractions 0-1


DEFAULT_MAP_AXES = MapAxes(
    rpm_values=[1500, 2500, 3500, 4500, 5500],
    load_values=[0.2, 0.4, 0.6, 0.8, 1.0],
)


def generate_engine_map(
    engine: Engine,
    axes: MapAxes = DEFAULT_MAP_AXES,
    ambient: AmbientConditions | None = None,
    thermal_state: ThermalState | None = None,
    boost_pressure_kpa_at_full_load: float = 100.0,
    lambda_target: float = 1.0,
    ignition_timing_btdc_deg: float = 18.0,
    injection_timing_btdc_deg: float = 12.0,
) -> pd.DataFrame:
    """Sweep RPM x load and evaluate every cell (Section 6: "Every cell
    should contain calculated performance."). Boost scales linearly with
    load for turbocharged engines (a simple, explicit wastegate-schedule
    proxy -- not a claim that this is how a real ECU maps boost)."""
    ambient = ambient or AmbientConditions()
    thermal_state = thermal_state or ThermalState()

    is_turbo = engine.model.geometry.aspiration.value == "turbocharged"

    rows = []
    for rpm in axes.rpm_values:
        for load in axes.load_values:
            boost = boost_pressure_kpa_at_full_load * load if is_turbo else 0.0
            op = OperatingPoint(
                rpm=rpm,
                load_fraction=load,
                boost_pressure_kpa=boost,
                lambda_target=lambda_target,
                ignition_timing_btdc_deg=ignition_timing_btdc_deg,
                injection_timing_btdc_deg=injection_timing_btdc_deg,
                intake_temperature_k=ambient.temperature_k + 15.0,  # ASSUMPTION: modest post-manifold heat soak
            )
            result = engine.evaluate(op, ambient, thermal_state)
            rows.append(
                {
                    "rpm": rpm,
                    "load_fraction": load,
                    "torque_nm": result.brake_torque_nm,
                    "power_kw": result.brake_power_kw,
                    "bsfc_g_per_kwh": result.efficiency.bsfc_g_per_kwh,
                    "brake_thermal_efficiency": result.efficiency.brake_thermal_efficiency,
                    "indicated_thermal_efficiency": result.efficiency.indicated_thermal_efficiency,
                    "mechanical_efficiency": result.efficiency.mechanical_efficiency,
                    "volumetric_efficiency": result.efficiency.volumetric_efficiency,
                    "combustion_efficiency": result.efficiency.combustion_efficiency,
                    "peak_cylinder_pressure_bar": result.combustion.peak_cylinder_pressure_bar,
                    "peak_cylinder_temp_k": result.combustion.peak_temperature_k,
                    "exhaust_temperature_k": result.exhaust_temperature_k,
                    "boost_pressure_kpa": boost,
                    "fuel_flow_kg_h": result.mixture.fuel_mass_flow_kg_h,
                    "air_flow_kg_h": result.airflow.air_mass_flow_kg_h,
                    "is_feasible": result.is_feasible,
                    "n_violations": len(result.constraint_violations),
                }
            )
    return pd.DataFrame(rows)


def pivot_map(df: pd.DataFrame, value_col: str) -> pd.DataFrame:
    """Reshape a tidy map DataFrame into a RPM-columns x load-rows table
    matching the Section 6/20 layout."""
    return df.pivot(index="load_fraction", columns="rpm", values=value_col).sort_index(ascending=False)
