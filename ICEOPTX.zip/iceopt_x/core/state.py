"""
core.state
==========

Pydantic data contracts shared across ICEOPT-X. These are the nouns of the
system: engine geometry, ambient conditions, operating points, thermal
state, and the constraint envelope the optimiser must never leave.

PHYSICS MODEL: structural definitions only (no calculation here).
"""
from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field, field_validator


# --------------------------------------------------------------------------- #
# Enumerations
# --------------------------------------------------------------------------- #
class StrokeCycle(str, Enum):
    TWO_STROKE = "two_stroke"
    FOUR_STROKE = "four_stroke"


class CombustionType(str, Enum):
    SPARK_IGNITION = "spark_ignition"      # petrol, CNG, H2, ethanol, methanol
    COMPRESSION_IGNITION = "compression_ignition"  # diesel, synthetic diesel


class AspirationType(str, Enum):
    NATURALLY_ASPIRATED = "naturally_aspirated"
    TURBOCHARGED = "turbocharged"
    SUPERCHARGED = "supercharged"


class CombustionModelLevel(int, Enum):
    """Section 8 model sophistication ladder. Higher levels require more
    calibration data; the engine never claims CFD-level accuracy."""
    L1_IDEALISED_THERMODYNAMIC = 1
    L2_FINITE_RATE_HEAT_RELEASE = 2
    L3_EMPIRICAL = 3
    L4_CALIBRATED_EXPERIMENTAL = 4


# --------------------------------------------------------------------------- #
# Geometry
# --------------------------------------------------------------------------- #
class EngineGeometry(BaseModel):
    """Configurable engine geometry (Section 5)."""

    cylinder_count: int = Field(gt=0, le=20)
    bore_m: float = Field(gt=0, description="Cylinder bore [m]")
    stroke_m: float = Field(gt=0, description="Piston stroke [m]")
    rod_length_m: float = Field(gt=0, description="Connecting-rod length [m]")
    compression_ratio: float = Field(gt=1.0, le=40.0)
    valve_area_m2: float = Field(gt=0, description="Effective total valve curtain area [m^2]")
    stroke_cycle: StrokeCycle = StrokeCycle.FOUR_STROKE
    combustion_type: CombustionType = CombustionType.SPARK_IGNITION
    aspiration: AspirationType = AspirationType.NATURALLY_ASPIRATED

    @field_validator("rod_length_m")
    @classmethod
    def _rod_longer_than_half_stroke(cls, v: float, info) -> float:
        stroke = info.data.get("stroke_m")
        if stroke is not None and v <= stroke / 2:
            raise ValueError("rod_length_m must exceed half the stroke (crank-slider is degenerate otherwise)")
        return v


class AmbientConditions(BaseModel):
    """Section 7/27: ambient state driving airflow and scenario analysis."""

    pressure_kpa: float = Field(default=101.325, gt=0)
    temperature_k: float = Field(default=298.15, gt=0)
    altitude_m: float = Field(default=0.0)
    relative_humidity: float = Field(default=0.5, ge=0.0, le=1.0)


# --------------------------------------------------------------------------- #
# Operating point / thermal state
# --------------------------------------------------------------------------- #
class OperatingPoint(BaseModel):
    """Section 6: the instantaneous engine state."""

    rpm: float = Field(gt=0)
    load_fraction: float = Field(ge=0.0, le=1.0, description="Fraction of max torque at this RPM")
    torque_nm: Optional[float] = None
    power_kw: Optional[float] = None
    fuel_flow_kg_h: Optional[float] = None
    air_flow_kg_h: Optional[float] = None
    manifold_pressure_kpa: Optional[float] = None
    boost_pressure_kpa: float = Field(default=0.0, ge=0.0)
    intake_temperature_k: float = Field(default=298.15, gt=0)
    coolant_temperature_k: float = Field(default=363.15, gt=0)
    oil_temperature_k: float = Field(default=363.15, gt=0)
    exhaust_temperature_k: Optional[float] = None

    # Actuation / calibration variables the optimiser searches over
    lambda_target: float = Field(default=1.0, gt=0.3, le=2.0, description="Normalised AFR (1.0 = stoichiometric)")
    ignition_timing_btdc_deg: float = Field(default=15.0, description="Spark advance, deg BTDC (SI engines)")
    injection_timing_btdc_deg: float = Field(default=10.0, description="Start of injection, deg BTDC (CI engines)")
    injection_pressure_bar: float = Field(default=1000.0, gt=0)


class ThermalState(BaseModel):
    """Section 15: lumped thermal state of the major masses."""

    cylinder_gas_temp_k: float = Field(default=298.15, gt=0)
    head_temp_k: float = Field(default=363.15, gt=0)
    block_temp_k: float = Field(default=358.15, gt=0)
    oil_temp_k: float = Field(default=363.15, gt=0)
    coolant_temp_k: float = Field(default=363.15, gt=0)
    exhaust_temp_k: float = Field(default=800.0, gt=0)


# --------------------------------------------------------------------------- #
# Constraint envelope
# --------------------------------------------------------------------------- #
class ConstraintLimits(BaseModel):
    """Section 25: hard safety envelope. The optimiser must reject any
    state that violates these limits."""

    max_cylinder_pressure_bar: float = Field(default=180.0, gt=0)
    max_cylinder_gas_temp_k: float = Field(default=2800.0, gt=0)
    max_rpm: float = Field(default=6500.0, gt=0)
    max_boost_kpa: float = Field(default=250.0, ge=0.0)
    max_turbine_speed_rpm: float = Field(default=220_000.0, gt=0)
    max_coolant_temp_k: float = Field(default=383.15, gt=0)
    max_oil_temp_k: float = Field(default=423.15, gt=0)
    min_lambda: float = Field(default=0.75, gt=0.0)
    max_lambda: float = Field(default=1.6, gt=0.0)
    max_exhaust_temp_k: float = Field(default=1223.15, gt=0)
    max_component_stress_mpa: float = Field(default=350.0, gt=0)


class ConstraintViolation(BaseModel):
    parameter: str
    value: float
    limit: float
    kind: str  # "upper" or "lower"

    def __str__(self) -> str:  # pragma: no cover - cosmetic
        rel = ">" if self.kind == "upper" else "<"
        return f"{self.parameter} = {self.value:.3g} {rel} limit {self.limit:.3g}"
