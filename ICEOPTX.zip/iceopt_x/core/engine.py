"""
core.engine
============

The central orchestrator (Section 1/31): wires every subsystem together
into one traceable evaluation chain,

    INPUTS -> AIRFLOW -> MIXTURE -> COMBUSTION -> THERMODYNAMIC WORK ->
    MECHANICAL LOSSES -> BRAKE OUTPUT -> EXHAUST/THERMAL -> EXERGY ->
    EFFICIENCY -> CONSTRAINT CHECK

`Engine.evaluate()` is the single function every optimiser in
`optimisation/` calls; nothing in this codebase computes brake power,
efficiency, or losses through any other path, so every optimisation
result is traceable back through exactly this chain (Section 31).

DESIGN NOTE on boost/turbo coupling: boost pressure is treated as a
controlled operating-point actuator (as real ECUs regulate it via
wastegate/VGT to a target, and Section 21 explicitly lists boost as a
search variable) rather than solved from an iterative turbo shaft
energy balance on every single evaluation. After the exhaust state is
known, `intake.turbo` is used to report whether that boost level is
thermodynamically consistent with the available exhaust energy
(compressor/turbine efficiency, implied wastegate bypass) as a
feasibility check -- the dedicated turbo-matching study in
`optimisation` can call `intake.turbo.solve_shaft_balance` directly for
turbo sizing work.

DESIGN NOTE on energy balance closure: the wall heat loss reported here
comes directly out of the crank-resolved combustion cycle (Woschni,
integrated in the first law -- see thermodynamics.cycle), so brake power
and wall heat are mutually consistent by construction. Exhaust heat is
computed independently via a blowdown-expansion + enthalpy-flow model
(Section 16), which is the most useful form for turbo/heat-recovery
sizing but is not forced to algebraically close the balance to the last
watt. The resulting `EnergyBalance.residual_fraction` is reported
honestly rather than hidden or forced to zero -- see README "Validation
philosophy".
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from iceopt_x.combustion.air_fuel_ratio import MixtureResult, fuel_flow_from_air_and_lambda
from iceopt_x.combustion.combustion import CombustionResult, evaluate_combustion
from iceopt_x.combustion.ignition import search_mbt_timing
from iceopt_x.core.state import (
    AmbientConditions,
    CombustionType,
    ConstraintLimits,
    ConstraintViolation,
    OperatingPoint,
    ThermalState,
)
from iceopt_x.engine.displacement import (
    revolutions_per_power_stroke,
    swept_volume_m3,
    total_displacement_m3,
)
from iceopt_x.engine.engine_model import EngineModel
from iceopt_x.exhaust.backpressure import exhaust_system_backpressure_kpa, total_backpressure_kpa
from iceopt_x.exhaust.exhaust_flow import exhaust_mass_flow_kg_s
from iceopt_x.exhaust.exhaust_temperature import exhaust_port_manifold_temperature_k
from iceopt_x.intake.airflow import AirflowResult, compute_airflow
from iceopt_x.intake.throttle import manifold_pressure_from_throttle_kpa, pumping_mean_effective_pressure_kpa
from iceopt_x.intake.turbo import CompressorResult, TurbineResult, compressor_outlet_state, solve_shaft_balance
from iceopt_x.mechanical.crankshaft import power_from_torque_kw, torque_from_mean_effective_pressure_nm
from iceopt_x.mechanical.mechanical_losses import MechanicalLossBreakdown, compute_mechanical_losses
from iceopt_x.thermal.oil import oil_dynamic_viscosity_pa_s
from iceopt_x.thermal.thermal_state import ThermalBalanceResult, compute_thermal_balance
from iceopt_x.thermodynamics.enthalpy import CP_EXHAUST_KJ_KGK, enthalpy_flow_kw
from iceopt_x.thermodynamics.energy_balance import EnergyBalance
from iceopt_x.thermodynamics.exergy import ExergyBreakdown, build_exergy_breakdown

TURBINE_BACKPRESSURE_TO_BOOST_RATIO = 0.85  # ASSUMPTION: typical modern turbo exhaust backpressure : boost ratio


@dataclass
class EfficiencyResult:
    volumetric_efficiency: float
    combustion_efficiency: float
    indicated_thermal_efficiency: float
    brake_thermal_efficiency: float
    mechanical_efficiency: float
    bsfc_g_per_kwh: float


@dataclass
class EvaluationResult:
    """The full traceable chain for one operating point (Section 31)."""

    inputs: OperatingPoint
    ambient: AmbientConditions
    thermal_state_in: ThermalState

    airflow: AirflowResult
    mixture: MixtureResult
    applied_ignition_timing_btdc_deg: float
    knock_limited: bool
    combustion: CombustionResult

    manifold_pressure_kpa: float
    exhaust_backpressure_kpa: float
    exhaust_mass_flow_kg_s: float
    exhaust_temperature_k: float
    exhaust_heat_available_kw: float
    exhaust_heat_leftover_kw: float
    compressor: CompressorResult | None
    turbine: TurbineResult | None

    gross_imep_kpa: float
    pmep_kpa: float
    net_imep_kpa: float
    indicated_torque_nm: float
    indicated_power_kw: float

    mechanical: MechanicalLossBreakdown
    brake_torque_nm: float
    brake_power_kw: float

    thermal_balance: ThermalBalanceResult
    exergy: ExergyBreakdown
    energy_balance: EnergyBalance
    efficiency: EfficiencyResult

    constraint_violations: list[ConstraintViolation] = field(default_factory=list)

    @property
    def is_feasible(self) -> bool:
        return len(self.constraint_violations) == 0


class Engine:
    """A configured EngineModel plus the single evaluate() entry point
    that walks the full physics chain for one operating point."""

    def __init__(self, model: EngineModel):
        self.model = model

    # ------------------------------------------------------------------ #
    def evaluate(
        self,
        op: OperatingPoint,
        ambient: AmbientConditions | None = None,
        thermal_state: ThermalState | None = None,
    ) -> EvaluationResult:
        geometry = self.model.geometry
        fuel = self.model.fuel
        constraints = self.model.constraints
        ambient = ambient or AmbientConditions()
        thermal_state = thermal_state or ThermalState()

        n_r = revolutions_per_power_stroke(geometry)
        total_disp = total_displacement_m3(geometry)
        swept_single = swept_volume_m3(geometry)
        cycles_per_second = op.rpm / 60.0 / n_r

        # ---- AIRFLOW ---------------------------------------------------
        manifold_pressure_kpa = manifold_pressure_from_throttle_kpa(
            ambient, throttle_fraction=op.load_fraction, boost_pressure_kpa=op.boost_pressure_kpa
        )
        airflow = compute_airflow(
            geometry,
            ambient,
            op.rpm,
            op.load_fraction,
            manifold_pressure_kpa,
            manifold_temperature_k=op.intake_temperature_k,
            boost_pressure_kpa=op.boost_pressure_kpa,
            ve_calibration_multiplier=self.model.calibration_multipliers.get("volumetric_efficiency", 1.0),
        )

        # ---- MIXTURE -----------------------------------------------------
        mixture = fuel_flow_from_air_and_lambda(airflow.air_mass_flow_kg_s, fuel, op.lambda_target)

        # ---- TIMING (Section 11: search, don't assume) --------------------
        is_ci = geometry.combustion_type == CombustionType.COMPRESSION_IGNITION
        if is_ci:
            applied_timing_btdc_deg = op.injection_timing_btdc_deg
            knock_limited = False
        else:
            ign = search_mbt_timing(
                base_mbt_btdc_deg=op.ignition_timing_btdc_deg,
                compression_ratio=geometry.compression_ratio,
                octane_number=fuel.octane_or_cetane,
                intake_temperature_k=op.intake_temperature_k,
                boost_pressure_kpa=op.boost_pressure_kpa,
            )
            applied_timing_btdc_deg = ign.applied_timing_btdc_deg
            knock_limited = ign.knock_limited

        # ---- COMBUSTION (per-cylinder quantities) -------------------------
        air_mass_per_cyl_kg = airflow.air_mass_per_cycle_kg / geometry.cylinder_count
        fuel_mass_per_cyl_kg = (mixture.fuel_mass_flow_kg_s / cycles_per_second) / geometry.cylinder_count

        # EMPIRICAL MODEL: residual (hot, inert) exhaust gas fraction
        # trapped from the previous cycle, approximated from how far
        # manifold pressure sits below ambient (heavy throttling traps
        # more residual; boost pushes it toward zero). See
        # combustion.combustion.evaluate_combustion for how this is used.
        residual_gas_fraction = float(np.clip(0.05 * (ambient.pressure_kpa / manifold_pressure_kpa) ** 1.5, 0.02, 0.30))

        combustion = evaluate_combustion(
            geometry=geometry,
            fuel=fuel,
            air_mass_per_cycle_kg=air_mass_per_cyl_kg,
            fuel_mass_per_cycle_kg=fuel_mass_per_cyl_kg,
            lambda_value=op.lambda_target,
            ivc_pressure_kpa=manifold_pressure_kpa,
            ivc_temperature_k=op.intake_temperature_k,
            rpm=op.rpm,
            timing_btdc_deg=applied_timing_btdc_deg,
            wall_temperature_k=thermal_state.block_temp_k,
            combustion_efficiency_multiplier=self.model.calibration_multipliers.get("combustion_efficiency", 1.0),
            residual_gas_fraction=residual_gas_fraction,
        )

        # ---- EXHAUST -------------------------------------------------------
        # Exhaust manifold temperature is taken from the closed-cycle EVO
        # state directly (plus the port/manifold heat-loss fraction), NOT
        # from an isentropic-expansion pressure-ratio scaling down to
        # manifold pressure. Blowdown through the exhaust valve converts
        # pressure into gas velocity (kinetic energy) which then
        # re-thermalises via turbulent mixing a short distance into the
        # port -- over the cylinder-to-manifold control volume the process
        # is close to isenthalpic (throttling), not isentropic, so
        # treating it as isentropic would fictitiously "extract work"
        # that was never delivered to the piston and break the energy
        # balance. `exhaust.exhaust_temperature.blowdown_expansion_temperature_k`
        # is kept available for callers who explicitly want the
        # (less energy-conservative) isentropic estimate.
        m_dot_exhaust = exhaust_mass_flow_kg_s(airflow.air_mass_flow_kg_s, mixture.fuel_mass_flow_kg_s)
        exhaust_sys_backpressure_kpa = exhaust_system_backpressure_kpa(m_dot_exhaust)
        evo_temp_k = float(combustion.cycle.temperature_k[-1])
        evo_pressure_pa = float(combustion.cycle.pressure_pa[-1])

        exhaust_temp_k = exhaust_port_manifold_temperature_k(evo_temp_k, ambient_temperature_k=ambient.temperature_k)

        compressor_result = None
        turbine_result = None
        post_turbine_temp_k = exhaust_temp_k
        if geometry.aspiration.value == "turbocharged":
            # Section 17: solve the compressor/turbine shaft power balance
            # for real, rather than assuming a fixed backpressure:boost
            # ratio -- this is also what makes "+1% compressor efficiency"
            # / "+1% turbine efficiency" genuine marginal-gain levers
            # (Section 23), not cosmetic multipliers.
            pressure_ratio = max((ambient.pressure_kpa + op.boost_pressure_kpa) / ambient.pressure_kpa, 1.001)
            compressor_result = compressor_outlet_state(
                ambient.temperature_k,
                ambient.pressure_kpa,
                pressure_ratio,
                airflow.air_mass_flow_kg_s,
                efficiency_calibration_multiplier=self.model.calibration_multipliers.get("compressor_efficiency", 1.0),
            )
            try:
                turbine_result = solve_shaft_balance(
                    compressor_result,
                    turbine_inlet_temperature_k=exhaust_temp_k,
                    exhaust_mass_flow_kg_s=max(m_dot_exhaust, 1e-6),
                    mechanical_efficiency=0.97,
                    turbine_efficiency_calibration_multiplier=self.model.calibration_multipliers.get("turbine_efficiency", 1.0),
                )
                downstream_of_turbine_kpa = ambient.pressure_kpa + 5.0  # ASSUMPTION: small residual muffler backpressure past the turbine
                turbine_inlet_pressure_kpa = turbine_result.expansion_ratio * downstream_of_turbine_kpa
                turbine_dp_kpa = max(turbine_inlet_pressure_kpa - ambient.pressure_kpa, 0.0)
                post_turbine_temp_k = turbine_result.outlet_temperature_k
            except Exception:
                turbine_dp_kpa = TURBINE_BACKPRESSURE_TO_BOOST_RATIO * op.boost_pressure_kpa  # fallback if shaft balance fails to converge
        else:
            turbine_dp_kpa = 0.0
        exhaust_backpressure_kpa = total_backpressure_kpa(exhaust_sys_backpressure_kpa, turbine_dp_kpa)

        # ---- INDICATED WORK (net of pumping) --------------------------------
        gross_imep_kpa = combustion.gross_indicated_work_j / swept_single / 1000.0
        pmep_kpa = pumping_mean_effective_pressure_kpa(ambient, manifold_pressure_kpa, exhaust_backpressure_kpa)
        net_imep_kpa = gross_imep_kpa - pmep_kpa

        indicated_torque_nm = torque_from_mean_effective_pressure_nm(net_imep_kpa, total_disp, n_r)
        indicated_power_kw = power_from_torque_kw(indicated_torque_nm, op.rpm)

        # ---- MECHANICAL LOSSES -> BRAKE OUTPUT (Section 13/14) ---------------
        oil_visc = oil_dynamic_viscosity_pa_s(thermal_state.oil_temp_k)
        mech = compute_mechanical_losses(
            geometry=geometry,
            rpm=op.rpm,
            peak_cylinder_pressure_kpa=combustion.peak_cylinder_pressure_bar * 100.0,
            oil_viscosity_pa_s=oil_visc,
            total_displacement_m3=total_disp,
            indicated_power_kw=indicated_power_kw,
            imep_kpa=net_imep_kpa,
            friction_calibration_multiplier=self.model.calibration_multipliers.get("friction", 1.0),
        )
        brake_power_kw = mech.brake_power_kw
        omega = op.rpm * 2.0 * math.pi / 60.0
        brake_torque_nm = brake_power_kw * 1000.0 / omega if omega > 0 else 0.0

        # ---- THERMAL BALANCE (Section 15) -------------------------------------
        wall_heat_loss_kw = combustion.wall_heat_loss_j * geometry.cylinder_count * cycles_per_second / 1000.0
        fuel_energy_kw = mixture.fuel_mass_flow_kg_s * fuel.lower_heating_value_mj_kg * 1000.0
        thermal_balance = compute_thermal_balance(
            wall_heat_loss_kw=wall_heat_loss_kw,
            coolant_inlet_temp_k=thermal_state.coolant_temp_k,
            ambient_temp_k=ambient.temperature_k,
            fuel_energy_kw=fuel_energy_kw,
        )

        # ---- EXHAUST ENERGY (Section 16) ---------------------------------------
        # `exhaust_heat_available_kw` is the gross exhaust energy stream at
        # the manifold, upstream of anything drawn off it (Section 16:
        # "determine how much energy is available for turbocharging, heat
        # recovery..."). The turbine's extraction (turbine.power_kw) is
        # already spent driving the compressor -- which is what raises
        # net_imep above gross_imep for a boosted engine, i.e. it already
        # shows up as extra brake power -- so crediting the *same* energy
        # a second time as leftover exhaust heat would double-count it in
        # the energy balance. `exhaust_heat_leftover_kw` (post-turbine
        # temperature) is what the balance and Section 18 heat-recovery
        # sizing should use; `exhaust_heat_available_kw` is kept for
        # traceability of the gross stream.
        exhaust_heat_available_kw = enthalpy_flow_kw(m_dot_exhaust, exhaust_temp_k, CP_EXHAUST_KJ_KGK, ambient.temperature_k)
        exhaust_heat_leftover_kw = enthalpy_flow_kw(m_dot_exhaust, post_turbine_temp_k, CP_EXHAUST_KJ_KGK, ambient.temperature_k)

        # ---- LOSSES for energy balance / exergy --------------------------------
        pumping_power_kw = pmep_kpa * total_disp * cycles_per_second  # kPa * m^3 / s = kW
        heat_released_total_kw = combustion.heat_released_j * geometry.cylinder_count * cycles_per_second / 1000.0
        combustion_loss_kw = max(fuel_energy_kw - heat_released_total_kw, 0.0)

        energy_balance = EnergyBalance(
            fuel_energy_kw=fuel_energy_kw,
            brake_power_kw=brake_power_kw,
            exhaust_heat_kw=exhaust_heat_leftover_kw,
            coolant_heat_kw=thermal_balance.coolant_heat_kw,
            oil_radiative_heat_kw=thermal_balance.oil_heat_kw + thermal_balance.radiative_misc_loss_kw,
            friction_heat_kw=mech.total_friction_power_kw,
            pumping_heat_kw=max(pumping_power_kw, 0.0),
            combustion_loss_kw=combustion_loss_kw,
        )

        exergy = build_exergy_breakdown(
            fuel_mass_flow_kg_s=mixture.fuel_mass_flow_kg_s,
            lhv_mj_kg=fuel.lower_heating_value_mj_kg,
            exergy_factor=fuel.exergy_factor,
            brake_power_kw=brake_power_kw,
            exhaust_heat_kw=exhaust_heat_leftover_kw,
            exhaust_avg_temp_k=post_turbine_temp_k,
            coolant_heat_kw=thermal_balance.coolant_heat_kw,
            coolant_avg_temp_k=thermal_state.coolant_temp_k,
            friction_power_kw=mech.total_friction_power_kw,
            pumping_power_kw=max(pumping_power_kw, 0.0),
            ambient_temperature_k=ambient.temperature_k,
        )

        # ---- EFFICIENCY SUMMARY -------------------------------------------------
        brake_eff = brake_power_kw / fuel_energy_kw if fuel_energy_kw > 0 else 0.0
        ind_eff = indicated_power_kw / fuel_energy_kw if fuel_energy_kw > 0 else 0.0
        mech_eff = brake_power_kw / indicated_power_kw if indicated_power_kw > 0 else 0.0
        bsfc = (mixture.fuel_mass_flow_kg_h * 1000.0) / brake_power_kw if brake_power_kw > 1e-6 else float("inf")

        efficiency = EfficiencyResult(
            volumetric_efficiency=airflow.volumetric_efficiency,
            combustion_efficiency=combustion.combustion_efficiency,
            indicated_thermal_efficiency=ind_eff,
            brake_thermal_efficiency=brake_eff,
            mechanical_efficiency=mech_eff,
            bsfc_g_per_kwh=bsfc,
        )

        # ---- CONSTRAINT CHECK (Section 25) ---------------------------------------
        violations = self._check_constraints(
            op, combustion, exhaust_temp_k, thermal_state, constraints
        )

        return EvaluationResult(
            inputs=op,
            ambient=ambient,
            thermal_state_in=thermal_state,
            airflow=airflow,
            mixture=mixture,
            applied_ignition_timing_btdc_deg=applied_timing_btdc_deg,
            knock_limited=knock_limited,
            combustion=combustion,
            manifold_pressure_kpa=manifold_pressure_kpa,
            exhaust_backpressure_kpa=exhaust_backpressure_kpa,
            exhaust_mass_flow_kg_s=m_dot_exhaust,
            exhaust_temperature_k=exhaust_temp_k,
            exhaust_heat_available_kw=exhaust_heat_available_kw,
            exhaust_heat_leftover_kw=exhaust_heat_leftover_kw,
            compressor=compressor_result,
            turbine=turbine_result,
            gross_imep_kpa=gross_imep_kpa,
            pmep_kpa=pmep_kpa,
            net_imep_kpa=net_imep_kpa,
            indicated_torque_nm=indicated_torque_nm,
            indicated_power_kw=indicated_power_kw,
            mechanical=mech,
            brake_torque_nm=brake_torque_nm,
            brake_power_kw=brake_power_kw,
            thermal_balance=thermal_balance,
            exergy=exergy,
            energy_balance=energy_balance,
            efficiency=efficiency,
            constraint_violations=violations,
        )

    @staticmethod
    def _check_constraints(
        op: OperatingPoint,
        combustion: CombustionResult,
        exhaust_temp_k: float,
        thermal_state: ThermalState,
        limits: ConstraintLimits,
    ) -> list[ConstraintViolation]:
        checks: list[ConstraintViolation] = []

        def upper(name: str, value: float, limit: float) -> None:
            if value > limit:
                checks.append(ConstraintViolation(parameter=name, value=value, limit=limit, kind="upper"))

        def lower(name: str, value: float, limit: float) -> None:
            if value < limit:
                checks.append(ConstraintViolation(parameter=name, value=value, limit=limit, kind="lower"))

        upper("rpm", op.rpm, limits.max_rpm)
        upper("peak_cylinder_pressure_bar", combustion.peak_cylinder_pressure_bar, limits.max_cylinder_pressure_bar)
        upper("peak_cylinder_gas_temp_k", combustion.peak_temperature_k, limits.max_cylinder_gas_temp_k)
        upper("boost_pressure_kpa", op.boost_pressure_kpa, limits.max_boost_kpa)
        upper("coolant_temperature_k", thermal_state.coolant_temp_k, limits.max_coolant_temp_k)
        upper("oil_temperature_k", thermal_state.oil_temp_k, limits.max_oil_temp_k)
        upper("exhaust_temperature_k", exhaust_temp_k, limits.max_exhaust_temp_k)
        upper("lambda", op.lambda_target, limits.max_lambda)
        lower("lambda", op.lambda_target, limits.min_lambda)

        return checks
