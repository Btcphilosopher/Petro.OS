"""core subpackage of ICEOPT-X."""
