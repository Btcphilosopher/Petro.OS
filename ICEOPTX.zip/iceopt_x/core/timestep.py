"""
core.timestep
==============

The real-time optimisation loop (Section 24):

    READ ENGINE STATE -> CALCULATE THERMODYNAMICS -> CALCULATE LOSSES ->
    CALCULATE PERFORMANCE -> SEARCH OPTIMAL OPERATING POINT ->
    CHECK CONSTRAINTS -> GENERATE SETPOINT -> REPEAT

This module is deliberately independent of any particular clock: the
same `RealTimeLoop.step()` can be driven at millisecond, second, or
minute cadence by whatever is calling it (a live telemetry feed, a
batch simulation driver, or a test). Model fidelity should be matched to
the interval in use -- see `step()`'s docstring.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from iceopt_x.core.engine import Engine, EvaluationResult
from iceopt_x.core.events import EventKind, EventLog
from iceopt_x.core.state import AmbientConditions, OperatingPoint, ThermalState
from iceopt_x.optimisation.optimizer import GlobalOptimizer, OptimizationResult


@dataclass
class LoopState:
    op: OperatingPoint
    ambient: AmbientConditions
    thermal_state: ThermalState
    last_evaluation: EvaluationResult | None = None
    last_optimization: OptimizationResult | None = None
    step_count: int = 0


@dataclass
class RealTimeLoop:
    engine: Engine
    state: LoopState
    objective: str = "brake_thermal_efficiency"
    reoptimize_every_n_steps: int = 1
    events: EventLog = field(default_factory=EventLog)

    def step(self, dt_s: float, target_rpm: float | None = None, target_load_fraction: float | None = None) -> EvaluationResult:
        """Advance the loop by one control interval.

        `dt_s` sets the model fidelity expectation, not the arithmetic
        (this is a quasi-steady-state loop, not a transient simulator):
        - dt_s ~ 1e-3 - 1e-2 s: crank-resolved fidelity is meaningful
          (the closed-cycle combustion model already resolves better
          than this internally).
        - dt_s ~ 0.1 - 10 s: cycle-averaged control-loop cadence, the
          intended use (ECU-like setpoint search).
        - dt_s ~ 60+ s: scenario/duty-cycle stepping (see
          optimisation.scenarios) -- thermal_state should be advanced
          externally between calls at this cadence.
        """
        if target_rpm is not None:
            self.state.op = self.state.op.model_copy(update={"rpm": target_rpm})
        if target_load_fraction is not None:
            self.state.op = self.state.op.model_copy(update={"load_fraction": target_load_fraction})

        if self.state.step_count % self.reoptimize_every_n_steps == 0:
            optimizer = GlobalOptimizer(self.engine)
            opt_result = optimizer.optimize(
                rpm=self.state.op.rpm,
                load_fraction=self.state.op.load_fraction,
                objective=self.objective,
                ambient=self.state.ambient,
                maxiter=20,
                popsize=10,
            )
            self.state.last_optimization = opt_result
            new_op = opt_result.evaluation.inputs
            self.events.record(
                EventKind.SETPOINT_CHANGE,
                f"New setpoint at step {self.state.step_count}: lambda={new_op.lambda_target:.3f}",
                rpm=new_op.rpm,
                load_fraction=new_op.load_fraction,
            )
            self.state.op = new_op
            result = opt_result.evaluation
        else:
            result = self.engine.evaluate(self.state.op, self.state.ambient, self.state.thermal_state)

        if not result.is_feasible:
            for v in result.constraint_violations:
                self.events.record(EventKind.CONSTRAINT_VIOLATION, str(v))

        self.state.last_evaluation = result
        self.state.step_count += 1
        return result
