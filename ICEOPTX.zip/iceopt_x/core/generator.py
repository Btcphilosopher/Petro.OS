"""
core.generator
================

Engine-as-generator mode (Section 28): the ICE runs at a fixed
(or narrow-band) RPM driving an electrical generator, so the optimiser's
job is to find the most efficient (RPM, load) region for a given
electrical demand rather than following vehicle-style transient
operation.
"""
from __future__ import annotations

from dataclasses import dataclass

from iceopt_x.core.engine import Engine, EvaluationResult
from iceopt_x.core.state import AmbientConditions, OperatingPoint, ThermalState
from iceopt_x.exhaust.heat_recovery import recoverable_exhaust_heat
from iceopt_x.optimisation.optimizer import GlobalOptimizer

GENERATOR_ELECTRICAL_EFFICIENCY = 0.95  # ASSUMPTION: modern synchronous/PM generator + rectifier chain


@dataclass
class GeneratorOperatingResult:
    rpm: float
    load_fraction: float
    evaluation: EvaluationResult
    electrical_power_kw: float
    thermal_recovery_kw: float
    fuel_flow_kg_h: float
    electrical_efficiency: float
    total_useful_efficiency: float

    def energy_over_duration(self, hours: float) -> dict[str, float]:
        return {
            "electrical_kwh": self.electrical_power_kw * hours,
            "thermal_kwh": self.thermal_recovery_kw * hours,
            "fuel_kg": self.fuel_flow_kg_h * hours,
        }


def evaluate_generator_point(
    engine: Engine,
    rpm: float,
    load_fraction: float,
    ambient: AmbientConditions | None = None,
    thermal_state: ThermalState | None = None,
    result: EvaluationResult | None = None,
    lambda_target: float = 1.0,
    heat_recovery_effectiveness: float = 0.65,
    **op_kwargs,
) -> GeneratorOperatingResult:
    """Pass a pre-computed `result` (e.g. from GlobalOptimizer) to avoid
    re-evaluating; otherwise a plain stoichiometric operating point is
    built and evaluated directly."""
    ambient = ambient or AmbientConditions()
    thermal_state = thermal_state or ThermalState()
    if result is None:
        op = OperatingPoint(rpm=rpm, load_fraction=load_fraction, lambda_target=lambda_target, **op_kwargs)
        result = engine.evaluate(op, ambient, thermal_state)

    electrical_kw = result.brake_power_kw * GENERATOR_ELECTRICAL_EFFICIENCY
    recovery = recoverable_exhaust_heat(
        result.exhaust_mass_flow_kg_s,
        result.exhaust_temperature_k,
        ambient.temperature_k,
        heat_exchanger_effectiveness=heat_recovery_effectiveness,
    )
    thermal_kw = recovery.recoverable_heat_kw + result.thermal_balance.coolant_heat_kw * 0.5  # ASSUMPTION: coolant heat is ~50% practically recoverable via a jacket-water heat exchanger

    fuel_energy_kw = result.mixture.fuel_mass_flow_kg_h / 3600.0 * engine.model.fuel.lower_heating_value_mj_kg * 1000.0
    electrical_eff = electrical_kw / fuel_energy_kw if fuel_energy_kw > 0 else 0.0
    total_useful_eff = (electrical_kw + thermal_kw) / fuel_energy_kw if fuel_energy_kw > 0 else 0.0

    return GeneratorOperatingResult(
        rpm=rpm,
        load_fraction=load_fraction,
        evaluation=result,
        electrical_power_kw=electrical_kw,
        thermal_recovery_kw=thermal_kw,
        fuel_flow_kg_h=result.mixture.fuel_mass_flow_kg_h,
        electrical_efficiency=electrical_eff,
        total_useful_efficiency=total_useful_eff,
    )


def find_optimal_generator_setpoint(
    engine: Engine,
    target_electrical_kw: float,
    rpm_candidates: list[float] | None = None,
    ambient: AmbientConditions | None = None,
    thermal_state: ThermalState | None = None,
    objective: str = "maximum_total_useful_energy",
) -> GeneratorOperatingResult:
    """For each candidate fixed generator RPM, optimise load/AFR/timing
    to hit the target electrical output as efficiently as possible, then
    pick the best RPM (Section 28: "identify the most efficient operating
    region rather than following vehicle-style transient operation")."""
    ambient = ambient or AmbientConditions()
    thermal_state = thermal_state or ThermalState()
    rpm_candidates = rpm_candidates or [1500.0, 1800.0, 2200.0, 2600.0, 3000.0]

    optimizer = GlobalOptimizer(engine)
    best: GeneratorOperatingResult | None = None
    fallback: GeneratorOperatingResult | None = None

    for rpm in rpm_candidates:
        # Coarse load search: at each candidate fixed generator RPM, find
        # the load fraction giving ~target electrical power, optimising
        # AFR/timing/boost at every point (not just assuming stoichiometric).
        for load in [0.3, 0.5, 0.7, 0.85, 1.0]:
            opt_result = optimizer.optimize(rpm, load, objective=objective, ambient=ambient, maxiter=25, popsize=10)
            candidate = evaluate_generator_point(engine, rpm, load, ambient, thermal_state, result=opt_result.evaluation)
            if fallback is None or candidate.electrical_power_kw > fallback.electrical_power_kw:
                fallback = candidate
            if not candidate.evaluation.is_feasible:
                continue
            if candidate.electrical_power_kw < target_electrical_kw * 0.9:
                continue
            if best is None or candidate.total_useful_efficiency > best.total_useful_efficiency:
                best = candidate

    return best if best is not None else fallback
