import React, { useState, useEffect } from 'react';
import { 
  FuelStation, FuelType, StoreProduct, Promotion, Vehicle, 
  WalletTransaction, DigitalReceipt, CoffeeOrder, CarWashBooking, EVChargingSession, SupportMessage 
} from '../types';
import { STORE_PRODUCTS } from '../data';
import { 
  MapPin, CreditCard, Award, History, Car, ShoppingBag, Coffee, ArrowRight,
  Shield, Check, Play, User, Bell, ChevronRight, PhoneCall, Key, HelpCircle, 
  Sparkles, RefreshCw, Smartphone, Plus, ArrowUpRight, ArrowDownLeft, Send, Compass, Zap
} from 'lucide-react';

interface CustomerAppProps {
  stations: FuelStation[];
  promotions: Promotion[];
  onClaimPromo: (promoId: string) => void;
  vehicles: Vehicle[];
  onAddVehicle: (newVehicle: Vehicle) => void;
  walletBalance: number;
  onUpdateWallet: (newBalance: number) => void;
  transactions: WalletTransaction[];
  onAddTransaction: (tx: WalletTransaction) => void;
  receipts: DigitalReceipt[];
  onAddReceipt: (receipt: DigitalReceipt) => void;
  activeOrders: CoffeeOrder[];
  onAddCoffeeOrder: (order: CoffeeOrder) => void;
  activeWashBookings: CarWashBooking[];
  onAddWashBooking: (booking: CarWashBooking) => void;
  onTriggerStaffSync: () => void;
}

export default function CustomerApp({
  stations,
  promotions,
  onClaimPromo,
  vehicles,
  onAddVehicle,
  walletBalance,
  onUpdateWallet,
  transactions,
  onAddTransaction,
  receipts,
  onAddReceipt,
  activeOrders,
  onAddCoffeeOrder,
  activeWashBookings,
  onAddWashBooking,
  onTriggerStaffSync
}: CustomerAppProps) {
  // Navigation & States
  const [currentTab, setCurrentTab] = useState<'home' | 'stations' | 'pay' | 'store' | 'wallet' | 'more'>('home');
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(true);
  const [authStep, setAuthStep] = useState<'login' | 'register' | 'otp' | 'biometric'>('login');
  
  // Form input states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [otpCode, setOtpCode] = useState('');
  
  // Selected station inside locator
  const [selectedStation, setSelectedStation] = useState<FuelStation | null>(stations[0]);
  const [stationFilters, setStationFilters] = useState({
    evOnly: false,
    washOnly: false,
    openOnly: false,
    maxDistance: 10
  });

  // Pay at Pump Simulation Wizard
  const [fuelingStep, setFuelingStep] = useState<number>(1);
  const [fuelStation, setFuelStation] = useState<FuelStation>(stations[0]);
  const [selectedPump, setSelectedPump] = useState<number | null>(null);
  const [selectedFuel, setSelectedFuel] = useState<FuelType>('Regular Petrol');
  const [fuelAmountLimit, setFuelAmountLimit] = useState<number>(50); // preset default £50
  const [fuelingPayment, setFuelingPayment] = useState<string>('BP Wallet');
  const [isAuthorizing, setIsAuthorizing] = useState<boolean>(false);
  const [fuelingLiters, setFuelingLiters] = useState<number>(0);
  const [fuelingCost, setFuelingCost] = useState<number>(0);
  const [fuelingProgress, setFuelingProgress] = useState<number>(0);
  const [generatedReceipt, setGeneratedReceipt] = useState<DigitalReceipt | null>(null);

  // Coffee Customizer Custom State
  const [coffeeStep, setCoffeeStep] = useState<'catalog' | 'customize' | 'checkout' | 'qr'>('catalog');
  const [selectedProduct, setSelectedProduct] = useState<StoreProduct | null>(null);
  const [coffeeSize, setCoffeeSize] = useState<'Regular' | 'Large'>('Regular');
  const [coffeeMilk, setCoffeeMilk] = useState<'Full Cream' | 'Skimmed' | 'Oat' | 'Almond'>('Full Cream');
  const [coffeeSugar, setCoffeeSugar] = useState<'None' | 'One' | 'Two' | 'Sweetener'>('None');
  const [coffeeFlavor, setCoffeeFlavor] = useState<'None' | 'Vanilla' | 'Caramel' | 'Hazelnut'>('None');
  const [coffeePickupTime, setCoffeePickupTime] = useState<string>('As soon as possible (5 mins)');
  const [latestCoffeeOrder, setLatestCoffeeOrder] = useState<CoffeeOrder | null>(null);

  // Car Wash selection
  const [washStep, setWashStep] = useState<'packages' | 'schedule' | 'success'>('packages');
  const [selectedWashPackage, setSelectedWashPackage] = useState<'Basic Wash' | 'Deluxe Wash' | 'Premium Wash' | null>(null);
  const [washPrice, setWashPrice] = useState<number>(0);
  const [washScheduleTime, setWashScheduleTime] = useState<string>('Today, 14:00');
  const [latestWashBooking, setLatestWashBooking] = useState<CarWashBooking | null>(null);

  // EV charging session simulation
  const [evStep, setEvStep] = useState<'select' | 'charging' | 'summary'>('select');
  const [activeEvSession, setActiveEvSession] = useState<EVChargingSession | null>(null);

  // Garage addition states
  const [newReg, setNewReg] = useState('');
  const [newMake, setNewMake] = useState('');
  const [newModel, setNewModel] = useState('');
  const [newYear, setNewYear] = useState<number>(2023);
  const [newFuel, setNewFuel] = useState<FuelType>('Regular Petrol');

  // Wallet add funds modal
  const [addFundsAmount, setAddFundsAmount] = useState<string>('20');
  const [showAddFundsModal, setShowAddFundsModal] = useState<boolean>(false);

  // Support live chat mock state
  const [chatMessages, setChatMessages] = useState<SupportMessage[]>([
    { id: 'm1', sender: 'agent', text: 'Hello! Welcome to BP Support. How can we assist you with your fueling or loyalty account today?', timestamp: '08:25' }
  ]);
  const [newMessageText, setNewMessageText] = useState('');

  // Notifications
  const [notifications, setNotifications] = useState([
    { id: 'n1', title: 'Double Points Active!', text: 'Earn 2x points on premium fuel fills this weekend.', time: '2 hours ago' },
    { id: 'n2', title: 'Fuel price reduction', text: 'Prices at BP Hammersmith reduced by 2p/L today.', time: '1 day ago' }
  ]);

  // Flip Loyalty Card
  const [cardFlipped, setCardFlipped] = useState<boolean>(false);

  // EV charging interval simulator
  useEffect(() => {
    let interval: any;
    if (evStep === 'charging' && activeEvSession) {
      interval = setInterval(() => {
        setActiveEvSession(prev => {
          if (!prev) return null;
          const nextSoC = prev.stateOfCharge + 2;
          const nextDuration = prev.duration + 1;
          const costPerMin = 0.5;
          const nextCost = prev.cost + costPerMin;
          if (nextSoC >= 100) {
            setEvStep('summary');
            clearInterval(interval);
            return {
              ...prev,
              stateOfCharge: 100,
              duration: nextDuration,
              estimatedMinutesLeft: 0,
              cost: nextCost,
              status: 'Completed'
            };
          }
          return {
            ...prev,
            stateOfCharge: nextSoC,
            duration: nextDuration,
            estimatedMinutesLeft: Math.max(0, 30 - nextDuration),
            cost: nextCost
          };
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [evStep, activeEvSession]);

  // Authenticate logic
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthStep('otp');
  };

  const handleOtpVerify = () => {
    setIsAuthenticated(true);
    setCurrentTab('home');
  };

  // Add vehicle
  const handleAddVehicleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReg || !newMake || !newModel) return;
    const v: Vehicle = {
      id: `v-${Date.now()}`,
      registration: newReg.toUpperCase(),
      make: newMake,
      model: newModel,
      year: newYear,
      fuelType: newFuel,
      mileage: 24000,
      reminders: {
        mot: '2027-02-18',
        insurance: '2027-05-10',
        service: '2027-08-22',
        oilChange: newFuel === 'EV Charging' ? 'N/A' : '2026-12-15'
      }
    };
    onAddVehicle(v);
    setNewReg('');
    setNewMake('');
    setNewModel('');
    alert(`Vehicle ${v.make} ${v.model} added to your BP Garage successfully!`);
  };

  // Wallet add funds submit
  const handleAddFundsSubmit = () => {
    const val = parseFloat(addFundsAmount);
    if (isNaN(val) || val <= 0) return;
    onUpdateWallet(walletBalance + val);
    onAddTransaction({
      id: `tx-${Date.now()}`,
      date: '2026-07-18 08:30',
      description: 'Wallet Deposit - Google Pay',
      amount: val,
      type: 'credit'
    });
    setShowAddFundsModal(false);
    setAddFundsAmount('20');
  };

  // Pay at Pump Simulation triggers
  const startFuelingProcess = () => {
    if (walletBalance < fuelAmountLimit && fuelingPayment === 'BP Wallet') {
      alert(`Insufficient funds in your BP Wallet (£${walletBalance.toFixed(2)}). Please top up or choose another payment method.`);
      return;
    }
    
    setIsAuthorizing(true);
    setTimeout(() => {
      setIsAuthorizing(false);
      setFuelingStep(5); // Active fueling screen
      
      // Simulate fuel flowing
      let progress = 0;
      const fuelPriceVal = fuelStation.fuels[selectedFuel]?.price || 1.459;
      const targetLiters = fuelAmountLimit / fuelPriceVal;
      
      const interval = setInterval(() => {
        progress += 5;
        setFuelingProgress(progress);
        setFuelingLiters((progress / 100) * targetLiters);
        setFuelingCost((progress / 100) * fuelAmountLimit);
        
        if (progress >= 100) {
          clearInterval(interval);
          
          // Complete fueling and generate receipt
          const newBalance = walletBalance - fuelAmountLimit;
          if (fuelingPayment === 'BP Wallet') {
            onUpdateWallet(newBalance);
          }
          
          const receiptId = `rec-${1000 + receipts.length + 1}`;
          const newReceipt: DigitalReceipt = {
            id: receiptId,
            date: '2026-07-18',
            time: '08:35',
            stationId: fuelStation.id,
            stationName: fuelStation.name,
            pumpNumber: selectedPump || 3,
            fuelType: selectedFuel,
            liters: parseFloat(((100 / 100) * targetLiters).toFixed(2)),
            amount: fuelAmountLimit,
            pricePerLiter: fuelPriceVal,
            paymentMethod: fuelingPayment,
            vatInvoice: `GB123456789-${receiptId}`
          };
          
          onAddReceipt(newReceipt);
          onAddTransaction({
            id: `tx-${Date.now()}`,
            date: '2026-07-18 08:35',
            description: `Fuel Fill - ${fuelStation.name}`,
            amount: -fuelAmountLimit,
            type: 'debit'
          });
          
          // Add Loyalty points (2 points per £1 spent)
          const earnedPoints = Math.round(fuelAmountLimit * 2);
          onAddTransaction({
            id: `tx-pts-${Date.now()}`,
            date: '2026-07-18 08:35',
            description: `Earned Points - Fuel Purchase`,
            amount: earnedPoints,
            type: 'credit'
          });

          setGeneratedReceipt(newReceipt);
          setFuelingStep(6); // Receipt stage
          onTriggerStaffSync(); // Notify staff portal
        }
      }, 150);
    }, 1500);
  };

  // Coffee order customizer
  const handleCoffeeSelect = (prod: StoreProduct) => {
    setSelectedProduct(prod);
    setCoffeeStep('customize');
  };

  const handleCoffeeOrderSubmit = () => {
    if (!selectedProduct) return;
    const priceVal = selectedProduct.price + (coffeeSize === 'Large' ? 0.40 : 0);
    
    if (walletBalance < priceVal) {
      alert("Insufficient wallet balance. Please add funds.");
      return;
    }
    
    onUpdateWallet(walletBalance - priceVal);
    
    const newOrd: CoffeeOrder = {
      id: `ord-${Date.now()}`,
      name: `${selectedProduct.name} (${coffeeSize})`,
      size: coffeeSize,
      milk: coffeeMilk,
      sugar: coffeeSugar,
      flavor: coffeeFlavor,
      pickupTime: coffeePickupTime,
      price: priceVal,
      status: 'Pending',
      qrCode: `QR_COFFEE_${Date.now()}`
    };
    
    onAddCoffeeOrder(newOrd);
    onAddTransaction({
      id: `tx-${Date.now()}`,
      date: '2026-07-18 08:31',
      description: `Coffee Ordered - Wild Bean`,
      amount: -priceVal,
      type: 'debit'
    });
    onAddTransaction({
      id: `tx-pts-${Date.now()}`,
      date: '2026-07-18 08:31',
      description: 'Earned Points - Store Purchase',
      amount: Math.round(priceVal * 3), // 3 points per £1 on store
      type: 'credit'
    });
    
    setLatestCoffeeOrder(newOrd);
    setCoffeeStep('qr');
    onTriggerStaffSync(); // Sync to staff dashboard
  };

  // Book car wash
  const handleWashSelect = (pkg: 'Basic Wash' | 'Deluxe Wash' | 'Premium Wash', price: number) => {
    setSelectedWashPackage(pkg);
    setWashPrice(price);
    setWashStep('schedule');
  };

  const handleWashOrderSubmit = () => {
    if (!selectedWashPackage) return;
    if (walletBalance < washPrice) {
      alert("Insufficient wallet balance.");
      return;
    }
    
    onUpdateWallet(walletBalance - washPrice);
    const newWash: CarWashBooking = {
      id: `wash-${Date.now()}`,
      packageName: selectedWashPackage,
      price: washPrice,
      features: selectedWashPackage === 'Premium Wash' 
        ? ['Underbody Blast', 'Super Wax Polish', 'Wheel Scrape Polish', 'Turbo Dry']
        : selectedWashPackage === 'Deluxe Wash'
        ? ['Active Foam Coat', 'Spray Wax', 'Wheel Cleaner', 'Blow Dry']
        : ['Basic Shower', 'Double Brush Wash', 'Towel Dry'],
      scheduleTime: washScheduleTime,
      status: 'Active',
      qrCode: `QR_WASH_${Date.now()}`
    };
    
    onAddWashBooking(newWash);
    onAddTransaction({
      id: `tx-${Date.now()}`,
      date: '2026-07-18 08:32',
      description: `${selectedWashPackage} Booked`,
      amount: -washPrice,
      type: 'debit'
    });
    
    setLatestWashBooking(newWash);
    setWashStep('success');
  };

  // Support messages submit
  const handleSendMessage = () => {
    if (!newMessageText.trim()) return;
    const userMsg: SupportMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: newMessageText,
      timestamp: '08:26'
    };
    setChatMessages(prev => [...prev, userMsg]);
    setNewMessageText('');

    setTimeout(() => {
      let botText = "Thank you for contacting BP Customer Support. Your query is registered and our customer service specialist will assist you shortly.";
      if (newMessageText.toLowerCase().includes('wallet') || newMessageText.toLowerCase().includes('pay')) {
        botText = "For quick wallet questions: You can securely top up using Google Pay, Visa, or Mastercard instantly. Standard fueling payments authorize a pre-selected limit and refund unused amounts within minutes.";
      } else if (newMessageText.toLowerCase().includes('loyalty') || newMessageText.toLowerCase().includes('point')) {
        botText = "Your BP Loyalty Points are automatically computed: Fuel yields 2 points per £1, and our Wild Bean cafe orders earn 3 points per £1. Redeem points under the Rewards panel!";
      }
      
      setChatMessages(prev => [...prev, {
        id: `msg-${Date.now() + 1}`,
        sender: 'agent',
        text: botText,
        timestamp: '08:26'
      }]);
    }, 1000);
  };

  // EV Charging session startup
  const startEvChargingSession = (chargerId: string) => {
    const ses: EVChargingSession = {
      id: `ev-${Date.now()}`,
      stationId: selectedStation?.id || 'st-01',
      chargerId: chargerId,
      speed: '150 kW Ultra Fast',
      stateOfCharge: 18,
      duration: 0,
      estimatedMinutesLeft: 30,
      cost: 0,
      status: 'Active'
    };
    setActiveEvSession(ses);
    setEvStep('charging');
  };

  // Filter nearby stations
  const filteredStations = stations.filter(st => {
    if (stationFilters.evOnly && !st.services.evChargers) return false;
    if (stationFilters.washOnly && !st.services.carWash) return false;
    if (stationFilters.openOnly && !st.isOpen) return false;
    if (st.distance > stationFilters.maxDistance) return false;
    return true;
  });

  const loyaltyPointsEarned = transactions
    .filter(tx => tx.description.includes('Points') && tx.type === 'credit')
    .reduce((sum, tx) => sum + tx.amount, 0);

  // Authenticate UI Check
  if (!isAuthenticated) {
    return (
      <div className="bg-white h-full flex flex-col justify-between" id="auth-flow-screen">
        {/* Header */}
        <div className="bg-emerald-800 text-white p-6 text-center shadow-md">
          <div className="flex items-center justify-center gap-2 mb-2">
            <div className="h-10 w-10 rounded-full bg-emerald-600 flex items-center justify-center border-2 border-amber-400">
              <span className="font-bold text-lg text-amber-300">bp</span>
            </div>
            <span className="text-xl font-bold tracking-wide">BP FuelSync Mobile</span>
          </div>
          <p className="text-xs text-emerald-100">Locate, Pay at Pump, EV Charge & Loyalty Sync</p>
        </div>

        {/* Form Container */}
        <div className="flex-1 p-6 flex flex-col justify-center">
          {authStep === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <h3 className="text-lg font-bold text-slate-800 text-center mb-2">Welcome Back</h3>
              <div>
                <label className="text-xs font-semibold text-slate-500 block mb-1">Email Address</label>
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com" 
                  required
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-emerald-500 bg-slate-50"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-500 block mb-1">Password</label>
                <input 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••" 
                  required
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-emerald-500 bg-slate-50"
                />
              </div>
              <button 
                type="submit" 
                className="w-full py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-sm transition-all shadow-md shadow-emerald-750/15"
              >
                Sign In Securely
              </button>

              <div className="relative flex py-2 items-center">
                <div className="flex-grow border-t border-slate-200"></div>
                <span className="flex-shrink mx-4 text-[10px] text-slate-400 uppercase font-bold tracking-wider">Or login with</span>
                <div className="flex-grow border-t border-slate-200"></div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button type="button" onClick={() => setAuthStep('otp')} className="py-2 border border-slate-200 hover:bg-slate-50 rounded-xl text-xs font-semibold text-slate-600 flex items-center justify-center gap-1.5 transition-all">
                  <Smartphone className="h-3.5 w-3.5 text-slate-500" /> Phone OTP
                </button>
                <button type="button" onClick={() => { setIsAuthenticated(true); setCurrentTab('home'); }} className="py-2 border border-slate-200 hover:bg-slate-50 rounded-xl text-xs font-semibold text-slate-600 flex items-center justify-center gap-1.5 transition-all">
                  <Shield className="h-3.5 w-3.5 text-emerald-600" /> Biometric Sync
                </button>
              </div>
            </form>
          )}

          {authStep === 'otp' && (
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-slate-800 text-center">Verify Phone Number</h3>
              <p className="text-xs text-slate-500 text-center">We sent an SMS security code with a One-Time PIN to your mobile phone.</p>
              <div>
                <input 
                  type="text" 
                  placeholder="Enter 6-digit OTP" 
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value)}
                  maxLength={6}
                  className="w-full text-center tracking-widest text-lg font-bold px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 bg-slate-50"
                />
              </div>
              <button 
                type="button" 
                onClick={handleOtpVerify}
                className="w-full py-2.5 rounded-xl bg-emerald-700 text-white font-semibold text-sm shadow-md"
              >
                Verify & Log In
              </button>
              <button onClick={() => setAuthStep('login')} className="w-full text-xs text-slate-400 hover:text-slate-600 font-semibold transition-all">
                Cancel
              </button>
            </div>
          )}
        </div>

        {/* Footer info banner */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center gap-2 justify-center text-[11px] text-slate-400">
          <Shield className="h-4 w-4 text-emerald-600 shrink-0" />
          <span>PCI-DSS Cryptography Security and SSL Pinning Active</span>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white h-full flex flex-col justify-between overflow-hidden text-slate-900 font-sans" id="customer-main-view">
      {/* Top Status and User Header bar - Editorial Aesthetic */}
      <div className="bg-white border-b border-slate-100 px-5 py-3.5 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-full bg-[#008B45] flex items-center justify-center border-2 border-[#FED100] shadow-xs">
            <span className="font-serif font-black text-sm text-[#FED100] italic">bp</span>
          </div>
          <div>
            <span className="text-[9px] text-[#008B45] block uppercase font-bold tracking-widest leading-none mb-0.5">Welcome Back</span>
            <span className="text-sm font-black text-slate-900 tracking-tight font-sans uppercase">Tom Adams</span>
          </div>
        </div>

        {/* Tier status indicator badge */}
        <div className="flex items-center gap-2">
          <span className="text-[9px] bg-[#FED100] text-[#00522B] font-black px-2.5 py-1 rounded-full uppercase tracking-wider shadow-xs">
            Gold Member
          </span>
          <button onClick={() => setIsAuthenticated(false)} className="text-slate-400 hover:text-slate-900 transition-all p-1">
            <User className="h-4.5 w-4.5" />
          </button>
        </div>
      </div>

      {/* Main Tab Views Scrollable Panel */}
      <div className="flex-1 overflow-y-auto min-h-0 bg-slate-50/50">
        
        {/* Tab 1: HOME VIEW */}
        {currentTab === 'home' && (
          <div className="p-5 space-y-5 animate-fade-in">
            {/* Loyalty Card widget with Flip transition */}
            <div 
              onClick={() => setCardFlipped(!cardFlipped)}
              className="relative h-44 w-full cursor-pointer perspective"
            >
              <div className={`w-full h-full duration-500 transform-style preserve-3d transition-all ${cardFlipped ? 'rotate-y-180' : ''}`}>
                
                {/* Front Side - Editorial Dark Green & Yellow Accent */}
                <div className="absolute inset-0 w-full h-full bg-[#008B45] text-white rounded-3xl p-5 flex flex-col justify-between backface-hidden shadow-md border border-[#008B45]/20 overflow-hidden">
                  <div className="absolute -top-6 -left-6 w-24 h-24 bg-[#FED100] rounded-full mix-blend-multiply opacity-20 pointer-events-none"></div>
                  
                  <div className="flex justify-between items-start relative z-10">
                    <div>
                      <span className="text-[10px] text-emerald-100 uppercase font-bold tracking-widest block mb-0.5">bp loyalty core</span>
                      <span className="text-xl font-serif font-black tracking-tight italic">GOLD PASS</span>
                    </div>
                    <div className="h-8 w-8 rounded-full bg-[#00522B] flex items-center justify-center border border-[#FED100]/60">
                      <span className="font-serif font-bold text-xs text-[#FED100] italic">bp</span>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-end relative z-10">
                    <div>
                      <span className="text-[9px] text-emerald-100 block uppercase font-bold tracking-wider leading-none mb-1">Your Balance</span>
                      <span className="text-3xl font-black text-[#FED100] tracking-tight">{1450 + loyaltyPointsEarned}<span className="text-xs uppercase ml-1 font-bold tracking-wider text-white">pts</span></span>
                    </div>
                    <div className="text-right">
                      <span className="text-[9px] text-emerald-200 block uppercase font-bold tracking-widest">Tap to Scan</span>
                      <span className="text-[11px] font-bold text-[#FED100]">Barcode Code →</span>
                    </div>
                  </div>
                </div>

                {/* Back Side */}
                <div className="absolute inset-0 w-full h-full bg-white rounded-3xl p-5 flex flex-col justify-between rotate-y-180 backface-hidden shadow-md border border-slate-200">
                  <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                    <span className="text-[10px] font-bold text-[#008B45] uppercase tracking-wider">Terminal Checkout Scanner</span>
                    <div className="h-6 w-6 rounded-full bg-[#008B45] flex items-center justify-center">
                      <span className="font-serif font-bold text-[10px] text-[#FED100] italic">bp</span>
                    </div>
                  </div>
                  {/* barcode barcode block */}
                  <div className="flex flex-col items-center justify-center flex-grow py-2">
                    <div className="bg-slate-950 h-10 w-48 flex items-center justify-center text-[10px] font-mono tracking-[4px] text-white select-none rounded">
                      ||||| | ||| |||| | |||
                    </div>
                    <span className="text-[9px] text-slate-400 font-mono mt-1.5 uppercase">BP-GOLD-1450-ADAMS</span>
                  </div>
                  <span className="text-[9px] text-slate-400 text-center block">Tap again to flip card</span>
                </div>

              </div>
            </div>

            {/* Quick Tools actions Grid */}
            <div className="grid grid-cols-4 gap-2.5">
              <button 
                onClick={() => { setSelectedProduct(STORE_PRODUCTS[0]); setCoffeeStep('customize'); setCurrentTab('store'); }}
                className="bg-white p-3 rounded-[20px] border border-slate-200/60 shadow-xs flex flex-col items-center text-center hover:border-[#008B45] transition-all group"
              >
                <div className="p-2 bg-amber-50 text-amber-700 rounded-xl mb-1.5 group-hover:bg-[#FED100] group-hover:text-[#00522B] transition-colors">
                  <Coffee className="h-4 w-4" />
                </div>
                <span className="text-[10px] font-bold text-slate-700 tracking-tight leading-tight uppercase group-hover:text-slate-900">Order Coffee</span>
              </button>

              <button 
                onClick={() => { setSelectedWashPackage('Premium Wash'); setWashStep('packages'); setCurrentTab('store'); }}
                className="bg-white p-3 rounded-[20px] border border-slate-200/60 shadow-xs flex flex-col items-center text-center hover:border-[#008B45] transition-all group"
              >
                <div className="p-2 bg-blue-50 text-blue-700 rounded-xl mb-1.5 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                  <Sparkles className="h-4 w-4" />
                </div>
                <span className="text-[10px] font-bold text-slate-700 tracking-tight leading-tight uppercase group-hover:text-slate-900">Car Wash</span>
              </button>

              <button 
                onClick={() => { setEvStep('select'); setCurrentTab('stations'); }}
                className="bg-white p-3 rounded-[20px] border border-slate-200/60 shadow-xs flex flex-col items-center text-center hover:border-[#008B45] transition-all group"
              >
                <div className="p-2 bg-emerald-50 text-emerald-700 rounded-xl mb-1.5 group-hover:bg-[#008B45] group-hover:text-white transition-colors">
                  <Zap className="h-4 w-4" />
                </div>
                <span className="text-[10px] font-bold text-slate-700 tracking-tight leading-tight uppercase group-hover:text-slate-900">EV Pulse</span>
              </button>

              <button 
                onClick={() => { setFuelingStep(1); setCurrentTab('pay'); }}
                className="bg-white p-3 rounded-[20px] border border-emerald-100 shadow-xs flex flex-col items-center text-center hover:border-[#008B45] transition-all bg-emerald-50/10 group"
              >
                <div className="p-2 bg-[#008B45] text-white rounded-xl mb-1.5 group-hover:bg-[#00522B] transition-colors">
                  <CreditCard className="h-4 w-4" />
                </div>
                <span className="text-[10px] font-extrabold text-[#008B45] tracking-tight leading-tight uppercase">Quick Pay</span>
              </button>
            </div>

            {/* Price feed list for active station */}
            <div className="bg-white p-4.5 rounded-[24px] border border-slate-100 shadow-sm">
              <div className="flex justify-between items-center mb-3">
                <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Live Fuel Prices</h4>
                <div className="flex items-center gap-1 text-[10px] text-[#008B45] font-bold uppercase tracking-wider">
                  <MapPin className="h-3 w-3 text-[#008B45]" />
                  <span>BP Hammersmith</span>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-2.5">
                <div className="p-3 bg-slate-50/50 rounded-xl border border-slate-100/80 flex justify-between items-center">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Petrol 95</span>
                  <span className="text-base font-black text-slate-900 font-sans">£{stations[0].fuels['Regular Petrol'].price.toFixed(3)}</span>
                </div>
                <div className="p-3 bg-[#008B45]/5 rounded-xl border border-[#008B45]/10 flex justify-between items-center">
                  <span className="text-[10px] font-bold text-[#008B45] uppercase tracking-wider">Ultimate 98</span>
                  <span className="text-base font-black text-[#008B45] font-sans">£{stations[0].fuels['Premium Petrol'].price.toFixed(3)}</span>
                </div>
                <div className="p-3 bg-slate-50/50 rounded-xl border border-slate-100/80 flex justify-between items-center">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Diesel</span>
                  <span className="text-base font-black text-slate-900 font-sans">£{stations[0].fuels['Diesel'].price.toFixed(3)}</span>
                </div>
                <div className="p-3 bg-[#008B45]/5 rounded-xl border border-[#008B45]/10 flex justify-between items-center">
                  <span className="text-[10px] font-bold text-[#008B45] uppercase tracking-wider">Ultimate Dsl</span>
                  <span className="text-base font-black text-[#008B45] font-sans">£{stations[0].fuels['Premium Diesel'].price.toFixed(3)}</span>
                </div>
              </div>
            </div>

            {/* Claims Active Promotions Campaign */}
            <div className="space-y-2">
              <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Exclusive Offers</h4>
              
              <div className="space-y-2.5">
                {promotions.filter(p => !p.claimed).map((promo) => (
                  <div key={promo.id} className="bg-[#FED100] rounded-3xl p-4.5 shadow-xs relative overflow-hidden flex justify-between items-center text-[#00522B] border border-amber-300">
                    <div className="relative z-10 max-w-[70%]">
                      <span className="text-[8px] font-extrabold bg-[#00522B] text-white px-2 py-0.5 rounded-full uppercase tracking-widest inline-block mb-1.5">LIMITED TIME</span>
                      <h4 className="text-sm font-black tracking-tight font-sans uppercase">{promo.title}</h4>
                      <p className="text-[11px] font-medium opacity-85 leading-tight mt-1">{promo.description}</p>
                    </div>
                    <button 
                      onClick={() => onClaimPromo(promo.id)}
                      className="bg-[#008B45] hover:bg-[#00522B] text-white rounded-xl px-4 py-2 text-xs font-black uppercase tracking-tight shadow-md transition-all shrink-0 relative z-10"
                    >
                      Claim
                    </button>
                    {/* decorative circles */}
                    <div className="absolute -right-10 -bottom-10 h-28 w-28 rounded-full bg-[#00522B]/5"></div>
                  </div>
                ))}
              </div>
            </div>

            {/* Emergency Assistance Call helper */}
            <div className="bg-rose-50/50 border border-rose-100 rounded-[20px] p-4 flex justify-between items-center gap-3">
              <div className="min-w-0">
                <span className="text-xs font-bold text-rose-800 uppercase tracking-wide block mb-0.5">Emergency Assistance</span>
                <p className="text-[10px] text-rose-600 leading-tight">Instant fuel towing, jump starts, or flat tire help at pump.</p>
              </div>
              <a href="tel:08000000" className="bg-rose-600 hover:bg-rose-700 text-white rounded-xl p-2 text-center flex items-center justify-center shrink-0 shadow-xs transition-all">
                <PhoneCall className="h-4 w-4" />
              </a>
            </div>

          </div>
        )}

        {/* Tab 2: STATION LOCATOR MAP */}
        {currentTab === 'stations' && (
          <div className="h-full flex flex-col animate-fade-in">
            {/* Filters bar */}
            <div className="p-3 bg-white border-b border-slate-100 shrink-0 space-y-2">
              <div className="flex gap-2 justify-between">
                <button 
                  onClick={() => setStationFilters(prev => ({ ...prev, evOnly: !prev.evOnly }))}
                  className={`px-2.5 py-1 rounded-xl text-[10px] font-bold border transition-all ${stationFilters.evOnly ? 'bg-emerald-50 border-emerald-300 text-emerald-800' : 'bg-slate-50 border-slate-200 text-slate-500'}`}
                >
                  ⚡ EV Charger
                </button>
                <button 
                  onClick={() => setStationFilters(prev => ({ ...prev, washOnly: !prev.washOnly }))}
                  className={`px-2.5 py-1 rounded-xl text-[10px] font-bold border transition-all ${stationFilters.washOnly ? 'bg-blue-50 border-blue-300 text-blue-800' : 'bg-slate-50 border-slate-200 text-slate-500'}`}
                >
                  🧼 Car Wash
                </button>
                <button 
                  onClick={() => setStationFilters(prev => ({ ...prev, openOnly: !prev.openOnly }))}
                  className={`px-2.5 py-1 rounded-xl text-[10px] font-bold border transition-all ${stationFilters.openOnly ? 'bg-emerald-50 border-emerald-300 text-emerald-800' : 'bg-slate-50 border-slate-200 text-slate-500'}`}
                >
                  🟢 Open Now
                </button>
              </div>
            </div>

            {/* Custom interactive Mock Map view */}
            <div className="relative h-44 bg-slate-100 shrink-0 border-b border-slate-200 flex items-center justify-center overflow-hidden">
              {/* Map decoration pattern */}
              <div className="absolute inset-0 opacity-15">
                <Compass className="absolute top-4 left-6 h-12 w-12 text-slate-900" />
                <div className="absolute top-10 right-10 border border-slate-900 h-24 w-24 rounded-full"></div>
                <div className="absolute bottom-2 left-24 border-t border-slate-900 w-36"></div>
              </div>
              
              {/* Station Markers on Map */}
              {filteredStations.map((st) => (
                <button
                  key={st.id}
                  onClick={() => setSelectedStation(st)}
                  className={`absolute p-1 rounded-full transition-all hover:scale-125 ${
                    selectedStation?.id === st.id 
                      ? 'bg-emerald-600 text-white ring-4 ring-emerald-500/25 z-20' 
                      : 'bg-white text-slate-600 border border-slate-300 shadow-sm z-10'
                  }`}
                  style={{
                    top: st.id === 'st-01' ? '25%' : st.id === 'st-02' ? '65%' : st.id === 'st-03' ? '40%' : '80%',
                    left: st.id === 'st-01' ? '30%' : st.id === 'st-02' ? '15%' : st.id === 'st-03' ? '70%' : '55%',
                  }}
                >
                  <MapPin className="h-4.5 w-4.5 shrink-0" />
                </button>
              ))}

              <div className="absolute bottom-2 right-2 bg-emerald-950/80 text-white text-[9px] font-bold px-2 py-0.5 rounded backdrop-blur-xs">
                Interactive Map Simulator
              </div>
            </div>

            {/* Stations scrollable list */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {filteredStations.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-slate-400 text-xs">No BP stations match current filters.</p>
                </div>
              ) : (
                filteredStations.map((st) => (
                  <div 
                    key={st.id}
                    onClick={() => setSelectedStation(st)}
                    className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
                      selectedStation?.id === st.id 
                        ? 'bg-white border-emerald-500 shadow-md ring-1 ring-emerald-500/10' 
                        : 'bg-white border-slate-100 shadow-sm'
                    }`}
                  >
                    <div className="flex justify-between items-start gap-2">
                      <div>
                        <h4 className="text-xs font-bold text-slate-800">{st.name}</h4>
                        <p className="text-[10px] text-slate-500 line-clamp-1 mt-0.5">{st.address}</p>
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono shrink-0">{st.distance} mi</span>
                    </div>

                    {/* Services row icons */}
                    <div className="flex flex-wrap gap-1 mt-2.5">
                      {st.services.evChargers && <span className="text-[9px] font-bold bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded">⚡ EV Fast</span>}
                      {st.services.carWash && <span className="text-[9px] font-bold bg-sky-50 text-sky-700 px-1.5 py-0.5 rounded">🧼 Car Wash</span>}
                      {st.services.store && <span className="text-[9px] font-bold bg-amber-50 text-amber-700 px-1.5 py-0.5 rounded">🛒 24h Store</span>}
                      {st.services.coffeeShop && <span className="text-[9px] font-bold bg-amber-50 text-amber-700 px-1.5 py-0.5 rounded">☕ Coffee</span>}
                    </div>

                    {/* Selected Expanded tools */}
                    {selectedStation?.id === st.id && (
                      <div className="mt-4 pt-3.5 border-t border-slate-150 flex gap-2 items-center justify-between">
                        <div className="flex gap-2">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                            st.queueStatus === 'Empty' 
                              ? 'bg-emerald-50 text-emerald-800' 
                              : st.queueStatus === 'Moderate'
                              ? 'bg-amber-50 text-amber-800'
                              : 'bg-rose-50 text-rose-800'
                          }`}>
                            {st.queueStatus} queue
                          </span>
                          <span className="text-[10px] text-slate-400">{st.openHours}</span>
                        </div>
                        
                        <div className="flex gap-1.5">
                          {st.services.evChargers && (
                            <button 
                              onClick={(e) => { e.stopPropagation(); startEvChargingSession('ev-pulse-1'); }}
                              className="px-2.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-750 text-white font-bold text-[10px] shadow-sm flex items-center gap-1 transition-all"
                            >
                              ⚡ Charge
                            </button>
                          )}
                          <button 
                            onClick={(e) => { e.stopPropagation(); setFuelStation(st); setFuelingStep(1); setCurrentTab('pay'); }}
                            className="px-2.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] shadow-sm flex items-center gap-1 transition-all"
                          >
                            Fill Up →
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>

            {/* EV charging active overlay view */}
            {activeEvSession && (
              <div className="bg-blue-950 text-white p-4 shrink-0 flex items-center justify-between border-t border-blue-900">
                <div className="flex items-center gap-3">
                  <div className="h-9 w-9 rounded-full bg-blue-900 flex items-center justify-center animate-pulse">
                    <Zap className="h-5 w-5 text-blue-400" />
                  </div>
                  <div>
                    <span className="text-[10px] text-blue-300 block uppercase font-bold tracking-wider">EV Charging Active</span>
                    <span className="text-xs font-bold font-mono">{activeEvSession.stateOfCharge}% Charged ({activeEvSession.duration}m)</span>
                  </div>
                </div>
                <button 
                  onClick={() => { setActiveEvSession(null); setEvStep('select'); }}
                  className="px-3 py-1 bg-rose-600 rounded-xl text-[10px] font-bold"
                >
                  Stop Session
                </button>
              </div>
            )}
          </div>
        )}

        {/* Tab 3: PAY AT PUMP SIMULATION */}
        {currentTab === 'pay' && (
          <div className="p-4 space-y-4 animate-fade-in" id="pay-at-pump-wizard">
            <div className="bg-emerald-800 text-white p-4 rounded-2xl flex items-center justify-between shadow-sm">
              <div>
                <span className="text-[10px] text-emerald-200 uppercase font-bold tracking-wider">Active Station</span>
                <h4 className="text-sm font-bold leading-tight">{fuelStation.name}</h4>
              </div>
              <button 
                onClick={() => setCurrentTab('stations')}
                className="text-[10px] font-bold bg-emerald-700/65 text-emerald-100 hover:text-white px-2 py-1 rounded-lg"
              >
                Change
              </button>
            </div>

            {/* Step 1: Select Pump Number */}
            {fuelingStep === 1 && (
              <div className="space-y-3">
                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Step 1: Select Pump Number</h3>
                <div className="grid grid-cols-4 gap-3">
                  {[1, 2, 3, 4, 5, 6, 7, 8].map((pumpNum) => (
                    <button
                      key={pumpNum}
                      onClick={() => { setSelectedPump(pumpNum); setFuelingStep(2); }}
                      className={`h-16 rounded-2xl border flex flex-col items-center justify-center transition-all ${
                        selectedPump === pumpNum 
                          ? 'bg-emerald-600 border-emerald-500 text-white shadow-md font-bold' 
                          : 'bg-white border-slate-100 hover:bg-slate-50 text-slate-700 shadow-sm'
                      }`}
                    >
                      <span className="text-[10px] opacity-60">Pump</span>
                      <span className="text-lg font-mono font-bold">{pumpNum}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Step 2: Choose Fuel Type */}
            {fuelingStep === 2 && (
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Step 2: Choose Fuel</h3>
                  <button onClick={() => setFuelingStep(1)} className="text-[10px] text-slate-400 font-semibold hover:text-slate-600">Back</button>
                </div>
                <div className="space-y-2">
                  {(Object.keys(fuelStation.fuels) as FuelType[]).filter(k => k !== 'EV Charging').map((fuelKey) => {
                    const priceVal = fuelStation.fuels[fuelKey]?.price || 1.459;
                    const available = fuelStation.fuels[fuelKey]?.available ?? true;
                    return (
                      <button
                        key={fuelKey}
                        disabled={!available}
                        onClick={() => { setSelectedFuel(fuelKey); setFuelingStep(3); }}
                        className={`w-full p-3 rounded-2xl border text-left flex justify-between items-center transition-all ${
                          !available 
                            ? 'bg-slate-50 border-slate-100 opacity-50 cursor-not-allowed'
                            : selectedFuel === fuelKey
                            ? 'bg-white border-emerald-500 shadow-md ring-1 ring-emerald-500/10 text-emerald-850'
                            : 'bg-white border-slate-100 hover:bg-slate-50 text-slate-700 shadow-sm'
                        }`}
                      >
                        <div>
                          <span className="text-xs font-bold block">{fuelKey}</span>
                          {!available && <span className="text-[9px] text-rose-500 font-medium">Out of stock</span>}
                        </div>
                        <span className="text-xs font-bold font-mono">£{priceVal.toFixed(3)}/L</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Step 3: Enter Amount limit */}
            {fuelingStep === 3 && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Step 3: Fueling Limit</h3>
                  <button onClick={() => setFuelingStep(2)} className="text-[10px] text-slate-400 font-semibold hover:text-slate-600">Back</button>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm text-center">
                  <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider mb-1">Total Authorization</span>
                  <span className="text-3xl font-bold font-mono text-emerald-700">£{fuelAmountLimit}</span>
                  
                  {/* Presets */}
                  <div className="grid grid-cols-4 gap-2 mt-4">
                    {[10, 20, 50, 80].map((pr) => (
                      <button
                        key={pr}
                        type="button"
                        onClick={() => setFuelAmountLimit(pr)}
                        className={`py-1.5 rounded-xl border font-mono text-xs font-bold transition-all ${
                          fuelAmountLimit === pr 
                            ? 'bg-emerald-600 text-white border-emerald-500' 
                            : 'bg-slate-50 border-slate-100 text-slate-600 hover:bg-slate-100'
                        }`}
                      >
                        £{pr}
                      </button>
                    ))}
                  </div>

                  <div className="mt-4">
                    <input 
                      type="range" 
                      min={5} 
                      max={120} 
                      step={5}
                      value={fuelAmountLimit}
                      onChange={(e) => setFuelAmountLimit(Number(e.target.value))}
                      className="w-full accent-emerald-600"
                    />
                    <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-1">
                      <span>£5 Min</span>
                      <span>£120 Max</span>
                    </div>
                  </div>
                </div>

                <button 
                  onClick={() => setFuelingStep(4)}
                  className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm transition-all shadow-md flex items-center justify-center gap-1"
                >
                  Confirm Limit <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            )}

            {/* Step 4: Authorize Payment method */}
            {fuelingStep === 4 && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Step 4: Authorize</h3>
                  <button onClick={() => setFuelingStep(3)} className="text-[10px] text-slate-400 font-semibold hover:text-slate-600">Back</button>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm space-y-3">
                  <div className="flex justify-between items-center text-xs font-semibold text-slate-600">
                    <span>Selected Pump</span>
                    <span className="font-mono text-slate-800 font-bold">Pump {selectedPump}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs font-semibold text-slate-600">
                    <span>Fuel Selection</span>
                    <span className="font-bold text-slate-800">{selectedFuel}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs font-semibold text-slate-600">
                    <span>Pre-Auth Limit</span>
                    <span className="font-mono text-emerald-700 font-bold">£{fuelAmountLimit.toFixed(2)}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider px-1">Payment Method</span>
                  
                  <button 
                    onClick={() => setFuelingPayment('BP Wallet')}
                    className={`w-full p-3.5 rounded-2xl border flex items-center justify-between text-left transition-all ${
                      fuelingPayment === 'BP Wallet'
                        ? 'bg-white border-emerald-500 shadow-md text-emerald-850'
                        : 'bg-white border-slate-100 hover:bg-slate-50 text-slate-600'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <CreditCard className="h-4.5 w-4.5 text-emerald-600" />
                      <div>
                        <span className="text-xs font-bold block">BP Wallet Balance</span>
                        <span className="text-[10px] text-slate-400 font-mono">Available: £{walletBalance.toFixed(2)}</span>
                      </div>
                    </div>
                  </button>

                  <button 
                    onClick={() => setFuelingPayment('Google Pay')}
                    className={`w-full p-3.5 rounded-2xl border flex items-center justify-between text-left transition-all ${
                      fuelingPayment === 'Google Pay'
                        ? 'bg-white border-emerald-500 shadow-md text-emerald-850'
                        : 'bg-white border-slate-100 hover:bg-slate-50 text-slate-600'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Smartphone className="h-4.5 w-4.5 text-slate-600" />
                      <div>
                        <span className="text-xs font-bold block">Google Pay</span>
                        <span className="text-[10px] text-slate-400">Linked Card: Visa •••• 4820</span>
                      </div>
                    </div>
                  </button>
                </div>

                <button 
                  onClick={startFuelingProcess}
                  disabled={isAuthorizing}
                  className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm transition-all shadow-md flex items-center justify-center gap-1.5"
                >
                  {isAuthorizing ? (
                    <>
                      <RefreshCw className="h-4 w-4 animate-spin" />
                      <span>Authorizing Card...</span>
                    </>
                  ) : (
                    <>
                      <Shield className="h-4 w-4" />
                      <span>Authorize Fueling (£{fuelAmountLimit})</span>
                    </>
                  )}
                </button>
              </div>
            )}

            {/* Step 5: Active Fueling Animation */}
            {fuelingStep === 5 && (
              <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm text-center space-y-4">
                <span className="text-xs font-bold text-emerald-700 uppercase tracking-widest block animate-pulse">Fueling Active...</span>
                
                {/* Progress Wheel */}
                <div className="relative h-32 w-32 mx-auto flex items-center justify-center">
                  <div className="absolute inset-0 rounded-full border-4 border-slate-100"></div>
                  <div 
                    className="absolute inset-0 rounded-full border-4 border-emerald-600 border-t-transparent animate-spin"
                    style={{ animationDuration: '2s' }}
                  ></div>
                  <div className="text-center">
                    <span className="text-2xl font-mono font-bold text-slate-800 block">{fuelingLiters.toFixed(2)} L</span>
                    <span className="text-[10px] text-slate-400 font-mono">Dispensed</span>
                  </div>
                </div>

                <div>
                  <span className="text-xs text-slate-400 block font-medium">Cost Accumulating</span>
                  <span className="text-xl font-bold font-mono text-slate-800">£ {fuelingCost.toFixed(2)}</span>
                </div>

                <p className="text-[11px] text-slate-400 leading-tight">Please do not exit the car or remove the nozzle until fueling is finished. Our terminal is communicating with Pump {selectedPump} securely.</p>
              </div>
            )}

            {/* Step 6: Beautiful digital receipt display */}
            {fuelingStep === 6 && generatedReceipt && (
              <div className="space-y-4 animate-fade-in">
                <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
                  {/* green banner header */}
                  <div className="bg-emerald-800 text-white p-4 text-center">
                    <div className="h-8 w-8 rounded-full bg-emerald-600 flex items-center justify-center border-2 border-amber-400 mx-auto mb-1">
                      <span className="font-bold text-xs text-amber-300">bp</span>
                    </div>
                    <span className="text-xs font-bold block uppercase tracking-wider">fuel transaction success</span>
                    <span className="text-[10px] text-emerald-200 font-mono">{generatedReceipt.vatInvoice}</span>
                  </div>

                  <div className="p-4 space-y-2.5">
                    <div className="flex justify-between text-xs text-slate-500 font-semibold">
                      <span>Station</span>
                      <span className="text-slate-800 text-right">{generatedReceipt.stationName}</span>
                    </div>
                    <div className="flex justify-between text-xs text-slate-500 font-semibold">
                      <span>Date / Time</span>
                      <span className="text-slate-800 font-mono">{generatedReceipt.date} {generatedReceipt.time}</span>
                    </div>
                    <div className="flex justify-between text-xs text-slate-500 font-semibold">
                      <span>Pump / Nozzle</span>
                      <span className="text-slate-800 font-mono">Pump {generatedReceipt.pumpNumber}</span>
                    </div>
                    <div className="flex justify-between text-xs text-slate-500 font-semibold">
                      <span>Fuel Selection</span>
                      <span className="text-slate-800 font-bold">{generatedReceipt.fuelType}</span>
                    </div>
                    <div className="flex justify-between text-xs text-slate-500 font-semibold">
                      <span>Volume Filled</span>
                      <span className="text-slate-800 font-mono font-bold">{generatedReceipt.liters.toFixed(2)} Liters</span>
                    </div>
                    <div className="flex justify-between text-xs text-slate-500 font-semibold border-b border-slate-100 pb-2.5">
                      <span>Unit Cost</span>
                      <span className="text-slate-800 font-mono">£{generatedReceipt.pricePerLiter.toFixed(3)}/L</span>
                    </div>
                    
                    <div className="flex justify-between items-center pt-1">
                      <span className="text-sm font-bold text-slate-800">Total Charged</span>
                      <span className="text-lg font-bold font-mono text-emerald-700">£{generatedReceipt.amount.toFixed(2)}</span>
                    </div>

                    <div className="p-2.5 bg-emerald-50 rounded-xl border border-emerald-100/50 flex items-center justify-between mt-3 text-emerald-800">
                      <span className="text-[10px] font-bold uppercase">points earned</span>
                      <span className="text-xs font-bold font-mono">+{Math.round(generatedReceipt.amount * 2)} pts</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button 
                    onClick={() => { alert(`Invoice PDF exported to: ${generatedReceipt.vatInvoice}.pdf`); }}
                    className="py-2.5 rounded-xl border border-slate-200 hover:bg-slate-100 text-xs font-bold text-slate-700 transition-all bg-white"
                  >
                    Export Invoice
                  </button>
                  <button 
                    onClick={() => { setFuelingStep(1); setSelectedPump(null); setCurrentTab('home'); }}
                    className="py-2.5 rounded-xl bg-emerald-700 text-white font-bold text-xs shadow-sm"
                  >
                    Back to Home
                  </button>
                </div>
              </div>
            )}

          </div>
        )}

        {/* Tab 4: CONVENIENCE STORE / COFFEE CATALOG */}
        {currentTab === 'store' && (
          <div className="p-4 space-y-4 animate-fade-in" id="store-coffee-builder">
            {/* Store & Coffee builder Wizard */}
            {coffeeStep === 'catalog' && (
              <div className="space-y-4">
                <div className="bg-gradient-to-br from-amber-700 to-amber-900 text-white rounded-2xl p-5 shadow-sm relative overflow-hidden flex justify-between items-center">
                  <div className="relative z-10">
                    <span className="text-[9px] font-extrabold bg-amber-400 text-amber-950 px-1.5 py-0.5 rounded uppercase tracking-wider block mb-1 w-max">wild bean cafe</span>
                    <h3 className="text-sm font-bold">Priority Coffee Pickup</h3>
                    <p className="text-[10px] opacity-90 leading-tight">Order premium hot bar coffees and skip lines instantly.</p>
                  </div>
                  <Coffee className="h-12 w-12 text-amber-300 opacity-30 relative z-10" />
                </div>

                {/* Products category lists */}
                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Wild Bean Cafe Menu</h4>
                  <div className="grid grid-cols-1 gap-2">
                    {STORE_PRODUCTS.filter(p => p.category === 'Coffee').map((prod) => (
                      <div key={prod.id} className="bg-white p-3 rounded-2xl border border-slate-100 shadow-sm flex justify-between items-center gap-3">
                        <div className="min-w-0">
                          <h4 className="text-xs font-bold text-slate-800">{prod.name}</h4>
                          <p className="text-[10px] text-slate-400 line-clamp-1">{prod.description}</p>
                          <span className="text-xs font-bold font-mono text-emerald-700 mt-1 block">£{prod.price.toFixed(2)}</span>
                        </div>
                        <button
                          onClick={() => handleCoffeeSelect(prod)}
                          className="px-3 py-1.5 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-bold text-[10px] shrink-0 transition-all shadow-sm shadow-amber-750/10"
                        >
                          Order
                        </button>
                      </div>
                    ))}
                  </div>

                  <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mt-4">Car Wash Packages</h4>
                  <div className="space-y-2">
                    <div className="bg-white p-3.5 rounded-2xl border border-slate-100 shadow-sm flex justify-between items-center">
                      <div>
                        <h4 className="text-xs font-bold text-slate-800">Basic Shower Wash</h4>
                        <p className="text-[10px] text-slate-400">Standard body spray wash and active hand drying.</p>
                        <span className="text-xs font-bold font-mono text-emerald-700 mt-0.5 block">£8.00</span>
                      </div>
                      <button 
                        onClick={() => handleWashSelect('Basic Wash', 8)}
                        className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-[10px]"
                      >
                        Book
                      </button>
                    </div>

                    <div className="bg-white p-3.5 rounded-2xl border border-slate-100 shadow-sm flex justify-between items-center ring-1 ring-blue-500/10">
                      <div>
                        <h4 className="text-xs font-bold text-slate-800 flex items-center gap-1">
                          Deluxe Clean Coat 
                          <span className="text-[8px] font-extrabold bg-blue-50 text-blue-600 px-1 rounded-full uppercase">Most popular</span>
                        </h4>
                        <p className="text-[10px] text-slate-400">Foam coat wash, wax spray, blowing dry and wheel scrub.</p>
                        <span className="text-xs font-bold font-mono text-emerald-700 mt-0.5 block">£12.00</span>
                      </div>
                      <button 
                        onClick={() => handleWashSelect('Deluxe Wash', 12)}
                        className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-[10px]"
                      >
                        Book
                      </button>
                    </div>
                  </div>

                  <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mt-4">Automotive & Accessories</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {STORE_PRODUCTS.filter(p => p.category === 'Engine Oil' || p.category === 'Car Accessories').slice(0, 2).map((prod) => (
                      <div key={prod.id} className="bg-white p-3 rounded-2xl border border-slate-100 shadow-sm flex flex-col justify-between text-left">
                        <div>
                          <h5 className="text-[11px] font-bold text-slate-700 truncate">{prod.name}</h5>
                          <p className="text-[9px] text-slate-400 line-clamp-2 leading-tight mt-0.5">{prod.description}</p>
                        </div>
                        <div className="flex justify-between items-center mt-3 pt-1.5 border-t border-slate-50">
                          <span className="text-xs font-bold font-mono text-slate-600">£{prod.price}</span>
                          <button 
                            onClick={() => { onUpdateWallet(walletBalance - prod.price); alert(`Item ${prod.name} purchased! Collect from checkout counters.`); }}
                            className="bg-emerald-600 text-white p-1 rounded-lg hover:bg-emerald-700"
                          >
                            <Plus className="h-3 w-3" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Coffee builder wizard step 2: Customizer details */}
            {coffeeStep === 'customize' && selectedProduct && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Customize Beverage</h3>
                  <button onClick={() => setCoffeeStep('catalog')} className="text-[10px] text-slate-400 font-semibold hover:text-slate-600">Cancel</button>
                </div>

                <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm space-y-3">
                  <h4 className="text-xs font-bold text-slate-700">{selectedProduct.name}</h4>
                  
                  {/* Size customization options */}
                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider mb-1.5">Size</span>
                    <div className="grid grid-cols-2 gap-2">
                      {(['Regular', 'Large'] as const).map(sz => (
                        <button
                          key={sz}
                          onClick={() => setCoffeeSize(sz)}
                          className={`py-1 rounded-xl text-xs font-bold border transition-all ${
                            coffeeSize === sz 
                              ? 'bg-amber-50 text-amber-800 border-amber-300' 
                              : 'bg-slate-50 border-slate-100 text-slate-500'
                          }`}
                        >
                          {sz} {sz === 'Large' ? '(+£0.40)' : ''}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Milk options */}
                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider mb-1.5">Milk Option</span>
                    <div className="grid grid-cols-2 gap-1.5">
                      {(['Full Cream', 'Skimmed', 'Oat', 'Almond'] as const).map(ml => (
                        <button
                          key={ml}
                          onClick={() => setCoffeeMilk(ml)}
                          className={`py-1 rounded-xl text-[10px] font-semibold border transition-all ${
                            coffeeMilk === ml 
                              ? 'bg-amber-50 text-amber-800 border-amber-300' 
                              : 'bg-slate-50 border-slate-100 text-slate-500'
                          }`}
                        >
                          {ml}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Sugar levels */}
                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider mb-1.5">Sweetness / Sugar</span>
                    <div className="grid grid-cols-4 gap-1">
                      {(['None', 'One', 'Two', 'Sweetener'] as const).map(sg => (
                        <button
                          key={sg}
                          onClick={() => setCoffeeSugar(sg)}
                          className={`py-1 rounded-lg text-[10px] font-semibold border transition-all ${
                            coffeeSugar === sg 
                              ? 'bg-amber-50 text-amber-800 border-amber-300' 
                              : 'bg-slate-50 border-slate-100 text-slate-500'
                          }`}
                        >
                          {sg}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Flavor syrups */}
                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider mb-1.5">Syrup Syrups</span>
                    <div className="grid grid-cols-2 gap-1.5">
                      {(['None', 'Vanilla', 'Caramel', 'Hazelnut'] as const).map(sy => (
                        <button
                          key={sy}
                          onClick={() => setCoffeeFlavor(sy)}
                          className={`py-1 rounded-xl text-[10px] font-semibold border transition-all ${
                            coffeeFlavor === sy 
                              ? 'bg-amber-50 text-amber-800 border-amber-300' 
                              : 'bg-slate-50 border-slate-100 text-slate-500'
                          }`}
                        >
                          {sy}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <button
                  onClick={handleCoffeeOrderSubmit}
                  className="w-full py-2.5 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-bold text-sm shadow-md transition-all"
                >
                  Confirm Beverage (£{(selectedProduct.price + (coffeeSize === 'Large' ? 0.40 : 0)).toFixed(2)})
                </button>
              </div>
            )}

            {/* Coffee builder step 3: QR Code pickup pass */}
            {coffeeStep === 'qr' && latestCoffeeOrder && (
              <div className="space-y-4 animate-fade-in text-center">
                <div className="bg-white p-5 rounded-2xl border border-slate-150 shadow-sm space-y-4">
                  <div className="flex items-center justify-center gap-1.5 text-amber-700">
                    <Coffee className="h-5 w-5" />
                    <span className="text-xs font-extrabold uppercase tracking-wider">barista order received</span>
                  </div>
                  
                  <p className="text-[11px] text-slate-500 leading-tight">Our Wild Bean barista is handcrafting your coffee. Scan this barcode at the pick-up priority counter when you arrive.</p>

                  <div className="flex flex-col items-center justify-center p-3 border border-slate-100 rounded-xl bg-slate-50">
                    <span className="text-xs font-bold text-slate-700 mb-1">{latestCoffeeOrder.name}</span>
                    <span className="text-[10px] text-slate-400 mb-4">Milks: {latestCoffeeOrder.milk} • Syrup: {latestCoffeeOrder.flavor}</span>
                    
                    <div className="bg-slate-900 h-10 w-44 flex items-center justify-center text-[10px] font-mono tracking-[4px] text-white">
                      |||| | ||| || ||||
                    </div>
                    <span className="text-[9px] text-slate-400 font-mono mt-1">{latestCoffeeOrder.qrCode}</span>
                  </div>
                </div>

                <button 
                  onClick={() => setCoffeeStep('catalog')}
                  className="w-full py-2 bg-slate-150 text-slate-700 rounded-xl font-bold text-xs"
                >
                  Close & Order More
                </button>
              </div>
            )}

            {/* Car wash scheduling page */}
            {washStep === 'schedule' && selectedWashPackage && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Book Car Wash</h3>
                  <button onClick={() => setWashStep('packages')} className="text-[10px] text-slate-400 font-semibold hover:text-slate-600">Cancel</button>
                </div>

                <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm space-y-3">
                  <span className="text-xs font-bold text-blue-700">{selectedWashPackage} Package</span>
                  <div>
                    <label className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider mb-1">Pick a wash slot</label>
                    <select 
                      value={washScheduleTime}
                      onChange={(e) => setWashScheduleTime(e.target.value)}
                      className="w-full p-2 border border-slate-150 rounded-xl text-xs bg-white text-slate-700"
                    >
                      <option value="Today, 14:00">Today, 14:00</option>
                      <option value="Today, 16:30">Today, 16:30</option>
                      <option value="Tomorrow, 09:00">Tomorrow, 09:00</option>
                      <option value="Tomorrow, 11:30">Tomorrow, 11:30</option>
                    </select>
                  </div>
                </div>

                <button
                  onClick={handleWashOrderSubmit}
                  className="w-full py-2.5 rounded-xl bg-blue-600 text-white font-bold text-sm shadow-md"
                >
                  Authorize Payment (£{washPrice.toFixed(2)})
                </button>
              </div>
            )}

            {/* Car Wash Success */}
            {washStep === 'success' && latestWashBooking && (
              <div className="space-y-4 text-center animate-fade-in">
                <div className="bg-white p-5 rounded-2xl border border-slate-150 shadow-sm space-y-4">
                  <div className="flex items-center justify-center gap-1 text-blue-700 font-bold">
                    <Check className="h-5 w-5" />
                    <span>Car Wash Voucher Booked</span>
                  </div>
                  <p className="text-[11px] text-slate-500">Scan this code at the car wash entry scanner terminal to activate wash nozzles.</p>
                  
                  <div className="p-3 border border-slate-100 bg-slate-50 rounded-xl flex flex-col items-center">
                    <span className="text-xs font-bold text-slate-800">{latestWashBooking.packageName} Pass</span>
                    <span className="text-[10px] text-slate-400 mb-3">Scheduled: {latestWashBooking.scheduleTime}</span>
                    <div className="bg-slate-900 h-10 w-44 flex items-center justify-center text-[10px] font-mono tracking-[4px] text-white">
                      || |||| ||| ||| |||
                    </div>
                  </div>
                </div>
                <button 
                  onClick={() => { setWashStep('packages'); setCoffeeStep('catalog'); }}
                  className="w-full py-2 bg-slate-150 text-slate-700 rounded-xl font-bold text-xs"
                >
                  Close Passes
                </button>
              </div>
            )}

          </div>
        )}

        {/* Tab 5: WALLET */}
        {currentTab === 'wallet' && (
          <div className="p-4 space-y-4 animate-fade-in" id="wallet-balance-dashboard">
            {/* Wallet core card display */}
            <div className="bg-gradient-to-br from-slate-800 to-slate-950 text-white rounded-2xl p-5 border border-slate-700/50 shadow-md relative overflow-hidden">
              <div className="flex justify-between items-start">
                <div>
                  <span className="text-xs text-slate-400 uppercase font-bold tracking-wider block">bp mobile wallet</span>
                  <span className="text-3xl font-bold font-mono text-emerald-400 mt-1 block">£ {walletBalance.toFixed(2)}</span>
                </div>
                <div className="h-8 w-8 rounded-full bg-emerald-600 flex items-center justify-center border-2 border-amber-400 shrink-0">
                  <span className="font-bold text-xs text-amber-300">bp</span>
                </div>
              </div>

              {/* Saved Credit Cards indicators */}
              <div className="flex justify-between items-end mt-6">
                <div>
                  <span className="text-[9px] text-slate-400 block uppercase font-bold">Auto Top-Up</span>
                  <span className="text-[11px] font-semibold text-slate-200">Disabled</span>
                </div>
                
                <button 
                  onClick={() => setShowAddFundsModal(true)}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 shadow-sm transition-all relative z-10"
                >
                  <Plus className="h-4 w-4" /> Add Money
                </button>
              </div>
            </div>

            {/* Wallet add money modal */}
            {showAddFundsModal && (
              <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-md space-y-3">
                <span className="text-xs font-bold text-slate-700 block">Top Up Balance</span>
                <div className="grid grid-cols-3 gap-2">
                  {['10', '20', '50'].map(am => (
                    <button
                      key={am}
                      onClick={() => setAddFundsAmount(am)}
                      className={`py-1.5 rounded-xl border text-xs font-bold font-mono transition-all ${
                        addFundsAmount === am
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                          : 'bg-slate-50 border-slate-100 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      £{am}
                    </button>
                  ))}
                </div>
                <div className="flex gap-2">
                  <input 
                    type="number"
                    value={addFundsAmount}
                    onChange={(e) => setAddFundsAmount(e.target.value)}
                    className="w-full p-2 border border-slate-150 rounded-xl text-xs font-mono text-center focus:outline-none focus:border-emerald-500"
                    placeholder="Other Amount (£)"
                  />
                  <button 
                    onClick={handleAddFundsSubmit}
                    className="bg-emerald-600 text-white px-4 py-2 rounded-xl text-xs font-bold hover:bg-emerald-700"
                  >
                    Confirm
                  </button>
                </div>
                <button 
                  onClick={() => setShowAddFundsModal(false)}
                  className="text-[10px] text-slate-400 font-semibold hover:text-slate-600 block mx-auto pt-1"
                >
                  Cancel
                </button>
              </div>
            )}

            {/* Historic Transactions List */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider px-1">Transaction History</h4>
              <div className="space-y-1.5">
                {transactions.map((tx) => (
                  <div key={tx.id} className="bg-white p-3 rounded-2xl border border-slate-100 shadow-sm flex justify-between items-center text-xs">
                    <div>
                      <span className="font-bold text-slate-800 block">{tx.description}</span>
                      <span className="text-[10px] text-slate-400 font-mono">{tx.date}</span>
                    </div>
                    <span className={`font-bold font-mono ${
                      tx.type === 'credit' ? 'text-emerald-600' : 'text-slate-700'
                    }`}>
                      {tx.type === 'credit' ? '+' : '-'} £{Math.abs(tx.amount).toFixed(2)}
                      {tx.description.includes('Points') && ' pts'}
                    </span>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* Tab 6: PROFILE, VEHICLE GARAGE & LIVE SUPPORT CHAT */}
        {currentTab === 'more' && (
          <div className="p-4 space-y-4 animate-fade-in" id="more-garage-chat">
            
            {/* Vehicle Garage */}
            <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm space-y-3">
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                <Car className="h-4.5 w-4.5 text-emerald-600" />
                BP Vehicle Garage
              </h3>
              
              <div className="space-y-2">
                {vehicles.map((v) => (
                  <div key={v.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="font-bold text-slate-800">{v.make} {v.model}</span>
                        <span className="text-[10px] text-slate-400 block font-mono mt-0.5">{v.fuelType} • {v.year}</span>
                      </div>
                      <span className="bg-amber-300 text-emerald-950 px-2 py-0.5 rounded font-mono font-bold text-[10px] shadow-xs">
                        {v.registration}
                      </span>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2 mt-3 pt-2.5 border-t border-slate-150/70 text-[10px]">
                      <div>
                        <span className="text-slate-400 block font-medium">MOT Due Date</span>
                        <span className="text-slate-700 font-semibold">{v.reminders.mot}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block font-medium">Oil Sync Reminder</span>
                        <span className="text-slate-700 font-semibold">{v.reminders.oilChange}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Add Vehicle expand form */}
              <form onSubmit={handleAddVehicleSubmit} className="pt-3 border-t border-slate-100 space-y-2">
                <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider">Register New Car</span>
                <div className="grid grid-cols-2 gap-2">
                  <input 
                    type="text" 
                    placeholder="Registration (e.g. AB12 XYZ)" 
                    value={newReg}
                    onChange={(e) => setNewReg(e.target.value)}
                    required
                    className="p-2 border border-slate-150 rounded-xl text-xs bg-white uppercase"
                  />
                  <input 
                    type="text" 
                    placeholder="Make (e.g. VW)" 
                    value={newMake}
                    onChange={(e) => setNewMake(e.target.value)}
                    required
                    className="p-2 border border-slate-150 rounded-xl text-xs bg-white"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <input 
                    type="text" 
                    placeholder="Model (e.g. Golf)" 
                    value={newModel}
                    onChange={(e) => setNewModel(e.target.value)}
                    required
                    className="p-2 border border-slate-150 rounded-xl text-xs bg-white"
                  />
                  <select 
                    value={newFuel}
                    onChange={(e) => setNewFuel(e.target.value as FuelType)}
                    className="p-2 border border-slate-150 rounded-xl text-xs bg-white text-slate-700"
                  >
                    <option value="Regular Petrol">Regular Petrol</option>
                    <option value="Premium Petrol">Premium Petrol</option>
                    <option value="Diesel">Diesel</option>
                    <option value="EV Charging">EV Charging</option>
                  </select>
                </div>
                <button 
                  type="submit"
                  className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-sm transition-all"
                >
                  Save Car to Garage
                </button>
              </form>
            </div>

            {/* Support Live Chat interface */}
            <div className="bg-white rounded-2xl border border-slate-100 shadow-sm flex flex-col h-64 overflow-hidden">
              <div className="bg-emerald-800 text-white p-3 text-xs font-bold flex items-center justify-between">
                <span>BP Customer Support Bot</span>
                <span className="h-2 w-2 rounded-full bg-emerald-400 animate-ping"></span>
              </div>
              
              {/* Messages viewport */}
              <div className="flex-1 overflow-y-auto p-3 space-y-2 bg-slate-50">
                {chatMessages.map((msg) => (
                  <div 
                    key={msg.id}
                    className={`max-w-[80%] p-2 rounded-xl text-[11px] leading-tight ${
                      msg.sender === 'user'
                        ? 'bg-emerald-600 text-white ml-auto'
                        : 'bg-white border border-slate-150 text-slate-700'
                    }`}
                  >
                    <p>{msg.text}</p>
                    <span className="text-[8px] opacity-60 block mt-0.5 text-right">{msg.timestamp}</span>
                  </div>
                ))}
              </div>

              {/* Messages inputs */}
              <div className="p-2 border-t border-slate-150 flex gap-1.5 bg-white items-center">
                <input 
                  type="text" 
                  placeholder="Ask about Wallet, Loyalty or Pay..." 
                  value={newMessageText}
                  onChange={(e) => setNewMessageText(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                  className="flex-1 p-2 border border-slate-150 rounded-xl text-xs bg-white"
                />
                <button 
                  type="button"
                  onClick={handleSendMessage}
                  className="bg-emerald-600 hover:bg-emerald-750 text-white p-2 rounded-xl"
                >
                  <Send className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>

          </div>
        )}

      </div>

      {/* Persistent Bottom Mobile Navigation Tab bar - Editorial Aesthetic */}
      <div className="bg-white border-t border-slate-100 grid grid-cols-5 py-2 shrink-0 shadow-sm" id="mobile-tab-navigation">
        <button 
          onClick={() => setCurrentTab('home')}
          className={`flex flex-col items-center justify-center transition-all ${currentTab === 'home' ? 'text-[#008B45]' : 'text-slate-400 hover:text-slate-700'}`}
        >
          <Compass className="h-4.5 w-4.5 mb-0.5" />
          <span className="text-[8px] font-extrabold uppercase tracking-widest">Home</span>
          <div className={`w-1 h-1 rounded-full mt-0.5 transition-all ${currentTab === 'home' ? 'bg-[#008B45]' : 'bg-transparent'}`}></div>
        </button>

        <button 
          onClick={() => setCurrentTab('stations')}
          className={`flex flex-col items-center justify-center transition-all ${currentTab === 'stations' ? 'text-[#008B45]' : 'text-slate-400 hover:text-slate-700'}`}
        >
          <MapPin className="h-4.5 w-4.5 mb-0.5" />
          <span className="text-[8px] font-extrabold uppercase tracking-widest">Stations</span>
          <div className={`w-1 h-1 rounded-full mt-0.5 transition-all ${currentTab === 'stations' ? 'bg-[#008B45]' : 'bg-transparent'}`}></div>
        </button>

        <button 
          onClick={() => { setFuelingStep(1); setCurrentTab('pay'); }}
          className={`flex flex-col items-center justify-center transition-all ${currentTab === 'pay' ? 'text-[#008B45]' : 'text-slate-400 hover:text-slate-700'}`}
        >
          <CreditCard className="h-4.5 w-4.5 mb-0.5" />
          <span className="text-[8px] font-extrabold uppercase tracking-widest">Pay Pump</span>
          <div className={`w-1 h-1 rounded-full mt-0.5 transition-all ${currentTab === 'pay' ? 'bg-[#008B45]' : 'bg-transparent'}`}></div>
        </button>

        <button 
          onClick={() => { setCoffeeStep('catalog'); setCurrentTab('store'); }}
          className={`flex flex-col items-center justify-center transition-all ${currentTab === 'store' ? 'text-[#008B45]' : 'text-slate-400 hover:text-slate-700'}`}
        >
          <ShoppingBag className="h-4.5 w-4.5 mb-0.5" />
          <span className="text-[8px] font-extrabold uppercase tracking-widest">Store</span>
          <div className={`w-1 h-1 rounded-full mt-0.5 transition-all ${currentTab === 'store' ? 'bg-[#008B45]' : 'bg-transparent'}`}></div>
        </button>

        <button 
          onClick={() => setCurrentTab('wallet')}
          className={`flex flex-col items-center justify-center transition-all ${currentTab === 'wallet' ? 'text-[#008B45]' : 'text-slate-400 hover:text-slate-700'}`}
        >
          <History className="h-4.5 w-4.5 mb-0.5" />
          <span className="text-[8px] font-extrabold uppercase tracking-widest">Wallet</span>
          <div className={`w-1 h-1 rounded-full mt-0.5 transition-all ${currentTab === 'wallet' ? 'bg-[#008B45]' : 'bg-transparent'}`}></div>
        </button>
      </div>
    </div>
  );
}
