import React from 'react';
import { Wifi, Battery, Radio } from 'lucide-react';

interface MobileEmulatorProps {
  children: React.ReactNode;
  activeRole: 'customer' | 'staff';
  onChangeRole: (role: 'customer' | 'staff') => void;
}

export default function MobileEmulator({ children, activeRole, onChangeRole }: MobileEmulatorProps) {
  // Current time clock
  const timeStr = '12:45';

  return (
    <div className="flex flex-col items-center py-4" id="mobile-emulator-wrapper">
      {/* Role Switcher Toolbar - Editorial Styled */}
      <div className="bg-white text-slate-950 p-1.5 rounded-full border border-slate-200/80 flex gap-1 mb-6 shadow-sm text-xs font-bold uppercase tracking-wider">
        <button
          onClick={() => onChangeRole('customer')}
          className={`px-4 py-2 rounded-full transition-all duration-300 ${
            activeRole === 'customer'
              ? 'bg-[#008B45] text-white shadow-sm font-extrabold'
              : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          Customer App View
        </button>
        <button
          onClick={() => onChangeRole('staff')}
          className={`px-4 py-2 rounded-full transition-all duration-300 ${
            activeRole === 'staff'
              ? 'bg-[#008B45] text-white shadow-sm font-extrabold'
              : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          Staff Terminal View
        </button>
      </div>

      {/* Outer Phone Shell Frame */}
      <div className="relative w-[375px] h-[750px] bg-white rounded-[48px] p-3 shadow-2xl border-4 border-slate-900 ring-1 ring-slate-200/50 flex flex-col justify-between overflow-hidden">
        {/* Physical buttons styling decoration */}
        <div className="absolute -left-1 top-24 h-12 w-[3px] bg-slate-400 rounded-r-sm"></div>
        <div className="absolute -left-1 top-40 h-10 w-[3px] bg-slate-400 rounded-r-sm"></div>
        <div className="absolute -right-1 top-28 h-16 w-[3px] bg-slate-400 rounded-l-sm"></div>

        {/* Inner Screen Content */}
        <div className="relative flex-1 bg-white rounded-[36px] overflow-hidden flex flex-col justify-between shadow-inner border border-slate-100">
          
          {/* Simulated Mobile Status Bar - Editorial Style */}
          <div className="bg-white text-slate-400 border-b border-slate-100 px-6 pt-3 pb-2 flex justify-between items-center text-[10px] font-bold tracking-wider font-sans shrink-0 z-50">
            <span className="text-[#008B45]">BP CONNECT • LONDON</span>
            {/* Camera notch cutout decoration */}
            <div className="absolute top-1 left-1/2 -translate-x-1/2 h-4.5 w-24 bg-slate-900 rounded-full z-50 flex items-center justify-center">
              <span className="h-1 w-1 rounded-full bg-slate-800"></span>
            </div>
            <div className="flex items-center gap-1.5">
              <span>5G</span>
              <span>98%</span>
              <span className="text-slate-600 font-mono">{timeStr}</span>
            </div>
          </div>

          {/* Render Active Children App View */}
          <div className="flex-grow min-h-0 bg-slate-50/50">
            {children}
          </div>

        </div>
      </div>

      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-4">London Digital Core Sandbox v2.6</span>
    </div>
  );
}

