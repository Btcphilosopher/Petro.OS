import React, { useState } from 'react';
import { CoffeeOrder, FuelStation, FuelType } from '../types';
import { 
  Check, Smartphone, Coffee, ShoppingBag, ShieldAlert, 
  RotateCw, RefreshCw, Layers, CheckCircle2, Sliders, AlertTriangle
} from 'lucide-react';

interface StaffAppProps {
  coffeeOrders: CoffeeOrder[];
  onUpdateCoffeeOrderStatus: (orderId: string, status: 'Pending' | 'Preparing' | 'Ready' | 'Picked Up') => void;
  stations: FuelStation[];
  onUpdateStations: (updated: FuelStation[]) => void;
  onScanVoucher: (qrCode: string) => void;
}

export default function StaffApp({
  coffeeOrders,
  onUpdateCoffeeOrderStatus,
  stations,
  onUpdateStations,
  onScanVoucher,
}: StaffAppProps) {
  // Navigation: Orders or Pumps
  const [activeTab, setActiveTab] = useState<'orders' | 'pumps'>('orders');
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Simulated scan text input
  const [scanText, setScanText] = useState<string>('');

  const [pumpStatuses, setPumpStatuses] = useState<Record<number, 'Active' | 'Stopped' | 'Maintenance'>>({
    1: 'Active',
    2: 'Active',
    3: 'Maintenance',
    4: 'Active',
    5: 'Active',
    6: 'Stopped',
    7: 'Active',
    8: 'Active',
  });

  const handlePumpStatusToggle = (pumpNum: number, status: 'Active' | 'Stopped' | 'Maintenance') => {
    setPumpStatuses(prev => ({
      ...prev,
      [pumpNum]: status
    }));
    triggerSuccess(`Set Pump ${pumpNum} to status: ${status}`);
  };

  const handleScanSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!scanText.trim()) return;
    onScanVoucher(scanText.trim());
    
    // Check if scan text matches a coffee order QR code
    const matchingCoffee = coffeeOrders.find(o => o.qrCode === scanText);
    if (matchingCoffee) {
      onUpdateCoffeeOrderStatus(matchingCoffee.id, 'Picked Up');
      triggerSuccess(`Scanned Flat White coffee order: Marked as Picked Up!`);
    } else {
      triggerSuccess(`Scanned Voucher: Code "${scanText}" successfully verified.`);
    }
    setScanText('');
  };

  const triggerSuccess = (msg: string) => {
    setSuccessMessage(msg);
    setTimeout(() => setSuccessMessage(null), 3000);
  };

  return (
    <div className="bg-slate-900 h-full flex flex-col justify-between text-slate-100 font-sans overflow-hidden" id="staff-rugged-terminal">
      {/* Top Banner Header */}
      <div className="bg-slate-950 p-4 shrink-0 flex items-center justify-between border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="h-7 w-7 rounded bg-emerald-600 flex items-center justify-center border border-amber-400">
            <span className="font-bold text-xs text-amber-300">bp</span>
          </div>
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-mono tracking-wider block">Rugged Handheld Terminal</span>
            <span className="text-xs font-bold text-white">Staff Member #1024</span>
          </div>
        </div>
        <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse"></span>
      </div>

      {/* Rugged status bar / selector */}
      <div className="bg-slate-950 px-3 py-1.5 shrink-0 flex gap-1 border-b border-slate-850">
        <button
          onClick={() => setActiveTab('orders')}
          className={`flex-1 py-1.5 rounded text-center text-xs font-bold transition-all ${
            activeTab === 'orders' ? 'bg-slate-800 text-emerald-400 border-b-2 border-emerald-500' : 'text-slate-400'
          }`}
        >
          ☕ Cafe Orders ({coffeeOrders.filter(o => o.status !== 'Picked Up').length})
        </button>
        <button
          onClick={() => setActiveTab('pumps')}
          className={`flex-1 py-1.5 rounded text-center text-xs font-bold transition-all ${
            activeTab === 'pumps' ? 'bg-slate-800 text-emerald-400 border-b-2 border-emerald-500' : 'text-slate-400'
          }`}
        >
          ⛽ Pump Control
        </button>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto min-h-0 p-4 space-y-4">
        {successMessage && (
          <div className="p-3 bg-emerald-950/80 border border-emerald-800 text-emerald-300 text-[11px] rounded-xl flex items-center gap-2 animate-fade-in">
            <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Tab 1: Coffee order pickup processors */}
        {activeTab === 'orders' && (
          <div className="space-y-4">
            
            {/* Simulation scanner input */}
            <form onSubmit={handleScanSubmit} className="p-3 bg-slate-950 rounded-xl border border-slate-850 space-y-2">
              <span className="text-[10px] text-slate-400 font-mono block uppercase">Mock Voucher scanner input</span>
              <div className="flex gap-1.5">
                <input 
                  type="text" 
                  placeholder="Enter QR order code to Scan" 
                  value={scanText}
                  onChange={(e) => setScanText(e.target.value)}
                  className="flex-1 bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-emerald-500"
                />
                <button 
                  type="submit" 
                  className="bg-emerald-600 text-white font-bold px-3 py-1.5 rounded text-xs hover:bg-emerald-700 shrink-0"
                >
                  Scan QR
                </button>
              </div>
            </form>

            <div className="space-y-2.5">
              <h4 className="text-[10px] text-slate-400 uppercase font-mono tracking-wider">Active Wild Bean queues</h4>
              
              {coffeeOrders.length === 0 ? (
                <div className="text-center py-6 text-slate-500 text-xs font-medium">
                  No active barista orders found.
                </div>
              ) : (
                coffeeOrders.map((ord) => (
                  <div key={ord.id} className="p-3 bg-slate-950 border border-slate-850 rounded-xl space-y-2 text-xs">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="font-bold text-white block">{ord.name}</span>
                        <span className="text-[10px] text-slate-400 block mt-0.5">Milk: {ord.milk} • Syrup: {ord.flavor}</span>
                      </div>
                      
                      <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase ${
                        ord.status === 'Pending'
                          ? 'bg-amber-950 text-amber-400 border border-amber-900/40'
                          : ord.status === 'Preparing'
                          ? 'bg-blue-950 text-blue-400 border border-blue-900/40'
                          : 'bg-emerald-950 text-emerald-400 border border-emerald-900/40'
                      }`}>
                        {ord.status}
                      </span>
                    </div>

                    <div className="flex justify-between items-center pt-2.5 border-t border-slate-850">
                      <span className="text-[10px] text-slate-500 font-mono font-medium">{ord.qrCode}</span>
                      <div className="flex gap-1">
                        {ord.status === 'Pending' && (
                          <button
                            onClick={() => onUpdateCoffeeOrderStatus(ord.id, 'Preparing')}
                            className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-2 py-1 rounded text-[10px] transition-all"
                          >
                            Brew Coffee
                          </button>
                        )}
                        {ord.status === 'Preparing' && (
                          <button
                            onClick={() => onUpdateCoffeeOrderStatus(ord.id, 'Ready')}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-2 py-1 rounded text-[10px] transition-all"
                          >
                            Set Ready
                          </button>
                        )}
                        {ord.status === 'Ready' && (
                          <button
                            onClick={() => onUpdateCoffeeOrderStatus(ord.id, 'Picked Up')}
                            className="bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white px-2 py-1 rounded text-[10px] transition-all"
                          >
                            Complete Pick Up
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Tab 2: Fuel pump controller statuses */}
        {activeTab === 'pumps' && (
          <div className="space-y-4">
            <h4 className="text-[10px] text-slate-400 uppercase font-mono tracking-wider">Station Pump Matrix (Pumps 1-8)</h4>
            
            <div className="grid grid-cols-2 gap-3">
              {[1, 2, 3, 4, 5, 6, 7, 8].map((num) => {
                const status = pumpStatuses[num];
                return (
                  <div key={num} className="p-3 bg-slate-950 border border-slate-850 rounded-xl space-y-2 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-white">Pump {num}</span>
                      <span className={`h-2.5 w-2.5 rounded-full ${
                        status === 'Active' ? 'bg-emerald-400' : status === 'Stopped' ? 'bg-rose-500' : 'bg-amber-400'
                      }`}></span>
                    </div>

                    <div className="grid grid-cols-3 gap-1 pt-2 border-t border-slate-850/50">
                      <button 
                        onClick={() => handlePumpStatusToggle(num, 'Active')}
                        className={`py-1 rounded text-[9px] font-bold ${status === 'Active' ? 'bg-emerald-950/80 text-emerald-400' : 'bg-slate-900 text-slate-500 hover:bg-slate-850'}`}
                      >
                        Active
                      </button>
                      <button 
                        onClick={() => handlePumpStatusToggle(num, 'Maintenance')}
                        className={`py-1 rounded text-[9px] font-bold ${status === 'Maintenance' ? 'bg-amber-950/80 text-amber-400' : 'bg-slate-900 text-slate-500 hover:bg-slate-850'}`}
                      >
                        Maint
                      </button>
                      <button 
                        onClick={() => handlePumpStatusToggle(num, 'Stopped')}
                        className={`py-1 rounded text-[9px] font-bold ${status === 'Stopped' ? 'bg-rose-950/80 text-rose-400' : 'bg-slate-900 text-slate-500 hover:bg-slate-850'}`}
                      >
                        STOP
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="p-3.5 bg-amber-950/20 rounded-xl border border-amber-900/20 text-amber-300 text-[10px] leading-relaxed flex gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
              <span>Pump emergency stop controls: Tapping "STOP" instantly pauses fuel dispenser pumps and triggers visual warnings on station checkout counters.</span>
            </div>
          </div>
        )}
      </div>

      {/* persistent bottom device rail */}
      <div className="bg-slate-950 p-3 text-center border-t border-slate-850 shrink-0">
        <span className="text-[10px] text-slate-500 font-mono">Terminal connection: RF Sync Signal 98.4%</span>
      </div>
    </div>
  );
}
