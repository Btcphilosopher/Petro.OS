import React, { useState } from 'react';
import { FileCode, Folder, Copy, Check, Terminal, FileText, Database, Layers, Play, Settings } from 'lucide-react';

interface CodeFile {
  name: string;
  path: string;
  language: string;
  category: 'core' | 'database' | 'network' | 'ui' | 'di' | 'config' | 'docs' | 'tests';
  description: string;
  content: string;
}

export default function CodeExporter() {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [copiedFile, setCopiedFile] = useState<string | null>(null);

  const files: CodeFile[] = [
    {
      name: 'MainActivity.kt',
      path: 'app/src/main/java/com/bp/fuelsync/MainActivity.kt',
      language: 'kotlin',
      category: 'core',
      description: 'The main entry point of the Android application, implementing Compose Navigation and setting up the Material 3 BP Green & Yellow theme.',
      content: `package com.bp.fuelsync

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.bp.fuelsync.ui.theme.BPFuelSyncTheme
import com.bp.fuelsync.ui.screens.LoginScreen
import com.bp.fuelsync.ui.screens.HomeScreen
import com.bp.fuelsync.ui.screens.PayAtPumpScreen
import com.bp.fuelsync.ui.screens.StationLocatorScreen
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BPFuelSyncTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation()
                }
            }
        }
    }
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "login") {
        composable("login") { 
            LoginScreen(
                onLoginSuccess = { navController.navigate("home") { popUpTo("login") { inclusive = true } } }
            ) 
        }
        composable("home") { 
            HomeScreen(
                onNavigateToPayAtPump = { navController.navigate("pay_at_pump") },
                onNavigateToLocator = { navController.navigate("locator") }
            ) 
        }
        composable("pay_at_pump") { 
            PayAtPumpScreen(
                onNavigateBack = { navController.popBackStack() }
            ) 
        }
        composable("locator") { 
            StationLocatorScreen(
                onNavigateBack = { navController.popBackStack() }
            ) 
        }
    }
}`
    },
    {
      name: 'AppDatabase.kt',
      path: 'app/src/main/java/com/bp/fuelsync/data/local/AppDatabase.kt',
      language: 'kotlin',
      category: 'database',
      description: 'Room Database definition with local offline support caching fuel stations and digital payment receipts.',
      content: `package com.bp.fuelsync.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.bp.fuelsync.data.local.dao.StationDao
import com.bp.fuelsync.data.local.dao.ReceiptDao
import com.bp.fuelsync.data.local.entity.StationEntity
import com.bp.fuelsync.data.local.entity.ReceiptEntity

@Database(
    entities = [StationEntity::class, ReceiptEntity::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun stationDao(): StationDao
    abstract fun receiptDao(): ReceiptDao
}`
    },
    {
      name: 'ReceiptDao.kt',
      path: 'app/src/main/java/com/bp/fuelsync/data/local/dao/ReceiptDao.kt',
      language: 'kotlin',
      category: 'database',
      description: 'Room Data Access Object (DAO) for securely inserting, reading, and syncing digital fuel transaction receipts offline.',
      content: `package com.bp.fuelsync.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.bp.fuelsync.data.local.entity.ReceiptEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ReceiptDao {
    @Query("SELECT * FROM receipts ORDER BY timestamp DESC")
    fun getAllReceipts(): Flow<List<ReceiptEntity>>

    @Query("SELECT * FROM receipts WHERE id = :receiptId")
    suspend fun getReceiptById(receiptId: String): ReceiptEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReceipt(receipt: ReceiptEntity)

    @Query("DELETE FROM receipts")
    suspend fun clearAllReceipts()
}`
    },
    {
      name: 'StationApiService.kt',
      path: 'app/src/main/java/com/bp/fuelsync/data/remote/StationApiService.kt',
      language: 'kotlin',
      category: 'network',
      description: 'Retrofit interface for executing secure, fast REST API operations with BP backend services, fully integrated with JWT Token auth headers.',
      content: `package com.bp.fuelsync.data.remote

import com.bp.fuelsync.data.remote.dto.StationDto
import com.bp.fuelsync.data.remote.dto.PriceUpdateDto
import com.bp.fuelsync.data.remote.dto.PaymentIntentDto
import com.bp.fuelsync.data.remote.dto.ReceiptDto
import retrofit2.http.*

interface StationApiService {
    @GET("api/stations")
    suspend fun getNearbyStations(
        @Query("lat") latitude: Double,
        @Query("lng") longitude: Double,
        @Query("radius") radiusKm: Double
    ): List<StationDto>

    @POST("api/payments/pay-at-pump/init")
    suspend fun initializeFuelTransaction(
        @Header("Authorization") token: String,
        @Body request: PaymentIntentDto
    ): ReceiptDto

    @GET("api/users/profile")
    suspend fun getUserProfile(
        @Header("Authorization") token: String
    ): UserProfileDto

    @POST("api/admin/stations/{id}/pricing")
    suspend fun updateLivePrices(
        @Header("Authorization") token: String,
        @Path("id") stationId: String,
        @Body pricing: List<PriceUpdateDto>
    ): ResponseBody
}`
    },
    {
      name: 'RepositoryImpl.kt',
      path: 'app/src/main/java/com/bp/fuelsync/data/repository/RepositoryImpl.kt',
      language: 'kotlin',
      category: 'core',
      description: 'Offline-First repository architecture mapping Retrofit API fetches, local caching to Room DB, and providing structured Flow data streams.',
      content: `package com.bp.fuelsync.data.repository

import com.bp.fuelsync.data.local.dao.StationDao
import com.bp.fuelsync.data.remote.StationApiService
import com.bp.fuelsync.domain.model.FuelStation
import com.bp.fuelsync.domain.repository.FuelStationRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import java.io.IOException
import javax.inject.Inject

class FuelStationRepositoryImpl @Inject constructor(
    private val apiService: StationApiService,
    private val stationDao: StationDao
) : FuelStationRepository {

    override fun getStations(lat: Double, lng: Double): Flow<Resource<List<FuelStation>>> = flow {
        emit(Resource.Loading())
        
        // Return cached stations from Room Database immediately (Offline-First)
        val cachedStations = stationDao.getStations().map { entities -> 
            entities.map { it.toDomainModel() } 
        }
        emit(Resource.Success(cachedStations.first()))

        try {
            // Fetch live prices and station queues from Retrofit endpoints
            val remoteStations = apiService.getNearbyStations(lat, lng, 10.0)
            
            // Sync / cache remote data into local database
            stationDao.clearAllStations()
            stationDao.insertStations(remoteStations.map { it.toEntity() })
            
            val updatedCache = stationDao.getStations().map { entities -> 
                entities.map { it.toDomainModel() } 
            }
            emit(Resource.Success(updatedCache.first()))
        } catch (e: IOException) {
            emit(Resource.Error("Network failure. Serving cached data.", cachedStations.first()))
        } catch (e: Exception) {
            emit(Resource.Error("An error occurred: \${e.localizedMessage}", cachedStations.first()))
        }
    }
}`
    },
    {
      name: 'PayAtPumpViewModel.kt',
      path: 'app/src/main/java/com/bp/fuelsync/ui/viewmodel/PayAtPumpViewModel.kt',
      language: 'kotlin',
      category: 'core',
      description: 'MVVM StateFlow manager controlling pump selection, digital authorization states, fuel volume simulation, and receipt generation.',
      content: `package com.bp.fuelsync.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bp.fuelsync.domain.repository.FuelStationRepository
import com.bp.fuelsync.domain.model.FuelType
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PayAtPumpViewModel @Inject constructor(
    private val repository: FuelStationRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(PayAtPumpUiState())
    val uiState: StateFlow<PayAtPumpUiState> = _uiState.asStateFlow()

    fun selectPump(pumpNumber: Int) {
        _uiState.update { it.copy(selectedPump = pumpNumber, currentStep = FuelStep.CHOOSE_FUEL) }
    }

    fun selectFuel(fuelType: FuelType) {
        _uiState.update { it.copy(selectedFuel = fuelType, currentStep = FuelStep.CHOOSE_AMOUNT) }
    }

    fun selectAmount(amountLimit: Double) {
        _uiState.update { it.copy(selectedAmount = amountLimit, currentStep = FuelStep.AUTHORIZE_PAYMENT) }
    }

    fun authorizePayment(paymentMethod: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isAuthorizing = true) }
            delay(1500) // Simulating Stripe / Google Pay authorization delay
            _uiState.update { 
                it.copy(
                    isAuthorizing = false, 
                    isAuthorized = true, 
                    currentStep = FuelStep.FUELING_ACTIVE,
                    litersDispensed = 0.0,
                    costAccrued = 0.0
                ) 
            }
            startFuelingSimulation()
        }
    }

    private fun startFuelingSimulation() {
        viewModelScope.launch {
            val pricePerLiter = 1.559 // BP Ultimate Premium
            val targetCost = _uiState.value.selectedAmount
            val totalLiters = targetCost / pricePerLiter
            
            val steps = 40
            for (i in 1..steps) {
                delay(150) // Incrementing flow state
                val progress = i.toDouble() / steps
                _uiState.update {
                    it.copy(
                        litersDispensed = progress * totalLiters,
                        costAccrued = progress * targetCost
                    )
                }
            }
            _uiState.update { it.copy(currentStep = FuelStep.RECEIPT_READY) }
        }
    }
}

enum class FuelStep { SELECT_PUMP, CHOOSE_FUEL, CHOOSE_AMOUNT, AUTHORIZE_PAYMENT, FUELING_ACTIVE, RECEIPT_READY }

data class PayAtPumpUiState(
    val currentStep: FuelStep = FuelStep.SELECT_PUMP,
    val selectedPump: Int? = null,
    val selectedFuel: FuelType? = null,
    val selectedAmount: Double = 0.0,
    val isAuthorizing: Boolean = false,
    val isAuthorized: Boolean = false,
    val litersDispensed: Double = 0.0,
    val costAccrued: Double = 0.0
)`
    },
    {
      name: 'PayAtPumpScreen.kt',
      path: 'app/src/main/java/com/bp/fuelsync/ui/screens/PayAtPumpScreen.kt',
      language: 'kotlin',
      category: 'ui',
      description: 'Elegant Jetpack Compose component designed in accordance with Material Design 3 and BP brand style, featuring smooth transitions and micro-interactions.',
      content: `package com.bp.fuelsync.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bp.fuelsync.ui.viewmodel.FuelStep
import com.bp.fuelsync.ui.viewmodel.PayAtPumpViewModel

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun PayAtPumpScreen(
    viewModel: PayAtPumpViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("BP Pay at Pump", color = Color.White) },
                colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0xFF006A4E)) // BP Green
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            AnimatedContent(targetState = uiState.currentStep) { step ->
                when (step) {
                    FuelStep.SELECT_PUMP -> {
                        PumpSelectionView(onPumpSelected = { viewModel.selectPump(it) })
                    }
                    FuelStep.CHOOSE_FUEL -> {
                        FuelSelectionView(onFuelSelected = { viewModel.selectFuel(it) })
                    }
                    FuelStep.CHOOSE_AMOUNT -> {
                        AmountSelectionView(onAmountSelected = { viewModel.selectAmount(it) })
                    }
                    FuelStep.AUTHORIZE_PAYMENT -> {
                        AuthPaymentView(
                            isAuthorizing = uiState.isAuthorizing,
                            onAuthorize = { viewModel.authorizePayment("BP Wallet") }
                        )
                    }
                    FuelStep.FUELING_ACTIVE -> {
                        FuelingProgressView(
                            liters = uiState.litersDispensed,
                            cost = uiState.costAccrued
                        )
                    }
                    FuelStep.RECEIPT_READY -> {
                        FuelReceiptView(
                            liters = uiState.litersDispensed,
                            cost = uiState.costAccrued,
                            fuelType = uiState.selectedFuel,
                            onFinish = onNavigateBack
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FuelingProgressView(liters: Double, cost: Double) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFAFAFA)),
        modifier = Modifier.fillMaxWidth().padding(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Fueling in Progress...", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF006A4E))
            Spacer(modifier = Modifier.height(24.dp))
            CircularProgressIndicator(
                color = Color(0xFFFFD100), // BP Yellow Accent
                strokeWidth = 6.dp,
                modifier = Modifier.size(100.dp)
            )
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = String.format("%.2f L", liters),
                fontSize = 42.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )
            Text(
                text = String.format("£ %.2f", cost),
                fontSize = 28.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.Gray
            )
        }
    }
}`
    },
    {
      name: 'HiltModules.kt',
      path: 'app/src/main/java/com/bp/fuelsync/di/HiltModules.kt',
      language: 'kotlin',
      category: 'di',
      description: 'Dagger Hilt Dependency Injection module configuring singletons for Room Database local store and Retrofit HTTP Network clients.',
      content: `package com.bp.fuelsync.di

import android.content.Context
import androidx.room.Room
import com.bp.fuelsync.data.local.AppDatabase
import com.bp.fuelsync.data.remote.StationApiService
import com.bp.fuelsync.data.repository.FuelStationRepositoryImpl
import com.bp.fuelsync.domain.repository.FuelStationRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideRoomDatabase(@ApplicationContext context: Context): AppDatabase {
        return Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            "bp_fuelsync_db"
        ).fallbackToDestructiveMigration().build()
    }

    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient {
        return OkHttpClient.Builder()
            .addInterceptor(HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            })
            .build()
    }

    @Provides
    @Singleton
    fun provideStationApiService(okHttpClient: OkHttpClient): StationApiService {
        return Retrofit.Builder()
            .baseUrl("https://api.bp-fuelsync.com/")
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(StationApiService::class.java)
    }

    @Provides
    @Singleton
    fun provideFuelStationRepository(
        apiService: StationApiService,
        db: AppDatabase
    ): FuelStationRepository {
        return FuelStationRepositoryImpl(apiService, db.stationDao())
    }
}`
    },
    {
      name: 'build.gradle.kts',
      path: 'app/build.gradle.kts',
      language: 'kotlin',
      category: 'config',
      description: 'Kotlin Gradle build definition compiling dependencies for Compose UI, Room DB, Retrofit, Coroutines, and Dagger Hilt DI.',
      content: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.kapt)
    alias(libs.plugins.hilt.android)
}

android {
    namespace = "com.bp.fuelsync"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.bp.fuelsync"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.8"
    }
}

dependencies {
    // Jetpack Compose M3
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.navigation)

    // Room Database
    implementation(libs.room.runtime)
    implementation(libs.room.ktx)
    kapt(libs.room.compiler)

    // Retrofit & Networking
    implementation(libs.retrofit)
    implementation(libs.retrofit.gson)
    implementation(libs.okhttp.logging)

    // Dagger Hilt
    implementation(libs.hilt.android)
    kapt(libs.hilt.compiler)

    // Coroutines
    implementation(libs.kotlinx.coroutines.android)

    // Testing
    testImplementation(libs.junit)
    testImplementation(libs.mockk)
    androidTestImplementation(libs.androidx.compose.ui.test)
}`
    },
    {
      name: 'AndroidManifest.xml',
      path: 'app/src/main/AndroidManifest.xml',
      language: 'xml',
      category: 'config',
      description: 'The Android App Manifest defining system permissions for location tracking, mobile network access, biometric verification, and NFC terminal payments.',
      content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.bp.fuelsync">

    <!-- Permissions for Location and Maps -->
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <!-- NFC and Biometrics -->
    <uses-permission android:name="android.permission.NFC" />
    <uses-permission android:name="android.permission.USE_BIOMETRIC" />
    
    <!-- Camera for QR Code Scanning -->
    <uses-permission android:name="android.permission.CAMERA" />

    <application
        android:name=".BPFuelApplication"
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.BPFuelSync"
        android:hardwareAccelerated="true">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/Theme.BPFuelSync">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <meta-data
            android:name="com.google.android.geo.API_KEY"
            android:value="YOUR_GOOGLE_MAPS_API_KEY" />

    </application>
</manifest>`
    },
    {
      name: 'REST_APIs.md',
      path: 'docs/REST_APIs.md',
      language: 'markdown',
      category: 'docs',
      description: 'Comprehensive REST API backend endpoint routing, authentication flow schemas, payload payloads, and server-side responses.',
      content: `# BP Fuel Station API Documentation

All requests require JWT Token credentials set in the \`Authorization: Bearer <token>\` header.

## 1. Authentication Endpoints

### Login / Biometric Exchange
* **Endpoint**: \`POST /api/auth/login\`
* **Headers**: \`Content-Type: application/json\`
* **Payload**:
\`\`\`json
{
  "email": "user@example.com",
  "password": "SecurePassword123",
  "deviceFingerprint": "9a7f31be4d"
}
\`\`\`
* **Response (200 OK)**:
\`\`\`json
{
  "token": "eyJhbGciOiJIUzI1NiIsIn...",
  "refreshToken": "df81920b-fc34-...",
  "user": {
    "name": "Tom Adams",
    "email": "tom@ahyx.org",
    "tier": "Gold",
    "points": 1450
  }
}
\`\`\`

---

## 2. Pay at Pump Endpoints

### Initialize Pre-authorization
* **Endpoint**: \`POST /api/payments/pay-at-pump/init\`
* **Payload**:
\`\`\`json
{
  "stationId": "st-01",
  "pumpNumber": 4,
  "fuelType": "Premium Petrol",
  "preAuthLimitAmount": 50.00,
  "paymentMethodToken": "tok_12345678"
}
\`\`\`
* **Response (200 OK)**:
\`\`\`json
{
  "transactionId": "tx-fuel-75910",
  "status": "AUTHORIZED",
  "authorizedLimit": 50.00,
  "authCode": "BP-7592"
}
\`\`\`

### Finalize Transaction (Receipt Generation)
* **Endpoint**: \`POST /api/payments/pay-at-pump/finalize\`
* **Payload**:
\`\`\`json
{
  "transactionId": "tx-fuel-75910",
  "actualLiters": 31.11,
  "actualCost": 48.50,
  "timestamp": "2026-07-18T08:30:00Z"
}
\`\`\`
* **Response (200 OK)**:
\`\`\`json
{
  "receiptId": "rec-1001",
  "vatInvoice": "GB123456789-1001",
  "pointsEarned": 97,
  "newPointsBalance": 1547,
  "tier": "Gold"
}
\`\`\`
`
    },
    {
      name: 'KotlinTests.kt',
      path: 'app/src/test/java/com/bp/fuelsync/PayAtPumpViewModelTest.kt',
      language: 'kotlin',
      category: 'tests',
      description: 'Robust unit and UI test files written with Mockk and Compose test libraries verifying fueling steps and live point computations.',
      content: `package com.bp.fuelsync

import com.bp.fuelsync.ui.viewmodel.FuelStep
import com.bp.fuelsync.ui.viewmodel.PayAtPumpViewModel
import com.bp.fuelsync.domain.repository.FuelStationRepository
import com.bp.fuelsync.domain.model.FuelType
import io.mockk.mockk
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.*
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class PayAtPumpViewModelTest {

    private val repository: FuelStationRepository = mockk()
    private lateinit var viewModel: PayAtPumpViewModel
    
    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
        viewModel = PayAtPumpViewModel(repository)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun selectPump_updatesStepAndPumpNumber() {
        // When selectPump is triggered
        viewModel.selectPump(4)

        // Then state is updated appropriately
        val state = viewModel.uiState.value
        assertEquals(4, state.selectedPump)
        assertEquals(FuelStep.CHOOSE_FUEL, state.currentStep)
    }

    @Test
    fun selectFuel_updatesStateFuelAndStep() {
        viewModel.selectPump(4)
        
        // When fuel is selected
        viewModel.selectFuel(FuelType.PREMIUM_PETROL)

        val state = viewModel.uiState.value
        assertEquals(FuelType.PREMIUM_PETROL, state.selectedFuel)
        assertEquals(FuelStep.CHOOSE_AMOUNT, state.currentStep)
    }
}`
    },
    {
      name: 'Setup_Instructions.md',
      path: 'Setup_Instructions.md',
      language: 'markdown',
      category: 'docs',
      description: 'Detailed instructions on compiling the project, running unit/UI tests, deploying Google Play Store release bundles, and CI/CD pipelines.',
      content: `# Android Kotlin Project Setup Instructions

Follow these instructions to run, compile, and configure the BP FuelSync Android Application.

## 1. Prerequisites
- **Android Studio Jellyfish (2023.3+)** or newer
- **JDK 17** configured in your System and Android Studio settings
- **Gradle 8.2+** (configured in the wrapper)

## 2. Importing the Project
1. Open Android Studio.
2. Select **File -> New -> Import Project...**
3. Select the root folder containing the project files.
4. Let Gradle sync and download build dependencies.

## 3. Configuration & API Keys
Add your Google Maps API Key in \`app/src/main/AndroidManifest.xml\`:
\`\`\`xml
<meta-data
    android:name="com.google.android.geo.API_KEY"
    android:value="AIzaSyYourGoogleMapsApiKey..." />
\`\`\`

## 4. Compile & Run
To compile the app via CLI or run unit tests, execute the following Gradle wrapper commands:

* **Compile Debug Build**:
  \`\`\`bash
  ./gradlew assembleDebug
  \`\`\`
* **Run Unit Tests**:
  \`\`\`bash
  ./gradlew test
  \`\`\`
* **Run Android Lint**:
  \`\`\`bash
  ./gradlew lint
  \`\`\`

## 5. Generating Google Play Store Release APK
To compile a secure, obfuscated Release APK or Android App Bundle (.aab):
1. Go to **Build -> Generate Signed Bundle / APK...** in Android Studio.
2. Choose **Android App Bundle** (preferred) or **APK**.
3. Create or select your production release keystore file, password, and alias.
4. Ensure **V2 Signing** is selected.
5. Click **Finish**. The compiled file will be located at:
   \`app/release/app-release.aab\`

## 6. GitHub Actions CI/CD Pipeline
Save the following configuration inside \`.github/workflows/android.yml\` for automated building and testing:
\`\`\`yaml
name: Android Build Pipeline

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Repository
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: 'zulu'
          java-version: '17'

      - name: Cache Gradle Packages
        uses: actions/cache@v4
        with:
          path: ~/.gradle/caches
          key: \${{ runner.os }}-gradle-\${{ hashFiles('**/*.gradle*', '**/gradle-wrapper.properties') }}

      - name: Grant Execute Permission to Gradlew
        run: chmod +x gradlew

      - name: Run Code Linter
        run: ./gradlew lint

      - name: Run Unit Tests
        run: ./gradlew test

      - name: Build Debug APK
        run: ./gradlew assembleDebug
\`\`\`
`
    }
  ];

  const filteredFiles = selectedCategory === 'all' 
    ? files 
    : files.filter(f => f.category === selectedCategory);

  const [activeFile, setActiveFile] = useState<CodeFile>(files[0]);

  const handleCopy = (content: string, name: string) => {
    navigator.clipboard.writeText(content);
    setCopiedFile(name);
    setTimeout(() => setCopiedFile(null), 2000);
  };

  const categories = [
    { id: 'all', label: 'All Files', icon: Folder },
    { id: 'core', label: 'Kotlin Core', icon: FileCode },
    { id: 'ui', label: 'Compose UI', icon: Layers },
    { id: 'database', label: 'Room Cache', icon: Database },
    { id: 'network', label: 'Retrofit REST', icon: Terminal },
    { id: 'di', label: 'Dagger Hilt', icon: Settings },
    { id: 'tests', label: 'Unit Tests', icon: Play },
    { id: 'config', label: 'Gradle & Manifest', icon: Settings },
    { id: 'docs', label: 'Documentation', icon: FileText },
  ];

  return (
    <div className="bg-slate-900 rounded-2xl border border-slate-800 shadow-2xl p-6 flex flex-col h-full overflow-hidden text-slate-100" id="code-exporter-section">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
          <FileCode className="h-6 w-6 text-emerald-400" />
          Android Production Kotlin Source Code Hub
        </h2>
        <p className="text-sm text-slate-400 mt-1">
          Explore, inspect, and copy standard-compliant Android production source code structured in clean MVVM & Jetpack Compose.
        </p>
      </div>

      {/* Category Tabs */}
      <div className="flex flex-wrap gap-2 mb-6 pb-4 border-b border-slate-800">
        {categories.map((cat) => {
          const Icon = cat.icon;
          return (
            <button
              key={cat.id}
              onClick={() => {
                setSelectedCategory(cat.id);
                // Auto reset active file if current is filtered out
                if (cat.id !== 'all') {
                  const firstOfCat = files.find(f => f.category === cat.id);
                  if (firstOfCat) setActiveFile(firstOfCat);
                }
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                selectedCategory === cat.id
                  ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20'
                  : 'bg-slate-800 text-slate-400 hover:bg-slate-750 hover:text-slate-200'
              }`}
            >
              <Icon className="h-3.5 w-3.5" />
              {cat.label}
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1 min-h-0 overflow-hidden">
        {/* File Navigator */}
        <div className="lg:col-span-1 bg-slate-950 rounded-xl border border-slate-850 p-4 flex flex-col h-[500px] lg:h-full overflow-y-auto">
          <h3 className="text-xs font-semibold text-slate-400 tracking-wider uppercase mb-3">Project Directory Tree</h3>
          <div className="space-y-2">
            {filteredFiles.map((file) => (
              <button
                key={file.path}
                onClick={() => setActiveFile(file)}
                className={`w-full text-left p-3 rounded-lg border transition-all flex flex-col ${
                  activeFile.path === file.path
                    ? 'bg-slate-900 border-emerald-500/50 text-emerald-300'
                    : 'bg-slate-950 border-slate-850 text-slate-300 hover:bg-slate-900/50'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <FileCode className={`h-4 w-4 ${activeFile.path === file.path ? 'text-emerald-400' : 'text-slate-400'}`} />
                  <span className="font-mono text-sm font-medium truncate">{file.name}</span>
                </div>
                <span className="text-[11px] text-slate-500 truncate mb-1">{file.path}</span>
                <p className="text-[11px] text-slate-400 line-clamp-2">{file.description}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Code Content & Details */}
        <div className="lg:col-span-2 flex flex-col bg-slate-950 rounded-xl border border-slate-850 overflow-hidden h-[500px] lg:h-full">
          {/* Header */}
          <div className="bg-slate-900 p-4 border-b border-slate-850 flex items-center justify-between">
            <div className="min-w-0">
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 uppercase font-mono tracking-wider">
                {activeFile.language}
              </span>
              <h4 className="text-sm font-mono font-bold text-white truncate mt-1">{activeFile.path}</h4>
            </div>
            <button
              onClick={() => handleCopy(activeFile.content, activeFile.name)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white transition-all text-xs"
            >
              {copiedFile === activeFile.name ? (
                <>
                  <Check className="h-3.5 w-3.5 text-emerald-400" />
                  <span className="text-emerald-400 font-medium">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5" />
                  <span>Copy Code</span>
                </>
              )}
            </button>
          </div>

          {/* Description */}
          <div className="bg-slate-900/50 p-4 border-b border-slate-850 text-xs text-slate-300">
            <strong className="text-slate-400 block mb-1">Component Description:</strong>
            {activeFile.description}
          </div>

          {/* Code Viewer Container */}
          <div className="flex-1 overflow-auto p-4 font-mono text-xs text-slate-300 bg-slate-950 leading-relaxed scrollbar-thin">
            <pre className="whitespace-pre">{activeFile.content}</pre>
          </div>
        </div>
      </div>
    </div>
  );
}
