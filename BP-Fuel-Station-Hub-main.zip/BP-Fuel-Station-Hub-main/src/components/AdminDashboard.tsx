import React, { useState } from 'react';
import { FuelStation, StoreProduct, Promotion, FuelType } from '../types';
import { TrendingUp, Users, DollarSign, Fuel, AlertCircle, Sparkles, Check, Play, Settings2 } from 'lucide-react';

interface AdminDashboardProps {
  stations: FuelStation[];
  onUpdateStations: (updated: FuelStation[]) => void;
  promotions: Promotion[];
  onUpdatePromotions: (updated: Promotion[]) => void;
  activeOrdersCount: number;
}

export default function AdminDashboard({
  stations,
  onUpdateStations,
  promotions,
  onUpdatePromotions,
  activeOrdersCount,
}: AdminDashboardProps) {
  const [selectedStationId, setSelectedStationId] = useState<string>(stations[0]?.id || '');
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const selectedStation = stations.find((s) => s.id === selectedStationId) || stations[0];

  const handlePriceChange = (fuelType: FuelType, newPrice: number) => {
    const updated = stations.map((st) => {
      if (st.id === selectedStationId) {
        return {
          ...st,
          fuels: {
            ...st.fuels,
            [fuelType]: {
              ...st.fuels[fuelType],
              price: Number(newPrice.toFixed(3)),
              lastUpdated: 'Just now',
            },
          },
        };
      }
      return st;
    });
    onUpdateStations(updated);
    showSuccess(`Updated ${fuelType} price to £${newPrice.toFixed(3)}/L`);
  };

  const handleAvailabilityToggle = (fuelType: FuelType) => {
    const updated = stations.map((st) => {
      if (st.id === selectedStationId) {
        const isCurrentlyAvailable = st.fuels[fuelType].available;
        return {
          ...st,
          fuels: {
            ...st.fuels,
            [fuelType]: {
              ...st.fuels[fuelType],
              available: !isCurrentlyAvailable,
              lastUpdated: 'Just now',
            },
          },
        };
      }
      return st;
    });
    onUpdateStations(updated);
    const isNowAvailable = updated.find(s => s.id === selectedStationId)?.fuels[fuelType].available;
    showSuccess(`${fuelType} is now ${isNowAvailable ? 'Available' : 'Out of Stock'}`);
  };

  const handleQueueStatusChange = (status: 'Empty' | 'Moderate' | 'Busy') => {
    const updated = stations.map((st) => {
      if (st.id === selectedStationId) {
        return { ...st, queueStatus: status };
      }
      return st;
    });
    onUpdateStations(updated);
    showSuccess(`Updated station queue status to ${status}`);
  };

  const handlePromoToggle = (promoId: string) => {
    const updated = promotions.map((pr) => {
      if (pr.id === promoId) {
        return { ...pr, claimed: !pr.claimed };
      }
      return pr;
    });
    onUpdatePromotions(updated);
    const updatedPromo = updated.find(p => p.id === promoId);
    showSuccess(`Promotion "${updatedPromo?.title}" status updated.`);
  };

  const showSuccess = (msg: string) => {
    setSuccessMessage(msg);
    setTimeout(() => setSuccessMessage(null), 3000);
  };

  // KPI calculations (predefined mock telemetry)
  const totalLitersSold = 142450.8;
  const totalRevenue = 208450.50;
  const activeLoyaltyUsers = 3840;

  // Render responsive SVG paths for the interactive charts
  const revenuePoints = "20,120 80,95 140,110 200,75 260,85 320,50 380,45 440,25 500,30 560,15";
  const fuelTypeVolumes = [
    { type: 'Regular Petrol', liters: 62400, color: '#10B981' },
    { type: 'Premium Petrol', liters: 34500, color: '#34D399' },
    { type: 'Diesel', liters: 31000, color: '#FBBF24' },
    { type: 'Premium Diesel', liters: 12050, color: '#F59E0B' },
    { type: 'EV Charging', liters: 2500, color: '#3B82F6' },
  ];

  return (
    <div className="space-y-6" id="admin-dashboard-root">
      {/* Overview stats cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-sm hover:shadow-md transition-all flex items-center gap-4">
          <div className="p-3.5 bg-emerald-50 rounded-xl text-emerald-600">
            <DollarSign className="h-6 w-6" />
          </div>
          <div>
            <span className="text-xs text-slate-400 font-medium block uppercase tracking-wider">Total Revenue</span>
            <span className="text-2xl font-bold text-slate-800 tracking-tight">£{totalRevenue.toLocaleString()}</span>
            <span className="text-xs text-emerald-500 font-semibold block mt-0.5">↑ 12.4% this week</span>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-sm hover:shadow-md transition-all flex items-center gap-4">
          <div className="p-3.5 bg-emerald-50 rounded-xl text-emerald-600">
            <Fuel className="h-6 w-6" />
          </div>
          <div>
            <span className="text-xs text-slate-400 font-medium block uppercase tracking-wider">Fuel Vol. Dispensed</span>
            <span className="text-2xl font-bold text-slate-800 tracking-tight">{totalLitersSold.toLocaleString()} L</span>
            <span className="text-xs text-emerald-500 font-semibold block mt-0.5">↑ 8.1% vs last month</span>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-sm hover:shadow-md transition-all flex items-center gap-4">
          <div className="p-3.5 bg-amber-50 rounded-xl text-amber-600">
            <Users className="h-6 w-6" />
          </div>
          <div>
            <span className="text-xs text-slate-400 font-medium block uppercase tracking-wider">Active App Users</span>
            <span className="text-2xl font-bold text-slate-800 tracking-tight">{activeLoyaltyUsers.toLocaleString()}</span>
            <span className="text-xs text-emerald-500 font-semibold block mt-0.5">↑ 4.2% daily active</span>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-sm hover:shadow-md transition-all flex items-center gap-4">
          <div className="p-3.5 bg-blue-50 rounded-xl text-blue-600">
            <TrendingUp className="h-6 w-6" />
          </div>
          <div>
            <span className="text-xs text-slate-400 font-medium block uppercase tracking-wider">Active Pickup Orders</span>
            <span className="text-2xl font-bold text-slate-800 tracking-tight">{activeOrdersCount}</span>
            <span className="text-xs text-slate-400 font-medium block mt-0.5">Pending barista pickup</span>
          </div>
        </div>
      </div>

      {/* Success notifier popup */}
      {successMessage && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-3 rounded-xl flex items-center gap-2 text-sm shadow-sm animate-fade-in animate-duration-300">
          <Check className="h-5 w-5 text-emerald-600 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Pricing and station controllers */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left column: Live price controller */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-100 p-6 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-100">
            <div>
              <h3 className="text-lg font-bold text-slate-800 tracking-tight flex items-center gap-1.5">
                <Settings2 className="h-5 w-5 text-emerald-600" />
                Live Pricing & Availability Control
              </h3>
              <p className="text-xs text-slate-400">Modify fuel prices in real-time. Changes instantly reflect inside customer apps.</p>
            </div>
            
            <select
              value={selectedStationId}
              onChange={(e) => setSelectedStationId(e.target.value)}
              className="px-3 py-1.5 rounded-xl border border-slate-200 text-slate-700 text-sm font-medium focus:outline-none focus:border-emerald-500 bg-white"
            >
              {stations.map((st) => (
                <option key={st.id} value={st.id}>
                  {st.name}
                </option>
              ))}
            </select>
          </div>

          {/* Table of fuels and interactive prices */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm border-collapse">
              <thead>
                <tr className="border-b border-slate-100 text-slate-400 text-xs font-semibold">
                  <th className="py-3 px-2">Fuel Type</th>
                  <th className="py-3 px-2">Live Cost (per L / kWh)</th>
                  <th className="py-3 px-2">Quick Adjust</th>
                  <th className="py-3 px-2 text-center">In Stock Status</th>
                  <th className="py-3 px-2 text-right">Last Sync</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 text-slate-700">
                {(Object.keys(selectedStation.fuels) as FuelType[]).map((fuelKey) => {
                  const fuelDetails = selectedStation.fuels[fuelKey];
                  return (
                    <tr key={fuelKey} className="hover:bg-slate-50/50 transition-colors">
                      <td className="py-3.5 px-2 font-medium text-slate-800">{fuelKey}</td>
                      <td className="py-3.5 px-2 font-mono text-emerald-700 font-bold">
                        £{fuelDetails.price.toFixed(3)}
                      </td>
                      <td className="py-3.5 px-2">
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handlePriceChange(fuelKey, fuelDetails.price - 0.01)}
                            className="px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-mono font-bold transition-colors"
                          >
                            -0.01
                          </button>
                          <button
                            onClick={() => handlePriceChange(fuelKey, fuelDetails.price + 0.01)}
                            className="px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-mono font-bold transition-colors"
                          >
                            +0.01
                          </button>
                        </div>
                      </td>
                      <td className="py-3.5 px-2 text-center">
                        <button
                          onClick={() => handleAvailabilityToggle(fuelKey)}
                          className={`px-2.5 py-1 rounded-full text-xs font-semibold transition-all ${
                            fuelDetails.available
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-150'
                              : 'bg-rose-50 text-rose-700 border border-rose-150'
                          }`}
                        >
                          {fuelDetails.available ? 'In Stock' : 'Out of Stock'}
                        </button>
                      </td>
                      <td className="py-3.5 px-2 text-right text-xs text-slate-400 font-mono">
                        {fuelDetails.lastUpdated}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Queue controller */}
          <div className="mt-6 pt-6 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-sm font-semibold text-slate-800">Station Traffic Congestion:</span>
              <p className="text-xs text-slate-400">Controls queue warning meters on locator maps</p>
            </div>
            <div className="flex gap-2">
              {(['Empty', 'Moderate', 'Busy'] as const).map((qState) => (
                <button
                  key={qState}
                  onClick={() => handleQueueStatusChange(qState)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-all ${
                    selectedStation.queueStatus === qState
                      ? qState === 'Empty'
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                        : qState === 'Moderate'
                        ? 'bg-amber-50 border-amber-300 text-amber-800'
                        : 'bg-rose-50 border-rose-300 text-rose-800'
                      : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50'
                  }`}
                >
                  {qState} Traffic
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right column: Promotion campaign managers */}
        <div className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="text-lg font-bold text-slate-800 tracking-tight flex items-center gap-1.5 mb-2">
              <Sparkles className="h-5 w-5 text-emerald-600" />
              Promotions Coordinator
            </h3>
            <p className="text-xs text-slate-400 mb-4">Toggle targeted geo-location campaigns and dynamic user incentives.</p>
            
            <div className="space-y-3">
              {promotions.map((promo) => (
                <div key={promo.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider inline-block mb-1 ${
                      promo.category === 'Fuel'
                        ? 'bg-emerald-100 text-emerald-800'
                        : promo.category === 'Coffee'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-blue-100 text-blue-800'
                    }`}>
                      {promo.category}
                    </span>
                    <h4 className="text-xs font-bold text-slate-800 truncate">{promo.title}</h4>
                    <p className="text-[11px] text-slate-500 line-clamp-1">{promo.description}</p>
                  </div>
                  
                  <button
                    onClick={() => handlePromoToggle(promo.id)}
                    className={`px-2 py-1 rounded-lg text-[10px] font-bold transition-all ${
                      !promo.claimed
                        ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                        : 'bg-slate-200 text-slate-500 hover:bg-slate-300'
                    }`}
                  >
                    {!promo.claimed ? 'Active' : 'Disabled'}
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 text-center">
            <span className="text-[11px] text-slate-400 block font-mono">Connected terminals: 2 Online</span>
          </div>
        </div>
      </div>

      {/* Analytics Charts & Graphs */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue SVG Line Chart */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-100 p-6 shadow-sm">
          <h3 className="text-base font-bold text-slate-800 mb-1">Fuel & Store Sales Trends (24h)</h3>
          <p className="text-xs text-slate-400 mb-6">Visual tracking of digital pay transactions and in-store purchases.</p>
          
          <div className="relative h-48 w-full bg-slate-50/50 rounded-xl border border-slate-100/80 p-4">
            {/* SVG graph */}
            <svg viewBox="0 0 600 150" className="w-full h-full" preserveAspectRatio="none">
              <defs>
                <linearGradient id="chartGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#10B981" stopOpacity="0.25" />
                  <stop offset="100%" stopColor="#10B981" stopOpacity="0" />
                </linearGradient>
              </defs>
              {/* Fill area */}
              <path
                d={`M 20,150 L ${revenuePoints} L 560,150 Z`}
                fill="url(#chartGrad)"
              />
              {/* Stroke line */}
              <path
                d={`M ${revenuePoints}`}
                fill="none"
                stroke="#10B981"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              {/* Data points */}
              {revenuePoints.split(' ').map((pt, idx) => {
                const [x, y] = pt.split(',');
                return (
                  <circle
                    key={idx}
                    cx={x}
                    cy={y}
                    r="4"
                    fill="#10B981"
                    stroke="#FFFFFF"
                    strokeWidth="1.5"
                    className="hover:r-6 cursor-pointer transition-all"
                  />
                );
              })}
            </svg>
            
            {/* Grid labels */}
            <div className="absolute bottom-2 left-4 right-4 flex justify-between text-[10px] text-slate-400 font-mono">
              <span>08:00</span>
              <span>12:00</span>
              <span>16:00</span>
              <span>20:00</span>
              <span>00:00</span>
              <span>04:00</span>
              <span>08:00</span>
            </div>
          </div>
        </div>

        {/* Volume share progress list */}
        <div className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm">
          <h3 className="text-base font-bold text-slate-800 mb-1">Sales Share by Fuel Type</h3>
          <p className="text-xs text-slate-400 mb-6">Comparative layout of today's dispensed volumes.</p>

          <div className="space-y-4">
            {fuelTypeVolumes.map((item) => {
              const maxLiters = 65000;
              const percentage = (item.liters / maxLiters) * 100;
              return (
                <div key={item.type}>
                  <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1.5">
                    <span>{item.type}</span>
                    <span className="font-mono text-slate-500">{item.liters.toLocaleString()} L</span>
                  </div>
                  <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-1000"
                      style={{
                        width: `${percentage}%`,
                        backgroundColor: item.color,
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
