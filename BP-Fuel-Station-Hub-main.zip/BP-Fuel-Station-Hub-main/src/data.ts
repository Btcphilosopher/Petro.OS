import { FuelStation, StoreProduct, Promotion, Vehicle, WalletTransaction, DigitalReceipt } from './types';

export const INITIAL_STATIONS: FuelStation[] = [
  {
    id: 'st-01',
    name: 'BP Hammersmith Connect',
    address: 'Great West Rd, Hammersmith, London W6 9TX',
    latitude: 51.4912,
    longitude: -0.2238,
    distance: 0.8,
    isOpen: true,
    openHours: 'Open 24 Hours',
    queueStatus: 'Moderate',
    services: {
      evChargers: true,
      carWash: true,
      airPump: true,
      atm: true,
      toilet: true,
      store: true,
      coffeeShop: true,
      lpg: false
    },
    fuels: {
      'Regular Petrol': { price: 1.439, available: true, lastUpdated: '10 mins ago' },
      'Premium Petrol': { price: 1.559, available: true, lastUpdated: '10 mins ago' },
      'Diesel': { price: 1.499, available: true, lastUpdated: '10 mins ago' },
      'Premium Diesel': { price: 1.619, available: true, lastUpdated: '10 mins ago' },
      'LPG': { price: 0.849, available: false, lastUpdated: '2 hours ago' },
      'AdBlue': { price: 1.129, available: true, lastUpdated: '1 hour ago' },
      'EV Charging': { price: 0.69, available: true, lastUpdated: '10 mins ago' }
    },
    rating: 4.6
  },
  {
    id: 'st-02',
    name: 'BP Richmond Pulse',
    address: 'Lower Mortlake Rd, Richmond TW9 2JU',
    latitude: 51.4641,
    longitude: -0.2912,
    distance: 2.3,
    isOpen: true,
    openHours: 'Open 24 Hours',
    queueStatus: 'Empty',
    services: {
      evChargers: true,
      carWash: false,
      airPump: true,
      atm: true,
      toilet: true,
      store: true,
      coffeeShop: true,
      lpg: true
    },
    fuels: {
      'Regular Petrol': { price: 1.459, available: true, lastUpdated: '1 hour ago' },
      'Premium Petrol': { price: 1.579, available: true, lastUpdated: '1 hour ago' },
      'Diesel': { price: 1.519, available: true, lastUpdated: '1 hour ago' },
      'Premium Diesel': { price: 1.639, available: true, lastUpdated: '1 hour ago' },
      'LPG': { price: 0.899, available: true, lastUpdated: '1 hour ago' },
      'AdBlue': { price: 1.159, available: true, lastUpdated: '2 hours ago' },
      'EV Charging': { price: 0.65, available: true, lastUpdated: '1 hour ago' }
    },
    rating: 4.4
  },
  {
    id: 'st-03',
    name: 'BP Kensington Mews',
    address: 'Cromwell Rd, South Kensington, London SW7 4EF',
    latitude: 51.4952,
    longitude: -0.1804,
    distance: 3.5,
    isOpen: true,
    openHours: '06:00 - 23:00',
    queueStatus: 'Busy',
    services: {
      evChargers: false,
      carWash: true,
      airPump: true,
      atm: false,
      toilet: true,
      store: true,
      coffeeShop: true,
      lpg: false
    },
    fuels: {
      'Regular Petrol': { price: 1.489, available: true, lastUpdated: '5 mins ago' },
      'Premium Petrol': { price: 1.609, available: true, lastUpdated: '5 mins ago' },
      'Diesel': { price: 1.539, available: true, lastUpdated: '5 mins ago' },
      'Premium Diesel': { price: 1.659, available: true, lastUpdated: '5 mins ago' },
      'LPG': { price: 0.00, available: false, lastUpdated: 'N/A' },
      'AdBlue': { price: 1.209, available: true, lastUpdated: '4 hours ago' },
      'EV Charging': { price: 0.00, available: false, lastUpdated: 'N/A' }
    },
    rating: 4.2
  },
  {
    id: 'st-04',
    name: 'BP Wembley Highway',
    address: 'Harrow Rd, Wembley HA9 6QE',
    latitude: 51.5542,
    longitude: -0.2923,
    distance: 5.1,
    isOpen: true,
    openHours: 'Open 24 Hours',
    queueStatus: 'Moderate',
    services: {
      evChargers: true,
      carWash: true,
      airPump: true,
      atm: true,
      toilet: true,
      store: true,
      coffeeShop: false,
      lpg: true
    },
    fuels: {
      'Regular Petrol': { price: 1.419, available: true, lastUpdated: '30 mins ago' },
      'Premium Petrol': { price: 1.539, available: true, lastUpdated: '30 mins ago' },
      'Diesel': { price: 1.479, available: true, lastUpdated: '30 mins ago' },
      'Premium Diesel': { price: 1.599, available: true, lastUpdated: '30 mins ago' },
      'LPG': { price: 0.829, available: true, lastUpdated: '30 mins ago' },
      'AdBlue': { price: 1.099, available: true, lastUpdated: '1 hour ago' },
      'EV Charging': { price: 0.59, available: true, lastUpdated: '30 mins ago' }
    },
    rating: 4.5
  }
];

export const STORE_PRODUCTS: StoreProduct[] = [
  { id: 'p-01', name: 'BP Wild Bean Flat White', category: 'Coffee', price: 3.45, description: 'Freshly ground premium Arabica coffee with velvet steamed milk.' },
  { id: 'p-02', name: 'BP Wild Bean Latte', category: 'Coffee', price: 3.65, description: 'Indulgent espresso combined with texturized fresh dairy or plant milk.' },
  { id: 'p-03', name: 'BP Wild Bean Cappuccino', category: 'Coffee', price: 3.65, description: 'Rich espresso capped with airy milk foam and chocolate dusting.' },
  { id: 'p-04', name: 'BP Wild Bean Espresso Double', category: 'Coffee', price: 2.50, description: 'Bold and smooth double shot of BP house-blend coffee.' },
  { id: 'p-05', name: 'Castrol EDGE 5W-30 1L', category: 'Engine Oil', price: 17.99, description: 'Fully synthetic fluid titanium engine oil for ultimate engine performance.' },
  { id: 'p-06', name: 'Castrol MAGNATEC 10W-40 1L', category: 'Engine Oil', price: 13.49, description: 'Instant protection from the moment you turn the key.' },
  { id: 'p-07', name: 'BP Ultimate Car Wash Kit', category: 'Car Accessories', price: 12.99, description: 'Includes wax wash, microfiber cloth, tire shine, and sponge.' },
  { id: 'p-08', name: 'Premium Screenwash 5L', category: 'Car Accessories', price: 6.50, description: 'Anti-smear, freeze protection down to -10°C, clear view.' },
  { id: 'p-09', name: 'BP Fresh Chicken & Bacon Club', category: 'Sandwiches', price: 4.75, description: 'Smoked bacon, tender roast chicken, and fresh lettuce in thick malted bread.' },
  { id: 'p-10', name: 'BP Triple Cheese & Tomato Toastie', category: 'Sandwiches', price: 4.25, description: 'Cheddar, mozzarella, and Red Leicester with sun-ripened tomatoes.' },
  { id: 'p-11', name: 'Coca Cola Zero 500ml', category: 'Drinks', price: 2.10, description: 'Great Coca-Cola taste with zero sugar and calories.' },
  { id: 'p-12', name: 'Lucozade Energy Orange 500ml', category: 'Drinks', price: 2.25, description: 'Sparkling glucose energy drink powered by real fruit juice.' },
  { id: 'p-13', name: 'McCoys Salt & Vinegar Crisps', category: 'Snacks', price: 1.45, description: 'Ridge-cut potato crisps packed with robust crunch and tang.' },
  { id: 'p-14', name: 'Cadbury Dairy Milk 110g', category: 'Snacks', price: 2.20, description: 'Classic delicious milk chocolate bar with fairtrade cocoa.' },
  { id: 'p-15', name: 'Pringles Sour Cream & Onion 200g', category: 'Snacks', price: 2.99, description: 'Iconic stackable crisps with delicious sour cream seasoning.' }
];

export const INITIAL_PROMOTIONS: Promotion[] = [
  {
    id: 'promo-01',
    title: '5p Off Per Liter',
    description: 'Save 5p/L on BP Ultimate Fuels when you buy any Wild Bean Coffee.',
    code: 'ULTIMATE5OFF',
    discountValue: '5p/L',
    category: 'Fuel',
    expiresDate: '31 Aug 2026',
    claimed: false
  },
  {
    id: 'promo-02',
    title: 'Free Coffee Upgrade',
    description: 'Claim a free Large upgrade on any Wild Bean hot beverage order.',
    code: 'COFFEEUP',
    discountValue: 'Free Size Upgrade',
    category: 'Coffee',
    expiresDate: '25 Jul 2026',
    claimed: false
  },
  {
    id: 'promo-03',
    title: 'Castrol Oil Combo Pack',
    description: 'Get 20% off screenwash when you purchase 1L of Castrol EDGE.',
    code: 'CASTROL20',
    discountValue: '20% Off Screenwash',
    category: 'Store',
    expiresDate: '15 Aug 2026',
    claimed: false
  },
  {
    id: 'promo-04',
    title: 'Double Points Weekend',
    description: 'Earn 2x Loyalty Points on all EV Charging sessions this weekend.',
    code: 'EV2XPOINTS',
    discountValue: '2x Points Multiplier',
    category: 'Loyalty',
    expiresDate: '20 Jul 2026',
    claimed: false
  },
  {
    id: 'promo-05',
    title: 'Deluxe Wash half-price',
    description: 'Get 50% off Deluxe Wash when you fill up with 40L or more.',
    code: 'WASH50',
    discountValue: '50% Car Wash',
    category: 'Car Wash',
    expiresDate: '10 Sep 2026',
    claimed: false
  }
];

export const INITIAL_VEHICLES: Vehicle[] = [
  {
    id: 'v-01',
    registration: 'BP75 COM',
    make: 'Volkswagen',
    model: 'Golf Mk8 R-Line',
    year: 2022,
    fuelType: 'Premium Petrol',
    mileage: 18450,
    reminders: {
      mot: '2026-11-15',
      insurance: '2026-09-01',
      service: '2026-10-20',
      oilChange: '2026-08-15'
    }
  },
  {
    id: 'v-02',
    registration: 'EV24 CHG',
    make: 'Tesla',
    model: 'Model Y Long Range',
    year: 2024,
    fuelType: 'EV Charging',
    mileage: 4200,
    reminders: {
      mot: '2027-04-18',
      insurance: '2026-12-10',
      service: '2027-04-18',
      oilChange: 'N/A'
    }
  }
];

export const INITIAL_TRANSACTIONS: WalletTransaction[] = [
  { id: 'tx-01', date: '2026-07-14 14:32', description: 'Fuel Purchase - BP Hammersmith', amount: -48.50, type: 'debit' },
  { id: 'tx-02', date: '2026-07-14 14:35', description: 'Earned Points - 97 Points', amount: 97, type: 'credit' },
  { id: 'tx-03', date: '2026-07-11 08:15', description: 'Wild Bean Coffee & Toastie', amount: -7.70, type: 'debit' },
  { id: 'tx-04', date: '2026-07-10 18:00', description: 'Wallet Deposit via Google Pay', amount: 50.00, type: 'credit' },
  { id: 'tx-05', date: '2026-07-05 11:20', description: 'Premium Car Wash', amount: -15.00, type: 'debit' }
];

export const INITIAL_RECEIPTS: DigitalReceipt[] = [
  {
    id: 'rec-1001',
    date: '2026-07-14',
    time: '14:32',
    stationId: 'st-01',
    stationName: 'BP Hammersmith Connect',
    pumpNumber: 4,
    fuelType: 'Premium Petrol',
    liters: 31.11,
    amount: 48.50,
    pricePerLiter: 1.559,
    paymentMethod: 'BP Wallet',
    vatInvoice: 'GB123456789-1001'
  },
  {
    id: 'rec-1002',
    date: '2026-07-05',
    time: '11:20',
    stationId: 'st-01',
    stationName: 'BP Hammersmith Connect',
    pumpNumber: 2,
    fuelType: 'Diesel',
    liters: 10.01,
    amount: 15.00,
    pricePerLiter: 1.499,
    paymentMethod: 'Google Pay',
    vatInvoice: 'GB123456789-1002'
  }
];

export const FAQS = [
  {
    q: 'How does Pay at Pump work?',
    a: 'Simply park at a pump, open the BP app, select Pay at Pump, choose your pump number and authorize payment. Once authorized, you can step out, fill up, and the correct amount will be charged directly, with a digital receipt sent instantly!'
  },
  {
    q: 'How do I earn BP Loyalty Points?',
    a: 'Show your loyalty QR code at checkout, or complete fuel payments via Pay at Pump to automatically earn points. Points can be used for instant fuel discounts, store items, free coffees, and merchandise.'
  },
  {
    q: 'What is the EV Charging network speed?',
    a: 'BP Pulse provides ultra-fast EV chargers with speeds ranging from 50kW up to 150kW and 350kW, allowing you to add up to 100 miles of range in just 10-15 minutes.'
  },
  {
    q: 'Can I order coffee for priority pickup?',
    a: 'Yes, select Order Coffee, customize your drink, choose your pickup time, pay securely, and scan your QR code at the pick-up counter. Our baristas will have it freshly brewed and ready.'
  }
];
