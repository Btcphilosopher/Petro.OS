export type FuelType = 
  | 'Regular Petrol'
  | 'Premium Petrol'
  | 'Diesel'
  | 'Premium Diesel'
  | 'LPG'
  | 'AdBlue'
  | 'EV Charging';

export type LoyaltyTier = 'Bronze' | 'Silver' | 'Gold' | 'Platinum';

export interface FuelPrice {
  price: number;
  available: boolean;
  lastUpdated: string;
}

export interface FuelStation {
  id: string;
  name: string;
  address: string;
  latitude: number;
  longitude: number;
  distance: number;
  isOpen: boolean;
  openHours: string;
  queueStatus: 'Empty' | 'Moderate' | 'Busy';
  services: {
    evChargers: boolean;
    carWash: boolean;
    airPump: boolean;
    atm: boolean;
    toilet: boolean;
    store: boolean;
    coffeeShop: boolean;
    lpg: boolean;
  };
  fuels: Record<FuelType, FuelPrice>;
  rating: number;
}

export interface Vehicle {
  id: string;
  registration: string;
  make: string;
  model: string;
  year: number;
  fuelType: FuelType;
  mileage: number;
  reminders: {
    mot: string;
    insurance: string;
    service: string;
    oilChange: string;
  };
}

export interface WalletTransaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: 'credit' | 'debit';
}

export interface DigitalReceipt {
  id: string;
  date: string;
  time: string;
  stationId: string;
  stationName: string;
  pumpNumber: number;
  fuelType: FuelType;
  liters: number;
  amount: number;
  pricePerLiter: number;
  paymentMethod: string;
  vatInvoice: string;
}

export interface StoreProduct {
  id: string;
  name: string;
  category: 'Coffee' | 'Snacks' | 'Drinks' | 'Sandwiches' | 'Groceries' | 'Car Accessories' | 'Engine Oil';
  price: number;
  description: string;
  iconName?: string;
}

export interface CoffeeOrder {
  id: string;
  name: string;
  size: 'Regular' | 'Large';
  milk: 'Full Cream' | 'Skimmed' | 'Oat' | 'Almond';
  sugar: 'None' | 'One' | 'Two' | 'Sweetener';
  flavor: 'None' | 'Vanilla' | 'Caramel' | 'Hazelnut';
  pickupTime: string;
  price: number;
  status: 'Pending' | 'Preparing' | 'Ready' | 'Picked Up';
  qrCode: string;
}

export interface CarWashBooking {
  id: string;
  packageName: 'Basic Wash' | 'Deluxe Wash' | 'Premium Wash';
  price: number;
  features: string[];
  scheduleTime: string;
  status: 'Active' | 'Completed' | 'Expired';
  qrCode: string;
}

export interface EVChargingSession {
  id: string;
  stationId: string;
  chargerId: string;
  speed: string; // e.g. "150 kW Ultra Fast"
  stateOfCharge: number; // percentage
  duration: number; // minutes elapsed
  estimatedMinutesLeft: number;
  cost: number;
  status: 'Active' | 'Completed';
}

export interface Promotion {
  id: string;
  title: string;
  description: string;
  code: string;
  discountValue: string;
  category: 'Fuel' | 'Store' | 'Coffee' | 'Car Wash' | 'Loyalty';
  expiresDate: string;
  claimed: boolean;
}

export interface SupportMessage {
  id: string;
  sender: 'user' | 'agent';
  text: string;
  timestamp: string;
}
