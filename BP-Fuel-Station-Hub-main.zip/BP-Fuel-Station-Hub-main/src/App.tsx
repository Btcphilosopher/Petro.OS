import React, { useState } from 'react';
import { 
  FuelStation, Promotion, Vehicle, WalletTransaction, DigitalReceipt, CoffeeOrder, CarWashBooking 
} from './types';
import { 
  INITIAL_STATIONS, INITIAL_PROMOTIONS, INITIAL_VEHICLES, 
  INITIAL_TRANSACTIONS, INITIAL_RECEIPTS 
} from './data';
import MobileEmulator from './components/MobileEmulator';
import CustomerApp from './components/CustomerApp';
import StaffApp from './components/StaffApp';
import AdminDashboard from './components/AdminDashboard';
import CodeExporter from './components/CodeExporter';
import { 
  Smartphone, BarChart3, FileCode2, Zap, HelpCircle, 
  Sparkles, ShieldCheck, Mail, MapPin, Award
} from 'lucide-react';

export default function App() {
  // Shared reactive state
  const [stations, setStations] = useState<FuelStation[]>(INITIAL_STATIONS);
  const [promotions, setPromotions] = useState<Promotion[]>(INITIAL_PROMOTIONS);
  const [vehicles, setVehicles] = useState<Vehicle[]>(INITIAL_VEHICLES);
  const [walletBalance, setWalletBalance] = useState<number>(120.50); // initial seed wallet balance
  const [transactions, setTransactions] = useState<WalletTransaction[]>(INITIAL_TRANSACTIONS);
  const [receipts, setReceipts] = useState<DigitalReceipt[]>(INITIAL_RECEIPTS);
  const [coffeeOrders, setCoffeeOrders] = useState<CoffeeOrder[]>([]);
  const [washBookings, setWashBookings] = useState<CarWashBooking[]>([]);

  // Workspace layout navigation: emulator, admin dashboard or code hub
  const [workspaceMode, setWorkspaceMode] = useState<'emulator' | 'admin' | 'code'>('emulator');
  // Sub-role for the mobile emulator
  const [emulatorRole, setEmulatorRole] = useState<'customer' | 'staff'>('customer');

  // Sync callbacks
  const handleClaimPromo = (promoId: string) => {
    setPromotions(prev => prev.map(p => p.id === promoId ? { ...p, claimed: true } : p));
  };

  const handleAddVehicle = (newVehicle: Vehicle) => {
    setVehicles(prev => [newVehicle, ...prev]);
  };

  const handleUpdateWallet = (newBalance: number) => {
    setWalletBalance(newBalance);
  };

  const handleAddTransaction = (tx: WalletTransaction) => {
    setTransactions(prev => [tx, ...prev]);
  };

  const handleAddReceipt = (rec: DigitalReceipt) => {
    setReceipts(prev => [rec, ...prev]);
  };

  const handleAddCoffeeOrder = (ord: CoffeeOrder) => {
    setCoffeeOrders(prev => [ord, ...prev]);
  };

  const handleUpdateCoffeeOrderStatus = (orderId: string, status: 'Pending' | 'Preparing' | 'Ready' | 'Picked Up') => {
    setCoffeeOrders(prev => prev.map(o => o.id === orderId ? { ...o, status } : o));
  };

  const handleAddWashBooking = (wash: CarWashBooking) => {
    setWashBookings(prev => [wash, ...prev]);
  };

  const handleScanVoucher = (qrCode: string) => {
    // Process voucher scans inside staff interface
    setWashBookings(prev => prev.map(w => w.qrCode === qrCode ? { ...w, status: 'Completed' } : w));
  };

  const handleTriggerStaffSync = () => {
    // Silent notification indicator trigger
  };

  return (
    <div className="min-h-screen bg-[#fafafa] font-sans flex flex-col justify-between" id="app-root">
      {/* Top Main Workspace Navigation Hub */}
      <header className="bg-white border-b border-slate-100 py-4 px-6 shrink-0">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
          
          {/* BP Branding Header */}
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-[#008B45] flex items-center justify-center border-2 border-[#FED100] shadow-sm">
              <span className="font-serif font-black text-xl text-[#FED100] tracking-tighter italic">bp</span>
            </div>
            <div>
              <h1 className="text-xl font-serif font-black text-slate-900 tracking-tighter leading-none italic">BP CONNECT</h1>
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5 block">Mobile App Sandbox & Live Codebase</span>
            </div>
          </div>

          {/* Main workspace navigation tabs */}
          <div className="flex bg-slate-50 p-1 rounded-full border border-slate-200/60 text-xs font-bold uppercase tracking-wider self-start md:self-auto shadow-xs">
            <button
              onClick={() => setWorkspaceMode('emulator')}
              className={`flex items-center gap-1.5 px-5 py-2 rounded-full transition-all duration-300 ${
                workspaceMode === 'emulator'
                  ? 'bg-[#008B45] text-white shadow-sm font-extrabold'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Smartphone className="h-4.5 w-4.5" />
              Simulator
            </button>
            
            <button
              onClick={() => setWorkspaceMode('admin')}
              className={`flex items-center gap-1.5 px-5 py-2 rounded-full transition-all duration-300 ${
                workspaceMode === 'admin'
                  ? 'bg-[#008B45] text-white shadow-sm font-extrabold'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <BarChart3 className="h-4.5 w-4.5" />
              Admin Panel
            </button>
            
            <button
              onClick={() => setWorkspaceMode('code')}
              className={`flex items-center gap-1.5 px-5 py-2 rounded-full transition-all duration-300 ${
                workspaceMode === 'code'
                  ? 'bg-[#008B45] text-white shadow-sm font-extrabold'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <FileCode2 className="h-4.5 w-4.5" />
              Kotlin Exporter
            </button>
          </div>

        </div>
      </header>

      {/* Main active workspace content body */}
      <main className="flex-grow max-w-7xl w-full mx-auto p-4 md:p-6 overflow-hidden">
        
        {/* Workspace 1: Interactive phone app emulator */}
        {workspaceMode === 'emulator' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center min-h-0">
            {/* Guide sidebar instructions */}
            <div className="lg:col-span-4 space-y-5 text-slate-600 bg-white border border-slate-100 p-6 rounded-[32px] shadow-sm self-start">
              <span className="text-[10px] font-bold text-[#008B45] block uppercase tracking-widest">How to Test the App</span>
              <h3 className="text-2xl font-serif font-black text-slate-900 tracking-tighter leading-tight italic">
                Multi-Role Sandbox
              </h3>
              <p className="text-xs leading-relaxed text-slate-500">
                Experience real-time interaction between Customer, Staff, and Admin roles directly inside your browser:
              </p>
              
              <ul className="space-y-4 text-xs leading-relaxed">
                <li className="flex gap-3">
                  <span className="h-6 w-6 rounded-full bg-[#008B45] text-[#FED100] font-black shrink-0 flex items-center justify-center text-[11px] font-serif italic">1</span>
                  <span className="text-slate-600">
                    <strong className="text-slate-900 font-semibold block mb-0.5">Fill up Petrol / Diesel:</strong> Navigate to **Stations**, select a BP pump, click **Fill Up**, and preauthorize funds. Watch the live counter accrue fuel & loyalty points in real-time.
                  </span>
                </li>
                <li className="flex gap-3">
                  <span className="h-6 w-6 rounded-full bg-[#008B45] text-[#FED100] font-black shrink-0 flex items-center justify-center text-[11px] font-serif italic">2</span>
                  <span className="text-slate-600">
                    <strong className="text-slate-900 font-semibold block mb-0.5">Wild Bean Coffee & QR Scans:</strong> Go to **Store**, order a flat white, and checkout. Switch the emulator to **Staff View** to prepare, brew, and complete pickup.
                  </span>
                </li>
                <li className="flex gap-3">
                  <span className="h-6 w-6 rounded-full bg-[#008B45] text-[#FED100] font-black shrink-0 flex items-center justify-center text-[11px] font-serif italic">3</span>
                  <span className="text-slate-600">
                    <strong className="text-slate-900 font-semibold block mb-0.5">Dynamic Pricing:</strong> Open the **Admin Panel** tab. Modify fuel pricing or activate campaigns. See them reflect instantly in the map app locator!
                  </span>
                </li>
              </ul>

              <div className="pt-4 border-t border-slate-100 flex items-center gap-2.5 text-[11px] text-slate-400 font-medium">
                <ShieldCheck className="h-4.5 w-4.5 text-[#008B45]" />
                <span>Encrypted Local State Store Active</span>
              </div>
            </div>

            {/* Centered Phone emulator frame */}
            <div className="lg:col-span-8 flex justify-center min-h-0">
              <MobileEmulator activeRole={emulatorRole} onChangeRole={setEmulatorRole}>
                {emulatorRole === 'customer' ? (
                  <CustomerApp
                    stations={stations}
                    promotions={promotions}
                    onClaimPromo={handleClaimPromo}
                    vehicles={vehicles}
                    onAddVehicle={handleAddVehicle}
                    walletBalance={walletBalance}
                    onUpdateWallet={handleUpdateWallet}
                    transactions={transactions}
                    onAddTransaction={handleAddTransaction}
                    receipts={receipts}
                    onAddReceipt={handleAddReceipt}
                    activeOrders={coffeeOrders}
                    onAddCoffeeOrder={handleAddCoffeeOrder}
                    activeWashBookings={washBookings}
                    onAddWashBooking={handleAddWashBooking}
                    onTriggerStaffSync={handleTriggerStaffSync}
                  />
                ) : (
                  <StaffApp
                    coffeeOrders={coffeeOrders}
                    onUpdateCoffeeOrderStatus={handleUpdateCoffeeOrderStatus}
                    stations={stations}
                    onUpdateStations={setStations}
                    onScanVoucher={handleScanVoucher}
                  />
                )}
              </MobileEmulator>
            </div>
          </div>
        )}

        {/* Workspace 2: Admin pricing and telemetry charts */}
        {workspaceMode === 'admin' && (
          <div className="animate-fade-in">
            <div className="bg-emerald-800 text-white rounded-2xl p-6 mb-6 shadow-md border border-emerald-700 flex justify-between items-center relative overflow-hidden">
              <div className="relative z-10">
                <span className="text-xs font-bold text-emerald-200 uppercase tracking-widest block mb-1">station control deck</span>
                <h2 className="text-2xl font-bold tracking-tight">BP Administrative Console</h2>
                <p className="text-xs text-emerald-100/90 max-w-lg mt-1">Adjust live gas prices, activate dynamic marketing campaigns, monitor sales telemetry graphs, and process customer queue statuses.</p>
              </div>
              <BarChart3 className="h-16 w-16 text-emerald-400/20 absolute -right-4 -bottom-4 z-0" />
            </div>

            <AdminDashboard
              stations={stations}
              onUpdateStations={setStations}
              promotions={promotions}
              onUpdatePromotions={setPromotions}
              activeOrdersCount={coffeeOrders.filter(o => o.status !== 'Picked Up').length}
            />
          </div>
        )}

        {/* Workspace 3: Clean-architecture Kotlin code generator */}
        {workspaceMode === 'code' && (
          <div className="animate-fade-in h-full">
            <CodeExporter />
          </div>
        )}

      </main>

      {/* Elegant minimalist platform footer */}
      <footer className="bg-white border-t border-slate-200 py-4 px-6 shrink-0 text-center text-xs text-slate-400 font-medium">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-2">
          <span>© 2026 BP Petrol Station Mobile Systems. All rights reserved.</span>
          <div className="flex gap-4 justify-center">
            <span className="hover:text-slate-600 cursor-pointer">Security Standards</span>
            <span>•</span>
            <span className="hover:text-slate-600 cursor-pointer">API Integration Guides</span>
            <span>•</span>
            <span className="hover:text-slate-600 cursor-pointer">CI/CD Deployments</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
