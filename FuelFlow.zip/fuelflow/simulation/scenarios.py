"""
simulation.scenarios
======================

Deterministic (given a seed) scenario definitions for the metrology
simulator, per FuelFlow section 15: slow/normal/high-flow/variable flow,
temperature variation, sensor noise, pulse jitter, meter drift, sensor
failure, communication failure, and transaction cancellation.

Each :class:`Scenario` is a small bundle of parameters, not code -- the
actual flow-profile shape and fault injection logic lives in
:mod:`fuelflow.simulation.dispenser_simulator`, which interprets these
parameters uniformly so new scenarios are just new parameter sets.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class FlowProfileShape(str, Enum):
    CONSTANT = "CONSTANT"
    RAMP_UP_DOWN = "RAMP_UP_DOWN"
    VARIABLE = "VARIABLE"


@dataclass(frozen=True)
class Scenario:
    name: str
    flow_profile: FlowProfileShape
    nominal_flow_rate: float  # unit-volume / minute (peak, for ramp/variable shapes)

    temperature_c: float = 15.0
    temperature_variation_amplitude_c: float = 0.0

    pulse_jitter_std_fraction: float = 0.0  # relative std dev applied to per-tick pulse count
    sensor_noise_std_c: float = 0.0  # temperature sensor noise

    meter_drift_per_day: float = 0.0

    sensor_failure_probability: float = 0.0  # probability a given tick reports meter_status_ok=False
    communication_failure_probability: float = 0.0  # probability a given tick reports comms down

    cancel_after_fraction: float | None = None  # if set, cancel once this fraction of target volume is reached

    dt_s: float = 0.25


# --- Preset scenarios --------------------------------------------------

SLOW_DISPENSE = Scenario(name="slow_dispense", flow_profile=FlowProfileShape.CONSTANT, nominal_flow_rate=1.0)

NORMAL_DISPENSE = Scenario(name="normal_dispense", flow_profile=FlowProfileShape.RAMP_UP_DOWN, nominal_flow_rate=6.0)

HIGH_FLOW_DISPENSE = Scenario(name="high_flow_dispense", flow_profile=FlowProfileShape.RAMP_UP_DOWN, nominal_flow_rate=11.5)

VARIABLE_FLOW = Scenario(name="variable_flow", flow_profile=FlowProfileShape.VARIABLE, nominal_flow_rate=7.0)

TEMPERATURE_VARIATION = Scenario(
    name="temperature_variation",
    flow_profile=FlowProfileShape.RAMP_UP_DOWN,
    nominal_flow_rate=6.0,
    temperature_c=10.0,
    temperature_variation_amplitude_c=8.0,
)

SENSOR_NOISE = Scenario(
    name="sensor_noise",
    flow_profile=FlowProfileShape.RAMP_UP_DOWN,
    nominal_flow_rate=6.0,
    sensor_noise_std_c=0.6,
)

PULSE_JITTER = Scenario(
    name="pulse_jitter",
    flow_profile=FlowProfileShape.RAMP_UP_DOWN,
    nominal_flow_rate=6.0,
    pulse_jitter_std_fraction=0.02,
)

METER_DRIFT = Scenario(
    name="meter_drift",
    flow_profile=FlowProfileShape.RAMP_UP_DOWN,
    nominal_flow_rate=6.0,
    meter_drift_per_day=0.00004,
)

SENSOR_FAILURE = Scenario(
    name="sensor_failure",
    flow_profile=FlowProfileShape.RAMP_UP_DOWN,
    nominal_flow_rate=6.0,
    sensor_failure_probability=0.01,
)

COMMUNICATION_FAILURE = Scenario(
    name="communication_failure",
    flow_profile=FlowProfileShape.RAMP_UP_DOWN,
    nominal_flow_rate=6.0,
    communication_failure_probability=0.01,
)

TRANSACTION_CANCELLATION = Scenario(
    name="transaction_cancellation",
    flow_profile=FlowProfileShape.RAMP_UP_DOWN,
    nominal_flow_rate=6.0,
    cancel_after_fraction=0.4,
)

ALL_SCENARIOS = [
    SLOW_DISPENSE,
    NORMAL_DISPENSE,
    HIGH_FLOW_DISPENSE,
    VARIABLE_FLOW,
    TEMPERATURE_VARIATION,
    SENSOR_NOISE,
    PULSE_JITTER,
    METER_DRIFT,
    SENSOR_FAILURE,
    COMMUNICATION_FAILURE,
    TRANSACTION_CANCELLATION,
]
