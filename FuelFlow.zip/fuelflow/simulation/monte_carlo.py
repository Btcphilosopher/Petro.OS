"""
simulation.monte_carlo
=========================

Runs many simulated transactions across scenarios and aggregates
accuracy statistics (mean error, maximum error, bias, repeatability,
standard deviation, uncertainty, rounding error), per FuelFlow section 15.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from typing import List, Sequence

from fuelflow.analytics.accuracy import AccuracyReport, compute_accuracy, compute_rounding_error_stats
from fuelflow.core.configuration import MeterConfig, RegionPricingConfig
from fuelflow.core.state_machine import TransactionState
from fuelflow.metrology.calibration import CalibrationState
from fuelflow.simulation.dispenser_simulator import SimulationResult, run_transaction
from fuelflow.simulation.scenarios import Scenario


@dataclass
class MonteCarloResult:
    n_requested: int
    n_completed: int
    n_faulted: int
    n_cancelled: int
    volume_accuracy: AccuracyReport
    monetary_rounding_accuracy: AccuracyReport
    n_incomplete: int = 0  # ran to the simulator's tick cap without reaching COMPLETED (should be rare/zero)
    fault_reasons: List[str] = field(default_factory=list)
    results: List[SimulationResult] = field(default_factory=list)


def run_monte_carlo(
    meter_config: MeterConfig,
    calibration_state: CalibrationState,
    fuel_code: str,
    unit_price: Decimal,
    region: RegionPricingConfig,
    target_amount: Decimal,
    scenarios: Sequence[Scenario],
    n_per_scenario: int = 50,
    base_seed: int = 1000,
    as_of_date: date | None = None,
) -> MonteCarloResult:
    """
    Run `n_per_scenario` transactions for each scenario (deterministically
    seeded so the whole run is reproducible) and aggregate accuracy
    statistics across every completed transaction.
    """
    results: List[SimulationResult] = []
    seed_counter = base_seed

    for scenario in scenarios:
        for _ in range(n_per_scenario):
            result = run_transaction(
                meter_config=meter_config,
                calibration_state=calibration_state,
                fuel_code=fuel_code,
                unit_price=unit_price,
                region=region,
                target_amount=target_amount,
                scenario=scenario,
                seed=seed_counter,
                as_of_date=as_of_date,
            )
            results.append(result)
            seed_counter += 1

    def _is_completed(r: SimulationResult) -> bool:
        return (
            not r.faulted
            and not r.cancelled
            and r.transaction is not None
            and r.transaction.state_machine.state == TransactionState.COMPLETED
        )

    completed = [r for r in results if _is_completed(r)]
    faulted = [r for r in results if r.faulted]
    cancelled = [r for r in results if r.cancelled]
    incomplete = [r for r in results if not r.faulted and not r.cancelled and not _is_completed(r)]

    if completed:
        volume_accuracy = compute_accuracy(
            [r.true_reference_volume for r in completed],
            [r.measured_volume for r in completed],
        )
        monetary_rounding_accuracy = compute_rounding_error_stats(
            [r.true_reference_value for r in completed],
            [r.final_charge for r in completed],
        )
    else:
        volume_accuracy = compute_accuracy([0.0], [0.0])
        monetary_rounding_accuracy = compute_accuracy([0.0], [0.0])

    return MonteCarloResult(
        n_requested=len(results),
        n_completed=len(completed),
        n_faulted=len(faulted),
        n_cancelled=len(cancelled),
        n_incomplete=len(incomplete),
        volume_accuracy=volume_accuracy,
        monetary_rounding_accuracy=monetary_rounding_accuracy,
        fault_reasons=[r.fault_reason for r in faulted],
        results=results,
    )
