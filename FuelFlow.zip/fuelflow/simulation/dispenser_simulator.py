"""
simulation.dispenser_simulator
=================================

Deterministic (given a seed) end-to-end transaction simulator: drives a
real :class:`fuelflow.core.engine.FuelFlowEngine` from a synthetic pulse
stream generated from a :class:`~fuelflow.simulation.scenarios.Scenario`,
exercising the exact same code path a physical meter's acquisition
front-end would drive.

Because the simulator also knows the *ideal*, noise-free commanded flow
profile, it can report a ground-truth reference volume alongside
FuelFlow's own measured/reconciled volume -- which is what makes the
Monte-Carlo accuracy analysis in `monte_carlo.py` possible.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from typing import Optional

from fuelflow.core.clock import SimulatedClock
from fuelflow.core.configuration import MeterConfig, RegionPricingConfig
from fuelflow.core.engine import FuelFlowEngine
from fuelflow.core.state_machine import TransactionState
from fuelflow.dispensing.dispenser import Dispenser, DispenserFault
from fuelflow.dispensing.nozzle import Nozzle
from fuelflow.dispensing.transaction import Transaction
from fuelflow.fuel.fuel_types import FuelTypeRegistry
from fuelflow.metrology.calibration import CalibrationState
from fuelflow.metrology.flow_meter import FlowMeter, MeterTechnology
from fuelflow.metrology.pulse_counter import pulses_from_flow_rate
from fuelflow.payment.terminal import MockPaymentTerminal, PaymentMethod
from fuelflow.pricing.price_engine import FuelPrice, PriceEngine, VolumeUnit
from fuelflow.simulation.scenarios import FlowProfileShape, Scenario


@dataclass
class SimulationResult:
    scenario_name: str
    transaction: Optional[Transaction]
    faulted: bool
    fault_reason: str = ""
    cancelled: bool = False
    true_reference_volume: float = 0.0  # ideal, noise-free commanded volume
    measured_volume: float = 0.0  # FuelFlow's own delivered volume
    true_reference_value: Decimal = Decimal("0.00")
    final_charge: Decimal = Decimal("0.00")
    dispense_duration_s: float = 0.0


def _build_engine(
    meter_config: MeterConfig,
    calibration_state: CalibrationState,
    fuel_code: str,
    unit_price: Decimal,
    region: RegionPricingConfig,
    approach_threshold_fraction: Decimal = Decimal("0.90"),
) -> tuple[FuelFlowEngine, str]:
    meter = FlowMeter(
        meter_id=meter_config.meter_id,
        technology=MeterTechnology.POSITIVE_DISPLACEMENT,
        pulses_per_unit_volume=meter_config.pulses_per_unit_volume,
        calibration_factor=meter_config.nominal_calibration_factor,
        maximum_flow_rate=meter_config.maximum_flow_rate,
        minimum_flow_rate=meter_config.minimum_flow_rate,
        volume_unit=meter_config.volume_unit,
        serial_number=meter_config.serial_number,
    )
    price_engine = PriceEngine(region=region)
    price_engine.set_price(
        FuelPrice(
            fuel_code=fuel_code,
            unit_price=unit_price,
            unit=VolumeUnit.GALLON if meter_config.volume_unit == "gal" else VolumeUnit.LITRE,
            currency=region.currency,
        )
    )
    dispenser = Dispenser(
        dispenser_id="SIM-01",
        meter=meter,
        calibration_state=calibration_state,
        price_engine=price_engine,
        fuel_registry=FuelTypeRegistry(),
        nozzle=Nozzle(nozzle_id="SIM-N1"),
        approach_threshold_fraction=approach_threshold_fraction,
    )
    clock = SimulatedClock()
    engine = FuelFlowEngine(payment_terminal=MockPaymentTerminal(), clock=clock)
    engine.register_dispenser(dispenser, fuel_display_name=fuel_code)
    return engine, dispenser.dispenser_id


def _flow_rate_at(scenario: Scenario, t: float, duration_estimate: float) -> float:
    if scenario.flow_profile == FlowProfileShape.CONSTANT:
        return scenario.nominal_flow_rate

    if scenario.flow_profile == FlowProfileShape.RAMP_UP_DOWN:
        # Ramp up from zero, then hold at the nominal rate. The ramp-*down*
        # towards the target is driven by the dispenser's own reported
        # TARGET_APPROACH state in `run_transaction` below (a fixed-time
        # ramp-down estimated in advance would either finish early -- and
        # sit at zero flow forever if the estimate was optimistic -- or
        # overshoot; reacting to the real measured state is both more
        # realistic and always converges).
        ramp = min(duration_estimate * 0.15, 3.0)
        if t < ramp:
            return scenario.nominal_flow_rate * (t / ramp)
        return scenario.nominal_flow_rate

    # VARIABLE: nominal rate modulated by a slow sinusoid, floor-clamped
    modulation = 0.5 + 0.5 * math.sin(t / 3.0)
    return max(scenario.nominal_flow_rate * modulation, scenario.nominal_flow_rate * 0.15)


def run_transaction(
    meter_config: MeterConfig,
    calibration_state: CalibrationState,
    fuel_code: str,
    unit_price: Decimal,
    region: RegionPricingConfig,
    target_amount: Decimal,
    scenario: Scenario,
    seed: Optional[int] = None,
    as_of_date: Optional[date] = None,
    approach_threshold_fraction: Decimal = Decimal("0.90"),
) -> SimulationResult:
    """Run one full simulated transaction under a given scenario."""
    rng = random.Random(seed)
    as_of_date = as_of_date or date.today()

    engine, dispenser_id = _build_engine(
        meter_config, calibration_state, fuel_code, unit_price, region, approach_threshold_fraction
    )

    txn = engine.start_transaction(dispenser_id, target_amount, fuel_code, PaymentMethod.AARDVARK_TOKEN, as_of_date)

    duration_estimate = max(60.0 * float(target_amount / unit_price) / scenario.nominal_flow_rate, 5.0)
    max_ticks = int(duration_estimate / scenario.dt_s * 3) + 200

    ideal_volume = 0.0
    tick_count = 0
    cancelled = False
    approaching_target = False

    try:
        while True:
            tick_count += 1
            if tick_count > max_ticks:
                break

            t = engine.clock.now()
            if approaching_target:
                # Creep flow for an accurate stop, per the real target-value
                # controller's behaviour once TARGET_APPROACH is reported.
                flow_rate = meter_config.minimum_flow_rate
            else:
                flow_rate = _flow_rate_at(scenario, t, duration_estimate)

            ideal_pulses = pulses_from_flow_rate(flow_rate, scenario.dt_s, meter_config.pulses_per_unit_volume)
            ideal_volume += flow_rate * (scenario.dt_s / 60.0)

            jitter = 1.0
            if scenario.pulse_jitter_std_fraction > 0:
                jitter = max(1.0 + rng.gauss(0.0, scenario.pulse_jitter_std_fraction), 0.0)
            raw_pulses = ideal_pulses * jitter

            temperature_c = scenario.temperature_c
            if scenario.temperature_variation_amplitude_c:
                temperature_c += scenario.temperature_variation_amplitude_c * math.sin(t / 20.0)
            if scenario.sensor_noise_std_c:
                temperature_c += rng.gauss(0.0, scenario.sensor_noise_std_c)

            meter_status_ok = rng.random() >= scenario.sensor_failure_probability
            communication_ok = rng.random() >= scenario.communication_failure_probability

            engine.clock.tick(scenario.dt_s)  # type: ignore[union-attr]

            if (
                scenario.cancel_after_fraction is not None
                and not cancelled
                and Decimal(str(ideal_volume)) >= txn.target.calculated_target_volume * Decimal(str(scenario.cancel_after_fraction))
            ):
                engine.cancel_transaction(dispenser_id, reason="scenario: transaction_cancellation")
                cancelled = True
                break

            snapshot = engine.step(
                dispenser_id,
                raw_pulses_in_tick=raw_pulses,
                dt_s=scenario.dt_s,
                temperature_c=temperature_c,
                density_kg_per_l=0.745,
                as_of_date=as_of_date,
                meter_status_ok=meter_status_ok,
                communication_ok=communication_ok,
            )

            if snapshot.state == TransactionState.TARGET_APPROACH:
                approaching_target = True

            if snapshot.state in (TransactionState.COMPLETED, TransactionState.CANCELLED, TransactionState.FAULT):
                break

    except DispenserFault as exc:
        return SimulationResult(
            scenario_name=scenario.name,
            transaction=engine.dispensers[dispenser_id].current_transaction,
            faulted=True,
            fault_reason=str(exc),
            true_reference_volume=ideal_volume,
        )

    final_txn = engine.dispensers[dispenser_id].current_transaction
    measured_volume = final_txn.actual_delivered_volume if final_txn else 0.0
    final_charge = final_txn.final_value.final_charge if final_txn and final_txn.final_value else Decimal("0.00")
    duration_s = final_txn.measurements[-1].timestamp if final_txn and final_txn.measurements else 0.0

    return SimulationResult(
        scenario_name=scenario.name,
        transaction=final_txn,
        faulted=False,
        cancelled=cancelled,
        true_reference_volume=ideal_volume,
        measured_volume=measured_volume,
        true_reference_value=(Decimal(str(round(ideal_volume, 6))) * unit_price),
        final_charge=final_charge,
        dispense_duration_s=duration_s,
    )
