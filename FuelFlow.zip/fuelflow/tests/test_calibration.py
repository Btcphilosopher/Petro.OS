from datetime import date

from fuelflow.calibration.calibration_history import CalibrationHistory
from fuelflow.calibration.calibration_record import CalibrationRecord
from fuelflow.calibration.calibration_test import run_calibration_test
from fuelflow.metrology.calibration import CalibrationState, CalibrationValidity, apply_calibration


def test_in_date_calibration_is_valid():
    state = CalibrationState(
        meter_id="M1",
        nominal_calibration_factor=1.0,
        actual_calibration_factor=1.001,
        calibration_date=date(2026, 1, 1),
        calibration_interval_days=365,
    )
    assert state.validity(date(2026, 6, 1)) == CalibrationValidity.IN_DATE
    assert state.is_fully_valid(date(2026, 6, 1))


def test_overdue_calibration_is_never_reported_fully_valid():
    state = CalibrationState(
        meter_id="M1",
        nominal_calibration_factor=1.0,
        actual_calibration_factor=1.001,
        calibration_date=date(2024, 1, 1),
        calibration_interval_days=365,
    )
    as_of = date(2026, 1, 1)
    assert state.validity(as_of) == CalibrationValidity.OVERDUE
    assert not state.is_fully_valid(as_of)


def test_calibration_factor_is_never_assumed_perfect():
    state = CalibrationState(
        meter_id="M1", nominal_calibration_factor=1.0, actual_calibration_factor=0.997, calibration_date=date(2026, 1, 1)
    )
    corrected = apply_calibration(raw_volume=100.0, calibration_state=state, as_of=date(2026, 1, 1))
    assert corrected == 100.0 * 0.997
    assert corrected != 100.0


def test_drift_accumulates_over_time():
    state = CalibrationState(
        meter_id="M1",
        nominal_calibration_factor=1.0,
        actual_calibration_factor=1.0,
        calibration_date=date(2026, 1, 1),
        meter_drift_per_day=0.0001,
    )
    factor_day_0 = state.effective_calibration_factor(date(2026, 1, 1))
    factor_day_100 = state.effective_calibration_factor(date(2026, 4, 11))
    assert factor_day_100 > factor_day_0


def test_calibration_test_derives_correction_factor():
    result = run_calibration_test("M1", reference_volume=20.0, meter_reported_volume=19.95, test_date=date(2026, 1, 1))
    assert abs(result.derived_calibration_factor - (20.0 / 19.95)) < 1e-9
    assert result.passed  # 0.25% error is well within the default 0.5% tolerance
    assert abs(result.relative_error) > 0


def test_calibration_test_fails_outside_tolerance():
    result = run_calibration_test("M1", reference_volume=20.0, meter_reported_volume=19.5, test_date=date(2026, 1, 1))
    assert not result.passed  # 2.5% error exceeds the default 0.5% tolerance


def test_calibration_history_builds_live_state():
    history = CalibrationHistory(meter_id="M1")
    history.add(
        CalibrationRecord(
            meter_id="M1",
            serial_number="SN-1",
            calibration_factor=1.0008,
            calibration_date=date(2026, 1, 1),
            reference_standard="20 gal certified prover",
            uncertainty=0.0015,
            technician="J. Rivera",
        )
    )
    live_state = history.to_live_state(nominal_calibration_factor=1.0)
    assert live_state.actual_calibration_factor == 1.0008
    assert not history.is_overdue(date(2026, 6, 1))
    assert history.is_overdue(date(2028, 1, 1))
