from fuelflow.core.configuration import DEFAULT_FUEL_TYPES
from fuelflow.fuel.density import density_at_temperature
from fuelflow.fuel.temperature import TemperatureCompensator


def test_reference_temperature_yields_no_correction():
    compensator = TemperatureCompensator()
    fuel = DEFAULT_FUEL_TYPES["PETROL_95"]
    result = compensator.compensate(observed_volume=10.0, observed_temperature_c=fuel.reference_temperature_c, fuel=fuel)
    assert abs(result.volume_correction_factor - 1.0) < 1e-9
    assert abs(result.reference_volume - 10.0) < 1e-9


def test_warmer_fuel_has_smaller_reference_volume():
    compensator = TemperatureCompensator()
    fuel = DEFAULT_FUEL_TYPES["PETROL_95"]
    warm_result = compensator.compensate(observed_volume=10.0, observed_temperature_c=30.0, fuel=fuel)
    # Warmer fuel has expanded, so the same observed volume corresponds to
    # *less* fuel at the cooler reference temperature.
    assert warm_result.reference_volume < 10.0


def test_diesel_and_petrol_have_different_coefficients():
    petrol = DEFAULT_FUEL_TYPES["PETROL_95"]
    diesel = DEFAULT_FUEL_TYPES["DIESEL"]
    assert petrol.thermal_expansion_coefficient_per_degc != diesel.thermal_expansion_coefficient_per_degc


def test_density_decreases_as_temperature_rises():
    fuel = DEFAULT_FUEL_TYPES["PETROL_95"]
    cold_density = density_at_temperature(fuel, 5.0)
    hot_density = density_at_temperature(fuel, 35.0)
    assert hot_density < cold_density
