import pytest

from fuelflow.core.state_machine import IllegalTransitionError, StateMachine, TransactionState


def test_happy_path_lifecycle():
    sm = StateMachine()
    sequence = [
        TransactionState.AUTHORISED,
        TransactionState.NOZZLE_LIFTED,
        TransactionState.DISPENSING,
        TransactionState.TARGET_APPROACH,
        TransactionState.TARGET_REACHED,
        TransactionState.FINALISING,
        TransactionState.COMPLETED,
    ]
    for i, state in enumerate(sequence):
        sm.transition(state, timestamp=float(i))
    assert sm.state == TransactionState.COMPLETED
    assert sm.is_terminal()
    assert len(sm.history) == len(sequence)


def test_illegal_transition_is_rejected():
    sm = StateMachine()
    with pytest.raises(IllegalTransitionError):
        sm.transition(TransactionState.DISPENSING, timestamp=0.0)


def test_cancellation_reachable_from_in_progress_states():
    sm = StateMachine()
    sm.transition(TransactionState.AUTHORISED, timestamp=0.0)
    sm.transition(TransactionState.NOZZLE_LIFTED, timestamp=1.0)
    sm.transition(TransactionState.CANCELLED, timestamp=2.0, reason="customer walked away")
    assert sm.state == TransactionState.CANCELLED
    assert sm.is_terminal()


def test_completed_state_has_no_further_transitions():
    sm = StateMachine(state=TransactionState.COMPLETED)
    assert not sm.can_transition(TransactionState.IDLE)
