from decimal import Decimal

from fuelflow.core.configuration import DEFAULT_CURRENCIES
from fuelflow.dispensing.target_value import TargetValueEngine
from fuelflow.pricing.price_engine import FuelPrice, VolumeUnit


def _price(unit_price: str) -> FuelPrice:
    return FuelPrice(
        fuel_code="PETROL_95",
        unit_price=Decimal(unit_price),
        unit=VolumeUnit.GALLON,
        currency=DEFAULT_CURRENCIES["USD"],
    )


def test_ten_dollars_at_3_499_is_about_2_858_gallons():
    engine = TargetValueEngine()
    result = engine.target_for_amount(Decimal("10.00"), _price("3.499"))
    assert abs(result.calculated_target_volume - Decimal("2.858")) < Decimal("0.001")


def test_target_volume_distinct_from_requested_amount():
    engine = TargetValueEngine()
    result = engine.target_for_amount(Decimal("20.00"), _price("3.499"))
    assert result.requested_monetary_value == Decimal("20.00")
    assert result.calculated_target_volume != result.requested_monetary_value


def test_rejects_non_positive_amount():
    engine = TargetValueEngine()
    try:
        engine.target_for_amount(Decimal("0.00"), _price("3.499"))
        assert False, "expected ValueError"
    except ValueError:
        pass


def test_preset_amount_must_be_configured():
    engine = TargetValueEngine()
    try:
        engine.target_for_preset(Decimal("7.00"), _price("3.499"))
        assert False, "expected ValueError"
    except ValueError:
        pass
