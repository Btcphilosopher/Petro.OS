from datetime import date

from fuelflow.metrology.calibration import CalibrationState
from fuelflow.metrology.flow_meter import FlowMeter, MeterTechnology
from fuelflow.metrology.pulse_counter import pulses_from_flow_rate
from fuelflow.metrology.volume_engine import VolumeEngine


def _engine(calibration_factor: float = 1.0) -> VolumeEngine:
    meter = FlowMeter(meter_id="M1", technology=MeterTechnology.POSITIVE_DISPLACEMENT, pulses_per_unit_volume=1000.0)
    calibration_state = CalibrationState(
        meter_id="M1",
        nominal_calibration_factor=1.0,
        actual_calibration_factor=calibration_factor,
        calibration_date=date(2026, 1, 1),
    )
    return VolumeEngine(meter=meter, calibration_state=calibration_state)


def test_accumulated_volume_matches_pulses_over_many_ticks():
    engine = _engine()
    flow_rate = 6.0  # gal/min
    dt_s = 1.0
    n_ticks = 60  # exactly one minute
    for i in range(n_ticks):
        pulses = pulses_from_flow_rate(flow_rate, dt_s, 1000.0)
        engine.process_tick(
            timestamp=float(i), raw_pulses_in_tick=pulses, dt_s=dt_s, temperature_c=15.0, density_kg_per_l=0.745
        )
    assert abs(engine.accumulated_calibrated_volume - flow_rate) < 1e-6


def test_calibration_factor_scales_accumulated_volume():
    engine_nominal = _engine(calibration_factor=1.0)
    engine_biased = _engine(calibration_factor=1.02)

    for i in range(10):
        pulses = pulses_from_flow_rate(6.0, 1.0, 1000.0)
        engine_nominal.process_tick(timestamp=float(i), raw_pulses_in_tick=pulses, dt_s=1.0, temperature_c=15.0, density_kg_per_l=0.745)
        engine_biased.process_tick(timestamp=float(i), raw_pulses_in_tick=pulses, dt_s=1.0, temperature_c=15.0, density_kg_per_l=0.745)

    ratio = engine_biased.accumulated_calibrated_volume / engine_nominal.accumulated_calibrated_volume
    assert abs(ratio - 1.02) < 1e-9


def test_measurement_is_fully_traceable():
    engine = _engine()
    pulses = pulses_from_flow_rate(6.0, 1.0, 1000.0)
    measurement = engine.process_tick(timestamp=0.0, raw_pulses_in_tick=pulses, dt_s=1.0, temperature_c=15.0, density_kg_per_l=0.745)

    assert measurement.raw_volume is not None
    assert measurement.calibrated_volume is not None
    assert measurement.calibration_factor_applied is not None
    assert measurement.filtered_pulses is not None
