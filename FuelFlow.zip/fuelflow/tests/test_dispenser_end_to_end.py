from datetime import date
from decimal import Decimal

from fuelflow.core.clock import SimulatedClock
from fuelflow.core.configuration import DEFAULT_CURRENCIES, RegionPricingConfig, default_meter
from fuelflow.core.engine import FuelFlowEngine
from fuelflow.core.state_machine import TransactionState
from fuelflow.dispensing.dispenser import Dispenser
from fuelflow.dispensing.nozzle import Nozzle
from fuelflow.digital_twin.dispenser_twin import FuelDispenserDigitalTwin
from fuelflow.fuel.fuel_types import FuelTypeRegistry
from fuelflow.metrology.calibration import CalibrationState
from fuelflow.metrology.flow_meter import FlowMeter, MeterTechnology
from fuelflow.metrology.pulse_counter import pulses_from_flow_rate
from fuelflow.payment.terminal import MockPaymentTerminal, PaymentMethod
from fuelflow.pricing.price_engine import FuelPrice, PriceEngine, VolumeUnit


def _build_engine() -> tuple[FuelFlowEngine, str]:
    meter_config = default_meter("MTR-04-A")
    meter = FlowMeter(
        meter_id=meter_config.meter_id,
        technology=MeterTechnology.POSITIVE_DISPLACEMENT,
        pulses_per_unit_volume=meter_config.pulses_per_unit_volume,
        calibration_factor=1.0,
        maximum_flow_rate=meter_config.maximum_flow_rate,
        minimum_flow_rate=meter_config.minimum_flow_rate,
        volume_unit=meter_config.volume_unit,
    )
    calibration_state = CalibrationState(
        meter_id=meter.meter_id, nominal_calibration_factor=1.0, actual_calibration_factor=1.0, calibration_date=date(2026, 1, 1)
    )
    region = RegionPricingConfig(region_code="US-DEFAULT", currency=DEFAULT_CURRENCIES["USD"], tax_rate=Decimal("0.00"))
    price_engine = PriceEngine(region=region)
    price_engine.set_price(FuelPrice(fuel_code="PETROL_95", unit_price=Decimal("3.499"), unit=VolumeUnit.GALLON, currency=region.currency))

    dispenser = Dispenser(
        dispenser_id="D-TEST",
        meter=meter,
        calibration_state=calibration_state,
        price_engine=price_engine,
        fuel_registry=FuelTypeRegistry(),
        nozzle=Nozzle(nozzle_id="N-TEST"),
    )
    engine = FuelFlowEngine(payment_terminal=MockPaymentTerminal(), clock=SimulatedClock())
    engine.register_dispenser(dispenser, fuel_display_name="Petrol 95")
    return engine, dispenser.dispenser_id


def test_ten_dollar_transaction_ends_at_target_charge():
    """
    Full flow -> calibration -> volume -> price -> target-value-controller
    -> reconciliation pipeline for FuelFlow's worked $10.00 example. A real
    target-value controller throttles flow down to a fine "creep" rate as
    it approaches the target for an accurate stop; this test mirrors that
    by reducing the commanded flow rate once the dispenser reports
    TARGET_APPROACH, so the simulated crossing tick is small enough that
    the final charge lands within a cent of the requested amount.
    """
    engine, dispenser_id = _build_engine()
    txn = engine.start_transaction(dispenser_id, Decimal("10.00"), "PETROL_95", PaymentMethod.NFC, date(2026, 1, 1))

    dt_s = 0.05
    meter = engine.dispensers[dispenser_id].meter
    flow_rate = 8.4

    for _ in range(50000):
        pulses = pulses_from_flow_rate(flow_rate, dt_s, meter.pulses_per_unit_volume)
        engine.clock.tick(dt_s)
        snapshot = engine.step(dispenser_id, pulses, dt_s, temperature_c=18.4, density_kg_per_l=0.745, as_of_date=date(2026, 1, 1))
        if snapshot.state == TransactionState.TARGET_APPROACH:
            flow_rate = meter.minimum_flow_rate  # creep flow for an accurate stop
        if snapshot.state in (TransactionState.COMPLETED, TransactionState.CANCELLED, TransactionState.FAULT):
            break

    assert txn.state_machine.state == TransactionState.COMPLETED
    assert txn.final_value is not None
    assert Decimal("10.00") <= txn.final_value.final_charge <= Decimal("10.01")
    assert abs(txn.actual_delivered_volume - 2.858) < 0.01
    assert txn.payment_captured


def test_digital_twin_mirrors_engine_state():
    engine, dispenser_id = _build_engine()
    engine.start_transaction(dispenser_id, Decimal("5.00"), "PETROL_95", PaymentMethod.NFC, date(2026, 1, 1))
    meter = engine.dispensers[dispenser_id].meter

    pulses = pulses_from_flow_rate(6.0, 0.1, meter.pulses_per_unit_volume)
    engine.clock.tick(0.1)
    snapshot = engine.step(dispenser_id, pulses, 0.1, temperature_c=20.0, density_kg_per_l=0.745, as_of_date=date(2026, 1, 1))

    twin = engine.twins[dispenser_id]
    assert twin.meter.accumulated_volume == snapshot.accumulated_volume
    assert twin.transaction.state == snapshot.state


def test_cancellation_leaves_transaction_in_cancelled_state():
    engine, dispenser_id = _build_engine()
    engine.start_transaction(dispenser_id, Decimal("5.00"), "PETROL_95", PaymentMethod.NFC, date(2026, 1, 1))
    txn = engine.cancel_transaction(dispenser_id, reason="test cancellation")
    assert txn.state_machine.state == TransactionState.CANCELLED
    assert txn.cancellation_reason == "test cancellation"
