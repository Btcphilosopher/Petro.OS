from decimal import Decimal

from fuelflow.core.configuration import DEFAULT_CURRENCIES, RegionPricingConfig
from fuelflow.pricing.currency import round_to_currency
from fuelflow.pricing.price_engine import FuelPrice, PriceEngine, VolumeUnit
from fuelflow.pricing.transaction_value import reconcile_transaction_value


def _engine() -> PriceEngine:
    region = RegionPricingConfig(
        region_code="US-DEFAULT", currency=DEFAULT_CURRENCIES["USD"], tax_rate=Decimal("0.00"), tax_included_in_price=True
    )
    engine = PriceEngine(region=region)
    engine.set_price(FuelPrice(fuel_code="PETROL_95", unit_price=Decimal("3.499"), unit=VolumeUnit.GALLON, currency=region.currency))
    return engine


def test_gross_value_uses_decimal_exactly():
    engine = _engine()
    value = engine.gross_value_for_volume("PETROL_95", Decimal("2.858"), VolumeUnit.GALLON)
    assert value == Decimal("2.858") * Decimal("3.499")


def test_rounding_is_explicit_and_documented():
    price = FuelPrice(fuel_code="PETROL_95", unit_price=Decimal("3.499"), unit=VolumeUnit.GALLON, currency=DEFAULT_CURRENCIES["USD"])
    txn_value = reconcile_transaction_value(price, Decimal("2.858"), tax_component=Decimal("0.00"))

    assert txn_value.gross_value_exact == Decimal("2.858") * Decimal("3.499")
    assert txn_value.final_charge == round_to_currency(txn_value.gross_value_exact, price.currency)
    assert txn_value.rounding_adjustment == txn_value.final_charge - txn_value.gross_value_exact
    # The example from FuelFlow section 8: exact value is a fraction of a cent away from $10, final charge rounds to $10.00
    assert txn_value.final_charge == Decimal("10.00")


def test_unit_conversion_gallons_to_litres_roundtrips():
    from fuelflow.pricing.price_engine import to_gallons, to_litres

    gallons = Decimal("10")
    litres = to_litres(gallons, VolumeUnit.GALLON)
    back = to_gallons(litres, VolumeUnit.LITRE)
    assert abs(back - gallons) < Decimal("0.0000001")
