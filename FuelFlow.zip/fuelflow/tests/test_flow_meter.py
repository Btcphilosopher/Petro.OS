from fuelflow.metrology.flow_meter import (
    CoriolisMeter,
    FlowMeter,
    MeterTechnology,
    PositiveDisplacementMeter,
    TurbineMeter,
)


def test_volume_for_pulses_is_pulses_over_ppuv():
    meter = FlowMeter(meter_id="M1", technology=MeterTechnology.PULSE_OUTPUT, pulses_per_unit_volume=1000.0)
    assert meter.volume_for_pulses(2858.0) == 2.858


def test_corrected_volume_applies_calibration_factor():
    meter = FlowMeter(
        meter_id="M1", technology=MeterTechnology.PULSE_OUTPUT, pulses_per_unit_volume=1000.0, calibration_factor=1.01
    )
    assert meter.corrected_volume(1000.0) == 1.0 * 1.01


def test_operating_range_check():
    meter = FlowMeter(
        meter_id="M1",
        technology=MeterTechnology.PULSE_OUTPUT,
        pulses_per_unit_volume=1000.0,
        minimum_flow_rate=0.3,
        maximum_flow_rate=12.0,
    )
    assert meter.is_within_operating_range(6.0)
    assert not meter.is_within_operating_range(0.1)
    assert not meter.is_within_operating_range(15.0)


def test_positive_displacement_meter_defaults():
    meter = PositiveDisplacementMeter(meter_id="M1", pulses_per_unit_volume=1000.0)
    assert meter.technology == MeterTechnology.POSITIVE_DISPLACEMENT


def test_turbine_meter_has_higher_minimum_flow():
    turbine = TurbineMeter(meter_id="M2", pulses_per_unit_volume=500.0)
    assert turbine.technology == MeterTechnology.TURBINE
    assert turbine.minimum_flow_rate == 1.0


def test_coriolis_meter_uses_density_to_derive_volume():
    meter = CoriolisMeter(meter_id="M3", pulses_per_unit_volume=1000.0, density_kg_per_l=0.75)
    mass_pulses = 750.0  # 0.75 kg worth of "pulses" at pulses_per_unit_volume=1000
    volume = meter.volume_for_pulses(mass_pulses)
    assert abs(volume - (0.75 / 0.75)) < 1e-9
