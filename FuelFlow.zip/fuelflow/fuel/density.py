"""
fuel.density
=============

Temperature-dependent density model for a configured fuel grade, used
both by Coriolis-style mass-flow meters (which need density to derive
volume) and for cross-checking volumetric measurements.
"""

from __future__ import annotations

from fuelflow.core.configuration import FuelTypeConfig


def density_at_temperature(fuel: FuelTypeConfig, temperature_c: float) -> float:
    """
    First-order volumetric approximation:

        density(T) = density(Tref) / (1 + alpha * (T - Tref))

    consistent with the volumetric expansion model used in
    :mod:`fuelflow.fuel.temperature`. `alpha` is the fuel's configured
    thermal expansion coefficient, never a universal constant.
    """
    delta_t = temperature_c - fuel.reference_temperature_c
    return fuel.density_at_15c_kg_per_l / (1.0 + fuel.thermal_expansion_coefficient_per_degc * delta_t)
