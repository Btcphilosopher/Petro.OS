"""
fuel.temperature
==================

Volume Correction Factor (VCF) / temperature compensation, per FuelFlow
section 5.

    observed volume -> temperature -> fuel expansion model
        -> reference-temperature volume

Coefficients are always sourced from the fuel's configuration, never
hard-coded as a universal constant -- petrol, diesel and ethanol blends
expand at different rates.
"""

from __future__ import annotations

from dataclasses import dataclass

from fuelflow.core.configuration import FuelTypeConfig


@dataclass(frozen=True)
class TemperatureCompensationResult:
    observed_volume: float
    observed_temperature_c: float
    reference_temperature_c: float
    volume_correction_factor: float
    reference_volume: float


class TemperatureCompensator:
    """
    Applies a first-order volumetric thermal expansion model:

        VCF = 1 / (1 + alpha * (T_observed - T_reference))

    so that:

        reference_volume = observed_volume * VCF

    This is the same functional form used by API MPMS Chapter 11.1 /
    ASTM D1250-style VCF tables at small (alpha * dT << 1) deviations;
    a production system handling large temperature excursions should
    substitute the full standard table lookup for `alpha`.
    """

    def compensate(self, observed_volume: float, observed_temperature_c: float, fuel: FuelTypeConfig) -> TemperatureCompensationResult:
        delta_t = observed_temperature_c - fuel.reference_temperature_c
        vcf = 1.0 / (1.0 + fuel.thermal_expansion_coefficient_per_degc * delta_t)
        reference_volume = observed_volume * vcf
        return TemperatureCompensationResult(
            observed_volume=observed_volume,
            observed_temperature_c=observed_temperature_c,
            reference_temperature_c=fuel.reference_temperature_c,
            volume_correction_factor=vcf,
            reference_volume=reference_volume,
        )
