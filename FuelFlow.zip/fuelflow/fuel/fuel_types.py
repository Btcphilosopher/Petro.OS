"""
fuel.fuel_types
=================

Thin runtime wrapper around :class:`fuelflow.core.configuration.FuelTypeConfig`
so fuel-type lookups read naturally from the rest of the dispensing code,
while the actual coefficients stay data (configuration), never hard-coded
constants scattered through business logic.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict

from fuelflow.core.configuration import DEFAULT_FUEL_TYPES, FuelTypeConfig


@dataclass(frozen=True)
class FuelGrade:
    config: FuelTypeConfig

    @property
    def code(self) -> str:
        return self.config.code

    @property
    def display_name(self) -> str:
        return self.config.display_name


class FuelTypeRegistry:
    """Lookup table of configured fuel grades for a given deployment."""

    def __init__(self, fuel_types: Dict[str, FuelTypeConfig] | None = None):
        self._types = dict(fuel_types or DEFAULT_FUEL_TYPES)

    def get(self, code: str) -> FuelGrade:
        try:
            return FuelGrade(self._types[code])
        except KeyError as exc:
            raise KeyError(f"Unknown/unconfigured fuel type: {code!r}") from exc

    def register(self, config: FuelTypeConfig) -> None:
        self._types[config.code] = config

    def codes(self) -> list[str]:
        return list(self._types.keys())
