"""
sensors.temperature_sensor
============================

Concrete temperature sensor with sane physical bounds checking.
"""

from __future__ import annotations

from dataclasses import dataclass

from fuelflow.sensors.sensor import Sensor, SensorReading


@dataclass
class TemperatureSensor(Sensor):
    min_plausible_c: float = -40.0
    max_plausible_c: float = 70.0

    def read(self, timestamp: float, true_value: float) -> SensorReading:
        reading = super().read(timestamp, true_value)
        if reading.valid and reading.value is not None:
            if not (self.min_plausible_c <= reading.value <= self.max_plausible_c):
                return SensorReading(timestamp=timestamp, value=reading.value, valid=False)
        return reading
