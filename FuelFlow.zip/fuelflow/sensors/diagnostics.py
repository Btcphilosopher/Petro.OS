"""
sensors.diagnostics
=====================

Aggregates validator findings across a dispenser's sensor set into one
overall system diagnostic, and keeps a short rolling history so
transient WARNING states can be distinguished from persistent ones that
should escalate towards SERVICE_REQUIRED.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Deque, List

from fuelflow.metrology.validation import DiagnosticState, ValidationFinding, _SEVERITY_ORDER


@dataclass
class DiagnosticsEngine:
    history_len: int = 50
    escalate_after_n_warnings: int = 10

    _recent_states: Deque[DiagnosticState] = field(default_factory=deque)

    def record(self, findings: List[ValidationFinding]) -> DiagnosticState:
        worst = DiagnosticState.NORMAL
        for f in findings:
            if _SEVERITY_ORDER.index(f.state) > _SEVERITY_ORDER.index(worst):
                worst = f.state

        self._recent_states.append(worst)
        while len(self._recent_states) > self.history_len:
            self._recent_states.popleft()

        # Persistent WARNING-level findings are promoted to DEGRADED --
        # a single blip is tolerated, a sustained pattern is not.
        recent_warning_count = sum(1 for s in self._recent_states if s == DiagnosticState.WARNING)
        if worst == DiagnosticState.WARNING and recent_warning_count >= self.escalate_after_n_warnings:
            return DiagnosticState.DEGRADED
        return worst

    def reset(self) -> None:
        self._recent_states.clear()
