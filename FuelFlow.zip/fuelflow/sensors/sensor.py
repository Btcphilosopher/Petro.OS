"""
sensors.sensor
================

Generic sensor abstraction with an injectable noise/dropout model, used
by the simulator to exercise the validation layer realistically.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Optional


@dataclass(frozen=True)
class SensorReading:
    timestamp: float
    value: Optional[float]  # None represents a dropout (no reading available)
    valid: bool


@dataclass
class Sensor:
    """
    Base sensor: wraps a "true" underlying process value with configurable
    Gaussian noise and an independent dropout probability, to emulate a
    real transducer's imperfections for validation/testing.
    """

    sensor_id: str
    noise_std_dev: float = 0.0
    dropout_probability: float = 0.0
    rng: random.Random = field(default_factory=random.Random)

    def read(self, timestamp: float, true_value: float) -> SensorReading:
        if self.rng.random() < self.dropout_probability:
            return SensorReading(timestamp=timestamp, value=None, valid=False)
        noisy = true_value + self.rng.gauss(0.0, self.noise_std_dev) if self.noise_std_dev else true_value
        return SensorReading(timestamp=timestamp, value=noisy, valid=True)
