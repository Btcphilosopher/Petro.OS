"""
digital_twin.dispenser_twin
=============================

FuelDispenserDigitalTwin: a complete software representation of one
dispenser, continuously mirroring the measured physical state, per
FuelFlow section 10.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal

from fuelflow.dispensing.dispenser import Dispenser
from fuelflow.dispensing.transaction import TransactionSnapshot
from fuelflow.digital_twin.state_model import (
    FlowState,
    FuelGradeState,
    MeterState,
    NozzleState,
    PaymentState,
    PriceState,
    PumpState,
    SensorState,
    TemperatureState,
    TwinCalibrationState,
    TwinTransactionState,
)


@dataclass
class FuelDispenserDigitalTwin:
    pump: PumpState
    meter: MeterState
    nozzle: NozzleState
    fuel_grade: FuelGradeState
    price: PriceState
    flow: FlowState = field(default_factory=FlowState)
    temperature: TemperatureState = field(default_factory=TemperatureState)
    transaction: TwinTransactionState = field(default_factory=TwinTransactionState)
    payment: PaymentState = field(default_factory=PaymentState)
    sensors: SensorState = field(default_factory=SensorState)
    calibration: TwinCalibrationState = field(default_factory=TwinCalibrationState)

    @classmethod
    def from_dispenser(cls, dispenser: Dispenser, fuel_display_name: str) -> "FuelDispenserDigitalTwin":
        txn = dispenser.current_transaction
        price = dispenser.price_engine.get_price(txn.fuel_code) if txn else None
        return cls(
            pump=PumpState(dispenser_id=dispenser.dispenser_id),
            meter=MeterState(meter_id=dispenser.meter.meter_id, volume_unit=dispenser.meter.volume_unit),
            nozzle=NozzleState(nozzle_id=dispenser.nozzle.nozzle_id, lifted=dispenser.nozzle.is_lifted),
            fuel_grade=FuelGradeState(
                fuel_code=txn.fuel_code if txn else "", display_name=fuel_display_name
            ),
            price=PriceState(
                unit_price=price.effective_unit_price() if price else Decimal("0.00"),
                currency_symbol=price.currency.symbol if price else "",
                volume_unit=(price.unit.value if price else dispenser.meter.volume_unit),
            ),
        )

    def sync(self, dispenser: Dispenser, snapshot: TransactionSnapshot, as_of_date: date | None = None) -> None:
        """Pull the latest measured state from the live dispenser/engine into the twin."""
        as_of_date = as_of_date or date.today()
        txn = dispenser.current_transaction

        self.meter.accumulated_volume = snapshot.accumulated_volume
        self.meter.flow_rate = snapshot.flow_rate
        self.meter.status = dispenser.diagnostic_state

        self.nozzle.lifted = dispenser.nozzle.is_lifted
        self.flow.instantaneous_flow_rate = snapshot.flow_rate

        if txn and txn.measurements:
            self.temperature.current_c = txn.measurements[-1].temperature

        if txn is not None:
            price = dispenser.price_engine.get_price(txn.fuel_code)
            self.fuel_grade = FuelGradeState(fuel_code=txn.fuel_code, display_name=self.fuel_grade.display_name)
            self.price = PriceState(
                unit_price=price.effective_unit_price(),
                currency_symbol=price.currency.symbol,
                volume_unit=price.unit.value,
            )

        self.transaction = TwinTransactionState(
            transaction_id=txn.transaction_id if txn else None,
            state=snapshot.state,
            target_amount=snapshot.target_amount,
            dispensed_value=snapshot.dispensed_value_exact,
        )

        self.payment = PaymentState(
            authorized=bool(txn and txn.payment_authorization_id is not None),
            captured=bool(txn and txn.payment_captured),
            method=None,
        )

        self.sensors = SensorState(overall_diagnostic=dispenser.diagnostic_state)

        self.calibration = TwinCalibrationState(
            validity=dispenser.calibration_state.validity(as_of_date),
            effective_factor=dispenser.calibration_state.effective_calibration_factor(as_of_date),
        )

    def render_summary(self) -> str:
        """Human-readable panel, in the style of FuelFlow section 10's example."""
        lines = [
            f"DISPENSER {self.pump.dispenser_id}",
            "",
            f"{self.fuel_grade.display_name}",
            f"{self.price.currency_symbol}{self.price.unit_price}/{self.price.volume_unit}",
            "",
            "FLOW",
            f"{self.flow.instantaneous_flow_rate:.1f} {self.meter.volume_unit}/min",
            "",
            "TOTAL",
            f"{self.price.currency_symbol}{self.transaction.dispensed_value.quantize(Decimal('0.01'))}",
            "",
            "VOLUME",
            f"{self.meter.accumulated_volume:.2f} {self.meter.volume_unit}",
            "",
            "TEMPERATURE",
            f"{self.temperature.current_c:.1f} °C",
            "",
            "METER STATUS",
            self.meter.status.value,
            "",
            "CALIBRATION",
            self.calibration.validity.value,
        ]
        return "\n".join(lines)
