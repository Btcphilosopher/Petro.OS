"""
digital_twin.state_model
==========================

Plain data snapshots mirroring each physical subsystem of the
dispenser, per FuelFlow section 10. These are pure state -- the twin
(`dispenser_twin.py`) is responsible for keeping them in sync with the
live engine.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Optional

from fuelflow.core.state_machine import TransactionState
from fuelflow.metrology.calibration import CalibrationValidity
from fuelflow.metrology.validation import DiagnosticState


@dataclass
class PumpState:
    dispenser_id: str
    powered: bool = True
    in_service: bool = True


@dataclass
class MeterState:
    meter_id: str
    accumulated_volume: float = 0.0
    volume_unit: str = "gal"
    flow_rate: float = 0.0
    status: DiagnosticState = DiagnosticState.NORMAL


@dataclass
class NozzleState:
    nozzle_id: str
    lifted: bool = False


@dataclass
class FuelGradeState:
    fuel_code: str
    display_name: str


@dataclass
class PriceState:
    unit_price: Decimal
    currency_symbol: str
    volume_unit: str


@dataclass
class FlowState:
    instantaneous_flow_rate: float = 0.0
    flow_unit: str = "gal/min"


@dataclass
class TemperatureState:
    current_c: float = 15.0


@dataclass
class TwinTransactionState:
    transaction_id: Optional[str] = None
    state: TransactionState = TransactionState.IDLE
    target_amount: Decimal = Decimal("0.00")
    dispensed_value: Decimal = Decimal("0.00")


@dataclass
class PaymentState:
    authorized: bool = False
    captured: bool = False
    method: Optional[str] = None


@dataclass
class SensorState:
    overall_diagnostic: DiagnosticState = DiagnosticState.NORMAL


@dataclass
class TwinCalibrationState:
    validity: CalibrationValidity = CalibrationValidity.UNKNOWN
    effective_factor: float = 1.0
