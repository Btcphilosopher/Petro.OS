"""
Aardvark FuelFlow
==================

A precision digital metrology, pricing and transaction engine for a modern
petrol-station fuel dispenser.

FuelFlow is a *supervisory computation, telemetry, validation, digital-twin,
diagnostics and transaction layer*. It is explicitly NOT a replacement for
legally-required certified metrology hardware (the physical positive
displacement / turbine / Coriolis meter, its certified pulse transducer and
its type-approved calibration) or for safety-critical dispenser controls
(solenoid valves, overfill protection, emergency stops, vapour recovery
interlocks, etc). Those remain the authoritative, certified systems in any
real installation. FuelFlow models, supervises, cross-checks and reconciles
their output.
"""

__version__ = "1.0.0"
__all__ = ["__version__"]
