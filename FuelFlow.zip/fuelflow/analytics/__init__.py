"""FuelFlow subpackage: analytics"""
