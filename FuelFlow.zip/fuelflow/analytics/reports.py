"""
analytics.reports
====================

Human-readable summary reports built from :mod:`fuelflow.analytics.accuracy`
statistics and from historian data.
"""

from __future__ import annotations

from typing import Sequence

from fuelflow.analytics.accuracy import AccuracyReport


def format_accuracy_report(title: str, report: AccuracyReport, unit: str = "") -> str:
    unit_suffix = f" {unit}" if unit else ""
    return "\n".join(
        [
            f"=== {title} ===",
            f"samples              : {report.n}",
            f"mean error           : {report.mean_error:+.6f}{unit_suffix}",
            f"bias                 : {report.bias:+.6f}{unit_suffix}",
            f"max absolute error   : {report.max_absolute_error:.6f}{unit_suffix}",
            f"std dev (repeatab.)  : {report.std_dev:.6f}{unit_suffix}",
            f"rmse                 : {report.rmse:.6f}{unit_suffix}",
        ]
    )


def format_transaction_summary(records: Sequence[dict]) -> str:
    lines = [f"Transactions on file: {len(records)}", ""]
    for r in records[-10:]:
        fv = r.get("final_value") or {}
        lines.append(
            f"{r['transaction_id'][:8]}  {r['fuel_code']:<10} "
            f"target={r['requested_monetary_value']:<8} "
            f"delivered={r.get('actual_delivered_volume', 0):.4f} "
            f"charge={fv.get('final_charge', '-')}  state={r['state']}"
        )
    return "\n".join(lines)
