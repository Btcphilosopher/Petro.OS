"""
analytics.accuracy
=====================

Metrology accuracy statistics over a population of transactions/samples:
mean error, maximum error, bias, repeatability (standard deviation of
repeated measurements of a nominally identical quantity), and rounding
error -- per FuelFlow section 15.
"""

from __future__ import annotations

import statistics
from dataclasses import dataclass
from typing import List, Sequence


@dataclass(frozen=True)
class AccuracyReport:
    n: int
    mean_error: float
    max_absolute_error: float
    bias: float
    std_dev: float
    repeatability: float  # std dev of the error distribution, an alias kept explicit for clarity
    rmse: float


def compute_accuracy(true_values: Sequence[float], measured_values: Sequence[float]) -> AccuracyReport:
    """
    `true_values` are the reference (e.g. simulator ground-truth or
    prover) quantities; `measured_values` are FuelFlow's computed
    quantities for the same events. Errors are `measured - true`.
    """
    if len(true_values) != len(measured_values):
        raise ValueError("true_values and measured_values must be the same length")
    if not true_values:
        raise ValueError("Need at least one sample")

    errors: List[float] = [m - t for t, m in zip(true_values, measured_values)]
    n = len(errors)
    mean_error = statistics.fmean(errors)
    max_absolute_error = max(abs(e) for e in errors)
    std_dev = statistics.pstdev(errors) if n > 1 else 0.0
    rmse = (sum(e**2 for e in errors) / n) ** 0.5

    return AccuracyReport(
        n=n,
        mean_error=mean_error,
        max_absolute_error=max_absolute_error,
        bias=mean_error,  # systematic bias is exactly the mean signed error
        std_dev=std_dev,
        repeatability=std_dev,
        rmse=rmse,
    )


def compute_rounding_error_stats(exact_values, rounded_values) -> AccuracyReport:
    """Same statistics, specialised for the currency-rounding step (Decimal-safe)."""
    exact_f = [float(v) for v in exact_values]
    rounded_f = [float(v) for v in rounded_values]
    return compute_accuracy(exact_f, rounded_f)
