"""
dispensing.target_value
=========================

TargetValueEngine, per FuelFlow section 7.

Given a requested monetary amount and a fuel price, determines the
*target volume* to dispense towards -- and keeps requested value,
calculated target volume, actual delivered volume and actual transaction
value as four distinct, never-conflated quantities.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, getcontext

from fuelflow.pricing.price_engine import FuelPrice

# Plenty of precision for intermediate volume division; final money values
# are always explicitly quantized to the currency's minor unit downstream.
getcontext().prec = 28

# Common preset amounts a dispenser UI offers, per FuelFlow section 7.
PRESET_AMOUNTS = (Decimal("5.00"), Decimal("10.00"), Decimal("20.00"), Decimal("50.00"), Decimal("100.00"))


@dataclass(frozen=True)
class TargetValueResult:
    requested_monetary_value: Decimal
    fuel_price: FuelPrice
    calculated_target_volume: Decimal


@dataclass
class TargetValueEngine:
    """
    Computes a target volume dynamically from a requested amount and the
    current fuel price -- never a hard-coded lookup table.
    """

    volume_decimal_places: int = 4  # e.g. 2.8580 gal -- generous precision, not currency rounding

    def target_for_amount(self, target_amount: Decimal, price: FuelPrice) -> TargetValueResult:
        if target_amount <= 0:
            raise ValueError("target_amount must be positive")
        unit_price = price.effective_unit_price()
        if unit_price <= 0:
            raise ValueError("fuel price must be positive")

        exact_volume = target_amount / unit_price
        quantum = Decimal(1).scaleb(-self.volume_decimal_places)
        target_volume = exact_volume.quantize(quantum)

        return TargetValueResult(
            requested_monetary_value=target_amount,
            fuel_price=price,
            calculated_target_volume=target_volume,
        )

    def target_for_preset(self, preset: Decimal, price: FuelPrice) -> TargetValueResult:
        if preset not in PRESET_AMOUNTS:
            raise ValueError(f"{preset} is not a configured preset amount: {PRESET_AMOUNTS}")
        return self.target_for_amount(preset, price)
