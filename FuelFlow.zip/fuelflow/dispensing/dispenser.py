"""
dispensing.dispenser
======================

The Dispenser: one physical pump/meter/nozzle unit, driven tick-by-tick
from raw pulse acquisition data (as real hardware would deliver it),
producing the running transaction state described in FuelFlow section 6.

    volume dispensed / fuel price / current transaction value / flow rate
    remaining target value / estimated time to target

This module deliberately only *consumes* raw pulses -- it never invents
flow. A live deployment feeds `tick()` from the certified meter's pulse
transducer; the simulator feeds it from a synthetic flow profile via
`fuelflow.metrology.pulse_counter.pulses_from_flow_rate`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from typing import Optional

from fuelflow.core.state_machine import TransactionState
from fuelflow.dispensing.nozzle import Nozzle
from fuelflow.dispensing.target_value import TargetValueEngine
from fuelflow.dispensing.transaction import Transaction, TransactionSnapshot
from fuelflow.fuel.fuel_types import FuelTypeRegistry
from fuelflow.fuel.temperature import TemperatureCompensator
from fuelflow.metrology.calibration import CalibrationState
from fuelflow.metrology.flow_meter import FlowMeter
from fuelflow.metrology.uncertainty import build_volume_uncertainty_budget
from fuelflow.metrology.validation import DiagnosticState, MeasurementSample, SensorValidator
from fuelflow.metrology.volume_engine import FlowMeasurement, VolumeEngine
from fuelflow.pricing.price_engine import PriceEngine
from fuelflow.pricing.transaction_value import reconcile_transaction_value


class DispenserFault(RuntimeError):
    pass


@dataclass
class Dispenser:
    dispenser_id: str
    meter: FlowMeter
    calibration_state: CalibrationState
    price_engine: PriceEngine
    fuel_registry: FuelTypeRegistry
    nozzle: Nozzle = field(default_factory=lambda: Nozzle(nozzle_id="N1"))
    validator: SensorValidator = field(default_factory=SensorValidator)
    target_engine: TargetValueEngine = field(default_factory=TargetValueEngine)
    temperature_compensator: TemperatureCompensator = field(default_factory=TemperatureCompensator)

    # Fraction of the target volume at which the (real) target-value
    # controller would begin throttling flow back for an accurate stop.
    # FuelFlow only *observes and reports* this transition; the actual
    # valve control is certified dispenser hardware.
    approach_threshold_fraction: Decimal = Decimal("0.90")

    volume_engine: VolumeEngine = field(init=False)
    current_transaction: Optional[Transaction] = field(default=None, init=False)
    diagnostic_state: DiagnosticState = field(default=DiagnosticState.NORMAL, init=False)

    def __post_init__(self) -> None:
        self.volume_engine = VolumeEngine(meter=self.meter, calibration_state=self.calibration_state)

    # -- lifecycle -----------------------------------------------------

    def authorise(self, timestamp: float, target_amount: Decimal, fuel_code: str) -> Transaction:
        if self.current_transaction is not None and not self.current_transaction.state_machine.is_terminal():
            raise DispenserFault("A transaction is already in progress on this dispenser")

        price = self.price_engine.get_price(fuel_code)
        target = self.target_engine.target_for_amount(target_amount, price)

        txn = Transaction(
            fuel_code=fuel_code,
            meter_id=self.meter.meter_id,
            dispenser_id=self.dispenser_id,
            target=target,
        )
        txn.state_machine.transition(TransactionState.AUTHORISED, timestamp, reason="payment authorised")
        self.current_transaction = txn
        self.volume_engine.reset_transaction()
        return txn

    def lift_nozzle(self, timestamp: float) -> None:
        txn = self._require_transaction()
        self.nozzle.lift()
        txn.state_machine.transition(TransactionState.NOZZLE_LIFTED, timestamp, reason="nozzle lifted")

    def begin_dispensing(self, timestamp: float) -> None:
        txn = self._require_transaction()
        txn.state_machine.transition(TransactionState.DISPENSING, timestamp, reason="flow started")

    def tick(
        self,
        timestamp: float,
        raw_pulses_in_tick: float,
        dt_s: float,
        temperature_c: float,
        density_kg_per_l: float,
        meter_status_ok: bool = True,
        communication_ok: bool = True,
        as_of_date: Optional[date] = None,
    ) -> TransactionSnapshot:
        """Advance the dispenser by one acquisition tick."""
        txn = self._require_transaction()
        as_of_date = as_of_date or date.today()

        previous_volume = self.volume_engine.accumulated_calibrated_volume

        # Provisionally process the measurement to get flow-rate/pulse info
        # for validation, using NORMAL quality; we patch the true quality
        # in below once the validator has run.
        measurement = self.volume_engine.process_tick(
            timestamp=timestamp,
            raw_pulses_in_tick=raw_pulses_in_tick,
            dt_s=dt_s,
            temperature_c=temperature_c,
            density_kg_per_l=density_kg_per_l,
            as_of=as_of_date,
        )

        sample = MeasurementSample(
            timestamp=timestamp,
            pulse_frequency_hz=measurement.pulse_frequency,
            flow_rate=measurement.instantaneous_flow_rate,
            accumulated_volume=measurement.accumulated_volume,
            previous_accumulated_volume=previous_volume,
            temperature_c=temperature_c,
            pressure_kpa=None,
            meter_status_ok=meter_status_ok,
            nozzle_lifted=self.nozzle.is_lifted,
            transaction_active=txn.state_machine.is_in_progress(),
            dt_s=dt_s,
            maximum_flow_rate=self.meter.maximum_flow_rate,
            minimum_flow_rate=self.meter.minimum_flow_rate,
            communication_ok=communication_ok,
        )
        findings = self.validator.evaluate(sample)
        self.diagnostic_state = self.validator.overall_state(findings)
        measurement.measurement_quality = self.diagnostic_state.value

        txn.record_measurement(measurement)

        if self.diagnostic_state in (DiagnosticState.INVALID, DiagnosticState.SERVICE_REQUIRED):
            raise DispenserFault(
                f"Measurement validation failed ({self.diagnostic_state.value}): "
                f"{[f.detail for f in findings if f.state == self.diagnostic_state]}"
            )

        self._advance_target_state(timestamp, measurement, txn)

        snapshot = self._build_snapshot(timestamp, measurement, txn)
        txn.record_snapshot(snapshot)
        return snapshot

    def _advance_target_state(self, timestamp: float, measurement: FlowMeasurement, txn: Transaction) -> None:
        price = self.price_engine.get_price(txn.fuel_code)
        current_value = Decimal(str(round(measurement.accumulated_volume, 6))) * price.effective_unit_price()
        target_amount = txn.target.requested_monetary_value
        state = txn.state_machine.state

        if state == TransactionState.DISPENSING:
            if current_value >= target_amount * self.approach_threshold_fraction:
                txn.state_machine.transition(
                    TransactionState.TARGET_APPROACH, timestamp, reason="approaching target value"
                )
                state = txn.state_machine.state

        if state == TransactionState.TARGET_APPROACH and current_value >= target_amount:
            txn.state_machine.transition(TransactionState.TARGET_REACHED, timestamp, reason="target value reached")

    def finalise(self, timestamp: float, as_of_date: Optional[date] = None) -> Transaction:
        txn = self._require_transaction()
        as_of_date = as_of_date or date.today()
        if txn.state_machine.state != TransactionState.TARGET_REACHED:
            raise DispenserFault(f"Cannot finalise from state {txn.state_machine.state.value}")

        txn.state_machine.transition(TransactionState.FINALISING, timestamp, reason="reconciling transaction")

        last = txn.measurements[-1]
        delivered_volume = Decimal(str(round(last.accumulated_volume, 6)))
        price = self.price_engine.get_price(txn.fuel_code)

        tax_component = self.price_engine.tax_component(delivered_volume * price.effective_unit_price())
        txn.final_value = reconcile_transaction_value(price, delivered_volume, tax_component)

        total_pulses = max(self.meter.pulses_per_unit_volume * float(delivered_volume), 1.0)
        pulse_resolution_uncertainty = 1.0 / total_pulses  # one quantised pulse, as a fraction of total count

        txn.final_uncertainty_budget = build_volume_uncertainty_budget(
            calibration_uncertainty=self.calibration_state.calibration_uncertainty,
            pulse_resolution_uncertainty=pulse_resolution_uncertainty,
            repeatability=0.0008,
            temperature_compensation_uncertainty=0.0005,
        )

        txn.state_machine.transition(TransactionState.COMPLETED, timestamp, reason="transaction complete")
        return txn

    def cancel(self, timestamp: float, reason: str) -> Transaction:
        txn = self._require_transaction()
        txn.state_machine.transition(TransactionState.CANCELLED, timestamp, reason=reason)
        txn.cancellation_reason = reason
        return txn

    # -- helpers ---------------------------------------------------------

    def _require_transaction(self) -> Transaction:
        if self.current_transaction is None:
            raise DispenserFault("No transaction in progress")
        return self.current_transaction

    def _build_snapshot(self, timestamp: float, measurement: FlowMeasurement, txn: Transaction) -> TransactionSnapshot:
        price = self.price_engine.get_price(txn.fuel_code)
        dispensed_value = Decimal(str(round(measurement.accumulated_volume, 6))) * price.effective_unit_price()
        target_amount = txn.target.requested_monetary_value
        remaining_value = max(target_amount - dispensed_value, Decimal("0.00"))

        eta: Optional[float] = None
        if measurement.instantaneous_flow_rate > 1e-6:
            remaining_volume = float(remaining_value) / float(price.effective_unit_price())
            eta = (remaining_volume / measurement.instantaneous_flow_rate) * 60.0

        return TransactionSnapshot(
            timestamp=timestamp,
            state=txn.state_machine.state,
            target_amount=target_amount,
            dispensed_value_exact=dispensed_value,
            remaining_value=remaining_value,
            flow_rate=measurement.instantaneous_flow_rate,
            accumulated_volume=measurement.accumulated_volume,
            estimated_time_to_target_s=eta,
        )
