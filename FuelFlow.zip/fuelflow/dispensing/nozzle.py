"""
dispensing.nozzle
===================

Model of the physical nozzle switch state. In a real dispenser this is a
certified, safety-interlocked microswitch; here it is a simple state
holder the supervisory state machine reacts to.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class NozzleState(str, Enum):
    HOLSTERED = "HOLSTERED"
    LIFTED = "LIFTED"


@dataclass
class Nozzle:
    nozzle_id: str
    state: NozzleState = NozzleState.HOLSTERED

    def lift(self) -> None:
        self.state = NozzleState.LIFTED

    def replace(self) -> None:
        self.state = NozzleState.HOLSTERED

    @property
    def is_lifted(self) -> bool:
        return self.state == NozzleState.LIFTED
