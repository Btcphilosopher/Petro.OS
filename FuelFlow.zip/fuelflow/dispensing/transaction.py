"""
dispensing.transaction
========================

The Transaction record: identity, requested target, running measurement
log, and final end-of-dispense reconciliation (FuelFlow section 8).
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from decimal import Decimal
from typing import List, Optional

from fuelflow.core.state_machine import StateMachine, TransactionState
from fuelflow.dispensing.target_value import TargetValueResult
from fuelflow.metrology.uncertainty import UncertaintyBudget
from fuelflow.metrology.volume_engine import FlowMeasurement
from fuelflow.pricing.transaction_value import TransactionValue


@dataclass
class TransactionSnapshot:
    """A point-in-time view of an in-progress transaction, for UI/telemetry."""

    timestamp: float
    state: TransactionState
    target_amount: Decimal
    dispensed_value_exact: Decimal
    remaining_value: Decimal
    flow_rate: float
    accumulated_volume: float
    estimated_time_to_target_s: Optional[float]


@dataclass
class Transaction:
    fuel_code: str
    meter_id: str
    dispenser_id: str
    target: TargetValueResult
    transaction_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    started_at_utc: Optional[str] = None
    completed_at_utc: Optional[str] = None

    state_machine: StateMachine = field(default_factory=StateMachine)
    measurements: List[FlowMeasurement] = field(default_factory=list)
    snapshots: List[TransactionSnapshot] = field(default_factory=list)

    payment_authorization_id: Optional[str] = None
    payment_captured: bool = False

    final_value: Optional[TransactionValue] = None
    final_uncertainty_budget: Optional[UncertaintyBudget] = None
    cancellation_reason: Optional[str] = None

    def record_measurement(self, measurement: FlowMeasurement) -> None:
        self.measurements.append(measurement)

    def record_snapshot(self, snapshot: TransactionSnapshot) -> None:
        self.snapshots.append(snapshot)

    @property
    def actual_delivered_volume(self) -> float:
        """
        The actual measured volume, distinct from `target.calculated_target_volume`.
        """
        return self.measurements[-1].accumulated_volume if self.measurements else 0.0

    @property
    def state(self) -> TransactionState:
        return self.state_machine.state

    def to_record_dict(self) -> dict:
        """Machine-readable record of the complete measurement chain (section 18/14)."""
        last = self.measurements[-1] if self.measurements else None
        return {
            "transaction_id": self.transaction_id,
            "dispenser_id": self.dispenser_id,
            "meter_id": self.meter_id,
            "fuel_code": self.fuel_code,
            "started_at_utc": self.started_at_utc,
            "completed_at_utc": self.completed_at_utc,
            "state": self.state.value,
            "requested_monetary_value": str(self.target.requested_monetary_value),
            "calculated_target_volume": str(self.target.calculated_target_volume),
            "actual_delivered_volume": last.accumulated_volume if last else 0.0,
            "measurement_chain_last_sample": {
                "timestamp": last.timestamp,
                "raw_pulses": last.raw_pulses,
                "pulse_frequency": last.pulse_frequency,
                "filtered_pulses": last.filtered_pulses,
                "calibration_factor_applied": last.calibration_factor_applied,
                "raw_volume": last.raw_volume,
                "calibrated_volume": last.calibrated_volume,
                "temperature": last.temperature,
                "density": last.density,
                "measurement_quality": last.measurement_quality,
                "calibration_state": last.calibration_state,
            }
            if last
            else None,
            "final_value": {
                "unit_price": str(self.final_value.unit_price),
                "delivered_volume": str(self.final_value.delivered_volume),
                "gross_value_exact": str(self.final_value.gross_value_exact),
                "tax_component": str(self.final_value.tax_component),
                "rounding_adjustment": str(self.final_value.rounding_adjustment),
                "final_charge": str(self.final_value.final_charge),
            }
            if self.final_value
            else None,
            "measurement_uncertainty_relative_95pct": (
                self.final_uncertainty_budget.expanded_uncertainty() if self.final_uncertainty_budget else None
            ),
            "payment_authorization_id": self.payment_authorization_id,
            "payment_captured": self.payment_captured,
            "cancellation_reason": self.cancellation_reason,
            "state_history": [
                {"from": t.from_state.value, "to": t.to_state.value, "timestamp": t.timestamp, "reason": t.reason}
                for t in self.state_machine.history
            ],
        }
