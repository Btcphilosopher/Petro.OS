"""
pricing.price_engine
======================

All monetary computation uses :class:`decimal.Decimal` -- never binary
floating point -- per FuelFlow section 3/12. Physical measurement
(volume, flow rate, temperature) stays in the metrology layer as
`float`; the boundary where a measured volume becomes a priced value is
the one deliberate, explicit conversion point in this module.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from typing import Dict

from fuelflow.core.configuration import CurrencyConfig, RegionPricingConfig

# US gallon <-> litre, exact rational conversion factor used throughout.
LITRES_PER_US_GALLON = Decimal("3.785411784")


class VolumeUnit(str, Enum):
    LITRE = "L"
    GALLON = "gal"


def to_litres(volume: Decimal, unit: VolumeUnit) -> Decimal:
    if unit == VolumeUnit.LITRE:
        return volume
    return volume * LITRES_PER_US_GALLON


def to_gallons(volume: Decimal, unit: VolumeUnit) -> Decimal:
    if unit == VolumeUnit.GALLON:
        return volume
    return volume / LITRES_PER_US_GALLON


@dataclass(frozen=True)
class FuelPrice:
    """A configured unit price for one fuel grade, in one region/currency."""

    fuel_code: str
    unit_price: Decimal
    unit: VolumeUnit
    currency: CurrencyConfig
    promotional_discount_per_unit: Decimal = Decimal("0.00")

    def effective_unit_price(self) -> Decimal:
        return self.unit_price - self.promotional_discount_per_unit


@dataclass
class PriceEngine:
    """
    Holds configured prices per fuel grade/region and performs the
    volume -> monetary value conversion using Decimal arithmetic only.
    """

    region: RegionPricingConfig
    prices: Dict[str, FuelPrice] = field(default_factory=dict)

    def set_price(self, price: FuelPrice) -> None:
        self.prices[price.fuel_code] = price

    def get_price(self, fuel_code: str) -> FuelPrice:
        try:
            return self.prices[fuel_code]
        except KeyError as exc:
            raise KeyError(f"No price configured for fuel {fuel_code!r}") from exc

    def unit_price_decimal(self, fuel_code: str) -> Decimal:
        return self.get_price(fuel_code).effective_unit_price()

    def gross_value_for_volume(self, fuel_code: str, volume: Decimal, unit: VolumeUnit) -> Decimal:
        """
        Pure multiplication in the fuel's *priced* unit -- no rounding here.
        Rounding to currency minor units happens explicitly downstream in
        :mod:`fuelflow.pricing.transaction_value`, never silently.
        """
        price = self.get_price(fuel_code)
        volume_in_price_unit = volume if unit == price.unit else self._convert(volume, unit, price.unit)
        return volume_in_price_unit * price.effective_unit_price()

    def apply_tax(self, gross_value: Decimal) -> Decimal:
        """
        Apply the region's tax rate. If tax is already included in the
        posted price, the tax component is broken out for reporting but
        not added again.
        """
        if self.region.tax_included_in_price:
            return gross_value
        return gross_value * (Decimal("1") + self.region.tax_rate)

    def tax_component(self, gross_value: Decimal) -> Decimal:
        if self.region.tax_included_in_price:
            # tax = gross - gross / (1 + rate)
            if self.region.tax_rate == 0:
                return Decimal("0.00")
            return gross_value - (gross_value / (Decimal("1") + self.region.tax_rate))
        return gross_value * self.region.tax_rate

    @staticmethod
    def _convert(volume: Decimal, from_unit: VolumeUnit, to_unit: VolumeUnit) -> Decimal:
        if from_unit == to_unit:
            return volume
        litres = to_litres(volume, from_unit)
        return litres if to_unit == VolumeUnit.LITRE else to_gallons(litres, VolumeUnit.LITRE)
