"""
pricing.transaction_value
===========================

Final monetary reconciliation for one transaction: gross value, tax
component, and the *explicitly documented* rounding adjustment between
the exact (many-decimal-place) calculated value and the charged amount,
per FuelFlow section 8.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal

from fuelflow.pricing.currency import round_to_currency
from fuelflow.pricing.price_engine import FuelPrice, VolumeUnit


@dataclass(frozen=True)
class TransactionValue:
    """
    Distinguishes the exact calculated value from the final, rounded
    charge -- the two are never silently conflated.
    """

    fuel_code: str
    delivered_volume: Decimal
    volume_unit: VolumeUnit
    unit_price: Decimal
    gross_value_exact: Decimal  # unrounded, full-precision
    tax_component: Decimal
    final_charge: Decimal  # rounded to currency minor unit
    rounding_adjustment: Decimal  # final_charge - gross_value_exact

    def summary_lines(self) -> list[str]:
        return [
            f"UNIT PRICE         {self.unit_price}/{self.volume_unit.value}",
            f"DELIVERED          {self.delivered_volume} {self.volume_unit.value}",
            f"CALCULATED VALUE   {self.gross_value_exact}",
            f"TAX                {self.tax_component}",
            f"ROUNDING ADJUST.   {self.rounding_adjustment:+}",
            f"FINAL CHARGE       {self.final_charge}",
        ]


def reconcile_transaction_value(
    price: FuelPrice, delivered_volume: Decimal, tax_component: Decimal
) -> TransactionValue:
    """
    Compute the final, explicitly-rounded transaction value from a
    delivered volume and a fuel price, per FuelFlow section 8's worked
    example:

        TARGET VALUE       $10.00
        UNIT PRICE         $3.499/gal
        DELIVERED          2.858 gal
        CALCULATED VALUE   $9.999...
        FINAL CHARGE       $10.00
    """
    unit_price = price.effective_unit_price()
    gross_value_exact = delivered_volume * unit_price
    final_charge = round_to_currency(gross_value_exact, price.currency)
    rounding_adjustment = final_charge - gross_value_exact
    return TransactionValue(
        fuel_code=price.fuel_code,
        delivered_volume=delivered_volume,
        volume_unit=price.unit,
        unit_price=unit_price,
        gross_value_exact=gross_value_exact,
        tax_component=tax_component,
        final_charge=final_charge,
        rounding_adjustment=rounding_adjustment,
    )
