"""
pricing.currency
==================

Currency-aware Decimal quantisation. All monetary rounding rules live
here, in one place, so "how many decimal places, rounded which way" is
never improvised inline elsewhere in the codebase.
"""

from __future__ import annotations

from decimal import ROUND_HALF_UP, Decimal

from fuelflow.core.configuration import CurrencyConfig, DEFAULT_CURRENCIES


def quantum_for(currency: CurrencyConfig) -> Decimal:
    """The smallest representable unit for a currency, e.g. Decimal('0.01')."""
    return Decimal(1).scaleb(-currency.minor_unit_decimals)


def round_to_currency(amount: Decimal, currency: CurrencyConfig, rounding=ROUND_HALF_UP) -> Decimal:
    """
    Round a Decimal monetary amount to the currency's minor unit using an
    explicit, documented rounding rule (half-up to the cent/penny by
    default -- the conventional retail rounding rule).
    """
    return amount.quantize(quantum_for(currency), rounding=rounding)


def format_money(amount: Decimal, currency: CurrencyConfig) -> str:
    quantised = round_to_currency(amount, currency)
    return f"{currency.symbol}{quantised}"


def get_currency(code: str) -> CurrencyConfig:
    try:
        return DEFAULT_CURRENCIES[code]
    except KeyError as exc:
        raise KeyError(f"Unconfigured currency: {code!r}") from exc
