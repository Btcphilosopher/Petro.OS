"""
core.engine
============

FuelFlowEngine: the top-level orchestrator that wires one or more
:class:`~fuelflow.dispensing.dispenser.Dispenser` instances together with
a payment terminal, digital twins and (optionally) a transaction
historian, and exposes the high-level API `main.py` and the simulator
drive: start a transaction, step it forward, finalise it, capture
payment.

This module contains no metrology or pricing logic of its own -- it
purely sequences calls into the lower layers, which is what keeps each
of those layers independently testable.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from typing import Callable, Dict, Optional

from fuelflow.core.clock import Clock, SystemClock
from fuelflow.core.configuration import EngineConfig
from fuelflow.core.state_machine import TransactionState
from fuelflow.digital_twin.dispenser_twin import FuelDispenserDigitalTwin
from fuelflow.dispensing.dispenser import Dispenser
from fuelflow.dispensing.transaction import Transaction, TransactionSnapshot
from fuelflow.payment.terminal import PaymentAuthorization, PaymentMethod, PaymentTerminal
from fuelflow.storage.historian import Historian


@dataclass
class FuelFlowEngine:
    payment_terminal: PaymentTerminal
    config: Optional[EngineConfig] = None
    clock: Clock = field(default_factory=SystemClock)
    historian: Optional[Historian] = None

    dispensers: Dict[str, Dispenser] = field(default_factory=dict)
    twins: Dict[str, FuelDispenserDigitalTwin] = field(default_factory=dict)
    _authorizations: Dict[str, PaymentAuthorization] = field(default_factory=dict)

    def register_dispenser(self, dispenser: Dispenser, fuel_display_name: str) -> None:
        self.dispensers[dispenser.dispenser_id] = dispenser
        self.twins[dispenser.dispenser_id] = FuelDispenserDigitalTwin.from_dispenser(dispenser, fuel_display_name)

    def start_transaction(
        self,
        dispenser_id: str,
        target_amount: Decimal,
        fuel_code: str,
        payment_method: PaymentMethod,
        as_of_date: Optional[date] = None,
    ) -> Transaction:
        dispenser = self._require_dispenser(dispenser_id)
        as_of_date = as_of_date or date.today()
        now = self.clock.now()

        price = dispenser.price_engine.get_price(fuel_code)
        authorization = self.payment_terminal.authorize(payment_method, target_amount, price.currency.code)
        if authorization.status.value != "APPROVED":
            raise PermissionError(f"Payment declined for dispenser {dispenser_id}: {authorization.status.value}")

        txn = dispenser.authorise(now, target_amount, fuel_code)
        txn.payment_authorization_id = authorization.authorization_id
        txn.started_at_utc = self.clock.now_utc_iso()
        self._authorizations[txn.transaction_id] = authorization

        dispenser.lift_nozzle(now)
        dispenser.begin_dispensing(now)
        return txn

    def step(
        self,
        dispenser_id: str,
        raw_pulses_in_tick: float,
        dt_s: float,
        temperature_c: float,
        density_kg_per_l: float,
        as_of_date: Optional[date] = None,
        meter_status_ok: bool = True,
        communication_ok: bool = True,
        on_snapshot: Optional[Callable[[TransactionSnapshot], None]] = None,
    ) -> TransactionSnapshot:
        dispenser = self._require_dispenser(dispenser_id)
        now = self.clock.now()
        snapshot = dispenser.tick(
            timestamp=now,
            raw_pulses_in_tick=raw_pulses_in_tick,
            dt_s=dt_s,
            temperature_c=temperature_c,
            density_kg_per_l=density_kg_per_l,
            meter_status_ok=meter_status_ok,
            communication_ok=communication_ok,
            as_of_date=as_of_date,
        )

        twin = self.twins[dispenser_id]
        twin.sync(dispenser, snapshot, as_of_date=as_of_date)

        if on_snapshot is not None:
            on_snapshot(snapshot)

        if snapshot.state == TransactionState.TARGET_REACHED:
            self._finalise_and_capture(dispenser_id, as_of_date)

        return snapshot

    def cancel_transaction(self, dispenser_id: str, reason: str) -> Transaction:
        dispenser = self._require_dispenser(dispenser_id)
        txn = dispenser.cancel(self.clock.now(), reason)
        auth = self._authorizations.get(txn.transaction_id)
        if auth is not None:
            self.payment_terminal.void(auth)
        if self.historian is not None:
            self.historian.record_transaction(txn)
        return txn

    def _finalise_and_capture(self, dispenser_id: str, as_of_date: Optional[date]) -> Transaction:
        dispenser = self._require_dispenser(dispenser_id)
        txn = dispenser.finalise(self.clock.now(), as_of_date=as_of_date)
        txn.completed_at_utc = self.clock.now_utc_iso()

        auth = self._authorizations.get(txn.transaction_id)
        if auth is not None and txn.final_value is not None:
            capture = self.payment_terminal.capture(auth, txn.final_value.final_charge)
            txn.payment_captured = capture.success

        if self.historian is not None:
            self.historian.record_transaction(txn)

        return txn

    def _require_dispenser(self, dispenser_id: str) -> Dispenser:
        try:
            return self.dispensers[dispenser_id]
        except KeyError as exc:
            raise KeyError(f"No dispenser registered with id {dispenser_id!r}") from exc
