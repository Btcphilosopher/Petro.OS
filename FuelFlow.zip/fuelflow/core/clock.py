"""
core.clock
==========

Time sources for FuelFlow. Every measurement, log record and transaction
event is timestamped from a single injectable clock so that the whole
engine can be driven deterministically in simulation/test, and from wall
clock time in a live deployment.
"""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field


class Clock(ABC):
    """Abstract time source."""

    @abstractmethod
    def now(self) -> float:
        """Return the current time in seconds (monotonic, not wall-clock)."""

    @abstractmethod
    def now_utc_iso(self) -> str:
        """Return the current wall-clock time as an ISO-8601 UTC string."""


class SystemClock(Clock):
    """Real-time clock backed by the OS monotonic counter."""

    def now(self) -> float:
        return time.monotonic()

    def now_utc_iso(self) -> str:
        return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


@dataclass
class SimulatedClock(Clock):
    """
    Deterministic, steppable clock used by the simulator and by tests.

    The clock never advances on its own -- callers explicitly `tick(dt)`
    it forward. This makes simulated transactions fully reproducible.
    """

    _t: float = 0.0
    _epoch_utc: float = field(default_factory=time.time)

    def now(self) -> float:
        return self._t

    def now_utc_iso(self) -> str:
        wall = self._epoch_utc + self._t
        return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(wall))

    def tick(self, dt: float) -> float:
        if dt < 0:
            raise ValueError("Clock cannot move backwards")
        self._t += dt
        return self._t

    def reset(self) -> None:
        self._t = 0.0
