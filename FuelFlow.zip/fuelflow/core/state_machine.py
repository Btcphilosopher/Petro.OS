"""
core.state_machine
===================

A small, strict, generic finite-state machine plus the concrete
transaction lifecycle used by the dispensing engine:

    IDLE -> AUTHORISED -> NOZZLE_LIFTED -> DISPENSING -> TARGET_APPROACH
         -> TARGET_REACHED -> FINALISING -> COMPLETED

with CANCELLED and FAULT reachable from any in-progress state. Every
transition is validated against an explicit adjacency table and recorded
with a timestamp, so the full lifecycle of a transaction is auditable.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Dict, List, Optional, Set


class TransactionState(str, Enum):
    IDLE = "IDLE"
    AUTHORISED = "AUTHORISED"
    NOZZLE_LIFTED = "NOZZLE_LIFTED"
    DISPENSING = "DISPENSING"
    TARGET_APPROACH = "TARGET_APPROACH"
    TARGET_REACHED = "TARGET_REACHED"
    FINALISING = "FINALISING"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"
    FAULT = "FAULT"


# Explicit adjacency table: the only transitions this state machine allows.
_TERMINAL_ESCAPES = {TransactionState.CANCELLED, TransactionState.FAULT}

_ALLOWED_TRANSITIONS: Dict[TransactionState, Set[TransactionState]] = {
    TransactionState.IDLE: {TransactionState.AUTHORISED},
    TransactionState.AUTHORISED: {TransactionState.NOZZLE_LIFTED} | _TERMINAL_ESCAPES,
    TransactionState.NOZZLE_LIFTED: {TransactionState.DISPENSING} | _TERMINAL_ESCAPES,
    TransactionState.DISPENSING: {TransactionState.TARGET_APPROACH} | _TERMINAL_ESCAPES,
    TransactionState.TARGET_APPROACH: {
        TransactionState.TARGET_REACHED,
        TransactionState.DISPENSING,  # flow can be modulated back and forth while approaching
    }
    | _TERMINAL_ESCAPES,
    TransactionState.TARGET_REACHED: {TransactionState.FINALISING} | _TERMINAL_ESCAPES,
    TransactionState.FINALISING: {TransactionState.COMPLETED, TransactionState.FAULT},
    TransactionState.COMPLETED: set(),
    TransactionState.CANCELLED: set(),
    TransactionState.FAULT: set(),
}


class IllegalTransitionError(RuntimeError):
    def __init__(self, current: TransactionState, target: TransactionState):
        super().__init__(f"Illegal transition: {current.value} -> {target.value}")
        self.current = current
        self.target = target


@dataclass(frozen=True)
class TransitionRecord:
    from_state: TransactionState
    to_state: TransactionState
    timestamp: float
    reason: str = ""


@dataclass
class StateMachine:
    """Generic strict FSM over :class:`TransactionState`."""

    state: TransactionState = TransactionState.IDLE
    history: List[TransitionRecord] = field(default_factory=list)
    _on_transition: Optional[Callable[[TransitionRecord], None]] = None

    def can_transition(self, target: TransactionState) -> bool:
        return target in _ALLOWED_TRANSITIONS.get(self.state, set())

    def transition(
        self, target: TransactionState, timestamp: float, reason: str = ""
    ) -> TransitionRecord:
        if not self.can_transition(target):
            raise IllegalTransitionError(self.state, target)
        record = TransitionRecord(
            from_state=self.state, to_state=target, timestamp=timestamp, reason=reason
        )
        self.state = target
        self.history.append(record)
        if self._on_transition is not None:
            self._on_transition(record)
        return record

    def is_terminal(self) -> bool:
        return self.state in (
            TransactionState.COMPLETED,
            TransactionState.CANCELLED,
            TransactionState.FAULT,
        )

    def is_in_progress(self) -> bool:
        return self.state not in (
            TransactionState.IDLE,
            TransactionState.COMPLETED,
            TransactionState.CANCELLED,
            TransactionState.FAULT,
        )
