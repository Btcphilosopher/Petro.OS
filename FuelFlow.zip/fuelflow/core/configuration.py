"""
core.configuration
===================

Central, explicit configuration objects for FuelFlow. Nothing about a
particular fuel's thermal-expansion coefficient, a meter's pulses-per-litre
figure, a currency's rounding rule, or a calibration interval is hard-coded
in business logic -- it all flows from configuration objects constructed
here (or loaded from JSON) so a deployment can be re-parameterised for a
different meter, fuel set, market or regulator without touching code.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import date
from decimal import Decimal
from pathlib import Path
from typing import Any, Dict, Optional


@dataclass(frozen=True)
class FuelTypeConfig:
    """Static physical/regulatory configuration for one fuel grade."""

    code: str  # e.g. "PETROL_95"
    display_name: str  # e.g. "Petrol 95"
    density_at_15c_kg_per_l: float  # reference density (kg/L) at 15 degC
    thermal_expansion_coefficient_per_degc: float  # volumetric, 1/degC
    reference_temperature_c: float = 15.0


@dataclass(frozen=True)
class MeterConfig:
    """Static configuration for one certified flow meter."""

    meter_id: str
    serial_number: str
    meter_type: str  # "positive_displacement" | "turbine" | "coriolis" | ...
    pulses_per_unit_volume: float  # pulses per litre (or per gallon), as installed
    volume_unit: str = "L"  # "L" or "gal"
    nominal_calibration_factor: float = 1.0
    maximum_flow_rate: float = 80.0  # unit-volume / minute
    minimum_flow_rate: float = 0.5  # unit-volume / minute
    calibration_interval_days: int = 365


@dataclass(frozen=True)
class CurrencyConfig:
    code: str  # ISO 4217, e.g. "USD"
    symbol: str
    minor_unit_decimals: int = 2  # cents, pence, ...


@dataclass(frozen=True)
class RegionPricingConfig:
    region_code: str
    currency: CurrencyConfig
    tax_rate: Decimal = Decimal("0.00")  # e.g. Decimal("0.20") == 20% VAT
    tax_included_in_price: bool = True


@dataclass
class EngineConfig:
    """Top-level configuration bundle handed to the FuelFlow engine."""

    dispenser_id: str = "DISPENSER-04"
    sample_period_s: float = 0.1
    fuel_types: Dict[str, FuelTypeConfig] = field(default_factory=dict)
    meters: Dict[str, MeterConfig] = field(default_factory=dict)
    region: Optional[RegionPricingConfig] = None
    extra: Dict[str, Any] = field(default_factory=dict)

    def to_json(self) -> str:
        def _default(o: Any) -> Any:
            if isinstance(o, Decimal):
                return str(o)
            if isinstance(o, date):
                return o.isoformat()
            raise TypeError(f"Not serialisable: {o!r}")

        return json.dumps(asdict(self), default=_default, indent=2)

    def save(self, path: str | Path) -> None:
        Path(path).write_text(self.to_json())


# ---------------------------------------------------------------------------
# Reference configuration data. These are illustrative defaults, not legal
# or regulatory guarantees -- a real deployment must source thermal
# expansion coefficients and meter constants from the applicable national
# metrology standard (e.g. API MPMS Chapter 11.1 / ASTM D1250 tables) and
# from the certified meter's own calibration certificate.
# ---------------------------------------------------------------------------

DEFAULT_FUEL_TYPES: Dict[str, FuelTypeConfig] = {
    "PETROL_95": FuelTypeConfig(
        code="PETROL_95",
        display_name="Petrol 95",
        density_at_15c_kg_per_l=0.745,
        thermal_expansion_coefficient_per_degc=0.00107,
    ),
    "PETROL_91": FuelTypeConfig(
        code="PETROL_91",
        display_name="Regular Unleaded 91",
        density_at_15c_kg_per_l=0.737,
        thermal_expansion_coefficient_per_degc=0.00109,
    ),
    "DIESEL": FuelTypeConfig(
        code="DIESEL",
        display_name="Diesel",
        density_at_15c_kg_per_l=0.836,
        thermal_expansion_coefficient_per_degc=0.00083,
    ),
    "E10": FuelTypeConfig(
        code="E10",
        display_name="E10 (10% ethanol)",
        density_at_15c_kg_per_l=0.749,
        thermal_expansion_coefficient_per_degc=0.00110,
    ),
    "E5": FuelTypeConfig(
        code="E5",
        display_name="E5 (5% ethanol)",
        density_at_15c_kg_per_l=0.747,
        thermal_expansion_coefficient_per_degc=0.00108,
    ),
}

DEFAULT_CURRENCIES: Dict[str, CurrencyConfig] = {
    "USD": CurrencyConfig(code="USD", symbol="$", minor_unit_decimals=2),
    "GBP": CurrencyConfig(code="GBP", symbol="£", minor_unit_decimals=2),
    "EUR": CurrencyConfig(code="EUR", symbol="€", minor_unit_decimals=2),
}


def default_meter(meter_id: str = "MTR-04-A") -> MeterConfig:
    """A representative certified positive-displacement meter, US gallon units."""
    return MeterConfig(
        meter_id=meter_id,
        serial_number="PD-2024-118820",
        meter_type="positive_displacement",
        pulses_per_unit_volume=1000.0,  # 1000 pulses / US gallon
        volume_unit="gal",
        nominal_calibration_factor=1.0000,
        maximum_flow_rate=12.0,  # gal/min
        minimum_flow_rate=0.3,  # gal/min
        calibration_interval_days=365,
    )


def default_engine_config() -> EngineConfig:
    return EngineConfig(
        dispenser_id="DISPENSER-04",
        sample_period_s=0.1,
        fuel_types=dict(DEFAULT_FUEL_TYPES),
        meters={"MTR-04-A": default_meter()},
        region=RegionPricingConfig(
            region_code="US-DEFAULT",
            currency=DEFAULT_CURRENCIES["USD"],
            tax_rate=Decimal("0.00"),
            tax_included_in_price=True,
        ),
    )
