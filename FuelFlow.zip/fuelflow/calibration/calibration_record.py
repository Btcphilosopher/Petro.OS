"""
calibration.calibration_record
=================================

The permanent record of one calibration event, per FuelFlow section 13:
meter ID, serial number, calibration factor, calibration date, next
calibration date, reference standard, uncertainty and the
technician/service record.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta


@dataclass(frozen=True)
class CalibrationRecord:
    meter_id: str
    serial_number: str
    calibration_factor: float
    calibration_date: date
    reference_standard: str  # e.g. "NIST-traceable 20 gal prover, cert #..."
    uncertainty: float  # relative, e.g. 0.0015 == 0.15%
    technician: str
    service_notes: str = ""
    calibration_interval_days: int = 365

    @property
    def next_calibration_date(self) -> date:
        return self.calibration_date + timedelta(days=self.calibration_interval_days)
