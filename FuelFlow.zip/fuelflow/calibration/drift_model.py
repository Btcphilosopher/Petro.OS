"""
calibration.drift_model
=========================

Simple, explicit models of how a meter's calibration factor drifts
between certification events, used both to project when a meter is
likely to fall outside tolerance (service scheduling) and to inject
realistic drift into the simulator.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date


@dataclass(frozen=True)
class LinearDriftModel:
    """
    The simplest useful drift model: a constant relative drift rate per
    day since the last calibration. Positive values mean the meter reads
    increasingly high over time; negative means increasingly low.
    """

    drift_per_day: float

    def factor_at(self, base_factor: float, calibration_date: date, as_of: date) -> float:
        days = max((as_of - calibration_date).days, 0)
        return base_factor * (1.0 + self.drift_per_day * days)

    def days_until_tolerance_exceeded(self, tolerance: float) -> float:
        """How many days of drift at this rate before |drift| exceeds tolerance."""
        if self.drift_per_day == 0:
            return float("inf")
        return abs(tolerance / self.drift_per_day)


@dataclass(frozen=True)
class RandomWalkDriftModel:
    """
    A more realistic model: drift accumulates as a random walk with a
    given daily standard deviation, rather than a fixed linear trend.
    Used by the Monte-Carlo simulator to generate a population of meters
    with varied drift histories.
    """

    daily_std_dev: float

    def sample_path(self, days: int, rng) -> list[float]:
        """Return a list of `days` relative-drift values, one per day."""
        drift = 0.0
        path = []
        for _ in range(days):
            drift += rng.gauss(0.0, self.daily_std_dev)
            path.append(drift)
        return path
