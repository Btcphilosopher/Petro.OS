"""
calibration.calibration_history
==================================

Append-only history of calibration records for one meter. This is the
system of record a live :class:`fuelflow.metrology.calibration.CalibrationState`
should be constructed from.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import List, Optional

from fuelflow.calibration.calibration_record import CalibrationRecord
from fuelflow.metrology.calibration import CalibrationState


@dataclass
class CalibrationHistory:
    meter_id: str
    records: List[CalibrationRecord] = field(default_factory=list)

    def add(self, record: CalibrationRecord) -> None:
        if record.meter_id != self.meter_id:
            raise ValueError(f"Record for meter {record.meter_id} does not belong to history for {self.meter_id}")
        self.records.append(record)
        self.records.sort(key=lambda r: r.calibration_date)

    def latest(self) -> Optional[CalibrationRecord]:
        return self.records[-1] if self.records else None

    def is_overdue(self, as_of: date) -> bool:
        latest = self.latest()
        if latest is None:
            return True
        return as_of > latest.next_calibration_date

    def as_of_date(self, as_of: date) -> Optional[CalibrationRecord]:
        """The record that was in effect on a given date."""
        applicable = [r for r in self.records if r.calibration_date <= as_of]
        return applicable[-1] if applicable else None

    def to_live_state(self, nominal_calibration_factor: float, meter_drift_per_day: float = 0.0) -> CalibrationState:
        """Build the runtime :class:`CalibrationState` from the latest record."""
        latest = self.latest()
        if latest is None:
            raise ValueError(f"No calibration record on file for meter {self.meter_id}")
        return CalibrationState(
            meter_id=self.meter_id,
            nominal_calibration_factor=nominal_calibration_factor,
            actual_calibration_factor=latest.calibration_factor,
            calibration_date=latest.calibration_date,
            calibration_interval_days=latest.calibration_interval_days,
            calibration_uncertainty=latest.uncertainty,
            meter_drift_per_day=meter_drift_per_day,
        )
