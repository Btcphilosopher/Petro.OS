"""
calibration.calibration_test
===============================

Models a wet calibration test (meter proving): dispense a known reference
volume through the meter under test, compare against the meter's own
reported volume, and derive the calibration factor that would correct it.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date


@dataclass(frozen=True)
class CalibrationTestResult:
    meter_id: str
    reference_volume: float  # from a certified prover / master meter
    meter_reported_volume: float  # raw, uncorrected meter reading
    derived_calibration_factor: float
    relative_error: float
    test_date: date
    passed: bool
    tolerance: float


def run_calibration_test(
    meter_id: str,
    reference_volume: float,
    meter_reported_volume: float,
    test_date: date,
    tolerance: float = 0.005,
) -> CalibrationTestResult:
    """
    Compute the calibration factor a meter needs so that
    `meter_reported_volume * factor == reference_volume`, and flag
    whether the *as-found* error (before correction) was within the
    accept/reject tolerance for the test.
    """
    if meter_reported_volume <= 0:
        raise ValueError("meter_reported_volume must be positive")

    derived_factor = reference_volume / meter_reported_volume
    relative_error = (meter_reported_volume - reference_volume) / reference_volume
    passed = abs(relative_error) <= tolerance

    return CalibrationTestResult(
        meter_id=meter_id,
        reference_volume=reference_volume,
        meter_reported_volume=meter_reported_volume,
        derived_calibration_factor=derived_factor,
        relative_error=relative_error,
        test_date=test_date,
        passed=passed,
        tolerance=tolerance,
    )
