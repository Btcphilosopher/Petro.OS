#!/usr/bin/env python3
"""
Aardvark FuelFlow -- demonstration entry point.

Runs a single simulated transaction end-to-end through the full
measurement/pricing/state-machine/payment/digital-twin/historian stack
(FuelFlow section 18), then prints the machine-readable transaction
record containing the complete measurement chain.

    python main.py                 # the section-18 demo transaction
    python main.py --full          # demo transaction + Monte-Carlo + optimisation summary
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import date
from decimal import Decimal
from pathlib import Path

from fuelflow.core.clock import SimulatedClock
from fuelflow.core.configuration import DEFAULT_CURRENCIES, RegionPricingConfig, default_meter
from fuelflow.core.engine import FuelFlowEngine
from fuelflow.dispensing.dispenser import Dispenser
from fuelflow.dispensing.nozzle import Nozzle
from fuelflow.fuel.fuel_types import FuelTypeRegistry
from fuelflow.metrology.calibration import CalibrationState
from fuelflow.metrology.flow_meter import FlowMeter, MeterTechnology
from fuelflow.metrology.pulse_counter import pulses_from_flow_rate
from fuelflow.payment.nfc import AardvarkNfcTerminal
from fuelflow.payment.terminal import PaymentMethod
from fuelflow.pricing.price_engine import FuelPrice, PriceEngine, VolumeUnit
from fuelflow.storage.historian import Historian

OUTPUT_DIR = Path(__file__).resolve().parent / "demo_output"


def build_demo_engine(historian: Historian | None) -> tuple[FuelFlowEngine, str]:
    meter_config = default_meter("MTR-04-A")
    meter = FlowMeter(
        meter_id=meter_config.meter_id,
        technology=MeterTechnology.POSITIVE_DISPLACEMENT,
        pulses_per_unit_volume=meter_config.pulses_per_unit_volume,
        calibration_factor=meter_config.nominal_calibration_factor,
        maximum_flow_rate=meter_config.maximum_flow_rate,
        minimum_flow_rate=meter_config.minimum_flow_rate,
        volume_unit=meter_config.volume_unit,
        serial_number=meter_config.serial_number,
    )
    calibration_state = CalibrationState(
        meter_id=meter.meter_id,
        nominal_calibration_factor=1.0,
        actual_calibration_factor=1.0006,  # a real certified meter, per its last calibration certificate
        calibration_date=date(2026, 3, 1),
        calibration_interval_days=365,
        calibration_uncertainty=0.0015,
        meter_drift_per_day=0.0,
    )

    region = RegionPricingConfig(
        region_code="US-DEFAULT", currency=DEFAULT_CURRENCIES["USD"], tax_rate=Decimal("0.00"), tax_included_in_price=True
    )
    price_engine = PriceEngine(region=region)
    price_engine.set_price(
        FuelPrice(fuel_code="PETROL_95", unit_price=Decimal("3.499"), unit=VolumeUnit.GALLON, currency=region.currency)
    )

    dispenser = Dispenser(
        dispenser_id="DISPENSER-04",
        meter=meter,
        calibration_state=calibration_state,
        price_engine=price_engine,
        fuel_registry=FuelTypeRegistry(),
        nozzle=Nozzle(nozzle_id="N1"),
    )

    engine = FuelFlowEngine(payment_terminal=AardvarkNfcTerminal(), clock=SimulatedClock(), historian=historian)
    engine.register_dispenser(dispenser, fuel_display_name="Petrol 95")
    return engine, dispenser.dispenser_id


def run_demo_transaction() -> dict:
    OUTPUT_DIR.mkdir(exist_ok=True)
    historian = Historian(db_path=str(OUTPUT_DIR / "fuelflow_demo.sqlite"), csv_path=str(OUTPUT_DIR / "fuelflow_demo_measurements.csv"))

    engine, dispenser_id = build_demo_engine(historian)
    dispenser = engine.dispensers[dispenser_id]
    meter = dispenser.meter
    price = dispenser.price_engine.get_price("PETROL_95")

    print("Aardvark FuelFlow")
    print(f"Dispenser {dispenser_id.split('-')[-1]}")
    print("Petrol 95")
    print()
    print("PRICE")
    print(f"${price.effective_unit_price()} / gallon")
    print()

    target_amount = Decimal("10.00")
    print("TARGET")
    print(f"${target_amount}")
    print()
    print("START DISPENSING")
    print()

    txn = engine.start_transaction(dispenser_id, target_amount, "PETROL_95", PaymentMethod.AARDVARK_TOKEN, date(2026, 9, 1))

    flow_rate = 8.4  # gal/min, per FuelFlow section 18's worked example
    dt_s = 0.05
    checkpoints = [Decimal("0.50"), Decimal("1.50"), Decimal("2.50")]
    checkpoint_idx = 0

    twin = engine.twins[dispenser_id]

    print("FLOW")
    print(f"{flow_rate} gal/min")
    print()

    while txn.state_machine.state.value not in ("COMPLETED", "CANCELLED", "FAULT"):
        raw_pulses = pulses_from_flow_rate(flow_rate, dt_s, meter.pulses_per_unit_volume)
        engine.clock.tick(dt_s)  # advance the simulated acquisition clock by one tick
        snapshot = engine.step(
            dispenser_id,
            raw_pulses_in_tick=raw_pulses,
            dt_s=dt_s,
            temperature_c=18.4,
            density_kg_per_l=0.745,
            as_of_date=date(2026, 9, 1),
        )

        if snapshot.state.value == "TARGET_APPROACH":
            # A real target-value controller throttles flow down to a fine
            # "creep" rate as it nears the target for an accurate stop;
            # FuelFlow only observes/reports that transition (it does not
            # drive the physical valve) -- this mirrors it in the demo so
            # the final charge lands on the target cent, as the certified
            # hardware's own shutoff would achieve.
            flow_rate = meter.minimum_flow_rate

        volume_decimal = Decimal(str(round(snapshot.accumulated_volume, 4)))
        if checkpoint_idx < len(checkpoints) and volume_decimal >= checkpoints[checkpoint_idx]:
            print("VOLUME")
            print(f"{snapshot.accumulated_volume:.3f} gal")
            print("VALUE")
            print(f"${snapshot.dispensed_value_exact.quantize(Decimal('0.01'))}")
            print()
            checkpoint_idx += 1

    print("VOLUME")
    print(f"{txn.actual_delivered_volume:.3f} gal")
    print("VALUE")
    print(f"≈ ${txn.final_value.final_charge}")
    print()
    print("DISPENSE COMPLETE")
    print()

    print("=== End-of-dispense reconciliation ===")
    for line in txn.final_value.summary_lines():
        print(line)
    print()

    print("=== Digital twin snapshot ===")
    print(twin.render_summary())
    print()

    record = txn.to_record_dict()
    record_path = OUTPUT_DIR / f"transaction_{txn.transaction_id}.json"
    record_path.write_text(json.dumps(record, indent=2))
    print(f"Machine-readable transaction record written to: {record_path}")

    historian.close()
    return record


def run_full_demo() -> None:
    """Also exercises Monte-Carlo accuracy analysis and the optimisation layer."""
    from fuelflow.analytics.reports import format_accuracy_report
    from fuelflow.core.configuration import default_meter
    from fuelflow.optimisation.calibration_optimizer import CalibrationOptimizer
    from fuelflow.optimisation.flow_optimizer import FlowOptimizer
    from fuelflow.optimisation.measurement_optimizer import MeasurementOptimizer
    from fuelflow.calibration.calibration_test import run_calibration_test
    from fuelflow.simulation.monte_carlo import run_monte_carlo
    from fuelflow.simulation.scenarios import ALL_SCENARIOS

    meter_config = default_meter("MTR-04-A")
    calibration_state = CalibrationState(
        meter_id=meter_config.meter_id,
        nominal_calibration_factor=1.0,
        actual_calibration_factor=1.0006,
        calibration_date=date(2026, 3, 1),
        calibration_uncertainty=0.0015,
    )
    region = RegionPricingConfig(region_code="US-DEFAULT", currency=DEFAULT_CURRENCIES["USD"], tax_rate=Decimal("0.00"))

    print("\n=== Monte-Carlo transaction simulation (all scenarios) ===")
    mc = run_monte_carlo(
        meter_config=meter_config,
        calibration_state=calibration_state,
        fuel_code="PETROL_95",
        unit_price=Decimal("3.499"),
        region=region,
        target_amount=Decimal("10.00"),
        scenarios=ALL_SCENARIOS,
        n_per_scenario=15,
    )
    print(
        f"requested={mc.n_requested} completed={mc.n_completed} faulted={mc.n_faulted} "
        f"cancelled={mc.n_cancelled} incomplete={mc.n_incomplete}"
    )
    print(format_accuracy_report("Delivered volume accuracy (gal)", mc.volume_accuracy, unit="gal"))
    print(format_accuracy_report("Final charge vs true value ($, incl. rounding)", mc.monetary_rounding_accuracy, unit="$"))

    print("\n=== Calibration optimiser ===")
    tests = [
        run_calibration_test("MTR-04-A", reference_volume=20.000, meter_reported_volume=19.981, test_date=date(2026, 3, 1)),
        run_calibration_test("MTR-04-A", reference_volume=20.000, meter_reported_volume=19.978, test_date=date(2026, 3, 1)),
        run_calibration_test("MTR-04-A", reference_volume=20.000, meter_reported_volume=19.984, test_date=date(2026, 3, 1)),
    ]
    cal_result = CalibrationOptimizer().fit(tests)
    print(
        f"least-squares factor={cal_result.least_squares_factor:.6f}  "
        f"bias before={cal_result.residual_bias_before:+.4%}  after={cal_result.residual_bias_after:+.4%}"
    )

    print("\n=== Measurement optimiser (sampling period x filter alpha) ===")
    mopt = MeasurementOptimizer()
    sweep = mopt.sweep(
        sample_periods_s=[0.05, 0.1, 0.25],
        filter_alphas=[0.2, 0.35, 0.6],
        pulses_per_unit_volume=meter_config.pulses_per_unit_volume,
        nominal_flow_rate=8.4,
        pulse_jitter_std_fraction=0.015,
    )
    best = mopt.best(sweep)
    print(f"best: dt={best.sample_period_s}s alpha={best.filter_alpha} std_dev={best.std_dev:.5f} (real-time OK={best.within_real_time_budget})")

    print("\n=== Flow optimiser (flow rate vs overshoot) ===")
    fopt = FlowOptimizer()
    flow_sweep = fopt.sweep(
        meter_config=meter_config,
        calibration_state=calibration_state,
        fuel_code="PETROL_95",
        unit_price=Decimal("3.499"),
        region=region,
        target_amount=Decimal("10.00"),
        flow_rates=[2.0, 5.0, 8.4, 11.0],
        n_trials=8,
    )
    for r in flow_sweep:
        print(f"flow={r.flow_rate:>5.1f} gal/min  mean_overshoot=${r.mean_overshoot:+.4f}  mean_duration={r.mean_dispense_duration_s:.1f}s")
    recommended = fopt.recommend(flow_sweep)
    print(f"recommended operating point: {recommended.flow_rate} gal/min")


def main() -> None:
    parser = argparse.ArgumentParser(description="Aardvark FuelFlow demonstration")
    parser.add_argument("--full", action="store_true", help="also run Monte-Carlo simulation and optimisation demos")
    args = parser.parse_args()

    run_demo_transaction()
    if args.full:
        run_full_demo()


if __name__ == "__main__":
    sys.exit(main() or 0)
