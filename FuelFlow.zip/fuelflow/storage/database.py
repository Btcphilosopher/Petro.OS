"""
storage.database
==================

SQLite schema and connection helper for the transaction historian.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS transactions (
    transaction_id TEXT PRIMARY KEY,
    dispenser_id TEXT NOT NULL,
    meter_id TEXT NOT NULL,
    fuel_code TEXT NOT NULL,
    started_at_utc TEXT,
    completed_at_utc TEXT,
    state TEXT NOT NULL,
    requested_monetary_value TEXT NOT NULL,
    calculated_target_volume TEXT NOT NULL,
    delivered_volume REAL,
    unit_price TEXT,
    gross_value_exact TEXT,
    tax_component TEXT,
    rounding_adjustment TEXT,
    final_charge TEXT,
    measurement_uncertainty_relative_95pct REAL,
    payment_authorization_id TEXT,
    payment_captured INTEGER,
    cancellation_reason TEXT,
    record_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS measurements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    transaction_id TEXT NOT NULL,
    timestamp REAL NOT NULL,
    meter_id TEXT NOT NULL,
    raw_pulses REAL,
    pulse_frequency REAL,
    instantaneous_flow_rate REAL,
    accumulated_volume REAL,
    temperature REAL,
    density REAL,
    calibration_factor_applied REAL,
    measurement_quality TEXT,
    calibration_state TEXT,
    FOREIGN KEY (transaction_id) REFERENCES transactions(transaction_id)
);

CREATE INDEX IF NOT EXISTS idx_measurements_txn ON measurements(transaction_id);
"""


def connect(db_path: str | Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(db_path))
    conn.executescript(SCHEMA)
    return conn
