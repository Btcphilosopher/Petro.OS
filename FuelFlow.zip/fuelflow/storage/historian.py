"""
storage.historian
===================

High-resolution transaction historian, per FuelFlow section 14. Records
every transaction (and, optionally, its full per-tick measurement log)
to SQLite, CSV or Parquet for local research/prototyping.

Parquet support is optional and only engaged if `pyarrow` (or `pandas`)
is installed; it degrades gracefully to CSV/SQLite otherwise so the
package has no hard dependency on a native-extension library.
"""

from __future__ import annotations

import csv
import json
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

from fuelflow.dispensing.transaction import Transaction
from fuelflow.storage.database import connect

HISTORIAN_FIELDS = [
    "timestamp",
    "meter_id",
    "transaction_id",
    "fuel_code",
    "unit_price",
    "raw_pulses",
    "accumulated_volume",
    "instantaneous_flow_rate",
    "temperature",
    "calibration_factor_applied",
    "measurement_quality",
    "payment_captured",
    "final_charge",
]


@dataclass
class Historian:
    db_path: str
    csv_path: Optional[str] = None
    parquet_path: Optional[str] = None

    def __post_init__(self) -> None:
        self._conn: sqlite3.Connection = connect(self.db_path)

    def record_transaction(self, txn: Transaction) -> None:
        self._write_sqlite(txn)
        if self.csv_path:
            self._append_csv(txn)
        if self.parquet_path:
            self._append_parquet(txn)

    def close(self) -> None:
        self._conn.close()

    # -- SQLite -----------------------------------------------------------

    def _write_sqlite(self, txn: Transaction) -> None:
        record = txn.to_record_dict()
        fv = record.get("final_value") or {}
        self._conn.execute(
            """
            INSERT OR REPLACE INTO transactions (
                transaction_id, dispenser_id, meter_id, fuel_code,
                started_at_utc, completed_at_utc, state,
                requested_monetary_value, calculated_target_volume,
                delivered_volume, unit_price, gross_value_exact,
                tax_component, rounding_adjustment, final_charge,
                measurement_uncertainty_relative_95pct,
                payment_authorization_id, payment_captured,
                cancellation_reason, record_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                record["transaction_id"],
                record["dispenser_id"],
                record["meter_id"],
                record["fuel_code"],
                record["started_at_utc"],
                record["completed_at_utc"],
                record["state"],
                record["requested_monetary_value"],
                record["calculated_target_volume"],
                record["actual_delivered_volume"],
                fv.get("unit_price"),
                fv.get("gross_value_exact"),
                fv.get("tax_component"),
                fv.get("rounding_adjustment"),
                fv.get("final_charge"),
                record["measurement_uncertainty_relative_95pct"],
                record["payment_authorization_id"],
                int(bool(record["payment_captured"])),
                record["cancellation_reason"],
                json.dumps(record),
            ),
        )

        for m in txn.measurements:
            self._conn.execute(
                """
                INSERT INTO measurements (
                    transaction_id, timestamp, meter_id, raw_pulses,
                    pulse_frequency, instantaneous_flow_rate,
                    accumulated_volume, temperature, density,
                    calibration_factor_applied, measurement_quality,
                    calibration_state
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    txn.transaction_id,
                    m.timestamp,
                    m.meter_id,
                    m.raw_pulses,
                    m.pulse_frequency,
                    m.instantaneous_flow_rate,
                    m.accumulated_volume,
                    m.temperature,
                    m.density,
                    m.calibration_factor_applied,
                    m.measurement_quality,
                    m.calibration_state,
                ),
            )
        self._conn.commit()

    # -- CSV ----------------------------------------------------------------

    def _append_csv(self, txn: Transaction) -> None:
        path = Path(self.csv_path)  # type: ignore[arg-type]
        write_header = not path.exists()
        with path.open("a", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=HISTORIAN_FIELDS)
            if write_header:
                writer.writeheader()
            for m in txn.measurements:
                writer.writerow(
                    {
                        "timestamp": m.timestamp,
                        "meter_id": m.meter_id,
                        "transaction_id": txn.transaction_id,
                        "fuel_code": txn.fuel_code,
                        "unit_price": txn.final_value.unit_price if txn.final_value else "",
                        "raw_pulses": m.raw_pulses,
                        "accumulated_volume": m.accumulated_volume,
                        "instantaneous_flow_rate": m.instantaneous_flow_rate,
                        "temperature": m.temperature,
                        "calibration_factor_applied": m.calibration_factor_applied,
                        "measurement_quality": m.measurement_quality,
                        "payment_captured": txn.payment_captured,
                        "final_charge": txn.final_value.final_charge if txn.final_value else "",
                    }
                )

    # -- Parquet (optional) --------------------------------------------------

    def _append_parquet(self, txn: Transaction) -> None:
        try:
            import pandas as pd  # type: ignore
        except ImportError:
            # No pandas/pyarrow available in this environment -- Parquet
            # export is a best-effort convenience, not a hard requirement.
            return

        rows = [
            {
                "timestamp": m.timestamp,
                "meter_id": m.meter_id,
                "transaction_id": txn.transaction_id,
                "fuel_code": txn.fuel_code,
                "raw_pulses": m.raw_pulses,
                "accumulated_volume": m.accumulated_volume,
                "instantaneous_flow_rate": m.instantaneous_flow_rate,
                "temperature": m.temperature,
                "calibration_factor_applied": m.calibration_factor_applied,
                "measurement_quality": m.measurement_quality,
            }
            for m in txn.measurements
        ]
        if not rows:
            return
        new_df = pd.DataFrame(rows)
        path = Path(self.parquet_path)  # type: ignore[arg-type]
        if path.exists():
            existing = pd.read_parquet(path)
            new_df = pd.concat([existing, new_df], ignore_index=True)
        new_df.to_parquet(path)

    # -- read-back helpers for analytics -------------------------------

    def fetch_all_transactions(self) -> List[dict]:
        cursor = self._conn.execute("SELECT record_json FROM transactions")
        return [json.loads(row[0]) for row in cursor.fetchall()]
