"""
payment.nfc
============

Aardvark NFC payment integration: an NFC-flavoured
:class:`~fuelflow.payment.terminal.PaymentTerminal` that models an
"Aardvark payment token" tap. Like the base terminal, it deals only in
opaque tokens -- the simulated NFC tag UID never leaves this module and
is never persisted alongside metrology/transaction data.
"""

from __future__ import annotations

import hashlib
import uuid
from dataclasses import dataclass
from decimal import Decimal

from fuelflow.payment.terminal import (
    AuthorizationStatus,
    CaptureResult,
    PaymentAuthorization,
    PaymentMethod,
    PaymentTerminal,
)


@dataclass(frozen=True)
class NfcTapEvent:
    """
    A simulated NFC tap. `tag_uid` stands in for whatever raw identifier
    the physical NFC hardware reads -- it is hashed immediately and never
    stored or forwarded in the clear.
    """

    tag_uid: str
    is_aardvark_token: bool = True


class AardvarkNfcTerminal(PaymentTerminal):
    """
    Simulated Aardvark NFC payment terminal.

        NFC tap -> Payment Authorisation -> Fuel Transaction -> Meter
            -> Final Amount -> Payment Capture -> Receipt
    """

    def __init__(self, decline: bool = False):
        self._decline = decline

    @staticmethod
    def _tokenize(tap: NfcTapEvent) -> str:
        digest = hashlib.sha256(tap.tag_uid.encode("utf-8")).hexdigest()[:20]
        prefix = "avk" if tap.is_aardvark_token else "nfc"
        return f"{prefix}_{digest}"

    def authorize_tap(self, tap: NfcTapEvent, estimated_amount: Decimal, currency_code: str) -> PaymentAuthorization:
        method = PaymentMethod.AARDVARK_TOKEN if tap.is_aardvark_token else PaymentMethod.NFC
        status = AuthorizationStatus.DECLINED if self._decline else AuthorizationStatus.APPROVED
        return PaymentAuthorization(
            authorization_id=str(uuid.uuid4()),
            method=method,
            token_reference=self._tokenize(tap),
            status=status,
            hold_amount=estimated_amount,
            currency_code=currency_code,
        )

    # -- PaymentTerminal interface --------------------------------------

    def authorize(self, method: PaymentMethod, estimated_amount: Decimal, currency_code: str) -> PaymentAuthorization:
        # Generic entry point: synthesises a tap for interface compatibility.
        return self.authorize_tap(NfcTapEvent(tag_uid=str(uuid.uuid4())), estimated_amount, currency_code)

    def capture(self, authorization: PaymentAuthorization, final_amount: Decimal) -> CaptureResult:
        if authorization.status != AuthorizationStatus.APPROVED:
            return CaptureResult(
                authorization_id=authorization.authorization_id,
                captured_amount=Decimal("0.00"),
                currency_code=authorization.currency_code,
                success=False,
                receipt_reference="",
            )
        return CaptureResult(
            authorization_id=authorization.authorization_id,
            captured_amount=final_amount,
            currency_code=authorization.currency_code,
            success=True,
            receipt_reference=f"rcpt_{uuid.uuid4().hex[:12]}",
        )

    def void(self, authorization: PaymentAuthorization) -> None:
        return None
