"""
payment.terminal
==================

Abstract payment interface. FuelFlow never stores raw payment
credentials (PAN, track data, wallet secrets) -- only opaque,
already-tokenised references handed back by the terminal/acquirer, per
FuelFlow section 11.

    NFC -> Payment Authorisation -> Fuel Transaction -> Meter
        -> Final Amount -> Payment Capture -> Receipt
"""

from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass
from decimal import Decimal
from enum import Enum


class PaymentMethod(str, Enum):
    NFC = "NFC"
    CONTACTLESS_CARD = "CONTACTLESS_CARD"
    MOBILE_WALLET = "MOBILE_WALLET"
    AARDVARK_TOKEN = "AARDVARK_TOKEN"


class AuthorizationStatus(str, Enum):
    APPROVED = "APPROVED"
    DECLINED = "DECLINED"
    ERROR = "ERROR"


@dataclass(frozen=True)
class PaymentAuthorization:
    """
    A pre-authorisation hold. `token_reference` is an opaque acquirer/
    tokenisation-vault reference -- never a PAN, CVV, or raw card/wallet
    credential.
    """

    authorization_id: str
    method: PaymentMethod
    token_reference: str
    status: AuthorizationStatus
    hold_amount: Decimal
    currency_code: str


@dataclass(frozen=True)
class CaptureResult:
    authorization_id: str
    captured_amount: Decimal
    currency_code: str
    success: bool
    receipt_reference: str


class PaymentTerminal(ABC):
    """Abstract payment terminal interface."""

    @abstractmethod
    def authorize(self, method: PaymentMethod, estimated_amount: Decimal, currency_code: str) -> PaymentAuthorization:
        """Place a pre-authorisation hold for (at least) the estimated amount."""

    @abstractmethod
    def capture(self, authorization: PaymentAuthorization, final_amount: Decimal) -> CaptureResult:
        """Capture the final, reconciled transaction amount against a prior authorisation."""

    @abstractmethod
    def void(self, authorization: PaymentAuthorization) -> None:
        """Release a hold without capturing (e.g. on transaction cancellation)."""


class MockPaymentTerminal(PaymentTerminal):
    """
    A deterministic in-memory terminal for simulation/testing. Never used
    against a real acquirer -- production deployments implement
    :class:`PaymentTerminal` against the certified payment stack.
    """

    def __init__(self, decline: bool = False):
        self._decline = decline

    def authorize(self, method: PaymentMethod, estimated_amount: Decimal, currency_code: str) -> PaymentAuthorization:
        status = AuthorizationStatus.DECLINED if self._decline else AuthorizationStatus.APPROVED
        return PaymentAuthorization(
            authorization_id=str(uuid.uuid4()),
            method=method,
            token_reference=f"tok_{uuid.uuid4().hex[:16]}",
            status=status,
            hold_amount=estimated_amount,
            currency_code=currency_code,
        )

    def capture(self, authorization: PaymentAuthorization, final_amount: Decimal) -> CaptureResult:
        if authorization.status != AuthorizationStatus.APPROVED:
            return CaptureResult(
                authorization_id=authorization.authorization_id,
                captured_amount=Decimal("0.00"),
                currency_code=authorization.currency_code,
                success=False,
                receipt_reference="",
            )
        return CaptureResult(
            authorization_id=authorization.authorization_id,
            captured_amount=final_amount,
            currency_code=authorization.currency_code,
            success=True,
            receipt_reference=f"rcpt_{uuid.uuid4().hex[:12]}",
        )

    def void(self, authorization: PaymentAuthorization) -> None:
        return None
