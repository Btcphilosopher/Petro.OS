"""
optimisation.measurement_optimizer
=====================================

Investigates how measurement quality (bias, standard deviation) changes
with acquisition sampling frequency and filter smoothing, subject to a
real-time processing budget, per FuelFlow section 16. The objective is
to minimise measurement uncertainty while keeping each acquisition tick
cheap enough to process in real time.

This runs a lightweight, direct simulation of the filter/pulse-count
stage (not a full transaction) so a broad parameter sweep stays fast
enough to run interactively.
"""

from __future__ import annotations

import random
import time
from dataclasses import dataclass
from typing import List, Sequence

from fuelflow.metrology.pulse_counter import pulses_from_flow_rate
from fuelflow.metrology.volume_engine import PulseFilter


@dataclass(frozen=True)
class MeasurementQualityResult:
    sample_period_s: float
    filter_alpha: float
    mean_error: float
    std_dev: float
    mean_processing_time_s: float  # proxy for real-time feasibility
    within_real_time_budget: bool


class MeasurementOptimizer:
    def __init__(self, real_time_budget_s: float = 0.02, rng: random.Random | None = None):
        """`real_time_budget_s` is the maximum acceptable per-tick processing time."""
        self.real_time_budget_s = real_time_budget_s
        self.rng = rng or random.Random(2024)

    def evaluate(
        self,
        sample_period_s: float,
        filter_alpha: float,
        pulses_per_unit_volume: float,
        nominal_flow_rate: float,
        pulse_jitter_std_fraction: float,
        n_ticks: int = 400,
    ) -> MeasurementQualityResult:
        pulse_filter = PulseFilter(alpha=filter_alpha)
        errors: List[float] = []
        processing_times: List[float] = []

        for _ in range(n_ticks):
            ideal_pulses = pulses_from_flow_rate(nominal_flow_rate, sample_period_s, pulses_per_unit_volume)
            jitter = 1.0 + self.rng.gauss(0.0, pulse_jitter_std_fraction)
            noisy_pulses = ideal_pulses * max(jitter, 0.0)

            start = time.perf_counter()
            raw_rate_hz = noisy_pulses / sample_period_s
            filtered_rate_hz = pulse_filter.apply(raw_rate_hz)
            filtered_pulses = filtered_rate_hz * sample_period_s
            processing_times.append(time.perf_counter() - start)

            errors.append((filtered_pulses - ideal_pulses) / ideal_pulses if ideal_pulses else 0.0)

        mean_error = sum(errors) / len(errors)
        variance = sum((e - mean_error) ** 2 for e in errors) / len(errors)
        std_dev = variance**0.5
        mean_processing_time_s = sum(processing_times) / len(processing_times)

        return MeasurementQualityResult(
            sample_period_s=sample_period_s,
            filter_alpha=filter_alpha,
            mean_error=mean_error,
            std_dev=std_dev,
            mean_processing_time_s=mean_processing_time_s,
            within_real_time_budget=mean_processing_time_s < self.real_time_budget_s
            and sample_period_s > mean_processing_time_s,
        )

    def sweep(
        self,
        sample_periods_s: Sequence[float],
        filter_alphas: Sequence[float],
        pulses_per_unit_volume: float,
        nominal_flow_rate: float,
        pulse_jitter_std_fraction: float,
    ) -> List[MeasurementQualityResult]:
        results = [
            self.evaluate(dt, alpha, pulses_per_unit_volume, nominal_flow_rate, pulse_jitter_std_fraction)
            for dt in sample_periods_s
            for alpha in filter_alphas
        ]
        return results

    @staticmethod
    def best(results: Sequence[MeasurementQualityResult]) -> MeasurementQualityResult:
        """Lowest standard deviation among candidates that fit the real-time budget."""
        feasible = [r for r in results if r.within_real_time_budget]
        pool = feasible or list(results)
        return min(pool, key=lambda r: r.std_dev)
