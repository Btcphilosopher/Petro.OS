"""
optimisation.calibration_optimizer
=====================================

Given a set of historical (reference, measured) volume pairs from wet
calibration tests, finds the calibration factor that minimises the
residual bias -- i.e. the factor a technician should actually enter,
rather than trusting a single test in isolation.

This never bypasses or "improves away" a required calibration test: it
is a fitting aid over *already-collected* certified reference
measurements (see :mod:`fuelflow.calibration.calibration_test`), used to
decide the best single correction factor across several such tests.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Sequence

from fuelflow.calibration.calibration_test import CalibrationTestResult


@dataclass(frozen=True)
class CalibrationOptimizationResult:
    least_squares_factor: float
    mean_ratio_factor: float
    residual_bias_before: float  # mean relative error using factor=1.0 (raw meter)
    residual_bias_after: float  # mean relative error using the optimised factor


class CalibrationOptimizer:
    def fit(self, tests: Sequence[CalibrationTestResult]) -> CalibrationOptimizationResult:
        if not tests:
            raise ValueError("Need at least one calibration test result")

        references = [t.reference_volume for t in tests]
        measured = [t.meter_reported_volume for t in tests]

        # Ordinary least squares fit of `reference = factor * measured`,
        # forced through the origin (a physically-sensible constraint --
        # zero measured volume must imply zero reference volume).
        numerator = sum(r * m for r, m in zip(references, measured))
        denominator = sum(m * m for m in measured)
        least_squares_factor = numerator / denominator if denominator else 1.0

        # Simple mean-of-ratios factor, useful as a sanity cross-check
        # against the least-squares fit above.
        mean_ratio_factor = sum(r / m for r, m in zip(references, measured) if m) / len(tests)

        residual_bias_before = self._mean_relative_error(references, measured, factor=1.0)
        residual_bias_after = self._mean_relative_error(references, measured, factor=least_squares_factor)

        return CalibrationOptimizationResult(
            least_squares_factor=least_squares_factor,
            mean_ratio_factor=mean_ratio_factor,
            residual_bias_before=residual_bias_before,
            residual_bias_after=residual_bias_after,
        )

    @staticmethod
    def _mean_relative_error(references: List[float], measured: List[float], factor: float) -> float:
        errors = [(m * factor - r) / r for r, m in zip(references, measured) if r]
        return sum(errors) / len(errors) if errors else 0.0
