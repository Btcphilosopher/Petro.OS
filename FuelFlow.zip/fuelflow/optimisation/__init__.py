"""FuelFlow subpackage: optimisation"""
