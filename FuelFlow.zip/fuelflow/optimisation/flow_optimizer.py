"""
optimisation.flow_optimizer
==============================

Investigates how commanded flow rate and acquisition tick size affect
end-of-dispense overshoot (the amount by which the final charge exceeds
the requested target once discrete pulses/ticks are accounted for) and
total dispense time, per FuelFlow section 16.

FuelFlow never controls the physical flow valve -- that is certified
dispenser hardware. This module answers the *analysis* question "how
would a given flow-rate/tick-size operating point affect measurement
outcomes", which a real target-value controller's throttling schedule
would be tuned against.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import List, Sequence

from fuelflow.core.configuration import MeterConfig, RegionPricingConfig
from fuelflow.metrology.calibration import CalibrationState
from fuelflow.simulation.dispenser_simulator import run_transaction
from fuelflow.simulation.scenarios import FlowProfileShape, Scenario


@dataclass(frozen=True)
class FlowOperatingPointResult:
    flow_rate: float
    dt_s: float
    mean_overshoot: Decimal
    max_overshoot: Decimal
    mean_dispense_duration_s: float
    n_trials: int


class FlowOptimizer:
    def evaluate_operating_point(
        self,
        meter_config: MeterConfig,
        calibration_state: CalibrationState,
        fuel_code: str,
        unit_price: Decimal,
        region: RegionPricingConfig,
        target_amount: Decimal,
        flow_rate: float,
        dt_s: float,
        n_trials: int = 10,
        base_seed: int = 5000,
    ) -> FlowOperatingPointResult:
        scenario = Scenario(
            name=f"flow_{flow_rate:.1f}_dt_{dt_s:.2f}",
            flow_profile=FlowProfileShape.CONSTANT,
            nominal_flow_rate=flow_rate,
            dt_s=dt_s,
        )

        overshoots: List[Decimal] = []
        durations: List[float] = []

        for i in range(n_trials):
            result = run_transaction(
                meter_config=meter_config,
                calibration_state=calibration_state,
                fuel_code=fuel_code,
                unit_price=unit_price,
                region=region,
                target_amount=target_amount,
                scenario=scenario,
                seed=base_seed + i,
            )
            if result.faulted or result.cancelled:
                continue
            overshoots.append(result.final_charge - target_amount)
            durations.append(result.dispense_duration_s)

        if not overshoots:
            return FlowOperatingPointResult(flow_rate, dt_s, Decimal("0.00"), Decimal("0.00"), 0.0, 0)

        mean_overshoot = sum(overshoots, Decimal("0.00")) / len(overshoots)
        max_overshoot = max(overshoots)
        mean_duration = sum(durations) / len(durations)

        return FlowOperatingPointResult(
            flow_rate=flow_rate,
            dt_s=dt_s,
            mean_overshoot=mean_overshoot,
            max_overshoot=max_overshoot,
            mean_dispense_duration_s=mean_duration,
            n_trials=len(overshoots),
        )

    def sweep(
        self,
        meter_config: MeterConfig,
        calibration_state: CalibrationState,
        fuel_code: str,
        unit_price: Decimal,
        region: RegionPricingConfig,
        target_amount: Decimal,
        flow_rates: Sequence[float],
        dt_s: float = 0.25,
        n_trials: int = 10,
    ) -> List[FlowOperatingPointResult]:
        return [
            self.evaluate_operating_point(
                meter_config, calibration_state, fuel_code, unit_price, region, target_amount, fr, dt_s, n_trials
            )
            for fr in flow_rates
        ]

    @staticmethod
    def recommend(
        results: Sequence[FlowOperatingPointResult], max_overshoot_tolerance: Decimal = Decimal("0.02")
    ) -> FlowOperatingPointResult:
        """
        Among operating points whose mean overshoot stays within
        tolerance, recommend the fastest (highest flow rate / shortest
        dispense time) -- the classic accuracy-vs-throughput trade-off a
        target-value controller's ramp-down schedule is tuned against.
        """
        feasible = [r for r in results if r.n_trials > 0 and abs(r.mean_overshoot) <= max_overshoot_tolerance]
        pool = feasible or [r for r in results if r.n_trials > 0]
        if not pool:
            raise ValueError("No successful trials to recommend from")
        return min(pool, key=lambda r: r.mean_dispense_duration_s)
