"""
metrology.calibration
======================

Applies a meter's calibration correction to a raw measured volume, and
tracks the *state* of calibration (nominal vs actual factor, date,
uncertainty, drift) so the rest of the system never has to assume a
meter reads perfectly.

The authoritative calibration *record keeping* (history, certificates,
test procedures, drift modelling over time) lives in the top-level
:mod:`fuelflow.calibration` package; this module is the runtime
application of whatever the *current* calibration state is, inside the
measurement chain.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
from enum import Enum


class CalibrationValidity(str, Enum):
    IN_DATE = "IN_DATE"
    DUE_SOON = "DUE_SOON"
    OVERDUE = "OVERDUE"
    UNKNOWN = "UNKNOWN"


@dataclass
class CalibrationState:
    """
    The live calibration state attached to a meter measurement.

    `nominal_calibration_factor` is the factory/design value; `actual_
    calibration_factor` is what the last certified calibration test
    actually measured (see :mod:`fuelflow.calibration.calibration_test`)
    and is what is applied to raw volume. They are deliberately kept
    distinct so drift from nominal is always visible.
    """

    meter_id: str
    nominal_calibration_factor: float
    actual_calibration_factor: float
    calibration_date: date
    calibration_interval_days: int = 365
    calibration_uncertainty: float = 0.0015  # relative, e.g. 0.0015 = 0.15%
    meter_drift_per_day: float = 0.0  # relative drift rate applied since calibration_date
    due_soon_window_days: int = 30

    @property
    def next_calibration_date(self) -> date:
        return self.calibration_date + timedelta(days=self.calibration_interval_days)

    def drift_since_calibration(self, as_of: date) -> float:
        """Estimated relative drift (fraction) accumulated since calibration."""
        days = max((as_of - self.calibration_date).days, 0)
        return self.meter_drift_per_day * days

    def effective_calibration_factor(self, as_of: date) -> float:
        """Calibration factor including the modelled drift-to-date."""
        return self.actual_calibration_factor * (1.0 + self.drift_since_calibration(as_of))

    def validity(self, as_of: date) -> CalibrationValidity:
        next_due = self.next_calibration_date
        if as_of > next_due:
            return CalibrationValidity.OVERDUE
        if (next_due - as_of).days <= self.due_soon_window_days:
            return CalibrationValidity.DUE_SOON
        return CalibrationValidity.IN_DATE

    def is_fully_valid(self, as_of: date) -> bool:
        """
        The system must refuse to represent an out-of-calibration
        measurement as fully valid -- this is the single choke point
        every consumer should check before trusting a measurement chain.
        """
        return self.validity(as_of) == CalibrationValidity.IN_DATE


def apply_calibration(raw_volume: float, calibration_state: CalibrationState, as_of: date) -> float:
    """Apply the effective (drift-corrected) calibration factor to a raw volume."""
    return raw_volume * calibration_state.effective_calibration_factor(as_of)
