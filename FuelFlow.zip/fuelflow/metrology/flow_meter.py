"""
metrology.flow_meter
=====================

Abstract and concrete models of certified flow-measurement hardware.

FuelFlow does not replace a certified meter -- it models its pulse output
so that the rest of the stack (pulse acquisition, calibration correction,
temperature compensation, pricing) can be developed, tested and validated
against a realistic, traceable signal chain. In a live deployment, the
`raw_pulses` these classes accumulate are supplied by the certified pulse
transducer's hardware interface, not synthesised.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class MeterTechnology(str, Enum):
    POSITIVE_DISPLACEMENT = "positive_displacement"
    TURBINE = "turbine"
    CORIOLIS = "coriolis"
    PULSE_OUTPUT = "pulse_output"
    ENCODER = "encoder"
    CERTIFIED_EXTERNAL = "certified_external"


class MeterInterface(ABC):
    """
    Abstract interface every certified measurement device (real or
    simulated) must implement so the acquisition layer can treat them
    uniformly regardless of underlying measurement technology.
    """

    meter_id: str
    technology: MeterTechnology
    pulses_per_unit_volume: float
    calibration_factor: float
    maximum_flow_rate: float
    minimum_flow_rate: float

    @abstractmethod
    def pulses_for_volume(self, volume: float) -> float:
        """Theoretical pulse count corresponding to an ideal volume."""

    @abstractmethod
    def is_within_operating_range(self, flow_rate: float) -> bool:
        """Whether a flow rate is within the meter's certified linear range."""


@dataclass
class FlowMeter(MeterInterface):
    """
    Configurable flow-meter model per FuelFlow section 4.

        volume = pulse_count / pulses_per_unit_volume
        corrected_volume = measured_volume * calibration_factor

    The calibration factor is never assumed perfect: it is explicit,
    dated, sourced from :mod:`fuelflow.calibration`, and carries an
    uncertainty (see :mod:`fuelflow.metrology.uncertainty`).
    """

    meter_id: str
    technology: MeterTechnology
    pulses_per_unit_volume: float
    calibration_factor: float = 1.0
    maximum_flow_rate: float = 80.0
    minimum_flow_rate: float = 0.3
    volume_unit: str = "L"
    serial_number: str = ""

    def pulses_for_volume(self, volume: float) -> float:
        return volume * self.pulses_per_unit_volume

    def volume_for_pulses(self, pulse_count: float) -> float:
        """Raw measured volume, before calibration correction."""
        if self.pulses_per_unit_volume <= 0:
            raise ValueError("pulses_per_unit_volume must be positive")
        return pulse_count / self.pulses_per_unit_volume

    def corrected_volume(self, pulse_count: float) -> float:
        """Measured volume with the current calibration factor applied."""
        return self.volume_for_pulses(pulse_count) * self.calibration_factor

    def is_within_operating_range(self, flow_rate: float) -> bool:
        return self.minimum_flow_rate <= flow_rate <= self.maximum_flow_rate

    def max_pulse_frequency_hz(self) -> float:
        """Pulse frequency at maximum rated flow (unit-volume/min)."""
        return (self.maximum_flow_rate / 60.0) * self.pulses_per_unit_volume


# --- Technology-specific specialisations -----------------------------------
#
# In this supervisory layer the technologies mainly differ in their
# operating envelope and expected noise/uncertainty characteristics; those
# differences are captured in the uncertainty and validation layers. The
# subclasses exist so callers can select/construct the right physical
# model explicitly and so type-specific behaviour can be added later
# without touching call sites.


@dataclass
class PositiveDisplacementMeter(FlowMeter):
    technology: MeterTechnology = field(default=MeterTechnology.POSITIVE_DISPLACEMENT, init=False)


@dataclass
class TurbineMeter(FlowMeter):
    technology: MeterTechnology = field(default=MeterTechnology.TURBINE, init=False)
    # Turbine meters typically need a higher minimum flow rate to stay linear.
    minimum_flow_rate: float = 1.0


@dataclass
class CoriolisMeter(FlowMeter):
    technology: MeterTechnology = field(default=MeterTechnology.CORIOLIS, init=False)
    # Coriolis meters measure mass flow directly; density is used to derive
    # volume. `density_kg_per_l` is the live process density reading.
    density_kg_per_l: Optional[float] = None

    def volume_for_pulses(self, pulse_count: float) -> float:
        # A Coriolis meter's "pulses" here represent a frequency output
        # proportional to mass flow; volume requires the live density.
        mass = pulse_count / self.pulses_per_unit_volume
        density = self.density_kg_per_l or 1.0
        return mass / density


@dataclass
class PulseOutputMeter(FlowMeter):
    technology: MeterTechnology = field(default=MeterTechnology.PULSE_OUTPUT, init=False)


@dataclass
class EncoderMeter(FlowMeter):
    """Absolute-position encoder rather than an incremental pulse train."""

    technology: MeterTechnology = field(default=MeterTechnology.ENCODER, init=False)

    def volume_for_pulses(self, pulse_count: float) -> float:
        # For an encoder, `pulse_count` is an absolute encoder position
        # delta already representing accumulated counts since reset.
        return super().volume_for_pulses(pulse_count)


@dataclass
class CertifiedExternalMeter(FlowMeter):
    """
    A meter whose measurement is entirely produced by an external,
    independently certified metrology system (e.g. a legally-verified
    dispenser controller). FuelFlow treats its readings as authoritative
    input and only supervises/reconciles/logs them -- it must never
    recompute or override them.
    """

    technology: MeterTechnology = field(default=MeterTechnology.CERTIFIED_EXTERNAL, init=False)
    authoritative: bool = field(default=True, init=False)
