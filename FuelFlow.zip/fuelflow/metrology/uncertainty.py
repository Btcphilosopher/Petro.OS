"""
metrology.uncertainty
======================

Combines the individual uncertainty contributors in the measurement chain
into a single expanded uncertainty for a delivered volume (and, downstream,
for the monetary value derived from it), using the standard root-sum-of-
squares (RSS) method for independent error sources (GUM-style budgeting,
simplified for a supervisory/demonstration context -- a legally-traceable
uncertainty budget must be established per the applicable national
metrology standard for the physical installation).
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import List


@dataclass(frozen=True)
class UncertaintyComponent:
    name: str
    relative_uncertainty: float  # fraction, e.g. 0.001 == 0.1%
    source: str = ""


@dataclass(frozen=True)
class UncertaintyBudget:
    components: List[UncertaintyComponent]

    def combined_relative_uncertainty(self) -> float:
        """Root-sum-of-squares combination, assuming independent sources."""
        return math.sqrt(sum(c.relative_uncertainty**2 for c in self.components))

    def expanded_uncertainty(self, coverage_factor: float = 2.0) -> float:
        """
        95%-confidence expanded uncertainty (k=2 for an approximately
        normal distribution), as a relative fraction.
        """
        return coverage_factor * self.combined_relative_uncertainty()


def build_volume_uncertainty_budget(
    calibration_uncertainty: float,
    pulse_resolution_uncertainty: float,
    repeatability: float,
    temperature_compensation_uncertainty: float,
) -> UncertaintyBudget:
    """
    Assemble the standard uncertainty contributors for a delivered-volume
    measurement.
    """
    return UncertaintyBudget(
        components=[
            UncertaintyComponent("calibration", calibration_uncertainty, "calibration certificate"),
            UncertaintyComponent("pulse_resolution", pulse_resolution_uncertainty, "pulses-per-unit-volume quantisation"),
            UncertaintyComponent("repeatability", repeatability, "meter repeatability spec"),
            UncertaintyComponent(
                "temperature_compensation", temperature_compensation_uncertainty, "thermal expansion model"
            ),
        ]
    )


def volume_uncertainty_absolute(volume: float, budget: UncertaintyBudget, coverage_factor: float = 2.0) -> float:
    """Expanded uncertainty in absolute volume units."""
    return volume * budget.expanded_uncertainty(coverage_factor)


def value_uncertainty_absolute(
    volume: float, unit_price: float, budget: UncertaintyBudget, coverage_factor: float = 2.0
) -> float:
    """
    Propagate volumetric uncertainty into monetary value. Price itself is
    treated as exact (it is a configured, not measured, quantity), so this
    is simply the volume's relative uncertainty applied to the gross value.
    """
    gross_value = volume * unit_price
    return gross_value * budget.expanded_uncertainty(coverage_factor)
