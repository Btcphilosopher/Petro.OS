"""
metrology.validation
=====================

Redundant plausibility checks over the measurement stream. This is the
system's independent "does this look physically sane" layer, separate
from (and in addition to) whatever safety interlocks the certified
dispenser hardware itself implements.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import List, Optional


class DiagnosticState(str, Enum):
    NORMAL = "NORMAL"
    WARNING = "WARNING"
    DEGRADED = "DEGRADED"
    INVALID = "INVALID"
    SERVICE_REQUIRED = "SERVICE_REQUIRED"


# Ordering used to combine multiple findings into one overall state.
_SEVERITY_ORDER = [
    DiagnosticState.NORMAL,
    DiagnosticState.WARNING,
    DiagnosticState.DEGRADED,
    DiagnosticState.INVALID,
    DiagnosticState.SERVICE_REQUIRED,
]


@dataclass(frozen=True)
class ValidationFinding:
    check: str
    state: DiagnosticState
    detail: str = ""


@dataclass
class MeasurementSample:
    """A snapshot of everything the validator needs to reason about."""

    timestamp: float
    pulse_frequency_hz: float
    flow_rate: float  # unit-volume / min
    accumulated_volume: float
    previous_accumulated_volume: float
    temperature_c: float
    pressure_kpa: Optional[float]
    meter_status_ok: bool
    nozzle_lifted: bool
    transaction_active: bool
    dt_s: float
    maximum_flow_rate: float
    minimum_flow_rate: float
    communication_ok: bool = True
    secondary_volume_estimate: Optional[float] = None  # from a redundant sensor/model, if available


@dataclass
class SensorValidator:
    """
    Runs a battery of independent plausibility checks against a
    :class:`MeasurementSample` and produces a combined diagnostic state.
    """

    max_flow_margin: float = 1.10  # allow 10% over rated max before flagging DEGRADED
    max_plausible_volume_jump_factor: float = 3.0  # vs. expected volume from flow*dt
    measurement_disagreement_tolerance: float = 0.02  # 2% relative, vs redundant estimate
    pulse_dropout_frequency_floor_hz: float = 0.0

    def evaluate(self, sample: MeasurementSample) -> List[ValidationFinding]:
        findings: List[ValidationFinding] = []

        findings.append(self._check_negative_flow(sample))
        findings.append(self._check_impossible_flow(sample))
        findings.append(self._check_missing_pulses(sample))
        findings.append(self._check_pulse_spike(sample))
        findings.append(self._check_communication(sample))
        findings.append(self._check_meter_status(sample))
        findings.append(self._check_volume_jump(sample))
        if sample.secondary_volume_estimate is not None:
            findings.append(self._check_measurement_disagreement(sample))

        return findings

    def overall_state(self, findings: List[ValidationFinding]) -> DiagnosticState:
        worst = DiagnosticState.NORMAL
        for f in findings:
            if _SEVERITY_ORDER.index(f.state) > _SEVERITY_ORDER.index(worst):
                worst = f.state
        return worst

    # -- individual checks ---------------------------------------------

    def _check_negative_flow(self, s: MeasurementSample) -> ValidationFinding:
        if s.flow_rate < 0:
            return ValidationFinding("negative_flow", DiagnosticState.INVALID, f"flow_rate={s.flow_rate}")
        return ValidationFinding("negative_flow", DiagnosticState.NORMAL)

    def _check_impossible_flow(self, s: MeasurementSample) -> ValidationFinding:
        if s.flow_rate > s.maximum_flow_rate * self.max_flow_margin:
            return ValidationFinding(
                "impossible_flow",
                DiagnosticState.INVALID,
                f"flow_rate={s.flow_rate} exceeds {self.max_flow_margin:.0%} of rated max {s.maximum_flow_rate}",
            )
        if s.flow_rate > s.maximum_flow_rate:
            return ValidationFinding(
                "impossible_flow", DiagnosticState.DEGRADED, f"flow_rate={s.flow_rate} exceeds rated max"
            )
        return ValidationFinding("impossible_flow", DiagnosticState.NORMAL)

    def _check_missing_pulses(self, s: MeasurementSample) -> ValidationFinding:
        # Flow is reported but the pulse train has gone silent -- classic
        # "stuck sensor" / dropout signature.
        if s.transaction_active and s.flow_rate > s.minimum_flow_rate and s.pulse_frequency_hz <= self.pulse_dropout_frequency_floor_hz:
            return ValidationFinding(
                "missing_pulses", DiagnosticState.SERVICE_REQUIRED, "flow reported but no pulses observed"
            )
        return ValidationFinding("missing_pulses", DiagnosticState.NORMAL)

    def _check_pulse_spike(self, s: MeasurementSample) -> ValidationFinding:
        # A frequency implying a flow rate far beyond the meter's physical
        # linear range is almost certainly electrical noise, not fuel.
        implied_max_hz = s.maximum_flow_rate * self.max_flow_margin
        if s.pulse_frequency_hz > 0 and implied_max_hz > 0 and s.flow_rate == 0 and s.pulse_frequency_hz > 1.0:
            return ValidationFinding(
                "pulse_spike", DiagnosticState.WARNING, "pulses observed with zero derived flow"
            )
        return ValidationFinding("pulse_spike", DiagnosticState.NORMAL)

    def _check_communication(self, s: MeasurementSample) -> ValidationFinding:
        if not s.communication_ok:
            return ValidationFinding("communication_loss", DiagnosticState.SERVICE_REQUIRED, "meter link down")
        return ValidationFinding("communication_loss", DiagnosticState.NORMAL)

    def _check_meter_status(self, s: MeasurementSample) -> ValidationFinding:
        if not s.meter_status_ok:
            return ValidationFinding("meter_status", DiagnosticState.INVALID, "meter self-report unhealthy")
        return ValidationFinding("meter_status", DiagnosticState.NORMAL)

    def _check_volume_jump(self, s: MeasurementSample) -> ValidationFinding:
        delta = s.accumulated_volume - s.previous_accumulated_volume
        if delta < 0:
            return ValidationFinding("unexpected_volume_jump", DiagnosticState.INVALID, "accumulated volume decreased")
        expected = s.flow_rate * (s.dt_s / 60.0)
        if expected <= 0:
            if delta > 1e-6:
                return ValidationFinding(
                    "unexpected_volume_jump", DiagnosticState.WARNING, "volume increased with no commanded flow"
                )
            return ValidationFinding("unexpected_volume_jump", DiagnosticState.NORMAL)
        if delta > expected * self.max_plausible_volume_jump_factor:
            return ValidationFinding(
                "unexpected_volume_jump",
                DiagnosticState.DEGRADED,
                f"delta={delta:.4f} exceeds {self.max_plausible_volume_jump_factor}x expected {expected:.4f}",
            )
        return ValidationFinding("unexpected_volume_jump", DiagnosticState.NORMAL)

    def _check_measurement_disagreement(self, s: MeasurementSample) -> ValidationFinding:
        primary = s.accumulated_volume
        secondary = s.secondary_volume_estimate or 0.0
        if primary <= 0:
            return ValidationFinding("measurement_disagreement", DiagnosticState.NORMAL)
        relative_diff = abs(primary - secondary) / primary
        if relative_diff > self.measurement_disagreement_tolerance:
            return ValidationFinding(
                "measurement_disagreement",
                DiagnosticState.WARNING,
                f"primary/secondary differ by {relative_diff:.2%}",
            )
        return ValidationFinding("measurement_disagreement", DiagnosticState.NORMAL)
