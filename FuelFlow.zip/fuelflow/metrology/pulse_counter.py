"""
metrology.pulse_counter
========================

Pulse acquisition and frequency estimation. This is the lowest layer of
the measurement chain: it only knows about raw pulse edges and elapsed
time -- no calibration, no temperature, no pricing.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Deque, Tuple


@dataclass
class PulseCounter:
    """
    Accumulates raw pulses from a meter's transducer and derives an
    instantaneous frequency estimate from a short rolling window, which
    is what a real acquisition front-end (FPGA/microcontroller) would
    hand up to the supervisory layer.
    """

    window_s: float = 1.0
    _total_pulses: float = 0.0
    _window: Deque[Tuple[float, float]] = field(default_factory=deque)  # (timestamp, pulses)

    @property
    def total_pulses(self) -> float:
        return self._total_pulses

    def accumulate(self, timestamp: float, pulse_count: float) -> None:
        """Register `pulse_count` pulses observed at `timestamp`."""
        if pulse_count < 0:
            raise ValueError("Pulse count cannot be negative (see validation layer for spike/anomaly handling)")
        self._total_pulses += pulse_count
        self._window.append((timestamp, pulse_count))
        cutoff = timestamp - self.window_s
        while self._window and self._window[0][0] < cutoff:
            self._window.popleft()

    def instantaneous_frequency_hz(self, timestamp: float) -> float:
        """Pulses-per-second averaged over the rolling window."""
        if not self._window:
            return 0.0
        earliest = self._window[0][0]
        span = max(timestamp - earliest, 1e-6)
        pulses_in_window = sum(p for _, p in self._window)
        return pulses_in_window / span

    def reset(self) -> None:
        self._total_pulses = 0.0
        self._window.clear()


def pulses_from_flow_rate(
    flow_rate_per_min: float, dt_s: float, pulses_per_unit_volume: float
) -> float:
    """
    Convert an instantaneous flow rate (unit-volume/min) over an elapsed
    time step into an ideal (noise-free) pulse count -- used by the
    simulator, and useful when bench-testing acquisition code without
    physical hardware.
    """
    volume = flow_rate_per_min * (dt_s / 60.0)
    return volume * pulses_per_unit_volume
