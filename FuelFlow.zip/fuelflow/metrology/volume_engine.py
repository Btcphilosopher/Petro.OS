"""
metrology.volume_engine
=========================

The traceable measurement pipeline:

    raw pulses -> filter -> calibration factor -> temperature correction
        -> volume

Every step produces a :class:`FlowMeasurement` record so the full chain
from raw pulses to a reported volume is auditable, per FuelFlow section 2/3.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import List, Optional

from fuelflow.metrology.calibration import CalibrationState
from fuelflow.metrology.flow_meter import FlowMeter
from fuelflow.metrology.pulse_counter import PulseCounter
from fuelflow.metrology.validation import DiagnosticState


@dataclass
class FlowMeasurement:
    """
    A single, fully-traceable measurement sample, per FuelFlow section 2.
    """

    timestamp: float
    raw_pulses: float
    pulse_frequency: float
    instantaneous_flow_rate: float
    accumulated_volume: float
    temperature: float
    density: float
    meter_id: str
    calibration_state: str  # CalibrationValidity value, snapshotted as a string
    measurement_quality: str  # DiagnosticState value, snapshotted as a string

    # -- traceability: every transformation the raw pulses passed through
    filtered_pulses: Optional[float] = None
    calibration_factor_applied: Optional[float] = None
    raw_volume: Optional[float] = None
    calibrated_volume: Optional[float] = None
    temperature_corrected_volume: Optional[float] = None


class PulseFilter:
    """
    Simple exponential moving-average filter over instantaneous pulse
    rate, used to reject high-frequency electrical noise before it
    reaches the calibration/volume stage. A real implementation would
    tune `alpha` (and possibly add a median/despike stage) against the
    specific transducer's noise spectrum; see
    :mod:`fuelflow.optimisation.measurement_optimizer`.
    """

    def __init__(self, alpha: float = 0.35):
        if not (0.0 < alpha <= 1.0):
            raise ValueError("alpha must be in (0, 1]")
        self.alpha = alpha
        self._state: Optional[float] = None

    def apply(self, raw_value: float) -> float:
        if self._state is None:
            self._state = raw_value
        else:
            self._state = self.alpha * raw_value + (1 - self.alpha) * self._state
        return self._state

    def reset(self) -> None:
        self._state = None


@dataclass
class VolumeEngine:
    """
    Owns the running accumulated volume for one meter and produces a
    :class:`FlowMeasurement` for each acquisition tick.
    """

    meter: FlowMeter
    calibration_state: CalibrationState
    pulse_filter: PulseFilter = field(default_factory=PulseFilter)
    pulse_counter: PulseCounter = field(default_factory=PulseCounter)

    _accumulated_raw_volume: float = 0.0
    _accumulated_calibrated_volume: float = 0.0
    history: List[FlowMeasurement] = field(default_factory=list)

    def reset_transaction(self) -> None:
        self._accumulated_raw_volume = 0.0
        self._accumulated_calibrated_volume = 0.0
        self.pulse_filter.reset()
        self.pulse_counter.reset()

    def process_tick(
        self,
        timestamp: float,
        raw_pulses_in_tick: float,
        dt_s: float,
        temperature_c: float,
        density_kg_per_l: float,
        as_of: Optional[date] = None,
        measurement_quality: DiagnosticState = DiagnosticState.NORMAL,
    ) -> FlowMeasurement:
        """
        Feed one acquisition tick's worth of raw pulses through the full
        filter -> calibration -> volume chain and return a traceable
        :class:`FlowMeasurement`.
        """
        as_of = as_of or date.today()

        self.pulse_counter.accumulate(timestamp, raw_pulses_in_tick)

        # filter stage: smooth instantaneous rate, not the accumulator
        raw_rate_hz = raw_pulses_in_tick / dt_s if dt_s > 0 else 0.0
        filtered_rate_hz = self.pulse_filter.apply(raw_rate_hz)
        filtered_pulses_in_tick = filtered_rate_hz * dt_s

        raw_volume_delta = self.meter.volume_for_pulses(filtered_pulses_in_tick)
        self._accumulated_raw_volume += raw_volume_delta

        calibration_factor = self.calibration_state.effective_calibration_factor(as_of)
        calibrated_volume_delta = raw_volume_delta * calibration_factor
        self._accumulated_calibrated_volume += calibrated_volume_delta

        instantaneous_flow_rate = (calibrated_volume_delta / dt_s) * 60.0 if dt_s > 0 else 0.0
        pulse_frequency = self.pulse_counter.instantaneous_frequency_hz(timestamp)

        measurement = FlowMeasurement(
            timestamp=timestamp,
            raw_pulses=self.pulse_counter.total_pulses,
            pulse_frequency=pulse_frequency,
            instantaneous_flow_rate=instantaneous_flow_rate,
            accumulated_volume=self._accumulated_calibrated_volume,
            temperature=temperature_c,
            density=density_kg_per_l,
            meter_id=self.meter.meter_id,
            calibration_state=self.calibration_state.validity(as_of).value,
            measurement_quality=measurement_quality.value,
            filtered_pulses=filtered_pulses_in_tick,
            calibration_factor_applied=calibration_factor,
            raw_volume=self._accumulated_raw_volume,
            calibrated_volume=self._accumulated_calibrated_volume,
        )
        self.history.append(measurement)
        return measurement

    @property
    def accumulated_calibrated_volume(self) -> float:
        return self._accumulated_calibrated_volume
