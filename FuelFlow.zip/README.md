# Aardvark FuelFlow

A high-precision digital metrology, pricing and transaction engine for a
modern petrol-station fuel dispenser.

**FuelFlow is a supervisory computation, telemetry, validation,
digital-twin, diagnostics and transaction layer. It is not a substitute
for certified metrology hardware (the physical positive-displacement /
turbine / Coriolis meter and its certified pulse transducer, calibrated
and sealed per the applicable weights-and-measures regulation) or for
safety-critical dispenser controls (solenoid valves, overfill
protection, emergency stops, vapour recovery interlocks). Those remain
the authoritative, certified systems in any real installation. FuelFlow
models, supervises, cross-checks, prices and reconciles their output.**

## What it answers

> How much fuel was dispensed, at what price, and what monetary value
> does that represent?

Given a target transaction of **$10.00** at **$3.499/gallon**, FuelFlow
*calculates* (never hard-codes) the target volume of **≈2.858 gallons**,
tracks the live dispense against that target tick-by-tick, and produces
an explicit, fully-traceable end-of-dispense reconciliation:

```
TARGET VALUE       $10.00
UNIT PRICE         $3.499/gal
DELIVERED          2.858 gal
CALCULATED VALUE   $10.000142...
ROUNDING ADJUST.   -0.000142
FINAL CHARGE       $10.00
```

## Design principles

- **Decimal for money, always.** Every price, tax, discount and charge
  is `decimal.Decimal`. Physical quantities (volume, flow rate,
  temperature) use `float`; the conversion from a measured volume to a
  priced value happens at one explicit, auditable boundary
  (`fuelflow.pricing`).
- **Traceable measurement chain.** Every `FlowMeasurement` records raw
  pulses, the filtered pulse count, the calibration factor applied, raw
  volume and calibrated volume -- nothing is silently transformed.
- **Calibration is never assumed perfect.** A meter's nominal and actual
  calibration factors, calibration date, uncertainty and modelled drift
  are explicit, dated, and checked (`fuelflow.metrology.calibration`,
  `fuelflow.calibration`). Out-of-calibration measurements are never
  reported as fully valid.
- **Requested value, target volume, delivered volume and charged value
  are four distinct quantities**, never silently conflated
  (`fuelflow.dispensing.target_value`).
- **Configuration, not constants.** Thermal expansion coefficients,
  pulses-per-unit-volume, calibration intervals, currency rounding rules
  and tax rates are all configuration objects
  (`fuelflow.core.configuration`), never magic numbers buried in logic.
- **No raw payment credentials.** The payment layer deals only in
  opaque, already-tokenised references (`fuelflow.payment`).

## Project layout

```
fuelflow/
├── core/            engine orchestration, clock, state machine, configuration
├── metrology/        flow meter models, pulse acquisition, calibration application,
│                     uncertainty budgeting, sensor validation
├── fuel/             fuel-grade config, temperature compensation, density
├── pricing/           Decimal price engine, currency rounding, transaction value
├── dispensing/        dispenser/nozzle/transaction, target-value engine
├── sensors/           sensor model, temperature sensor, diagnostics aggregation
├── payment/            abstract payment terminal + Aardvark NFC integration
├── digital_twin/       FuelDispenserDigitalTwin, full physical-state mirror
├── calibration/         calibration record/history/test/drift-model subsystem
├── optimisation/       calibration/measurement/flow optimisers
├── simulation/          scenario definitions, transaction simulator, Monte Carlo
├── storage/             SQLite/CSV/Parquet transaction historian
├── analytics/           accuracy statistics and reports
├── tests/                pytest suite
└── main.py               demonstration entry point
```

## Running the demo

```bash
pip install -r requirements.txt   # only needed for pytest
python -m fuelflow.main           # or: python fuelflow/main.py
python -m fuelflow.main --full    # + Monte-Carlo accuracy run + optimisers
```

This runs the FuelFlow section-18 worked example end to end: a $10.00
target transaction on Petrol 95 at $3.499/gallon, streamed through the
full pulse -> calibration -> temperature -> volume -> price ->
target-value-controller -> reconciliation -> payment-capture ->
digital-twin pipeline, then writes a machine-readable transaction record
(JSON) plus a SQLite/CSV historian log to `fuelflow/demo_output/`.

## Running the tests

```bash
pytest fuelflow/tests -v
```

## Simulation & Monte Carlo

`fuelflow.simulation` can run thousands of deterministic, seeded
transactions across scenarios (slow/normal/high-flow/variable flow,
temperature variation, sensor noise, pulse jitter, meter drift, sensor
failure, communication failure, transaction cancellation) and report
mean error, maximum error, bias, repeatability, standard deviation and
rounding error via `fuelflow.analytics.accuracy`:

```python
from datetime import date
from decimal import Decimal
from fuelflow.core.configuration import DEFAULT_CURRENCIES, RegionPricingConfig, default_meter
from fuelflow.metrology.calibration import CalibrationState
from fuelflow.simulation.monte_carlo import run_monte_carlo
from fuelflow.simulation.scenarios import ALL_SCENARIOS

meter_config = default_meter()
calibration_state = CalibrationState(
    meter_id=meter_config.meter_id,
    nominal_calibration_factor=1.0,
    actual_calibration_factor=1.0006,
    calibration_date=date(2026, 3, 1),
)
region = RegionPricingConfig(region_code="US-DEFAULT", currency=DEFAULT_CURRENCIES["USD"], tax_rate=Decimal("0"))

result = run_monte_carlo(
    meter_config, calibration_state, "PETROL_95", Decimal("3.499"), region,
    target_amount=Decimal("10.00"), scenarios=ALL_SCENARIOS, n_per_scenario=200,
)
print(result.volume_accuracy, result.monetary_rounding_accuracy)
```

## Optimisation

`fuelflow.optimisation` explores how measurement quality changes with
sampling frequency, filter smoothing, and flow-rate operating points,
and fits an optimal calibration factor from a set of wet calibration
tests -- always as an *analysis and fitting* aid over already-collected
certified measurements, never as a way to bypass, defeat, or alter a
legally required dispenser control.
