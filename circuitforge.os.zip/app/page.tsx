'use client';

import React, { useEffect, useState } from 'react';
import {
  TrackDigitalTwinState,
  StudioMode,
  CameraMode,
  OverlayMode,
  ScenarioType
} from '@/lib/circuitforge/types';
import { digitalTwinStore } from '@/lib/circuitforge/digitalTwinStream';
import { ThreeCanvas } from '@/components/circuitforge/ThreeCanvas';
import { StudioNavbar } from '@/components/circuitforge/StudioNavbar';
import { DesignPanel } from '@/components/circuitforge/DesignPanel';
import { TelemetryPanel } from '@/components/circuitforge/TelemetryPanel';
import { RAnalyticsPanel } from '@/components/circuitforge/RAnalyticsPanel';
import { ConstructionPanel } from '@/components/circuitforge/ConstructionPanel';
import { OptimisationModal } from '@/components/circuitforge/OptimisationModal';
import { ExportModal } from '@/components/circuitforge/ExportModal';
import { ReportModal } from '@/components/circuitforge/ReportModal';
import { AlertTriangle, X, Eye, Sliders, Layers, Maximize2 } from 'lucide-react';

export default function CircuitForgeStudioPage() {
  const [twinState, setTwinState] = useState<TrackDigitalTwinState>(digitalTwinStore.getState());
  const [isOptimiseOpen, setIsOptimiseOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [isReportOpen, setIsReportOpen] = useState(false);
  const [showWarnings, setShowWarnings] = useState(false);

  useEffect(() => {
    // Start simulation loop
    digitalTwinStore.startSimulation();

    // Subscribe to state updates
    const unsubscribe = digitalTwinStore.subscribe((newState) => {
      setTwinState(newState);
    });

    return () => {
      unsubscribe();
      digitalTwinStore.stopSimulation();
    };
  }, []);

  const leadVehicle = twinState.vehicles[0] || {
    id: 'lead',
    name: 'Lead',
    number: 1,
    driverModel: 'Pro',
    color: '#ef4444',
    distance: 0,
    lap: 1,
    sector: 1,
    speed: 180,
    throttle: 0.9,
    brake: 0,
    gear: 5,
    rpm: 7200,
    lateralG: 1.2,
    longitudinalG: 0.4,
    combinedG: 1.26,
    roll: 0,
    pitch: 0,
    position: { x: 0, y: 0, z: 0 },
    rotation: 0
  };

  return (
    <div className="w-screen h-screen bg-[#0a0a0c] text-slate-300 flex flex-col overflow-hidden font-sans select-none">
      {/* Top Navbar */}
      <StudioNavbar
        studioMode={twinState.studioMode}
        cameraMode={twinState.cameraMode}
        overlayMode={twinState.overlayMode}
        scenario={twinState.scenario}
        simulationSpeed={twinState.simulationSpeed}
        isSimulating={twinState.isSimulating}
        elevationExaggeration={twinState.geometry.elevationExaggeration}
        warningsCount={twinState.warnings.length}
        onOpenOptimise={() => setIsOptimiseOpen(true)}
        onOpenExport={() => setIsExportOpen(true)}
        onOpenReport={() => setIsReportOpen(true)}
        onToggleWarnings={() => setShowWarnings(!showWarnings)}
      />

      {/* Main Studio Viewport Grid */}
      <div className="flex-1 relative flex overflow-hidden">
        {/* Left Drawer / Panel based on Studio Mode */}
        {twinState.studioMode === 'DESIGN' && (
          <DesignPanel
            geometry={twinState.geometry}
            selectedCornerId={twinState.selectedCornerId}
            warnings={twinState.warnings}
          />
        )}

        {(twinState.studioMode === 'ANALYSE' || twinState.studioMode === 'SIMULATE') && (
          <RAnalyticsPanel
            analytics={twinState.analytics}
            overlayMode={twinState.overlayMode}
            scenario={twinState.scenario}
          />
        )}

        {twinState.studioMode === 'BUILD' && (
          <ConstructionPanel
            construction={twinState.construction}
            geometry={twinState.geometry}
          />
        )}

        {/* Center 3D Digital Twin Canvas */}
        <div className="flex-1 h-full relative">
          <ThreeCanvas
            onCornerSelect={(cornerId) => digitalTwinStore.selectCorner(cornerId)}
          />

          {/* Quick Floating Node Badge on Canvas Top */}
          <div className="absolute top-6 left-6 space-y-2 pointer-events-none z-20">
            <div className="bg-slate-900/80 backdrop-blur border border-slate-700 px-3 py-2 rounded">
              <span className="text-[10px] text-slate-500 block uppercase font-bold tracking-widest leading-none mb-1">Current Node</span>
              <span className="text-xs text-white font-mono font-bold">
                {twinState.geometry.corners.find((c) => c.id === twinState.selectedCornerId)?.name || 'T7: Apex Horizon'}
              </span>
            </div>
            <div className="flex gap-2">
              <div className="bg-indigo-600/20 backdrop-blur border border-indigo-500/30 px-3 py-1 rounded text-[10px] text-indigo-300 font-bold">
                SPEED OVERLAY: {twinState.overlayMode === 'SPEED' ? 'ON' : 'AUTO'}
              </div>
              <div className="bg-slate-800/80 backdrop-blur border border-slate-700 px-3 py-1 rounded text-[10px] text-slate-400 font-bold">
                CURVATURE: {twinState.overlayMode === 'CURVATURE' ? 'ON' : 'AUTO'}
              </div>
            </div>
          </div>

          {/* Floating G-Force Meter on Canvas Bottom-Right */}
          <div className="absolute bottom-6 right-6 w-44 space-y-3 pointer-events-none z-20 hidden md:block">
            <div className="bg-slate-900/90 backdrop-blur border border-slate-800 p-3.5 rounded-xl">
              <h3 className="text-[10px] text-slate-500 uppercase font-bold mb-2 tracking-widest">G-Force Meter</h3>
              <div className="relative h-20 w-full flex items-center justify-center border border-slate-800 rounded bg-[#0d0d10]">
                <div className="absolute w-full h-[1px] bg-slate-800" />
                <div className="absolute h-full w-[1px] bg-slate-800" />
                <div
                  className="w-2.5 h-2.5 bg-red-500 rounded-full absolute transition-all duration-75"
                  style={{
                    transform: `translate(${leadVehicle.lateralG * 8}px, ${-leadVehicle.longitudinalG * 8}px)`,
                    boxShadow: '0 0 10px rgba(239, 68, 68, 0.6)'
                  }}
                />
                <span className="absolute bottom-1 right-2 text-[9px] text-slate-400 font-mono font-bold">
                  {leadVehicle.combinedG}G
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Telemetry Sidebar Panel */}
        <TelemetryPanel
          telemetry={twinState.telemetry}
          vehicle={leadVehicle}
          geometry={twinState.geometry}
          timeScrubber={twinState.timeScrubber}
        />
      </div>

      {/* Sleek Footer Bar */}
      <footer className="h-12 bg-[#0d0d10] border-t border-slate-800 flex items-center px-6 gap-8 text-xs shrink-0 z-30">
        <div className="flex items-center gap-2 border-r border-slate-800 pr-8">
          <span className="text-[10px] font-bold text-slate-500 uppercase">Mode</span>
          <span className="text-xs font-mono text-indigo-400 font-bold">{twinState.studioMode}_ENG_DASHBOARD</span>
        </div>
        <div className="flex gap-8 overflow-hidden">
          <div className="flex flex-col">
            <span className="text-[8px] text-slate-500 uppercase font-bold tracking-tighter">Curvature</span>
            <span className="text-[10px] font-mono text-slate-300">
              {(twinState.geometry.points[Math.floor((leadVehicle.distance / twinState.geometry.length) * twinState.geometry.points.length)]?.curvature || 0.042).toFixed(3)}m⁻¹
            </span>
          </div>
          <div className="flex flex-col">
            <span className="text-[8px] text-slate-500 uppercase font-bold tracking-tighter">Gradient</span>
            <span className="text-[10px] font-mono text-slate-300">
              {((twinState.geometry.points[Math.floor((leadVehicle.distance / twinState.geometry.length) * twinState.geometry.points.length)]?.gradient || -0.024) * 100).toFixed(1)}%
            </span>
          </div>
          <div className="flex flex-col">
            <span className="text-[8px] text-slate-500 uppercase font-bold tracking-tighter">Camber</span>
            <span className="text-[10px] font-mono text-slate-300">
              +{(twinState.geometry.points[Math.floor((leadVehicle.distance / twinState.geometry.length) * twinState.geometry.points.length)]?.camber || 1.5).toFixed(1)}°
            </span>
          </div>
          <div className="flex flex-col">
            <span className="text-[8px] text-slate-500 uppercase font-bold tracking-tighter">Overtaking Index</span>
            <span className="text-[10px] font-mono text-emerald-400 font-bold">{twinState.analytics.overtakingPotential}</span>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-4">
          <span className="text-[10px] font-mono text-slate-600 uppercase tracking-widest">Ver: 3.6.0-PRO</span>
        </div>
      </footer>

      {/* Warnings Drawer Overlay */}
      {showWarnings && twinState.warnings.length > 0 && (
        <div className="absolute top-16 right-80 w-96 bg-[#0d0d10] border border-amber-500/50 rounded-xl p-4 shadow-2xl z-40 space-y-2">
          <div className="flex justify-between items-center border-b border-slate-800 pb-2">
            <span className="text-amber-400 font-extrabold text-xs flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4" />
              <span>DESIGN CONSTRAINT WARNINGS</span>
            </span>
            <button
              onClick={() => setShowWarnings(false)}
              className="text-slate-400 hover:text-slate-200"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-1.5 text-xs text-amber-200 font-mono">
            {twinState.warnings.map((w, i) => (
              <p key={i} className="bg-[#111114] p-2 rounded border border-amber-500/20">
                {w}
              </p>
            ))}
          </div>
        </div>
      )}

      {/* Modals */}
      {isOptimiseOpen && (
        <OptimisationModal
          candidates={twinState.candidateDesigns}
          activeCandidateId={twinState.activeCandidateId}
          onClose={() => setIsOptimiseOpen(false)}
        />
      )}

      {isExportOpen && (
        <ExportModal
          state={twinState}
          onClose={() => setIsExportOpen(false)}
        />
      )}

      {isReportOpen && (
        <ReportModal
          state={twinState}
          onClose={() => setIsReportOpen(false)}
        />
      )}
    </div>
  );
}
