import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'CIRCUITFORGE.OS - Race Circuit Digital Design Studio',
  description: 'Kotlin + R Animated Race-Track Design Studio & Digital Twin Engine',
  openGraph: {
    title: 'CIRCUITFORGE.OS - Race Circuit Digital Design Studio',
    description: 'Kotlin + R Animated Race-Track Design Studio & Digital Twin Engine',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'CIRCUITFORGE.OS - Race Circuit Digital Design Studio',
    description: 'Kotlin + R Animated Race-Track Design Studio & Digital Twin Engine',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
