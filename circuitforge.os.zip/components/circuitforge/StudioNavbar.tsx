'use client';

import React from 'react';
import {
  StudioMode,
  CameraMode,
  OverlayMode,
  ScenarioType
} from '@/lib/circuitforge/types';
import { digitalTwinStore } from '@/lib/circuitforge/digitalTwinStream';
import {
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  Download,
  FileText,
  Eye,
  Sliders,
  Layers,
  Activity,
  Maximize2,
  Undo,
  Redo,
  ShieldAlert
} from 'lucide-react';

interface StudioNavbarProps {
  studioMode: StudioMode;
  cameraMode: CameraMode;
  overlayMode: OverlayMode;
  scenario: ScenarioType;
  simulationSpeed: number;
  isSimulating: boolean;
  elevationExaggeration: number;
  warningsCount: number;
  onOpenOptimise: () => void;
  onOpenExport: () => void;
  onOpenReport: () => void;
  onToggleWarnings: () => void;
}

export const StudioNavbar: React.FC<StudioNavbarProps> = ({
  studioMode,
  cameraMode,
  overlayMode,
  scenario,
  simulationSpeed,
  isSimulating,
  elevationExaggeration,
  warningsCount,
  onOpenOptimise,
  onOpenExport,
  onOpenReport,
  onToggleWarnings
}) => {
  const modes: StudioMode[] = ['DESIGN', 'SIMULATE', 'ANALYSE', 'BUILD', 'CINEMATIC', 'RACE'];
  const cameraModes: CameraMode[] = ['TOP', 'ISOMETRIC', 'TRACKSIDE', 'CHASE', 'COCKPIT', 'HELICOPTER', 'CONSTRUCTION', 'FREE'];
  const speedOptions = [0.25, 0.5, 1, 2, 5, 10, 100];
  const exaggerationOptions = [1, 2, 5, 10];

  return (
    <header className="h-14 w-full border-b border-slate-800 flex items-center justify-between px-6 bg-[#111114] text-slate-300 font-sans z-30 select-none shrink-0 overflow-x-auto">
      {/* Brand & Mode Navigation */}
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-indigo-600 rounded flex items-center justify-center font-bold text-white shadow-lg shadow-indigo-500/20 text-sm">
            C
          </div>
          <span className="font-bold tracking-tighter text-lg text-white">
            CIRCUITFORGE<span className="text-indigo-400">.OS</span>
          </span>
        </div>

        {/* Studio Navigation Modes */}
        <nav className="hidden md:flex gap-4 items-center">
          {modes.map((mode) => {
            const isActive = studioMode === mode;
            return (
              <button
                key={mode}
                onClick={() => digitalTwinStore.setStudioMode(mode)}
                className={`text-xs font-semibold py-4 px-1 transition-all border-b-2 ${
                  isActive
                    ? 'text-white border-indigo-500 font-bold'
                    : 'text-slate-400 hover:text-white border-transparent'
                }`}
              >
                {mode}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Middle Controls: Simulation Clock, Camera, Elevation Exaggeration */}
      <div className="flex items-center gap-3">
        {/* Active Digital Twin Badge */}
        <span className="hidden xl:flex items-center gap-2 text-[10px] font-mono bg-emerald-500/10 text-emerald-400 px-2 py-1 rounded border border-emerald-500/20">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
          DIGITAL TWIN ACTIVE
        </span>

        {/* Simulation Clock & Play/Pause */}
        <div className="flex items-center gap-1 bg-[#0d0d10] p-1 rounded border border-slate-800">
          <button
            onClick={() => digitalTwinStore.setSimulating(!isSimulating)}
            className={`p-1.5 rounded text-xs font-bold flex items-center gap-1 ${
              isSimulating ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' : 'bg-indigo-600/20 text-indigo-400 border border-indigo-500/40'
            }`}
            title={isSimulating ? 'Pause Simulation' : 'Run Simulation'}
          >
            {isSimulating ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
          </button>

          <span className="text-[10px] font-mono text-slate-500 px-1 hidden sm:inline">SIM:</span>
          {speedOptions.map((spd) => (
            <button
              key={spd}
              onClick={() => digitalTwinStore.setSimulationSpeed(spd)}
              className={`px-1.5 py-0.5 rounded text-[10px] font-mono ${
                simulationSpeed === spd ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {spd}×
            </button>
          ))}
        </div>

        {/* Camera Selector */}
        <div className="flex items-center gap-1 bg-[#0d0d10] px-2.5 py-1 rounded border border-slate-800">
          <Eye className="w-3.5 h-3.5 text-indigo-400" />
          <span className="text-[10px] font-mono text-slate-500">CAM:</span>
          <select
            value={cameraMode}
            onChange={(e) => digitalTwinStore.setCameraMode(e.target.value as CameraMode)}
            className="bg-transparent text-xs font-mono text-indigo-400 border-none outline-none cursor-pointer font-bold"
          >
            {cameraModes.map((cam) => (
              <option key={cam} value={cam} className="bg-[#111114] text-slate-200">
                {cam}
              </option>
            ))}
          </select>
        </div>

        {/* Elevation Exaggeration */}
        <div className="hidden lg:flex items-center gap-1 bg-[#0d0d10] px-2.5 py-1 rounded border border-slate-800">
          <span className="text-[9px] font-mono text-slate-500 font-bold uppercase tracking-tight">
            ELEVATION:
          </span>
          {exaggerationOptions.map((ex) => (
            <button
              key={ex}
              onClick={() => digitalTwinStore.setElevationExaggeration(ex)}
              className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                elevationExaggeration === ex
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {ex}×
            </button>
          ))}
        </div>
      </div>

      {/* Action Buttons & Status Badges */}
      <div className="flex items-center gap-2">
        {/* Undo / Redo */}
        <div className="hidden sm:flex items-center gap-1 bg-[#0d0d10] p-1 rounded border border-slate-800">
          <button
            onClick={() => digitalTwinStore.undo()}
            className="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800"
            title="Undo (Ctrl+Z)"
          >
            <Undo className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => digitalTwinStore.redo()}
            className="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800"
            title="Redo (Ctrl+Shift+Z)"
          >
            <Redo className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Warnings trigger */}
        {warningsCount > 0 && (
          <button
            onClick={onToggleWarnings}
            className="px-2.5 py-1 rounded bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold flex items-center gap-1 animate-pulse"
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>{warningsCount}</span>
          </button>
        )}

        {/* R Live Optimise Button */}
        <button
          onClick={onOpenOptimise}
          className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-1.5 px-3 rounded text-xs transition-all flex items-center gap-1.5 shadow-md shadow-indigo-500/20"
        >
          <Sparkles className="w-3.5 h-3.5 text-indigo-200" />
          <span className="hidden sm:inline">OPTIMISE</span>
        </button>

        {/* Export Button */}
        <button
          onClick={onOpenExport}
          className="px-2.5 py-1.5 rounded bg-[#0d0d10] border border-slate-800 hover:bg-slate-800 text-slate-300 text-xs font-medium flex items-center gap-1"
        >
          <Download className="w-3.5 h-3.5 text-indigo-400" />
          <span className="hidden md:inline">EXPORT</span>
        </button>

        {/* Report Button */}
        <button
          onClick={onOpenReport}
          className="px-2.5 py-1.5 rounded bg-[#0d0d10] border border-slate-800 hover:bg-slate-800 text-slate-300 text-xs font-medium flex items-center gap-1"
        >
          <FileText className="w-3.5 h-3.5 text-emerald-400" />
          <span className="hidden md:inline">REPORT</span>
        </button>
      </div>
    </header>
  );
};
