'use client';

import React from 'react';
import { TrackDigitalTwinState } from '@/lib/circuitforge/types';
import { FileText, Printer, X, Check, Award, Activity, HardHat, DollarSign } from 'lucide-react';

interface ReportModalProps {
  state: TrackDigitalTwinState;
  onClose: () => void;
}

export const ReportModal: React.FC<ReportModalProps> = ({ state, onClose }) => {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center z-50 p-4 font-mono select-none overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-4xl w-full p-6 space-y-6 shadow-2xl my-8">
        {/* Header */}
        <div className="flex justify-between items-center border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <FileText className="w-5 h-5 text-emerald-400" />
            <div>
              <h2 className="text-lg font-extrabold text-slate-100 tracking-wider">
                CIRCUITFORGE.OS ENGINEERING REPORT
              </h2>
              <p className="text-xs text-slate-400">
                AUTOMATED DIGITAL TWIN TECHNICAL AUDIT REPORT
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-extrabold text-xs flex items-center space-x-1.5"
            >
              <Printer className="w-4 h-4" />
              <span>PRINT / PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Report Content */}
        <div className="space-y-6 bg-slate-950 p-6 rounded-xl border border-slate-800 text-xs">
          {/* Report Title & Metadata */}
          <div className="border-b border-slate-800 pb-4 flex justify-between items-start">
            <div>
              <h1 className="text-xl font-black text-slate-100">{state.geometry.name}</h1>
              <p className="text-slate-400 text-xs mt-0.5">
                Grand Prix Circuit Digital Design Audit | Generated: {new Date().toLocaleDateString()}
              </p>
            </div>
            <div className="text-right">
              <span className="px-3 py-1 rounded bg-cyan-950 text-cyan-300 font-extrabold border border-cyan-800">
                GRADE 1 SPEC
              </span>
            </div>
          </div>

          {/* Section 1: Track Summary & Dimensions */}
          <div className="space-y-2">
            <h3 className="font-bold text-slate-200 text-sm flex items-center space-x-1.5 text-cyan-400">
              <span>1. TRACK GEOMETRY & DIMENSIONS</span>
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-slate-900 p-3 rounded-lg border border-slate-800 text-slate-300">
              <div>
                <div className="text-slate-500 text-[10px]">TOTAL LENGTH</div>
                <div className="font-bold text-slate-100 text-sm">{(state.geometry.length / 1000).toFixed(2)} km</div>
              </div>
              <div>
                <div className="text-slate-500 text-[10px]">DEFAULT WIDTH</div>
                <div className="font-bold text-slate-100 text-sm">{state.geometry.defaultWidth} m</div>
              </div>
              <div>
                <div className="text-slate-500 text-[10px]">TOTAL CORNERS</div>
                <div className="font-bold text-slate-100 text-sm">{state.geometry.corners.length}</div>
              </div>
              <div>
                <div className="text-slate-500 text-[10px]">ELEVATION DELTA</div>
                <div className="font-bold text-slate-100 text-sm">32.5 m</div>
              </div>
            </div>
          </div>

          {/* Section 2: R Analytics & Performance Audit */}
          <div className="space-y-2">
            <h3 className="font-bold text-slate-200 text-sm flex items-center space-x-1.5 text-purple-400">
              <Activity className="w-4 h-4" />
              <span>2. R ANALYTICS & LAP PERFORMANCE</span>
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-slate-900 p-3 rounded-lg border border-slate-800 text-slate-300">
              <div>
                <div className="text-slate-500 text-[10px]">EST. LAP TIME</div>
                <div className="font-extrabold text-cyan-300 text-sm">{state.analytics.lapTimeFormatted}</div>
              </div>
              <div>
                <div className="text-slate-500 text-[10px]">AVERAGE SPEED</div>
                <div className="font-bold text-slate-100 text-sm">{state.analytics.avgSpeed} km/h</div>
              </div>
              <div>
                <div className="text-slate-500 text-[10px]">MAX SPEED</div>
                <div className="font-bold text-slate-100 text-sm">{state.analytics.maxSpeed} km/h</div>
              </div>
              <div>
                <div className="text-slate-500 text-[10px]">OVERTAKING INDEX</div>
                <div className="font-extrabold text-emerald-400 text-sm">{state.analytics.overtakingPotential} / 100</div>
              </div>
            </div>
          </div>

          {/* Section 3: Earthworks & Civil Engineering */}
          <div className="space-y-2">
            <h3 className="font-bold text-slate-200 text-sm flex items-center space-x-1.5 text-amber-400">
              <HardHat className="w-4 h-4" />
              <span>3. CIVIL CONSTRUCTION & EARTHWORKS</span>
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-slate-900 p-3 rounded-lg border border-slate-800 text-slate-300">
              <div>
                <div className="text-slate-500 text-[10px]">EARTHWORKS CUT</div>
                <div className="font-bold text-red-400 text-sm">{(state.construction.cutVolume / 1000).toFixed(0)}k m³</div>
              </div>
              <div>
                <div className="text-slate-500 text-[10px]">EARTHWORKS FILL</div>
                <div className="font-bold text-blue-400 text-sm">{(state.construction.fillVolume / 1000).toFixed(0)}k m³</div>
              </div>
              <div>
                <div className="text-slate-500 text-[10px]">PAVEMENT AREA</div>
                <div className="font-bold text-slate-100 text-sm">{state.construction.pavementArea.toLocaleString()} m²</div>
              </div>
              <div>
                <div className="text-slate-500 text-[10px]">ESTIMATED BUDGET</div>
                <div className="font-extrabold text-amber-400 text-sm">${(state.analytics.estimatedCost / 1000000).toFixed(1)}M USD</div>
              </div>
            </div>
          </div>

          {/* Section 4: Design Score Breakdown */}
          <div className="space-y-2">
            <h3 className="font-bold text-slate-200 text-sm flex items-center space-x-1.5 text-emerald-400">
              <Award className="w-4 h-4" />
              <span>4. OVERALL CIRCUIT DESIGN SCORE</span>
            </h3>
            <div className="bg-slate-900 p-4 rounded-lg border border-slate-800 flex justify-between items-center">
              <div className="space-y-1">
                <div className="text-slate-400 font-bold">TOTAL DESIGN SCORE:</div>
                <div className="text-xs text-slate-500">
                  Weighted sum of Lap Quality, Variety, Overtaking, Elevation, and Construction.
                </div>
              </div>
              <div className="text-3xl font-black text-cyan-300 font-mono">
                {state.analytics.designScore.total} <span className="text-sm font-normal text-slate-500">/ 100</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end border-t border-slate-800 pt-3">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-800 text-slate-200 hover:bg-slate-700 text-xs font-semibold"
          >
            CLOSE REPORT
          </button>
        </div>
      </div>
    </div>
  );
};
