'use client';

import React from 'react';
import { TelemetryState, VehicleState, TrackGeometry } from '@/lib/circuitforge/types';
import { digitalTwinStore } from '@/lib/circuitforge/digitalTwinStream';
import { Activity, Gauge, Timer, Zap, ChevronRight } from 'lucide-react';

interface TelemetryPanelProps {
  telemetry: TelemetryState;
  vehicle: VehicleState;
  geometry: TrackGeometry;
  timeScrubber: number;
}

export const TelemetryPanel: React.FC<TelemetryPanelProps> = ({
  telemetry,
  vehicle,
  geometry,
  timeScrubber
}) => {
  const lapTimeFormatted = () => {
    const totalSec = telemetry.currentLapTime;
    const mins = Math.floor(totalSec / 60);
    const secs = (totalSec % 60).toFixed(2);
    return `${mins}:${Number(secs) < 10 ? '0' : ''}${secs}`;
  };

  const handleGraphClick = (e: React.MouseEvent<SVGSVGElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const progress = Math.max(0, Math.min(1, clickX / rect.width));
    digitalTwinStore.setTimeScrubber(progress);
  };

  return (
    <aside className="w-72 border-l border-slate-800 bg-[#0d0d10] flex flex-col h-full overflow-y-auto select-none shrink-0 font-sans text-xs">
      <div className="p-5 flex-1 space-y-6">
        {/* R Analytics Output Box */}
        <div>
          <h2 className="text-[10px] uppercase tracking-widest text-slate-500 font-bold mb-4">
            R Analytics Output
          </h2>
          <div className="bg-[#111114] border border-slate-800 rounded p-4 space-y-4 shadow-sm">
            <div className="flex justify-between items-baseline">
              <span className="text-xs text-slate-400">Est. Lap Time</span>
              <span className="text-xl font-mono font-bold text-indigo-400">{lapTimeFormatted()}</span>
            </div>
            <div className="flex justify-between items-baseline">
              <span className="text-xs text-slate-400 font-sans">Avg. Speed</span>
              <span className="text-sm font-mono text-white font-bold">{vehicle.speed} km/h</span>
            </div>
            <div className="flex justify-between items-baseline">
              <span className="text-xs text-slate-400 font-sans">Earthworks</span>
              <span className="text-sm font-mono text-white font-bold">2.59M m³</span>
            </div>
            <div className="flex justify-between items-baseline">
              <span className="text-xs text-slate-400 font-sans">Complexity</span>
              <span className="text-sm font-mono text-white font-bold">82.4</span>
            </div>
          </div>
        </div>

        {/* Live Telemetry Gauges */}
        <div>
          <h2 className="text-[10px] uppercase tracking-widest text-slate-500 font-bold mb-4">
            Live Telemetry
          </h2>
          <div className="space-y-4">
            <div className="space-y-1">
              <div className="flex justify-between text-[10px] text-slate-500 uppercase font-bold">
                <span>Speed</span>
                <span className="text-slate-300 font-mono">{vehicle.speed} KMH</span>
              </div>
              <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)] transition-all duration-75"
                  style={{ width: `${Math.min(100, (vehicle.speed / 320) * 100)}%` }}
                />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-[10px] text-slate-500 uppercase font-bold">
                <span>Throttle</span>
                <span className="text-slate-300 font-mono">{Math.round(vehicle.throttle * 100)}%</span>
              </div>
              <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-indigo-500 transition-all duration-75"
                  style={{ width: `${vehicle.throttle * 100}%` }}
                />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-[10px] text-slate-500 uppercase font-bold">
                <span>Brake</span>
                <span className="text-slate-300 font-mono">{Math.round(vehicle.brake * 100)}%</span>
              </div>
              <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-red-500 transition-all duration-75"
                  style={{ width: `${vehicle.brake * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Interactive Telemetry Graph */}
        <div>
          <div className="flex justify-between items-center text-[10px] uppercase tracking-widest text-slate-500 font-bold mb-2">
            <span>Telemetry vs Distance</span>
            <span className="text-indigo-400 font-mono">Scrub</span>
          </div>
          <div className="relative w-full h-28 bg-[#111114] rounded border border-slate-800 overflow-hidden cursor-crosshair">
            <svg
              className="w-full h-full"
              viewBox="0 0 300 120"
              preserveAspectRatio="none"
              onClick={handleGraphClick}
            >
              <line x1="0" y1="40" x2="300" y2="40" stroke="#1e293b" strokeWidth="0.5" />
              <line x1="0" y1="80" x2="300" y2="80" stroke="#1e293b" strokeWidth="0.5" />

              {/* Speed Curve */}
              <polyline
                fill="none"
                stroke="#6366f1"
                strokeWidth="1.5"
                points={telemetry.graphData
                  .map((d, i) => `${(i / telemetry.graphData.length) * 300},${120 - (d.speed / 320) * 110}`)
                  .join(' ')}
              />

              {/* Throttle Curve */}
              <polyline
                fill="none"
                stroke="#10b981"
                strokeWidth="1"
                points={telemetry.graphData
                  .map((d, i) => `${(i / telemetry.graphData.length) * 300},${120 - d.throttle * 40 - 5}`)
                  .join(' ')}
              />

              {/* Brake Curve */}
              <polyline
                fill="none"
                stroke="#ef4444"
                strokeWidth="1"
                points={telemetry.graphData
                  .map((d, i) => `${(i / telemetry.graphData.length) * 300},${120 - d.brake * 40 - 5}`)
                  .join(' ')}
              />

              {/* Cursor Line */}
              <line
                x1={timeScrubber * 300}
                y1="0"
                x2={timeScrubber * 300}
                y2="120"
                stroke="#818cf8"
                strokeWidth="2"
                strokeDasharray="2,2"
              />
            </svg>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.001"
            value={timeScrubber}
            onChange={(e) => digitalTwinStore.setTimeScrubber(parseFloat(e.target.value))}
            className="w-full accent-indigo-500 bg-slate-800 h-1 rounded cursor-pointer mt-2"
          />
        </div>
      </div>

      {/* Construction Cost Banner at bottom */}
      <div className="p-5 bg-indigo-600/5 border-t border-slate-800 mt-auto">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[10px] text-indigo-300 font-bold uppercase">Construction Cost</span>
          <span className="text-sm font-mono text-white font-bold">$142.8M</span>
        </div>
        <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
          <div className="h-full bg-indigo-500 w-3/5"></div>
        </div>
      </div>
    </aside>
  );
};
