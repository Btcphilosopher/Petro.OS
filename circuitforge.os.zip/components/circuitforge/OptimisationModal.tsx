'use client';

import React, { useState } from 'react';
import { CandidateDesign } from '@/lib/circuitforge/types';
import { digitalTwinStore } from '@/lib/circuitforge/digitalTwinStream';
import { Sparkles, X, Check, ArrowRight, Activity, DollarSign, Layers, Award } from 'lucide-react';

interface OptimisationModalProps {
  candidates: CandidateDesign[];
  activeCandidateId: string | null;
  onClose: () => void;
}

export const OptimisationModal: React.FC<OptimisationModalProps> = ({
  candidates,
  activeCandidateId,
  onClose
}) => {
  const [selectedId, setSelectedId] = useState<string>(activeCandidateId || candidates[0]?.id || 'candidate-a');
  const selectedCandidate = candidates.find((c) => c.id === selectedId) || candidates[0];

  const handleApplyMorph = () => {
    digitalTwinStore.morphToCandidate(selectedId);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center z-50 p-4 font-mono select-none">
      <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-4xl w-full p-6 space-y-6 shadow-2xl">
        {/* Header */}
        <div className="flex justify-between items-center border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded bg-purple-950 border border-purple-800">
              <Sparkles className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <h2 className="text-lg font-extrabold text-slate-100 tracking-wider">
                R-POWERED MULTI-OBJECTIVE CIRCUIT OPTIMISER
              </h2>
              <p className="text-xs text-slate-400">
                STATISTICAL CANDIDATE DESIGN EVALUATION & MORPHING
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Candidate Cards Grid (Requirement #34) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {candidates.map((cand) => {
            const isSelected = selectedId === cand.id;
            return (
              <div
                key={cand.id}
                onClick={() => setSelectedId(cand.id)}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-purple-950/50 border-purple-500 shadow-xl shadow-purple-500/10 ring-2 ring-purple-500/30'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-950'
                }`}
              >
                <div className="flex justify-between items-start mb-2">
                  <span className="font-bold text-xs text-slate-200">{cand.name}</span>
                  {isSelected && (
                    <span className="w-4 h-4 rounded-full bg-purple-500 flex items-center justify-center text-slate-950">
                      <Check className="w-3 h-3 stroke-[3]" />
                    </span>
                  )}
                </div>

                <div className="space-y-1 text-xs">
                  <div className="flex justify-between text-slate-400">
                    <span>SCORE:</span>
                    <span className="font-extrabold text-purple-300">{cand.designScore}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>LAP TIME:</span>
                    <span className="font-bold text-cyan-300">{cand.lapTimeStr}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>EST. COST:</span>
                    <span className="font-bold text-amber-300">${cand.costMillion}M</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>EARTHWORKS:</span>
                    <span className="font-bold text-slate-200">{cand.earthworksMillionM3}M m³</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Detailed Design Comparison Matrix (Requirement #35) */}
        <div className="bg-slate-950 rounded-xl border border-slate-800 p-4 space-y-3">
          <h3 className="font-bold text-xs text-slate-300 uppercase tracking-wider flex items-center space-x-2">
            <Award className="w-4 h-4 text-purple-400" />
            <span>CANDIDATE COMPARISON MATRIX</span>
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="py-2">METRIC</th>
                  {candidates.map((c) => (
                    <th key={c.id} className={`py-2 px-2 ${c.id === selectedId ? 'text-purple-300 font-bold' : ''}`}>
                      {c.name.split(' ')[1]}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                <tr>
                  <td className="py-2 text-slate-400">LENGTH (KM)</td>
                  {candidates.map((c) => (
                    <td key={c.id} className="py-2 px-2 font-mono">{c.lengthKm}</td>
                  ))}
                </tr>
                <tr>
                  <td className="py-2 text-slate-400">LAP TIME</td>
                  {candidates.map((c) => (
                    <td key={c.id} className="py-2 px-2 font-mono font-bold text-cyan-300">{c.lapTimeStr}</td>
                  ))}
                </tr>
                <tr>
                  <td className="py-2 text-slate-400">CIVIL COST ($M)</td>
                  {candidates.map((c) => (
                    <td key={c.id} className="py-2 px-2 font-mono font-bold text-amber-300">${c.costMillion}M</td>
                  ))}
                </tr>
                <tr>
                  <td className="py-2 text-slate-400">EARTHWORKS (M M³)</td>
                  {candidates.map((c) => (
                    <td key={c.id} className="py-2 px-2 font-mono">{c.earthworksMillionM3}M</td>
                  ))}
                </tr>
                <tr>
                  <td className="py-2 text-slate-400">OVERTAKING SCORE</td>
                  {candidates.map((c) => (
                    <td key={c.id} className="py-2 px-2 font-mono font-bold text-emerald-300">{c.overtakingScore}</td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Footer Actions (Requirement #36 Morphing) */}
        <div className="flex justify-between items-center border-t border-slate-800 pt-4">
          <p className="text-xs text-slate-400">
            Applying candidate will smoothly morph track centerline, terrain, runoff, and racing line in 3D.
          </p>

          <div className="flex space-x-3">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 font-semibold text-xs"
            >
              CANCEL
            </button>
            <button
              onClick={handleApplyMorph}
              className="px-5 py-2 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-extrabold text-xs flex items-center space-x-2 shadow-lg shadow-purple-500/25"
            >
              <span>MORPH TO {selectedCandidate.name}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
