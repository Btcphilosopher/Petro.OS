'use client';

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { TrackDigitalTwinState, TrackPoint, OverlayMode } from '@/lib/circuitforge/types';
import { digitalTwinStore } from '@/lib/circuitforge/digitalTwinStream';

interface ThreeCanvasProps {
  onCornerSelect?: (cornerId: string) => void;
}

const getOverlayColor = (pt: TrackPoint, mode: OverlayMode): THREE.Color => {
  switch (mode) {
    case 'SPEED': {
      const ratio = Math.min(1, pt.speed / 300);
      return new THREE.Color().setHSL((1 - ratio) * 0.6, 0.9, 0.5);
    }
    case 'CURVATURE': {
      const ratio = Math.min(1, pt.curvature * 25);
      return new THREE.Color().setHSL(ratio * 0.8, 0.9, 0.5);
    }
    case 'BRAKING': {
      if (pt.brakingIntensity > 0.1) {
        return new THREE.Color(0xef4444);
      }
      return new THREE.Color(0x10b981);
    }
    case 'LATERAL_G': {
      const ratio = Math.min(1, pt.lateralG / 3.5);
      return new THREE.Color().setHSL((1 - ratio) * 0.7, 0.9, 0.5);
    }
    case 'GRADIENT': {
      if (pt.gradient > 0.02) return new THREE.Color(0xf59e0b);
      if (pt.gradient < -0.02) return new THREE.Color(0x3b82f6);
      return new THREE.Color(0x475569);
    }
    case 'BANKING': {
      const ratio = Math.min(1, Math.abs(pt.banking) / 10);
      return new THREE.Color().setHSL(0.5 + ratio * 0.4, 0.9, 0.5);
    }
    case 'COST':
    case 'EARTHWORKS': {
      const ratio = Math.min(1, Math.abs(pt.elevation) / 25);
      return new THREE.Color().setHSL(0.1 + ratio * 0.8, 0.8, 0.5);
    }
    default:
      return new THREE.Color(0x334155);
  }
};

export const ThreeCanvas: React.FC<ThreeCanvasProps> = ({ onCornerSelect }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [twinState, setTwinState] = useState<TrackDigitalTwinState>(digitalTwinStore.getState());
  const [fps, setFps] = useState<number>(60);

  // Three.js References
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);

  // Mesh Group References
  const trackMeshGroupRef = useRef<THREE.Group | null>(null);
  const terrainMeshGroupRef = useRef<THREE.Group | null>(null);
  const racingLineGroupRef = useRef<THREE.Group | null>(null);
  const vehiclesGroupRef = useRef<THREE.Group | null>(null);
  const cornerMarkersGroupRef = useRef<THREE.Group | null>(null);
  const earthworksGroupRef = useRef<THREE.Group | null>(null);
  const constructionGroupRef = useRef<THREE.Group | null>(null);

  // Digital Twin state ref for 60fps render loop
  const stateRef = useRef<TrackDigitalTwinState>(digitalTwinStore.getState());

  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;

    // 1. Scene Setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0a0c); // Sleek Interface Dark Canvas
    scene.fog = new THREE.FogExp2(0x0a0a0c, 0.0006);
    sceneRef.current = scene;

    // 2. Camera Setup
    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;
    const camera = new THREE.PerspectiveCamera(45, width / height, 1, 5000);
    camera.position.set(300, 320, 420);
    cameraRef.current = camera;

    // 3. Renderer Setup
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;

    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // 4. Orbit Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxPolarAngle = Math.PI / 2 - 0.02; // Prevent camera clipping ground
    controlsRef.current = controls;

    // 5. Lighting Setup
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 1.4);
    dirLight.position.set(400, 600, 300);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    dirLight.shadow.camera.near = 10;
    dirLight.shadow.camera.far = 2000;
    dirLight.shadow.camera.left = -600;
    dirLight.shadow.camera.right = 600;
    dirLight.shadow.camera.top = 600;
    dirLight.shadow.camera.bottom = -600;
    scene.add(dirLight);

    const hemiLight = new THREE.HemisphereLight(0x38bdf8, 0x1e293b, 0.4);
    scene.add(hemiLight);

    // Groups Initialisation
    const trackMeshGroup = new THREE.Group();
    scene.add(trackMeshGroup);
    trackMeshGroupRef.current = trackMeshGroup;

    const terrainMeshGroup = new THREE.Group();
    scene.add(terrainMeshGroup);
    terrainMeshGroupRef.current = terrainMeshGroup;

    const racingLineGroup = new THREE.Group();
    scene.add(racingLineGroup);
    racingLineGroupRef.current = racingLineGroup;

    const vehiclesGroup = new THREE.Group();
    scene.add(vehiclesGroup);
    vehiclesGroupRef.current = vehiclesGroup;

    const cornerMarkersGroup = new THREE.Group();
    scene.add(cornerMarkersGroup);
    cornerMarkersGroupRef.current = cornerMarkersGroup;

    const earthworksGroup = new THREE.Group();
    scene.add(earthworksGroup);
    earthworksGroupRef.current = earthworksGroup;

    const constructionGroup = new THREE.Group();
    scene.add(constructionGroup);
    constructionGroupRef.current = constructionGroup;

    // Helper functions inside effect
    const rebuildAllMeshes = () => {
      const state = stateRef.current;
      const points = state.geometry.points;
      if (!points || points.length < 2) return;

      // Clear previous meshes
      [trackMeshGroup, terrainMeshGroup, racingLineGroup, cornerMarkersGroup, earthworksGroup, constructionGroup].forEach((grp) => {
        while (grp.children.length > 0) {
          const child = grp.children.pop();
          if (child && (child as THREE.Mesh).geometry) {
            (child as THREE.Mesh).geometry.dispose();
          }
        }
      });

      // 1. Render Track Pavement Ribbon Mesh
      const trackVertices: number[] = [];
      const trackColors: number[] = [];
      const trackIndices: number[] = [];

      points.forEach((pt, i) => {
        trackVertices.push(pt.leftEdge.x, pt.leftEdge.y, pt.leftEdge.z);
        trackVertices.push(pt.rightEdge.x, pt.rightEdge.y, pt.rightEdge.z);

        const color = getOverlayColor(pt, state.overlayMode);
        trackColors.push(color.r, color.g, color.b);
        trackColors.push(color.r, color.g, color.b);

        if (i < points.length - 1) {
          const idx = i * 2;
          trackIndices.push(idx, idx + 1, idx + 2);
          trackIndices.push(idx + 1, idx + 3, idx + 2);
        }
      });

      // Close circuit loop
      const lastIdx = (points.length - 1) * 2;
      trackIndices.push(lastIdx, lastIdx + 1, 0);
      trackIndices.push(lastIdx + 1, 1, 0);

      const trackGeo = new THREE.BufferGeometry();
      trackGeo.setAttribute('position', new THREE.Float32BufferAttribute(trackVertices, 3));
      trackGeo.setAttribute('color', new THREE.Float32BufferAttribute(trackColors, 3));
      trackGeo.setIndex(trackIndices);
      trackGeo.computeVertexNormals();

      const trackMat = new THREE.MeshStandardMaterial({
        vertexColors: true,
        roughness: 0.4,
        metalness: 0.1,
        side: THREE.DoubleSide
      });

      const trackMesh = new THREE.Mesh(trackGeo, trackMat);
      trackMesh.receiveShadow = true;
      trackMesh.castShadow = true;
      trackMeshGroup.add(trackMesh);

      // 2. Render 3D Terrain Grid DEM
      const terrainGeo = new THREE.PlaneGeometry(1200, 1200, 60, 60);
      terrainGeo.rotateX(-Math.PI / 2);

      const posAttr = terrainGeo.attributes.position;
      for (let i = 0; i < posAttr.count; i++) {
        const vx = posAttr.getX(i);
        const vz = posAttr.getZ(i);

        let minSqDist = Infinity;
        let trackElev = 0;

        points.forEach((pt) => {
          const sqd = (pt.center.x - vx) ** 2 + (pt.center.z - vz) ** 2;
          if (sqd < minSqDist) {
            minSqDist = sqd;
            trackElev = pt.center.y;
          }
        });

        const dist = Math.sqrt(minSqDist);
        let y = Math.sin(vx * 0.01) * 6 + Math.cos(vz * 0.01) * 6;

        if (dist < 120) {
          const factor = dist / 120;
          y = trackElev * (1 - factor) + y * factor - 1.2;
        }

        posAttr.setY(i, y);
      }

      terrainGeo.computeVertexNormals();
      const terrainMat = new THREE.MeshStandardMaterial({
        color: 0x111827,
        wireframe: state.studioMode === 'BUILD' || state.overlayMode === 'EARTHWORKS',
        roughness: 0.9,
        metalness: 0.1
      });

      const terrainMesh = new THREE.Mesh(terrainGeo, terrainMat);
      terrainMesh.receiveShadow = true;
      terrainMeshGroup.add(terrainMesh);

      // 3. Render Ideal Racing Line Ribbon
      const linePositions: number[] = [];
      points.forEach((pt) => {
        linePositions.push(pt.racingLinePoint.x, pt.racingLinePoint.y + 0.2, pt.racingLinePoint.z);
      });

      const lineGeo = new THREE.BufferGeometry();
      lineGeo.setAttribute('position', new THREE.Float32BufferAttribute(linePositions, 3));

      const lineMat = new THREE.LineBasicMaterial({ color: 0x38bdf8, linewidth: 3 });
      const racingLineMesh = new THREE.LineLoop(lineGeo, lineMat);
      racingLineGroup.add(racingLineMesh);

      // 4. Render Corner Apex Markers
      state.geometry.corners.forEach((c) => {
        const ptIdx = Math.floor(c.positionIndex * points.length) % points.length;
        const pt = points[ptIdx] || points[0];

        const isSelected = state.selectedCornerId === c.id;

        const markerGeo = new THREE.CylinderGeometry(isSelected ? 6 : 4, isSelected ? 6 : 4, 1.5, 16);
        const markerMat = new THREE.MeshStandardMaterial({
          color: isSelected ? 0x38bdf8 : 0xa855f7,
          emissive: isSelected ? 0x0284c7 : 0x6b21a8,
          emissiveIntensity: 0.8
        });

        const markerMesh = new THREE.Mesh(markerGeo, markerMat);
        markerMesh.position.set(pt.center.x, pt.center.y + 1, pt.center.z);
        markerMesh.userData = { cornerId: c.id, cornerName: c.name };
        cornerMarkersGroup.add(markerMesh);
      });
    };

    const updateVehiclePositions = () => {
      if (!vehiclesGroupRef.current) return;
      const vehicles = stateRef.current.vehicles;
      const group = vehiclesGroupRef.current;

      while (group.children.length < vehicles.length) {
        const carGroup = new THREE.Group();
        const bodyGeo = new THREE.BoxGeometry(4.2, 1.2, 2.0);
        const bodyMat = new THREE.MeshStandardMaterial({ color: 0xef4444, metalness: 0.8, roughness: 0.2 });
        const bodyMesh = new THREE.Mesh(bodyGeo, bodyMat);
        bodyMesh.castShadow = true;
        bodyMesh.position.y = 0.6;
        carGroup.add(bodyMesh);

        const wingGeo = new THREE.BoxGeometry(1.0, 0.4, 2.2);
        const wingMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.9 });
        const wingMesh = new THREE.Mesh(wingGeo, wingMat);
        wingMesh.position.set(-1.8, 1.2, 0);
        carGroup.add(wingMesh);

        group.add(carGroup);
      }

      for (let i = 0; i < group.children.length; i++) {
        group.children[i].visible = i < vehicles.length;
      }

      vehicles.forEach((v, i) => {
        const carGroup = group.children[i] as THREE.Group;
        if (!carGroup) return;

        carGroup.position.set(v.position.x, v.position.y + 0.3, v.position.z);
        carGroup.rotation.y = v.rotation + Math.PI / 2;
        carGroup.rotation.z = (v.roll * Math.PI) / 180;
        carGroup.rotation.x = (v.pitch * Math.PI) / 180;

        const bodyMesh = carGroup.children[0] as THREE.Mesh;
        if (bodyMesh && bodyMesh.material) {
          (bodyMesh.material as THREE.MeshStandardMaterial).color.setStyle(v.color);
        }
      });
    };

    const updateCameraPosition = () => {
      const camera = cameraRef.current;
      const controls = controlsRef.current;
      if (!camera || !controls) return;

      const state = stateRef.current;
      const leadVehicle = state.vehicles[0];
      const mode = state.cameraMode;

      if (mode === 'FREE') return;

      if (mode === 'TOP') {
        camera.position.set(0, 750, 0.1);
        controls.target.set(0, 0, 0);
      } else if (mode === 'ISOMETRIC') {
        camera.position.set(300, 320, 420);
        controls.target.set(0, 0, 0);
      } else if (mode === 'TRACKSIDE') {
        camera.position.set(120, 25, 180);
        if (leadVehicle) {
          controls.target.set(leadVehicle.position.x, leadVehicle.position.y, leadVehicle.position.z);
        }
      } else if (mode === 'CHASE' && leadVehicle) {
        const offsetX = -Math.cos(leadVehicle.rotation) * 25;
        const offsetZ = Math.sin(leadVehicle.rotation) * 25;
        camera.position.set(
          leadVehicle.position.x + offsetX,
          leadVehicle.position.y + 12,
          leadVehicle.position.z + offsetZ
        );
        controls.target.set(leadVehicle.position.x, leadVehicle.position.y + 2, leadVehicle.position.z);
      } else if (mode === 'COCKPIT' && leadVehicle) {
        camera.position.set(leadVehicle.position.x, leadVehicle.position.y + 1.8, leadVehicle.position.z);
        const lookX = leadVehicle.position.x + Math.sin(leadVehicle.rotation) * 40;
        const lookZ = leadVehicle.position.z + Math.cos(leadVehicle.rotation) * 40;
        controls.target.set(lookX, leadVehicle.position.y + 1.5, lookZ);
      } else if (mode === 'HELICOPTER' && leadVehicle) {
        camera.position.set(
          leadVehicle.position.x + Math.sin(Date.now() * 0.0005) * 120,
          leadVehicle.position.y + 140,
          leadVehicle.position.z + Math.cos(Date.now() * 0.0005) * 120
        );
        controls.target.set(leadVehicle.position.x, leadVehicle.position.y, leadVehicle.position.z);
      } else if (mode === 'CONSTRUCTION') {
        camera.position.set(0, 240, 360);
        controls.target.set(0, 0, 0);
      }
    };

    // Initial Mesh Build
    rebuildAllMeshes();

    // Render loop
    let lastTime = performance.now();
    let frameCount = 0;
    let animId: number;

    const animate = () => {
      animId = requestAnimationFrame(animate);

      const now = performance.now();
      frameCount++;
      if (now - lastTime >= 1000) {
        setFps(frameCount);
        frameCount = 0;
        lastTime = now;
      }

      controls.update();
      updateVehiclePositions();
      updateCameraPosition();
      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    // Subscribe to State Changes
    const unsubscribe = digitalTwinStore.subscribe((newState) => {
      stateRef.current = newState;
      setTwinState(newState);
      rebuildAllMeshes();
    });

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      unsubscribe();
      if (container && renderer.domElement && container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  const handleCanvasClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current || !cameraRef.current || !cornerMarkersGroupRef.current) return;

    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(x, y), cameraRef.current);

    const intersects = raycaster.intersectObjects(cornerMarkersGroupRef.current.children, true);
    if (intersects.length > 0) {
      const hit = intersects[0].object;
      if (hit.userData && hit.userData.cornerId && onCornerSelect) {
        onCornerSelect(hit.userData.cornerId);
      }
    }
  };

  return (
    <div
      ref={containerRef}
      onClick={handleCanvasClick}
      className="relative w-full h-full cursor-crosshair select-none bg-[#0a0a0c] overflow-hidden"
    >
      {/* Background Radial Dots Grid Matching Theme */}
      <div
        className="absolute inset-0 opacity-20 pointer-events-none z-0"
        style={{
          backgroundImage: 'radial-gradient(#334155 1px, transparent 1px)',
          backgroundSize: '40px 40px'
        }}
      />

      {/* Floating HUD Badges */}
      <div className="absolute top-4 left-4 flex flex-wrap items-center gap-2 z-10 pointer-events-none">
        <div className="bg-slate-900/80 backdrop-blur border border-slate-700 px-3 py-1.5 rounded">
          <span className="text-[10px] text-slate-500 block uppercase font-bold tracking-widest leading-none">GPU Renderer</span>
          <span className="text-xs text-white font-mono font-bold leading-tight">{fps} FPS</span>
        </div>
        <div className="bg-indigo-600/20 backdrop-blur border border-indigo-500/30 px-3 py-1.5 rounded text-[10px] text-indigo-300 font-bold">
          OVERLAY: {twinState.overlayMode}
        </div>
        <div className="bg-slate-800/80 backdrop-blur border border-slate-700 px-3 py-1.5 rounded text-[10px] text-slate-400 font-bold">
          ELEVATION EXAGGERATION: {twinState.geometry.elevationExaggeration}×
        </div>
      </div>

      <div className="absolute bottom-4 left-4 px-3 py-1.5 rounded bg-slate-900/80 backdrop-blur border border-slate-700 text-[10px] font-mono text-slate-400 z-10 pointer-events-none flex items-center gap-2">
        <span className="text-emerald-400 font-bold">[PYTHON SIM]</span>
        <span>• Geometry & Physics</span>
        <span className="text-indigo-400 font-bold">[R ANALYTICS]</span>
        <span>• Metrics</span>
        <span className="text-cyan-400 font-bold">[KOTLIN 3D]</span>
        <span>• WebGL Render</span>
      </div>
    </div>
  );
};
