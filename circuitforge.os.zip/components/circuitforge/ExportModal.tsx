'use client';

import React, { useState } from 'react';
import { TrackDigitalTwinState } from '@/lib/circuitforge/types';
import { Download, FileCode, FileText, Image as ImageIcon, MapPin, X, Check } from 'lucide-react';

interface ExportModalProps {
  state: TrackDigitalTwinState;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ state, onClose }) => {
  const [downloadedFormat, setDownloadedFormat] = useState<string | null>(null);

  const downloadFile = (filename: string, content: string, type: string) => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setDownloadedFormat(filename);
    setTimeout(() => setDownloadedFormat(null), 3000);
  };

  const handleExportJson = () => {
    const jsonStr = JSON.stringify(state, null, 2);
    downloadFile('circuitforge_project.circuitforge', jsonStr, 'application/json');
  };

  const handleExportCsv = () => {
    let csv = 'Distance_m,X,Y,Z,Elevation_m,Banking_deg,Speed_kmh,LateralG,LongitudinalG,Curvature\n';
    state.geometry.points.forEach((p) => {
      csv += `${p.distance.toFixed(2)},${p.center.x.toFixed(2)},${p.center.y.toFixed(2)},${p.center.z.toFixed(2)},${p.elevation.toFixed(2)},${p.banking.toFixed(2)},${p.speed.toFixed(1)},${p.lateralG.toFixed(2)},${p.longitudinalG.toFixed(2)},${p.curvature.toFixed(6)}\n`;
    });
    downloadFile('circuitforge_telemetry.csv', csv, 'text/csv');
  };

  const handleExportGeoJson = () => {
    const features = state.geometry.points.map((p) => ({
      type: 'Feature',
      geometry: {
        type: 'Point',
        coordinates: [p.center.x, p.center.z, p.center.y]
      },
      properties: {
        distance: p.distance,
        elevation: p.elevation,
        speed: p.speed,
        banking: p.banking
      }
    }));

    const geoJson = {
      type: 'FeatureCollection',
      features
    };
    downloadFile('circuitforge_layout.geojson', JSON.stringify(geoJson, null, 2), 'application/geo+json');
  };

  const handleExportSvg = () => {
    const points = state.geometry.points;
    const pathData = points
      .map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.center.x + 400} ${p.center.z + 400}`)
      .join(' ') + ' Z';

    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 800" width="800" height="800" style="background:#0a0d14;">
  <path d="${pathData}" fill="none" stroke="#38bdf8" stroke-width="12" stroke-linecap="round" stroke-linejoin="round"/>
  <text x="40" y="60" fill="#f8fafc" font-family="monospace" font-size="24" font-weight="bold">${state.geometry.name}</text>
  <text x="40" y="90" fill="#94a3b8" font-family="monospace" font-size="16">Length: ${(state.geometry.length / 1000).toFixed(2)} km | Corners: ${state.geometry.corners.length}</text>
</svg>`;

    downloadFile('circuitforge_map.svg', svg, 'image/svg+xml');
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center z-50 p-4 font-mono select-none">
      <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-xl w-full p-6 space-y-6 shadow-2xl">
        <div className="flex justify-between items-center border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <Download className="w-5 h-5 text-cyan-400" />
            <h2 className="text-lg font-extrabold text-slate-100 tracking-wider">
              EXPORT DIGITAL TWIN DATA
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {downloadedFormat && (
          <div className="p-3 bg-emerald-950/80 border border-emerald-500/50 rounded-lg text-emerald-300 text-xs font-bold flex items-center space-x-2">
            <Check className="w-4 h-4 text-emerald-400" />
            <span>Successfully exported {downloadedFormat}!</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Native .circuitforge Project File */}
          <button
            onClick={handleExportJson}
            className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-cyan-500 hover:bg-slate-950 text-left space-y-1.5 group transition-all"
          >
            <div className="flex items-center space-x-2 text-cyan-400 font-bold text-xs">
              <FileCode className="w-4 h-4" />
              <span>.CIRCUITFORGE PROJECT</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Full serialised state containing geometry, terrain, vehicle config, R analytics, and camera presets.
            </p>
          </button>

          {/* Telemetry CSV */}
          <button
            onClick={handleExportCsv}
            className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-emerald-500 hover:bg-slate-950 text-left space-y-1.5 group transition-all"
          >
            <div className="flex items-center space-x-2 text-emerald-400 font-bold text-xs">
              <FileText className="w-4 h-4" />
              <span>CSV TELEMETRY DATA</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Distance-indexed tabular telemetry (Speed, Lateral/Longitudinal G, Banking, Elevation, Curvature).
            </p>
          </button>

          {/* Vector SVG Map */}
          <button
            onClick={handleExportSvg}
            className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-purple-500 hover:bg-slate-950 text-left space-y-1.5 group transition-all"
          >
            <div className="flex items-center space-x-2 text-purple-400 font-bold text-xs">
              <ImageIcon className="w-4 h-4" />
              <span>SVG VECTOR CIRCUIT MAP</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Clean 2D engineering vector track map for CAD layout rendering and publications.
            </p>
          </button>

          {/* GIS GeoJSON */}
          <button
            onClick={handleExportGeoJson}
            className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-amber-500 hover:bg-slate-950 text-left space-y-1.5 group transition-all"
          >
            <div className="flex items-center space-x-2 text-amber-400 font-bold text-xs">
              <MapPin className="w-4 h-4" />
              <span>GeoJSON GIS LAYOUT</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Geospatial coordinate features for civil engineering GIS software and site integration.
            </p>
          </button>
        </div>

        <div className="border-t border-slate-800 pt-3 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-800 text-slate-200 hover:bg-slate-700 text-xs font-semibold"
          >
            CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};
