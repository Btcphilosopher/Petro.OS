'use client';

import React from 'react';
import { Corner, TrackGeometry } from '@/lib/circuitforge/types';
import { digitalTwinStore } from '@/lib/circuitforge/digitalTwinStream';
import { Sliders, CornerDownRight, Navigation, Layers, RotateCcw, AlertTriangle } from 'lucide-react';

interface DesignPanelProps {
  geometry: TrackGeometry;
  selectedCornerId: string | null;
  warnings: string[];
}

export const DesignPanel: React.FC<DesignPanelProps> = ({
  geometry,
  selectedCornerId,
  warnings
}) => {
  const selectedCorner = geometry.corners.find((c) => c.id === selectedCornerId) || geometry.corners[0];

  const handleGlobalWidthChange = (width: number) => {
    const updated = { ...geometry, defaultWidth: width };
    digitalTwinStore.updateGeometry(updated);
  };

  return (
    <aside className="w-64 border-r border-slate-800 bg-[#0d0d10] flex flex-col h-full overflow-y-auto select-none shrink-0 font-sans text-xs">
      <div className="p-4 border-b border-slate-800">
        <h2 className="text-[10px] uppercase tracking-widest text-slate-500 font-bold mb-4">
          Track Geometry
        </h2>

        {/* Track Geometry Metric Sliders / Bars */}
        <div className="space-y-4">
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="text-slate-400">Length</span>
              <span className="text-indigo-400 font-mono font-bold">{(geometry.length / 1000).toFixed(2)}km</span>
            </div>
            <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-indigo-500" style={{ width: `${Math.min(100, (geometry.length / 6000) * 100)}%` }}></div>
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="text-slate-400">Width</span>
              <span className="text-indigo-400 font-mono font-bold">{geometry.defaultWidth.toFixed(1)}m</span>
            </div>
            <div className="h-1 bg-slate-800 rounded-full overflow-hidden mb-1">
              <div className="h-full bg-indigo-500" style={{ width: `${((geometry.defaultWidth - 10) / 12) * 100}%` }}></div>
            </div>
            <input
              type="range"
              min="10"
              max="22"
              step="0.5"
              value={geometry.defaultWidth}
              onChange={(e) => handleGlobalWidthChange(parseFloat(e.target.value))}
              className="w-full accent-indigo-500 bg-slate-800 h-1 rounded cursor-pointer"
            />
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="text-slate-400">Corners</span>
              <span className="text-indigo-400 font-mono font-bold">{geometry.corners.length}</span>
            </div>
            <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-indigo-500" style={{ width: `${Math.min(100, (geometry.corners.length / 16) * 100)}%` }}></div>
            </div>
          </div>
        </div>
      </div>

      {/* Select Corner Selector */}
      <div className="p-4 border-b border-slate-800">
        <h2 className="text-[10px] uppercase tracking-widest text-slate-500 font-bold mb-3">
          Corner Inspector
        </h2>
        <select
          value={selectedCornerId || ''}
          onChange={(e) => digitalTwinStore.selectCorner(e.target.value)}
          className="w-full bg-[#111114] border border-slate-800 text-slate-200 rounded p-2 font-mono text-xs focus:outline-none focus:border-indigo-500 cursor-pointer"
        >
          {geometry.corners.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name} (R: {c.radius}m, {c.banking}°)
            </option>
          ))}
        </select>
      </div>

      {/* Interactive Corner Inspector Controls */}
      {selectedCorner && (
        <div className="p-4 space-y-4 border-b border-slate-800">
          <div className="flex justify-between items-center">
            <span className="text-xs font-bold text-white font-mono">{selectedCorner.name.toUpperCase()}</span>
            <span className="text-[10px] text-emerald-400 font-mono font-bold">
              APEX: {selectedCorner.apexSpeed} km/h
            </span>
          </div>

          {/* Radius */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-slate-400">Radius</span>
              <span className="text-indigo-400 font-mono font-bold">{selectedCorner.radius}m</span>
            </div>
            <input
              type="range"
              min="18"
              max="180"
              value={selectedCorner.radius}
              onChange={(e) =>
                digitalTwinStore.updateCorner(selectedCorner.id, { radius: parseFloat(e.target.value) })
              }
              className="w-full accent-indigo-500 bg-slate-800 h-1 rounded cursor-pointer"
            />
          </div>

          {/* Angle */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-slate-400">Angle</span>
              <span className="text-indigo-400 font-mono font-bold">{selectedCorner.angle}°</span>
            </div>
            <input
              type="range"
              min="-160"
              max="160"
              value={selectedCorner.angle}
              onChange={(e) =>
                digitalTwinStore.updateCorner(selectedCorner.id, { angle: parseFloat(e.target.value) })
              }
              className="w-full accent-indigo-500 bg-slate-800 h-1 rounded cursor-pointer"
            />
          </div>

          {/* Banking */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-slate-400">Banking</span>
              <span className="text-indigo-400 font-mono font-bold">{selectedCorner.banking}°</span>
            </div>
            <input
              type="range"
              min="-5"
              max="15"
              step="0.5"
              value={selectedCorner.banking}
              onChange={(e) =>
                digitalTwinStore.updateCorner(selectedCorner.id, { banking: parseFloat(e.target.value) })
              }
              className="w-full accent-indigo-500 bg-slate-800 h-1 rounded cursor-pointer"
            />
          </div>

          {/* Camber */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-slate-400">Camber</span>
              <span className="text-indigo-400 font-mono font-bold">{selectedCorner.camber}°</span>
            </div>
            <input
              type="range"
              min="-4"
              max="4"
              step="0.5"
              value={selectedCorner.camber}
              onChange={(e) =>
                digitalTwinStore.updateCorner(selectedCorner.id, { camber: parseFloat(e.target.value) })
              }
              className="w-full accent-indigo-500 bg-slate-800 h-1 rounded cursor-pointer"
            />
          </div>

          {/* Elevation */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-slate-400">Elevation</span>
              <span className="text-indigo-400 font-mono font-bold">{selectedCorner.elevation}m</span>
            </div>
            <input
              type="range"
              min="-10"
              max="45"
              value={selectedCorner.elevation}
              onChange={(e) =>
                digitalTwinStore.updateCorner(selectedCorner.id, {
                  elevation: parseFloat(e.target.value),
                  controlPoint: {
                    ...selectedCorner.controlPoint,
                    y: parseFloat(e.target.value)
                  }
                })
              }
              className="w-full accent-indigo-500 bg-slate-800 h-1 rounded cursor-pointer"
            />
          </div>
        </div>
      )}

      {/* Warnings Display */}
      {warnings.length > 0 && (
        <div className="p-4 space-y-2 bg-amber-500/5 border-b border-amber-500/20">
          <div className="flex items-center gap-1.5 text-amber-400 font-bold text-[10px] uppercase">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Design Warnings</span>
          </div>
          {warnings.map((w, idx) => (
            <p key={idx} className="text-[10px] text-amber-200/80 leading-tight font-mono">
              • {w}
            </p>
          ))}
        </div>
      )}

      {/* Bottom CTA Button matching Sleek Interface theme */}
      <div className="mt-auto p-4 border-t border-slate-800 bg-[#111114]">
        <button
          onClick={() => digitalTwinStore.setStudioMode('ANALYSE')}
          className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2 rounded text-xs transition-all flex items-center justify-center gap-2 shadow-md shadow-indigo-500/20"
        >
          <Sliders className="w-4 h-4" />
          ANALYSE SPECS
        </button>
      </div>
    </aside>
  );
};
