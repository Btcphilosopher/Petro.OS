'use client';

import React from 'react';
import { ConstructionState, TrackGeometry, ConstructionPhase } from '@/lib/circuitforge/types';
import { digitalTwinStore } from '@/lib/circuitforge/digitalTwinStream';
import { HardHat, Truck, DollarSign, Calendar, Layers } from 'lucide-react';

interface ConstructionPanelProps {
  construction: ConstructionState;
  geometry: TrackGeometry;
}

export const ConstructionPanel: React.FC<ConstructionPanelProps> = ({
  construction,
  geometry
}) => {
  const phases: { phase: ConstructionPhase; label: string }[] = [
    { phase: 'SITE', label: '1. SITE PREPARATION & CLEARING' },
    { phase: 'EARTHWORK', label: '2. EARTHWORKS (CUT & FILL)' },
    { phase: 'DRAINAGE', label: '3. SUB-SURFACE DRAINAGE' },
    { phase: 'SUBBASE', label: '4. AGGREGATE SUBBASE LAYER' },
    { phase: 'PAVEMENT', label: '5. ASPHALT PAVEMENT (FIA GRADE)' },
    { phase: 'KERBS', label: '6. KERBS & APEX STRIPING' },
    { phase: 'RUNOFF', label: '7. GRAVEL & ASPHALT RUNOFF' },
    { phase: 'BARRIERS', label: '8. TECPRO & CATCH FENCING' },
    { phase: 'PIT_COMPLEX', label: '9. PIT BUILDING & PADDOCK' },
    { phase: 'FINISHED', label: '10. FINISHED GRAND PRIX CIRCUIT' }
  ];

  return (
    <aside className="w-80 h-full bg-[#0d0d10] border-r border-slate-800 flex flex-col justify-between p-4 overflow-y-auto text-xs font-sans select-none shrink-0">
      <div>
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-4">
          <div className="flex items-center space-x-2">
            <HardHat className="w-4 h-4 text-indigo-400" />
            <h2 className="font-extrabold text-xs text-slate-100 tracking-wider uppercase">
              Civil Engineering Dashboard
            </h2>
          </div>
          <span className="px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 text-[10px] font-mono font-bold">
            [CIVIL ENG]
          </span>
        </div>

        {/* Construction Phase Progress */}
        <div className="bg-[#111114] p-3.5 rounded border border-slate-800 mb-5 space-y-2 shadow-sm">
          <div className="flex justify-between items-center text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            <span>CONSTRUCTION SEQUENCE</span>
            <span className="text-indigo-400 font-mono font-extrabold">{construction.progress}% COMPLETE</span>
          </div>

          <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.5)] transition-all duration-300"
              style={{ width: `${construction.progress}%` }}
            />
          </div>
        </div>

        {/* Phase Selector Buttons */}
        <div className="space-y-1.5 mb-5">
          <label className="text-slate-500 font-bold text-[10px] uppercase tracking-wider block mb-2">
            SELECT CONSTRUCTION LAYER:
          </label>
          {phases.map((p) => {
            const isActive = construction.phase === p.phase;
            return (
              <button
                key={p.phase}
                onClick={() => digitalTwinStore.setConstructionPhase(p.phase)}
                className={`w-full text-left px-3 py-1.5 rounded text-[11px] font-semibold flex items-center justify-between border transition-all ${
                  isActive
                    ? 'bg-indigo-600/20 border-indigo-500/50 text-indigo-300 font-bold'
                    : 'bg-[#111114] border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                <span>{p.label}</span>
                {isActive && <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />}
              </button>
            );
          })}
        </div>

        {/* Earthworks & Civil Telemetry */}
        <div className="bg-[#111114] rounded border border-slate-800 overflow-hidden space-y-0 text-xs shadow-sm">
          <div className="bg-[#0d0d10] px-3 py-2 border-b border-slate-800 font-bold text-slate-300 flex items-center space-x-1.5 uppercase text-[10px] tracking-wider">
            <Truck className="w-3.5 h-3.5 text-indigo-400" />
            <span>EARTHWORKS & CIVIL TELEMETRY</span>
          </div>

          <div className="p-3 divide-y divide-slate-800/80">
            <div className="flex justify-between py-1.5 items-baseline">
              <span className="text-slate-400">CUT VOLUME (EXCAVATION):</span>
              <span className="font-extrabold text-red-400 font-mono">{(construction.cutVolume / 1000).toFixed(0)}k m³</span>
            </div>
            <div className="flex justify-between py-1.5 items-baseline">
              <span className="text-slate-400">FILL VOLUME (EMBANKMENT):</span>
              <span className="font-extrabold text-indigo-400 font-mono">{(construction.fillVolume / 1000).toFixed(0)}k m³</span>
            </div>
            <div className="flex justify-between py-1.5 items-baseline">
              <span className="text-slate-400">CUT / FILL BALANCE:</span>
              <span className="font-bold text-emerald-400 font-mono">
                {Math.abs(construction.cutVolume - construction.fillVolume) < 50000 ? 'BALANCED' : 'IMPORT NEEDED'}
              </span>
            </div>
            <div className="flex justify-between py-1.5 items-baseline">
              <span className="text-slate-400">ESTIMATED DURATION:</span>
              <span className="font-bold text-slate-200 font-mono">{construction.constructionDays} DAYS</span>
            </div>
            <div className="flex justify-between py-1.5 items-baseline">
              <span className="text-slate-400">TOTAL ESTIMATED BUDGET:</span>
              <span className="font-extrabold text-indigo-300 font-mono">
                ${(construction.totalCost / 1000000).toFixed(1)}M USD
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="pt-4 border-t border-slate-800 text-[10px] text-slate-500 text-center font-mono">
        <span>CIVIL ENGINEERING & EARTHWORKS COST MODEL</span>
      </div>
    </aside>
  );
};
