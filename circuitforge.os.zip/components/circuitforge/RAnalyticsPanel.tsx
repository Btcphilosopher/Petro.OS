'use client';

import React from 'react';
import { AnalyticsState, OverlayMode, ScenarioType } from '@/lib/circuitforge/types';
import { digitalTwinStore } from '@/lib/circuitforge/digitalTwinStream';
import { PieChart, Layers, CloudRain, ShieldCheck, Cpu, SlidersHorizontal, BarChart3 } from 'lucide-react';

interface RAnalyticsPanelProps {
  analytics: AnalyticsState;
  overlayMode: OverlayMode;
  scenario: ScenarioType;
}

export const RAnalyticsPanel: React.FC<RAnalyticsPanelProps> = ({
  analytics,
  overlayMode,
  scenario
}) => {
  const overlays: { mode: OverlayMode; label: string }[] = [
    { mode: 'SPEED', label: 'SPEED GRADIENT' },
    { mode: 'CURVATURE', label: 'CURVATURE OVERLAY' },
    { mode: 'BRAKING', label: 'BRAKING ZONES' },
    { mode: 'LATERAL_G', label: 'LATERAL G-FORCE' },
    { mode: 'GRADIENT', label: 'ELEVATION GRADIENT' },
    { mode: 'BANKING', label: 'TRACK BANKING' },
    { mode: 'COST', label: 'SPATIAL COST MAP' },
    { mode: 'EARTHWORKS', label: 'EARTHWORKS CUT/FILL' },
    { mode: 'OPTIMISATION', label: 'PERFORMANCE HEATMAP' }
  ];

  const scenarios: { type: ScenarioType; label: string }[] = [
    { type: 'DRY', label: 'DRY TRACK (STANDARD)' },
    { type: 'WET', label: 'WET CONDITIONS (82% GRIP)' },
    { type: 'HIGH_GRIP', label: 'HIGH GRIP SPEC (110%)' },
    { type: 'LOW_GRIP', label: 'LOW GRIP / DUST (88%)' },
    { type: 'PRO_DRIVER', label: 'PRO DRIVER (MAX LIMIT)' },
    { type: 'AMATEUR_DRIVER', label: 'AMATEUR DRIVER (90%)' },
    { type: 'HEAVY_TRAFFIC', label: 'HEAVY TRAFFIC (DRAFTING)' }
  ];

  return (
    <aside className="w-80 h-full bg-[#0d0d10] border-r border-slate-800 flex flex-col justify-between p-4 overflow-y-auto text-xs font-sans select-none shrink-0">
      <div>
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-4">
          <div className="flex items-center space-x-2">
            <PieChart className="w-4 h-4 text-indigo-400" />
            <h2 className="font-extrabold text-xs text-slate-100 tracking-wider uppercase">
              R Analytics Output
            </h2>
          </div>
          <span className="px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 text-[10px] font-mono font-bold">
            [R ENGINE]
          </span>
        </div>

        {/* Primary R Metrics Card */}
        <div className="bg-[#111114] rounded border border-slate-800 overflow-hidden mb-5 shadow-sm">
          <div className="bg-[#0d0d10] px-3 py-2 border-b border-slate-800 font-bold text-slate-300 flex justify-between items-center text-[10px] tracking-wider uppercase">
            <span>R ANALYTICS SUMMARY</span>
            <span className="text-indigo-400 font-mono">STATISTICAL MODEL</span>
          </div>

          <div className="p-3 divide-y divide-slate-800/80 text-xs">
            <div className="flex justify-between py-2 items-baseline">
              <span className="text-slate-400">Est. Lap Time</span>
              <span className="font-extrabold text-indigo-400 font-mono text-sm">{analytics.lapTimeFormatted}</span>
            </div>
            <div className="flex justify-between py-2 items-baseline">
              <span className="text-slate-400">Avg. Speed</span>
              <span className="font-bold text-slate-200 font-mono">{analytics.avgSpeed} km/h</span>
            </div>
            <div className="flex justify-between py-2 items-baseline">
              <span className="text-slate-400">Earthworks</span>
              <span className="font-bold text-slate-200 font-mono">{(analytics.earthworksVolume / 1000000).toFixed(2)}M m³</span>
            </div>
            <div className="flex justify-between py-2 items-baseline">
              <span className="text-slate-400">Complexity</span>
              <span className="font-bold text-slate-200 font-mono">{analytics.complexityScore} / 100</span>
            </div>
            <div className="flex justify-between py-2 items-baseline">
              <span className="text-slate-400">Overtaking Potential</span>
              <span className="font-bold text-emerald-400 font-mono">{analytics.overtakingPotential} / 100</span>
            </div>
            <div className="flex justify-between py-2 items-baseline">
              <span className="text-slate-400">Estimated Cost</span>
              <span className="font-bold text-indigo-300 font-mono">${(analytics.estimatedCost / 1000000).toFixed(1)}M USD</span>
            </div>
          </div>
        </div>

        {/* Circuit Design Score Radar / Bar Breakdown */}
        <div className="bg-[#111114] p-3.5 rounded border border-slate-800 mb-5 space-y-3 shadow-sm">
          <div className="flex justify-between items-center border-b border-slate-800 pb-1.5">
            <span className="font-bold text-slate-200 text-[10px] uppercase tracking-wider flex items-center space-x-1.5">
              <BarChart3 className="w-3.5 h-3.5 text-indigo-400" />
              <span>CIRCUIT DESIGN SCORE</span>
            </span>
            <span className="text-xl font-bold text-indigo-400 font-mono">
              {analytics.designScore.total}
            </span>
          </div>

          <div className="space-y-2 text-[10px]">
            <div>
              <div className="flex justify-between text-slate-400 mb-0.5">
                <span>LAP QUALITY ({analytics.scoreWeights.lapQuality * 100}%):</span>
                <span className="font-bold text-slate-200">{analytics.designScore.lapQuality}</span>
              </div>
              <div className="w-full h-1.5 bg-slate-950 rounded overflow-hidden">
                <div className="h-full bg-blue-500" style={{ width: `${analytics.designScore.lapQuality}%` }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-0.5">
                <span>CORNER VARIETY ({analytics.scoreWeights.cornerVariety * 100}%):</span>
                <span className="font-bold text-slate-200">{analytics.designScore.cornerVariety}</span>
              </div>
              <div className="w-full h-1.5 bg-slate-950 rounded overflow-hidden">
                <div className="h-full bg-purple-500" style={{ width: `${analytics.designScore.cornerVariety}%` }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-0.5">
                <span>OVERTAKING ({analytics.scoreWeights.overtaking * 100}%):</span>
                <span className="font-bold text-slate-200">{analytics.designScore.overtaking}</span>
              </div>
              <div className="w-full h-1.5 bg-slate-950 rounded overflow-hidden">
                <div className="h-full bg-emerald-500" style={{ width: `${analytics.designScore.overtaking}%` }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-0.5">
                <span>ELEVATION ({analytics.scoreWeights.elevationUse * 100}%):</span>
                <span className="font-bold text-slate-200">{analytics.designScore.elevationUse}</span>
              </div>
              <div className="w-full h-1.5 bg-slate-950 rounded overflow-hidden">
                <div className="h-full bg-amber-500" style={{ width: `${analytics.designScore.elevationUse}%` }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-0.5">
                <span>CONSTRUCTION EFFICIENCY ({analytics.scoreWeights.constructionEff * 100}%):</span>
                <span className="font-bold text-slate-200">{analytics.designScore.constructionEff}</span>
              </div>
              <div className="w-full h-1.5 bg-slate-950 rounded overflow-hidden">
                <div className="h-full bg-cyan-500" style={{ width: `${analytics.designScore.constructionEff}%` }} />
              </div>
            </div>
          </div>
        </div>

        {/* Scenario Engine Selector (Requirement #40) */}
        <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800 mb-5 space-y-2">
          <div className="flex items-center space-x-1.5 font-bold text-slate-200 text-xs">
            <CloudRain className="w-3.5 h-3.5 text-blue-400" />
            <span>R SCENARIO ENGINE</span>
          </div>

          <select
            value={scenario}
            onChange={(e) => digitalTwinStore.setScenario(e.target.value as ScenarioType)}
            className="w-full bg-slate-950 border border-slate-700 text-cyan-300 font-mono text-xs rounded p-2 focus:outline-none"
          >
            {scenarios.map((s) => (
              <option key={s.type} value={s.type}>
                {s.label}
              </option>
            ))}
          </select>
        </div>

        {/* Analytical Heatmaps Switcher */}
        <div className="space-y-2">
          <label className="text-slate-400 font-bold text-[10px] uppercase tracking-wider flex items-center space-x-1">
            <Layers className="w-3.5 h-3.5 text-indigo-400" />
            <span>3D TRACK ANALYTICAL OVERLAYS</span>
          </label>

          <div className="grid grid-cols-1 gap-1.5">
            {overlays.map((ov) => {
              const isActive = overlayMode === ov.mode;
              return (
                <button
                  key={ov.mode}
                  onClick={() => digitalTwinStore.setOverlayMode(ov.mode)}
                  className={`w-full text-left px-3 py-1.5 rounded text-[11px] font-semibold flex items-center justify-between border transition-all ${
                    isActive
                      ? 'bg-indigo-600/20 border-indigo-500/50 text-indigo-300 font-bold'
                      : 'bg-[#111114] border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                  }`}
                >
                  <span>{ov.label}</span>
                  {isActive && <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <div className="pt-4 border-t border-slate-800 text-[10px] text-slate-500 text-center font-mono">
        <span>R STATISTICAL FORECASTING & OPTIMISATION</span>
      </div>
    </aside>
  );
};
