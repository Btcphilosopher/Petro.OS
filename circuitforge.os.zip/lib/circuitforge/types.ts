// CIRCUITFORGE.OS Core Type Definitions

export type StudioMode = 'DESIGN' | 'SIMULATE' | 'ANALYSE' | 'BUILD' | 'CINEMATIC' | 'RACE';

export type CameraMode = 'TOP' | 'ISOMETRIC' | 'TRACKSIDE' | 'CHASE' | 'COCKPIT' | 'HELICOPTER' | 'CONSTRUCTION' | 'FREE';

export type OverlayMode = 
  | 'NONE'
  | 'SPEED'
  | 'CURVATURE'
  | 'BRAKING'
  | 'LATERAL_G'
  | 'GRADIENT'
  | 'BANKING'
  | 'COST'
  | 'EARTHWORKS'
  | 'OPTIMISATION';

export type ScenarioType = 'DRY' | 'WET' | 'HIGH_GRIP' | 'LOW_GRIP' | 'PRO_DRIVER' | 'AMATEUR_DRIVER' | 'HEAVY_TRAFFIC';

export type ConstructionPhase = 
  | 'SITE'
  | 'EARTHWORK'
  | 'DRAINAGE'
  | 'SUBBASE'
  | 'PAVEMENT'
  | 'KERBS'
  | 'RUNOFF'
  | 'BARRIERS'
  | 'PIT_COMPLEX'
  | 'FINISHED';

export interface Vector3D {
  x: number;
  y: number;
  z: number;
}

export interface Corner {
  id: string;
  number: number;
  name: string;
  radius: number; // in meters
  angle: number; // in degrees
  banking: number; // in degrees (-5 to 15)
  camber: number; // in degrees
  elevation: number; // in meters relative to base
  positionIndex: number; // index along track spline (0..1)
  entrySpeed: number; // km/h
  apexSpeed: number; // km/h
  exitSpeed: number; // km/h
  minRadius: number;
  controlPoint: Vector3D;
  type: 'hairpin' | 'sweeper' | 'chicane' | 'medium' | 'fast';
}

export interface Sector {
  id: number;
  name: string;
  startDistance: number; // meters
  endDistance: number; // meters
  bestTime: number; // seconds
  currentTime: number; // seconds
  delta: number; // seconds relative to ref
}

export interface TrackPoint {
  distance: number; // meters from start
  center: Vector3D;
  leftEdge: Vector3D;
  rightEdge: Vector3D;
  racingLinePoint: Vector3D;
  tangent: Vector3D;
  normal: Vector3D;
  elevation: number;
  banking: number; // degrees
  camber: number; // degrees
  width: number; // meters
  speed: number; // km/h calculated by Python engine
  brakingIntensity: number; // 0..1
  curvature: number; // 1/radius
  gradient: number; // % slope
  lateralG: number;
  longitudinalG: number;
  costZone: 'LOW' | 'MEDIUM' | 'HIGH';
  earthworksType: 'CUT' | 'FILL' | 'BALANCED';
  earthworksDepth: number; // meters
}

export interface TrackGeometry {
  id: string;
  name: string;
  length: number; // meters (e.g. 5420m)
  defaultWidth: number; // meters
  elevationExaggeration: number; // 1x, 2x, 5x, 10x
  corners: Corner[];
  sectors: Sector[];
  points: TrackPoint[];
}

export interface TerrainState {
  gridSize: number; // e.g., 60x60 grid
  width: number; // meters span
  length: number; // meters span
  demData: number[][]; // elevation DEM map
  contoursEnabled: boolean;
}

export interface VehicleState {
  id: string;
  name: string;
  number: number;
  driverModel: string;
  color: string;
  distance: number; // distance along track in meters
  lap: number;
  sector: number;
  speed: number; // km/h
  throttle: number; // 0..1
  brake: number; // 0..1
  gear: number;
  rpm: number;
  lateralG: number;
  longitudinalG: number;
  combinedG: number;
  roll: number; // degrees
  pitch: number; // degrees
  position: Vector3D;
  rotation: number; // yaw in radians
}

export interface TelemetryState {
  currentDistance: number;
  currentLapTime: number; // seconds
  bestLapTime: number; // seconds
  refLapTime: number; // seconds
  prevLapTime: number; // seconds
  sectors: Sector[];
  graphData: {
    distance: number;
    speed: number;
    brake: number;
    throttle: number;
    lateralG: number;
    longitudinalG: number;
  }[];
}

export interface AnalyticsState {
  lapTime: number; // seconds
  lapTimeFormatted: string; // "1:47.32"
  avgSpeed: number; // km/h
  maxSpeed: number; // km/h
  cornersCount: number;
  complexityScore: number; // 0-100
  overtakingPotential: number; // 0-100
  earthworksVolume: number; // m3
  siteArea: number; // km2
  pavementArea: number; // m2
  estimatedCost: number; // USD
  riskIndex: number; // 0-100
  designScore: {
    total: number;
    lapQuality: number;
    cornerVariety: number;
    overtaking: number;
    elevationUse: number;
    constructionEff: number;
    earthworksBal: number;
  };
  scoreWeights: {
    lapQuality: number;
    cornerVariety: number;
    overtaking: number;
    elevationUse: number;
    constructionEff: number;
    earthworksBal: number;
  };
}

export interface ConstructionState {
  phase: ConstructionPhase;
  progress: number; // 0..100%
  cutVolume: number; // m3
  fillVolume: number; // m3
  haulDistance: number; // km
  pavementArea: number; // m2
  drainageLength: number; // meters
  totalCost: number; // USD
  constructionDays: number;
  isAnimating: boolean;
}

export interface CandidateDesign {
  id: string;
  name: string;
  lengthKm: number;
  lapTimeStr: string;
  lapTimeSec: number;
  costMillion: number;
  earthworksMillionM3: number;
  overtakingScore: number;
  designScore: number;
  trackGeometry: TrackGeometry;
  analytics: AnalyticsState;
}

export interface TimelineKeyframe {
  id: string;
  timeSeconds: number;
  cornerId: string;
  cornerNumber: number;
  parameter: 'radius' | 'banking' | 'elevation';
  value: number;
}

export interface SystemEngineStatus {
  pythonOnline: boolean;
  pythonLatencyMs: number;
  rOnline: boolean;
  rLatencyMs: number;
  kotlinFps: number;
}

export interface TrackDigitalTwinState {
  geometry: TrackGeometry;
  terrain: TerrainState;
  vehicles: VehicleState[];
  telemetry: TelemetryState;
  analytics: AnalyticsState;
  construction: ConstructionState;
  candidateDesigns: CandidateDesign[];
  activeCandidateId: string | null;
  selectedCornerId: string | null;
  studioMode: StudioMode;
  cameraMode: CameraMode;
  overlayMode: OverlayMode;
  scenario: ScenarioType;
  simulationSpeed: number; // 0.25, 0.5, 1, 2, 5, 10, 100
  isSimulating: boolean;
  timeScrubber: number; // 0..1 (progress along lap)
  history: TrackGeometry[];
  historyIndex: number;
  keyframes: TimelineKeyframe[];
  warnings: string[];
  engineStatus: SystemEngineStatus;
}
