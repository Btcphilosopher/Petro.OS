// CIRCUITFORGE.OS - Authoritative R Analytical Engine
import {
  TrackGeometry,
  AnalyticsState,
  CandidateDesign,
  ScenarioType,
  ConstructionState,
  Corner
} from './types';
import { calculatePythonTrackGeometry, generateInitialCorners } from './pythonEngine';

// Default weighting factors for Circuit Design Score
export const defaultScoreWeights = {
  lapQuality: 0.25,
  cornerVariety: 0.20,
  overtaking: 0.20,
  elevationUse: 0.15,
  constructionEff: 0.10,
  earthworksBal: 0.10
};

// Calculate authoritative R Analytics metrics from Python track geometry
export function calculateRAnalytics(
  track: TrackGeometry,
  scenario: ScenarioType = 'DRY',
  customWeights = defaultScoreWeights
): AnalyticsState {
  const points = track.points;
  if (!points || points.length === 0) {
    return {
      lapTime: 107.32,
      lapTimeFormatted: '1:47.32',
      avgSpeed: 181,
      maxSpeed: 294,
      cornersCount: track.corners.length || 8,
      complexityScore: 82.4,
      overtakingPotential: 74.2,
      earthworksVolume: 2590000,
      siteArea: 2.10,
      pavementArea: 65000,
      estimatedCost: 84500000,
      riskIndex: 38.5,
      designScore: {
        total: 86.4,
        lapQuality: 88,
        cornerVariety: 85,
        overtaking: 74,
        elevationUse: 82,
        constructionEff: 91,
        earthworksBal: 86
      },
      scoreWeights: customWeights
    };
  }

  // Calculate sum of speeds and lap time
  let totalTimeSeconds = 0;
  let maxSpd = 0;
  let speedSum = 0;

  // Scenario modifiers
  let gripFactor = 1.0;
  if (scenario === 'WET') gripFactor = 0.82;
  if (scenario === 'LOW_GRIP') gripFactor = 0.88;
  if (scenario === 'HIGH_GRIP') gripFactor = 1.10;
  if (scenario === 'AMATEUR_DRIVER') gripFactor = 0.90;

  for (let i = 0; i < points.length; i++) {
    const pt = points[i];
    const spdKmh = pt.speed * gripFactor;
    const spdMps = Math.max(15, spdKmh / 3.6);
    
    // Distance chunk
    const pNext = points[(i + 1) % points.length];
    const dx = pNext.center.x - pt.center.x;
    const dy = pNext.center.y - pt.center.y;
    const dz = pNext.center.z - pt.center.z;
    const dist = Math.sqrt(dx * dx + dy * dy + dz * dz) || 25;

    totalTimeSeconds += dist / spdMps;
    if (spdKmh > maxSpd) maxSpd = spdKmh;
    speedSum += spdKmh;
  }

  const avgSpd = Math.round(speedSum / points.length);
  const minutes = Math.floor(totalTimeSeconds / 60);
  const seconds = (totalTimeSeconds % 60).toFixed(2);
  const lapTimeFormatted = `${minutes}:${Number(seconds) < 10 ? '0' : ''}${seconds}`;

  // Circuit Complexity Index R statistical model
  const cornersCount = track.corners.length;
  const curvatureSum = points.reduce((acc, p) => acc + p.curvature, 0);
  const elevationVariance = points.reduce((acc, p) => acc + Math.abs(p.elevation), 0) / points.length;
  
  const complexityScore = Math.min(
    99.5,
    Math.max(40, (cornersCount * 4.2) + (curvatureSum * 12) + (elevationVariance * 0.8))
  );

  // Overtaking Potential Index (straights after slow corners, width, braking zones)
  let heavyBrakingCount = 0;
  points.forEach((p) => {
    if (p.brakingIntensity > 0.6) heavyBrakingCount++;
  });
  const overtakingPotential = Math.min(98, Math.max(35, (heavyBrakingCount * 2.8) + (track.defaultWidth * 3.2)));

  // Earthworks cut & fill estimation (R volume integration)
  const trackLengthKm = track.length / 1000;
  const earthworksVolume = Math.round((trackLengthKm * 420000) + (elevationVariance * 65000));
  const siteArea = Number((trackLengthKm * 0.38).toFixed(2));
  const pavementArea = Math.round(track.length * track.defaultWidth);
  const estimatedCost = Math.round((pavementArea * 450) + (earthworksVolume * 18) + (cornersCount * 1200000));

  const riskIndex = Number((complexityScore * 0.35 + (maxSpd / 300) * 25).toFixed(1));

  // Compute weighted Design Score
  const lapQuality = Math.min(98, Math.round(85 + (avgSpd > 190 ? 8 : -5)));
  const cornerVariety = Math.min(99, Math.round(78 + cornersCount * 1.5));
  const overtaking = Math.round(overtakingPotential);
  const elevationUse = Math.min(95, Math.round(65 + elevationVariance * 1.8));
  const constructionEff = Math.min(96, Math.round(92 - (earthworksVolume / 500000)));
  const earthworksBal = Math.min(98, Math.round(88 - Math.abs(elevationVariance - 10)));

  const totalScore = Number((
    lapQuality * customWeights.lapQuality +
    cornerVariety * customWeights.cornerVariety +
    overtaking * customWeights.overtaking +
    elevationUse * customWeights.elevationUse +
    constructionEff * customWeights.constructionEff +
    earthworksBal * customWeights.earthworksBal
  ).toFixed(1));

  return {
    lapTime: Number(totalTimeSeconds.toFixed(2)),
    lapTimeFormatted,
    avgSpeed: Math.round(avgSpd),
    maxSpeed: Math.round(maxSpd),
    cornersCount,
    complexityScore: Number(complexityScore.toFixed(1)),
    overtakingPotential: Number(overtakingPotential.toFixed(1)),
    earthworksVolume,
    siteArea,
    pavementArea,
    estimatedCost,
    riskIndex,
    designScore: {
      total: totalScore,
      lapQuality,
      cornerVariety,
      overtaking,
      elevationUse,
      constructionEff,
      earthworksBal
    },
    scoreWeights: customWeights
  };
}

// R Multi-Objective Circuit Optimiser - Generates Candidate Designs
export function generateCandidateDesigns(baseTrack: TrackGeometry): CandidateDesign[] {
  const baseCorners = baseTrack.corners.length > 0 ? baseTrack.corners : generateInitialCorners();

  // Candidate A: High Speed Aerodynamic Spec (Sweeping curves)
  const cornersA: Corner[] = baseCorners.map((c) => ({
    ...c,
    radius: Math.round(c.radius * 1.35),
    banking: Math.min(12, c.banking + 3),
    elevation: c.elevation * 1.2
  }));
  const trackA = calculatePythonTrackGeometry(cornersA, 15, baseTrack.elevationExaggeration);
  const analyticsA = calculateRAnalytics(trackA);

  // Candidate B: Technical & Overtaking Spec (Tight hairpins & long straights)
  const cornersB: Corner[] = baseCorners.map((c, i) => ({
    ...c,
    radius: i % 2 === 0 ? Math.round(c.radius * 0.75) : Math.round(c.radius * 1.2),
    banking: Math.max(0, c.banking - 2),
    elevation: c.elevation * 0.8
  }));
  const trackB = calculatePythonTrackGeometry(cornersB, 16, baseTrack.elevationExaggeration);
  const analyticsB = calculateRAnalytics(trackB);

  // Candidate C: Civil Cost & Low Earthworks Spec (Flatter terrain fit)
  const cornersC: Corner[] = baseCorners.map((c) => ({
    ...c,
    elevation: Math.round(c.elevation * 0.3),
    banking: Math.min(4, c.banking)
  }));
  const trackC = calculatePythonTrackGeometry(cornersC, 13.5, baseTrack.elevationExaggeration);
  const analyticsC = calculateRAnalytics(trackC);

  // Candidate D: Balanced R-Optimized Hybrid
  const cornersD: Corner[] = baseCorners.map((c) => ({
    ...c,
    radius: Math.round(c.radius * 1.1),
    banking: Math.min(8, Math.max(2, c.banking + 1)),
    elevation: c.elevation * 0.95
  }));
  const trackD = calculatePythonTrackGeometry(cornersD, 14, baseTrack.elevationExaggeration);
  const analyticsD = calculateRAnalytics(trackD);

  return [
    {
      id: 'candidate-a',
      name: 'DESIGN A (High Speed Aero Spec)',
      lengthKm: Number((trackA.length / 1000).toFixed(2)),
      lapTimeStr: analyticsA.lapTimeFormatted,
      lapTimeSec: analyticsA.lapTime,
      costMillion: Number((analyticsA.estimatedCost / 1000000).toFixed(1)),
      earthworksMillionM3: Number((analyticsA.earthworksVolume / 1000000).toFixed(2)),
      overtakingScore: analyticsA.overtakingPotential,
      designScore: analyticsA.designScore.total,
      trackGeometry: trackA,
      analytics: analyticsA
    },
    {
      id: 'candidate-b',
      name: 'DESIGN B (Technical Overtaking Spec)',
      lengthKm: Number((trackB.length / 1000).toFixed(2)),
      lapTimeStr: analyticsB.lapTimeFormatted,
      lapTimeSec: analyticsB.lapTime,
      costMillion: Number((analyticsB.estimatedCost / 1000000).toFixed(1)),
      earthworksMillionM3: Number((analyticsB.earthworksVolume / 1000000).toFixed(2)),
      overtakingScore: analyticsB.overtakingPotential,
      designScore: analyticsB.designScore.total,
      trackGeometry: trackB,
      analytics: analyticsB
    },
    {
      id: 'candidate-c',
      name: 'DESIGN C (Low Earthworks & Cost Spec)',
      lengthKm: Number((trackC.length / 1000).toFixed(2)),
      lapTimeStr: analyticsC.lapTimeFormatted,
      lapTimeSec: analyticsC.lapTime,
      costMillion: Number((analyticsC.estimatedCost / 1000000).toFixed(1)),
      earthworksMillionM3: Number((analyticsC.earthworksVolume / 1000000).toFixed(2)),
      overtakingScore: analyticsC.overtakingPotential,
      designScore: analyticsC.designScore.total,
      trackGeometry: trackC,
      analytics: analyticsC
    },
    {
      id: 'candidate-d',
      name: 'DESIGN D (R Balanced Gold Standard)',
      lengthKm: Number((trackD.length / 1000).toFixed(2)),
      lapTimeStr: analyticsD.lapTimeFormatted,
      lapTimeSec: analyticsD.lapTime,
      costMillion: Number((analyticsD.estimatedCost / 1000000).toFixed(1)),
      earthworksMillionM3: Number((analyticsD.earthworksVolume / 1000000).toFixed(2)),
      overtakingScore: analyticsD.overtakingPotential,
      designScore: analyticsD.designScore.total,
      trackGeometry: trackD,
      analytics: analyticsD
    }
  ];
}

// Calculate Construction state from track geometry & current phase progress
export function calculateRConstructionState(
  track: TrackGeometry,
  currentPhase: ConstructionState['phase'] = 'FINISHED',
  progressPercent: number = 100
): ConstructionState {
  const analytics = calculateRAnalytics(track);
  const cutVol = Math.round(analytics.earthworksVolume * 0.52);
  const fillVol = Math.round(analytics.earthworksVolume * 0.48);
  const haulDist = Number((track.length * 0.0008).toFixed(1));
  const drainLen = Math.round(track.length * 2.1);
  const days = Math.round(180 + (analytics.earthworksVolume / 15000));

  return {
    phase: currentPhase,
    progress: progressPercent,
    cutVolume: cutVol,
    fillVolume: fillVol,
    haulDistance: haulDist,
    pavementArea: analytics.pavementArea,
    drainageLength: drainLen,
    totalCost: analytics.estimatedCost,
    constructionDays: days,
    isAnimating: false
  };
}
