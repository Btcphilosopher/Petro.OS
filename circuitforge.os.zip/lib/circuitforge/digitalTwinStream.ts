// CIRCUITFORGE.OS - Digital Twin State Engine & Event Stream
import {
  TrackDigitalTwinState,
  TrackGeometry,
  Corner,
  StudioMode,
  CameraMode,
  OverlayMode,
  ScenarioType,
  ConstructionPhase,
  CandidateDesign,
  AnalyticsState
} from './types';
import {
  calculatePythonTrackGeometry,
  generateInitialCorners,
  generateTerrainDEM,
  createInitialVehicles
} from './pythonEngine';
import {
  calculateRAnalytics,
  generateCandidateDesigns,
  calculateRConstructionState,
  defaultScoreWeights
} from './rAnalytics';

type StateListener = (state: TrackDigitalTwinState) => void;

class DigitalTwinStore {
  private state: TrackDigitalTwinState;
  private listeners: Set<StateListener> = new Set();
  private animFrameId: number | null = null;
  private lastTimestamp: number = 0;

  constructor() {
    const initialCorners = generateInitialCorners();
    const geometry = calculatePythonTrackGeometry(initialCorners, 14, 1.0);
    const terrain = generateTerrainDEM(geometry);
    const vehicles = createInitialVehicles(3, geometry);
    const analytics = calculateRAnalytics(geometry, 'DRY');
    const construction = calculateRConstructionState(geometry, 'FINISHED', 100);
    const candidates = generateCandidateDesigns(geometry);

    this.state = {
      geometry,
      terrain,
      vehicles,
      telemetry: {
        currentDistance: 0,
        currentLapTime: 0,
        bestLapTime: analytics.lapTime,
        refLapTime: analytics.lapTime + 0.45,
        prevLapTime: analytics.lapTime + 0.18,
        sectors: geometry.sectors,
        graphData: geometry.points.map((p) => ({
          distance: p.distance,
          speed: p.speed,
          brake: p.brakingIntensity,
          throttle: p.brakingIntensity > 0.1 ? 0 : 1.0,
          lateralG: p.lateralG,
          longitudinalG: p.longitudinalG
        }))
      },
      analytics,
      construction,
      candidateDesigns: candidates,
      activeCandidateId: null,
      selectedCornerId: 'corner-7',
      studioMode: 'DESIGN',
      cameraMode: 'ISOMETRIC',
      overlayMode: 'SPEED',
      scenario: 'DRY',
      simulationSpeed: 1.0,
      isSimulating: true,
      timeScrubber: 0,
      history: [geometry],
      historyIndex: 0,
      keyframes: [],
      warnings: this.evaluateConstraintWarnings(geometry),
      engineStatus: {
        pythonOnline: true,
        pythonLatencyMs: 14,
        rOnline: true,
        rLatencyMs: 22,
        kotlinFps: 60
      }
    };
  }

  public getState(): TrackDigitalTwinState {
    return this.state;
  }

  public subscribe(listener: StateListener): () => void {
    this.listeners.add(listener);
    listener(this.state);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    this.listeners.forEach((listener) => listener(this.state));
  }

  public setStudioMode(mode: StudioMode) {
    this.state = { ...this.state, studioMode: mode };
    this.notify();
  }

  public setCameraMode(mode: CameraMode) {
    this.state = { ...this.state, cameraMode: mode };
    this.notify();
  }

  public setOverlayMode(mode: OverlayMode) {
    this.state = { ...this.state, overlayMode: mode };
    this.notify();
  }

  public setScenario(scenario: ScenarioType) {
    const analytics = calculateRAnalytics(this.state.geometry, scenario, this.state.analytics.scoreWeights);
    this.state = {
      ...this.state,
      scenario,
      analytics
    };
    this.notify();
  }

  public setSimulationSpeed(speed: number) {
    this.state = { ...this.state, simulationSpeed: speed };
    this.notify();
  }

  public setSimulating(isSimulating: boolean) {
    this.state = { ...this.state, isSimulating };
    this.notify();
  }

  public selectCorner(cornerId: string | null) {
    this.state = { ...this.state, selectedCornerId: cornerId };
    this.notify();
  }

  public setElevationExaggeration(exaggeration: number) {
    const updatedGeometry = calculatePythonTrackGeometry(
      this.state.geometry.corners,
      this.state.geometry.defaultWidth,
      exaggeration
    );
    this.updateGeometry(updatedGeometry);
  }

  // Update a single corner parameter smoothly
  public updateCorner(cornerId: string, updates: Partial<Corner>) {
    const updatedCorners = this.state.geometry.corners.map((c) => {
      if (c.id === cornerId) {
        return { ...c, ...updates };
      }
      return c;
    });

    const newGeometry = calculatePythonTrackGeometry(
      updatedCorners,
      this.state.geometry.defaultWidth,
      this.state.geometry.elevationExaggeration
    );

    this.updateGeometry(newGeometry);
  }

  // Set time scrubber (0..1 along lap)
  public setTimeScrubber(progress: number) {
    const totalDist = this.state.geometry.length || 5000;
    const targetDist = progress * totalDist;

    const vehicles = this.state.vehicles.map((v, i) => {
      if (i === 0) {
        return { ...v, distance: targetDist };
      }
      return v;
    });

    const lapTimeSec = this.state.analytics.lapTime || 107.32;
    this.state = {
      ...this.state,
      timeScrubber: progress,
      vehicles,
      telemetry: {
        ...this.state.telemetry,
        currentDistance: targetDist,
        currentLapTime: progress * lapTimeSec
      }
    };
    this.notify();
  }

  // Morph to a candidate design smoothly over time
  public morphToCandidate(candidateId: string) {
    const candidate = this.state.candidateDesigns.find((c) => c.id === candidateId);
    if (!candidate) return;

    this.state = {
      ...this.state,
      activeCandidateId: candidateId
    };
    this.updateGeometry(candidate.trackGeometry);
  }

  // Update geometry & re-run Python + R pipeline
  public updateGeometry(newGeometry: TrackGeometry) {
    const terrain = generateTerrainDEM(newGeometry);
    const analytics = calculateRAnalytics(newGeometry, this.state.scenario, this.state.analytics.scoreWeights);
    const construction = calculateRConstructionState(newGeometry, this.state.construction.phase, this.state.construction.progress);
    const warnings = this.evaluateConstraintWarnings(newGeometry);

    // Push to undo history stack
    const newHistory = this.state.history.slice(0, this.state.historyIndex + 1);
    newHistory.push(newGeometry);

    this.state = {
      ...this.state,
      geometry: newGeometry,
      terrain,
      analytics,
      construction,
      warnings,
      history: newHistory,
      historyIndex: newHistory.length - 1,
      telemetry: {
        ...this.state.telemetry,
        bestLapTime: analytics.lapTime,
        graphData: newGeometry.points.map((p) => ({
          distance: p.distance,
          speed: p.speed,
          brake: p.brakingIntensity,
          throttle: p.brakingIntensity > 0.1 ? 0 : 1.0,
          lateralG: p.lateralG,
          longitudinalG: p.longitudinalG
        }))
      }
    };
    this.notify();
  }

  public undo() {
    if (this.state.historyIndex > 0) {
      const idx = this.state.historyIndex - 1;
      const geom = this.state.history[idx];
      const terrain = generateTerrainDEM(geom);
      const analytics = calculateRAnalytics(geom, this.state.scenario);
      this.state = {
        ...this.state,
        geometry: geom,
        terrain,
        analytics,
        historyIndex: idx
      };
      this.notify();
    }
  }

  public redo() {
    if (this.state.historyIndex < this.state.history.length - 1) {
      const idx = this.state.historyIndex + 1;
      const geom = this.state.history[idx];
      const terrain = generateTerrainDEM(geom);
      const analytics = calculateRAnalytics(geom, this.state.scenario);
      this.state = {
        ...this.state,
        geometry: geom,
        terrain,
        analytics,
        historyIndex: idx
      };
      this.notify();
    }
  }

  public updateScoreWeights(newWeights: Partial<AnalyticsState['scoreWeights']>) {
    const merged = { ...this.state.analytics.scoreWeights, ...newWeights };
    const analytics = calculateRAnalytics(this.state.geometry, this.state.scenario, merged);
    this.state = { ...this.state, analytics };
    this.notify();
  }

  public setConstructionPhase(phase: ConstructionPhase) {
    const phases: ConstructionPhase[] = [
      'SITE', 'EARTHWORK', 'DRAINAGE', 'SUBBASE', 'PAVEMENT', 'KERBS', 'RUNOFF', 'BARRIERS', 'PIT_COMPLEX', 'FINISHED'
    ];
    const idx = phases.indexOf(phase);
    const progress = Math.round(((idx + 1) / phases.length) * 100);
    const construction = calculateRConstructionState(this.state.geometry, phase, progress);

    this.state = { ...this.state, construction };
    this.notify();
  }

  private evaluateConstraintWarnings(geometry: TrackGeometry): string[] {
    const warnings: string[] = [];

    geometry.corners.forEach((c) => {
      if (c.radius < 30) {
        warnings.push(`⚠ Turn ${c.number}: Extremely tight radius (${c.radius}m) - high tire degradation hazard.`);
      }
      if (Math.abs(c.banking) > 9) {
        warnings.push(`⚠ Turn ${c.number}: Steep banking (${c.banking}°) - check FIA drainage & structural slope rules.`);
      }
      if (c.elevation > 25) {
        warnings.push(`⚠ Turn ${c.number}: Excessive hill elevation (${c.elevation}m) - earthworks cost penalty.`);
      }
    });

    if (geometry.length < 3500) {
      warnings.push('⚠ Track Length below 3.5km - Grade 1 Grand Prix minimum is 3.5km.');
    }

    return warnings;
  }

  // Main simulation loop running independent from render FPS
  public startSimulation() {
    if (typeof window === 'undefined') return;

    this.lastTimestamp = performance.now();

    const tick = (now: number) => {
      const deltaSec = (now - this.lastTimestamp) / 1000;
      this.lastTimestamp = now;

      if (this.state.isSimulating && deltaSec > 0) {
        const simTimeDelta = deltaSec * this.state.simulationSpeed;
        const totalDist = this.state.geometry.length || 5000;

        // Advance vehicles along track distance parameter 's'
        const updatedVehicles = this.state.vehicles.map((v, i) => {
          const ptIdx = Math.floor((v.distance / totalDist) * this.state.geometry.points.length) % this.state.geometry.points.length;
          const trackPt = this.state.geometry.points[ptIdx] || this.state.geometry.points[0];

          const currentSpeedMps = (trackPt.speed * (1 - i * 0.04)) / 3.6;
          let newDist = v.distance + currentSpeedMps * simTimeDelta;
          let newLap = v.lap;

          if (newDist >= totalDist) {
            newDist = newDist % totalDist;
            newLap += 1;
          }

          const sector = newDist < totalDist * 0.33 ? 1 : newDist < totalDist * 0.68 ? 2 : 3;

          return {
            ...v,
            distance: newDist,
            lap: newLap,
            sector,
            speed: Math.round(trackPt.speed),
            throttle: trackPt.brakingIntensity > 0.1 ? 0 : 0.95,
            brake: Number(trackPt.brakingIntensity.toFixed(2)),
            gear: Math.min(8, Math.max(1, Math.floor(trackPt.speed / 40) + 1)),
            rpm: Math.round(4500 + (trackPt.speed % 40) * 120),
            lateralG: Number((trackPt.lateralG * (1 + Math.sin(now * 0.003) * 0.05)).toFixed(2)),
            longitudinalG: Number(trackPt.longitudinalG.toFixed(2)),
            combinedG: Number(Math.sqrt(trackPt.lateralG ** 2 + trackPt.longitudinalG ** 2).toFixed(2)),
            roll: trackPt.banking * 0.6,
            pitch: trackPt.longitudinalG * 1.5,
            position: trackPt.racingLinePoint,
            rotation: Math.atan2(trackPt.tangent.x, trackPt.tangent.z)
          };
        });

        // Sync lead car to time scrubber & telemetry
        const leadVehicle = updatedVehicles[0];
        const progress = leadVehicle.distance / totalDist;
        const lapTimeSec = this.state.analytics.lapTime || 107.32;

        this.state = {
          ...this.state,
          vehicles: updatedVehicles,
          timeScrubber: progress,
          telemetry: {
            ...this.state.telemetry,
            currentDistance: leadVehicle.distance,
            currentLapTime: progress * lapTimeSec
          }
        };

        this.notify();
      }

      this.animFrameId = requestAnimationFrame(tick);
    };

    this.animFrameId = requestAnimationFrame(tick);
  }

  public stopSimulation() {
    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
  }
}

// Global Singleton Instance
export const digitalTwinStore = new DigitalTwinStore();
