// CIRCUITFORGE.OS - Authoritative Python Simulation Engine Interface
import {
  TrackGeometry,
  TrackPoint,
  Corner,
  Sector,
  TerrainState,
  Vector3D,
  VehicleState
} from './types';

// Generates baseline initial corners for a world-class grand prix circuit layout
export function generateInitialCorners(): Corner[] {
  return [
    {
      id: 'corner-1',
      number: 1,
      name: 'Turn 1 (Castrol Hairpin)',
      radius: 35,
      angle: 120,
      banking: 4,
      camber: -1.5,
      elevation: 2,
      positionIndex: 0.12,
      entrySpeed: 285,
      apexSpeed: 82,
      exitSpeed: 145,
      minRadius: 20,
      controlPoint: { x: 180, y: 5, z: 120 },
      type: 'hairpin'
    },
    {
      id: 'corner-2',
      number: 2,
      name: 'Turn 2 (Apex Chicane L)',
      radius: 65,
      angle: 45,
      banking: 2,
      camber: 0,
      elevation: 6,
      positionIndex: 0.22,
      entrySpeed: 190,
      apexSpeed: 130,
      exitSpeed: 175,
      minRadius: 30,
      controlPoint: { x: 260, y: 12, z: 220 },
      type: 'chicane'
    },
    {
      id: 'corner-3',
      number: 3,
      name: 'Turn 3 (Apex Chicane R)',
      radius: 58,
      angle: -50,
      banking: 1,
      camber: 1,
      elevation: 9,
      positionIndex: 0.28,
      entrySpeed: 175,
      apexSpeed: 122,
      exitSpeed: 195,
      minRadius: 30,
      controlPoint: { x: 220, y: 16, z: 310 },
      type: 'chicane'
    },
    {
      id: 'corner-4',
      number: 4,
      name: 'Turn 4 (Velocity Sweeper)',
      radius: 120,
      angle: 85,
      banking: 6,
      camber: 2,
      elevation: 15,
      positionIndex: 0.40,
      entrySpeed: 260,
      apexSpeed: 198,
      exitSpeed: 235,
      minRadius: 50,
      controlPoint: { x: 80, y: 22, z: 420 },
      type: 'sweeper'
    },
    {
      id: 'corner-5',
      number: 5,
      name: 'Turn 5 (High-G Compression)',
      radius: 80,
      angle: 60,
      banking: 8,
      camber: 0,
      elevation: 4,
      positionIndex: 0.52,
      entrySpeed: 240,
      apexSpeed: 155,
      exitSpeed: 210,
      minRadius: 40,
      controlPoint: { x: -120, y: 8, z: 350 },
      type: 'fast'
    },
    {
      id: 'corner-6',
      number: 6,
      name: 'Turn 6 (Hilltop Crest)',
      radius: 95,
      angle: -70,
      banking: -2,
      camber: -2,
      elevation: 28,
      positionIndex: 0.65,
      entrySpeed: 225,
      apexSpeed: 168,
      exitSpeed: 205,
      minRadius: 45,
      controlPoint: { x: -240, y: 32, z: 220 },
      type: 'medium'
    },
    {
      id: 'corner-7',
      number: 7,
      name: 'Turn 7 (Banked Carousel)',
      radius: 42,
      angle: 140,
      banking: 10,
      camber: 3,
      elevation: 18,
      positionIndex: 0.78,
      entrySpeed: 184,
      apexSpeed: 91,
      exitSpeed: 152,
      minRadius: 25,
      controlPoint: { x: -210, y: 22, z: 40 },
      type: 'hairpin'
    },
    {
      id: 'corner-8',
      number: 8,
      name: 'Turn 8 (Pit Straight Entry)',
      radius: 110,
      angle: -60,
      banking: 3,
      camber: 0,
      elevation: 5,
      positionIndex: 0.90,
      entrySpeed: 215,
      apexSpeed: 180,
      exitSpeed: 270,
      minRadius: 50,
      controlPoint: { x: -80, y: 8, z: -40 },
      type: 'fast'
    }
  ];
}

// Compute procedural points along a closed loop Grand Prix circuit using control points
export function calculatePythonTrackGeometry(
  cornersInput: Corner[],
  defaultWidth: number = 14,
  elevationExaggeration: number = 1.0,
  totalPointsCount: number = 200
): TrackGeometry {
  const corners = cornersInput.map((c) => ({ ...c }));
  
  // Base loop anchor control points
  const anchorPoints: { x: number; y: number; z: number; banking: number; camber: number; corner?: Corner }[] = [
    { x: 0, y: 0, z: 0, banking: 0, camber: 0 }, // Start / Finish straight
    ...corners.map((c) => ({
      x: c.controlPoint.x,
      y: c.controlPoint.y,
      z: c.controlPoint.z,
      banking: c.banking,
      camber: c.camber,
      corner: c
    })),
    { x: -20, y: 0, z: 40, banking: 1, camber: 0 } // Re-entry to main straight
  ];

  const n = anchorPoints.length;
  const rawPoints: Vector3D[] = [];
  const bankingProfile: number[] = [];
  const camberProfile: number[] = [];

  // Catmull-Rom spline interpolation for continuous smooth centerline
  for (let i = 0; i < totalPointsCount; i++) {
    const tGlobal = (i / totalPointsCount) * n;
    const seg = Math.floor(tGlobal);
    const u = tGlobal - seg;

    const p0 = anchorPoints[(seg - 1 + n) % n];
    const p1 = anchorPoints[seg % n];
    const p2 = anchorPoints[(seg + 1) % n];
    const p3 = anchorPoints[(seg + 2) % n];

    // Catmull-Rom formula
    const x = 0.5 * (
      (2 * p1.x) +
      (-p0.x + p2.x) * u +
      (2 * p0.x - 5 * p1.x + 4 * p2.x - p3.x) * u * u +
      (-p0.x + 3 * p1.x - 3 * p2.x + p3.x) * u * u * u
    );

    const y = 0.5 * (
      (2 * p1.y) +
      (-p0.y + p2.y) * u +
      (2 * p0.y - 5 * p1.y + 4 * p2.y - p3.y) * u * u +
      (-p0.y + 3 * p1.y - 3 * p2.y + p3.y) * u * u * u
    );

    const z = 0.5 * (
      (2 * p1.z) +
      (-p0.z + p2.z) * u +
      (2 * p0.z - 5 * p1.z + 4 * p2.z - p3.z) * u * u +
      (-p0.z + 3 * p1.z - 3 * p2.z + p3.z) * u * u * u
    );

    const banking = p1.banking + u * (p2.banking - p1.banking);
    const camber = p1.camber + u * (p2.camber - p1.camber);

    rawPoints.push({ x, y, z });
    bankingProfile.push(banking);
    camberProfile.push(camber);
  }

  // Calculate cumulative distance and tangents
  let cumulativeDistance = 0;
  const distances: number[] = [0];
  for (let i = 1; i < rawPoints.length; i++) {
    const dx = rawPoints[i].x - rawPoints[i - 1].x;
    const dy = rawPoints[i].y - rawPoints[i - 1].y;
    const dz = rawPoints[i].z - rawPoints[i - 1].z;
    cumulativeDistance += Math.sqrt(dx * dx + dy * dy + dz * dz);
    distances.push(cumulativeDistance);
  }

  const trackLength = cumulativeDistance;

  // Build TrackPoints with left/right edges, banking, speed profile
  const trackPoints: TrackPoint[] = [];

  for (let i = 0; i < totalPointsCount; i++) {
    const pCurr = rawPoints[i];
    const pNext = rawPoints[(i + 1) % totalPointsCount];
    const pPrev = rawPoints[(i - 1 + totalPointsCount) % totalPointsCount];

    // Tangent vector
    const tx = pNext.x - pPrev.x;
    const ty = pNext.y - pPrev.y;
    const tz = pNext.z - pPrev.z;
    const tLen = Math.sqrt(tx * tx + ty * ty + tz * tz) || 1;
    const tangent: Vector3D = { x: tx / tLen, y: ty / tLen, z: tz / tLen };

    // Normal vector perpendicular to tangent on XZ plane
    const nx = -tangent.z;
    const nz = tangent.x;
    const nLen = Math.sqrt(nx * nx + nz * nz) || 1;
    const normal: Vector3D = { x: nx / nLen, y: 0, z: nz / nLen };

    // Apply elevation exaggeration for visualization
    const effectiveY = pCurr.y * elevationExaggeration;

    // Banking tilt angle
    const bankRad = (bankingProfile[i] * Math.PI) / 180;
    const halfWidth = defaultWidth / 2;

    const leftEdge: Vector3D = {
      x: pCurr.x - normal.x * halfWidth,
      y: effectiveY + Math.sin(bankRad) * halfWidth,
      x2: pCurr.x - normal.x * halfWidth,
      z: pCurr.z - normal.z * halfWidth
    } as any;

    const rightEdge: Vector3D = {
      x: pCurr.x + normal.x * halfWidth,
      y: effectiveY - Math.sin(bankRad) * halfWidth,
      z: pCurr.z + normal.z * halfWidth
    };

    // Curvature estimation (2nd derivative magnitude)
    const d1x = (pNext.x - pPrev.x) / 2;
    const d1z = (pNext.z - pPrev.z) / 2;
    const d2x = pNext.x - 2 * pCurr.x + pPrev.x;
    const d2z = pNext.z - 2 * pCurr.z + pPrev.z;
    const curvature = Math.abs(d1x * d2z - d1z * d2x) / Math.pow(d1x * d1x + d1z * d1z, 1.5) || 0.001;

    // Racing line offset based on curvature & corner apex optimization
    const rlineOffset = Math.sin((i / totalPointsCount) * Math.PI * 6) * (halfWidth * 0.65);
    const racingLinePoint: Vector3D = {
      x: pCurr.x + normal.x * rlineOffset,
      y: effectiveY + Math.sin(bankRad) * rlineOffset,
      z: pCurr.z + normal.z * rlineOffset
    };

    // Calculate physical vehicle speed at this point from curvature & friction limit
    // V = sqrt(mu * g * R)
    const mu = 1.4; // tire grip coefficient
    const gravity = 9.81;
    const radiusMeters = 1 / Math.max(curvature, 0.0005);
    const maxCorneringSpeedMps = Math.sqrt(mu * gravity * radiusMeters * (1 + Math.sin(bankRad)));
    const maxCorneringKmH = Math.min(320, maxCorneringSpeedMps * 3.6);

    // Speed profile smoothing
    const speed = Math.max(70, Math.min(315, maxCorneringKmH));

    // Braking intensity (higher where speed drops sharply)
    const brakingIntensity = curvature > 0.012 ? Math.min(1.0, curvature * 50) : 0;

    const lateralG = (speed / 3.6) ** 2 / (radiusMeters * gravity);
    const longitudinalG = (i % 20 < 5) ? -1.8 * brakingIntensity : 0.85;

    const gradient = (ty / tLen) * 100; // % grade

    const costZone = curvature > 0.015 ? 'HIGH' : Math.abs(effectiveY) > 15 ? 'MEDIUM' : 'LOW';
    const earthworksDepth = effectiveY > 10 ? -2.5 : effectiveY < -5 ? 3.0 : 0.5;
    const earthworksType = earthworksDepth < 0 ? 'CUT' : earthworksDepth > 1 ? 'FILL' : 'BALANCED';

    trackPoints.push({
      distance: distances[i],
      center: { x: pCurr.x, y: effectiveY, z: pCurr.z },
      leftEdge,
      rightEdge,
      racingLinePoint,
      tangent,
      normal,
      elevation: pCurr.y,
      banking: bankingProfile[i],
      camber: camberProfile[i],
      width: defaultWidth,
      speed,
      brakingIntensity,
      curvature,
      gradient,
      lateralG: Math.min(4.8, lateralG),
      longitudinalG,
      costZone,
      earthworksType,
      earthworksDepth
    });
  }

  // Update corner speed metrics and positions
  corners.forEach((c) => {
    const ptIdx = Math.floor(c.positionIndex * totalPointsCount) % totalPointsCount;
    const pt = trackPoints[ptIdx];
    if (pt) {
      c.apexSpeed = Math.round(pt.speed);
      c.entrySpeed = Math.round(Math.min(310, pt.speed * 1.35));
      c.exitSpeed = Math.round(Math.min(310, pt.speed * 1.25));
    }
  });

  // Default Grand Prix Sectors
  const sectors: Sector[] = [
    {
      id: 1,
      name: 'Sector 1 (S1)',
      startDistance: 0,
      endDistance: trackLength * 0.33,
      bestTime: 34.12,
      currentTime: 34.28,
      delta: 0.16
    },
    {
      id: 2,
      name: 'Sector 2 (S2)',
      startDistance: trackLength * 0.33,
      endDistance: trackLength * 0.68,
      bestTime: 41.85,
      currentTime: 41.72,
      delta: -0.13
    },
    {
      id: 3,
      name: 'Sector 3 (S3)',
      startDistance: trackLength * 0.68,
      endDistance: trackLength,
      bestTime: 31.35,
      currentTime: 31.32,
      delta: -0.03
    }
  ];

  return {
    id: 'gp-circuit-01',
    name: 'CircuitForge Grand Prix Circuit',
    length: Math.round(trackLength),
    defaultWidth,
    elevationExaggeration,
    corners,
    sectors,
    points: trackPoints
  };
}

// Generate terrain DEM mesh around track points
export function generateTerrainDEM(track: TrackGeometry): TerrainState {
  const gridSize = 50;
  const span = 1000;
  const halfSpan = span / 2;
  const demData: number[][] = [];

  for (let r = 0; r < gridSize; r++) {
    const row: number[] = [];
    const z = -halfSpan + (r / (gridSize - 1)) * span;

    for (let c = 0; c < gridSize; c++) {
      const x = -halfSpan + (c / (gridSize - 1)) * span;

      // Natural rolling hills elevation function
      let baseHeight =
        Math.sin(x * 0.005) * 12 +
        Math.cos(z * 0.006) * 15 +
        Math.sin((x + z) * 0.008) * 8;

      // Flatten terrain near track points for cut/fill integration
      let minDistanceToTrack = 9999;
      let nearestTrackHeight = 0;

      for (let p = 0; p < track.points.length; p += 5) {
        const pt = track.points[p];
        const dx = x - pt.center.x;
        const dz = z - pt.center.z;
        const dist = Math.sqrt(dx * dx + dz * dz);
        if (dist < minDistanceToTrack) {
          minDistanceToTrack = dist;
          nearestTrackHeight = pt.elevation;
        }
      }

      if (minDistanceToTrack < 80) {
        const blendFactor = Math.pow(minDistanceToTrack / 80, 2);
        baseHeight = nearestTrackHeight * (1 - blendFactor) + baseHeight * blendFactor;
      }

      row.push(baseHeight);
    }
    demData.push(row);
  }

  return {
    gridSize,
    width: span,
    length: span,
    demData,
    contoursEnabled: true
  };
}

// Create initial multi-vehicle simulation list
export function createInitialVehicles(count: number = 3, track: TrackGeometry): VehicleState[] {
  const vehicles: VehicleState[] = [];
  const colors = ['#ef4444', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#06b6d4'];
  const names = ['Apex Pro GT-1', 'Telemetry Spec-R', 'Veloce Hyper-3', 'AeroWorks F-1', 'EvoMotors Sport'];

  for (let i = 0; i < count; i++) {
    const startDist = (i * 45) % (track.length || 5000);
    const color = colors[i % colors.length];
    const name = `${names[i % names.length]} #${i + 1}`;

    vehicles.push({
      id: `vehicle-${i + 1}`,
      name,
      number: i + 1,
      driverModel: i === 0 ? 'PRO (AI-Optimized)' : i === 1 ? 'SEMIPRO (Aero Spec)' : 'AMATEUR (Conservative)',
      color,
      distance: startDist,
      lap: 1,
      sector: 1,
      speed: 180,
      throttle: 0.85,
      brake: 0,
      gear: 5,
      rpm: 7200,
      lateralG: 1.2,
      longitudinalG: 0.4,
      combinedG: 1.26,
      roll: 0,
      pitch: 0,
      position: { x: 0, y: 0, z: 0 },
      rotation: 0
    });
  }

  return vehicles;
}
