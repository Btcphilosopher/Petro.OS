package circuitforge.network

import circuitforge.model.TrackGeometry
import circuitforge.model.Vehicle
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class DigitalTwinState(
    val geometry: TrackGeometry? = null,
    val vehicles: List<Vehicle> = emptyList(),
    val isConnected: Boolean = true
)

class DigitalTwinStream {
    private val _state = MutableStateFlow(DigitalTwinState())
    val state: StateFlow<DigitalTwinState> = _state.asStateFlow()

    suspend fun connectWebSocket(url: String) {
        // Ktor WebSocket client subscription to /ws/track and /ws/simulation
    }
}
