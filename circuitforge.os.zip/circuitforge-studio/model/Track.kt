package circuitforge.model

import kotlinx.serialization.Serializable

@Serializable
data class Vector3D(
    val x: Float,
    val y: Float,
    val z: Float
)

@Serializable
data class Corner(
    val id: String,
    val number: Int,
    val name: String,
    val radius: Float,
    val angle: Float,
    val banking: Float,
    val camber: Float,
    val elevation: Float,
    val positionIndex: Float,
    val entrySpeed: Float,
    val apexSpeed: Float,
    val exitSpeed: Float,
    val minRadius: Float,
    val controlPoint: Vector3D,
    val type: String
)

@Serializable
data class Sector(
    val id: Int,
    val name: String,
    val startDistance: Float,
    val endDistance: Float,
    val bestTime: Float,
    val currentTime: Float,
    val delta: Float
)

@Serializable
data class TrackPoint(
    val distance: Float,
    val center: Vector3D,
    val leftEdge: Vector3D,
    val rightEdge: Vector3D,
    val racingLinePoint: Vector3D,
    val tangent: Vector3D,
    val normal: Vector3D,
    val elevation: Float,
    val banking: Float,
    val camber: Float,
    val width: Float,
    val speed: Float,
    val brakingIntensity: Float,
    val curvature: Float,
    val gradient: Float,
    val lateralG: Float,
    val longitudinalG: Float
)

@Serializable
data class TrackGeometry(
    val id: String,
    val name: String,
    val length: Float,
    val defaultWidth: Float,
    val elevationExaggeration: Float,
    val corners: List<Corner>,
    val sectors: List<Sector>,
    val points: List<TrackPoint>
)
