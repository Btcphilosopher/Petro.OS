package circuitforge.model

import kotlinx.serialization.Serializable

@Serializable
enum class ConstructionPhase {
    SITE, EARTHWORK, DRAINAGE, SUBBASE, PAVEMENT, KERBS, RUNOFF, BARRIERS, PIT_COMPLEX, FINISHED
}

@Serializable
data class Construction(
    val phase: ConstructionPhase,
    val progress: Float,
    val cutVolume: Double,
    val fillVolume: Double,
    val haulDistance: Float,
    val pavementArea: Double,
    val drainageLength: Float,
    val totalCost: Double,
    val constructionDays: Int
)
