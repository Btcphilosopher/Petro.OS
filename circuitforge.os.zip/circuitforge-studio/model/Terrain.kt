package circuitforge.model

import kotlinx.serialization.Serializable

@Serializable
data class Terrain(
    val gridSize: Int,
    val width: Float,
    val length: Float,
    val demData: List<List<Float>>,
    val contoursEnabled: Boolean
)
