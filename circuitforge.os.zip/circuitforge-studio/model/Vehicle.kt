package circuitforge.model

import kotlinx.serialization.Serializable

@Serializable
data class Vehicle(
    val id: String,
    val name: String,
    val number: Int,
    val driverModel: String,
    val color: String,
    val distance: Float,
    val lap: Int,
    val sector: Int,
    val speed: Float,
    val throttle: Float,
    val brake: Float,
    val gear: Int,
    val rpm: Int,
    val lateralG: Float,
    val longitudinalG: Float,
    val combinedG: Float,
    val roll: Float,
    val pitch: Float,
    val position: Vector3D,
    val rotation: Float
)
