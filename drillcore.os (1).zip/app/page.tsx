'use client';

import React, { useState, useEffect, useRef } from 'react';
import { Header } from '../components/Header';
import { LiveDigitalTwinView } from '../components/LiveDigitalTwinView';
import { PhysicsSuiteView } from '../components/PhysicsSuiteView';
import { RQuantIntelligenceView } from '../components/RQuantIntelligenceView';
import { ScenarioLabView } from '../components/ScenarioLabView';
import { DigitalTwinReplayView } from '../components/DigitalTwinReplayView';
import { DrillingAdvisorView } from '../components/DrillingAdvisorView';
import { CliTerminalView } from '../components/CliTerminalView';
import { EngineeringReportView } from '../components/EngineeringReportView';
import { DigitalTwinState, DrillingTwinEngine } from '../lib/twin/drillingTwin';
import { UnitSystem } from '../lib/physics/units';
import { ScenarioEvaluation } from '../lib/twin/advisorAndScenarios';
import { DrillingRecommendation } from '../lib/twin/advisorAndScenarios';

export default function Home() {
  const [twin, setTwin] = useState<DigitalTwinState>(() => DrillingTwinEngine.createInitialTwin());
  const [unitSystem, setUnitSystem] = useState<UnitSystem>('SI');
  const [activeTab, setActiveTab] = useState<string>('live-twin');

  // Simulation timer loop
  useEffect(() => {
    if (!twin.isSimulating) return;

    const interval = setInterval(() => {
      setTwin(prev => {
        if (!prev.isSimulating) return prev;
        return DrillingTwinEngine.stepSimulation(prev, 1.0);
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [twin.isSimulating]);

  // Toggle play/pause
  const handleTogglePlay = () => {
    setTwin(prev => ({
      ...prev,
      isSimulating: !prev.isSimulating,
    }));
  };

  // Step simulation forward once
  const handleStep = () => {
    setTwin(prev => DrillingTwinEngine.stepSimulation(prev, 2.0));
  };

  // Reset to initial baseline state
  const handleReset = () => {
    setTwin(DrillingTwinEngine.createInitialTwin());
  };

  // Change simulation speed
  const handleSpeedChange = (speed: number) => {
    setTwin(prev => ({
      ...prev,
      simulationSpeed: speed,
    }));
  };

  // Driller direct control adjustments
  const handleControlChange = (key: 'wob' | 'rpm' | 'flow' | 'mudDensity', val: number) => {
    setTwin(prev => {
      const newWob = key === 'wob' ? val : prev.controlWobKn;
      const newRpm = key === 'rpm' ? val : prev.controlRpm;
      const newFlow = key === 'flow' ? val : prev.controlFlowRateLs;
      const newMudDensity = key === 'mudDensity' ? val : prev.mudDensityKgM3;

      const modifiedState: DigitalTwinState = {
        ...prev,
        controlWobKn: newWob,
        controlRpm: newRpm,
        controlFlowRateLs: newFlow,
        mudDensityKgM3: newMudDensity,
      };

      // Recalculate physics step with 0 delta time to update instant outputs
      return DrillingTwinEngine.stepSimulation(modifiedState, 0.0);
    });
  };

  // Apply Bayesian Pareto Optimal Setpoints
  const handleApplyOptimal = () => {
    const opt = twin.optimizationResult.recommendedOptimalPoint;
    setTwin(prev => {
      const modifiedState: DigitalTwinState = {
        ...prev,
        controlWobKn: opt.wobKn,
        controlRpm: opt.rpm,
        controlFlowRateLs: opt.flowRateLs,
      };
      return DrillingTwinEngine.stepSimulation(modifiedState, 0.0);
    });
  };

  // Apply a Scenario Lab scenario
  const handleApplyScenario = (scenario: ScenarioEvaluation) => {
    setTwin(prev => {
      const modifiedState: DigitalTwinState = {
        ...prev,
        controlWobKn: scenario.parameters.wobKn,
        controlRpm: scenario.parameters.rpm,
        controlFlowRateLs: scenario.parameters.flowRateLs,
      };
      return DrillingTwinEngine.stepSimulation(modifiedState, 0.0);
    });
    setActiveTab('live-twin');
  };

  // Apply an Advisor Recommendation
  const handleApplyRecommendation = (rec: DrillingRecommendation) => {
    setTwin(prev => {
      const modifiedState: DigitalTwinState = {
        ...prev,
        controlWobKn: rec.suggestedSetpoints.wobKn,
        controlRpm: rec.suggestedSetpoints.rpm,
        controlFlowRateLs: rec.suggestedSetpoints.flowRateLs,
      };
      return DrillingTwinEngine.stepSimulation(modifiedState, 0.0);
    });
    setActiveTab('live-twin');
  };

  return (
    <div className="min-h-screen bg-[#050505] text-[#e0e0e0] flex flex-col font-sans selection:bg-[#00ff41]/20 selection:text-[#00ff41]">
      {/* Platform Header & Navigation Bar */}
      <Header
        twin={twin}
        unitSystem={unitSystem}
        setUnitSystem={setUnitSystem}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onTogglePlay={handleTogglePlay}
        onStep={handleStep}
        onReset={handleReset}
        onSpeedChange={handleSpeedChange}
      />

      {/* Main Content Workspace Area */}
      <main className="flex-1 p-4 lg:p-6 max-w-7xl w-full mx-auto">
        {activeTab === 'live-twin' && (
          <LiveDigitalTwinView
            twin={twin}
            unitSystem={unitSystem}
            onControlChange={handleControlChange}
            onApplyOptimal={handleApplyOptimal}
          />
        )}

        {activeTab === 'physics-suite' && (
          <PhysicsSuiteView twin={twin} unitSystem={unitSystem} />
        )}

        {activeTab === 'r-quant-ml' && (
          <RQuantIntelligenceView twin={twin} unitSystem={unitSystem} />
        )}

        {activeTab === 'scenario-lab' && (
          <ScenarioLabView
            twin={twin}
            unitSystem={unitSystem}
            onApplyScenario={handleApplyScenario}
          />
        )}

        {activeTab === 'twin-replay' && (
          <DigitalTwinReplayView twin={twin} unitSystem={unitSystem} />
        )}

        {activeTab === 'drilling-advisor' && (
          <DrillingAdvisorView
            twin={twin}
            unitSystem={unitSystem}
            onApplyRecommendation={handleApplyRecommendation}
          />
        )}

        {activeTab === 'cli-terminal' && (
          <CliTerminalView twin={twin} />
        )}

        {activeTab === 'engineering-report' && (
          <EngineeringReportView twin={twin} unitSystem={unitSystem} />
        )}
      </main>

      {/* Immersive UI Persistent Footer */}
      <footer className="h-10 bg-[#0a0a0a] border-t border-[#222] flex items-center px-6 justify-between text-[9px] font-mono text-[#666] select-none sticky bottom-0 z-40">
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00ff41] shadow-[0_0_6px_#00ff41]"></span>
            <span>CORE: RUNNING</span>
          </div>
          <span>CPU: 12%</span>
          <span>MEM: 4.2GB</span>
          <span>IO: 420 MB/S</span>
          <span className="hidden sm:inline">DISCRETE STEP: Δt=0.10s</span>
          <span className="hidden md:inline">UPTIME: 142:24:11</span>
        </div>
        <div className="flex items-center space-x-3">
          <span className="text-white bg-blue-900/50 border border-blue-700/40 px-2 py-0.5 rounded text-[8px] font-bold">
            RUST ENGINE: DETERMINISTIC
          </span>
          <span className="text-white bg-purple-900/50 border border-purple-700/40 px-2 py-0.5 rounded text-[8px] font-bold">
            R STATS: SYNCED
          </span>
          <span className="hidden sm:inline text-[#00ff41] bg-[#111] border border-[#333] px-2 py-0.5 rounded text-[8px] font-bold">
            P10/P50/P90: CONVERGED
          </span>
        </div>
      </footer>
    </div>
  );
}
