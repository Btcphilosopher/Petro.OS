import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'DRILLCORE.OS | Computational Drilling Engineering & Digital Twin',
  description: 'Hard-engineering drilling digital twin, physics simulation, quantitative R analytics, and ML optimisation platform.',
  openGraph: {
    title: 'DRILLCORE.OS | Computational Drilling Engineering & Digital Twin',
    description: 'Hard-engineering drilling digital twin, physics simulation, quantitative R analytics, and ML optimisation platform.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'DRILLCORE.OS | Computational Drilling Engineering & Digital Twin',
    description: 'Hard-engineering drilling digital twin, physics simulation, quantitative R analytics, and ML optimisation platform.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
