'use client';

import React, { useState } from 'react';
import { 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  Zap, 
  ArrowRight, 
  Cpu, 
  Sliders, 
  Activity, 
  Lock, 
  Check,
  XCircle,
  HelpCircle
} from 'lucide-react';
import { DigitalTwinState } from '../lib/twin/drillingTwin';
import { UnitSystem } from '../lib/physics/units';
import { 
  AdvisorAndScenarioEngine, 
  DrillingRecommendation, 
  AutomationLevel 
} from '../lib/twin/advisorAndScenarios';

interface DrillingAdvisorViewProps {
  twin: DigitalTwinState;
  unitSystem: UnitSystem;
  onApplyRecommendation: (rec: DrillingRecommendation) => void;
}

export const DrillingAdvisorView: React.FC<DrillingAdvisorViewProps> = ({
  twin,
  unitSystem,
  onApplyRecommendation,
}) => {
  const [autonomyLevel, setAutonomyLevel] = useState<AutomationLevel>('LEVEL_2_RECOMMEND');
  const recommendations = AdvisorAndScenarioEngine.generateAdvisorRecommendations(twin);

  const autonomyLevels: { id: AutomationLevel; name: string; desc: string; badge: string }[] = [
    {
      id: 'LEVEL_0_OBSERVE',
      name: 'Level 0: Human Manual',
      desc: 'Raw telemetry display only. No recommendations or automated setpoint computations.',
      badge: 'MANUAL',
    },
    {
      id: 'LEVEL_1_ANALYSE',
      name: 'Level 1: Diagnostic Analysis',
      desc: 'Physics & ML anomaly detection flags hazards and equipment limits.',
      badge: 'ASSIST',
    },
    {
      id: 'LEVEL_2_RECOMMEND',
      name: 'Level 2: Advisory Recommendations',
      desc: 'Calculates Pareto-optimal parameter setpoints for driller review and confirmation.',
      badge: 'ADVISORY',
    },
    {
      id: 'LEVEL_3_PREPARE_SETPOINTS',
      name: 'Level 3: Setpoint Preparation',
      desc: 'Stages setpoints directly to Top Drive and Mud Pump control buffers for single-click execution.',
      badge: 'STAGED',
    },
    {
      id: 'LEVEL_4_EXECUTE_WITHIN_CONSTRAINTS',
      name: 'Level 4: Closed-Loop Execution',
      desc: 'Auto-executes within hard-coded mechanical safety envelopes with independent trip triggers.',
      badge: 'AUTONOMOUS',
    },
  ];

  return (
    <div className="space-y-4 font-sans text-[#e0e0e0]">
      {/* Automation Control Boundary Selector */}
      <div className="bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none bg-grid-dots"></div>
        <div className="flex items-center justify-between border-b border-[#222] pb-2 relative z-10">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#00ff41]" />
            <span className="text-[10px] font-mono font-bold text-[#888] uppercase tracking-widest">
              Automated Drilling Control Boundary & Autonomy Levels
            </span>
          </div>
          <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-[#111] text-[#00ff41] border border-[#00ff41]/40 font-bold shadow-[0_0_8px_rgba(0,255,65,0.15)]">
            HARDWARE SAFETY TRIPS ACTIVE
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-2 relative z-10">
          {autonomyLevels.map(lvl => {
            const isSelected = autonomyLevel === lvl.id;
            return (
              <button
                key={lvl.id}
                onClick={() => setAutonomyLevel(lvl.id)}
                className={`p-3 rounded border text-left transition-all space-y-1 ${
                  isSelected
                    ? 'bg-[#111] border-[#00ff41]/60 shadow-[0_0_10px_rgba(0,255,65,0.15)] text-white'
                    : 'bg-[#050505] border-[#222] text-[#888] hover:bg-[#111] hover:text-[#ccc]'
                }`}
              >
                <div className="flex items-center justify-between text-[10px] font-mono">
                  <span className="font-bold text-[#00ff41]">{lvl.badge}</span>
                  {isSelected && <Check className="w-3.5 h-3.5 text-[#00ff41]" />}
                </div>
                <h4 className="font-bold text-xs text-white">{lvl.name}</h4>
                <p className="text-[10px] text-[#777] leading-tight">{lvl.desc}</p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Structured Recommendations Feed */}
      <div className="bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none bg-grid-dots"></div>
        <div className="flex items-center justify-between border-b border-[#222] pb-2 relative z-10">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-400" />
            <span className="text-[10px] font-mono font-bold text-[#888] uppercase tracking-widest">
              Actionable Real-Time Drilling Engineering Advisories
            </span>
          </div>
          <span className="text-[9px] font-mono text-[#00ff41] px-2 py-0.5 rounded bg-[#111] border border-[#333]">
            {recommendations.length} Active Advisories
          </span>
        </div>

        <div className="space-y-3 pt-1 relative z-10">
          {recommendations.map(rec => {
            const isStickSlip = rec.actionCode === 'INCREASE_RPM';
            const isOptimal = rec.actionCode === 'OPTIMIZE_PARAMETERS';

            return (
              <div
                key={rec.id}
                className={`p-4 rounded border space-y-3 transition-all ${
                  isStickSlip
                    ? 'bg-[#180a0a] border-red-800/60'
                    : isOptimal
                    ? 'bg-[#0f1a12] border-[#00ff41]/50 shadow-[0_0_10px_rgba(0,255,65,0.1)]'
                    : 'bg-[#050505] border-[#222]'
                }`}
              >
                {/* Header */}
                <div className="flex items-start justify-between gap-2">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className={`text-[9px] font-mono px-2 py-0.5 rounded font-bold uppercase tracking-wider ${
                        isStickSlip ? 'bg-red-950 text-red-400 border border-red-800/60' : 'bg-[#00ff41]/20 text-[#00ff41] border border-[#00ff41]/40'
                      }`}>
                        {rec.actionCode}
                      </span>
                      <span className="text-xs font-mono text-[#888]">
                        Confidence: <strong className="text-[#00ff41]">{rec.mlConfidencePercent}%</strong>
                      </span>
                    </div>
                    <h3 className="font-bold text-sm text-white font-mono mt-1.5">{rec.title}</h3>
                  </div>

                  <button
                    onClick={() => onApplyRecommendation(rec)}
                    className="px-4 py-2 rounded bg-[#00ff41] hover:bg-[#00ff41]/90 text-black text-xs font-mono font-bold flex items-center gap-1.5 shadow-[0_0_10px_rgba(0,255,65,0.3)] transition-all shrink-0 uppercase tracking-wider"
                  >
                    <span>ACCEPT & EXECUTE</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Details Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-mono">
                  {/* Left: Reason & Evidence */}
                  <div className="space-y-2 p-3 bg-[#111] rounded border border-[#222]">
                    <div>
                      <span className="text-[#888] text-[9px] block font-bold uppercase tracking-wider">OPERATIONAL RATIONALE</span>
                      <p className="text-white mt-0.5 text-[11px] leading-relaxed font-sans">{rec.reason}</p>
                    </div>
                    <div>
                      <span className="text-[#888] text-[9px] block font-bold uppercase tracking-wider">TELEMETRY DATA EVIDENCE</span>
                      <p className="text-amber-300 mt-0.5 text-[11px] leading-relaxed font-sans">{rec.dataEvidence}</p>
                    </div>
                    <div className="text-[10px] text-[#666] pt-1 border-t border-[#222]">
                      Model: {rec.physicsModelUsed}
                    </div>
                  </div>

                  {/* Right: Suggested Setpoints & Constraint Checks */}
                  <div className="space-y-2 p-3 bg-[#111] rounded border border-[#222]">
                    <span className="text-[#888] text-[9px] block font-bold uppercase tracking-wider">PROPOSED SETPOINTS</span>
                    <div className="grid grid-cols-3 gap-2 text-center text-xs">
                      <div className="p-1.5 bg-[#050505] rounded border border-[#222]">
                        <span className="text-[#666] text-[8px] uppercase block">WOB</span>
                        <strong className="text-[#00ff41]">{rec.suggestedSetpoints.wobKn} kN</strong>
                      </div>
                      <div className="p-1.5 bg-[#050505] rounded border border-[#222]">
                        <span className="text-[#666] text-[8px] uppercase block">RPM</span>
                        <strong className="text-sky-400">{rec.suggestedSetpoints.rpm}</strong>
                      </div>
                      <div className="p-1.5 bg-[#050505] rounded border border-[#222]">
                        <span className="text-[#666] text-[8px] uppercase block">FLOW</span>
                        <strong className="text-amber-400">{rec.suggestedSetpoints.flowRateLs} L/s</strong>
                      </div>
                    </div>

                    {/* Constraint verification checklist */}
                    <div className="pt-2 border-t border-[#222] space-y-1 text-[10px]">
                      <span className="text-[#666] block text-[9px] uppercase tracking-wider font-bold">HARD PHYSICS SAFETY GATES</span>
                      <div className="flex flex-wrap gap-2">
                        <span className="flex items-center gap-1 text-[#00ff41]">
                          <CheckCircle2 className="w-3 h-3" /> Top Drive Torque Safe
                        </span>
                        <span className="flex items-center gap-1 text-[#00ff41]">
                          <CheckCircle2 className="w-3 h-3" /> Mud Pump SPP Safe
                        </span>
                        <span className="flex items-center gap-1 text-[#00ff41]">
                          <CheckCircle2 className="w-3 h-3" /> ECD Pore/Frac Window Safe
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
