'use client';

import React from 'react';
import { 
  FileText, 
  Download, 
  Copy, 
  Check, 
  ShieldCheck, 
  Compass, 
  Layers, 
  Flame, 
  Gauge, 
  DollarSign,
  Cpu
} from 'lucide-react';
import { DigitalTwinState } from '../lib/twin/drillingTwin';
import { UnitSystem } from '../lib/physics/units';

interface EngineeringReportViewProps {
  twin: DigitalTwinState;
  unitSystem: UnitSystem;
}

export const EngineeringReportView: React.FC<EngineeringReportViewProps> = ({ twin, unitSystem }) => {
  const [copied, setCopied] = React.useState(false);

  const handleCopy = () => {
    const reportText = `
DRILLCORE.OS ISO/SPE DRILLING ENGINEERING AUDIT REPORT
======================================================
Well: ${twin.wellName} (${twin.wellId})
Field: ${twin.field} | Rig: ${twin.rig.name}
Date: ${new Date().toLocaleDateString()}
Current MD: ${twin.currentDepthMdM.toFixed(1)} m | TVD: ${twin.currentTvdM.toFixed(1)} m
ROP: ${twin.ropResult.ropMHr.toFixed(1)} m/hr | MSE: ${twin.ropResult.mseMpa.toFixed(0)} MPa
SPP: ${twin.hydraulicsResult.standpipePressureBar.toFixed(1)} bar | ECD: ${twin.hydraulicsResult.ecdSg.toFixed(2)} sg
Total Cost: $${twin.economicsResult.totalCostUsd.toLocaleString()} USD
Cost/m: $${twin.economicsResult.costPerMeterUsd.toFixed(1)}/m
NPT Hours: ${twin.economicsResult.nptHoursTotal.toFixed(1)} hrs (${twin.economicsResult.nptPercentage.toFixed(1)}%)
Bit Dull Grade: ${twin.bit.dullGrade.toFixed(2)} / 8.0
`;
    navigator.clipboard.writeText(reportText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-4 font-sans text-[#e0e0e0]">
      {/* Top Action Bar */}
      <div className="flex items-center justify-between bg-[#0a0a0a] p-4 rounded border border-[#222]">
        <div className="flex items-center gap-2">
          <FileText className="w-4 h-4 text-[#00ff41]" />
          <span className="text-[10px] font-mono font-bold text-[#888] uppercase tracking-widest">
            ISO / SPE Drilling Operations Audit & Mathematical Documentation
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="px-3 py-1.5 rounded bg-[#111] hover:bg-[#1a1a1a] text-white border border-[#333] hover:border-[#00ff41]/50 text-xs font-mono font-semibold flex items-center gap-1.5 transition-all"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-[#00ff41]" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy Text'}</span>
          </button>
        </div>
      </div>

      {/* Structured Engineering Report Card */}
      <div className="bg-[#0a0a0a] rounded border border-[#222] p-6 space-y-6 font-mono text-xs text-[#ccc] relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none bg-grid-dots"></div>
        {/* Section 1: Executive Summary */}
        <div className="space-y-2 border-b border-[#222] pb-4 relative z-10">
          <h2 className="text-xs font-bold text-[#00ff41] tracking-wider uppercase">
            1. EXECUTIVE WELL DELIVERY & DRILLING SUMMARY
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-2 text-[11px]">
            <div className="p-2.5 bg-[#111] rounded border border-[#222]">
              <span className="text-[#666] block text-[9px] uppercase">WELL IDENTIFIER</span>
              <strong className="text-white">{twin.wellName}</strong>
            </div>
            <div className="p-2.5 bg-[#111] rounded border border-[#222]">
              <span className="text-[#666] block text-[9px] uppercase">CURRENT DEPTH (MD/TVD)</span>
              <strong className="text-[#00ff41]">{twin.currentDepthMdM.toFixed(1)} m / {twin.currentTvdM.toFixed(1)} m</strong>
            </div>
            <div className="p-2.5 bg-[#111] rounded border border-[#222]">
              <span className="text-[#666] block text-[9px] uppercase">TOTAL EXPENDITURE</span>
              <strong className="text-white">${twin.economicsResult.totalCostUsd.toLocaleString()} USD</strong>
            </div>
            <div className="p-2.5 bg-[#111] rounded border border-[#222]">
              <span className="text-[#666] block text-[9px] uppercase">NON-PRODUCTIVE TIME (NPT)</span>
              <strong className="text-amber-400">{twin.economicsResult.nptHoursTotal.toFixed(1)} hrs ({twin.economicsResult.nptPercentage.toFixed(1)}%)</strong>
            </div>
          </div>
        </div>

        {/* Section 2: Drilling Mechanics */}
        <div className="space-y-2 border-b border-[#222] pb-4 relative z-10">
          <h2 className="text-xs font-bold text-sky-400 tracking-wider uppercase">
            2. DRILLING MECHANICS, BIT WEAR & ROP EFFICIENCY
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2 text-[11px]">
            <div className="p-3 bg-[#111] rounded border border-[#222] space-y-1">
              <span className="text-[#888] font-bold block uppercase text-[9px]">RATE OF PENETRATION</span>
              <div className="text-lg font-bold text-[#00ff41]">{twin.ropResult.ropMHr.toFixed(1)} m/hr</div>
              <p className="text-[10px] text-[#666]">Mechanistic Hareland & Rampersad Shearing Model</p>
            </div>
            <div className="p-3 bg-[#111] rounded border border-[#222] space-y-1">
              <span className="text-[#888] font-bold block uppercase text-[9px]">MECHANICAL SPECIFIC ENERGY</span>
              <div className="text-lg font-bold text-sky-400">{twin.ropResult.mseMpa.toFixed(0)} MPa</div>
              <p className="text-[10px] text-[#666]">Teale MSE Formulation (Efficiency {twin.ropResult.drillingEfficiencyPercent.toFixed(0)}%)</p>
            </div>
            <div className="p-3 bg-[#111] rounded border border-[#222] space-y-1">
              <span className="text-[#888] font-bold block uppercase text-[9px]">BIT WEAR / IADC DULL</span>
              <div className="text-lg font-bold text-white">{twin.bit.dullGrade.toFixed(2)} / 8.0</div>
              <p className="text-[10px] text-[#666]">Meters Drilled: {twin.bit.cumulativeMetersDrilled.toFixed(0)} m in {twin.bit.operatingHours.toFixed(1)} hrs</p>
            </div>
          </div>
        </div>

        {/* Section 3: Hydraulics & Pressure Window */}
        <div className="space-y-2 border-b border-[#222] pb-4 relative z-10">
          <h2 className="text-xs font-bold text-purple-400 tracking-wider uppercase">
            3. HYDRAULIC PRESSURE LOSSES & INTEGRITY
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2 text-[11px]">
            <div className="p-3 bg-[#111] rounded border border-[#222] space-y-1">
              <span className="text-[#888] font-bold block uppercase text-[9px]">STANDPIPE PRESSURE</span>
              <div className="text-lg font-bold text-amber-400">{twin.hydraulicsResult.standpipePressureBar.toFixed(1)} bar</div>
              <p className="text-[10px] text-[#666]">Flow: {twin.hydraulicsResult.flowRateLs.toFixed(1)} L/s</p>
            </div>
            <div className="p-3 bg-[#111] rounded border border-[#222] space-y-1">
              <span className="text-[#888] font-bold block uppercase text-[9px]">EQUIVALENT CIRC DENSITY</span>
              <div className="text-lg font-bold text-purple-400">{twin.hydraulicsResult.ecdSg.toFixed(2)} sg</div>
              <p className="text-[10px] text-[#666]">Safe Window: {twin.currentFormation.porePressureGradSg.toFixed(2)} - {twin.currentFormation.fractureGradSg.toFixed(2)} sg</p>
            </div>
            <div className="p-3 bg-[#111] rounded border border-[#222] space-y-1">
              <span className="text-[#888] font-bold block uppercase text-[9px]">ANNULAR HOLE CLEANING</span>
              <div className="text-lg font-bold text-[#00ff41]">{twin.cuttingsResult.wellCleaningIndexScore.toFixed(0)} / 100</div>
              <p className="text-[10px] text-[#666]">Larsen-Chien Transport Ratio: {twin.cuttingsResult.transportRatioPercent.toFixed(0)}%</p>
            </div>
          </div>
        </div>

        {/* Section 4: Mathematical Physics Equations Reference */}
        <div className="space-y-3 relative z-10">
          <h2 className="text-xs font-bold text-white tracking-wider uppercase">
            4. MATHEMATICAL PHYSICS FORMULATION ARCHITECTURE
          </h2>
          <div className="bg-[#050505] p-4 rounded border border-[#222] space-y-3 text-[11px] text-[#aaa]">
            <div>
              <strong className="text-[#00ff41] block">1. 3D Minimum Curvature Trajectory:</strong>
              <code>{"ΔMD = s_{i+1} - s_i;  RF = (2/β)·tan(β/2);  ΔTVD = (ΔMD/2)·(cos I₁ + cos I₂)·RF"}</code>
            </div>
            <div>
              <strong className="text-sky-400 block">2. Mechanistic Rock Shearing ROP (Hareland):</strong>
              <code>{"ROP = f_D(WOB, RPM, D_bit, UCS, TFA) = c · (WOB/D_bit)^a · RPM^b · (1/UCS) · (1 - ΔDull)"}</code>
            </div>
            <div>
              <strong className="text-amber-400 block">3. Teale Mechanical Specific Energy (MSE):</strong>
              <code>{"MSE = WOB / A_bit + (2π · RPM · Torque) / (A_bit · ROP)"}</code>
            </div>
            <div>
              <strong className="text-red-400 block">4. Johancsik 3D Torque &amp; Drag with Paslay-Dawson Buckling:</strong>
              <code>{"F_{i+1} = F_i + w·cos(θ)·Δs ± μ·N_i;  F_{crit,sin} = 2·sqrt(E·I·w·sin(θ) / r)"}</code>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
