'use client';

import React from 'react';
import { 
  Sliders, 
  Play, 
  ShieldAlert, 
  CheckCircle2, 
  AlertTriangle, 
  TrendingUp, 
  Flame, 
  Gauge, 
  DollarSign,
  ArrowRight,
  Info
} from 'lucide-react';
import { DigitalTwinState } from '../lib/twin/drillingTwin';
import { UnitSystem } from '../lib/physics/units';
import { AdvisorAndScenarioEngine, ScenarioEvaluation } from '../lib/twin/advisorAndScenarios';

interface ScenarioLabViewProps {
  twin: DigitalTwinState;
  unitSystem: UnitSystem;
  onApplyScenario: (scenario: ScenarioEvaluation) => void;
}

export const ScenarioLabView: React.FC<ScenarioLabViewProps> = ({
  twin,
  unitSystem,
  onApplyScenario,
}) => {
  const scenarios = AdvisorAndScenarioEngine.runScenarioLab(twin);

  return (
    <div className="space-y-4 font-sans text-[#e0e0e0]">
      <div className="bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none bg-grid-dots"></div>
        <div className="flex items-center justify-between border-b border-[#222] pb-2 relative z-10">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#00ff41]" />
            <span className="text-[10px] font-mono font-bold text-[#888] uppercase tracking-widest">
              Parallel What-If Scenario Lab & Operational Risk Matrix
            </span>
          </div>
          <span className="text-[9px] font-mono text-[#00ff41] px-2 py-0.5 rounded bg-[#111] border border-[#333]">
            Simulated on Authoritative Physics Engine
          </span>
        </div>

        <p className="text-xs text-[#888] leading-relaxed font-sans relative z-10">
          Test hypothesized drilling conditions, aggressive ROP setpoints, sudden formation changes, and well control influxes in a sandboxed physics simulation before issuing commands to the rig.
        </p>

        {/* Scenarios Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2 relative z-10">
          {scenarios.map(sc => {
            const isBaseline = sc.scenarioType === 'BASELINE';
            const isOptimized = sc.scenarioType === 'OPTIMISED_SETPOINTS';

            return (
              <div
                key={sc.scenarioType}
                className={`p-4 rounded border flex flex-col justify-between transition-all ${
                  isOptimized
                    ? 'bg-[#0f1a12] border-[#00ff41]/60 shadow-[0_0_12px_rgba(0,255,65,0.15)]'
                    : isBaseline
                    ? 'bg-[#0a0a0a] border-sky-500/40'
                    : sc.outcomes.isSafe
                    ? 'bg-[#050505] border-[#222]'
                    : 'bg-[#180a0a] border-red-800/60'
                }`}
              >
                <div className="space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded font-bold uppercase tracking-wider ${
                        isOptimized
                          ? 'bg-[#00ff41]/20 text-[#00ff41] border border-[#00ff41]/40'
                          : isBaseline
                          ? 'bg-sky-950 text-sky-400 border border-sky-800/50'
                          : sc.outcomes.isSafe
                          ? 'bg-[#111] text-[#888] border border-[#333]'
                          : 'bg-red-950 text-red-400 border border-red-800/50'
                      }`}>
                        {sc.scenarioType}
                      </span>
                      <h4 className="font-bold font-mono text-xs text-white mt-1.5">{sc.title}</h4>
                    </div>
                    {sc.outcomes.isSafe ? (
                      <CheckCircle2 className="w-4 h-4 text-[#00ff41] shrink-0 mt-0.5" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                    )}
                  </div>

                  <p className="text-[11px] text-[#888] font-sans leading-relaxed">{sc.description}</p>

                  {/* Operational Parameters Strip */}
                  <div className="p-2 rounded bg-[#111] border border-[#222] grid grid-cols-3 gap-1 text-[10px] font-mono text-center">
                    <div>
                      <span className="text-[#666] block text-[8px] uppercase">WOB</span>
                      <strong className="text-white">{sc.parameters.wobKn} kN</strong>
                    </div>
                    <div>
                      <span className="text-[#666] block text-[8px] uppercase">RPM</span>
                      <strong className="text-sky-400">{sc.parameters.rpm}</strong>
                    </div>
                    <div>
                      <span className="text-[#666] block text-[8px] uppercase">FLOW</span>
                      <strong className="text-amber-400">{sc.parameters.flowRateLs} L/s</strong>
                    </div>
                  </div>

                  {/* Physical Outcomes */}
                  <div className="space-y-1 text-xs font-mono pt-1">
                    <div className="flex justify-between">
                      <span className="text-[#888]">Expected ROP:</span>
                      <span className={`font-bold ${sc.outcomes.ropMHr > twin.ropResult.ropMHr ? 'text-[#00ff41]' : 'text-white'}`}>
                        {sc.outcomes.ropMHr.toFixed(1)} m/hr
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#888]">Mech Spec Energy (MSE):</span>
                      <span className="font-bold text-white">{sc.outcomes.mseMpa.toFixed(0)} MPa</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#888]">Stick-Slip Severity:</span>
                      <span className={`font-bold ${sc.outcomes.stickSlipSeverityPercent > 60 ? 'text-red-400' : 'text-[#00ff41]'}`}>
                        {sc.outcomes.stickSlipSeverityPercent.toFixed(0)}%
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#888]">Standpipe Pressure:</span>
                      <span className="font-bold text-white">{sc.outcomes.standpipePressureBar.toFixed(1)} bar</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#888]">Cost per Meter:</span>
                      <span className="font-bold text-white">${sc.outcomes.costPerMeterUsd.toFixed(0)}/m</span>
                    </div>
                  </div>

                  {/* Hazard / Bottleneck Banner if unsafe */}
                  {!sc.outcomes.isSafe && (
                    <div className="p-2 rounded bg-red-950/40 border border-red-800 text-[10px] font-mono text-red-300 flex items-start gap-1.5">
                      <ShieldAlert className="w-3.5 h-3.5 shrink-0 mt-0.5 text-red-400" />
                      <span>{sc.outcomes.bottleneckOrHazard}</span>
                    </div>
                  )}
                </div>

                <div className="pt-3 mt-3 border-t border-[#222]">
                  <button
                    onClick={() => onApplyScenario(sc)}
                    className="w-full py-1.5 rounded bg-[#111] hover:bg-[#1a1a1a] hover:border-[#00ff41]/50 border border-[#333] text-white text-[11px] font-mono font-semibold transition-all flex items-center justify-center gap-1.5"
                  >
                    <span>Commit to Digital Twin</span>
                    <ArrowRight className="w-3.5 h-3.5 text-[#00ff41]" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
