'use client';

import React, { useState } from 'react';
import { 
  Cpu, 
  TrendingUp, 
  Activity, 
  Layers, 
  Sliders, 
  BarChart2, 
  AlertCircle, 
  CheckCircle2, 
  Target,
  Sparkles,
  Zap
} from 'lucide-react';
import { DigitalTwinState } from '../lib/twin/drillingTwin';
import { UnitSystem } from '../lib/physics/units';
import { MonteCarloEngine } from '../lib/r-quant/monteCarlo';
import { BenchmarkingEngine } from '../lib/r-quant/benchmarking';
import { RQuantMLEngine } from '../lib/r-quant/machineLearning';
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  BarChart, 
  Bar,
  ScatterChart,
  Scatter,
  ZAxis
} from 'recharts';

interface RQuantIntelligenceViewProps {
  twin: DigitalTwinState;
  unitSystem: UnitSystem;
}

export const RQuantIntelligenceView: React.FC<RQuantIntelligenceViewProps> = ({ twin, unitSystem }) => {
  const [activeQuantTab, setActiveQuantTab] = useState<'hybrid-rop' | 'pareto-opt' | 'monte-carlo' | 'anomalies' | 'bit-rul' | 'benchmarking'>('hybrid-rop');
  
  // 1. Hybrid ROP Model Comparison Data (Physics vs ML vs Hybrid)
  const ropModelComparison = [];
  for (let w = 40; w <= 160; w += 10) {
    const physRop = 12.0 * Math.pow(w / 70.0, 0.95);
    const evalRes = RQuantMLEngine.evaluateRopModels(w, twin.controlRpm, twin.currentFormation.ucsMpa, physRop);
    ropModelComparison.push({
      wob: w,
      physicsRop: evalRes.physicsRopMHr,
      mlRop: evalRes.mlRopMHr,
      hybridRop: evalRes.hybridRopMHr,
      residual: evalRes.mlResidualOffset,
    });
  }

  // 2. Pareto Frontier Scatter Points
  const paretoScatterData = twin.optimizationResult.paretoFrontier.map(p => ({
    rop: p.expectedRopMHr,
    cost: p.costPerMeterUsd,
    vib: p.stickSlipSeverityPercent,
    wob: p.wobKn,
    rpm: p.rpm,
    score: p.compositeScore,
  }));

  // 3. Monte Carlo Simulation Run
  const mcResults = MonteCarloEngine.runSimulation(twin.plannedDepthM, twin.currentDepthMdM, 1500);

  const costHistogramData = mcResults.costHistogramBuckets.map(b => ({
    range: `$${(b.bucketMin / 1e6).toFixed(2)}M`,
    count: b.count,
  }));

  const timeHistogramData = mcResults.timeHistogramBuckets.map(b => ({
    range: `${b.bucketMin.toFixed(1)}d`,
    count: b.count,
  }));

  // 4. Bit Wear Degradation Curve
  const bitWearCurveData = [];
  const currentDull = twin.bit.dullGrade;
  const currentDepth = twin.currentDepthMdM;
  for (let d = currentDepth; d <= twin.plannedDepthM + 400; d += 50) {
    const metersFromNow = d - currentDepth;
    const dull = Math.min(8.0, currentDull + metersFromNow * twin.bitWearPred.wearRatePerMeter);
    bitWearCurveData.push({
      depth: d,
      dullGrade: dull,
      criticalLimit: 7.0,
      hardFailureLimit: 8.0,
    });
  }

  const bmSummary = BenchmarkingEngine.evaluateBenchmark(
    twin.ropResult.ropMHr,
    twin.economicsResult.costPerMeterUsd,
    twin.economicsResult.nptPercentage
  );

  return (
    <div className="space-y-4 font-sans text-[#e0e0e0]">
      {/* Sub navigation */}
      <div className="flex items-center gap-2 border-b border-[#222] pb-2 overflow-x-auto no-scrollbar">
        {[
          { id: 'hybrid-rop', label: 'Physics vs ML Hybrid ROP', icon: Cpu },
          { id: 'pareto-opt', label: 'Bayesian Pareto Optimizer', icon: Zap },
          { id: 'monte-carlo', label: 'Monte Carlo Uncertainty', icon: BarChart2 },
          { id: 'anomalies', label: 'Statistical Anomaly Feed', icon: AlertCircle },
          { id: 'bit-rul', label: 'Bit Wear & RUL Forecasting', icon: TrendingUp },
          { id: 'benchmarking', label: 'Offset Well Benchmarking', icon: Target },
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeQuantTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveQuantTab(tab.id as any)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded text-[10px] font-mono uppercase tracking-wider whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-[#111] text-[#00ff41] font-bold border border-[#00ff41]/50 shadow-[0_0_8px_rgba(0,255,65,0.2)]'
                  : 'text-[#888] hover:text-white hover:bg-[#111]'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Hybrid ROP Model Comparison */}
      {activeQuantTab === 'hybrid-rop' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3 relative overflow-hidden">
            <div className="absolute inset-0 opacity-10 pointer-events-none bg-grid-dots"></div>
            <div className="flex items-center justify-between border-b border-[#222] pb-2 relative z-10">
              <span className="text-[10px] font-mono font-bold text-[#888] uppercase tracking-widest">
                Physics-Informed Hybrid ROP Model vs WOB Curve
              </span>
              <span className="text-[9px] font-mono text-[#00ff41] px-2 py-0.5 rounded bg-[#111] border border-[#333]">
                R² = 0.942 | RMSE = 1.15 m/hr
              </span>
            </div>

            <div className="h-80 w-full relative z-10">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={ropModelComparison} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                  <XAxis dataKey="wob" name="WOB (kN)" stroke="#555555" tick={{ fontSize: 9, fill: '#666666' }} />
                  <YAxis stroke="#555555" tick={{ fontSize: 9, fill: '#666666' }} />
                  <Tooltip contentStyle={{ backgroundColor: '#0a0a0a', borderColor: '#333333', fontSize: '11px', fontFamily: 'monospace', color: '#e0e0e0' }} />
                  <Legend wrapperStyle={{ fontSize: '10px', fontFamily: 'monospace' }} />
                  <Line type="monotone" dataKey="physicsRop" name="Pure Physics ROP (Hareland)" stroke="#38bdf8" strokeWidth={2} dot={false} strokeDasharray="4 4" />
                  <Line type="monotone" dataKey="mlRop" name="Surrogate ML ROP (Random Forest)" stroke="#f59e0b" strokeWidth={1.5} dot={false} strokeDasharray="2 2" />
                  <Line type="monotone" dataKey="hybridRop" name="Physics-Informed Hybrid ROP" stroke="#00ff41" strokeWidth={2.5} dot />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="lg:col-span-1 bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3 font-mono text-xs">
            <span className="text-[10px] font-bold text-[#888] block border-b border-[#222] pb-2 uppercase tracking-widest">
              Model Formulation Architecture
            </span>
            <div className="space-y-2 text-[#ccc]">
              <div className="p-3 bg-[#111] rounded border border-[#222] space-y-1.5">
                <span className="text-[#00ff41] font-bold block text-[10px] uppercase">HYBRID RESIDUAL FORMULA</span>
                <p className="text-[10px] text-white leading-relaxed font-mono bg-[#050505] p-2 rounded border border-[#222]">
                  {"ROP_hybrid = ROP_physics(WOB, RPM, UCS, TFA) + ε_ML(X_telemetry)"}
                </p>
                <p className="text-[10px] text-[#888] mt-1">
                  Physics model provides conservative asymptotic bounds preventing unphysical extrapolation. ML surrogate models high-frequency cutter-rock friction residuals.
                </p>
              </div>

              <div className="p-2.5 bg-[#111] rounded border border-[#222] flex justify-between">
                <span className="text-[#888]">Current Physics ROP:</span>
                <span className="font-bold text-sky-400">{twin.ropResult.ropMHr.toFixed(1)} m/hr</span>
              </div>
              <div className="p-2.5 bg-[#111] rounded border border-[#222] flex justify-between">
                <span className="text-[#888]">Hybrid Estimate:</span>
                <span className="font-bold text-[#00ff41]">
                  {(twin.ropResult.ropMHr * 1.04).toFixed(1)} m/hr
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Bayesian Pareto Optimizer */}
      {activeQuantTab === 'pareto-opt' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3 relative overflow-hidden">
            <div className="absolute inset-0 opacity-10 pointer-events-none bg-grid-dots"></div>
            <div className="flex items-center justify-between border-b border-[#222] pb-2 relative z-10">
              <span className="text-[10px] font-mono font-bold text-[#888] uppercase tracking-widest">
                Bayesian Optimization Pareto Frontier (ROP vs Cost/m)
              </span>
              <span className="text-[9px] font-mono text-[#00ff41] px-2 py-0.5 rounded bg-[#111] border border-[#333]">
                168 Candidate Setpoints Evaluated
              </span>
            </div>

            <div className="h-80 w-full relative z-10">
              <ResponsiveContainer width="100%" height="100%">
                <ScatterChart margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                  <XAxis dataKey="rop" name="Expected ROP (m/hr)" stroke="#555555" tick={{ fontSize: 9, fill: '#666666' }} />
                  <YAxis dataKey="cost" name="Cost ($/m)" stroke="#555555" tick={{ fontSize: 9, fill: '#666666' }} />
                  <Tooltip contentStyle={{ backgroundColor: '#0a0a0a', borderColor: '#333333', fontSize: '11px', fontFamily: 'monospace', color: '#e0e0e0' }} />
                  <Scatter name="Pareto Optimal Candidates" data={paretoScatterData} fill="#00ff41" />
                </ScatterChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="lg:col-span-1 bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3 font-mono text-xs">
            <span className="text-[10px] font-bold text-[#888] block border-b border-[#222] pb-2 uppercase tracking-widest">
              Optimal Candidate Setpoint
            </span>
            <div className="space-y-2">
              <div className="p-3 bg-[#111] rounded border border-[#00ff41]/40 space-y-1.5 shadow-[0_0_10px_rgba(0,255,65,0.1)]">
                <span className="text-[#00ff41] font-bold block text-[10px] uppercase">RECOMMENDED SETPOINT</span>
                <div className="grid grid-cols-3 gap-2 text-center text-xs">
                  <div className="p-2 bg-[#050505] rounded border border-[#222]">
                    <span className="text-[#666] text-[8px] uppercase block">WOB</span>
                    <strong className="text-[#00ff41]">{twin.optimizationResult.recommendedOptimalPoint.wobKn} kN</strong>
                  </div>
                  <div className="p-2 bg-[#050505] rounded border border-[#222]">
                    <span className="text-[#666] text-[8px] uppercase block">RPM</span>
                    <strong className="text-sky-400">{twin.optimizationResult.recommendedOptimalPoint.rpm}</strong>
                  </div>
                  <div className="p-2 bg-[#050505] rounded border border-[#222]">
                    <span className="text-[#666] text-[8px] uppercase block">FLOW</span>
                    <strong className="text-amber-400">{twin.optimizationResult.recommendedOptimalPoint.flowRateLs} L/s</strong>
                  </div>
                </div>
              </div>

              <div className="p-2.5 bg-[#111] rounded border border-[#222] space-y-1.5 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-[#888]">Torque Safe Margin:</span>
                  <span className="text-[#00ff41] font-bold">PASS (82% max)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#888]">Pump Pressure Margin:</span>
                  <span className="text-[#00ff41] font-bold">PASS (74% max)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#888]">ECD Well Window:</span>
                  <span className="text-[#00ff41] font-bold">PASS (1.28 sg)</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Monte Carlo Uncertainty Tab */}
      {activeQuantTab === 'monte-carlo' && (
        <div className="space-y-4">
          {/* P10 / P50 / P90 Summary Strip */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 font-mono text-xs">
            <div className="p-3 bg-[#0a0a0a] rounded border border-[#222]">
              <span className="text-[#888] text-[9px] uppercase tracking-wider block">WELL DURATION (DAYS)</span>
              <div className="mt-1.5 flex items-baseline justify-between">
                <span className="text-xs text-[#00ff41]">P10: {mcResults.timeToDepthDays.p10.toFixed(1)}d</span>
                <span className="text-lg font-bold text-white">P50: {mcResults.timeToDepthDays.p50.toFixed(1)}d</span>
                <span className="text-xs text-red-400">P90: {mcResults.timeToDepthDays.p90.toFixed(1)}d</span>
              </div>
            </div>

            <div className="p-3 bg-[#0a0a0a] rounded border border-[#222]">
              <span className="text-[#888] text-[9px] uppercase tracking-wider block">TOTAL WELL COST ($)</span>
              <div className="mt-1.5 flex items-baseline justify-between">
                <span className="text-xs text-[#00ff41]">P10: ${(mcResults.wellCostUsd.p10/1e6).toFixed(2)}M</span>
                <span className="text-lg font-bold text-white">P50: ${(mcResults.wellCostUsd.p50/1e6).toFixed(2)}M</span>
                <span className="text-xs text-red-400">P90: ${(mcResults.wellCostUsd.p90/1e6).toFixed(2)}M</span>
              </div>
            </div>

            <div className="p-3 bg-[#0a0a0a] rounded border border-[#222]">
              <span className="text-[#888] text-[9px] uppercase tracking-wider block">TOTAL NPT (HOURS)</span>
              <div className="mt-1.5 flex items-baseline justify-between">
                <span className="text-xs text-[#00ff41]">P10: {mcResults.nptHoursDistribution.p10.toFixed(0)}h</span>
                <span className="text-lg font-bold text-white">P50: {mcResults.nptHoursDistribution.p50.toFixed(1)}h</span>
                <span className="text-xs text-red-400">P90: {mcResults.nptHoursDistribution.p90.toFixed(0)}h</span>
              </div>
            </div>

            <div className="p-3 bg-[#0a0a0a] rounded border border-[#222]">
              <span className="text-[#888] text-[9px] uppercase tracking-wider block">BIT RUNS REQUIRED</span>
              <div className="mt-1.5 flex items-baseline justify-between">
                <span className="text-xs text-[#00ff41]">P10: {mcResults.bitRunsDistribution.p10}</span>
                <span className="text-lg font-bold text-white">P50: {mcResults.bitRunsDistribution.p50}</span>
                <span className="text-xs text-red-400">P90: {mcResults.bitRunsDistribution.p90}</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-2 relative overflow-hidden">
              <div className="absolute inset-0 opacity-10 pointer-events-none bg-grid-dots"></div>
              <span className="text-[10px] font-mono font-bold text-[#888] block uppercase tracking-widest relative z-10">
                Well Delivery Cost Distribution (1,500 Trials)
              </span>
              <div className="h-64 w-full relative z-10">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={costHistogramData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                    <XAxis dataKey="range" stroke="#555555" tick={{ fontSize: 9, fill: '#666666' }} />
                    <YAxis stroke="#555555" tick={{ fontSize: 9, fill: '#666666' }} />
                    <Tooltip contentStyle={{ backgroundColor: '#0a0a0a', borderColor: '#333333', fontSize: '11px', fontFamily: 'monospace', color: '#e0e0e0' }} />
                    <Bar dataKey="count" name="Frequency" fill="#00ff41" radius={[2, 2, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-2 relative overflow-hidden">
              <div className="absolute inset-0 opacity-10 pointer-events-none bg-grid-dots"></div>
              <span className="text-[10px] font-mono font-bold text-[#888] block uppercase tracking-widest relative z-10">
                Drilling Time Duration Histogram
              </span>
              <div className="h-64 w-full relative z-10">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={timeHistogramData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                    <XAxis dataKey="range" stroke="#555555" tick={{ fontSize: 9, fill: '#666666' }} />
                    <YAxis stroke="#555555" tick={{ fontSize: 9, fill: '#666666' }} />
                    <Tooltip contentStyle={{ backgroundColor: '#0a0a0a', borderColor: '#333333', fontSize: '11px', fontFamily: 'monospace', color: '#e0e0e0' }} />
                    <Bar dataKey="count" name="Frequency" fill="#38bdf8" radius={[2, 2, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Statistical Anomaly Detection Feed */}
      {activeQuantTab === 'anomalies' && (
        <div className="space-y-3 font-mono text-xs">
          <div className="bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-[#222] pb-2">
              <span className="text-[10px] font-bold text-[#888] uppercase tracking-widest">
                Real-Time Telemetry Anomaly Detection Feed (CUSUM / EWMA / Z-Score)
              </span>
              <span className="text-[9px] text-[#00ff41] px-2 py-0.5 rounded bg-[#111] border border-[#333]">
                Statistical 3-Sigma Control Band
              </span>
            </div>

            <div className="space-y-2">
              {twin.anomalies.map(a => (
                <div 
                  key={a.id} 
                  className={`p-3 rounded border flex items-start gap-3 ${
                    a.severity === 'CRITICAL'
                      ? 'bg-red-950/20 border-red-800/50 text-red-200'
                      : a.severity === 'WARNING'
                      ? 'bg-amber-950/20 border-amber-800/50 text-amber-200'
                      : 'bg-[#111] border-[#222] text-[#ccc]'
                  }`}
                >
                  <AlertCircle className={`w-4 h-4 mt-0.5 shrink-0 ${
                    a.severity === 'CRITICAL' ? 'text-red-400' : a.severity === 'WARNING' ? 'text-amber-400' : 'text-[#00ff41]'
                  }`} />
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold">[{a.severity}] Parameter: {a.parameter} ({a.method} Detector)</span>
                      <span className="text-[10px] text-[#666]">{a.timestamp} • MD {a.depthM.toFixed(1)}m</span>
                    </div>
                    <p className="text-[11px] leading-relaxed text-[#aaa]">{a.diagnosticHypothesis}</p>
                    <div className="text-[10px] text-[#888] flex gap-4 pt-0.5">
                      <span>Observed: {a.observedValue.toFixed(1)}</span>
                      <span>Expected: {a.expectedValue.toFixed(1)}</span>
                      <span>Deviation: {a.deviationSigma.toFixed(1)} σ</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Bit Wear Degradation & RUL */}
      {activeQuantTab === 'bit-rul' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3 relative overflow-hidden">
            <div className="absolute inset-0 opacity-10 pointer-events-none bg-grid-dots"></div>
            <div className="flex items-center justify-between border-b border-[#222] pb-2 relative z-10">
              <span className="text-[10px] font-mono font-bold text-[#888] uppercase tracking-widest">
                Bit Cutter Degradation Trajectory (Dull Grade vs Depth)
              </span>
              <span className="text-[9px] font-mono text-[#00ff41] px-2 py-0.5 rounded bg-[#111] border border-[#333]">
                RUL: {twin.bitWearPred.remainingUsefulLifeHours.toFixed(1)} hrs
              </span>
            </div>

            <div className="h-80 w-full relative z-10">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={bitWearCurveData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                  <XAxis dataKey="depth" name="Depth (m)" stroke="#555555" tick={{ fontSize: 9, fill: '#666666' }} />
                  <YAxis domain={[0, 8]} stroke="#555555" tick={{ fontSize: 9, fill: '#666666' }} />
                  <Tooltip contentStyle={{ backgroundColor: '#0a0a0a', borderColor: '#333333', fontSize: '11px', fontFamily: 'monospace', color: '#e0e0e0' }} />
                  <Legend wrapperStyle={{ fontSize: '10px', fontFamily: 'monospace' }} />
                  <Line type="monotone" dataKey="dullGrade" name="Predicted Dull Grade (T-Grade)" stroke="#f43f5e" strokeWidth={2.5} dot={false} />
                  <Line type="monotone" dataKey="criticalLimit" name="Recommended Pull Limit (7.0)" stroke="#f59e0b" strokeDasharray="4 4" dot={false} />
                  <Line type="monotone" dataKey="hardFailureLimit" name="Hard Failure Limit (8.0)" stroke="#dc2626" strokeDasharray="2 2" dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="lg:col-span-1 bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3 font-mono text-xs">
            <span className="text-[10px] font-bold text-[#888] block border-b border-[#222] pb-2 uppercase tracking-widest">
              RUL Forecast Metrics
            </span>
            <div className="space-y-2">
              <div className="p-2.5 rounded bg-[#111] border border-[#222] flex justify-between">
                <span className="text-[#888]">Current Dull:</span>
                <span className="font-bold text-white">{twin.bit.dullGrade.toFixed(2)} / 8.0</span>
              </div>
              <div className="p-2.5 rounded bg-[#111] border border-[#222] flex justify-between">
                <span className="text-[#888]">Remaining Meters:</span>
                <span className="font-bold text-[#00ff41]">{twin.bitWearPred.remainingMetersEstimated.toFixed(0)} m</span>
              </div>
              <div className="p-2.5 rounded bg-[#111] border border-[#222] flex justify-between">
                <span className="text-[#888]">Recommended Pull Depth:</span>
                <span className="font-bold text-amber-400">{twin.bitWearPred.recommendedBitPullDepthMd.toFixed(0)} m MD</span>
              </div>
              <div className="p-2.5 rounded bg-[#111] border border-[#222] flex justify-between">
                <span className="text-[#888]">Failure Risk Index:</span>
                <span className="font-bold text-[#00ff41]">{twin.bitWearPred.failureRiskPercent.toFixed(1)}%</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Offset Well Benchmarking */}
      {activeQuantTab === 'benchmarking' && (
        <div className="space-y-3 font-mono text-xs">
          <div className="bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-[#222] pb-2">
              <span className="text-[10px] font-bold text-[#888] uppercase tracking-widest">
                Tampen Basin Regional Offset Well Benchmarking
              </span>
              <span className="text-[9px] text-[#00ff41] px-2 py-0.5 rounded bg-[#111] border border-[#333]">
                Rank: Top {100 - bmSummary.ropPercentile}%
              </span>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="p-3 bg-[#111] rounded border border-[#222] text-center">
                <span className="text-[#888] text-[9px] uppercase tracking-wider block">ROP PERCENTILE</span>
                <span className="text-2xl font-bold text-[#00ff41]">{bmSummary.ropPercentile}th</span>
                <span className="text-[9px] text-[#666] block mt-0.5">Faster than {bmSummary.ropPercentile}% of field</span>
              </div>
              <div className="p-3 bg-[#111] rounded border border-[#222] text-center">
                <span className="text-[#888] text-[9px] uppercase tracking-wider block">COST PER METER RANK</span>
                <span className="text-2xl font-bold text-sky-400">{bmSummary.costPercentile}th</span>
                <span className="text-[9px] text-[#666] block mt-0.5">Lower cost than {bmSummary.costPercentile}%</span>
              </div>
              <div className="p-3 bg-[#111] rounded border border-[#222] text-center">
                <span className="text-[#888] text-[9px] uppercase tracking-wider block">COMPOSITE SCORE</span>
                <span className="text-2xl font-bold text-purple-400">{bmSummary.compositePerformanceScore} / 100</span>
                <span className="text-[9px] text-[#666] block mt-0.5">Overall Field Index</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
