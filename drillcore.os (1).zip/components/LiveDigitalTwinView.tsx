'use client';

import React from 'react';
import { 
  Gauge, 
  Activity, 
  Layers, 
  AlertTriangle, 
  CheckCircle2, 
  Compass, 
  Flame, 
  Zap,
  TrendingUp,
  Cpu,
  ShieldAlert,
  ArrowUpRight,
  Clock,
  DollarSign
} from 'lucide-react';
import { DigitalTwinState } from '../lib/twin/drillingTwin';
import { UnitSystem, UnitConverter } from '../lib/physics/units';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';

interface LiveDigitalTwinViewProps {
  twin: DigitalTwinState;
  unitSystem: UnitSystem;
  onControlChange: (key: 'wob' | 'rpm' | 'flow' | 'mudDensity', val: number) => void;
  onApplyOptimal: () => void;
}

export const LiveDigitalTwinView: React.FC<LiveDigitalTwinViewProps> = ({
  twin,
  unitSystem,
  onControlChange,
  onApplyOptimal,
}) => {
  const isOilfield = unitSystem === 'OILFIELD';

  // Unit conversions
  const ropVal = isOilfield ? twin.ropResult.ropFtHr : twin.ropResult.ropMHr;
  const ropUnit = isOilfield ? 'ft/hr' : 'm/hr';

  const wobVal = isOilfield ? UnitConverter.knToKlbf(twin.controlWobKn) : twin.controlWobKn;
  const wobUnit = isOilfield ? 'klbf' : 'kN';

  const flowVal = isOilfield ? UnitConverter.lsToGpm(twin.controlFlowRateLs) : twin.controlFlowRateLs;
  const flowUnit = isOilfield ? 'GPM' : 'L/s';

  const sppVal = isOilfield ? UnitConverter.barToPsi(twin.hydraulicsResult.standpipePressureBar) : twin.hydraulicsResult.standpipePressureBar;
  const sppUnit = isOilfield ? 'psi' : 'bar';

  const torqueVal = isOilfield ? UnitConverter.nmToFtLbf(twin.torqueDragResult.surfaceTorqueKnM * 1000) : twin.torqueDragResult.surfaceTorqueKnM;
  const torqueUnit = isOilfield ? 'ft-lbf' : 'kN.m';

  const hookVal = isOilfield ? UnitConverter.nToKlbf(twin.hoisting.hookLoadKn * 1000) : twin.hoisting.hookLoadKn;
  const hookUnit = isOilfield ? 'klbf' : 'kN';

  const mudVal = isOilfield ? UnitConverter.kgM3ToPpg(twin.mudDensityKgM3) : twin.mudDensityKgM3;
  const mudUnit = isOilfield ? 'ppg' : 'kg/m³';

  // Telemetry chart data
  const chartData = twin.telemetryHistory.map(t => ({
    time: t.timestamp,
    depth: t.depthMdM,
    rop: isOilfield ? t.ropMHr * 3.28084 : t.ropMHr,
    mse: t.mseMpa,
    spp: isOilfield ? t.standpipePressureBar * 14.5038 : t.standpipePressureBar,
    torque: isOilfield ? t.surfaceTorqueKnM * 737.56 : t.surfaceTorqueKnM,
    vib: t.vibrationG,
    ecd: t.ecdSg,
  }));

  const vib = twin.vibrationTelemetry;
  const hyd = twin.hydraulicsResult;
  const cuttings = twin.cuttingsResult;
  const bit = twin.bit;

  return (
    <div className="space-y-4 font-sans text-[#e0e0e0]">
      {/* Top Operations Panel: Live Driller Controls & State Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Real-time Driller Setpoints Control Console */}
        <div className="lg:col-span-1 bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-4">
          <div className="flex items-center justify-between border-b border-[#222] pb-2.5">
            <div className="flex items-center gap-2 text-[10px] font-mono font-bold text-[#888] uppercase tracking-widest">
              <SlidersIcon className="w-3.5 h-3.5 text-[#00ff41]" />
              <span>Driller Setpoints</span>
            </div>
            <button
              onClick={onApplyOptimal}
              className="text-[9px] font-mono px-2 py-1 rounded bg-[#00ff41] text-black hover:bg-[#00cc33] transition-colors flex items-center gap-1 font-bold tracking-tight shadow-[0_0_8px_#00ff41]"
              title="Auto-apply Bayesian Multi-Objective Optimal Parameters"
            >
              <Zap className="w-3 h-3 text-black fill-black" />
              <span>OPTIMIZE</span>
            </button>
          </div>

          {/* WOB Control */}
          <div className="space-y-1.5 bg-[#111] p-2.5 rounded border border-[#222]">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-[#888] text-[10px] uppercase">WOB (Weight on Bit)</span>
              <span className="font-bold text-[#00ff41]">
                {wobVal.toFixed(1)} <span className="text-[10px] text-[#555]">{wobUnit}</span>
              </span>
            </div>
            <input
              type="range"
              min="20"
              max="180"
              step="2"
              value={twin.controlWobKn}
              onChange={e => onControlChange('wob', parseFloat(e.target.value))}
              className="w-full accent-[#00ff41] bg-[#050505] rounded h-1 cursor-pointer"
            />
            <div className="flex justify-between text-[9px] text-[#555] font-mono">
              <span>20 kN</span>
              <span>100 kN</span>
              <span>180 kN</span>
            </div>
          </div>

          {/* RPM Control */}
          <div className="space-y-1.5 bg-[#111] p-2.5 rounded border border-[#222]">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-[#888] text-[10px] uppercase">Rotary Speed (RPM)</span>
              <span className="font-bold text-white">{twin.controlRpm} <span className="text-[10px] text-[#555]">RPM</span></span>
            </div>
            <input
              type="range"
              min="40"
              max="220"
              step="5"
              value={twin.controlRpm}
              onChange={e => onControlChange('rpm', parseFloat(e.target.value))}
              className="w-full accent-[#00ff41] bg-[#050505] rounded h-1 cursor-pointer"
            />
            <div className="flex justify-between text-[9px] text-[#555] font-mono">
              <span>40 RPM</span>
              <span>130 RPM</span>
              <span>220 RPM</span>
            </div>
          </div>

          {/* Flow Rate Control */}
          <div className="space-y-1.5 bg-[#111] p-2.5 rounded border border-[#222]">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-[#888] text-[10px] uppercase">Pump Flow (Q)</span>
              <span className="font-bold text-white">
                {flowVal.toFixed(1)} <span className="text-[10px] text-[#555]">{flowUnit}</span>
              </span>
            </div>
            <input
              type="range"
              min="20"
              max="65"
              step="1"
              value={twin.controlFlowRateLs}
              onChange={e => onControlChange('flow', parseFloat(e.target.value))}
              className="w-full accent-amber-500 bg-[#050505] rounded h-1 cursor-pointer"
            />
            <div className="flex justify-between text-[9px] text-[#555] font-mono">
              <span>20 L/s</span>
              <span>42 L/s</span>
              <span>65 L/s</span>
            </div>
          </div>

          {/* Mud Density Control */}
          <div className="space-y-1.5 bg-[#111] p-2.5 rounded border border-[#222]">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-[#888] text-[10px] uppercase">Mud Density (MW)</span>
              <span className="font-bold text-purple-400">
                {mudVal.toFixed(isOilfield ? 2 : 0)} <span className="text-[10px] text-[#555]">{mudUnit}</span>
              </span>
            </div>
            <input
              type="range"
              min="1050"
              max="1600"
              step="10"
              value={twin.mudDensityKgM3}
              onChange={e => onControlChange('mudDensity', parseFloat(e.target.value))}
              className="w-full accent-purple-500 bg-[#050505] rounded h-1 cursor-pointer"
            />
            <div className="flex justify-between text-[9px] text-[#555] font-mono">
              <span>1.05 sg</span>
              <span>1.28 sg</span>
              <span>1.60 sg</span>
            </div>
          </div>

          {/* Stratigraphic Quick Info */}
          <div className="pt-2 border-t border-[#222] text-[10px] font-mono space-y-1.5 text-[#888]">
            <div className="flex justify-between">
              <span className="text-[#555] uppercase">Formation:</span>
              <span className="text-white font-bold">{twin.currentFormation.name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#555] uppercase">Lithology:</span>
              <span className="text-amber-400">{twin.currentFormation.lithology}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#555] uppercase">Rock UCS:</span>
              <span className="text-white">{twin.currentFormation.ucsMpa} MPa</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#555] uppercase">Pore / Frac:</span>
              <span className="text-white font-mono">
                {twin.currentFormation.porePressureGradSg.toFixed(2)} / {twin.currentFormation.fractureGradSg.toFixed(2)} sg
              </span>
            </div>
          </div>
        </div>

        {/* Real-time Primary Physical Telemetry Gauges (3 cols) */}
        <div className="lg:col-span-3 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {/* ROP Card */}
          <div className="bg-[#0a0a0a] rounded border border-[#222] p-4 flex flex-col justify-between relative overflow-hidden">
            <div className="flex items-center justify-between text-[#888] text-[10px] font-mono uppercase tracking-wider">
              <span>Rate of Penetration</span>
              <Activity className="w-3.5 h-3.5 text-[#00ff41]" />
            </div>
            <div className="my-2">
              <div className="text-3xl font-mono font-bold text-[#00ff41] tracking-tight">
                {ropVal.toFixed(1)}
                <span className="text-xs font-normal text-[#555] ml-1.5">{ropUnit}</span>
              </div>
              <div className="text-[9px] font-mono text-[#666] mt-0.5">
                Target: {(ropVal * 1.15).toFixed(1)} {ropUnit}
              </div>
            </div>
            <div className="w-full bg-[#111] h-1 rounded-full overflow-hidden">
              <div 
                className="bg-[#00ff41] h-full shadow-[0_0_8px_#00ff41] transition-all"
                style={{ width: `${Math.min(100, (twin.ropResult.ropMHr / 40) * 100)}%` }}
              />
            </div>
          </div>

          {/* Mechanical Specific Energy (MSE) Card */}
          <div className="bg-[#0a0a0a] rounded border border-[#222] p-4 flex flex-col justify-between">
            <div className="flex items-center justify-between text-[#888] text-[10px] font-mono uppercase tracking-wider">
              <span>Mech Spec Energy</span>
              <TrendingUp className="w-3.5 h-3.5 text-blue-400" />
            </div>
            <div className="my-2">
              <div className="text-3xl font-mono font-bold text-white tracking-tight">
                {twin.ropResult.mseMpa.toFixed(0)}
                <span className="text-xs font-normal text-[#555] ml-1.5">MPa</span>
              </div>
              <div className="text-[9px] font-mono text-[#666] mt-0.5">
                Efficiency: {twin.ropResult.drillingEfficiencyPercent.toFixed(0)}% (Teale)
              </div>
            </div>
            <div className="w-full bg-[#111] h-1 rounded-full overflow-hidden">
              <div 
                className={`h-full transition-all ${
                  twin.ropResult.mseMpa > 400 ? 'bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.5)]' : 'bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.5)]'
                }`}
                style={{ width: `${Math.min(100, (twin.ropResult.mseMpa / 600) * 100)}%` }}
              />
            </div>
          </div>

          {/* Standpipe Pressure (SPP) */}
          <div className="bg-[#0a0a0a] rounded border border-[#222] p-4 flex flex-col justify-between">
            <div className="flex items-center justify-between text-[#888] text-[10px] font-mono uppercase tracking-wider">
              <span>Standpipe Pressure</span>
              <Gauge className="w-3.5 h-3.5 text-amber-400" />
            </div>
            <div className="my-2">
              <div className="text-3xl font-mono font-bold text-white tracking-tight">
                {sppVal.toFixed(1)}
                <span className="text-xs font-normal text-[#555] ml-1.5">{sppUnit}</span>
              </div>
              <div className="text-[9px] font-mono text-[#666] mt-0.5">
                Limit: {isOilfield ? (twin.rig.mudPumpsMaxPressureBar * 14.5038).toFixed(0) : twin.rig.mudPumpsMaxPressureBar} {sppUnit}
              </div>
            </div>
            <div className="w-full bg-[#111] h-1 rounded-full overflow-hidden">
              <div 
                className="bg-amber-500 h-full shadow-[0_0_8px_rgba(245,158,11,0.5)] transition-all"
                style={{ width: `${Math.min(100, (hyd.standpipePressureBar / twin.rig.mudPumpsMaxPressureBar) * 100)}%` }}
              />
            </div>
          </div>

          {/* ECD vs Pore Pressure Window */}
          <div className="bg-[#0a0a0a] rounded border border-[#222] p-4 flex flex-col justify-between">
            <div className="flex items-center justify-between text-[#888] text-[10px] font-mono uppercase tracking-wider">
              <span>Equiv Circ Density</span>
              <ShieldAlert className="w-3.5 h-3.5 text-purple-400" />
            </div>
            <div className="my-2">
              <div className="text-3xl font-mono font-bold text-purple-400 tracking-tight">
                {hyd.ecdSg.toFixed(2)}
                <span className="text-xs font-normal text-[#555] ml-1.5">sg</span>
              </div>
              <div className="text-[9px] font-mono text-[#666] mt-0.5">
                Window: {twin.currentFormation.porePressureGradSg.toFixed(2)} - {twin.currentFormation.fractureGradSg.toFixed(2)}
              </div>
            </div>
            <div className="w-full bg-[#111] h-1 rounded-full overflow-hidden">
              <div 
                className="bg-purple-500 h-full shadow-[0_0_8px_rgba(168,85,247,0.5)] transition-all"
                style={{ width: `${Math.min(100, ((hyd.ecdSg - 1.0) / 0.8) * 100)}%` }}
              />
            </div>
          </div>

          {/* Surface Torque */}
          <div className="bg-[#0a0a0a] rounded border border-[#222] p-4 flex flex-col justify-between">
            <div className="flex items-center justify-between text-[#888] text-[10px] font-mono uppercase tracking-wider">
              <span>Surface Torque</span>
              <Zap className="w-3.5 h-3.5 text-orange-500" />
            </div>
            <div className="my-2">
              <div className="text-3xl font-mono font-bold text-white tracking-tight">
                {torqueVal.toFixed(1)}
                <span className="text-xs font-normal text-[#555] ml-1.5">{torqueUnit}</span>
              </div>
              <div className="text-[9px] font-mono text-[#666] mt-0.5">
                Bit Torque: {(twin.ropResult.torqueKnM * (isOilfield ? 737.56 : 1)).toFixed(1)} {torqueUnit}
              </div>
            </div>
            <div className="w-full bg-[#111] h-1 rounded-full overflow-hidden">
              <div 
                className="bg-orange-500 h-full shadow-[0_0_8px_rgba(249,115,22,0.4)] transition-all"
                style={{ width: `${Math.min(100, (twin.torqueDragResult.surfaceTorqueKnM / 18.0) * 100)}%` }}
              />
            </div>
          </div>

          {/* Surface Hook Load */}
          <div className="bg-[#0a0a0a] rounded border border-[#222] p-4 flex flex-col justify-between">
            <div className="flex items-center justify-between text-[#888] text-[10px] font-mono uppercase tracking-wider">
              <span>Surface Hook Load</span>
              <Compass className="w-3.5 h-3.5 text-cyan-400" />
            </div>
            <div className="my-2">
              <div className="text-3xl font-mono font-bold text-white tracking-tight">
                {hookVal.toFixed(0)}
                <span className="text-xs font-normal text-[#555] ml-1.5">{hookUnit}</span>
              </div>
              <div className="text-[9px] font-mono text-[#666] mt-0.5">
                Margin: {twin.hoisting.loadMarginPercent.toFixed(0)}% safe
              </div>
            </div>
            <div className="w-full bg-[#111] h-1 rounded-full overflow-hidden">
              <div 
                className="bg-cyan-500 h-full shadow-[0_0_8px_rgba(6,182,212,0.4)] transition-all"
                style={{ width: `${Math.min(100, (twin.hoisting.hookLoadKn / twin.rig.hookLoadLimitKn) * 100)}%` }}
              />
            </div>
          </div>

          {/* Vibration / Stick-Slip Monitor */}
          <div className="bg-[#0a0a0a] rounded border border-[#222] p-4 flex flex-col justify-between">
            <div className="flex items-center justify-between text-[#888] text-[10px] font-mono uppercase tracking-wider">
              <span>Stick-Slip Severity</span>
              {vib.isStickSlipActive ? (
                <AlertTriangle className="w-3.5 h-3.5 text-red-500 animate-pulse" />
              ) : (
                <CheckCircle2 className="w-3.5 h-3.5 text-[#00ff41]" />
              )}
            </div>
            <div className="my-2">
              <div className={`text-3xl font-mono font-bold tracking-tight ${
                vib.isStickSlipActive ? 'text-red-500' : 'text-[#00ff41]'
              }`}>
                {vib.torsionalVibrationPercent.toFixed(0)}%
              </div>
              <div className="text-[9px] font-mono text-[#666] mt-0.5">
                Bit RPM: {vib.bitRpmInstantaneous.toFixed(0)} (Inst)
              </div>
            </div>
            <div className="w-full bg-[#111] h-1 rounded-full overflow-hidden">
              <div 
                className={`h-full transition-all ${
                  vib.isStickSlipActive ? 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.5)]' : 'bg-[#00ff41] shadow-[0_0_8px_#00ff41]'
                }`}
                style={{ width: `${Math.min(100, vib.torsionalVibrationPercent)}%` }}
              />
            </div>
          </div>

          {/* Bit Wear Dull Grade */}
          <div className="bg-[#0a0a0a] rounded border border-[#222] p-4 flex flex-col justify-between">
            <div className="flex items-center justify-between text-[#888] text-[10px] font-mono uppercase tracking-wider">
              <span>Bit Dull Grade</span>
              <Layers className="w-3.5 h-3.5 text-[#888]" />
            </div>
            <div className="my-2">
              <div className="text-3xl font-mono font-bold text-white tracking-tight">
                {bit.dullGrade.toFixed(2)}
                <span className="text-xs font-normal text-[#555] ml-1.5">/ 8.0</span>
              </div>
              <div className="text-[9px] font-mono text-[#666] mt-0.5">
                Drilled: {bit.cumulativeMetersDrilled.toFixed(0)} m ({bit.operatingHours.toFixed(1)}h)
              </div>
            </div>
            <div className="w-full bg-[#111] h-1 rounded-full overflow-hidden">
              <div 
                className={`h-full transition-all ${
                  bit.dullGrade > 6.0 ? 'bg-red-500' : bit.dullGrade > 4.0 ? 'bg-amber-500' : 'bg-[#00ff41]'
                }`}
                style={{ width: `${Math.min(100, (bit.dullGrade / 8.0) * 100)}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Stratigraphic Wellbore Schematic + Real-time Telemetry Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* 2D Stratigraphic Wellbore Profile */}
        <div className="lg:col-span-1 bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-[#222] pb-2">
            <div className="flex items-center gap-2 text-[10px] font-mono font-bold text-[#888] uppercase tracking-widest">
              <Layers className="w-3.5 h-3.5 text-[#00ff41]" />
              <span>Wellbore Stratigraphy</span>
            </div>
            <span className="text-[9px] font-mono text-[#666]">
              Shoe: {twin.casingShoeDepthM}m
            </span>
          </div>

          <div className="relative h-80 bg-[#050505] rounded border border-[#222] p-2 overflow-y-auto no-scrollbar font-mono text-xs">
            {/* Render Formation Columns */}
            <div className="space-y-1.5">
              {twin.formations.map((form) => {
                const isCurrent = twin.currentFormation.id === form.id;
                const topDepth = form.topDepthMd;
                const baseDepth = form.baseDepthMd;
                const thickness = baseDepth - topDepth;

                return (
                  <div
                    key={form.id}
                    className={`p-2.5 rounded border transition-all ${
                      isCurrent
                        ? 'bg-[#111] border-[#00ff41] shadow-[0_0_10px_rgba(0,255,65,0.15)] ring-1 ring-[#00ff41]/50'
                        : 'bg-[#0a0a0a] border-[#222] opacity-80'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[11px]">
                      <div className="flex items-center gap-2">
                        <span 
                          className="w-2 h-2 rounded-full"
                          style={{ backgroundColor: form.colorHex }}
                        />
                        <span className="font-bold text-white">{form.name}</span>
                        {isCurrent && (
                          <span className="text-[8px] px-1.5 py-0.2 rounded bg-[#00ff41]/20 text-[#00ff41] font-mono font-bold border border-[#00ff41]/40">
                            ON-BOTTOM
                          </span>
                        )}
                      </div>
                      <span className="text-[#666] text-[10px]">
                        {topDepth}m - {baseDepth}m ({thickness}m)
                      </span>
                    </div>

                    <div className="mt-1 flex items-center justify-between text-[10px] text-[#888]">
                      <span>Lithology: <strong className="text-white font-normal">{form.lithology}</strong></span>
                      <span>UCS: <strong className="text-white font-normal">{form.ucsMpa} MPa</strong></span>
                      <span>CAI: <strong className="text-white font-normal">{form.caiAbrasiveness}</strong></span>
                    </div>

                    {isCurrent && (
                      <div className="mt-2 pt-1.5 border-t border-[#333] flex items-center justify-between text-[10px] text-[#00ff41]">
                        <span>Bit Depth: <strong>{twin.currentDepthMdM.toFixed(1)} m</strong></span>
                        <span>Inc: <strong>32.3°</strong></span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Cuttings & Annular Cleaning Box */}
          <div className="p-3 bg-[#111] rounded border border-[#222] text-xs font-mono space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-[#888] text-[10px] uppercase">Well Cleaning Index:</span>
              <span className={`font-bold text-xs ${
                cuttings.wellCleaningIndexScore > 75 ? 'text-[#00ff41]' : 'text-amber-400'
              }`}>
                {cuttings.wellCleaningIndexScore.toFixed(0)} / 100 ({cuttings.cleaningStatus})
              </span>
            </div>
            <div className="flex items-between justify-between text-[10px] text-[#888]">
              <span>Annular Velocity: <strong className="text-white">{cuttings.annularVelocityMs.toFixed(2)} m/s</strong></span>
              <span>Transport Ratio: <strong className="text-white">{cuttings.transportRatioPercent.toFixed(0)}%</strong></span>
            </div>
            <div className="w-full bg-[#050505] h-1 rounded-full overflow-hidden">
              <div 
                className="bg-[#00ff41] h-full shadow-[0_0_6px_#00ff41]"
                style={{ width: `${cuttings.wellCleaningIndexScore}%` }}
              />
            </div>
          </div>
        </div>

        {/* Real-time Multi-Channel Telemetry Chart (2 cols) */}
        <div className="lg:col-span-2 bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3 relative overflow-hidden">
          <div className="absolute inset-0 opacity-10 pointer-events-none bg-grid-dots"></div>
          <div className="flex items-center justify-between border-b border-[#222] pb-2 relative z-10">
            <div className="flex items-center gap-2 text-[10px] font-mono font-bold text-[#888] uppercase tracking-widest">
              <Activity className="w-3.5 h-3.5 text-[#00ff41]" />
              <span>Real-Time Telemetry Matrix</span>
            </div>
            <div className="flex items-center gap-3 text-[10px] font-mono text-[#666]">
              <span className="px-2 py-0.5 bg-[#111] rounded border border-[#333] text-[9px] text-[#888]">
                FIDELITY_3 (CALIBRATED)
              </span>
              <span>Rate: 1 Hz</span>
            </div>
          </div>

          {/* Recharts Multi-line telemetry chart */}
          <div className="h-80 w-full relative z-10">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                <XAxis dataKey="time" stroke="#555555" tick={{ fontSize: 9, fill: '#666666' }} />
                <YAxis stroke="#555555" tick={{ fontSize: 9, fill: '#666666' }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0a0a0a', borderColor: '#333333', fontSize: '11px', fontFamily: 'monospace', color: '#e0e0e0' }}
                />
                <Legend wrapperStyle={{ fontSize: '10px', fontFamily: 'monospace', paddingTop: '8px' }} />
                <Line 
                  type="monotone" 
                  dataKey="rop" 
                  name={`ROP (${ropUnit})`} 
                  stroke="#00ff41" 
                  strokeWidth={2} 
                  dot={false} 
                  isAnimationActive={false}
                />
                <Line 
                  type="monotone" 
                  dataKey="torque" 
                  name={`Torque (${torqueUnit})`} 
                  stroke="#f97316" 
                  strokeWidth={1.5} 
                  dot={false} 
                  isAnimationActive={false}
                />
                <Line 
                  type="monotone" 
                  dataKey="spp" 
                  name={`SPP (${sppUnit})`} 
                  stroke="#eab308" 
                  strokeWidth={1.5} 
                  dot={false} 
                  isAnimationActive={false}
                />
                <Line 
                  type="monotone" 
                  dataKey="mse" 
                  name="MSE (MPa)" 
                  stroke="#38bdf8" 
                  strokeWidth={1.5} 
                  dot={false} 
                  isAnimationActive={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Bottom Live Telemetry Quality Strip */}
          <div className="grid grid-cols-3 gap-2 pt-2 border-t border-[#222] text-[10px] font-mono text-[#888] relative z-10">
            <div className="p-2 rounded bg-[#111] border border-[#222] flex items-center justify-between">
              <span className="text-[#666]">MWD Gamma Ray:</span>
              <span className="font-bold text-white">
                {twin.telemetryHistory[twin.telemetryHistory.length - 1]?.gammaRayApi.toFixed(1)} API
              </span>
            </div>
            <div className="p-2 rounded bg-[#111] border border-[#222] flex items-center justify-between">
              <span className="text-[#666]">LWD Resistivity:</span>
              <span className="font-bold text-white">
                {twin.telemetryHistory[twin.telemetryHistory.length - 1]?.deepResistivityOhmm.toFixed(1)} Ω·m
              </span>
            </div>
            <div className="p-2 rounded bg-[#111] border border-[#222] flex items-center justify-between">
              <span className="text-[#666]">Sensor Integrity:</span>
              <span className="font-bold text-[#00ff41]">VALID (100%)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

function SlidersIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="4" x2="4" y1="21" y2="14" /><line x1="4" x2="4" y1="10" y2="3" /><line x1="12" x2="12" y1="21" y2="12" /><line x1="12" x2="12" y1="8" y2="3" /><line x1="20" x2="20" y1="21" y2="16" /><line x1="20" x2="20" y1="12" y2="3" /><line x1="2" x2="6" y1="14" y2="14" /><line x1="10" x2="14" y1="8" y2="8" /><line x1="18" x2="22" y1="16" y2="16" />
    </svg>
  );
}
