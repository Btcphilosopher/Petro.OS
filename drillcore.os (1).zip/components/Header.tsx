'use client';

import React from 'react';
import { 
  Play, 
  Pause, 
  FastForward, 
  RotateCcw, 
  Activity, 
  Gauge, 
  Cpu, 
  Layers, 
  Flame, 
  ShieldCheck, 
  Terminal,
  FileText,
  Sliders,
  Compass,
  Zap
} from 'lucide-react';
import { DigitalTwinState, DrillingRegime } from '../lib/twin/drillingTwin';
import { UnitSystem } from '../lib/physics/units';

interface HeaderProps {
  twin: DigitalTwinState;
  unitSystem: UnitSystem;
  setUnitSystem: (u: UnitSystem) => void;
  activeTab: string;
  setActiveTab: (t: string) => void;
  onTogglePlay: () => void;
  onStep: () => void;
  onReset: () => void;
  onSpeedChange: (speed: number) => void;
}

export const Header: React.FC<HeaderProps> = ({
  twin,
  unitSystem,
  setUnitSystem,
  activeTab,
  setActiveTab,
  onTogglePlay,
  onStep,
  onReset,
  onSpeedChange,
}) => {
  const isOilfield = unitSystem === 'OILFIELD';

  const depthDisplay = isOilfield 
    ? `${(twin.currentDepthMdM * 3.28084).toFixed(0)} ft` 
    : `${twin.currentDepthMdM.toFixed(1)} m`;

  const tvdDisplay = isOilfield 
    ? `${(twin.currentTvdM * 3.28084).toFixed(0)} ft` 
    : `${twin.currentTvdM.toFixed(1)} m`;

  const targetDisplay = isOilfield 
    ? `${(twin.plannedDepthM * 3.28084).toFixed(0)} ft` 
    : `${twin.plannedDepthM.toFixed(0)} m`;

  const navTabs = [
    { id: 'live-twin', label: 'Live Digital Twin', icon: Activity },
    { id: 'physics-suite', label: 'Physics & Mechanics', icon: Compass },
    { id: 'r-quant-ml', label: 'R Quant & ML', icon: Cpu },
    { id: 'scenario-lab', label: 'Scenario Lab', icon: Sliders },
    { id: 'twin-replay', label: 'Twin Replay', icon: RotateCcw },
    { id: 'drilling-advisor', label: 'Drilling Advisor', icon: ShieldCheck },
    { id: 'cli-terminal', label: 'DRILL CLI', icon: Terminal },
    { id: 'engineering-report', label: 'Audit & Report', icon: FileText },
  ];

  return (
    <header className="bg-[#0a0a0a] border-b border-[#222] text-[#e0e0e0] select-none sticky top-0 z-50">
      {/* Top Identity & Operations Telemetry Bar */}
      <div className="px-5 py-2.5 flex flex-wrap items-center justify-between gap-4 border-b border-[#222] bg-[#0a0a0a]">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-3">
            <div className="text-[#00ff41] font-mono text-xl tracking-tighter font-bold flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-[#00ff41] shadow-[0_0_8px_#00ff41] inline-block"></span>
              <span>DRILLCORE.OS</span>
            </div>
            <div className="h-4 w-px bg-[#333]"></div>
            <div className="text-[10px] text-[#888] font-mono">
              SYSTEM: <span className="text-[#00ff41]">RUST CORE</span> / <span className="text-purple-400">R-QUANT 4.2.1</span>
            </div>
          </div>
          <div className="hidden sm:flex items-center gap-1.5">
            <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-[#111] text-[#888] border border-[#333]">
              FIDELITY_3 (CALIBRATED)
            </span>
          </div>
        </div>

        {/* Live Depth & Operational Status */}
        <div className="flex flex-wrap items-center gap-3 text-xs font-mono">
          <div className="flex items-center space-x-2 bg-[#111] px-3 py-1.5 rounded border border-[#222]">
            <span className="w-2 h-2 rounded-full bg-[#00ff41] shadow-[0_0_8px_#00ff41]"></span>
            <span className="text-[#888] text-[10px]">STATE:</span>
            <span className="text-white text-[11px] font-bold">{twin.regime}</span>
          </div>

          <div className="bg-[#111] px-3 py-1.5 rounded border border-[#222] flex items-center gap-3">
            <div>
              <span className="text-[#666] text-[9px] uppercase block leading-tight">MD DEPTH</span>
              <span className="font-bold text-[#00ff41] text-xs">{depthDisplay}</span>
            </div>
            <div className="h-5 w-px bg-[#222]" />
            <div>
              <span className="text-[#666] text-[9px] uppercase block leading-tight">TVD</span>
              <span className="font-semibold text-white text-xs">{tvdDisplay}</span>
            </div>
            <div className="h-5 w-px bg-[#222]" />
            <div>
              <span className="text-[#666] text-[9px] uppercase block leading-tight">WELL</span>
              <span className="text-white text-xs">{twin.wellName}</span>
            </div>
          </div>

          {/* Unit System Toggle */}
          <div className="flex items-center bg-[#111] p-0.5 rounded border border-[#222]">
            <button
              onClick={() => setUnitSystem('SI')}
              className={`px-2 py-1 rounded text-[10px] font-bold tracking-tight transition-colors ${
                unitSystem === 'SI' 
                  ? 'bg-[#222] text-[#00ff41] border border-[#333]' 
                  : 'text-[#666] hover:text-[#aaa]'
              }`}
            >
              SI (m, bar)
            </button>
            <button
              onClick={() => setUnitSystem('OILFIELD')}
              className={`px-2 py-1 rounded text-[10px] font-bold tracking-tight transition-colors ${
                unitSystem === 'OILFIELD' 
                  ? 'bg-[#222] text-[#00ff41] border border-[#333]' 
                  : 'text-[#666] hover:text-[#aaa]'
              }`}
            >
              OILFIELD (ft, psi)
            </button>
          </div>

          {/* Simulation Controls */}
          <div className="flex items-center gap-1 bg-[#111] p-1 rounded border border-[#222]">
            <button
              onClick={onTogglePlay}
              className={`flex items-center gap-1 px-3 py-1 rounded text-[10px] font-mono font-bold tracking-tighter transition-all ${
                twin.isSimulating
                  ? 'bg-amber-500 hover:bg-amber-400 text-black shadow-[0_0_8px_rgba(245,158,11,0.4)]'
                  : 'bg-[#00ff41] hover:bg-[#00cc33] text-black shadow-[0_0_8px_#00ff41]'
              }`}
              title={twin.isSimulating ? 'Pause physics simulation' : 'Start real-time digital twin physics'}
            >
              {twin.isSimulating ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
              <span>{twin.isSimulating ? 'PAUSE' : 'SIMULATE'}</span>
            </button>

            <button
              onClick={onStep}
              disabled={twin.isSimulating}
              className="p-1.5 rounded text-[#aaa] hover:text-white hover:bg-[#222] disabled:opacity-30 disabled:cursor-not-allowed"
              title="Single step physical discrete update"
            >
              <Zap className="w-3 h-3" />
            </button>

            {/* Speed Multiplier */}
            <div className="flex items-center text-[10px] text-[#666] font-mono ml-1">
              {[1, 5, 20, 100].map(s => (
                <button
                  key={s}
                  onClick={() => onSpeedChange(s)}
                  className={`px-1.5 py-0.5 rounded transition-colors ${
                    twin.simulationSpeed === s
                      ? 'bg-[#222] text-[#00ff41] font-bold border border-[#333]'
                      : 'hover:text-[#aaa]'
                  }`}
                >
                  {s}x
                </button>
              ))}
            </div>

            <button
              onClick={onReset}
              className="p-1.5 rounded text-[#666] hover:text-rose-400 hover:bg-[#222] ml-1"
              title="Reset well state to baseline"
            >
              <RotateCcw className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="px-5 flex items-center gap-1 overflow-x-auto no-scrollbar bg-[#080808]">
        {navTabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-mono font-medium border-b-2 transition-all whitespace-nowrap ${
                isActive
                  ? 'border-[#00ff41] text-[#00ff41] bg-[#111]/80'
                  : 'border-transparent text-[#666] hover:text-[#bbb] hover:bg-[#0f0f0f]'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#00ff41]' : 'text-[#666]'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
