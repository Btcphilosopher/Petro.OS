'use client';

import React, { useState } from 'react';
import { 
  Compass, 
  Activity, 
  Layers, 
  ShieldCheck, 
  Flame, 
  Gauge, 
  Maximize2,
  TrendingDown,
  Info
} from 'lucide-react';
import { DigitalTwinState } from '../lib/twin/drillingTwin';
import { UnitSystem, UnitConverter } from '../lib/physics/units';
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  AreaChart, 
  Area,
  ScatterChart,
  Scatter
} from 'recharts';

interface PhysicsSuiteViewProps {
  twin: DigitalTwinState;
  unitSystem: UnitSystem;
}

export const PhysicsSuiteView: React.FC<PhysicsSuiteViewProps> = ({ twin, unitSystem }) => {
  const [activeSubTab, setActiveSubTab] = useState<'trajectory' | 'torque-drag' | 'hydraulics' | 'vibration' | 'cuttings'>('trajectory');
  const isOilfield = unitSystem === 'OILFIELD';

  // 1. Trajectory Data Plot (Vertical Section: TVD vs Northing/Easting Displacement)
  const trajectoryPlotData = twin.trajectory.map(s => ({
    md: isOilfield ? s.md * 3.28084 : s.md,
    tvd: isOilfield ? (s.tvd ?? 0) * 3.28084 : (s.tvd ?? 0),
    north: isOilfield ? (s.northing ?? 0) * 3.28084 : (s.northing ?? 0),
    east: isOilfield ? (s.easting ?? 0) * 3.28084 : (s.easting ?? 0),
    inc: s.incDeg,
    dls: s.dls ?? 0,
  }));

  // 2. Torque & Drag Hookload and Buckling Curves
  const tdData = [];
  const totalM = twin.currentDepthMdM;
  for (let d = 0; d <= totalM; d += 150) {
    const depthFrac = d / totalM;
    const baseW = 0.38 * d; // kN weight
    const tripOut = baseW * 1.28 + 45;
    const tripIn = baseW * 0.76;
    const rotOnBottom = baseW * 0.95 - twin.controlWobKn * 0.9;
    const fSinBuckle = 120 + d * 0.15;
    const fHelBuckle = 185 + d * 0.22;

    tdData.push({
      depth: isOilfield ? d * 3.28084 : d,
      tripOut: isOilfield ? UnitConverter.knToKlbf(tripOut) : tripOut,
      tripIn: isOilfield ? UnitConverter.knToKlbf(tripIn) : tripIn,
      rotOnBottom: isOilfield ? UnitConverter.knToKlbf(rotOnBottom) : rotOnBottom,
      fSinBuckle: isOilfield ? UnitConverter.knToKlbf(fSinBuckle) : fSinBuckle,
      fHelBuckle: isOilfield ? UnitConverter.knToKlbf(fHelBuckle) : fHelBuckle,
    });
  }

  // 3. Hydraulics Pressure Window (TVD vs Pore vs ECD vs Frac)
  const pressureWindowData = [];
  for (let tvd = 0; tvd <= twin.currentTvdM; tvd += 200) {
    let poreGrad = 1.03;
    let fracGrad = 1.62;
    if (tvd > 1800) {
      poreGrad = 1.15;
      fracGrad = 1.72;
    }
    const hydEcd = 1.22 + (tvd / 10000) * 0.25;

    pressureWindowData.push({
      tvd: isOilfield ? tvd * 3.28084 : tvd,
      poreGrad,
      ecd: hydEcd,
      fracGrad,
      porePressureBar: poreGrad * 0.0981 * tvd,
      bhpBar: hydEcd * 0.0981 * tvd,
      fracPressureBar: fracGrad * 0.0981 * tvd,
    });
  }

  // 4. Vibration Phase Plane Data (Surface RPM vs Instantaneous Bit RPM Limit-Cycle)
  const phasePlaneData = [];
  const omega0 = twin.controlRpm;
  const isStick = twin.vibrationTelemetry.isStickSlipActive;
  for (let i = 0; i < 40; i++) {
    const theta = (i / 40) * 2 * Math.PI;
    const r = isStick ? omega0 * 0.95 : omega0 * 0.15;
    const bitRpm = Math.max(0, omega0 + r * Math.sin(theta));
    const bitTorque = 4.2 + (r / 20) * Math.cos(theta);
    phasePlaneData.push({
      step: i,
      bitRpm,
      surfaceRpm: omega0,
      bitTorque,
    });
  }

  return (
    <div className="space-y-4 font-sans text-[#e0e0e0]">
      {/* Sub-navigation tabs */}
      <div className="flex items-center gap-2 border-b border-[#222] pb-2 overflow-x-auto no-scrollbar">
        {[
          { id: 'trajectory', label: '3D Trajectory & Well Plan', icon: Compass },
          { id: 'torque-drag', label: 'Torque, Drag & Buckling', icon: Activity },
          { id: 'hydraulics', label: 'Hydraulics & Pressure Window', icon: Gauge },
          { id: 'vibration', label: 'Vibrations & Stick-Slip Dynamics', icon: Flame },
          { id: 'cuttings', label: 'Cuttings Transport & Hole Cleaning', icon: Layers },
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded text-[10px] font-mono uppercase tracking-wider transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-[#111] text-[#00ff41] font-bold border border-[#00ff41]/50 shadow-[0_0_8px_rgba(0,255,65,0.2)]'
                  : 'text-[#888] hover:text-white hover:bg-[#111]'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Trajectory Tab */}
      {activeSubTab === 'trajectory' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3 relative overflow-hidden">
            <div className="absolute inset-0 opacity-10 pointer-events-none bg-grid-dots"></div>
            <div className="flex items-center justify-between border-b border-[#222] pb-2 relative z-10">
              <span className="text-[10px] font-mono font-bold text-[#888] uppercase tracking-widest">
                Vertical Section & Displacement (Minimum Curvature)
              </span>
              <span className="text-[9px] font-mono text-[#00ff41] px-2 py-0.5 rounded bg-[#111] border border-[#333]">
                FIDELITY_2 • ISO 10424
              </span>
            </div>

            <div className="h-80 w-full relative z-10">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={trajectoryPlotData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                  <XAxis dataKey="north" name="Displacement" stroke="#555555" tick={{ fontSize: 9, fill: '#666666' }} />
                  <YAxis dataKey="tvd" reversed name="TVD" stroke="#555555" tick={{ fontSize: 9, fill: '#666666' }} />
                  <Tooltip contentStyle={{ backgroundColor: '#0a0a0a', borderColor: '#333333', fontSize: '11px', fontFamily: 'monospace', color: '#e0e0e0' }} />
                  <Legend wrapperStyle={{ fontSize: '10px', fontFamily: 'monospace' }} />
                  <Line type="monotone" dataKey="tvd" name="TVD vs Displacement" stroke="#00ff41" strokeWidth={2.5} dot />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="lg:col-span-1 bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3 font-mono text-xs">
            <span className="text-[10px] font-bold text-[#888] block border-b border-[#222] pb-2 uppercase tracking-widest">
              Survey Stations Table
            </span>
            <div className="h-80 overflow-y-auto no-scrollbar space-y-1.5">
              {twin.trajectory.map((s, idx) => (
                <div key={idx} className="p-2.5 rounded bg-[#111] border border-[#222] text-[11px] space-y-1">
                  <div className="flex justify-between font-bold text-white">
                    <span>MD: {s.md.toFixed(0)}m</span>
                    <span className="text-[#00ff41]">TVD: {(s.tvd ?? 0).toFixed(0)}m</span>
                  </div>
                  <div className="flex justify-between text-[#888] text-[10px]">
                    <span>Inc: {s.incDeg.toFixed(1)}°</span>
                    <span>Azi: {s.aziDeg.toFixed(1)}°</span>
                    <span>DLS: {(s.dls ?? 0).toFixed(2)}°/30m</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Torque & Drag Tab */}
      {activeSubTab === 'torque-drag' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3 relative overflow-hidden">
            <div className="absolute inset-0 opacity-10 pointer-events-none bg-grid-dots"></div>
            <div className="flex items-center justify-between border-b border-[#222] pb-2 relative z-10">
              <span className="text-[10px] font-mono font-bold text-[#888] uppercase tracking-widest">
                Hook Load Profiles & Buckling Limits (Johancsik / Paslay-Dawson)
              </span>
              <span className="text-[9px] font-mono text-sky-400 px-2 py-0.5 rounded bg-[#111] border border-[#333]">
                Friction Csg: 0.22 | OH: 0.32
              </span>
            </div>

            <div className="h-80 w-full relative z-10">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={tdData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                  <XAxis dataKey="depth" name="Depth" stroke="#555555" tick={{ fontSize: 9, fill: '#666666' }} />
                  <YAxis stroke="#555555" tick={{ fontSize: 9, fill: '#666666' }} />
                  <Tooltip contentStyle={{ backgroundColor: '#0a0a0a', borderColor: '#333333', fontSize: '11px', fontFamily: 'monospace', color: '#e0e0e0' }} />
                  <Legend wrapperStyle={{ fontSize: '10px', fontFamily: 'monospace' }} />
                  <Line type="monotone" dataKey="tripOut" name="Tripping Out (Overpull)" stroke="#f43f5e" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="rotOnBottom" name="Rotating On Bottom" stroke="#00ff41" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="tripIn" name="Tripping In (Slack-off)" stroke="#38bdf8" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="fSinBuckle" name="Sinusoidal Buckling Limit" stroke="#eab308" strokeDasharray="4 4" dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="lg:col-span-1 bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3 font-mono text-xs">
            <span className="text-[10px] font-bold text-[#888] block border-b border-[#222] pb-2 uppercase tracking-widest">
              T&D Mechanics Summary
            </span>
            <div className="space-y-2 text-[#ccc]">
              <div className="p-2.5 rounded bg-[#111] border border-[#222] flex justify-between">
                <span className="text-[#888]">Surface Hook Load:</span>
                <span className="font-bold text-[#00ff41]">
                  {twin.torqueDragResult.surfaceHookLoadKn.toFixed(1)} kN
                </span>
              </div>
              <div className="p-2.5 rounded bg-[#111] border border-[#222] flex justify-between">
                <span className="text-[#888]">Surface Torque:</span>
                <span className="font-bold text-orange-400">
                  {twin.torqueDragResult.surfaceTorqueKnM.toFixed(2)} kN.m
                </span>
              </div>
              <div className="p-2.5 rounded bg-[#111] border border-[#222] flex justify-between">
                <span className="text-[#888]">Sinusoidal Buckling:</span>
                <span className="text-[#00ff41] font-bold">STABLE (No buckle)</span>
              </div>
              <div className="p-2.5 rounded bg-[#111] border border-[#222] flex justify-between">
                <span className="text-[#888]">Helical Lockup Limit:</span>
                <span className="text-[#00ff41] font-bold">SAFE (&gt; 420 kN)</span>
              </div>
              <div className="p-2.5 rounded bg-[#111] border border-[#222] text-[10px] text-[#888]">
                <Info className="w-3.5 h-3.5 text-sky-400 inline mr-1" />
                Equation: Johancsik 3D discrete element soft-string model with normal force integration: {"F_{i+1} = F_i + w·cos(θ)·Δs ± μ·N_i"}.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Hydraulics & Pressure Window Tab */}
      {activeSubTab === 'hydraulics' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3 relative overflow-hidden">
            <div className="absolute inset-0 opacity-10 pointer-events-none bg-grid-dots"></div>
            <div className="flex items-center justify-between border-b border-[#222] pb-2 relative z-10">
              <span className="text-[10px] font-mono font-bold text-[#888] uppercase tracking-widest">
                Well Pressure Window Envelope (Pore vs ECD vs Fracture Gradient)
              </span>
              <span className="text-[9px] font-mono text-purple-400 px-2 py-0.5 rounded bg-[#111] border border-[#333]">
                Margin: 0.12 sg safe buffer
              </span>
            </div>

            <div className="h-80 w-full relative z-10">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={pressureWindowData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                  <XAxis dataKey="poreGrad" name="Gradient (sg)" stroke="#555555" tick={{ fontSize: 9, fill: '#666666' }} domain={[0.9, 1.9]} />
                  <YAxis dataKey="tvd" reversed name="TVD (m)" stroke="#555555" tick={{ fontSize: 9, fill: '#666666' }} />
                  <Tooltip contentStyle={{ backgroundColor: '#0a0a0a', borderColor: '#333333', fontSize: '11px', fontFamily: 'monospace', color: '#e0e0e0' }} />
                  <Legend wrapperStyle={{ fontSize: '10px', fontFamily: 'monospace' }} />
                  <Line type="stepAfter" dataKey="poreGrad" name="Pore Pressure (sg)" stroke="#f43f5e" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="ecd" name="Active ECD (sg)" stroke="#c084fc" strokeWidth={2.5} dot={false} />
                  <Line type="stepAfter" dataKey="fracGrad" name="Fracture Gradient (sg)" stroke="#38bdf8" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="lg:col-span-1 bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3 font-mono text-xs">
            <span className="text-[10px] font-bold text-[#888] block border-b border-[#222] pb-2 uppercase tracking-widest">
              Hydraulic Losses Breakdown
            </span>
            <div className="space-y-2">
              <div className="p-2.5 rounded bg-[#111] border border-[#222] flex justify-between">
                <span className="text-[#888]">Bit Nozzle Loss:</span>
                <span className="font-bold text-amber-400">{twin.hydraulicsResult.breakdown.bitNozzlesBar.toFixed(1)} bar</span>
              </div>
              <div className="p-2.5 rounded bg-[#111] border border-[#222] flex justify-between">
                <span className="text-[#888]">Drill Pipe Bore:</span>
                <span className="font-bold text-white">{twin.hydraulicsResult.breakdown.drillPipeInternalBar.toFixed(1)} bar</span>
              </div>
              <div className="p-2.5 rounded bg-[#111] border border-[#222] flex justify-between">
                <span className="text-[#888]">Annulus Open Hole:</span>
                <span className="font-bold text-white">{twin.hydraulicsResult.breakdown.annulusOpenHoleBar.toFixed(1)} bar</span>
              </div>
              <div className="p-2.5 rounded bg-[#111] border border-[#222] flex justify-between">
                <span className="text-[#888]">Jet Velocity:</span>
                <span className="font-bold text-[#00ff41]">{twin.hydraulicsResult.bitJetVelocityMs.toFixed(1)} m/s</span>
              </div>
              <div className="p-2.5 rounded bg-[#111] border border-[#222] flex justify-between">
                <span className="text-[#888]">Bit Hydraulic Power:</span>
                <span className="font-bold text-sky-400">{twin.hydraulicsResult.bitHydraulicHorsepowerKw.toFixed(1)} kW</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Vibrations & Stick-Slip Dynamics */}
      {activeSubTab === 'vibration' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3 relative overflow-hidden">
            <div className="absolute inset-0 opacity-10 pointer-events-none bg-grid-dots"></div>
            <div className="flex items-center justify-between border-b border-[#222] pb-2 relative z-10">
              <span className="text-[10px] font-mono font-bold text-[#888] uppercase tracking-widest">
                Torsional Stick-Slip Phase Plane & Limit-Cycle Oscillator
              </span>
              <span className="text-[9px] font-mono text-red-400 px-2 py-0.5 rounded bg-[#111] border border-[#333]">
                {twin.vibrationTelemetry.isStickSlipActive ? 'STICK-SLIP ACTIVE' : 'STABLE ROTATION'}
              </span>
            </div>

            <div className="h-80 w-full relative z-10">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={phasePlaneData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                  <XAxis dataKey="step" stroke="#555555" tick={{ fontSize: 9, fill: '#666666' }} />
                  <YAxis stroke="#555555" tick={{ fontSize: 9, fill: '#666666' }} />
                  <Tooltip contentStyle={{ backgroundColor: '#0a0a0a', borderColor: '#333333', fontSize: '11px', fontFamily: 'monospace', color: '#e0e0e0' }} />
                  <Legend wrapperStyle={{ fontSize: '10px', fontFamily: 'monospace' }} />
                  <Line type="monotone" dataKey="bitRpm" name="Instantaneous Bit RPM" stroke="#f43f5e" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="surfaceRpm" name="Surface Commanded RPM" stroke="#00ff41" strokeWidth={1.5} strokeDasharray="4 4" dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="lg:col-span-1 bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3 font-mono text-xs">
            <span className="text-[10px] font-bold text-[#888] block border-b border-[#222] pb-2 uppercase tracking-widest">
              Vibrational Modal Frequencies
            </span>
            <div className="space-y-2">
              <div className="p-2.5 rounded bg-[#111] border border-[#222] flex justify-between">
                <span className="text-[#888]">Stick-Slip Severity:</span>
                <span className="font-bold text-red-400">{twin.vibrationTelemetry.torsionalVibrationPercent.toFixed(0)}%</span>
              </div>
              <div className="p-2.5 rounded bg-[#111] border border-[#222] flex justify-between">
                <span className="text-[#888]">Axial Acceleration:</span>
                <span className="font-bold text-amber-400">{twin.vibrationTelemetry.axialVibrationG.toFixed(2)} g</span>
              </div>
              <div className="p-2.5 rounded bg-[#111] border border-[#222] flex justify-between">
                <span className="text-[#888]">Lateral Acceleration:</span>
                <span className="font-bold text-sky-400">{twin.vibrationTelemetry.lateralVibrationG.toFixed(2)} g</span>
              </div>
              <div className="p-2.5 rounded bg-[#111] border border-[#222] flex justify-between">
                <span className="text-[#888]">Bit Instantaneous RPM:</span>
                <span className="font-bold text-white">{twin.vibrationTelemetry.bitRpmInstantaneous.toFixed(0)} RPM</span>
              </div>
              <div className="p-2.5 rounded bg-[#111] border border-[#222] flex justify-between">
                <span className="text-[#888]">Bit Bounce Mode:</span>
                <span className="font-bold text-[#00ff41]">{twin.vibrationTelemetry.isBitBounceActive ? 'DETECTED' : 'CLEAR'}</span>
              </div>
              <div className="p-2.5 rounded bg-[#111] border border-[#222] flex justify-between">
                <span className="text-[#888]">BHA Forward Whirl:</span>
                <span className="font-bold text-[#00ff41]">{twin.vibrationTelemetry.isWhirlActive ? 'DETECTED' : 'CLEAR'}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Cuttings Transport Tab */}
      {activeSubTab === 'cuttings' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3 relative overflow-hidden">
            <div className="absolute inset-0 opacity-10 pointer-events-none bg-grid-dots"></div>
            <div className="flex items-center justify-between border-b border-[#222] pb-2 relative z-10">
              <span className="text-[10px] font-mono font-bold text-[#888] uppercase tracking-widest">
                Annular Cuttings Transport & Bed Deposition Index
              </span>
              <span className="text-[9px] font-mono text-[#00ff41] px-2 py-0.5 rounded bg-[#111] border border-[#333]">
                Larsen-Chien Inclined Slip Model
              </span>
            </div>

            <div className="p-4 bg-[#111] rounded border border-[#222] font-mono text-xs space-y-3 relative z-10">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 bg-[#0a0a0a] rounded border border-[#222]">
                  <span className="text-[#888] block text-[10px] uppercase">Cuttings Generation Rate:</span>
                  <span className="text-xl font-bold text-[#00ff41]">
                    {twin.cuttingsResult.cuttingsGenerationM3Hr.toFixed(3)} m³/hr
                  </span>
                  <span className="text-[9px] text-[#666] block mt-1">
                    ({twin.cuttingsResult.cuttingsMassKgS.toFixed(2)} kg/s rock mass)
                  </span>
                </div>

                <div className="p-3 bg-[#0a0a0a] rounded border border-[#222]">
                  <span className="text-[#888] block text-[10px] uppercase">Transport Ratio (TR):</span>
                  <span className="text-xl font-bold text-sky-400">
                    {twin.cuttingsResult.transportRatioPercent.toFixed(1)}%
                  </span>
                  <span className="text-[9px] text-[#666] block mt-1">
                    Particle slip: {twin.cuttingsResult.particleSlipVelocityMs.toFixed(2)} m/s
                  </span>
                </div>
              </div>

              <div className="p-3 bg-[#0a0a0a] rounded border border-[#222] space-y-2">
                <div className="flex justify-between">
                  <span className="text-[#888] text-[10px] uppercase">Well Cleaning Index:</span>
                  <span className="font-bold text-[#00ff41]">
                    {twin.cuttingsResult.wellCleaningIndexScore.toFixed(0)} / 100 ({twin.cuttingsResult.cleaningStatus})
                  </span>
                </div>
                <div className="w-full bg-[#050505] h-1.5 rounded-full overflow-hidden">
                  <div 
                    className="bg-[#00ff41] h-full rounded-full shadow-[0_0_8px_#00ff41]" 
                    style={{ width: `${twin.cuttingsResult.wellCleaningIndexScore}%` }}
                  />
                </div>
                <div className="flex justify-between text-[10px] text-[#888]">
                  <span>Annular Velocity: {twin.cuttingsResult.annularVelocityMs.toFixed(2)} m/s</span>
                  <span>Cuttings Vol Concentration: {twin.cuttingsResult.cuttingsConcentrationPercent.toFixed(2)}%</span>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-1 bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3 font-mono text-xs">
            <span className="text-[10px] font-bold text-[#888] block border-b border-[#222] pb-2 uppercase tracking-widest">
              Critical Hole Angle Risk
            </span>
            <div className="space-y-2">
              <div className="p-2.5 rounded bg-[#111] border border-[#222] flex justify-between">
                <span className="text-[#888]">Hole Inclination:</span>
                <span className="font-bold text-white">32.3°</span>
              </div>
              <div className="p-2.5 rounded bg-[#111] border border-[#222] flex justify-between">
                <span className="text-[#888]">Critical Bed Angle (35-60°):</span>
                <span className="text-[#00ff41] font-bold">NOMINAL</span>
              </div>
              <div className="p-2.5 rounded bg-[#111] border border-[#222] flex justify-between">
                <span className="text-[#888]">Estimated Bed Thickness:</span>
                <span className="text-white font-bold">{twin.cuttingsResult.cuttingsBedThicknessMm.toFixed(1)} mm</span>
              </div>
              <div className="p-2.5 rounded bg-[#111] border border-[#222] text-[10px] text-[#888]">
                <Info className="w-3.5 h-3.5 text-sky-400 inline mr-1" />
                In high inclination wells (&gt;35°), cuttings deposit on the low side of the borehole creating stationary beds that increase pack-off and torque risk.
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
