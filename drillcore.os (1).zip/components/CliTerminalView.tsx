'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Terminal, Send, Trash2, Play, CornerDownLeft, Sparkles } from 'lucide-react';
import { DigitalTwinState } from '../lib/twin/drillingTwin';
import { CliEngine, CliOutput } from '../lib/twin/cliEngine';

interface CliTerminalViewProps {
  twin: DigitalTwinState;
}

export const CliTerminalView: React.FC<CliTerminalViewProps> = ({ twin }) => {
  const [inputCmd, setInputCmd] = useState('');
  const [history, setHistory] = useState<CliOutput[]>([
    {
      command: 'drill well',
      timestamp: new Date().toLocaleTimeString(),
      status: 'SUCCESS',
      rawOutput: CliEngine.executeCommand('drill well', twin).rawOutput,
    },
  ]);

  const terminalEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  const handleRunCommand = (cmdToRun?: string) => {
    const cmd = cmdToRun || inputCmd;
    if (!cmd.trim()) return;

    const res = CliEngine.executeCommand(cmd, twin);
    setHistory(prev => [...prev, res]);
    setInputCmd('');
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleRunCommand();
    }
  };

  const quickCommands = [
    'drill well',
    'drill hydraulics',
    'drill trajectory',
    'drill torque-drag',
    'drill vibration',
    'drill pressure',
    'drill bit',
    'drill optimise',
    'drill montecarlo',
    'drill compare',
    'drill validate',
    'drill report',
  ];

  return (
    <div className="space-y-4 font-sans text-[#e0e0e0]">
      <div className="bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none bg-grid-dots"></div>
        <div className="flex items-center justify-between border-b border-[#222] pb-2 relative z-10">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-[#00ff41]" />
            <span className="text-[10px] font-mono font-bold text-[#888] uppercase tracking-widest">
              DRILLCORE.OS Hard-Engineering Command Line Interface
            </span>
          </div>
          <button
            onClick={() => setHistory([])}
            className="text-[10px] font-mono text-[#777] hover:text-[#00ff41] flex items-center gap-1 transition-colors"
          >
            <Trash2 className="w-3 h-3" />
            <span>Clear Buffer</span>
          </button>
        </div>

        {/* Quick Command Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1 text-[11px] font-mono relative z-10">
          <span className="text-[#666] text-[9px] uppercase font-bold tracking-wider shrink-0">Presets:</span>
          {quickCommands.map(qc => (
            <button
              key={qc}
              onClick={() => handleRunCommand(qc)}
              className="px-2 py-0.5 rounded bg-[#111] hover:bg-[#1a1a1a] hover:border-[#00ff41]/50 text-[#aaa] hover:text-white border border-[#222] shrink-0 transition-all text-[10px]"
            >
              {qc}
            </button>
          ))}
        </div>

        {/* Terminal Screen */}
        <div className="bg-[#050505] rounded border border-[#222] h-96 overflow-y-auto no-scrollbar font-mono text-xs text-[#ccc] space-y-4 p-4 relative z-10">
          <div className="text-[10px] text-[#666] border-b border-[#1a1a1a] pb-2">
            DRILLCORE.OS Engine Terminal v3.4 [x86_64-linux-gnu] • Rust Physics Core • R Quant Runtime
            <br />Type &apos;drill help&apos; or click presets to query subsystems.
          </div>

          {history.map((h, idx) => (
            <div key={idx} className="space-y-1">
              <div className="flex items-center gap-2 text-[11px] text-[#00ff41] font-bold">
                <span className="text-[#666]">[{h.timestamp}]</span>
                <span className="text-[#888]">$</span>
                <span className="tracking-wide">{h.command}</span>
              </div>
              <pre className="text-[#ccc] whitespace-pre-wrap font-mono text-[11px] pl-4 border-l border-[#222] leading-relaxed">
                {h.rawOutput}
              </pre>
            </div>
          ))}

          <div ref={terminalEndRef} />
        </div>

        {/* Command Input Bar */}
        <div className="flex items-center gap-2 bg-[#050505] p-2 rounded border border-[#222] relative z-10">
          <span className="text-[#00ff41] font-mono text-xs font-bold pl-2">drill &gt;</span>
          <input
            type="text"
            value={inputCmd}
            onChange={e => setInputCmd(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type 'drill optimise', 'drill montecarlo', 'drill report'..."
            className="flex-1 bg-transparent text-xs font-mono text-white placeholder-[#555] focus:outline-none"
          />
          <button
            onClick={() => handleRunCommand()}
            className="px-3 py-1.5 rounded bg-[#00ff41] hover:bg-[#00ff41]/90 text-black font-mono text-xs font-bold flex items-center gap-1 transition-all shadow-[0_0_8px_rgba(0,255,65,0.2)] uppercase tracking-wider"
          >
            <span>Execute</span>
            <CornerDownLeft className="w-3 h-3" />
          </button>
        </div>
      </div>
    </div>
  );
};
