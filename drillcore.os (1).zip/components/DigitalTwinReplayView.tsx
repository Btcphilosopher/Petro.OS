'use client';

import React, { useState } from 'react';
import { 
  RotateCcw, 
  Play, 
  Pause, 
  Clock, 
  Layers, 
  CheckCircle2, 
  AlertTriangle, 
  Flame, 
  ChevronRight,
  Database
} from 'lucide-react';
import { DigitalTwinState, DrillingEvent } from '../lib/twin/drillingTwin';
import { UnitSystem } from '../lib/physics/units';

interface DigitalTwinReplayViewProps {
  twin: DigitalTwinState;
  unitSystem: UnitSystem;
}

export const DigitalTwinReplayView: React.FC<DigitalTwinReplayViewProps> = ({ twin, unitSystem }) => {
  const [selectedEventId, setSelectedEventId] = useState<string>(twin.events[twin.events.length - 1]?.id || 'evt-0');

  const selectedEvent = twin.events.find(e => e.id === selectedEventId) || twin.events[0];

  return (
    <div className="space-y-4 font-sans text-[#e0e0e0]">
      <div className="bg-[#0a0a0a] rounded border border-[#222] p-4 space-y-3 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none bg-grid-dots"></div>
        <div className="flex items-center justify-between border-b border-[#222] pb-2 relative z-10">
          <div className="flex items-center gap-2">
            <RotateCcw className="w-4 h-4 text-[#00ff41]" />
            <span className="text-[10px] font-mono font-bold text-[#888] uppercase tracking-widest">
              Event-Sourced Well History & Deterministic Replay Engine
            </span>
          </div>
          <span className="text-[9px] font-mono text-[#00ff41] px-2 py-0.5 rounded bg-[#111] border border-[#333]">
            {twin.events.length} Immutable Event Records Recorded
          </span>
        </div>

        <p className="text-xs text-[#888] leading-relaxed font-sans relative z-10">
          Every drilling milestone, operational setpoint change, formation boundary transition, and vibrational excursion is captured as an immutable event with a complete physics state snapshot, enabling deterministic time-travel and post-well audit.
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 pt-2 relative z-10">
          {/* Event Timeline List (Left) */}
          <div className="lg:col-span-1 bg-[#050505] rounded border border-[#222] p-3 space-y-2 h-96 overflow-y-auto no-scrollbar font-mono text-xs">
            <span className="text-[#666] text-[9px] block uppercase font-bold tracking-wider border-b border-[#222] pb-1">
              Event Stream Audit Log
            </span>

            {twin.events.map((evt) => {
              const isSelected = evt.id === selectedEventId;
              return (
                <button
                  key={evt.id}
                  onClick={() => setSelectedEventId(evt.id)}
                  className={`w-full text-left p-2.5 rounded border transition-all space-y-1 ${
                    isSelected
                      ? 'bg-[#111] border-[#00ff41]/60 shadow-[0_0_8px_rgba(0,255,65,0.2)] text-white'
                      : 'bg-[#0a0a0a] border-[#222] text-[#888] hover:bg-[#111] hover:text-[#e0e0e0]'
                  }`}
                >
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="font-bold text-[#00ff41]">{evt.type}</span>
                    <span className="text-[#666]">MD: {evt.depthMdM}m</span>
                  </div>
                  <p className="text-[11px] line-clamp-2 leading-tight text-[#ccc]">{evt.description}</p>
                  <span className="text-[9px] text-[#555] block">{evt.timestamp}</span>
                </button>
              );
            })}
          </div>

          {/* Selected Event State Snapshot Inspector (Right 2 cols) */}
          <div className="lg:col-span-2 bg-[#050505] rounded border border-[#222] p-4 space-y-3 font-mono text-xs">
            <div className="flex items-center justify-between border-b border-[#222] pb-2">
              <div>
                <span className="text-[9px] text-[#00ff41] block font-bold uppercase tracking-widest">SNAPSHOT STATE INSPECTOR</span>
                <h3 className="text-sm font-bold text-white mt-0.5">{selectedEvent?.type}</h3>
              </div>
              <span className="text-[10px] text-[#666]">{selectedEvent?.timestamp} • MD {selectedEvent?.depthMdM} m</span>
            </div>

            <div className="p-3 bg-[#111] rounded border border-[#222] space-y-1.5 text-[#ccc]">
              <span className="text-[#888] text-[9px] block font-bold uppercase tracking-wider">EVENT LOG DESCRIPTION</span>
              <p className="text-xs leading-relaxed font-sans text-white">{selectedEvent?.description}</p>
            </div>

            <div className="space-y-2">
              <span className="text-[#888] text-[9px] block font-bold uppercase tracking-wider">Physical State Vector at Event</span>
              <div className="bg-[#0a0a0a] p-3 rounded border border-[#222] text-[11px] overflow-x-auto text-[#00ff41]">
                <pre>{JSON.stringify(selectedEvent?.dataSnapshot, null, 2)}</pre>
              </div>
            </div>

            <div className="pt-2 text-[9px] text-[#555] font-mono">
              Integrity: Cryptographically signed event record. Replayable on DRILLCORE Rust Kernel v3.4.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
