/**
 * DRILLCORE.OS Monte Carlo Uncertainty & Well Delivery Simulator (drillquant/montecarlo)
 * Simulates thousands of stochastic well delivery realization paths
 * to produce P10 / P50 / P90 distributions for Time, Cost, NPT, and Bit Runs.
 */

export interface MonteCarloTrial {
  trialIndex: number;
  totalTimeHours: number;
  totalCostUsd: number;
  nptHours: number;
  bitRunsCount: number;
  avgRopMHr: number;
}

export interface MonteCarloDistribution {
  p10: number; // 90% chance of being better than this (Optimistic)
  p50: number; // Median expected outcome
  p90: number; // 10% chance of exceeding this (Conservative)
  mean: number;
  standardDeviation: number;
  min: number;
  max: number;
}

export interface MonteCarloResults {
  totalTrials: number;
  timeToDepthDays: MonteCarloDistribution;
  wellCostUsd: MonteCarloDistribution;
  nptHoursDistribution: MonteCarloDistribution;
  bitRunsDistribution: MonteCarloDistribution;
  avgRopDistribution: MonteCarloDistribution;
  costHistogramBuckets: { bucketMin: number; bucketMax: number; count: number }[];
  timeHistogramBuckets: { bucketMin: number; bucketMax: number; count: number }[];
}

export class MonteCarloEngine {
  /**
   * Generates a Gaussian random variable using Box-Muller transform
   */
  private static randomNormal(mean: number, stdDev: number): number {
    let u = 0, v = 0;
    while (u === 0) u = Math.random();
    while (v === 0) v = Math.random();
    const num = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
    return num * stdDev + mean;
  }

  /**
   * Runs Monte Carlo well delivery simulation (e.g. 1000 - 5000 iterations)
   */
  public static runSimulation(
    targetDepthM: number = 3000,
    currentDepthM: number = 2450,
    trialCount: number = 1500
  ): MonteCarloResults {
    const remainingMeters = Math.max(100, targetDepthM - currentDepthM);
    const trials: MonteCarloTrial[] = [];

    for (let i = 0; i < trialCount; i++) {
      // 1. Stochastic rock strength & ROP
      const baseRop = this.randomNormal(23.5, 4.2);
      const effectiveRop = Math.max(8.0, baseRop);
      const drillingHours = remainingMeters / effectiveRop;

      // 2. Stochastic connection & trip time
      const stands = remainingMeters / 28.5; // ~28.5m per stand (90 ft)
      const connectionHours = stands * (this.randomNormal(4.5, 1.2) / 60); // 4.5 mins avg

      // 3. Bit life & bit changes
      const bitLifeM = this.randomNormal(650, 120);
      const bitChanges = Math.floor(remainingMeters / Math.max(200, bitLifeM));
      const tripHours = bitChanges * this.randomNormal(11.5, 2.0);

      // 4. Stochastic NPT events (equipment failure, tight hole, weather)
      let nptHours = 0;
      const nptEventChance = Math.random();
      if (nptEventChance < 0.25) {
        // Minor NPT event
        nptHours = this.randomNormal(4.5, 1.8);
      } else if (nptEventChance < 0.08) {
        // Major NPT event (stuck pipe, pump failure)
        nptHours = this.randomNormal(28.0, 8.5);
      }
      nptHours = Math.max(0, nptHours);

      const totalTimeHours = drillingHours + connectionHours + tripHours + nptHours;
      const totalCostUsd = 1200000 + (totalTimeHours * 3650) + (bitChanges * 42000);

      trials.push({
        trialIndex: i,
        totalTimeHours,
        totalCostUsd,
        nptHours,
        bitRunsCount: bitChanges + 1,
        avgRopMHr: effectiveRop,
      });
    }

    // Helper to calculate percentiles
    const calcDistribution = (values: number[]): MonteCarloDistribution => {
      const sorted = [...values].sort((a, b) => a - b);
      const n = sorted.length;
      const p10 = sorted[Math.floor(n * 0.10)];
      const p50 = sorted[Math.floor(n * 0.50)];
      const p90 = sorted[Math.floor(n * 0.90)];
      const mean = sorted.reduce((a, b) => a + b, 0) / n;
      const variance = sorted.map(x => Math.pow(x - mean, 2)).reduce((a, b) => a + b, 0) / n;
      const stdDev = Math.sqrt(variance);

      return {
        p10,
        p50,
        p90,
        mean,
        standardDeviation: stdDev,
        min: sorted[0],
        max: sorted[n - 1],
      };
    };

    const timeDays = trials.map(t => t.totalTimeHours / 24);
    const costs = trials.map(t => t.totalCostUsd);
    const npts = trials.map(t => t.nptHours);
    const bits = trials.map(t => t.bitRunsCount);
    const rops = trials.map(t => t.avgRopMHr);

    // Build Cost Histogram Buckets
    const minCost = Math.min(...costs);
    const maxCost = Math.max(...costs);
    const costBucketCount = 12;
    const costBucketWidth = (maxCost - minCost) / costBucketCount;
    const costBuckets = Array.from({ length: costBucketCount }, (_, idx) => ({
      bucketMin: minCost + idx * costBucketWidth,
      bucketMax: minCost + (idx + 1) * costBucketWidth,
      count: 0,
    }));

    for (const c of costs) {
      const bIdx = Math.min(costBucketCount - 1, Math.floor((c - minCost) / costBucketWidth));
      costBuckets[bIdx].count++;
    }

    // Build Time Histogram Buckets
    const minTime = Math.min(...timeDays);
    const maxTime = Math.max(...timeDays);
    const timeBucketCount = 12;
    const timeBucketWidth = (maxTime - minTime) / timeBucketCount;
    const timeBuckets = Array.from({ length: timeBucketCount }, (_, idx) => ({
      bucketMin: minTime + idx * timeBucketWidth,
      bucketMax: minTime + (idx + 1) * timeBucketWidth,
      count: 0,
    }));

    for (const t of timeDays) {
      const bIdx = Math.min(timeBucketCount - 1, Math.floor((t - minTime) / timeBucketWidth));
      timeBuckets[bIdx].count++;
    }

    return {
      totalTrials: trialCount,
      timeToDepthDays: calcDistribution(timeDays),
      wellCostUsd: calcDistribution(costs),
      nptHoursDistribution: calcDistribution(npts),
      bitRunsDistribution: calcDistribution(bits),
      avgRopDistribution: calcDistribution(rops),
      costHistogramBuckets: costBuckets,
      timeHistogramBuckets: timeBuckets,
    };
  }
}
