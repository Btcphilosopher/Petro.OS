/**
 * DRILLCORE.OS Engineering Units & Standards (SI Native with Oilfield Conversions)
 * Standardizes physical quantities, engineering results, and validation types.
 */

export type ModelFidelity = 'FIDELITY_0' | 'FIDELITY_1' | 'FIDELITY_2' | 'FIDELITY_3';
// FIDELITY_0: Conceptual model
// FIDELITY_1: Engineering approximation
// FIDELITY_2: Detailed engineering model
// FIDELITY_3: Calibrated/validated field model

export interface EngineeringResult<T = number> {
  value: T;
  unit: string;
  equation: string;
  inputs: Record<string, number | string | boolean>;
  assumptions: string[];
  uncertainty: {
    standardDeviation?: number;
    confidenceInterval95?: [number, number];
    relativeErrorPercent?: number;
  };
  validityRange: {
    min?: number;
    max?: number;
    notes?: string;
  };
  modelVersion: string;
  fidelity: ModelFidelity;
}

export type UnitSystem = 'SI' | 'OILFIELD' | 'METRIC_OILFIELD';

export class UnitConverter {
  // Length
  static mToFt(m: number): number { return m * 3.28084; }
  static ftToM(ft: number): number { return ft / 3.28084; }
  static mmToIn(mm: number): number { return mm / 25.4; }
  static inToMm(inch: number): number { return inch * 25.4; }

  // Force
  static nToLbf(n: number): number { return n * 0.224809; }
  static lbfToN(lbf: number): number { return lbf / 0.224809; }
  static nToKlbf(n: number): number { return (n * 0.224809) / 1000; }
  static klbfToN(klbf: number): number { return (klbf * 1000) / 0.224809; }
  static knToKlbf(kn: number): number { return (kn * 1000 * 0.224809) / 1000; }
  static klbfToKn(klbf: number): number { return (klbf * 1000) / 0.224809 / 1000; }
  static nToTonnes(n: number): number { return n / 9806.65; }

  // Pressure
  static paToPsi(pa: number): number { return pa * 0.000145038; }
  static psiToPa(psi: number): number { return psi / 0.000145038; }
  static paToBar(pa: number): number { return pa / 100000; }
  static barToPa(bar: number): number { return bar * 100000; }
  static barToPsi(bar: number): number { return bar * 14.5038; }
  static psiToBar(psi: number): number { return psi / 14.5038; }
  static paToMpa(pa: number): number { return pa / 1000000; }

  // Density / Fluid Weight
  static kgM3ToPpg(kgM3: number): number { return kgM3 * 0.0083454; }
  static ppgToKgM3(ppg: number): number { return ppg / 0.0083454; }
  static kgM3ToSg(kgM3: number): number { return kgM3 / 1000; }

  // Flow Rate
  static m3sToGpm(m3s: number): number { return m3s * 15850.323; }
  static gpmToM3s(gpm: number): number { return gpm / 15850.323; }
  static lsToGpm(ls: number): number { return ls * 15.850323; }
  static gpmToLs(gpm: number): number { return gpm / 15.850323; }

  // Torque
  static nmToFtLbf(nm: number): number { return nm * 0.737562; }
  static ftLbfToNm(ftLbf: number): number { return ftLbf / 0.737562; }
  static nmToKNm(nm: number): number { return nm / 1000; }

  // Velocity / ROP
  static msToFtHr(ms: number): number { return ms * 11811.0236; }
  static ftHrToMs(ftHr: number): number { return ftHr / 11811.0236; }
  static msToMHr(ms: number): number { return ms * 3600; }
  static mHrToMs(mHr: number): number { return mHr / 3600; }

  // Temperature
  static cToF(c: number): number { return (c * 9/5) + 32; }
  static fToC(f: number): number { return (f - 32) * 5/9; }
  static cToK(c: number): number { return c + 273.15; }
}
