/**
 * DRILLCORE.OS Rig, Hoisting & Top Drive Digital Twin
 * Physical models for drawworks, traveling block, wire rope load paths,
 * top drive electromechanical torque/power limits, and surface sensors.
 */

import { EngineeringResult } from './units';

export type RigType = 'LAND_RIG' | 'OFFSHORE_JACKUP' | 'OFFSHORE_SEMISUB' | 'DRILLSHIP';

export interface RigConfig {
  rigId: string;
  name: string;
  rigType: RigType;
  maxDepthCapacityM: number;       // m (e.g. 7000m)
  derrickHeightM: number;          // m (e.g. 45m)
  hookLoadLimitKn: number;         // kN (e.g. 4500 kN ~ 1,000,000 lbs)
  drawworksPowerKw: number;        // kW (e.g. 1500 kW ~ 2000 HP)
  topDrivePowerKw: number;         // kW (e.g. 800 kW ~ 1100 HP)
  topDriveMaxTorqueNm: number;     // Nm (e.g. 65,000 Nm ~ 48,000 ft-lbs)
  topDriveMaxRpm: number;          // RPM (e.g. 250 RPM)
  mudPumpsMaxPressureBar: number;  // bar (e.g. 350 bar ~ 5000 psi)
  mudPumpsMaxFlowRateLs: number;   // L/s (e.g. 60 L/s ~ 950 gpm)
  numberOfLines: number;           // lines strung to traveling block (e.g. 12)
  hoistingEfficiency: number;      // fraction 0.85 - 0.95
  rigDayRateUsd: number;           // $/day (e.g. 185,000 USD/day)
}

export interface HoistingState {
  hookLoadKn: number;              // Current hook load (kN)
  blockLoadKn: number;             // Load on traveling block (kN)
  fastlineTensionKn: number;       // Tension on fastline off drawworks drum (kN)
  deadlineTensionKn: number;       // Tension on deadline anchor (kN)
  hoistingSpeedMs: number;         // m/s
  requiredPowerKw: number;         // kW
  loadMarginPercent: number;       // % safe remaining hook load
}

export interface TopDriveState {
  rpm: number;
  torqueNm: number;
  powerKw: number;
  temperatureC: number;
  direction: 'FORWARD_CW' | 'REVERSE_CCW';
  operatingHours: number;
  torqueCapacityPercent: number;
  powerCapacityPercent: number;
}

export class RigEngine {
  public static getDefaultRigConfig(): RigConfig {
    return {
      rigId: 'RIG-DC-700',
      name: 'CyberDrill 2000 HP CyberRig',
      rigType: 'LAND_RIG',
      maxDepthCapacityM: 6000,
      derrickHeightM: 46.5,
      hookLoadLimitKn: 4450,       // ~1,000,000 lbf
      drawworksPowerKw: 1490,      // 2000 HP
      topDrivePowerKw: 820,        // 1100 HP
      topDriveMaxTorqueNm: 62000,  // 45,700 ft-lbf
      topDriveMaxRpm: 240,
      mudPumpsMaxPressureBar: 345, // 5000 psi
      mudPumpsMaxFlowRateLs: 55,   // ~870 gpm
      numberOfLines: 12,
      hoistingEfficiency: 0.88,
      rigDayRateUsd: 45000,
    };
  }

  /**
   * Calculates hoisting system mechanics: fastline tension, block load, lifting power
   */
  public static calculateHoisting(
    hookLoadKn: number,
    hoistingSpeedMs: number,
    config: RigConfig
  ): EngineeringResult<HoistingState> {
    const N = config.numberOfLines;
    const eff = config.hoistingEfficiency;

    // Fastline tension T_f = W / (N * eff)
    const fastlineTensionKn = hookLoadKn / (N * eff);
    const deadlineTensionKn = hookLoadKn / N;
    
    // Total load on crown block = W + T_f + T_d
    const crownBlockLoadKn = hookLoadKn + fastlineTensionKn + deadlineTensionKn;

    // Power required at drawworks = (HookLoad * speed) / eff (in kW)
    const powerKw = (hookLoadKn * hoistingSpeedMs) / eff;
    const loadMarginPercent = Math.max(0, ((config.hookLoadLimitKn - hookLoadKn) / config.hookLoadLimitKn) * 100);

    const state: HoistingState = {
      hookLoadKn,
      blockLoadKn: hookLoadKn,
      fastlineTensionKn,
      deadlineTensionKn,
      hoistingSpeedMs,
      requiredPowerKw: powerKw,
      loadMarginPercent,
    };

    return {
      value: state,
      unit: 'kN / kW',
      equation: 'T_fastline = W_hook / (N_lines * eta); Power = (W_hook * v) / eta',
      inputs: { hookLoadKn, hoistingSpeedMs, numberOfLines: N, efficiency: eff },
      assumptions: ['Friction distributed evenly across crown and traveling sheave bearings', 'Dynamic acceleration negligible at steady trip speed'],
      uncertainty: { standardDeviation: 12.0, relativeErrorPercent: 2.5 },
      validityRange: { min: 0, max: config.hookLoadLimitKn, notes: 'Must not exceed static hook load rating' },
      modelVersion: 'RIG-HOIST-V2.0',
      fidelity: 'FIDELITY_2',
    };
  }

  /**
   * Calculates Top Drive electrical/mechanical state and power draw
   */
  public static calculateTopDrive(
    rpm: number,
    torqueNm: number,
    config: RigConfig,
    operatingHours: number = 420.5
  ): EngineeringResult<TopDriveState> {
    // Rotational power: P (W) = Torque (Nm) * omega (rad/s)
    // omega = 2 * pi * RPM / 60
    const omega = (2 * Math.PI * rpm) / 60;
    const powerKw = (torqueNm * omega) / 1000;

    const torqueCapacityPercent = Math.min(100, (torqueNm / config.topDriveMaxTorqueNm) * 100);
    const powerCapacityPercent = Math.min(100, (powerKw / config.topDrivePowerKw) * 100);

    // Motor thermal estimate based on load percentage
    const ambientTempC = 25.0;
    const motorTempC = ambientTempC + (powerCapacityPercent / 100) * 55.0;

    const state: TopDriveState = {
      rpm,
      torqueNm,
      powerKw,
      temperatureC: motorTempC,
      direction: 'FORWARD_CW',
      operatingHours,
      torqueCapacityPercent,
      powerCapacityPercent,
    };

    return {
      value: state,
      unit: 'kW / Nm',
      equation: 'Power_rot = (Torque_Nm * 2 * pi * RPM) / 60000',
      inputs: { rpm, torqueNm, maxTorque: config.topDriveMaxTorqueNm, maxPower: config.topDrivePowerKw },
      assumptions: ['AC VFD motor continuous rating curve', 'Direct drive or 1:1 gear ratio'],
      uncertainty: { standardDeviation: 3.5, relativeErrorPercent: 1.5 },
      validityRange: { min: 0, max: config.topDriveMaxTorqueNm, notes: 'Stall protection engages above max torque' },
      modelVersion: 'RIG-TOPDRIVE-V1.9',
      fidelity: 'FIDELITY_2',
    };
  }
}
