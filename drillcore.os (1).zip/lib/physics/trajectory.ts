/**
 * DRILLCORE.OS Well Trajectory Engine
 * Implements rigorous 3D directional survey calculation methods:
 * - Minimum Curvature (standard ISO/API industry method with dogleg ratio factor)
 * - Tangential
 * - Balanced Tangential
 * - Average Angle
 */

import { EngineeringResult } from './units';

export type TrajectoryMethod = 'MINIMUM_CURVATURE' | 'TANGENTIAL' | 'BALANCED_TANGENTIAL' | 'AVERAGE_ANGLE';

export interface SurveyStation {
  md: number;        // Measured Depth (m)
  incDeg: number;    // Inclination (degrees, 0 = vertical)
  aziDeg: number;    // Azimuth (degrees from True North, 0-360)
  tvd?: number;      // True Vertical Depth (m)
  northing?: number; // North displacement (m)
  easting?: number;  // East displacement (m)
  dls?: number;      // Dogleg Severity (deg / 30m)
  dogleg?: number;   // Total dogleg angle (deg)
  buildRate?: number;// deg / 30m
  turnRate?: number; // deg / 30m
  verticalSection?: number; // m along target azimuth
}

export class TrajectoryEngine {
  private static degToRad(deg: number): number {
    return (deg * Math.PI) / 180;
  }

  private static radToDeg(rad: number): number {
    return (rad * 180) / Math.PI;
  }

  /**
   * Calculates dogleg angle (DL in radians) between two survey stations
   */
  public static calculateDogleg(
    inc1Rad: number,
    azi1Rad: number,
    inc2Rad: number,
    azi2Rad: number
  ): number {
    const cosDl =
      Math.cos(inc2Rad - inc1Rad) -
      Math.sin(inc1Rad) * Math.sin(inc2Rad) * (1 - Math.cos(azi2Rad - azi1Rad));
    
    // Clamp for numerical safety
    const clampedCosDl = Math.max(-1, Math.min(1, cosDl));
    return Math.acos(clampedCosDl);
  }

  /**
   * Minimum Curvature calculation method (ISO 10424 / API RP 7G compliant)
   */
  public static minimumCurvatureInterval(
    s1: SurveyStation,
    s2: SurveyStation,
    targetAziDeg: number = 0
  ): SurveyStation {
    const deltaMd = s2.md - s1.md;
    if (deltaMd <= 0) {
      return { ...s2, tvd: s1.tvd ?? 0, northing: s1.northing ?? 0, easting: s1.easting ?? 0, dls: 0, dogleg: 0 };
    }

    const inc1 = this.degToRad(s1.incDeg);
    const inc2 = this.degToRad(s2.incDeg);
    const azi1 = this.degToRad(s1.aziDeg);
    const azi2 = this.degToRad(s2.aziDeg);

    const dl = this.calculateDogleg(inc1, azi1, inc2, azi2);
    
    // Ratio factor RF = (2 / dl) * tan(dl / 2) -> 1 as dl -> 0
    let rf = 1.0;
    if (dl > 1e-6) {
      rf = (2 / dl) * Math.tan(dl / 2);
    }

    const deltaTvd = 0.5 * deltaMd * (Math.cos(inc1) + Math.cos(inc2)) * rf;
    const deltaNorth = 0.5 * deltaMd * (Math.sin(inc1) * Math.cos(azi1) + Math.sin(inc2) * Math.cos(azi2)) * rf;
    const deltaEast = 0.5 * deltaMd * (Math.sin(inc1) * Math.sin(azi1) + Math.sin(inc2) * Math.sin(azi2)) * rf;

    const tvd = (s1.tvd ?? 0) + deltaTvd;
    const northing = (s1.northing ?? 0) + deltaNorth;
    const easting = (s1.easting ?? 0) + deltaEast;

    const dlDeg = this.radToDeg(dl);
    const dls = (dlDeg / deltaMd) * 30; // deg per 30m
    const buildRate = ((s2.incDeg - s1.incDeg) / deltaMd) * 30;
    const turnRate = ((s2.aziDeg - s1.aziDeg) / deltaMd) * 30;

    const targetAziRad = this.degToRad(targetAziDeg);
    const vs = northing * Math.cos(targetAziRad) + easting * Math.sin(targetAziRad);

    return {
      md: s2.md,
      incDeg: s2.incDeg,
      aziDeg: s2.aziDeg,
      tvd,
      northing,
      easting,
      dls,
      dogleg: dlDeg,
      buildRate,
      turnRate,
      verticalSection: vs,
    };
  }

  /**
   * Tangential Method
   */
  public static tangentialInterval(s1: SurveyStation, s2: SurveyStation): SurveyStation {
    const deltaMd = s2.md - s1.md;
    const inc2 = this.degToRad(s2.incDeg);
    const azi2 = this.degToRad(s2.aziDeg);

    const deltaTvd = deltaMd * Math.cos(inc2);
    const deltaNorth = deltaMd * Math.sin(inc2) * Math.cos(azi2);
    const deltaEast = deltaMd * Math.sin(inc2) * Math.sin(azi2);

    return {
      md: s2.md,
      incDeg: s2.incDeg,
      aziDeg: s2.aziDeg,
      tvd: (s1.tvd ?? 0) + deltaTvd,
      northing: (s1.northing ?? 0) + deltaNorth,
      easting: (s1.easting ?? 0) + deltaEast,
      dls: (Math.abs(s2.incDeg - s1.incDeg) / deltaMd) * 30,
      dogleg: Math.abs(s2.incDeg - s1.incDeg),
    };
  }

  /**
   * Average Angle Method
   */
  public static averageAngleInterval(s1: SurveyStation, s2: SurveyStation): SurveyStation {
    const deltaMd = s2.md - s1.md;
    const incAvg = this.degToRad((s1.incDeg + s2.incDeg) / 2);
    const aziAvg = this.degToRad((s1.aziDeg + s2.aziDeg) / 2);

    const deltaTvd = deltaMd * Math.cos(incAvg);
    const deltaNorth = deltaMd * Math.sin(incAvg) * Math.cos(aziAvg);
    const deltaEast = deltaMd * Math.sin(incAvg) * Math.sin(aziAvg);

    return {
      md: s2.md,
      incDeg: s2.incDeg,
      aziDeg: s2.aziDeg,
      tvd: (s1.tvd ?? 0) + deltaTvd,
      northing: (s1.northing ?? 0) + deltaNorth,
      easting: (s1.easting ?? 0) + deltaEast,
      dls: (Math.abs(s2.incDeg - s1.incDeg) / deltaMd) * 30,
      dogleg: Math.abs(s2.incDeg - s1.incDeg),
    };
  }

  /**
   * Compute full 3D trajectory from survey stations
   */
  public static computeTrajectory(
    stations: SurveyStation[],
    method: TrajectoryMethod = 'MINIMUM_CURVATURE',
    targetAziDeg: number = 0
  ): SurveyStation[] {
    if (stations.length === 0) return [];
    
    const result: SurveyStation[] = [];
    // Origin station
    result.push({
      ...stations[0],
      tvd: stations[0].tvd ?? stations[0].md,
      northing: stations[0].northing ?? 0,
      easting: stations[0].easting ?? 0,
      dls: 0,
      dogleg: 0,
      verticalSection: 0,
    });

    for (let i = 1; i < stations.length; i++) {
      const prev = result[i - 1];
      const curr = stations[i];
      let computed: SurveyStation;

      switch (method) {
        case 'MINIMUM_CURVATURE':
          computed = this.minimumCurvatureInterval(prev, curr, targetAziDeg);
          break;
        case 'TANGENTIAL':
          computed = this.tangentialInterval(prev, curr);
          break;
        case 'AVERAGE_ANGLE':
          computed = this.averageAngleInterval(prev, curr);
          break;
        case 'BALANCED_TANGENTIAL':
        default: {
          const deltaMd = curr.md - prev.md;
          const inc1 = this.degToRad(prev.incDeg);
          const inc2 = this.degToRad(curr.incDeg);
          const azi1 = this.degToRad(prev.aziDeg);
          const azi2 = this.degToRad(curr.aziDeg);
          const deltaTvd = 0.5 * deltaMd * (Math.cos(inc1) + Math.cos(inc2));
          const deltaNorth = 0.5 * deltaMd * (Math.sin(inc1) * Math.cos(azi1) + Math.sin(inc2) * Math.cos(azi2));
          const deltaEast = 0.5 * deltaMd * (Math.sin(inc1) * Math.sin(azi1) + Math.sin(inc2) * Math.sin(azi2));
          computed = {
            md: curr.md,
            incDeg: curr.incDeg,
            aziDeg: curr.aziDeg,
            tvd: (prev.tvd ?? 0) + deltaTvd,
            northing: (prev.northing ?? 0) + deltaNorth,
            easting: (prev.easting ?? 0) + deltaEast,
            dls: (Math.abs(curr.incDeg - prev.incDeg) / deltaMd) * 30,
          };
          break;
        }
      }
      result.push(computed);
    }
    return result;
  }

  /**
   * Interpolate trajectory point at any continuous measured depth (MD)
   */
  public static interpolateAtMd(
    computedStations: SurveyStation[],
    targetMd: number
  ): SurveyStation {
    if (computedStations.length === 0) {
      return { md: targetMd, incDeg: 0, aziDeg: 0, tvd: targetMd, northing: 0, easting: 0, dls: 0 };
    }
    if (targetMd <= computedStations[0].md) return computedStations[0];
    if (targetMd >= computedStations[computedStations.length - 1].md) {
      return computedStations[computedStations.length - 1];
    }

    // Find bounding stations
    for (let i = 0; i < computedStations.length - 1; i++) {
      const s1 = computedStations[i];
      const s2 = computedStations[i + 1];
      if (targetMd >= s1.md && targetMd <= s2.md) {
        const fraction = (targetMd - s1.md) / (s2.md - s1.md);
        const inc = s1.incDeg + fraction * (s2.incDeg - s1.incDeg);
        const azi = s1.aziDeg + fraction * (s2.aziDeg - s1.aziDeg);
        const subStation: SurveyStation = { md: targetMd, incDeg: inc, aziDeg: azi };
        return this.minimumCurvatureInterval(s1, subStation);
      }
    }
    return computedStations[computedStations.length - 1];
  }

  /**
   * Calculates 3D deviation between planned trajectory and actual drilled trajectory
   */
  public static calculateTrajectoryDeviation(
    planned: SurveyStation[],
    actual: SurveyStation[]
  ): {
    md: number;
    tvdDiff: number;
    horizontalDiff: number;
    total3dDiff: number;
    inTolerance: boolean;
  }[] {
    return actual.map(act => {
      const plan = this.interpolateAtMd(planned, act.md);
      const tvdDiff = (act.tvd ?? 0) - (plan.tvd ?? 0);
      const dNorth = (act.northing ?? 0) - (plan.northing ?? 0);
      const dEast = (act.easting ?? 0) - (plan.easting ?? 0);
      const horizontalDiff = Math.sqrt(dNorth * dNorth + dEast * dEast);
      const total3dDiff = Math.sqrt(tvdDiff * tvdDiff + horizontalDiff * horizontalDiff);

      return {
        md: act.md,
        tvdDiff,
        horizontalDiff,
        total3dDiff,
        inTolerance: total3dDiff <= 15.0, // 15m tolerance cylinder window
      };
    });
  }
}
