/**
 * DRILLCORE.OS Cuttings Transport, Hole Cleaning & Well Control Engine
 * Models annular cuttings loading, particle slip velocities, bed deposition risk,
 * well cleaning scores, and kick influx / lost circulation physics.
 */

import { EngineeringResult } from './units';

export type LostCirculationSeverity = 'NORMAL' | 'PARTIAL_LOSS' | 'SEVERE_LOSS' | 'TOTAL_LOSS';

export interface CuttingsTransportResult {
  cuttingsGenerationM3Hr: number;
  cuttingsMassKgS: number;
  annularVelocityMs: number;
  particleSlipVelocityMs: number;
  transportRatioPercent: number;    // Transport Ratio TR = (v_a - v_s) / v_a * 100
  cuttingsConcentrationPercent: number; // Volume % in annulus
  cuttingsBedThicknessMm: number;
  criticalHoleAngleRisk: boolean;   // True if hole is in 35° - 60° bed settling range
  wellCleaningIndexScore: number;   // 0 (Dangerously plugged) to 100 (Optimal clean)
  cleaningStatus: 'OPTIMAL' | 'ACCEPTABLE' | 'POOR_CLEANING_ALERT' | 'CRITICAL_PACKOFF_RISK';
}

export interface WellControlState {
  isInfluxDetected: boolean;
  influxVolumeM3: number;
  pitGainRateM3Hr: number;
  shutInDrillPipePressureBar: number;
  shutInCasingPressureBar: number;
  requiredKillMudWeightKgM3: number;
  lostCirculationStatus: LostCirculationSeverity;
  mudLossRateM3Hr: number;
  cumulativeLossM3: number;
}

export class CuttingsAndWellControlEngine {
  /**
   * Calculates annular cuttings transport and hole cleaning efficiency
   */
  public static calculateCuttingsTransport(
    ropMHr: number,
    flowRateLs: number,
    holeDiameterMm: number,
    drillPipeOdMm: number,
    holeInclinationDeg: number,
    mudDensityKgM3: number,
    plasticViscosityCp: number,
    rockDensityKgM3: number = 2500
  ): EngineeringResult<CuttingsTransportResult> {
    const qM3s = flowRateLs / 1000;
    const holeAreaM2 = (Math.PI / 4) * Math.pow(holeDiameterMm / 1000, 2);
    const pipeAreaM2 = (Math.PI / 4) * Math.pow(drillPipeOdMm / 1000, 2);
    const annularAreaM2 = holeAreaM2 - pipeAreaM2;

    // Annular velocity (m/s)
    const annularVelocityMs = qM3s / annularAreaM2;

    // Rock cuttings volume generation (m3/hr)
    const cuttingsGenerationM3Hr = holeAreaM2 * ropMHr;
    const cuttingsMassKgS = (cuttingsGenerationM3Hr * rockDensityKgM3) / 3600;

    // Particle slip velocity v_s based on Chien correlation (particle size ~ 3mm cutting)
    const dParticleM = 0.003;
    const densityDiff = rockDensityKgM3 - mudDensityKgM3;
    const muPaS = plasticViscosityCp / 1000;

    // Uncorrected vertical slip velocity
    const vSlipVerticalMs = (9.81 * dParticleM * dParticleM * densityDiff) / (18 * muPaS);
    
    // Angle correction: Inclination between 35° and 60° causes cuttings to slide down low side
    const incRad = (holeInclinationDeg * Math.PI) / 180;
    let angleFactor = 1.0;
    if (holeInclinationDeg > 25 && holeInclinationDeg < 65) {
      angleFactor = 1.45 + 0.3 * Math.sin(2 * incRad); // Increased settling tendency
    } else if (holeInclinationDeg >= 65) {
      angleFactor = 1.15;
    }

    const particleSlipVelocityMs = Math.min(annularVelocityMs * 0.85, vSlipVerticalMs * angleFactor);

    // Transport ratio TR = (v_a - v_s) / v_a
    const transportRatio = Math.max(0.1, (annularVelocityMs - particleSlipVelocityMs) / annularVelocityMs);
    const transportRatioPercent = transportRatio * 100;

    // Annular cuttings volumetric concentration
    // C_c = V_c / (V_c + Q * TR)
    const cuttingsM3s = cuttingsGenerationM3Hr / 3600;
    const cuttingsConcentration = cuttingsM3s / (cuttingsM3s + qM3s * transportRatio);
    const cuttingsConcentrationPercent = cuttingsConcentration * 100;

    // Critical hole angle risk (35 - 60 degrees)
    const criticalHoleAngleRisk = holeInclinationDeg >= 35 && holeInclinationDeg <= 60;

    // Cuttings bed thickness on low side of hole (mm)
    let bedThicknessMm = 0;
    if (cuttingsConcentrationPercent > 4.5 || criticalHoleAngleRisk) {
      bedThicknessMm = Math.min(holeDiameterMm * 0.45, (cuttingsConcentrationPercent - 3.0) * 8.5);
      if (criticalHoleAngleRisk) bedThicknessMm *= 1.35;
    }

    // Well cleaning score index (0 - 100)
    // Decreases with high ROP, low flow, high cuttings concentration, and thick bed
    let cleaningScore = 100 - (cuttingsConcentrationPercent * 7.5) - (bedThicknessMm / holeDiameterMm) * 80;
    if (annularVelocityMs < 0.6) cleaningScore -= 20;
    if (criticalHoleAngleRisk) cleaningScore -= 10;
    cleaningScore = Math.max(5, Math.min(100, cleaningScore));

    let cleaningStatus: 'OPTIMAL' | 'ACCEPTABLE' | 'POOR_CLEANING_ALERT' | 'CRITICAL_PACKOFF_RISK' = 'OPTIMAL';
    if (cleaningScore < 45 || bedThicknessMm > 40) {
      cleaningStatus = 'CRITICAL_PACKOFF_RISK';
    } else if (cleaningScore < 68) {
      cleaningStatus = 'POOR_CLEANING_ALERT';
    } else if (cleaningScore < 85) {
      cleaningStatus = 'ACCEPTABLE';
    }

    const result: CuttingsTransportResult = {
      cuttingsGenerationM3Hr,
      cuttingsMassKgS,
      annularVelocityMs,
      particleSlipVelocityMs,
      transportRatioPercent,
      cuttingsConcentrationPercent,
      cuttingsBedThicknessMm: Math.max(0, bedThicknessMm),
      criticalHoleAngleRisk,
      wellCleaningIndexScore: cleaningScore,
      cleaningStatus,
    };

    return {
      value: result,
      unit: '% / mm / m/s',
      equation: 'TR = (v_a - v_s)/v_a; C_c = V_cut / (V_cut + Q*TR); Score = f(TR, v_a, Bed_thick, theta)',
      inputs: { ropMHr, flowRateLs, holeDiameterMm, holeInclinationDeg, mudDensityKgM3 },
      assumptions: ['Larsen-Chien inclined cuttings bed transport correlation', 'Spherical cut shape distribution'],
      uncertainty: { standardDeviation: 5.5, relativeErrorPercent: 8.0 },
      validityRange: { min: 0, max: 100, notes: 'Valid for annular velocities 0.3 - 2.5 m/s' },
      modelVersion: 'PHYSICS-CUTTINGS-LARSEN-CHIEN-V2.8',
      fidelity: 'FIDELITY_2',
    };
  }

  /**
   * Calculates Well Control / Kill Mud Weight requirements if an influx is detected
   */
  public static calculateWellControl(
    originalMudWeightKgM3: number,
    tvdM: number,
    sidppBar: number = 0,
    sicpBar: number = 0,
    pitGainM3: number = 0
  ): WellControlState {
    const isInflux = sidppBar > 0 || pitGainM3 > 0.5;
    
    // Kill Mud Weight (KMW):
    // KMW = OMW + (SIDPP / (0.00980665 * TVD)) (in kg/m3)
    let requiredKillMudWeightKgM3 = originalMudWeightKgM3;
    if (isInflux && tvdM > 0) {
      const deltaMudKgM3 = (sidppBar * 1e5) / (9.80665 * tvdM);
      requiredKillMudWeightKgM3 = originalMudWeightKgM3 + deltaMudKgM3;
    }

    return {
      isInfluxDetected: isInflux,
      influxVolumeM3: pitGainM3,
      pitGainRateM3Hr: isInflux ? pitGainM3 * 2.5 : 0,
      shutInDrillPipePressureBar: sidppBar,
      shutInCasingPressureBar: sicpBar,
      requiredKillMudWeightKgM3,
      lostCirculationStatus: 'NORMAL',
      mudLossRateM3Hr: 0,
      cumulativeLossM3: 0,
    };
  }
}
