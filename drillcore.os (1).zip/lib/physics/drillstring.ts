/**
 * DRILLCORE.OS Drill String & BHA (Bottom Hole Assembly) Engine
 * Models mechanical drill string assembly, tubular mass distributions,
 * stiffness, buoyancy factor, and axial neutral point.
 */

import { EngineeringResult } from './units';

export type ComponentType =
  | 'DRILL_PIPE'
  | 'HEAVY_WEIGHT_DRILL_PIPE'
  | 'DRILL_COLLAR'
  | 'STABILIZER'
  | 'MUD_MOTOR'
  | 'RSS'
  | 'MWD'
  | 'LWD'
  | 'JAR'
  | 'DRILL_BIT';

export interface DrillStringComponent {
  id: string;
  name: string;
  type: ComponentType;
  lengthM: number;           // m
  outerDiameterMm: number;   // mm (e.g. 127mm = 5.0")
  innerDiameterMm: number;   // mm (e.g. 108.6mm = 4.276")
  linearMassKgM: number;     // kg/m (in air)
  steelGrade: string;        // e.g. 'S-135', 'G-105', 'AISI 4145H'
  yieldStrengthMpa: number;  // MPa (e.g. 930 MPa for S-135)
  torsionalLimitKnM: number; // kN.m
  modulusOfElasticityGpa: number; // GPa (typically 207 GPa for drill pipe steel)
}

export interface BHAAssembly {
  name: string;
  bitDiameterMm: number;     // mm (e.g. 215.9mm = 8.5")
  components: DrillStringComponent[];
  totalLengthM: number;
  totalAirMassKg: number;
  neutralPointDepthM: number; // Depth where axial stress transitions from compression to tension
  bendingStiffnessAvgGpa: number;
}

export interface FullDrillString {
  totalMeasuredDepthM: number;
  mudDensityKgM3: number;
  bha: BHAAssembly;
  drillPipes: DrillStringComponent[];
  totalMassInAirKg: number;
  totalBuoyedMassKg: number;
  buoyancyFactor: number;
}

export class DrillStringEngine {
  /**
   * Buoyancy factor BF = 1 - (rho_mud / rho_steel)
   * Steel density ~ 7850 kg/m3
   */
  public static calculateBuoyancyFactor(
    mudDensityKgM3: number,
    steelDensityKgM3: number = 7850
  ): number {
    return Math.max(0.1, 1 - mudDensityKgM3 / steelDensityKgM3);
  }

  /**
   * Generates a standard high-performance directional BHA for 8-1/2" hole
   */
  public static getDefaultBHA(bitDiameterMm: number = 215.9): BHAAssembly {
    const components: DrillStringComponent[] = [
      {
        id: 'comp-1',
        name: '8-1/2" 5-Blade Matrix PDC Bit',
        type: 'DRILL_BIT',
        lengthM: 0.35,
        outerDiameterMm: bitDiameterMm,
        innerDiameterMm: 50.8,
        linearMassKgM: 145.0,
        steelGrade: 'Matrix Body / Tungsten Carbide',
        yieldStrengthMpa: 850,
        torsionalLimitKnM: 45.0,
        modulusOfElasticityGpa: 240,
      },
      {
        id: 'comp-2',
        name: '6-3/4" Rotary Steerable System (RSS Point-the-Bit)',
        type: 'RSS',
        lengthM: 4.8,
        outerDiameterMm: 171.45,
        innerDiameterMm: 57.15,
        linearMassKgM: 155.0,
        steelGrade: 'Non-Mag Austenitic Alloy',
        yieldStrengthMpa: 965,
        torsionalLimitKnM: 38.0,
        modulusOfElasticityGpa: 195,
      },
      {
        id: 'comp-3',
        name: '6-3/4" Near-Bit Stabilizer (8-7/16" Blade OD)',
        type: 'STABILIZER',
        lengthM: 1.8,
        outerDiameterMm: 214.3,
        innerDiameterMm: 57.15,
        linearMassKgM: 180.0,
        steelGrade: 'AISI 4145H Mod',
        yieldStrengthMpa: 760,
        torsionalLimitKnM: 52.0,
        modulusOfElasticityGpa: 207,
      },
      {
        id: 'comp-4',
        name: '6-3/4" MWD Telemetry & Gamma Collar',
        type: 'MWD',
        lengthM: 9.2,
        outerDiameterMm: 171.45,
        innerDiameterMm: 57.15,
        linearMassKgM: 148.0,
        steelGrade: 'Non-Mag P550',
        yieldStrengthMpa: 895,
        torsionalLimitKnM: 42.0,
        modulusOfElasticityGpa: 195,
      },
      {
        id: 'comp-5',
        name: '6-3/4" LWD Dual Resistivity & Density-Neutron Collar',
        type: 'LWD',
        lengthM: 11.5,
        outerDiameterMm: 171.45,
        innerDiameterMm: 57.15,
        linearMassKgM: 152.0,
        steelGrade: 'Non-Mag P550',
        yieldStrengthMpa: 895,
        torsionalLimitKnM: 42.0,
        modulusOfElasticityGpa: 195,
      },
      {
        id: 'comp-6',
        name: '6-1/2" Slick Drill Collars (6 joints)',
        type: 'DRILL_COLLAR',
        lengthM: 56.4,
        outerDiameterMm: 165.1,
        innerDiameterMm: 57.15,
        linearMassKgM: 142.0,
        steelGrade: 'AISI 4145H Mod',
        yieldStrengthMpa: 760,
        torsionalLimitKnM: 48.0,
        modulusOfElasticityGpa: 207,
      },
      {
        id: 'comp-7',
        name: '6-1/2" Drilling Hydraulic Jar',
        type: 'JAR',
        lengthM: 9.5,
        outerDiameterMm: 165.1,
        innerDiameterMm: 57.15,
        linearMassKgM: 135.0,
        steelGrade: 'AISI 4145H Mod',
        yieldStrengthMpa: 825,
        torsionalLimitKnM: 44.0,
        modulusOfElasticityGpa: 207,
      },
      {
        id: 'comp-8',
        name: '5" Heavy Weight Drill Pipe (15 joints)',
        type: 'HEAVY_WEIGHT_DRILL_PIPE',
        lengthM: 141.0,
        outerDiameterMm: 127.0,
        innerDiameterMm: 76.2,
        linearMassKgM: 73.5,
        steelGrade: 'AISI 4145H',
        yieldStrengthMpa: 760,
        torsionalLimitKnM: 32.0,
        modulusOfElasticityGpa: 207,
      },
    ];

    let totalLengthM = 0;
    let totalAirMassKg = 0;
    for (const c of components) {
      totalLengthM += c.lengthM;
      totalAirMassKg += c.lengthM * c.linearMassKgM;
    }

    return {
      name: '8-1/2" Steerable RSS Logging Assembly',
      bitDiameterMm,
      components,
      totalLengthM,
      totalAirMassKg,
      neutralPointDepthM: 0,
      bendingStiffnessAvgGpa: 207,
    };
  }

  /**
   * Assemble complete drill string from surface to bit at current MD
   */
  public static assembleDrillString(
    currentMdM: number,
    bha: BHAAssembly,
    mudDensityKgM3: number,
    wobKn: number = 80.0
  ): FullDrillString {
    const bf = this.calculateBuoyancyFactor(mudDensityKgM3);
    const pipeLengthNeeded = Math.max(0, currentMdM - bha.totalLengthM);

    // Standard 5" S-135 19.5 lb/ft Drill Pipe (OD 127mm, ID 108.6mm)
    const drillPipe: DrillStringComponent = {
      id: 'dp-5in-s135',
      name: '5" S-135 Drill Pipe (19.50 lb/ft NC50)',
      type: 'DRILL_PIPE',
      lengthM: pipeLengthNeeded,
      outerDiameterMm: 127.0,
      innerDiameterMm: 108.6,
      linearMassKgM: 29.02,
      steelGrade: 'S-135',
      yieldStrengthMpa: 930,
      torsionalLimitKnM: 41.5,
      modulusOfElasticityGpa: 207,
    };

    const pipeMassInAir = pipeLengthNeeded * drillPipe.linearMassKgM;
    const totalMassInAirKg = bha.totalAirMassKg + pipeMassInAir;
    const totalBuoyedMassKg = totalMassInAirKg * bf;

    // Calculate neutral point depth: where Buoyed BHA weight equals WOB
    // Weight on bit is provided by heavy drill collars and HWDP in compression
    const g = 9.80665;
    const wobRequiredN = wobKn * 1000;
    let accumulatedBuoyedWeightN = 0;
    let neutralPointAboveBitM = 0;

    for (const comp of bha.components) {
      const compBuoyedWeightN = comp.lengthM * comp.linearMassKgM * g * bf;
      if (accumulatedBuoyedWeightN + compBuoyedWeightN >= wobRequiredN) {
        const remainingN = wobRequiredN - accumulatedBuoyedWeightN;
        const fraction = remainingN / compBuoyedWeightN;
        neutralPointAboveBitM += comp.lengthM * fraction;
        break;
      } else {
        accumulatedBuoyedWeightN += compBuoyedWeightN;
        neutralPointAboveBitM += comp.lengthM;
      }
    }

    const neutralPointDepthM = currentMdM - neutralPointAboveBitM;
    bha.neutralPointDepthM = neutralPointDepthM;

    return {
      totalMeasuredDepthM: currentMdM,
      mudDensityKgM3,
      bha,
      drillPipes: [drillPipe],
      totalMassInAirKg,
      totalBuoyedMassKg,
      buoyancyFactor: bf,
    };
  }
}
