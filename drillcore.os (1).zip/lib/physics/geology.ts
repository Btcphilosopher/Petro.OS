/**
 * DRILLCORE.OS Geology & Rock Mechanics Engine
 * Models formation stratigraphy, pore pressure, fracture gradients,
 * rock strength (UCS, cohesion, Young's Modulus, Poisson's Ratio), and abrasiveness.
 */

import { EngineeringResult, ModelFidelity } from './units';

export type LithologyType =
  | 'SHALE'
  | 'SANDSTONE'
  | 'LIMESTONE'
  | 'DOLOMITE'
  | 'SILTSTONE'
  | 'CONGLOMERATE'
  | 'BASEMENT';

export type GeologicalModelStatus = 'CONCEPTUAL' | 'CALIBRATED' | 'VALIDATED';

export interface FormationLayer {
  id: string;
  name: string;
  topDepthMd: number;        // m
  baseDepthMd: number;       // m
  lithology: LithologyType;
  colorHex: string;
  pattern: string;
  
  // Physical & Reservoir Properties
  bulkDensity: number;       // kg/m3 (e.g. 2300 - 2750)
  porosity: number;          // fraction 0.0 - 0.40
  permeabilityMd: number;    // millidarcies
  waterSaturation: number;   // fraction 0.0 - 1.0
  gasSaturation: number;     // fraction 0.0 - 1.0
  oilSaturation: number;     // fraction 0.0 - 1.0
  
  // Geomechanical Properties (SI Native)
  ucsMpa: number;            // Unconfined Compressive Strength (MPa)
  tensileStrengthMpa: number;// Tensile Strength (MPa)
  cohesionMpa: number;       // Cohesion (MPa)
  frictionAngleDeg: number;  // Internal friction angle (degrees)
  youngsModulusGpa: number;  // Young's Modulus (GPa)
  poissonsRatio: number;     // Poisson's ratio (0.15 - 0.35)
  caiAbrasiveness: number;   // Cerchar Abrasiveness Index (0.5 - 5.0)
  
  // Pressure & Temperature Gradients
  porePressureGradSg: number;   // Pore pressure equivalent mud weight (sg or ppg equivalent)
  fractureGradSg: number;       // Fracture pressure gradient (sg equivalent)
  tempGradientCPerKm: number;   // Geothermal gradient (°C / km, typical ~25 - 35)

  // Status & Validation
  modelStatus: GeologicalModelStatus;
}

export class GeologyEngine {
  /**
   * Default synthetic well geological stratigraphy (3,000m exploration well)
   */
  public static getDefaultFormationModel(): FormationLayer[] {
    return [
      {
        id: 'layer-1',
        name: 'Surface Tertiary Silt & Sand',
        topDepthMd: 0,
        baseDepthMd: 450,
        lithology: 'SILTSTONE',
        colorHex: '#d97706',
        pattern: 'dots',
        bulkDensity: 2150,
        porosity: 0.28,
        permeabilityMd: 120,
        waterSaturation: 0.95,
        gasSaturation: 0.0,
        oilSaturation: 0.0,
        ucsMpa: 18.5,
        tensileStrengthMpa: 1.8,
        cohesionMpa: 4.2,
        frictionAngleDeg: 28,
        youngsModulusGpa: 8.5,
        poissonsRatio: 0.32,
        caiAbrasiveness: 1.2,
        porePressureGradSg: 1.03, // Hydrostatic freshwater/seawater
        fractureGradSg: 1.45,
        tempGradientCPerKm: 28.0,
        modelStatus: 'VALIDATED',
      },
      {
        id: 'layer-2',
        name: 'Upper Nordland Shale',
        topDepthMd: 450,
        baseDepthMd: 1250,
        lithology: 'SHALE',
        colorHex: '#64748b',
        pattern: 'lines',
        bulkDensity: 2320,
        porosity: 0.16,
        permeabilityMd: 0.005,
        waterSaturation: 0.90,
        gasSaturation: 0.05,
        oilSaturation: 0.0,
        ucsMpa: 34.0,
        tensileStrengthMpa: 3.2,
        cohesionMpa: 8.5,
        frictionAngleDeg: 22,
        youngsModulusGpa: 14.0,
        poissonsRatio: 0.29,
        caiAbrasiveness: 1.6,
        porePressureGradSg: 1.10,
        fractureGradSg: 1.62,
        tempGradientCPerKm: 30.0,
        modelStatus: 'CALIBRATED',
      },
      {
        id: 'layer-3',
        name: 'Chalk & Limestone Cap',
        topDepthMd: 1250,
        baseDepthMd: 1950,
        lithology: 'LIMESTONE',
        colorHex: '#38bdf8',
        pattern: 'brick',
        bulkDensity: 2540,
        porosity: 0.12,
        permeabilityMd: 4.5,
        waterSaturation: 0.80,
        gasSaturation: 0.15,
        oilSaturation: 0.05,
        ucsMpa: 85.0,
        tensileStrengthMpa: 8.0,
        cohesionMpa: 18.0,
        frictionAngleDeg: 36,
        youngsModulusGpa: 28.0,
        poissonsRatio: 0.25,
        caiAbrasiveness: 2.8,
        porePressureGradSg: 1.15,
        fractureGradSg: 1.78,
        tempGradientCPerKm: 31.0,
        modelStatus: 'CALIBRATED',
      },
      {
        id: 'layer-4',
        name: 'Brent Reservoir Sandstone',
        topDepthMd: 1950,
        baseDepthMd: 2600,
        lithology: 'SANDSTONE',
        colorHex: '#eab308',
        pattern: 'dots',
        bulkDensity: 2420,
        porosity: 0.22,
        permeabilityMd: 350,
        waterSaturation: 0.30,
        gasSaturation: 0.20,
        oilSaturation: 0.50,
        ucsMpa: 52.0,
        tensileStrengthMpa: 5.0,
        cohesionMpa: 12.0,
        frictionAngleDeg: 34,
        youngsModulusGpa: 22.0,
        poissonsRatio: 0.21,
        caiAbrasiveness: 3.5,
        porePressureGradSg: 1.22, // Overpressured reservoir
        fractureGradSg: 1.85,
        tempGradientCPerKm: 32.0,
        modelStatus: 'VALIDATED',
      },
      {
        id: 'layer-5',
        name: 'Basal Dolomite & Hard Stringers',
        topDepthMd: 2600,
        baseDepthMd: 3000,
        lithology: 'DOLOMITE',
        colorHex: '#a855f7',
        pattern: 'diamond',
        bulkDensity: 2710,
        porosity: 0.06,
        permeabilityMd: 0.8,
        waterSaturation: 0.60,
        gasSaturation: 0.40,
        oilSaturation: 0.0,
        ucsMpa: 125.0, // High strength rock
        tensileStrengthMpa: 11.5,
        cohesionMpa: 26.0,
        frictionAngleDeg: 42,
        youngsModulusGpa: 45.0,
        poissonsRatio: 0.24,
        caiAbrasiveness: 4.2,
        porePressureGradSg: 1.28,
        fractureGradSg: 1.95,
        tempGradientCPerKm: 33.0,
        modelStatus: 'CONCEPTUAL',
      },
    ];
  }

  /**
   * Find the formation layer at a given Measured Depth
   */
  public static getLayerAtDepth(layers: FormationLayer[], depthMd: number): FormationLayer {
    for (const layer of layers) {
      if (depthMd >= layer.topDepthMd && depthMd < layer.baseDepthMd) {
        return layer;
      }
    }
    return layers[layers.length - 1];
  }

  /**
   * Calculate formation temperature profile based on surface temp and geothermal gradient
   */
  public static calculateFormationTemperature(
    surfaceTempC: number,
    tvdM: number,
    gradCPerKm: number = 30.0
  ): EngineeringResult<number> {
    const tempC = surfaceTempC + (tvdM / 1000) * gradCPerKm;
    return {
      value: tempC,
      unit: '°C',
      equation: 'T_formation = T_surface + (TVD / 1000) * Grad_thermal',
      inputs: { surfaceTempC, tvdM, gradCPerKm },
      assumptions: ['Linear 1D conductive geothermal equilibrium', 'Steady-state undisturbed crust'],
      uncertainty: { standardDeviation: 1.5, relativeErrorPercent: 3.0 },
      validityRange: { min: 0, max: 250, notes: 'Valid for crustal depths up to 8,000m' },
      modelVersion: 'GEOLOGY-THERMAL-V2.1',
      fidelity: 'FIDELITY_2',
    };
  }

  /**
   * Calculates Mohr-Coulomb rock failure envelope:
   * Shear Strength tau = Cohesion + sigma_n * tan(friction_angle)
   */
  public static calculateConfinedRockStrength(
    ucsMpa: number,
    frictionAngleDeg: number,
    confiningPressureMpa: number
  ): EngineeringResult<number> {
    const phiRad = (frictionAngleDeg * Math.PI) / 180;
    const q = (1 + Math.sin(phiRad)) / (1 - Math.sin(phiRad));
    const confinedStrengthMpa = ucsMpa + confiningPressureMpa * q;

    return {
      value: confinedStrengthMpa,
      unit: 'MPa',
      equation: 'UCS_confined = UCS_0 + sigma_3 * (1 + sin(phi)) / (1 - sin(phi))',
      inputs: { ucsMpa, frictionAngleDeg, confiningPressureMpa },
      assumptions: ['Mohr-Coulomb linear shear failure criterion', 'Isotropic intact rock core'],
      uncertainty: { standardDeviation: 4.2, relativeErrorPercent: 7.5 },
      validityRange: { min: 0, max: 800, notes: 'Valid under compressive triaxial conditions' },
      modelVersion: 'ROCK-MOHR-COULOMB-V1.4',
      fidelity: 'FIDELITY_2',
    };
  }
}
