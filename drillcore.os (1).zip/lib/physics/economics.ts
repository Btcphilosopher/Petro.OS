/**
 * DRILLCORE.OS Drilling Economics, Cost Engine & NPT Analytics
 * Models operational expenditures, day rates, cost per meter, bit replacement economics,
 * Non-Productive Time (NPT) breakdowns, and rig energy & carbon emission accounting.
 */

import { EngineeringResult } from './units';

export type NptCategory =
  | 'MECHANICAL'
  | 'FORMATION'
  | 'DRILLING'
  | 'MUD'
  | 'PRESSURE'
  | 'WAITING'
  | 'LOGISTICS'
  | 'WEATHER'
  | 'MAINTENANCE'
  | 'OTHER';

export interface NptRecord {
  id: string;
  category: NptCategory;
  durationHours: number;
  costUsd: number;
  description: string;
  timestamp: string;
}

export interface DrillingCostModel {
  rigDayRateUsd: number;        // e.g. 45,000 USD/day ($1,875/hr)
  personnelCostPerHourUsd: number; // e.g. $850/hr
  fuelCostPerLiterUsd: number;  // e.g. $1.15/L
  mudCostPerM3Usd: number;      // e.g. $280/m3
  bhaRentalCostPerHourUsd: number; // e.g. $650/hr
  currentBitCostUsd: number;    // e.g. $38,000 for 8.5" PDC
  casingAndCementCostUsd: number; // Cumulative casing/cement costs
  loggingCostUsd: number;       // MWD/LWD service cost
}

export interface DrillingEconomicsResult {
  totalCostUsd: number;
  costPerMeterUsd: number;
  costPerFootUsd: number;
  costPerHourUsd: number;
  plannedCostUsd: number;
  costVarianceUsd: number;
  drillingTimeHours: number;
  trippingTimeHours: number;
  connectionTimeHours: number;
  nptHoursTotal: number;
  nptCostTotalUsd: number;
  nptPercentage: number;
  nptRecords: NptRecord[];
  
  // Bit Replacement Economic Comparison
  bitEconomicsComparison: {
    cheaperBitCostPerMeter: number;
    premiumBitCostPerMeter: number;
    recommendedBitStrategy: 'KEEP_CURRENT_BIT' | 'UPGRADE_PREMIUM_PDC' | 'RUN_CHEAPER_OFFSET';
    savingsPerWellUsd: number;
  };

  // Rig Power & Carbon Emissions Accounting
  totalEnergyKwh: number;
  fuelConsumedLiters: number;
  co2EmissionsTonnes: number;
}

export class EconomicsEngine {
  public static getDefaultCostModel(): DrillingCostModel {
    return {
      rigDayRateUsd: 48000, // $2,000/hr
      personnelCostPerHourUsd: 950,
      fuelCostPerLiterUsd: 1.18,
      mudCostPerM3Usd: 320,
      bhaRentalCostPerHourUsd: 720,
      currentBitCostUsd: 42000,
      casingAndCementCostUsd: 285000,
      loggingCostUsd: 95000,
    };
  }

  public static getDefaultNptRecords(): NptRecord[] {
    return [
      {
        id: 'npt-1',
        category: 'MECHANICAL',
        durationHours: 3.5,
        costUsd: 12845,
        description: 'Top drive washpipe packing leak repair and pressure test',
        timestamp: 'Day 2 08:30',
      },
      {
        id: 'npt-2',
        category: 'DRILLING',
        durationHours: 2.0,
        costUsd: 7340,
        description: 'Circulated hole clean after high cuttings loading spike in shale section',
        timestamp: 'Day 3 14:15',
      },
      {
        id: 'npt-3',
        category: 'MUD',
        durationHours: 1.8,
        costUsd: 6606,
        description: 'Weighted up active mud system with barite to mitigate background gas influx',
        timestamp: 'Day 4 19:40',
      },
    ];
  }

  /**
   * Calculates comprehensive drilling economics, cost per meter, and bit comparison
   */
  public static calculateEconomics(
    depthM: number,
    drillingHours: number,
    trippingHours: number,
    connectionHours: number,
    model: DrillingCostModel,
    nptRecords: NptRecord[] = this.getDefaultNptRecords(),
    avgTopDrivePowerKw: number = 380,
    avgPumpsPowerKw: number = 520
  ): EngineeringResult<DrillingEconomicsResult> {
    const rigHourlyRate = model.rigDayRateUsd / 24;
    const baseRigAndCrewHourly = rigHourlyRate + model.personnelCostPerHourUsd + model.bhaRentalCostPerHourUsd;

    // Total NPT
    let nptHoursTotal = 0;
    let nptCostTotalUsd = 0;
    for (const rec of nptRecords) {
      nptHoursTotal += rec.durationHours;
      nptCostTotalUsd += rec.costUsd;
    }

    const totalOperatingHours = drillingHours + trippingHours + connectionHours + nptHoursTotal;

    // Power, Fuel & Emissions (Rig diesel generator consumes ~0.24 L / kWh)
    const totalPowerKw = avgTopDrivePowerKw + avgPumpsPowerKw + 150; // +150kW base camp load
    const totalEnergyKwh = totalPowerKw * totalOperatingHours;
    const fuelConsumedLiters = totalEnergyKwh * 0.245;
    const fuelCostUsd = fuelConsumedLiters * model.fuelCostPerLiterUsd;
    
    // Emissions factor: ~2.68 kg CO2 per liter of diesel fuel
    const co2EmissionsTonnes = (fuelConsumedLiters * 2.68) / 1000;

    // Time-based cost
    const timeBasedCostUsd = totalOperatingHours * baseRigAndCrewHourly + fuelCostUsd;

    // Total Well Cost
    const totalCostUsd =
      timeBasedCostUsd +
      model.currentBitCostUsd +
      model.casingAndCementCostUsd +
      model.loggingCostUsd +
      (depthM / 10) * 12.0; // Mud consumption per meter drilled

    const costPerMeterUsd = depthM > 0 ? totalCostUsd / depthM : 0;
    const costPerFootUsd = costPerMeterUsd / 3.28084;
    const costPerHourUsd = totalOperatingHours > 0 ? totalCostUsd / totalOperatingHours : 0;

    const plannedCostUsd = 1450000 + depthM * 380;
    const costVarianceUsd = totalCostUsd - plannedCostUsd;
    const nptPercentage = (nptHoursTotal / Math.max(1, totalOperatingHours)) * 100;

    // Bit economics comparison (Cheaper bit vs Premium long life bit)
    // C_m = (Bit_Cost + Hourly_Rate * (t_drill + t_trip)) / Meters_drilled
    const tripTimePerRunHours = 12.0;
    
    // Cheaper Bit: $22k cost, 250m life, 18 m/hr avg ROP
    const cheapBitLifeM = 250;
    const cheapBitDrillHrs = cheapBitLifeM / 18.0;
    const cheaperBitCostPerMeter =
      (22000 + baseRigAndCrewHourly * (cheapBitDrillHrs + tripTimePerRunHours)) / cheapBitLifeM;

    // Premium Bit: $45k cost, 750m life, 26 m/hr avg ROP
    const premBitLifeM = 750;
    const premBitDrillHrs = premBitLifeM / 26.0;
    const premiumBitCostPerMeter =
      (45000 + baseRigAndCrewHourly * (premBitDrillHrs + tripTimePerRunHours)) / premBitLifeM;

    const savingsPerWellUsd = Math.max(0, (cheaperBitCostPerMeter - premiumBitCostPerMeter) * 1800);

    const result: DrillingEconomicsResult = {
      totalCostUsd,
      costPerMeterUsd,
      costPerFootUsd,
      costPerHourUsd,
      plannedCostUsd,
      costVarianceUsd,
      drillingTimeHours: drillingHours,
      trippingTimeHours: trippingHours,
      connectionTimeHours: connectionHours,
      nptHoursTotal,
      nptCostTotalUsd,
      nptPercentage,
      nptRecords,
      bitEconomicsComparison: {
        cheaperBitCostPerMeter,
        premiumBitCostPerMeter,
        recommendedBitStrategy: premiumBitCostPerMeter < cheaperBitCostPerMeter ? 'UPGRADE_PREMIUM_PDC' : 'RUN_CHEAPER_OFFSET',
        savingsPerWellUsd,
      },
      totalEnergyKwh,
      fuelConsumedLiters,
      co2EmissionsTonnes,
    };

    return {
      value: result,
      unit: 'USD / USD/m',
      equation: 'C_total = Sum(t_i * Rate_rig) + Cost_bit + Cost_casing + Cost_mud + NPT; C_m = (C_bit + Rate*(t_d + t_trip))/Delta_D',
      inputs: { depthM, drillingHours, trippingHours, nptHoursTotal, rigDayRateUsd: model.rigDayRateUsd },
      assumptions: ['Standard SPE drilling accounting breakdown', 'Diesel power generation at 0.245 L/kWh'],
      uncertainty: { standardDeviation: 15000, relativeErrorPercent: 3.2 },
      validityRange: { min: 0, max: 1e8, notes: 'Valid across full well life cycle' },
      modelVersion: 'ECON-DRILL-COST-V2.5',
      fidelity: 'FIDELITY_2',
    };
  }
}
