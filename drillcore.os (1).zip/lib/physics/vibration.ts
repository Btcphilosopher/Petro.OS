/**
 * DRILLCORE.OS Drilling Vibration & Stick-Slip Dynamics Engine
 * Models torsional stick-slip limit cycles, axial bit-bounce,
 * lateral BHA whirl, and generates real-time vibration telemetry & stability maps.
 */

import { EngineeringResult } from './units';

export type VibrationSeverity = 'LOW_SAFE' | 'MODERATE' | 'HIGH_ALERT' | 'CRITICAL_DAMAGE';

export interface VibrationTelemetry {
  axialVibrationG: number;       // Axial acceleration RMS (g)
  lateralVibrationG: number;     // Lateral acceleration RMS (g)
  torsionalVibrationPercent: number; // Stick-slip severity index (0 - 200%)
  bitRpmInstantaneous: number;   // Actual instantaneous bit RPM
  bitTorqueInstantaneousKnM: number; // Actual instantaneous bit torque (kN.m)
  isStickSlipActive: boolean;
  isBitBounceActive: boolean;
  isWhirlActive: boolean;
  severity: VibrationSeverity;
}

export interface StickSlipPhasePoint {
  timeSec: number;
  surfaceRpm: number;
  bitRpm: number;
  torqueKnM: number;
  relativeAngleRad: number;
}

export interface StabilityMapPoint {
  wobKn: number;
  rpm: number;
  stickSlipSeverity: number;     // 0 - 100%
  isStable: boolean;
}

export class VibrationEngine {
  /**
   * Evaluates instantaneous 2-DOF torsional pendulum vibration state
   */
  public static simulateStickSlipStep(
    surfaceRpm: number,
    wobKn: number,
    drillStringLengthM: number,
    rockUcsMpa: number,
    timeSec: number
  ): VibrationTelemetry {
    // Torsional stiffness K_t = (G * J) / L
    // G for steel = 79 GPa, J for 5" DP = ~1.2e-5 m4
    const G = 79e9;
    const J = 1.2e-5;
    const Kt = (G * J) / Math.max(100, drillStringLengthM); // N.m/rad

    // Critical RPM threshold where stick-slip typically is mitigated:
    // High WOB + Low RPM + High Rock Strength -> Severe Stick-Slip
    const stickSlipRiskFactor = (wobKn * 1.8 * Math.sqrt(rockUcsMpa / 30.0)) / Math.max(10, surfaceRpm);

    let isStickSlip = false;
    let bitRpm = surfaceRpm;
    let torsionalSeverity = 15.0; // Baseline low vibration
    let torqueInstant = (wobKn * 0.035) + 1.2;

    if (stickSlipRiskFactor > 18.0) {
      // Severe stick-slip limit cycle active
      isStickSlip = true;
      torsionalSeverity = Math.min(185, 45 + stickSlipRiskFactor * 4.5);

      // Period of oscillation T ~ 2 * pi * sqrt(J_bha / K_t) ~ 2.0 to 4.5 seconds
      const periodSec = 3.2;
      const phase = (timeSec % periodSec) / periodSec; // 0.0 to 1.0

      if (phase < 0.45) {
        // STICK PHASE: Bit is locked (0 RPM), torque winds up
        bitRpm = 0;
        torqueInstant = (wobKn * 0.035) * (1.0 + phase * 2.8);
      } else {
        // SLIP PHASE: Bit releases violently, spinning up to 2x - 2.8x surface RPM
        const slipPhase = (phase - 0.45) / 0.55;
        bitRpm = surfaceRpm * (2.4 * Math.sin(slipPhase * Math.PI));
        torqueInstant = (wobKn * 0.035) * (0.3 + 0.5 * Math.cos(slipPhase * Math.PI));
      }
    } else {
      // Stable regime with small random harmonic ripple
      const ripple = 0.08 * Math.sin(timeSec * 8.5);
      bitRpm = Math.max(0, surfaceRpm * (1 + ripple));
      torsionalSeverity = Math.max(5, stickSlipRiskFactor * 2.2);
    }

    // Axial vibration (bit bounce) risk increases at very high WOB & hard formations
    const axialG = (wobKn / 160.0) * (rockUcsMpa / 100.0) * 1.8 + 0.2;
    const isBitBounce = axialG > 2.8;

    // Lateral vibration (whirl) risk increases at high RPM and low WOB
    const lateralG = (surfaceRpm / 180.0) * (40.0 / Math.max(20, wobKn)) * 2.2 + 0.3;
    const isWhirl = lateralG > 3.2;

    let severity: VibrationSeverity = 'LOW_SAFE';
    if (torsionalSeverity > 120 || axialG > 3.5 || lateralG > 4.0) {
      severity = 'CRITICAL_DAMAGE';
    } else if (torsionalSeverity > 80 || axialG > 2.5 || lateralG > 2.8) {
      severity = 'HIGH_ALERT';
    } else if (torsionalSeverity > 40 || axialG > 1.5 || lateralG > 1.8) {
      severity = 'MODERATE';
    }

    return {
      axialVibrationG: axialG,
      lateralVibrationG: lateralG,
      torsionalVibrationPercent: torsionalSeverity,
      bitRpmInstantaneous: bitRpm,
      bitTorqueInstantaneousKnM: torqueInstant,
      isStickSlipActive: isStickSlip,
      isBitBounceActive: isBitBounce,
      isWhirlActive: isWhirl,
      severity,
    };
  }

  /**
   * Generates a Stick-Slip Phase Plane trajectory (Bit RPM vs Torque) over time
   */
  public static generatePhasePlaneTrajectory(
    surfaceRpm: number,
    wobKn: number,
    depthM: number,
    rockUcsMpa: number,
    steps: number = 60
  ): StickSlipPhasePoint[] {
    const points: StickSlipPhasePoint[] = [];
    const dt = 0.08;

    for (let i = 0; i < steps; i++) {
      const t = i * dt;
      const telem = this.simulateStickSlipStep(surfaceRpm, wobKn, depthM, rockUcsMpa, t);
      points.push({
        timeSec: t,
        surfaceRpm,
        bitRpm: telem.bitRpmInstantaneous,
        torqueKnM: telem.bitTorqueInstantaneousKnM,
        relativeAngleRad: ((surfaceRpm - telem.bitRpmInstantaneous) * (2 * Math.PI / 60)) * t,
      });
    }

    return points;
  }

  /**
   * Generates a 2D Stability Map: WOB vs RPM answering
   * "Which combinations of RPM and WOB increase stick-slip risk?"
   */
  public static generateStabilityMap(
    depthM: number,
    rockUcsMpa: number
  ): StabilityMapPoint[] {
    const points: StabilityMapPoint[] = [];
    const wobValues = [40, 60, 80, 100, 120, 140, 160];
    const rpmValues = [40, 60, 80, 100, 120, 140, 160, 180, 200];

    for (const wob of wobValues) {
      for (const rpm of rpmValues) {
        const risk = (wob * 1.8 * Math.sqrt(rockUcsMpa / 30.0)) / Math.max(10, rpm);
        const severity = Math.min(100, (risk / 25.0) * 100);
        points.push({
          wobKn: wob,
          rpm,
          stickSlipSeverity: severity,
          isStable: severity < 60,
        });
      }
    }

    return points;
  }
}
