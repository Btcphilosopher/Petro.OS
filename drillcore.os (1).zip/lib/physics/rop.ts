/**
 * DRILLCORE.OS Rate of Penetration (ROP), Bit Mechanics & MSE Engine
 * Implements mechanistic rock-cutting physics, Bingham empirical model,
 * Teale Mechanical Specific Energy (MSE), and bit wear dynamics.
 */

import { EngineeringResult } from './units';
import { FormationLayer } from './geology';

export type BitType = 'PDC' | 'ROLLER_CONE' | 'HYBRID';
export type RopModelType = 'MECHANISTIC' | 'EMPIRICAL' | 'DATA_DRIVEN' | 'HYBRID';

export interface DrillBitSpecs {
  id: string;
  name: string;
  bitType: BitType;
  diameterMm: number;        // mm (e.g. 215.9mm = 8.5")
  bladeCount: number;        // e.g. 5 or 6 blades
  cutterCount: number;       // e.g. 38 cutters
  cutterSizeMm: number;      // e.g. 13mm or 16mm PDC cutters
  nozzleCount: number;       // e.g. 5 nozzles
  nozzleSizes32nds: number[];// e.g. [12, 12, 12, 14, 14] in 32nds of an inch
  tfaMm2: number;            // Total Flow Area (mm2)
  maxWobKn: number;          // Max allowable WOB (kN) (e.g. 180 kN)
  maxRpm: number;            // Max allowable RPM (e.g. 220 RPM)
  dullGrade: number;         // 0 (Brand New) to 8 (Completely Worn Out)
  operatingHours: number;    // Cumulative rotating hours on bit
  cumulativeMetersDrilled: number; // m
}

export interface RopCalculationResult {
  ropMHr: number;            // Rate of Penetration (m/hr)
  ropFtHr: number;           // ROP (ft/hr)
  torqueKnM: number;         // Calculated Bit Torque (kN.m)
  mseMpa: number;            // Mechanical Specific Energy (MPa)
  drillingEfficiencyPercent: number; // 100 * (Rock UCS / MSE)
  rockVolumeRemovedM3Hr: number;     // m3/hr
  rockMassRemovedKgS: number;        // kg/s
  cutterWearIncrementPerHr: number;  // Dull grade delta per hour
  modelUsed: RopModelType;
}

export class RopEngine {
  /**
   * Calculates Total Flow Area (TFA) in mm² from nozzle sizes in 32nds of an inch
   */
  public static calculateTfa(nozzleSizes32nds: number[]): number {
    let tfaMm2 = 0;
    for (const size of nozzleSizes32nds) {
      const diamMm = (size / 32) * 25.4;
      const area = (Math.PI / 4) * diamMm * diamMm;
      tfaMm2 += area;
    }
    return tfaMm2;
  }

  public static getDefaultPdcBit(): DrillBitSpecs {
    const nozzles = [12, 12, 12, 14, 14];
    return {
      id: 'BIT-PDC-850-MD513',
      name: 'Matrix DrillCore MD513 8-1/2" PDC Bit',
      bitType: 'PDC',
      diameterMm: 215.9,
      bladeCount: 5,
      cutterCount: 42,
      cutterSizeMm: 13.0,
      nozzleCount: 5,
      nozzleSizes32nds: nozzles,
      tfaMm2: this.calculateTfa(nozzles),
      maxWobKn: 160.0,
      maxRpm: 220,
      dullGrade: 1.2, // Minor initial wear
      operatingHours: 14.5,
      cumulativeMetersDrilled: 380.0,
    };
  }

  /**
   * Mechanistic ROP model based on cutter engagement depth, formation UCS,
   * WOB, RPM, hydraulic cleaning efficiency, and bit dull state.
   */
  public static calculateMechanisticRop(
    wobKn: number,
    rpm: number,
    bit: DrillBitSpecs,
    formation: FormationLayer,
    flowRateLs: number,
    mudDensityKgM3: number,
    mlResidualOffset: number = 0.0
  ): EngineeringResult<RopCalculationResult> {
    const bitRadiusM = (bit.diameterMm / 1000) / 2;
    const holeAreaM2 = Math.PI * bitRadiusM * bitRadiusM;

    // Rock confined strength in MPa
    const ucsMpa = formation.ucsMpa;
    
    // Threshold WOB required to initiate rock indentation (kN)
    const thresholdWobKn = (bit.diameterMm / 25.4) * 0.45 * (ucsMpa / 35.0);
    const effectiveWobKn = Math.max(0.5, wobKn - thresholdWobKn);

    // Wear factor: ROP degrades exponentially as dull grade increases from 0 to 8
    const wearFactor = Math.exp(-0.18 * bit.dullGrade);

    // Hydraulic impact cleaning factor: clean hole promotes cutter penetration
    // Q in m3/s
    const qM3s = flowRateLs / 1000;
    const tfaM2 = bit.tfaMm2 / 1e6;
    const nozzleVelocityMs = qM3s / tfaM2;
    const hydraulicHhp = (0.5 * mudDensityKgM3 * qM3s * nozzleVelocityMs * nozzleVelocityMs) / 1000; // kW
    const hydraulicCleaningFactor = Math.min(1.35, 0.75 + (hydraulicHhp / 250.0) * 0.4);

    // Mechanistic cutting coefficient K (calibrated for PDC shearing)
    const kPdc = 0.082; // Base coefficient

    // Base Mechanistic ROP in m/hr
    // ROP = K * (RPM / 60) * (WOB / D_bit) * (1 / UCS)^0.85 * wearFactor * cleaning
    const baseRopMHr =
      (kPdc * (rpm / 60) * (effectiveWobKn / (bit.diameterMm / 1000)) * (100.0 / Math.pow(ucsMpa, 0.88))) *
      wearFactor *
      hydraulicCleaningFactor;

    // Final ROP with optional ML residual correction for Hybrid Model
    const finalRopMHr = Math.max(0.2, baseRopMHr + mlResidualOffset);
    const ropFtHr = finalRopMHr * 3.28084;

    // Bit Torque calculation: T = (1/3) * mu_rock * WOB * D_bit + parasitic drag
    const muRock = 0.38 + (formation.frictionAngleDeg / 100.0);
    const torqueKnM = (1.0 / 3.0) * muRock * (wobKn) * (bit.diameterMm / 1000) + 0.15;

    // Teale Mechanical Specific Energy (MSE) in MPa:
    // MSE = (WOB / A_hole) + (120 * pi * RPM * Torque) / (A_hole * ROP_m/hr)
    // In SI: WOB in N, A_hole in m2 -> Pa -> / 1e6 -> MPa
    const wobN = wobKn * 1000;
    const torqueNm = torqueKnM * 1000;
    const ropMs = finalRopMHr / 3600;

    const mseAxialMpa = (wobN / holeAreaM2) / 1e6;
    const mseTorsionalMpa = ((2 * Math.PI * (rpm / 60) * torqueNm) / (holeAreaM2 * ropMs)) / 1e6;
    const totalMseMpa = mseAxialMpa + mseTorsionalMpa;

    // Drilling efficiency = (Rock UCS / MSE) * 100%
    const drillingEfficiencyPercent = Math.min(100, Math.max(1, (ucsMpa / totalMseMpa) * 100));

    // Rock removal rate
    const rockVolumeRemovedM3Hr = holeAreaM2 * finalRopMHr;
    const rockMassRemovedKgS = (rockVolumeRemovedM3Hr * formation.bulkDensity) / 3600;

    // Wear increment rate per hour
    // Abrasiveness CAI and high MSE accelerate bit cutter wear
    const cutterWearIncrementPerHr = (formation.caiAbrasiveness / 3.5) * (totalMseMpa / 350.0) * 0.045;

    const result: RopCalculationResult = {
      ropMHr: finalRopMHr,
      ropFtHr,
      torqueKnM,
      mseMpa: totalMseMpa,
      drillingEfficiencyPercent,
      rockVolumeRemovedM3Hr,
      rockMassRemovedKgS,
      cutterWearIncrementPerHr,
      modelUsed: mlResidualOffset !== 0 ? 'HYBRID' : 'MECHANISTIC',
    };

    return {
      value: result,
      unit: 'm/hr / MPa',
      equation: 'ROP = K_pdc * (RPM) * (WOB / D) * (1 / UCS)^0.88 * exp(-0.18*Dull) * F_hyd; MSE = WOB/A + 2*pi*N*T/(A*v)',
      inputs: {
        wobKn,
        rpm,
        bitDiameterMm: bit.diameterMm,
        bitDullGrade: bit.dullGrade,
        formationUcsMpa: ucsMpa,
        caiAbrasiveness: formation.caiAbrasiveness,
        flowRateLs,
      },
      assumptions: [
        'Pure ductile rock shearing mode (PDC matrix)',
        'Continuous cuttings evacuation without bit balling',
        'Isotropic drillability across cutter contact profile',
      ],
      uncertainty: { standardDeviation: 1.8, relativeErrorPercent: 6.5 },
      validityRange: { min: 0.1, max: 120.0, notes: 'Valid for WOB up to bit manufacturer limit' },
      modelVersion: 'PHYSICS-ROP-BOURGOYNE-HARELAND-V3.2',
      fidelity: 'FIDELITY_2',
    };
  }
}
