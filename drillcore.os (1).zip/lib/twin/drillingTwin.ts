/**
 * DRILLCORE.OS Authoritative Digital Twin Engine (DrillingTwin)
 * Represents the complete physical well, equipment, rock-fluid interaction,
 * sensor stream, event-sourced audit log, and real-time state machine.
 */

import { UnitConverter, EngineeringResult } from '../physics/units';
import { SurveyStation, TrajectoryEngine, TrajectoryMethod } from '../physics/trajectory';
import { FormationLayer, GeologyEngine } from '../physics/geology';
import { RigConfig, RigEngine, HoistingState, TopDriveState } from '../physics/rig';
import { DrillStringComponent, BHAAssembly, FullDrillString, DrillStringEngine } from '../physics/drillstring';
import { DrillBitSpecs, RopEngine, RopCalculationResult } from '../physics/rop';
import { TorqueDragEngine, TorqueDragResults, OperatingMode } from '../physics/torqueDrag';
import { VibrationEngine, VibrationTelemetry } from '../physics/vibration';
import { HydraulicsEngine, MudProperties, HydraulicsResult } from '../physics/hydraulics';
import { CuttingsAndWellControlEngine, CuttingsTransportResult, WellControlState } from '../physics/cuttingsAndWellControl';
import { EconomicsEngine, DrillingCostModel, DrillingEconomicsResult, NptRecord } from '../physics/economics';
import { RQuantMLEngine, TelemetryAnomaly, FormationClassificationResult, BitWearPrediction } from '../r-quant/machineLearning';
import { OptimizationEngine, OptimizationResult } from '../r-quant/optimisation';

export type DrillingRegime =
  | 'ROTATING_DRILLING'
  | 'SLIDING'
  | 'CONNECTION'
  | 'CIRCULATING'
  | 'TRIPPING_IN'
  | 'TRIPPING_OUT'
  | 'REAMING'
  | 'BACKREAMING'
  | 'STATIC';

export type SensorQuality =
  | 'VALID'
  | 'ESTIMATED'
  | 'STALE'
  | 'MISSING'
  | 'FAULT'
  | 'CALIBRATION_REQUIRED';

export interface SensorMeasurement<T = number> {
  value: T;
  unit: string;
  timestamp: string;
  sensorId: string;
  quality: SensorQuality;
  uncertainty: number;
}

export type DrillingEventType =
  | 'SPUD'
  | 'DRILLING_STARTED'
  | 'FORMATION_CHANGE'
  | 'WOB_CHANGED'
  | 'RPM_CHANGED'
  | 'FLOW_CHANGED'
  | 'PRESSURE_ANOMALY'
  | 'STICK_SLIP_DETECTED'
  | 'CONNECTION_STARTED'
  | 'CONNECTION_COMPLETED'
  | 'BIT_CHANGE'
  | 'BHA_CHANGE'
  | 'CASING_RUN'
  | 'CEMENTING'
  | 'LOSS_EVENT'
  | 'KICK_EVENT'
  | 'TARGET_DEPTH_REACHED';

export interface DrillingEvent {
  id: string;
  type: DrillingEventType;
  timestamp: string;
  depthMdM: number;
  description: string;
  dataSnapshot: Record<string, number | string | boolean>;
}

export interface TelemetryFrame {
  timestamp: string;
  depthMdM: number;
  tvdM: number;
  wobKn: number;
  surfaceRpm: number;
  flowRateLs: number;
  surfaceTorqueKnM: number;
  standpipePressureBar: number;
  ropMHr: number;
  mseMpa: number;
  ecdSg: number;
  vibrationG: number;
  gammaRayApi: number;
  deepResistivityOhmm: number;
  formationName: string;
  regime: DrillingRegime;
}

export interface DigitalTwinState {
  // Well Metadata
  wellId: string;
  wellName: string;
  field: string;
  plannedDepthM: number;
  currentDepthMdM: number;
  currentTvdM: number;
  casingShoeDepthM: number;
  holeDiameterMm: number;

  // Active Control Inputs
  controlWobKn: number;
  controlRpm: number;
  controlFlowRateLs: number;
  mudDensityKgM3: number;

  // State Machine
  regime: DrillingRegime;
  isSimulating: boolean;
  simulationSpeed: number; // 1x, 5x, 20x, 100x

  // Subsystem States
  trajectory: SurveyStation[];
  plannedTrajectory: SurveyStation[];
  formations: FormationLayer[];
  currentFormation: FormationLayer;
  rig: RigConfig;
  hoisting: HoistingState;
  topDrive: TopDriveState;
  bha: BHAAssembly;
  drillString: FullDrillString;
  bit: DrillBitSpecs;
  mud: MudProperties;
  
  // Physics Outputs
  ropResult: RopCalculationResult;
  hydraulicsResult: HydraulicsResult;
  vibrationTelemetry: VibrationTelemetry;
  cuttingsResult: CuttingsTransportResult;
  torqueDragResult: TorqueDragResults;
  wellControlState: WellControlState;
  economicsResult: DrillingEconomicsResult;

  // R Quant & ML Outputs
  anomalies: TelemetryAnomaly[];
  formationClass: FormationClassificationResult;
  bitWearPred: BitWearPrediction;
  optimizationResult: OptimizationResult;

  // Telemetry History & Event Sourcing
  telemetryHistory: TelemetryFrame[];
  events: DrillingEvent[];
  operatingHoursTotal: number;
}

export class DrillingTwinEngine {
  /**
   * Initializes a brand-new digital twin state for a 3,000m exploration well
   */
  public static createInitialTwin(): DigitalTwinState {
    const plannedDepthM = 3000;
    const currentDepthMdM = 2450;
    const casingShoeDepthM = 1800;
    const holeDiameterMm = 215.9;

    // Build Planned Trajectory (Vertical -> Kickoff at 800m -> Build to 32° at 2200m -> Hold section)
    const rawPlannedStations: SurveyStation[] = [
      { md: 0, incDeg: 0, aziDeg: 45 },
      { md: 800, incDeg: 0, aziDeg: 45 },
      { md: 1200, incDeg: 12, aziDeg: 45 },
      { md: 1600, incDeg: 22, aziDeg: 45 },
      { md: 2200, incDeg: 32, aziDeg: 45 },
      { md: 3000, incDeg: 32, aziDeg: 45 },
    ];
    const plannedTrajectory = TrajectoryEngine.computeTrajectory(rawPlannedStations, 'MINIMUM_CURVATURE', 45);

    // Build Actual Drilled Trajectory with minor real-world tortuosity
    const rawActualStations: SurveyStation[] = [
      { md: 0, incDeg: 0, aziDeg: 45 },
      { md: 800, incDeg: 0.2, aziDeg: 46 },
      { md: 1200, incDeg: 12.4, aziDeg: 44.5 },
      { md: 1600, incDeg: 21.8, aziDeg: 45.2 },
      { md: 2200, incDeg: 32.1, aziDeg: 45.0 },
      { md: 2450, incDeg: 32.3, aziDeg: 45.1 },
    ];
    const actualTrajectory = TrajectoryEngine.computeTrajectory(rawActualStations, 'MINIMUM_CURVATURE', 45);
    const bitSurvey = TrajectoryEngine.interpolateAtMd(actualTrajectory, currentDepthMdM);
    const currentTvdM = bitSurvey.tvd ?? currentDepthMdM;

    const formations = GeologyEngine.getDefaultFormationModel();
    const currentFormation = GeologyEngine.getLayerAtDepth(formations, currentDepthMdM);

    const rig = RigEngine.getDefaultRigConfig();
    const bha = DrillStringEngine.getDefaultBHA(holeDiameterMm);
    const mud = HydraulicsEngine.getDefaultMud();
    const drillString = DrillStringEngine.assembleDrillString(currentDepthMdM, bha, mud.densityKgM3, 85.0);
    const bit = RopEngine.getDefaultPdcBit();

    const controlWobKn = 85.0;
    const controlRpm = 120.0;
    const controlFlowRateLs = 42.0;

    // Compute initial physics states
    const ropEng = RopEngine.calculateMechanisticRop(controlWobKn, controlRpm, bit, currentFormation, controlFlowRateLs, mud.densityKgM3);
    const hydEng = HydraulicsEngine.calculateHydraulics(controlFlowRateLs, currentDepthMdM, currentTvdM, casingShoeDepthM, mud, bit.tfaMm2, currentFormation);
    const vibTelem = VibrationEngine.simulateStickSlipStep(controlRpm, controlWobKn, currentDepthMdM, currentFormation.ucsMpa, 0);
    const cuttingsEng = CuttingsAndWellControlEngine.calculateCuttingsTransport(
      ropEng.value.ropMHr,
      controlFlowRateLs,
      holeDiameterMm,
      127.0,
      bitSurvey.incDeg,
      mud.densityKgM3,
      mud.plasticViscosityCp,
      currentFormation.bulkDensity
    );
    const tdEng = TorqueDragEngine.calculateTorqueAndDrag(
      actualTrajectory,
      drillString,
      'ROTATE_ON_BOTTOM',
      casingShoeDepthM,
      0.22,
      0.32,
      controlWobKn,
      ropEng.value.torqueKnM,
      holeDiameterMm
    );
    const hoistingEng = RigEngine.calculateHoisting(tdEng.value.surfaceHookLoadKn, 0.0, rig);
    const topDriveEng = RigEngine.calculateTopDrive(controlRpm, tdEng.value.surfaceTorqueKnM * 1000, rig);
    const wellControlState = CuttingsAndWellControlEngine.calculateWellControl(mud.densityKgM3, currentTvdM);
    const costModel = EconomicsEngine.getDefaultCostModel();
    const economicsEng = EconomicsEngine.calculateEconomics(currentDepthMdM, 78.5, 14.0, 8.5, costModel);

    // Initial Telemetry History Seed
    const telemetryHistory: TelemetryFrame[] = [];
    for (let d = 2000; d <= 2450; d += 25) {
      const form = GeologyEngine.getLayerAtDepth(formations, d);
      const subSurvey = TrajectoryEngine.interpolateAtMd(actualTrajectory, d);
      telemetryHistory.push({
        timestamp: `08:${Math.floor((d - 2000) / 10).toString().padStart(2, '0')}:00`,
        depthMdM: d,
        tvdM: subSurvey.tvd ?? d,
        wobKn: controlWobKn + (Math.sin(d * 0.1) * 4),
        surfaceRpm: controlRpm,
        flowRateLs: controlFlowRateLs,
        surfaceTorqueKnM: 4.8 + Math.sin(d * 0.05) * 0.4,
        standpipePressureBar: 185.0 + (d / 20),
        ropMHr: 24.2 - (form.ucsMpa / 15.0),
        mseMpa: 285.0 + form.ucsMpa * 1.5,
        ecdSg: 1.28 + (d / 10000),
        vibrationG: 0.8 + (form.ucsMpa / 120.0),
        gammaRayApi: form.lithology === 'SHALE' ? 95 : 32,
        deepResistivityOhmm: form.lithology === 'SANDSTONE' ? 42 : 12,
        formationName: form.name,
        regime: 'ROTATING_DRILLING',
      });
    }

    const anomalies = RQuantMLEngine.detectAnomalies(telemetryHistory);
    const formationClass = RQuantMLEngine.classifyFormation(34.0, 38.5, ropEng.value.ropMHr, controlWobKn);
    const bitWearPred = RQuantMLEngine.predictBitLife(
      bit.dullGrade,
      bit.operatingHours,
      bit.cumulativeMetersDrilled,
      plannedDepthM,
      currentDepthMdM,
      ropEng.value.mseMpa,
      currentFormation.caiAbrasiveness
    );
    const optimizationResult = OptimizationEngine.runMultiObjectiveOptimization(
      controlWobKn,
      controlRpm,
      controlFlowRateLs,
      currentDepthMdM,
      currentTvdM,
      bit,
      currentFormation,
      rig,
      mud
    );

    const initialEvents: DrillingEvent[] = [
      {
        id: 'evt-0',
        type: 'SPUD',
        timestamp: 'Day 1 00:00:00',
        depthMdM: 0,
        description: 'Well DRILLCORE Alpha-01 spudded successfully on Rig DC-700.',
        dataSnapshot: { rigId: rig.rigId },
      },
      {
        id: 'evt-1',
        type: 'CASING_RUN',
        timestamp: 'Day 2 16:30:00',
        depthMdM: 1800,
        description: '9-5/8" Intermediate Casing set and cemented at 1800m shoe depth.',
        dataSnapshot: { casingShoeDepthM: 1800, shoeTestBar: 245 },
      },
      {
        id: 'evt-2',
        type: 'FORMATION_CHANGE',
        timestamp: 'Day 3 11:45:00',
        depthMdM: 1950,
        description: 'Crossed formation top into Brent Reservoir Sandstone. Porosity 22%, Perm 350mD.',
        dataSnapshot: { formation: 'Brent Reservoir Sandstone', ucsMpa: 52 },
      },
      {
        id: 'evt-3',
        type: 'DRILLING_STARTED',
        timestamp: 'Day 4 08:00:00',
        depthMdM: 2450,
        description: 'Resumed rotary directional drilling in 8-1/2" section.',
        dataSnapshot: { wobKn: controlWobKn, rpm: controlRpm, flowRateLs: controlFlowRateLs },
      },
    ];

    return {
      wellId: 'WELL-DC-2026-001',
      wellName: 'DRILLCORE Alpha-01',
      field: 'North Sea Brent Field Sector 4',
      plannedDepthM,
      currentDepthMdM,
      currentTvdM,
      casingShoeDepthM,
      holeDiameterMm,
      controlWobKn,
      controlRpm,
      controlFlowRateLs,
      mudDensityKgM3: mud.densityKgM3,
      regime: 'ROTATING_DRILLING',
      isSimulating: false,
      simulationSpeed: 1,
      trajectory: actualTrajectory,
      plannedTrajectory,
      formations,
      currentFormation,
      rig,
      hoisting: hoistingEng.value,
      topDrive: topDriveEng.value,
      bha,
      drillString,
      bit,
      mud,
      ropResult: ropEng.value,
      hydraulicsResult: hydEng.value,
      vibrationTelemetry: vibTelem,
      cuttingsResult: cuttingsEng.value,
      torqueDragResult: tdEng.value,
      wellControlState,
      economicsResult: economicsEng.value,
      anomalies,
      formationClass,
      bitWearPred,
      optimizationResult,
      telemetryHistory,
      events: initialEvents,
      operatingHoursTotal: 101.0,
    };
  }

  /**
   * Performs one discrete physics step of drilling advancement
   */
  public static stepSimulation(state: DigitalTwinState, deltaSeconds: number = 2.0): DigitalTwinState {
    const speed = state.simulationSpeed;
    const dt = deltaSeconds * speed;

    // Calculate ROP under current controls
    const ropEng = RopEngine.calculateMechanisticRop(
      state.controlWobKn,
      state.controlRpm,
      state.bit,
      state.currentFormation,
      state.controlFlowRateLs,
      state.mudDensityKgM3
    );

    const ropMHr = ropEng.value.ropMHr;
    const metersAdvanced = (ropMHr / 3600) * dt;
    const newDepthMd = Math.min(state.plannedDepthM, state.currentDepthMdM + metersAdvanced);

    // Update Bit wear
    const dullIncrement = (ropEng.value.cutterWearIncrementPerHr / 3600) * dt;
    const updatedBit: DrillBitSpecs = {
      ...state.bit,
      dullGrade: Math.min(8.0, state.bit.dullGrade + dullIncrement),
      operatingHours: state.bit.operatingHours + dt / 3600,
      cumulativeMetersDrilled: state.bit.cumulativeMetersDrilled + metersAdvanced,
    };

    // Update trajectory to bit
    const currentSurvey = TrajectoryEngine.interpolateAtMd(state.trajectory, newDepthMd);
    const newTvd = currentSurvey.tvd ?? newDepthMd;

    // Check formation transitions
    const newFormation = GeologyEngine.getLayerAtDepth(state.formations, newDepthMd);
    const newEvents = [...state.events];

    if (newFormation.id !== state.currentFormation.id) {
      newEvents.push({
        id: `evt-form-${Date.now()}`,
        type: 'FORMATION_CHANGE',
        timestamp: new Date().toLocaleTimeString(),
        depthMdM: Math.round(newDepthMd),
        description: `Stratigraphic boundary transition: Entered ${newFormation.name} (UCS: ${newFormation.ucsMpa} MPa).`,
        dataSnapshot: { layerId: newFormation.id, lithology: newFormation.lithology },
      });
    }

    if (newDepthMd >= state.plannedDepthM && state.currentDepthMdM < state.plannedDepthM) {
      newEvents.push({
        id: `evt-td-${Date.now()}`,
        type: 'TARGET_DEPTH_REACHED',
        timestamp: new Date().toLocaleTimeString(),
        depthMdM: state.plannedDepthM,
        description: `Well ${state.wellName} has reached Planned Total Depth (${state.plannedDepthM} m).`,
        dataSnapshot: { totalDepthM: state.plannedDepthM },
      });
    }

    // Assemble updated drillstring
    const drillString = DrillStringEngine.assembleDrillString(
      newDepthMd,
      state.bha,
      state.mudDensityKgM3,
      state.controlWobKn
    );

    // Recalculate all physical subsystems
    const hydEng = HydraulicsEngine.calculateHydraulics(
      state.controlFlowRateLs,
      newDepthMd,
      newTvd,
      state.casingShoeDepthM,
      state.mud,
      state.bit.tfaMm2,
      newFormation
    );

    const vibTelem = VibrationEngine.simulateStickSlipStep(
      state.controlRpm,
      state.controlWobKn,
      newDepthMd,
      newFormation.ucsMpa,
      state.operatingHoursTotal * 3600 + dt
    );

    if (vibTelem.isStickSlipActive && !state.vibrationTelemetry.isStickSlipActive) {
      newEvents.push({
        id: `evt-vib-${Date.now()}`,
        type: 'STICK_SLIP_DETECTED',
        timestamp: new Date().toLocaleTimeString(),
        depthMdM: Math.round(newDepthMd),
        description: `Severe torsional stick-slip oscillation detected (Severity: ${vibTelem.torsionalVibrationPercent.toFixed(0)}%). Recommend increasing RPM or trimming WOB.`,
        dataSnapshot: { severity: vibTelem.torsionalVibrationPercent },
      });
    }

    const cuttingsEng = CuttingsAndWellControlEngine.calculateCuttingsTransport(
      ropEng.value.ropMHr,
      state.controlFlowRateLs,
      state.holeDiameterMm,
      127.0,
      currentSurvey.incDeg,
      state.mudDensityKgM3,
      state.mud.plasticViscosityCp,
      newFormation.bulkDensity
    );

    const tdEng = TorqueDragEngine.calculateTorqueAndDrag(
      state.trajectory,
      drillString,
      'ROTATE_ON_BOTTOM',
      state.casingShoeDepthM,
      0.22,
      0.32,
      state.controlWobKn,
      ropEng.value.torqueKnM,
      state.holeDiameterMm
    );

    const hoistingEng = RigEngine.calculateHoisting(tdEng.value.surfaceHookLoadKn, 0.0, state.rig);
    const topDriveEng = RigEngine.calculateTopDrive(state.controlRpm, tdEng.value.surfaceTorqueKnM * 1000, state.rig);

    const costModel = EconomicsEngine.getDefaultCostModel();
    const updatedOperatingHours = state.operatingHoursTotal + dt / 3600;
    const economicsEng = EconomicsEngine.calculateEconomics(
      newDepthMd,
      updatedOperatingHours * 0.78,
      14.0,
      8.5,
      costModel,
      state.economicsResult.nptRecords
    );

    // Append telemetry frame
    const newTelemFrame: TelemetryFrame = {
      timestamp: new Date().toLocaleTimeString(),
      depthMdM: Math.round(newDepthMd * 10) / 10,
      tvdM: Math.round(newTvd * 10) / 10,
      wobKn: state.controlWobKn,
      surfaceRpm: state.controlRpm,
      flowRateLs: state.controlFlowRateLs,
      surfaceTorqueKnM: tdEng.value.surfaceTorqueKnM,
      standpipePressureBar: hydEng.value.standpipePressureBar,
      ropMHr: ropEng.value.ropMHr,
      mseMpa: ropEng.value.mseMpa,
      ecdSg: hydEng.value.ecdSg,
      vibrationG: vibTelem.axialVibrationG + vibTelem.lateralVibrationG,
      gammaRayApi: newFormation.lithology === 'SHALE' ? 95 : (newFormation.lithology === 'SANDSTONE' ? 35 : 18),
      deepResistivityOhmm: newFormation.lithology === 'SANDSTONE' ? 45 : 8.5,
      formationName: newFormation.name,
      regime: state.regime,
    };

    const telemetryHistory = [...state.telemetryHistory.slice(-50), newTelemFrame];
    const anomalies = RQuantMLEngine.detectAnomalies(telemetryHistory);

    const bitWearPred = RQuantMLEngine.predictBitLife(
      updatedBit.dullGrade,
      updatedBit.operatingHours,
      updatedBit.cumulativeMetersDrilled,
      state.plannedDepthM,
      newDepthMd,
      ropEng.value.mseMpa,
      newFormation.caiAbrasiveness
    );

    const optimizationResult = OptimizationEngine.runMultiObjectiveOptimization(
      state.controlWobKn,
      state.controlRpm,
      state.controlFlowRateLs,
      newDepthMd,
      newTvd,
      updatedBit,
      newFormation,
      state.rig,
      state.mud
    );

    return {
      ...state,
      currentDepthMdM: newDepthMd,
      currentTvdM: newTvd,
      currentFormation: newFormation,
      bit: updatedBit,
      drillString,
      ropResult: ropEng.value,
      hydraulicsResult: hydEng.value,
      vibrationTelemetry: vibTelem,
      cuttingsResult: cuttingsEng.value,
      torqueDragResult: tdEng.value,
      hoisting: hoistingEng.value,
      topDrive: topDriveEng.value,
      economicsResult: economicsEng.value,
      anomalies,
      bitWearPred,
      optimizationResult,
      telemetryHistory,
      events: newEvents,
      operatingHoursTotal: updatedOperatingHours,
    };
  }
}
