"""
visualisation.plots
=====================
2D circuit rendering (Section 72), track heatmaps (Section 70) and
analytics charts (Section 71), built with Matplotlib so `main.py` can
run headlessly. 3D point export (Section 73) is provided for a future
Kotlin/Compose or WebGL frontend.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from engine.digital_twin.twin import TrackDigitalTwin


def plot_track_map(twin: TrackDigitalTwin, out_path: str, show_racing_line: bool = True) -> str:
    t = twin.track
    fig, ax = plt.subplots(figsize=(9, 9))
    ax.plot(t.boundaries.left_x, t.boundaries.left_y, color="#888888", lw=1)
    ax.plot(t.boundaries.right_x, t.boundaries.right_y, color="#888888", lw=1)
    ax.plot(t.arrays.x, t.arrays.y, "--", color="#cccccc", lw=0.8, label="Centreline")
    if show_racing_line and twin.racing_line is not None:
        ax.plot(twin.racing_line.x, twin.racing_line.y, color="#d62728", lw=1.4, label="Racing line")
    for c in t.corners:
        ax.plot(t.arrays.x[c.apex_idx], t.arrays.y[c.apex_idx], "o", color="#1f77b4", ms=4)
        ax.annotate(str(c.index + 1), (t.arrays.x[c.apex_idx], t.arrays.y[c.apex_idx]), fontsize=7)
    ax.set_title(f"{t.name} — Track Map")
    ax.set_aspect("equal")
    ax.legend(loc="upper right", fontsize=8)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return out_path


def plot_heatmap(twin: TrackDigitalTwin, metric: str, out_path: str) -> str:
    t = twin.track
    values = {
        "speed": twin.lap.speed_kmh, "curvature": t.arrays.curvature,
        "gradient": t.arrays.gradient * 100, "banking": t.arrays.banking,
        "lateral_acceleration": twin.lap.lateral_accel / 9.81,
        "braking": np.gradient(twin.lap.speed_ms, t.arrays.ds),
        "risk_proxy": np.abs(twin.lap.lateral_accel / 9.81) + np.abs(t.arrays.gradient) * 5,
    }[metric]
    fig, ax = plt.subplots(figsize=(9, 9))
    sc = ax.scatter(t.arrays.x, t.arrays.y, c=values, cmap="turbo", s=6)
    fig.colorbar(sc, ax=ax, label=metric)
    ax.set_title(f"{t.name} — {metric.replace('_', ' ').title()} Heatmap")
    ax.set_aspect("equal")
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return out_path


def plot_analytics(twin: TrackDigitalTwin, out_path: str) -> str:
    t = twin.track
    fig, axes = plt.subplots(3, 2, figsize=(12, 10), sharex=True)
    s_km = t.arrays.s / 1000.0
    axes[0, 0].plot(s_km, twin.lap.speed_kmh); axes[0, 0].set_title("Speed vs Distance"); axes[0, 0].set_ylabel("km/h")
    axes[0, 1].plot(s_km, t.arrays.z); axes[0, 1].set_title("Elevation vs Distance"); axes[0, 1].set_ylabel("m")
    axes[1, 0].plot(s_km, t.arrays.curvature); axes[1, 0].set_title("Curvature vs Distance"); axes[1, 0].set_ylabel("1/m")
    axes[1, 1].plot(s_km, t.arrays.gradient * 100); axes[1, 1].set_title("Gradient vs Distance"); axes[1, 1].set_ylabel("%")
    axes[2, 0].plot(s_km, t.arrays.banking); axes[2, 0].set_title("Banking vs Distance"); axes[2, 0].set_ylabel("deg")
    lap_time_cum = np.cumsum(t.arrays.ds / np.maximum(twin.lap.speed_ms, 1))
    axes[2, 1].plot(s_km, lap_time_cum); axes[2, 1].set_title("Cumulative Lap Time vs Distance"); axes[2, 1].set_ylabel("s")
    for ax in axes[-1, :]:
        ax.set_xlabel("Distance (km)")
    fig.suptitle(f"{t.name} — Track Analytics")
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return out_path


def plot_gg_diagram(twin: TrackDigitalTwin, out_path: str) -> str:
    from engine.lap_time.simulator import gg_diagram
    lat_g, long_g = gg_diagram(twin.lap)
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.scatter(lat_g, long_g, s=4, alpha=0.5)
    ax.set_xlabel("Lateral G"); ax.set_ylabel("Longitudinal G")
    ax.set_title(f"{twin.track.name} — G-G Diagram")
    ax.axhline(0, color="grey", lw=0.5); ax.axvline(0, color="grey", lw=0.5)
    ax.set_aspect("equal")
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return out_path


def export_3d_points(twin: TrackDigitalTwin) -> list[dict]:
    """Per-point x/y/z/heading/banking/width payload for a future 3D frontend (Section 73)."""
    a = twin.track.arrays
    return [
        {"x": float(a.x[i]), "y": float(a.y[i]), "z": float(a.z[i]),
         "heading": float(a.heading[i]), "banking": float(a.banking[i]), "width": float(a.width[i])}
        for i in range(len(a.s))
    ]
