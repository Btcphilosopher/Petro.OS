"""
engine.vehicle.driver
=======================
DriverModel (Sections 35-36): a skill multiplier applied to the physics
limits used by the lap-time simulator, plus named driver profiles for
comparison.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class DriverProfile(str, Enum):
    PRO = "PRO"
    AMATEUR = "AMATEUR"
    AGGRESSIVE = "AGGRESSIVE"
    CONSERVATIVE = "CONSERVATIVE"


@dataclass
class DriverModel:
    braking_skill: float = 1.0     # 0..1.05, fraction of theoretical braking used
    cornering_skill: float = 1.0
    throttle_skill: float = 1.0
    consistency: float = 1.0       # 0..1, reduces lap-to-lap variance (not used in QSS mean)
    risk: float = 0.5              # 0..1, biases skill combination toward aggression

    @property
    def combined_skill(self) -> float:
        base = (self.braking_skill + self.cornering_skill + self.throttle_skill) / 3.0
        return base * (0.95 + 0.10 * self.risk)


DRIVER_PRESETS = {
    DriverProfile.PRO: DriverModel(1.0, 1.0, 1.0, 0.98, 0.6),
    DriverProfile.AMATEUR: DriverModel(0.82, 0.80, 0.85, 0.75, 0.35),
    DriverProfile.AGGRESSIVE: DriverModel(1.02, 1.03, 1.02, 0.7, 0.9),
    DriverProfile.CONSERVATIVE: DriverModel(0.9, 0.88, 0.9, 0.95, 0.2),
}


def get_driver(profile: DriverProfile) -> DriverModel:
    return DRIVER_PRESETS[profile]
