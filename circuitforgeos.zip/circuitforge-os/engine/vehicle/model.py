"""
engine.vehicle.model
======================
Generic configurable race-car model (Sections 20-21, 28). No real-world
vehicle is modelled unless a user explicitly supplies matching parameters.
"""
from __future__ import annotations

from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field


class VehicleType(str, Enum):
    FORMULA = "FORMULA"
    GT = "GT"
    SPORTS_CAR = "SPORTS_CAR"
    TOURING_CAR = "TOURING_CAR"
    PROTOTYPE = "PROTOTYPE"
    MOTORCYCLE = "MOTORCYCLE"


class Gearbox(BaseModel):
    gear_ratios: List[float] = Field(default_factory=lambda: [3.2, 2.4, 1.9, 1.5, 1.2, 1.0])
    final_drive: float = 3.4
    shift_time_s: float = 0.05
    redline_rpm: float = 9500.0

    def wheel_speed_ms(self, gear_idx: int, rpm: float, wheel_radius_m: float) -> float:
        ratio = self.gear_ratios[gear_idx] * self.final_drive
        wheel_rpm = rpm / ratio
        omega = wheel_rpm * 2 * 3.141592653589793 / 60.0
        return omega * wheel_radius_m

    def best_gear(self, speed_ms: float, wheel_radius_m: float) -> int:
        best, best_diff = 0, float("inf")
        for i, ratio in enumerate(self.gear_ratios):
            total_ratio = ratio * self.final_drive
            omega = speed_ms / max(wheel_radius_m, 1e-6)
            rpm = omega * total_ratio * 60.0 / (2 * 3.141592653589793)
            diff = abs(rpm - self.redline_rpm * 0.85)
            if rpm <= self.redline_rpm and diff < best_diff:
                best, best_diff = i, diff
        return best


class Vehicle(BaseModel):
    name: str = "Generic GT"
    vehicle_type: VehicleType = VehicleType.GT
    mass_kg: float = 1250.0
    engine_power_w: float = 350_000.0        # ~470 hp
    drag_coefficient: float = 0.85
    frontal_area_m2: float = 1.9
    downforce_coefficient: float = 1.6
    tyre_mu: float = 1.55
    wheelbase_m: float = 2.65
    wheel_radius_m: float = 0.33
    brake_decel_max_ms2: float = 14.0
    rolling_resistance_coeff: float = 0.012
    gearbox: Gearbox = Field(default_factory=Gearbox)
    drivetrain_efficiency: float = 0.90

    def top_speed_estimate(self, air_density: float = 1.225) -> float:
        """Solve F_drive(vmax) = F_drag(vmax) for engine-power-limited top speed."""
        from scipy.optimize import brentq

        def net_force(v):
            if v <= 0.1:
                v = 0.1
            f_drive = (self.engine_power_w * self.drivetrain_efficiency) / v
            f_drag = 0.5 * air_density * self.drag_coefficient * self.frontal_area_m2 * v ** 2
            return f_drive - f_drag

        try:
            return float(brentq(net_force, 1, 150))
        except Exception:
            return 100.0


PRESETS = {
    VehicleType.FORMULA: Vehicle(
        name="Formula-Spec Open-Wheeler", vehicle_type=VehicleType.FORMULA,
        mass_kg=798, engine_power_w=610_000, drag_coefficient=1.0, frontal_area_m2=1.5,
        downforce_coefficient=3.2, tyre_mu=1.9, wheelbase_m=3.6, wheel_radius_m=0.33,
        brake_decel_max_ms2=45.0,
    ),
    VehicleType.GT: Vehicle(
        name="GT-Spec Coupe", vehicle_type=VehicleType.GT,
        mass_kg=1300, engine_power_w=430_000, drag_coefficient=0.9, frontal_area_m2=2.0,
        downforce_coefficient=1.8, tyre_mu=1.6, wheelbase_m=2.7, wheel_radius_m=0.34,
        brake_decel_max_ms2=16.0,
    ),
    VehicleType.SPORTS_CAR: Vehicle(
        name="Road-Going Sports Car", vehicle_type=VehicleType.SPORTS_CAR,
        mass_kg=1450, engine_power_w=330_000, drag_coefficient=0.95, frontal_area_m2=2.1,
        downforce_coefficient=0.9, tyre_mu=1.35, wheelbase_m=2.6, wheel_radius_m=0.34,
        brake_decel_max_ms2=13.0,
    ),
    VehicleType.TOURING_CAR: Vehicle(
        name="Touring Car", vehicle_type=VehicleType.TOURING_CAR,
        mass_kg=1350, engine_power_w=260_000, drag_coefficient=1.05, frontal_area_m2=2.2,
        downforce_coefficient=0.7, tyre_mu=1.3, wheelbase_m=2.65, wheel_radius_m=0.32,
        brake_decel_max_ms2=12.0,
    ),
    VehicleType.PROTOTYPE: Vehicle(
        name="Le-Mans-Style Prototype", vehicle_type=VehicleType.PROTOTYPE,
        mass_kg=1030, engine_power_w=520_000, drag_coefficient=0.85, frontal_area_m2=1.85,
        downforce_coefficient=2.6, tyre_mu=1.75, wheelbase_m=3.0, wheel_radius_m=0.34,
        brake_decel_max_ms2=30.0,
    ),
    VehicleType.MOTORCYCLE: Vehicle(
        name="Prototype Racing Motorcycle", vehicle_type=VehicleType.MOTORCYCLE,
        mass_kg=165, engine_power_w=180_000, drag_coefficient=0.6, frontal_area_m2=0.4,
        downforce_coefficient=0.05, tyre_mu=1.3, wheelbase_m=1.45, wheel_radius_m=0.3,
        brake_decel_max_ms2=11.0,
    ),
}


def get_preset(vehicle_type: VehicleType) -> Vehicle:
    return PRESETS[vehicle_type].model_copy(deep=True)
