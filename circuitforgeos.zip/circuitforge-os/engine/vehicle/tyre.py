"""
engine.vehicle.tyre
=====================
Generic TyreModel + compound presets (Sections 39-40). Does not
represent any particular manufacturer's tyre data.
"""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum


class TyreCompound(str, Enum):
    SOFT = "SOFT"
    MEDIUM = "MEDIUM"
    HARD = "HARD"
    WET = "WET"


@dataclass
class TyreModel:
    compound: TyreCompound = TyreCompound.MEDIUM
    base_mu: float = 1.55
    optimal_temp_c: float = 90.0
    wear_rate_per_lap: float = 0.012      # fraction of grip lost per lap at full pace
    pressure_bar: float = 1.9

    def friction(self, lap_number: int, temperature_c: float = 90.0) -> float:
        wear = min(lap_number * self.wear_rate_per_lap, 0.5)
        temp_factor = 1.0 - 0.002 * abs(temperature_c - self.optimal_temp_c)
        return max(self.base_mu * (1 - wear) * temp_factor, self.base_mu * 0.4)


TYRE_PRESETS = {
    TyreCompound.SOFT: TyreModel(TyreCompound.SOFT, base_mu=1.75, wear_rate_per_lap=0.020),
    TyreCompound.MEDIUM: TyreModel(TyreCompound.MEDIUM, base_mu=1.55, wear_rate_per_lap=0.012),
    TyreCompound.HARD: TyreModel(TyreCompound.HARD, base_mu=1.40, wear_rate_per_lap=0.007),
    TyreCompound.WET: TyreModel(TyreCompound.WET, base_mu=1.10, wear_rate_per_lap=0.010,
                                 optimal_temp_c=55.0),
}


def get_tyre(compound: TyreCompound) -> TyreModel:
    return TYRE_PRESETS[compound]


def degradation_curve(tyre: TyreModel, laps: int, temperature_c: float = 90.0):
    return [tyre.friction(lap, temperature_c) for lap in range(laps)]
