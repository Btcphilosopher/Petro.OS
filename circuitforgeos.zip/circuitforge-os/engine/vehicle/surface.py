"""engine.vehicle.surface — SurfaceModel (Section 38): per-zone track surface properties."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List
import numpy as np


@dataclass
class SurfaceZone:
    start_s: float
    end_s: float
    friction: float = 1.0        # multiplier on tyre_mu
    roughness: float = 0.5       # 0..1
    temperature_c: float = 25.0
    wear: float = 0.0            # 0..1
    wetness: float = 0.0         # 0..1


@dataclass
class SurfaceModel:
    zones: List[SurfaceZone] = field(default_factory=list)
    default_friction: float = 1.0

    def friction_profile(self, s: np.ndarray) -> np.ndarray:
        f = np.full_like(s, self.default_friction, dtype=float)
        for z in self.zones:
            mask = (s >= z.start_s) & (s < z.end_s)
            f[mask] = z.friction * (1 - 0.4 * z.wetness) * (1 - 0.15 * z.wear)
        return f
