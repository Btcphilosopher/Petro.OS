"""
engine.vehicle.weather
========================
Simplified WeatherModel (Section 37) adjusting friction/visibility/
braking multipliers used elsewhere in the physics chain.
"""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum


class WeatherCondition(str, Enum):
    DRY = "DRY"
    DAMP = "DAMP"
    WET = "WET"
    HEAVY_RAIN = "HEAVY_RAIN"


@dataclass
class WeatherEffect:
    friction_multiplier: float
    visibility_m: float
    braking_multiplier: float
    speed_multiplier: float


WEATHER_PRESETS = {
    WeatherCondition.DRY: WeatherEffect(1.00, 2000, 1.00, 1.00),
    WeatherCondition.DAMP: WeatherEffect(0.85, 800, 0.90, 0.95),
    WeatherCondition.WET: WeatherEffect(0.65, 300, 0.75, 0.85),
    WeatherCondition.HEAVY_RAIN: WeatherEffect(0.45, 100, 0.55, 0.70),
}


def get_weather(condition: WeatherCondition) -> WeatherEffect:
    return WEATHER_PRESETS[condition]
