"""
engine.safety.engine
======================
SafetyZoneEngine (Section 45): aggregates conceptual runoff, barrier,
marshal-post and service-access elements. All outputs are simulation /
design-visualisation concepts, NOT a certification of circuit safety.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

import numpy as np

from engine.common import TrackArrays
from engine.runoff.engine import RunoffZone, compute_runoff_zones, total_runoff_area


@dataclass
class BarrierSegment:
    start_s: float
    end_s: float
    barrier_type: str
    length_m: float
    offset_m: float


@dataclass
class MarshalPost:
    s: float
    x: float
    y: float


@dataclass
class SafetyReport:
    runoff_zones: List[RunoffZone]
    total_runoff_area_m2: float
    barriers: List[BarrierSegment]
    total_barrier_length_m: float
    marshal_posts: List[MarshalPost]
    service_road_length_m: float
    disclaimer: str = (
        "Simulation estimate only. Not a certified motorsport safety "
        "assessment or FIA/sanctioning-body homologation."
    )


class SafetyZoneEngine:
    def __init__(self, cfg: dict):
        self.cfg = cfg

    def analyse(self, arrays: TrackArrays, speed_kmh: np.ndarray) -> SafetyReport:
        runoff = compute_runoff_zones(arrays, speed_kmh, self.cfg)
        runoff_area = total_runoff_area(runoff)

        barriers = [BarrierSegment(
            start_s=z.start_s, end_s=z.end_s, barrier_type="Debris Fence (conceptual)",
            length_m=(z.end_s - z.start_s) * 2, offset_m=z.depth_m,
        ) for z in runoff]
        barrier_len = sum(b.length_m for b in barriers)

        spacing = self.cfg.get("marshal_post_spacing_m", 300)
        n_posts = max(int(arrays.length // spacing), 1)
        posts = []
        for i in range(n_posts):
            s_target = i * spacing
            idx = int(np.searchsorted(arrays.s, s_target))
            idx = min(idx, len(arrays.s) - 1)
            posts.append(MarshalPost(s=float(arrays.s[idx]), x=float(arrays.x[idx]), y=float(arrays.y[idx])))

        service_road_length = arrays.length * 1.05  # perimeter access road, conceptual

        return SafetyReport(
            runoff_zones=runoff, total_runoff_area_m2=runoff_area,
            barriers=barriers, total_barrier_length_m=barrier_len,
            marshal_posts=posts, service_road_length_m=service_road_length,
        )
