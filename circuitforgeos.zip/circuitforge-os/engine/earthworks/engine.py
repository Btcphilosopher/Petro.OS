"""
engine.earthworks.engine
==========================
Earthworks estimation (Section 53) via cross-sectional cut/fill
integration along the corridor, EarthworksOptimizer (Section 54) for a
simple cut/fill/haul-distance balancing search, and haul-distance
modelling (Section 55). All volumes are SIMULATION ESTIMATES.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List

import numpy as np

from engine.common import TrackArrays
from engine.terrain.dem import DigitalElevationModel


@dataclass
class EarthworksResult:
    cut_volume_m3: float
    fill_volume_m3: float
    net_volume_m3: float
    net_direction: str
    per_point_cut_fill: np.ndarray   # + = cut needed, - = fill needed [m]
    corridor_width_m: float


def compute_earthworks(arrays: TrackArrays, dem: DigitalElevationModel,
                        corridor_width_m: float = 30.0, side_slope_ratio: float = 2.0) -> EarthworksResult:
    """
    Approximate cross-sectional cut/fill: at each station, sample terrain
    elevation under the track corridor centre and compare against the
    design track elevation. The corridor is modelled as a trapezoid whose
    top width is `corridor_width_m` and side slopes run at
    `side_slope_ratio` (horizontal:vertical).
    """
    terrain_z = dem.sample(arrays.x, arrays.y)
    terrain_z = np.nan_to_num(terrain_z, nan=float(np.nanmean(terrain_z)))

    delta = terrain_z - arrays.z   # positive => terrain above design => CUT required
    ds = arrays.ds

    # trapezoidal cross-sectional area for a cut or fill of depth |delta|:
    # A = width * depth + side_slope_ratio * depth^2
    depth = np.abs(delta)
    area = corridor_width_m * depth + side_slope_ratio * depth ** 2

    cut_mask = delta > 0
    fill_mask = delta < 0

    cut_volume = float(np.sum(area[cut_mask]) * ds)
    fill_volume = float(np.sum(area[fill_mask]) * ds)
    net = cut_volume - fill_volume

    return EarthworksResult(
        cut_volume_m3=cut_volume, fill_volume_m3=fill_volume,
        net_volume_m3=abs(net), net_direction="CUT" if net >= 0 else "FILL",
        per_point_cut_fill=delta, corridor_width_m=corridor_width_m,
    )


@dataclass
class HaulEstimate:
    total_moved_m3: float
    average_haul_distance_m: float
    estimated_truck_loads: float
    estimated_haul_effort_index: float


def estimate_haul(result: EarthworksResult, arrays: TrackArrays, truck_capacity_m3: float = 15.0) -> HaulEstimate:
    """
    Pairs nearby cut/fill stations along the corridor (simplified 1D
    "balance line" haul model) and estimates total moved volume, average
    haul distance and an effort index (volume * distance).
    """
    delta = result.per_point_cut_fill
    ds = arrays.ds
    cut_idx = np.where(delta > 0)[0]
    fill_idx = np.where(delta < 0)[0]
    if len(cut_idx) == 0 or len(fill_idx) == 0:
        moved = min(result.cut_volume_m3, result.fill_volume_m3)
        return HaulEstimate(moved, 0.0, moved / truck_capacity_m3, 0.0)

    moved = min(result.cut_volume_m3, result.fill_volume_m3)
    # crude average haul distance: mean absolute station separation between
    # the centroid of cut stations and centroid of fill stations
    cut_centroid_s = float(np.mean(arrays.s[cut_idx]))
    fill_centroid_s = float(np.mean(arrays.s[fill_idx]))
    avg_distance = abs(cut_centroid_s - fill_centroid_s)
    effort = moved * avg_distance

    return HaulEstimate(
        total_moved_m3=moved, average_haul_distance_m=avg_distance,
        estimated_truck_loads=moved / truck_capacity_m3,
        estimated_haul_effort_index=effort,
    )


def optimise_vertical_alignment(control_z: np.ndarray, terrain_at_control: np.ndarray,
                                 max_gradient_pct: float = 12.0) -> np.ndarray:
    """
    EarthworksOptimizer (Section 54): a lightweight SciPy-based optimiser
    that adjusts a sparse vertical-alignment control vector to minimise
    total cut + fill (proxy: sum |terrain - design|) subject to a maximum
    gradient constraint between consecutive control points.
    """
    from scipy.optimize import minimize

    n = len(control_z)

    def cost(z):
        earthworks_cost = np.sum(np.abs(terrain_at_control - z))
        grad_penalty = np.sum(np.maximum(np.abs(np.diff(z)) - max_gradient_pct, 0) ** 2) * 100
        return float(earthworks_cost + grad_penalty)

    res = minimize(cost, control_z, method="Nelder-Mead",
                    options={"maxiter": 300, "xatol": 0.1, "fatol": 1.0})
    return res.x
