"""
engine.geometry.primitives
===========================
Parametric track primitives. Each primitive defines its length and a
curvature function kappa(s_local) for s_local in [0, length]. The
GeometryBuilder (engine.geometry.builder) integrates these curvature
functions into a continuous centreline using cumulative numerical
integration (Euler / cumulative-trapezoid), which is the standard way
road/rail/race-track alignments are generated from curvature.

Supported primitives:
    STRAIGHT, ARC (circular), CLOTHOID (linear curvature ramp / transition
    spiral), HAIRPIN (very small radius arc), CHICANE (composite),
    SWEEPER (large radius, large angle arc), ESS (composite S).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, List, Optional

import numpy as np


class PrimitiveKind(str, Enum):
    STRAIGHT = "STRAIGHT"
    ARC = "CIRCULAR_ARC"
    CLOTHOID = "CLOTHOID"
    HAIRPIN = "HAIRPIN"
    ESS = "ESS"
    SWEEPER = "SWEEPER"
    CHICANE = "CHICANE"
    COMPLEX = "COMPLEX"


@dataclass
class TrackPrimitive:
    """A single geometric building block of the circuit."""

    kind: PrimitiveKind
    length: float                       # arc length of this primitive [m]
    kappa_fn: Callable[[np.ndarray], np.ndarray]  # curvature(s_local) -> 1/m
    elevation_change: float = 0.0       # total dz across the primitive [m]
    banking: float = 0.0                # target banking angle [deg]
    camber: float = 0.0                 # target camber angle [deg]
    width_start: Optional[float] = None
    width_end: Optional[float] = None
    label: str = ""

    def kappa(self, s_local: np.ndarray) -> np.ndarray:
        return self.kappa_fn(np.clip(s_local, 0, self.length))


def straight(length: float, elevation_change: float = 0.0,
             banking: float = 0.0, camber: float = 0.0, label: str = "") -> TrackPrimitive:
    return TrackPrimitive(
        kind=PrimitiveKind.STRAIGHT, length=length,
        kappa_fn=lambda s: np.zeros_like(np.atleast_1d(s), dtype=float),
        elevation_change=elevation_change, banking=banking, camber=camber,
        label=label or "Straight",
    )


def circular_arc(radius: float, angle_deg: float, direction: int = 1,
                  elevation_change: float = 0.0, banking: float = 0.0,
                  camber: float = 0.0, label: str = "") -> TrackPrimitive:
    """direction: +1 = left turn, -1 = right turn."""
    radius = max(abs(radius), 1e-6)
    length = radius * np.radians(abs(angle_deg))
    k = direction * (1.0 / radius)
    return TrackPrimitive(
        kind=PrimitiveKind.ARC, length=length,
        kappa_fn=lambda s: np.full_like(np.atleast_1d(s), k, dtype=float),
        elevation_change=elevation_change, banking=banking, camber=camber,
        label=label or "Arc",
    )


def clothoid(length: float, kappa_start: float, kappa_end: float,
             elevation_change: float = 0.0, banking: float = 0.0,
             camber: float = 0.0, label: str = "") -> TrackPrimitive:
    """Linear curvature transition (Euler spiral approximation)."""
    def kfn(s, L=length, k0=kappa_start, k1=kappa_end):
        s = np.atleast_1d(s)
        t = np.clip(s / max(L, 1e-9), 0, 1)
        return k0 + (k1 - k0) * t
    return TrackPrimitive(
        kind=PrimitiveKind.CLOTHOID, length=length, kappa_fn=kfn,
        elevation_change=elevation_change, banking=banking, camber=camber,
        label=label or "Clothoid",
    )


def hairpin(radius: float, direction: int = 1, angle_deg: float = 150.0,
            elevation_change: float = 0.0, banking: float = 0.0,
            label: str = "") -> TrackPrimitive:
    p = circular_arc(radius=radius, angle_deg=angle_deg, direction=direction,
                      elevation_change=elevation_change, banking=banking,
                      label=label or "Hairpin")
    p.kind = PrimitiveKind.HAIRPIN
    return p


def sweeper(radius: float, angle_deg: float, direction: int = 1,
            elevation_change: float = 0.0, banking: float = 0.0,
            label: str = "") -> TrackPrimitive:
    p = circular_arc(radius=radius, angle_deg=angle_deg, direction=direction,
                      elevation_change=elevation_change, banking=banking,
                      label=label or "Sweeper")
    p.kind = PrimitiveKind.SWEEPER
    return p


def chicane(radius: float, angle_deg: float, transition_length: float,
            gap: float = 20.0, elevation_change: float = 0.0,
            label: str = "") -> List[TrackPrimitive]:
    """Left-right (or right-left) flick composed of two clothoid-eased arcs."""
    r = max(abs(radius), 1e-6)
    k = 1.0 / r
    seq = [
        clothoid(transition_length, 0.0, k, label=f"{label} in-L"),
        circular_arc(r, angle_deg, direction=1, label=f"{label} L"),
        clothoid(transition_length, k, 0.0, label=f"{label} out-L"),
        straight(gap, label=f"{label} link"),
        clothoid(transition_length, 0.0, -k, label=f"{label} in-R"),
        circular_arc(r, angle_deg, direction=-1, label=f"{label} R"),
        clothoid(transition_length, -k, 0.0, label=f"{label} out-R"),
    ]
    if elevation_change:
        seq[0].elevation_change = elevation_change
    return seq


def ess(radius: float, angle_deg: float, transition_length: float,
        label: str = "") -> List[TrackPrimitive]:
    """A tight S-shaped combination — alternating direction arcs, no link straight."""
    r = max(abs(radius), 1e-6)
    k = 1.0 / r
    return [
        clothoid(transition_length, 0.0, k, label=f"{label} in-1"),
        circular_arc(r, angle_deg, direction=1, label=f"{label} 1"),
        clothoid(transition_length, k, -k, label=f"{label} link"),
        circular_arc(r, angle_deg, direction=-1, label=f"{label} 2"),
        clothoid(transition_length, -k, 0.0, label=f"{label} out"),
    ]


def eased_arc(radius: float, angle_deg: float, direction: int = 1,
              transition_length: float = 25.0, elevation_change: float = 0.0,
              banking: float = 0.0, camber: float = 0.0,
              label: str = "") -> List[TrackPrimitive]:
    """A standard racing corner: clothoid entry -> constant arc -> clothoid exit."""
    r = max(abs(radius), 1e-6)
    k = direction * (1.0 / r)
    core_angle = max(angle_deg - (np.degrees(transition_length / (2 * r))), 1.0)
    return [
        clothoid(transition_length, 0.0, k, label=f"{label} entry"),
        circular_arc(r, core_angle, direction=direction, elevation_change=elevation_change,
                      banking=banking, camber=camber, label=label or "Corner"),
        clothoid(transition_length, k, 0.0, label=f"{label} exit"),
    ]
