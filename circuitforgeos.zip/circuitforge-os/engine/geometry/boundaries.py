"""
engine.geometry.boundaries
============================
Derives left/right pavement edges and the pavement polygon from the
centreline + variable track width, and computes pavement area / length /
average width metrics (Sections 18-19).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from shapely.geometry import Polygon

from engine.common import TrackArrays, normals


@dataclass
class TrackBoundaries:
    left_x: np.ndarray
    left_y: np.ndarray
    right_x: np.ndarray
    right_y: np.ndarray
    polygon: Polygon
    pavement_area_m2: float
    track_length_m: float
    average_width_m: float


def compute_boundaries(arrays: TrackArrays) -> TrackBoundaries:
    nx, ny = normals(arrays.heading)
    half_w = arrays.width / 2.0

    left_x = arrays.x + nx * half_w
    left_y = arrays.y + ny * half_w
    right_x = arrays.x - nx * half_w
    right_y = arrays.y - ny * half_w

    ring = list(zip(left_x, left_y)) + list(zip(right_x[::-1], right_y[::-1]))
    try:
        poly = Polygon(ring)
        if not poly.is_valid:
            poly = poly.buffer(0)
        area = float(poly.area)
    except Exception:
        area = float(np.sum(arrays.width) * arrays.ds)

    return TrackBoundaries(
        left_x=left_x, left_y=left_y, right_x=right_x, right_y=right_y,
        polygon=poly if isinstance(poly, Polygon) else Polygon(ring),
        pavement_area_m2=area,
        track_length_m=arrays.length,
        average_width_m=float(np.mean(arrays.width)),
    )
