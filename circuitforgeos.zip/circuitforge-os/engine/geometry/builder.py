"""
engine.geometry.builder
========================
Integrates a sequence of TrackPrimitive objects into a pinpoint-sampled,
continuous centreline using numerical integration of curvature:

    heading(s) = heading0 + integral(kappa(s') ds')
    x(s)       = x0 + integral(cos(heading(s')) ds')
    y(s)       = y0 + integral(sin(heading(s')) ds')

This is the standard curvature-to-Cartesian alignment method used in
road/rail/race-track design and guarantees heading (C1) continuity by
construction, since curvature is integrated rather than fitted.
"""
from __future__ import annotations

from typing import List, Optional, Sequence

import numpy as np

from engine.common import TrackArrays
from engine.geometry.primitives import TrackPrimitive


class GeometryBuilder:
    def __init__(self, resolution_m: float = 1.0):
        self.resolution_m = resolution_m

    def build(self, primitives: Sequence[TrackPrimitive],
              start_width: float = 12.0, close_loop: bool = True) -> TrackArrays:
        ds = self.resolution_m
        total_length = sum(p.length for p in primitives)
        n = max(int(round(total_length / ds)), 2)

        s = np.linspace(0, total_length, n, endpoint=False)
        kappa = np.zeros(n)
        gradient_target = np.zeros(n)   # dz/ds per-sample target (from elevation_change/length)
        banking = np.zeros(n)
        camber = np.zeros(n)
        width = np.full(n, start_width)

        cursor = 0.0
        for prim in primitives:
            mask = (s >= cursor) & (s < cursor + prim.length)
            if np.any(mask):
                s_local = s[mask] - cursor
                kappa[mask] = prim.kappa(s_local)
                if prim.length > 0:
                    gradient_target[mask] = prim.elevation_change / prim.length
                banking[mask] = prim.banking
                camber[mask] = prim.camber
                if prim.width_start is not None and prim.width_end is not None:
                    t = s_local / prim.length
                    width[mask] = prim.width_start + t * (prim.width_end - prim.width_start)
            cursor += prim.length

        heading = np.cumsum(kappa) * ds
        heading = heading - heading[0]

        x = np.cumsum(np.cos(heading)) * ds
        y = np.cumsum(np.sin(heading)) * ds
        x -= x[0]
        y -= y[0]

        if close_loop and n > 2:
            # Correct residual closure error by removing a linear drift
            # component (keeps the loop geometrically closed for a track
            # whose primitives were designed to sum to 360 degrees of turn).
            closure_dx, closure_dy = x[-1] + np.cos(heading[-1]) * ds - x[0], \
                                      y[-1] + np.sin(heading[-1]) * ds - y[0]
            correction = np.linspace(0, 1, n)
            x -= correction * closure_dx
            y -= correction * closure_dy

        z = np.cumsum(gradient_target) * ds
        gradient = np.gradient(z, ds)

        return TrackArrays(
            s=s, x=x, y=y, z=z, heading=heading, curvature=kappa,
            gradient=gradient, banking=banking, camber=camber, width=width,
        )

    @staticmethod
    def closure_error(arrays: TrackArrays) -> float:
        """Euclidean distance between the last and first sample (should be ~ds for a closed loop)."""
        return float(np.hypot(arrays.x[-1] - arrays.x[0], arrays.y[-1] - arrays.y[0]))
