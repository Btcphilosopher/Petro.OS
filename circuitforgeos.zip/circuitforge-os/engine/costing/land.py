"""engine.costing.land — Land-requirement aggregation (Section 61)."""
from __future__ import annotations
from dataclasses import dataclass


@dataclass
class LandRequirement:
    track_footprint_m2: float
    runoff_m2: float
    service_roads_m2: float
    paddock_m2: float
    pit_complex_m2: float
    parking_m2: float
    landscape_buffer_m2: float

    @property
    def total_site_area_m2(self) -> float:
        return (self.track_footprint_m2 + self.runoff_m2 + self.service_roads_m2
                + self.paddock_m2 + self.pit_complex_m2 + self.parking_m2
                + self.landscape_buffer_m2)

    @property
    def total_site_area_km2(self) -> float:
        return self.total_site_area_m2 / 1_000_000.0


def compute_land_requirement(track_footprint_m2: float, runoff_m2: float,
                              service_road_length_m: float, pit_complex_m2: float,
                              cfg: dict, track_perimeter_m: float) -> LandRequirement:
    land_cfg = cfg["land"]
    service_road_width = 6.0
    buffer_m = land_cfg.get("landscape_buffer_m", 25)
    buffer_area = track_perimeter_m * buffer_m  # ring buffer approximation
    return LandRequirement(
        track_footprint_m2=track_footprint_m2,
        runoff_m2=runoff_m2,
        service_roads_m2=service_road_length_m * service_road_width,
        paddock_m2=land_cfg.get("paddock_area_m2", 0),
        pit_complex_m2=pit_complex_m2,
        parking_m2=land_cfg.get("parking_area_m2", 0),
        landscape_buffer_m2=buffer_area,
    )
