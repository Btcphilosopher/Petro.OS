"""
engine.costing.engine
=======================
Configurable conceptual construction-cost model (Section 60). Unit
costs are NOT authoritative real-world prices — they are user-editable
synthetic parameters (see config.yaml: costing.unit_costs).
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict


@dataclass
class CostBreakdown:
    earthworks: float
    pavement: float
    drainage: float
    runoff: float
    barriers: float
    service_roads: float
    pit_infrastructure: float
    land_preparation: float
    currency_note: str

    @property
    def total(self) -> float:
        return (self.earthworks + self.pavement + self.drainage + self.runoff
                + self.barriers + self.service_roads + self.pit_infrastructure
                + self.land_preparation)

    def as_dict(self) -> Dict[str, float]:
        d = {
            "earthworks": self.earthworks, "pavement": self.pavement,
            "drainage": self.drainage, "runoff": self.runoff,
            "barriers": self.barriers, "service_roads": self.service_roads,
            "pit_infrastructure": self.pit_infrastructure,
            "land_preparation": self.land_preparation, "total": self.total,
        }
        return d


def compute_cost(earthworks_m3: float, pavement_m2: float, drainage_m: float,
                  runoff_m2: float, barrier_m: float, service_road_m2: float,
                  pit_area_m2: float, land_area_m2: float, cfg: dict) -> CostBreakdown:
    uc = cfg["unit_costs"]
    return CostBreakdown(
        earthworks=earthworks_m3 * uc["earthworks_per_m3"],
        pavement=pavement_m2 * uc["pavement_per_m2"],
        drainage=drainage_m * uc["drainage_per_m"],
        runoff=runoff_m2 * uc["runoff_per_m2"],
        barriers=barrier_m * uc["barrier_per_m"],
        service_roads=service_road_m2 * uc["service_road_per_m2"],
        pit_infrastructure=pit_area_m2 * uc["pit_infrastructure_per_m2"],
        land_preparation=land_area_m2 * uc["land_prep_per_m2"],
        currency_note=cfg.get("currency", "synthetic unit cost, non-authoritative"),
    )
