"""engine.construction.schedule — ConstructionSchedule / simple Gantt (Section 58)."""
from __future__ import annotations
from dataclasses import dataclass
from typing import List

from engine.construction.phases import ConstructionPhase

# Simple linear dependency chain in listed order — later phases follow
# civil-engineering convention (earthworks before pavement, etc.)
DEFAULT_DEPENDENCY_ORDER = [
    "SITE PREPARATION", "EARTHWORKS", "DRAINAGE", "SUBBASE", "BASE",
    "PAVEMENT", "KERBS", "RUNOFF", "BARRIERS", "PIT FACILITIES",
    "SERVICE ROADS", "LANDSCAPING",
]


@dataclass
class ScheduledPhase:
    name: str
    start_day: float
    end_day: float
    duration_days: float
    crew_size: int


@dataclass
class ConstructionSchedule:
    phases: List[ScheduledPhase]
    total_duration_days: float


def build_schedule(phases: List[ConstructionPhase], overlap_fraction: float = 0.15) -> ConstructionSchedule:
    by_name = {p.name.value: p for p in phases}
    scheduled = []
    cursor = 0.0
    for name in DEFAULT_DEPENDENCY_ORDER:
        p = by_name.get(name)
        if p is None:
            continue
        start = max(cursor - p.duration_days * overlap_fraction, 0.0)
        end = start + p.duration_days
        scheduled.append(ScheduledPhase(name=name, start_day=round(start, 1), end_day=round(end, 1),
                                         duration_days=p.duration_days, crew_size=p.crew_size))
        cursor = end
    total = max((s.end_day for s in scheduled), default=0.0)
    return ConstructionSchedule(phases=scheduled, total_duration_days=round(total, 1))
