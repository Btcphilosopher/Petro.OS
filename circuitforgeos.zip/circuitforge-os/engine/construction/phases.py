"""engine.construction.phases — Construction phase model (Section 57)."""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from typing import List


class PhaseName(str, Enum):
    SITE_PREPARATION = "SITE PREPARATION"
    EARTHWORKS = "EARTHWORKS"
    DRAINAGE = "DRAINAGE"
    SUBBASE = "SUBBASE"
    BASE = "BASE"
    PAVEMENT = "PAVEMENT"
    KERBS = "KERBS"
    RUNOFF = "RUNOFF"
    BARRIERS = "BARRIERS"
    PIT_FACILITIES = "PIT FACILITIES"
    SERVICE_ROADS = "SERVICE ROADS"
    LANDSCAPING = "LANDSCAPING"


@dataclass
class ConstructionPhase:
    name: PhaseName
    quantity: float
    unit: str
    productivity_per_day: float
    crew_size: int
    duration_days: float = 0.0

    def __post_init__(self):
        self.duration_days = round(self.quantity / max(self.productivity_per_day, 1e-6), 1)


def build_phases(earthworks_m3: float, pavement_m2: float, drainage_m: float,
                  runoff_m2: float, barrier_m: float, service_road_m2: float,
                  pit_area_m2: float) -> List[ConstructionPhase]:
    return [
        ConstructionPhase(PhaseName.SITE_PREPARATION, pavement_m2, "m2", 8000, 6),
        ConstructionPhase(PhaseName.EARTHWORKS, earthworks_m3, "m3", 1800, 14),
        ConstructionPhase(PhaseName.DRAINAGE, drainage_m, "m", 120, 8),
        ConstructionPhase(PhaseName.SUBBASE, pavement_m2, "m2", 3500, 10),
        ConstructionPhase(PhaseName.BASE, pavement_m2, "m2", 3000, 10),
        ConstructionPhase(PhaseName.PAVEMENT, pavement_m2, "m2", 2200, 12),
        ConstructionPhase(PhaseName.KERBS, pavement_m2 ** 0.5 * 20, "m", 250, 6),
        ConstructionPhase(PhaseName.RUNOFF, runoff_m2, "m2", 4500, 8),
        ConstructionPhase(PhaseName.BARRIERS, barrier_m, "m", 180, 6),
        ConstructionPhase(PhaseName.PIT_FACILITIES, pit_area_m2, "m2", 90, 20),
        ConstructionPhase(PhaseName.SERVICE_ROADS, service_road_m2, "m2", 1800, 8),
        ConstructionPhase(PhaseName.LANDSCAPING, pavement_m2, "m2", 6000, 5),
    ]
