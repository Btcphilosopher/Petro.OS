"""
engine.construction.pit
=========================
Conceptual pit complex model (Sections 62-63): pit lane geometry and
supporting facility footprints, represented as configurable geometric
objects with basic travel-time estimation.
"""
from __future__ import annotations
from dataclasses import dataclass


@dataclass
class PitLane:
    length_m: float = 350.0
    width_m: float = 8.0
    speed_limit_kmh: float = 60.0
    entry_s: float = 0.0
    exit_s: float = 350.0

    def travel_time_s(self, accel_zone_frac: float = 0.15) -> float:
        v = self.speed_limit_kmh / 3.6
        accel_len = self.length_m * accel_zone_frac
        decel_len = accel_len
        cruise_len = max(self.length_m - accel_len - decel_len, 0)
        a = 3.0  # m/s^2 conceptual accel/decel
        t_accel = v / a
        t_decel = v / a
        t_cruise = cruise_len / v
        return round(t_accel + t_cruise + t_decel, 2)


@dataclass
class PitComplex:
    pit_lane: PitLane
    garage_count: int = 24
    garage_area_m2: float = 90.0
    paddock_area_m2: float = 45000.0
    race_control_area_m2: float = 400.0
    medical_area_m2: float = 600.0
    scrutineering_area_m2: float = 500.0
    media_centre_area_m2: float = 800.0
    hospitality_area_m2: float = 3500.0

    @property
    def total_pit_building_area_m2(self) -> float:
        return (self.garage_count * self.garage_area_m2 + self.race_control_area_m2
                + self.medical_area_m2 + self.scrutineering_area_m2
                + self.media_centre_area_m2 + self.hospitality_area_m2)

    @property
    def total_complex_area_m2(self) -> float:
        return self.total_pit_building_area_m2 + self.paddock_area_m2
