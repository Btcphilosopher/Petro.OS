"""engine.construction.equipment — Construction equipment simulation (Section 59)."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict


@dataclass
class Equipment:
    name: str
    capacity: float          # m3/load or m2/pass depending on class
    productivity_per_day: float
    fuel_l_per_day: float
    cost_per_day: float
    availability_pct: float = 0.9


EQUIPMENT_LIBRARY: Dict[str, Equipment] = {
    "excavator": Equipment("Excavator", capacity=1.5, productivity_per_day=900, fuel_l_per_day=180, cost_per_day=650),
    "bulldozer": Equipment("Bulldozer", capacity=8.0, productivity_per_day=1200, fuel_l_per_day=220, cost_per_day=700),
    "grader": Equipment("Grader", capacity=3.5, productivity_per_day=4000, fuel_l_per_day=110, cost_per_day=550),
    "dump_truck": Equipment("Dump Truck", capacity=15.0, productivity_per_day=1800, fuel_l_per_day=90, cost_per_day=420),
    "roller": Equipment("Roller", capacity=0.0, productivity_per_day=6000, fuel_l_per_day=70, cost_per_day=380),
    "paver": Equipment("Paver", capacity=0.0, productivity_per_day=2200, fuel_l_per_day=130, cost_per_day=900),
    "crane": Equipment("Crane", capacity=0.0, productivity_per_day=0, fuel_l_per_day=60, cost_per_day=1100),
}


def fleet_for_earthworks(volume_m3: float) -> Dict[str, int]:
    excavators = max(int(volume_m3 // 12000) + 1, 1)
    dozers = max(excavators // 2, 1)
    trucks = max(excavators * 3, 2)
    return {"excavator": excavators, "bulldozer": dozers, "dump_truck": trucks, "grader": 2, "roller": 2}


def fleet_for_pavement(area_m2: float) -> Dict[str, int]:
    return {"paver": max(int(area_m2 // 20000) + 1, 1), "roller": 3, "dump_truck": 4}


def estimate_daily_cost(fleet: Dict[str, int]) -> float:
    return sum(EQUIPMENT_LIBRARY[k].cost_per_day * n for k, n in fleet.items() if k in EQUIPMENT_LIBRARY)
