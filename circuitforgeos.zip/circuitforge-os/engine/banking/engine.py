"""
engine.banking.engine
=======================
BankingProfile: smooth (no-instantaneous-change) banking angle vs
distance, built from (s, banking_deg) control points using a PCHIP
spline (monotone / overshoot-safe), with explicit transition-distance
reporting (Section 15).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Sequence

import numpy as np

from engine.spline.profiles import ControlPoint, ProfileSpline


@dataclass
class BankingTransition:
    start_s: float
    peak_s: float
    end_s: float
    start_deg: float
    peak_deg: float
    end_deg: float
    transition_length_m: float


class BankingProfile:
    def __init__(self, control_points: Sequence[ControlPoint], kind: str = "pchip"):
        self.control_points = list(control_points)
        self.spline = ProfileSpline(self.control_points, kind=kind)

    def evaluate(self, s: np.ndarray) -> np.ndarray:
        return self.spline(s)

    def transitions(self) -> List[BankingTransition]:
        """Report each consecutive pair of control points as a transition."""
        out = []
        pts = sorted(self.control_points, key=lambda c: c.s)
        for a, b in zip(pts[:-1], pts[1:]):
            out.append(BankingTransition(
                start_s=a.s, peak_s=b.s, end_s=b.s,
                start_deg=a.value, peak_deg=b.value, end_deg=b.value,
                transition_length_m=b.s - a.s,
            ))
        return out

    @classmethod
    def constant(cls, length: float, angle_deg: float) -> "BankingProfile":
        return cls([ControlPoint(0, angle_deg), ControlPoint(length, angle_deg)])

    @classmethod
    def flat(cls, length: float) -> "BankingProfile":
        return cls.constant(length, 0.0)
