"""
engine.drainage.engine
========================
DrainageModel (Section 49): conceptual surface-drainage analysis from
track gradient + crossfall (camber), identifying local low points and
approximate water-flow direction. NOT a final civil-engineering design.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

import numpy as np

from engine.common import TrackArrays


@dataclass
class DrainagePoint:
    s: float
    x: float
    y: float
    z: float
    flow_direction_deg: float


@dataclass
class DrainageReport:
    low_points: List[DrainagePoint]
    collection_points: List[DrainagePoint]
    corridor_length_m: float
    disclaimer: str = "Conceptual surface-drainage estimate only — not a certified civil design."


def analyse_drainage(arrays: TrackArrays) -> DrainageReport:
    z = arrays.z
    grad = arrays.gradient
    # local minima of elevation = low points where water tends to collect
    is_min = (np.roll(z, 1) > z) & (np.roll(z, -1) > z)
    idx = np.where(is_min)[0]

    low_points = []
    for i in idx:
        # flow direction: downhill along centreline, deflected by camber sign
        camber = arrays.camber[i]
        base_heading = arrays.heading[i]
        deflection = np.radians(np.clip(camber, -15, 15)) * np.sign(camber if camber != 0 else 1)
        flow_dir = np.degrees(base_heading + np.pi / 2 * np.sign(camber if camber != 0 else 1) + deflection) % 360
        low_points.append(DrainagePoint(s=float(arrays.s[i]), x=float(arrays.x[i]), y=float(arrays.y[i]),
                                         z=float(z[i]), flow_direction_deg=float(flow_dir)))

    # collection points: cluster low points further than 150 m apart
    collection = []
    last_s = -1e9
    for p in low_points:
        if p.s - last_s > 150:
            collection.append(p)
            last_s = p.s

    corridor_length = float(np.sum(np.abs(grad) > 0.001) * arrays.ds)

    return DrainageReport(low_points=low_points, collection_points=collection,
                           corridor_length_m=corridor_length)
