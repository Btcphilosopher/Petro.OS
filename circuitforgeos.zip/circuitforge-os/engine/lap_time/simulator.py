"""
engine.lap_time.simulator
===========================
LapTimeSimulator (Section 32-34): classic quasi-steady-state (QSS) point-
mass lap-time simulation.

Algorithm
---------
1. v_limit(s): steady-state maximum speed at every point from cornering
   physics (curvature + friction + downforce + banking + camber),
   capped by the vehicle's power-limited top speed.
2. Forward pass: integrate acceleration (engine force - resistances)
   from each point to the next, capped by v_limit — models how fast the
   car *can* be going, limited by traction out of corners.
3. Backward pass: integrate maximum braking deceleration backward from
   each point, capped by v_limit — models the latest point the car can
   still be going fast, given it must slow for the corner ahead.
4. v(s) = min(v_limit, v_forward, v_backward) — the achievable speed
   trace, from which lap time, sector times, braking zones and the G-G
   diagram are derived.

This is a standard simplified method used across race-engineering
software; it does not model transient tyre/suspension dynamics.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from engine.common import G, TrackArrays
from engine.physics.cornering import max_corner_speed
from engine.physics.longitudinal import net_acceleration
from engine.vehicle.model import Vehicle


@dataclass
class LapTimeResult:
    s: np.ndarray
    speed_ms: np.ndarray
    speed_kmh: np.ndarray
    longitudinal_accel: np.ndarray
    lateral_accel: np.ndarray
    total_time_s: float
    average_speed_kmh: float
    max_speed_kmh: float
    braking_zones: list
    v_limit_ms: np.ndarray

    @property
    def lap_time_str(self) -> str:
        m = int(self.total_time_s // 60)
        sec = self.total_time_s - m * 60
        return f"{m}:{sec:05.2f}"


def simulate_lap(arrays: TrackArrays, vehicle: Vehicle, air_density: float = 1.225,
                  driver_skill: float = 1.0) -> LapTimeResult:
    ds = arrays.ds
    n = len(arrays.s)
    v_top = vehicle.top_speed_estimate(air_density)

    v_limit = max_corner_speed(vehicle, arrays.curvature, arrays.banking, arrays.camber,
                                air_density, v_top=v_top)
    v_limit *= np.clip(driver_skill, 0.5, 1.05)
    v_limit = np.minimum(v_limit, v_top)

    # ---- forward pass (acceleration-limited) ----
    v_fwd = np.empty(n)
    v_fwd[0] = v_limit[0]
    for i in range(1, n):
        a = net_acceleration(vehicle, v_fwd[i - 1], arrays.gradient[i - 1], air_density)
        v_candidate = np.sqrt(max(v_fwd[i - 1] ** 2 + 2 * a * ds, 0.0))
        v_fwd[i] = min(v_candidate, v_limit[i])

    # ---- backward pass (braking-limited), circuit wraps around ----
    v_bwd = np.array(v_limit, copy=True)
    for _ in range(2):  # two passes around the loop to converge braking into the final corner
        for i in range(n - 2, -1, -1):
            a = net_acceleration(vehicle, v_bwd[i + 1], arrays.gradient[i + 1], air_density, braking=True)
            v_candidate = np.sqrt(max(v_bwd[i + 1] ** 2 - 2 * a * ds, 0.0))
            v_bwd[i] = min(v_bwd[i], v_candidate, v_limit[i])

    v = np.minimum(np.minimum(v_fwd, v_bwd), v_limit)
    v = np.maximum(v, 1.0)

    dt = ds / v
    total_time = float(np.sum(dt))

    a_long = np.gradient(v, ds) * v  # dv/ds * v = dv/dt (chain rule along path)
    a_lat = v ** 2 * arrays.curvature

    # braking zones: contiguous regions where dv/ds < -small threshold
    braking_mask = np.gradient(v, ds) < -0.02
    zones = []
    idx = 0
    while idx < n:
        if braking_mask[idx]:
            start = idx
            while idx < n and braking_mask[idx]:
                idx += 1
            end = idx - 1
            zones.append({
                "braking_start_s": float(arrays.s[start]),
                "braking_distance_m": float(arrays.s[end] - arrays.s[start]),
                "braking_time_s": float(np.sum(dt[start:end + 1])),
                "entry_speed_kmh": float(v[start] * 3.6),
                "exit_speed_kmh": float(v[end] * 3.6),
            })
        else:
            idx += 1

    return LapTimeResult(
        s=arrays.s, speed_ms=v, speed_kmh=v * 3.6,
        longitudinal_accel=a_long, lateral_accel=a_lat,
        total_time_s=total_time, average_speed_kmh=float(np.mean(v) * 3.6),
        max_speed_kmh=float(np.max(v) * 3.6), braking_zones=zones,
        v_limit_ms=v_limit,
    )


def gg_diagram(result: LapTimeResult) -> tuple[np.ndarray, np.ndarray]:
    """Return (lateral_g, longitudinal_g) arrays for a G-G diagram (Section 34)."""
    return result.lateral_accel / G, result.longitudinal_accel / G
