"""
engine.lap_time.traffic
=========================
TrafficSimulator (Section 41) and overtaking-zone analysis (Section 42).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

import numpy as np

from engine.common import TrackArrays
from engine.lap_time.simulator import LapTimeResult
from engine.topology.straights import Straight


@dataclass
class TrafficVehicle:
    name: str
    lap: LapTimeResult
    start_offset_s: float = 0.0

    def position_at(self, t: float) -> float:
        """Approximate arc-length position at time t via the lap speed trace."""
        cum_t = np.cumsum(self.lap.s * 0 + (self.lap.s[1] - self.lap.s[0]) / np.maximum(self.lap.speed_ms, 1))
        idx = int(np.searchsorted(cum_t, t % self.lap.total_time_s))
        idx = min(idx, len(self.lap.s) - 1)
        return float(self.lap.s[idx]) + self.start_offset_s


@dataclass
class TrafficSimulator:
    vehicles: List[TrafficVehicle] = field(default_factory=list)

    def add_vehicle(self, vehicle: TrafficVehicle):
        self.vehicles.append(vehicle)

    def density(self, track_length: float) -> float:
        return len(self.vehicles) / max(track_length / 1000.0, 1e-6)  # vehicles per km


@dataclass
class OvertakingZone:
    straight_index: int
    start_s: float
    length_m: float
    score: float


def detect_overtaking_zones(straights: List[Straight], lap: LapTimeResult,
                             track_width_avg: float) -> List[OvertakingZone]:
    zones = []
    for st in straights:
        mask = (lap.s >= st.start_s) & (lap.s <= st.end_s)
        if not np.any(mask):
            continue
        v = lap.speed_kmh[mask]
        speed_delta = float(np.max(v) - np.min(v))
        braking_present = 1.0 if np.any(np.diff(v) < -1) else 0.5
        width_factor = min(track_width_avg / 12.0, 1.5)
        score = (st.length_m / 100.0) * 0.4 + speed_delta * 0.3 + braking_present * 20 * width_factor
        zones.append(OvertakingZone(st.index, st.start_s, st.length_m, round(score, 1)))
    zones.sort(key=lambda z: -z.score)
    return zones
