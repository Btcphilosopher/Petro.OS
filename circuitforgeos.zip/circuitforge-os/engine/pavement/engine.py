"""engine.pavement.engine — Pavement quantity take-off (Section 56). Conceptual only."""
from __future__ import annotations
from dataclasses import dataclass


@dataclass
class PavementResult:
    surface_area_m2: float
    base_area_m2: float
    subbase_area_m2: float
    surface_volume_m3: float
    base_volume_m3: float
    subbase_volume_m3: float
    total_pavement_volume_m3: float


def compute_pavement(pavement_area_m2: float, cfg: dict) -> PavementResult:
    st = cfg.get("surface_thickness_m", 0.05)
    bt = cfg.get("base_thickness_m", 0.15)
    sbt = cfg.get("subbase_thickness_m", 0.20)
    surface_v = pavement_area_m2 * st
    base_v = pavement_area_m2 * bt
    subbase_v = pavement_area_m2 * sbt
    return PavementResult(
        surface_area_m2=pavement_area_m2, base_area_m2=pavement_area_m2,
        subbase_area_m2=pavement_area_m2, surface_volume_m3=surface_v,
        base_volume_m3=base_v, subbase_volume_m3=subbase_v,
        total_pavement_volume_m3=surface_v + base_v + subbase_v,
    )
