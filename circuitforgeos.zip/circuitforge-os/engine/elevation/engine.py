"""
engine.elevation.engine
=========================
ElevationProfile: builds z(s), gradient(s) = dz/ds and an approximate
vertical acceleration dz''/ds^2 * v^2 term, from sparse elevation control
points. Supports named archetypes (hill, crest, valley, roller) as
convenience constructors (Section 12).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Sequence

import numpy as np

from engine.spline.profiles import ControlPoint, ProfileSpline


@dataclass
class ElevationResult:
    z: np.ndarray
    gradient: np.ndarray           # dz/ds
    gradient_pct: np.ndarray       # grade in %
    gradient_deg: np.ndarray       # grade in degrees
    curvature_vertical: np.ndarray  # d^2z/ds^2 (crest/compression indicator)
    max_uphill_pct: float
    max_downhill_pct: float
    crest_indices: np.ndarray
    compression_indices: np.ndarray


class ElevationProfile:
    def __init__(self, control_points: Sequence[ControlPoint], kind: str = "pchip"):
        self.spline = ProfileSpline(control_points, kind=kind)

    def evaluate(self, s: np.ndarray) -> ElevationResult:
        z = self.spline(s)
        ds = float(s[1] - s[0]) if len(s) > 1 else 1.0
        grad = np.gradient(z, ds)
        grad_pct = grad * 100.0
        grad_deg = np.degrees(np.arctan(grad))
        vcurv = np.gradient(grad, ds)
        crest_idx = np.where((vcurv < -1e-4))[0]
        comp_idx = np.where((vcurv > 1e-4))[0]
        return ElevationResult(
            z=z, gradient=grad, gradient_pct=grad_pct, gradient_deg=grad_deg,
            curvature_vertical=vcurv,
            max_uphill_pct=float(np.max(grad_pct)) if len(grad_pct) else 0.0,
            max_downhill_pct=float(np.min(grad_pct)) if len(grad_pct) else 0.0,
            crest_indices=crest_idx, compression_indices=comp_idx,
        )

    @classmethod
    def flat(cls, length: float) -> "ElevationProfile":
        return cls([ControlPoint(0, 0), ControlPoint(length, 0)])

    @classmethod
    def hill(cls, length: float, peak_height: float, peak_frac: float = 0.5) -> "ElevationProfile":
        peak_s = length * peak_frac
        return cls([
            ControlPoint(0, 0), ControlPoint(peak_s, peak_height), ControlPoint(length, 0),
        ])

    @classmethod
    def roller(cls, length: float, amplitude: float, n_waves: int = 4) -> "ElevationProfile":
        s_ctrl = np.linspace(0, length, n_waves * 2 + 1)
        z_ctrl = amplitude * np.sin(np.linspace(0, n_waves * np.pi, len(s_ctrl)))
        return cls([ControlPoint(s, z) for s, z in zip(s_ctrl, z_ctrl)])

    @classmethod
    def valley(cls, length: float, depth: float, valley_frac: float = 0.5) -> "ElevationProfile":
        return cls.hill(length, -depth, valley_frac)
