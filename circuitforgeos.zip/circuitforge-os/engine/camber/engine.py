"""
engine.camber.engine
======================
CamberProfile: cross-slope of the pavement (positive = falls away from
the racing line toward the outside, aiding drainage; negative = adverse
camber). Tracks camber_angle(s) and camber_gradient(s) (Section 16).
"""
from __future__ import annotations

from typing import Sequence

import numpy as np

from engine.spline.profiles import ControlPoint, ProfileSpline


class CamberProfile:
    def __init__(self, control_points: Sequence[ControlPoint], kind: str = "pchip"):
        self.spline = ProfileSpline(control_points, kind=kind)

    def evaluate(self, s: np.ndarray):
        angle = self.spline(s)
        ds = float(s[1] - s[0]) if len(s) > 1 else 1.0
        grad = np.gradient(angle, ds)
        return angle, grad

    @classmethod
    def constant(cls, length: float, angle_deg: float = 2.0) -> "CamberProfile":
        return cls([ControlPoint(0, angle_deg), ControlPoint(length, angle_deg)])
