"""
engine.spline.profiles
========================
Generic scalar-profile-along-track spline builder used by elevation,
banking, camber and width engines. Wraps SciPy's CubicSpline / PCHIP /
BSpline interpolators and offers continuity checking (C0/C1/C2).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Sequence

import numpy as np
from scipy.interpolate import CubicSpline, PchipInterpolator, BSpline, splrep

Kind = Literal["cubic", "pchip", "bspline", "linear", "constant"]


@dataclass
class ControlPoint:
    s: float
    value: float


class ProfileSpline:
    """Builds and evaluates a 1D profile value(s) from sparse control points."""

    def __init__(self, control_points: Sequence[ControlPoint], kind: Kind = "pchip"):
        if len(control_points) == 0:
            raise ValueError("At least one control point is required")
        pts = sorted(control_points, key=lambda c: c.s)
        self.s_ctrl = np.array([p.s for p in pts], dtype=float)
        self.v_ctrl = np.array([p.value for p in pts], dtype=float)
        self.kind = kind
        self._fn = self._build()

    def _build(self):
        if len(self.s_ctrl) == 1:
            v0 = self.v_ctrl[0]
            return lambda s: np.full_like(np.atleast_1d(s), v0, dtype=float)
        if self.kind == "cubic":
            return CubicSpline(self.s_ctrl, self.v_ctrl, bc_type="natural")
        if self.kind == "pchip":
            return PchipInterpolator(self.s_ctrl, self.v_ctrl)
        if self.kind == "bspline":
            k = min(3, len(self.s_ctrl) - 1)
            tck = splrep(self.s_ctrl, self.v_ctrl, k=k)
            bs = BSpline(*tck)
            return bs
        if self.kind == "linear":
            return lambda s: np.interp(s, self.s_ctrl, self.v_ctrl)
        # constant / step
        return lambda s: np.interp(s, self.s_ctrl, self.v_ctrl)

    def __call__(self, s: np.ndarray) -> np.ndarray:
        s_clamped = np.clip(s, self.s_ctrl[0], self.s_ctrl[-1])
        return np.asarray(self._fn(s_clamped), dtype=float)

    def derivative(self, s: np.ndarray, order: int = 1) -> np.ndarray:
        s_clamped = np.clip(s, self.s_ctrl[0], self.s_ctrl[-1])
        if hasattr(self._fn, "derivative"):
            return np.asarray(self._fn.derivative(order)(s_clamped), dtype=float)
        # numerical fallback
        h = 1e-3
        return (self(s_clamped + h) - self(s_clamped - h)) / (2 * h)


def continuity_report(values: np.ndarray, ds: float, tol_c1: float = 5.0,
                       tol_c2: float = 50.0) -> dict:
    """
    Estimate C0/C1/C2 continuity of a sampled profile.
    C0: no NaN / no discontinuous jumps beyond tol.
    C1: first-derivative jumps below tol_c1 (units/m).
    C2: second-derivative jumps below tol_c2 (units/m^2).
    """
    d0_jumps = np.abs(np.diff(values))
    d1 = np.gradient(values, ds)
    d1_jumps = np.abs(np.diff(d1))
    d2 = np.gradient(d1, ds)
    d2_jumps = np.abs(np.diff(d2))
    return {
        "C0_continuous": bool(np.all(np.isfinite(values))),
        "C1_continuous": bool(np.nanmax(d1_jumps) < tol_c1) if len(d1_jumps) else True,
        "C2_continuous": bool(np.nanmax(d2_jumps) < tol_c2) if len(d2_jumps) else True,
        "max_first_derivative_jump": float(np.nanmax(d1_jumps)) if len(d1_jumps) else 0.0,
        "max_second_derivative_jump": float(np.nanmax(d2_jumps)) if len(d2_jumps) else 0.0,
    }
