"""
engine.runoff.engine
======================
Runoff-zone sizing (Section 46) — conceptual, speed-dependent runoff
depth per corner/straight, producing polygons (via Shapely buffer) and
area/earthworks/land-requirement inputs.

Depth guidance (NOT a certified standard) follows the general FIA-style
principle that runoff should scale with local speed: higher speed
sections receive deeper conceptual runoff.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List

import numpy as np
from shapely.geometry import Polygon
from shapely.ops import unary_union

from engine.common import TrackArrays, normals


@dataclass
class RunoffZone:
    start_s: float
    end_s: float
    depth_m: float
    side: str            # "left" | "right" | "both"
    area_m2: float


def _depth_for_speed(speed_kmh: float, cfg: dict) -> float:
    if speed_kmh < 100:
        return cfg["runoff_depth_slow_m"]
    if speed_kmh < 160:
        return cfg["runoff_depth_medium_m"]
    if speed_kmh < 220:
        return cfg["runoff_depth_fast_m"]
    return cfg["runoff_depth_extreme_m"]


def compute_runoff_zones(arrays: TrackArrays, speed_kmh: np.ndarray, cfg: dict,
                          segment_len_m: float = 100.0) -> List[RunoffZone]:
    zones = []
    total = arrays.length
    n_segments = max(int(total // segment_len_m), 1)
    nx, ny = normals(arrays.heading)
    for i in range(n_segments):
        s0 = i * segment_len_m
        s1 = min((i + 1) * segment_len_m, total)
        mask = (arrays.s >= s0) & (arrays.s < s1)
        if not np.any(mask):
            continue
        v = float(np.mean(speed_kmh[mask]))
        depth = _depth_for_speed(v, cfg)
        half_w = float(np.mean(arrays.width[mask])) / 2.0
        seg_len = s1 - s0
        area = seg_len * depth * 2  # both sides, conceptual rectangle
        zones.append(RunoffZone(start_s=s0, end_s=s1, depth_m=depth, side="both", area_m2=area))
    return zones


def total_runoff_area(zones: List[RunoffZone]) -> float:
    return float(sum(z.area_m2 for z in zones))
