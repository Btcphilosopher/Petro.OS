"""
engine.topology.character
===========================
Circuit design-character metrics (Section 43) and Circuit Complexity
Index (Section 44).
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import List

import numpy as np

from engine.common import TrackArrays
from engine.topology.corners import Corner
from engine.topology.straights import Straight


@dataclass
class CircuitCharacter:
    corner_density_per_km: float
    average_corner_speed_kmh: float
    slow_corner_pct: float
    high_speed_corner_pct: float
    straight_pct: float
    elevation_change_m: float
    max_gradient_pct: float
    direction_changes_per_km: float
    corners_per_km: float
    braking_zones_per_km: float
    elevation_events_per_km: float
    complexity_index: float


def compute_character(arrays: TrackArrays, corners: List[Corner], straights: List[Straight],
                       lap_speed_kmh: np.ndarray, n_braking_zones: int) -> CircuitCharacter:
    length_km = arrays.length / 1000.0
    n_corners = len(corners)
    slow = sum(1 for c in corners if c.min_radius_m < 40)
    fast = sum(1 for c in corners if c.min_radius_m >= 80)
    straight_len = sum(s.length_m for s in straights)

    corner_speeds = []
    for c in corners:
        seg = lap_speed_kmh[c.start_idx:c.end_idx + 1]
        if len(seg):
            corner_speeds.append(float(np.min(seg)))
    avg_corner_speed = float(np.mean(corner_speeds)) if corner_speeds else 0.0

    heading_diff = np.abs(np.diff(np.sign(arrays.curvature[np.abs(arrays.curvature) > 1e-4])))
    direction_changes = int(np.sum(heading_diff == 2))

    elevation_events = int(np.sum(np.abs(np.diff(np.sign(np.gradient(arrays.z)))) > 0))

    complexity = (
        (n_corners / max(length_km, 1e-6)) * 1.0
        + (direction_changes / max(length_km, 1e-6)) * 0.5
        + (n_braking_zones / max(length_km, 1e-6)) * 0.7
        + (elevation_events / max(length_km, 1e-6)) * 0.3
    )

    return CircuitCharacter(
        corner_density_per_km=n_corners / max(length_km, 1e-6),
        average_corner_speed_kmh=avg_corner_speed,
        slow_corner_pct=100.0 * slow / max(n_corners, 1),
        high_speed_corner_pct=100.0 * fast / max(n_corners, 1),
        straight_pct=100.0 * straight_len / max(arrays.length, 1e-6),
        elevation_change_m=float(np.max(arrays.z) - np.min(arrays.z)),
        max_gradient_pct=float(np.max(np.abs(arrays.gradient)) * 100.0),
        direction_changes_per_km=direction_changes / max(length_km, 1e-6),
        corners_per_km=n_corners / max(length_km, 1e-6),
        braking_zones_per_km=n_braking_zones / max(length_km, 1e-6),
        elevation_events_per_km=elevation_events / max(length_km, 1e-6),
        complexity_index=round(complexity, 2),
    )
