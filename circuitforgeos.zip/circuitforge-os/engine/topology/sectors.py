"""
engine.topology.sectors
=========================
Arbitrary sector splitting + per-sector statistics (Section 11).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Sequence

import numpy as np

from engine.common import TrackArrays


@dataclass
class Sector:
    index: int
    name: str
    start_s: float
    end_s: float
    length_m: float
    sector_time_s: float = 0.0
    average_speed_kmh: float = 0.0
    maximum_speed_kmh: float = 0.0


def make_sectors(arrays: TrackArrays, boundaries_s: Optional[Sequence[float]] = None,
                  n_sectors: int = 3) -> List[Sector]:
    total = arrays.length
    if boundaries_s is None:
        boundaries_s = [total * i / n_sectors for i in range(n_sectors + 1)]
    sectors = []
    for i in range(len(boundaries_s) - 1):
        sectors.append(Sector(
            index=i, name=f"Sector {i + 1}",
            start_s=boundaries_s[i], end_s=boundaries_s[i + 1],
            length_m=boundaries_s[i + 1] - boundaries_s[i],
        ))
    return sectors


def compute_sector_stats(sectors: List[Sector], arrays: TrackArrays,
                          speed_ms: np.ndarray) -> List[Sector]:
    ds = arrays.ds
    for sec in sectors:
        mask = (arrays.s >= sec.start_s) & (arrays.s < sec.end_s)
        if not np.any(mask):
            continue
        v = speed_ms[mask]
        v_safe = np.maximum(v, 0.1)
        sec.sector_time_s = float(np.sum(ds / v_safe))
        sec.average_speed_kmh = float(np.mean(v) * 3.6)
        sec.maximum_speed_kmh = float(np.max(v) * 3.6)
    return sectors
