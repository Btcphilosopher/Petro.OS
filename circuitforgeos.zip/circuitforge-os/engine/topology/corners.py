"""
engine.topology.corners
=========================
Automatic corner detection & classification from the curvature signal
(Section 9), plus geometric/dynamic apex detection (Section 31).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional

import numpy as np

from engine.common import TrackArrays

CURVATURE_THRESHOLD = 1.0 / 250.0  # radius < 250 m counts as "in a corner"


class CornerClass(str, Enum):
    HAIRPIN = "HAIRPIN"
    SLOW = "SLOW"
    MEDIUM = "MEDIUM"
    FAST = "FAST"
    SWEEPER = "SWEEPER"
    DOUBLE_APEX = "DOUBLE_APEX"
    ESS = "ESS"
    CHICANE = "CHICANE"


@dataclass
class Corner:
    index: int
    start_idx: int
    apex_idx: int
    end_idx: int
    start_s: float
    apex_s: float
    end_s: float
    direction: int              # +1 left, -1 right
    min_radius_m: float
    turn_angle_deg: float
    corner_class: CornerClass
    geometric_apex_s: float = 0.0
    dynamic_apex_s: Optional[float] = None
    apex_type: str = "GEOMETRIC"   # EARLY | GEOMETRIC | LATE
    entry_speed_kmh: Optional[float] = None
    apex_speed_kmh: Optional[float] = None
    exit_speed_kmh: Optional[float] = None


def _classify(min_radius: float, turn_angle: float) -> CornerClass:
    if min_radius < 15:
        return CornerClass.HAIRPIN
    if turn_angle < 45 and min_radius > 120:
        return CornerClass.SWEEPER
    if min_radius < 35:
        return CornerClass.SLOW
    if min_radius < 80:
        return CornerClass.MEDIUM
    return CornerClass.FAST


def detect_corners(arrays: TrackArrays,
                    curvature_threshold: float = CURVATURE_THRESHOLD,
                    min_length_m: float = 5.0) -> List[Corner]:
    kappa = arrays.curvature
    in_corner = np.abs(kappa) > curvature_threshold
    corners: List[Corner] = []

    n = len(kappa)
    idx = 0
    cid = 0
    while idx < n:
        if in_corner[idx]:
            start = idx
            while idx < n and in_corner[idx]:
                idx += 1
            end = idx - 1
            if (arrays.s[end] - arrays.s[start]) < min_length_m:
                continue
            seg = kappa[start:end + 1]
            apex_local = int(np.argmax(np.abs(seg)))
            apex = start + apex_local
            direction = int(np.sign(seg[apex_local])) or 1
            min_radius = float(1.0 / max(np.abs(seg[apex_local]), 1e-6))
            heading_change = float(np.degrees(arrays.heading[end] - arrays.heading[start]))
            turn_angle = abs(heading_change)

            sign_changes = np.sum(np.diff(np.sign(seg[np.abs(seg) > 1e-6])) != 0)
            if sign_changes >= 2:
                cclass = CornerClass.CHICANE if turn_angle < 90 else CornerClass.ESS
            elif sign_changes == 1:
                cclass = CornerClass.ESS
            else:
                # multiple local maxima of |curvature| -> double apex
                peaks = 0
                for i in range(1, len(seg) - 1):
                    if abs(seg[i]) > abs(seg[i - 1]) and abs(seg[i]) >= abs(seg[i + 1]):
                        peaks += 1
                cclass = CornerClass.DOUBLE_APEX if peaks >= 2 else _classify(min_radius, turn_angle)

            corners.append(Corner(
                index=cid, start_idx=start, apex_idx=apex, end_idx=end,
                start_s=float(arrays.s[start]), apex_s=float(arrays.s[apex]),
                end_s=float(arrays.s[end]), direction=direction,
                min_radius_m=min_radius, turn_angle_deg=turn_angle,
                corner_class=cclass, geometric_apex_s=float(arrays.s[apex]),
            ))
            cid += 1
        else:
            idx += 1
    return corners


def detect_apex_types(corner: Corner, arrays: TrackArrays,
                       racing_line_offset: Optional[np.ndarray] = None) -> Corner:
    """
    Determine early/geometric/late apex by comparing the dynamic (racing
    line) apex location against the geometric apex, using the lateral
    offset profile if a racing line has been computed.
    """
    if racing_line_offset is None:
        corner.apex_type = "GEOMETRIC"
        corner.dynamic_apex_s = corner.geometric_apex_s
        return corner

    seg = racing_line_offset[corner.start_idx:corner.end_idx + 1]
    dyn_local = int(np.argmax(np.abs(seg))) if len(seg) else 0
    dyn_idx = corner.start_idx + dyn_local
    dyn_s = float(arrays.s[dyn_idx])
    corner.dynamic_apex_s = dyn_s
    mid_s = (corner.start_s + corner.end_s) / 2.0
    if dyn_s < mid_s - (corner.end_s - corner.start_s) * 0.1:
        corner.apex_type = "EARLY"
    elif dyn_s > mid_s + (corner.end_s - corner.start_s) * 0.1:
        corner.apex_type = "LATE"
    else:
        corner.apex_type = "GEOMETRIC"
    return corner
