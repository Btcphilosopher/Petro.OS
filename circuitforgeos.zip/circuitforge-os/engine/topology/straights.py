"""
engine.topology.straights
===========================
Automatic straight-line detection (Section 10) — the complement of the
corner mask, filtered by minimum length.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List

import numpy as np

from engine.common import TrackArrays
from engine.topology.corners import CURVATURE_THRESHOLD


@dataclass
class Straight:
    index: int
    start_idx: int
    end_idx: int
    start_s: float
    end_s: float
    length_m: float
    gradient_pct: float
    max_simulated_speed_kmh: float = 0.0
    drs_zone: bool = False
    braking_point_s: float = None


def detect_straights(arrays: TrackArrays,
                      curvature_threshold: float = CURVATURE_THRESHOLD,
                      min_length_m: float = 40.0) -> List[Straight]:
    kappa = arrays.curvature
    is_straight = np.abs(kappa) <= curvature_threshold
    n = len(kappa)
    straights: List[Straight] = []
    idx = 0
    sid = 0
    while idx < n:
        if is_straight[idx]:
            start = idx
            while idx < n and is_straight[idx]:
                idx += 1
            end = idx - 1
            length = float(arrays.s[end] - arrays.s[start])
            if length >= min_length_m:
                grad_pct = float(np.mean(arrays.gradient[start:end + 1]) * 100.0)
                straights.append(Straight(
                    index=sid, start_idx=start, end_idx=end,
                    start_s=float(arrays.s[start]), end_s=float(arrays.s[end]),
                    length_m=length, gradient_pct=grad_pct,
                    drs_zone=length > 400.0,
                ))
                sid += 1
        else:
            idx += 1
    return straights
