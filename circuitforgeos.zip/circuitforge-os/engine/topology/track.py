"""
engine.topology.track
=======================
RaceTrack — the fundamental circuit object (Section 4), aggregating
geometry, elevation/banking/camber profiles and derived topology
(corners/straights/sectors/runoff zones/terrain link).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

import numpy as np

from engine.common import TrackArrays
from engine.geometry.boundaries import TrackBoundaries, compute_boundaries
from engine.topology.corners import Corner, detect_corners
from engine.topology.straights import Straight, detect_straights
from engine.topology.sectors import Sector, make_sectors


@dataclass
class RaceTrack:
    track_id: str
    name: str
    arrays: TrackArrays
    boundaries: TrackBoundaries = None
    corners: List[Corner] = field(default_factory=list)
    straights: List[Straight] = field(default_factory=list)
    sectors: List[Sector] = field(default_factory=list)
    runoff_zones: list = field(default_factory=list)
    terrain: object = None

    @property
    def total_length(self) -> float:
        return self.arrays.length

    @property
    def width(self) -> float:
        return float(np.mean(self.arrays.width))

    @property
    def centerline(self) -> TrackArrays:
        return self.arrays

    @property
    def elevation_profile(self) -> np.ndarray:
        return self.arrays.z

    @property
    def banking_profile(self) -> np.ndarray:
        return self.arrays.banking

    @property
    def camber_profile(self) -> np.ndarray:
        return self.arrays.camber

    def recompute_topology(self, curvature_threshold: Optional[float] = None,
                            n_sectors: int = 3) -> "RaceTrack":
        self.boundaries = compute_boundaries(self.arrays)
        kwargs = {} if curvature_threshold is None else {"curvature_threshold": curvature_threshold}
        self.corners = detect_corners(self.arrays, **kwargs)
        self.straights = detect_straights(self.arrays)
        self.sectors = make_sectors(self.arrays, n_sectors=n_sectors)
        return self

    def validate(self) -> dict:
        from engine.geometry.builder import GeometryBuilder
        closure = GeometryBuilder.closure_error(self.arrays)
        issues = []
        if closure > max(5.0, self.arrays.ds * 5):
            issues.append(f"Circuit is not well closed (gap={closure:.2f} m)")
        if np.any(np.abs(self.arrays.curvature) > 1.0):  # radius < 1 m
            issues.append("Curvature exceeds physically reasonable limits (radius < 1 m)")
        if np.any(self.arrays.width < 3.0):
            issues.append("Track width drops below 3 m at some point")
        grad_jump = np.max(np.abs(np.diff(self.arrays.gradient))) if len(self.arrays.gradient) > 1 else 0
        if grad_jump > 0.5:
            issues.append("Discontinuous gradient change detected")
        bank_jump = np.max(np.abs(np.diff(self.arrays.banking))) if len(self.arrays.banking) > 1 else 0
        if bank_jump > 5.0:
            issues.append("Instantaneous banking change detected (> 5 deg between samples)")
        return {
            "closed_circuit": closure <= max(5.0, self.arrays.ds * 5),
            "closure_error_m": closure,
            "valid": len(issues) == 0,
            "issues": issues,
        }
