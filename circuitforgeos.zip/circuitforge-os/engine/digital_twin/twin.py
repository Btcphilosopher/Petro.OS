"""
engine.digital_twin.twin
==========================
TrackDigitalTwin (Section 74): the aggregator object that expresses
CIRCUITFORGE.OS's defining principle — parametric causality (Section 94):

    geometry -> curvature -> elevation -> banking -> vehicle physics
    -> racing line -> lap time -> safety/runoff -> terrain -> earthworks
    -> construction -> cost -> optimisation -> new design

Calling `recompute()` re-runs this entire chain from the current
geometry/terrain/vehicle configuration, so a single parametric edit
(Section 82, e.g. "Turn 7 radius 42m -> 55m") propagates automatically
through every downstream subsystem.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

import numpy as np

from engine.common import TrackArrays
from engine.geometry.builder import GeometryBuilder
from engine.geometry.primitives import TrackPrimitive
from engine.topology.track import RaceTrack
from engine.topology.character import compute_character
from engine.racing_line.optimizer import RacingLineOptimizer, RacingLineResult
from engine.lap_time.simulator import simulate_lap, LapTimeResult
from engine.lap_time.traffic import detect_overtaking_zones
from engine.vehicle.model import Vehicle
from engine.vehicle.driver import DriverModel
from engine.safety.engine import SafetyZoneEngine, SafetyReport
from engine.drainage.engine import analyse_drainage, DrainageReport
from engine.pavement.engine import compute_pavement, PavementResult
from engine.terrain.dem import DigitalElevationModel
from engine.earthworks.engine import compute_earthworks, estimate_haul, EarthworksResult, HaulEstimate
from engine.construction.phases import build_phases
from engine.construction.schedule import build_schedule
from engine.construction.equipment import fleet_for_earthworks, fleet_for_pavement, estimate_daily_cost
from engine.construction.pit import PitLane, PitComplex
from engine.costing.engine import compute_cost, CostBreakdown
from engine.costing.land import compute_land_requirement, LandRequirement


@dataclass
class DesignSnapshot:
    version: str
    summary: Dict[str, float]


@dataclass
class TrackDigitalTwin:
    name: str
    cfg: dict
    vehicle: Vehicle
    driver: DriverModel
    resolution_m: float = 1.0

    track: Optional[RaceTrack] = None
    terrain: Optional[DigitalElevationModel] = None
    racing_line: Optional[RacingLineResult] = None
    lap: Optional[LapTimeResult] = None
    safety: Optional[SafetyReport] = None
    drainage: Optional[DrainageReport] = None
    pavement: Optional[PavementResult] = None
    earthworks: Optional[EarthworksResult] = None
    haul: Optional[HaulEstimate] = None
    cost: Optional[CostBreakdown] = None
    land: Optional[LandRequirement] = None
    pit_complex: Optional[PitComplex] = None
    character: Optional[object] = None

    history: List[DesignSnapshot] = field(default_factory=list)
    _primitives: List[TrackPrimitive] = field(default_factory=list)

    # ---------------------------------------------------------------- build
    def set_geometry(self, primitives: Sequence[TrackPrimitive], width_m: float = 12.0) -> "TrackDigitalTwin":
        self._primitives = list(primitives)
        builder = GeometryBuilder(resolution_m=self.resolution_m)
        arrays = builder.build(self._primitives, start_width=width_m)
        self.track = RaceTrack(track_id="T-001", name=self.name, arrays=arrays).recompute_topology()
        return self

    def set_terrain(self, dem: DigitalElevationModel) -> "TrackDigitalTwin":
        self.terrain = dem
        if self.track is not None:
            self.track.terrain = dem
        return self

    # ------------------------------------------------------------ pipeline
    def recompute(self, air_density: float = 1.225) -> "TrackDigitalTwin":
        """Runs the full parametric-causality chain end to end."""
        if self.track is None:
            raise RuntimeError("Geometry must be set (set_geometry) before recompute()")
        arrays = self.track.arrays

        # RACING LINE
        self.racing_line = RacingLineOptimizer(arrays, car_width_m=1.9).solve()

        # LAP TIME (uses racing-line curvature for a sharper corner-speed estimate)
        line_arrays = TrackArrays(
            s=arrays.s, x=self.racing_line.x, y=self.racing_line.y, z=arrays.z,
            heading=arrays.heading, curvature=self.racing_line.curvature,
            gradient=arrays.gradient, banking=arrays.banking, camber=arrays.camber,
            width=arrays.width,
        )
        self.lap = simulate_lap(line_arrays, self.vehicle, air_density,
                                 driver_skill=self.driver.combined_skill)

        # re-detect corner speeds/entry/apex/exit from the lap trace
        for c in self.track.corners:
            seg = self.lap.speed_kmh[c.start_idx:c.end_idx + 1]
            if len(seg):
                c.entry_speed_kmh = float(seg[0])
                c.apex_speed_kmh = float(np.min(seg))
                c.exit_speed_kmh = float(seg[-1])

        self.character = compute_character(arrays, self.track.corners, self.track.straights,
                                            self.lap.speed_kmh, len(self.lap.braking_zones))

        # SAFETY / RUNOFF
        self.safety = SafetyZoneEngine(self.cfg["safety"]).analyse(arrays, self.lap.speed_kmh)

        # DRAINAGE
        self.drainage = analyse_drainage(arrays)

        # PAVEMENT
        self.pavement = compute_pavement(self.track.boundaries.pavement_area_m2, self.cfg["pavement"])

        # TERRAIN -> EARTHWORKS
        if self.terrain is not None:
            self.earthworks = compute_earthworks(
                arrays, self.terrain,
                corridor_width_m=self.cfg["earthworks"]["corridor_width_m"],
                side_slope_ratio=self.cfg["earthworks"]["side_slope_ratio"],
            )
            self.haul = estimate_haul(self.earthworks, arrays)
        else:
            self.earthworks = EarthworksResult(0, 0, 0, "CUT", np.zeros_like(arrays.s), 0)
            self.haul = HaulEstimate(0, 0, 0, 0)

        # PIT COMPLEX
        pit_lane = PitLane(length_m=max(arrays.length * 0.07, 250))
        self.pit_complex = PitComplex(pit_lane=pit_lane)

        # LAND REQUIREMENT
        self.land = compute_land_requirement(
            track_footprint_m2=self.track.boundaries.pavement_area_m2,
            runoff_m2=self.safety.total_runoff_area_m2,
            service_road_length_m=self.safety.service_road_length_m,
            pit_complex_m2=self.pit_complex.total_complex_area_m2,
            cfg=self.cfg, track_perimeter_m=arrays.length * 2,
        )

        # CONSTRUCTION -> COST
        self.cost = compute_cost(
            earthworks_m3=self.earthworks.net_volume_m3,
            pavement_m2=self.pavement.surface_area_m2,
            drainage_m=self.drainage.corridor_length_m,
            runoff_m2=self.safety.total_runoff_area_m2,
            barrier_m=self.safety.total_barrier_length_m,
            service_road_m2=self.land.service_roads_m2,
            pit_area_m2=self.pit_complex.total_pit_building_area_m2,
            land_area_m2=self.land.total_site_area_m2,
            cfg=self.cfg["costing"],
        )

        self._record_history()
        return self

    def _record_history(self):
        version = f"DESIGN-{len(self.history) + 1:03d}"
        summary = {
            "length_m": self.track.total_length,
            "corners": len(self.track.corners),
            "lap_time_s": self.lap.total_time_s,
            "avg_speed_kmh": self.lap.average_speed_kmh,
            "earthworks_m3": self.earthworks.cut_volume_m3 + self.earthworks.fill_volume_m3,
            "construction_cost": self.cost.total,
            "pavement_area_m2": self.track.boundaries.pavement_area_m2,
        }
        self.history.append(DesignSnapshot(version=version, summary=summary))

    def compare_versions(self, i: int, j: int) -> Dict[str, tuple]:
        a, b = self.history[i].summary, self.history[j].summary
        return {k: (a[k], b[k], b[k] - a[k]) for k in a}

    # ------------------------------------------------------------- editing
    def edit_corner_radius(self, corner_index: int, new_radius_m: float) -> "TrackDigitalTwin":
        """
        Parametric editing (Section 82): locate the ARC primitive(s)
        belonging to `corner_index`, rebuild geometry with the new radius,
        and recompute() the entire downstream chain.
        """
        from engine.geometry.primitives import PrimitiveKind
        arc_positions = [i for i, p in enumerate(self._primitives)
                          if p.kind in (PrimitiveKind.ARC, PrimitiveKind.HAIRPIN, PrimitiveKind.SWEEPER)]
        if corner_index >= len(arc_positions):
            raise IndexError(f"No corner at index {corner_index}")
        pos = arc_positions[corner_index]
        old = self._primitives[pos]
        from engine.geometry.primitives import circular_arc
        angle_deg = float(np.degrees(old.length * abs(old.kappa_fn(np.array([0.0]))[0])))
        direction = int(np.sign(old.kappa_fn(np.array([0.0]))[0])) or 1
        new_prim = circular_arc(new_radius_m, angle_deg, direction=direction,
                                 banking=old.banking, camber=old.camber, label=old.label)
        self._primitives[pos] = new_prim
        self.set_geometry(self._primitives, width_m=float(np.mean(self.track.arrays.width)))
        return self.recompute()

    # --------------------------------------------------------------- report
    def report(self) -> dict:
        t = self.track
        return {
            "track_length_km": round(t.total_length / 1000, 3),
            "average_width_m": round(t.width, 2),
            "corners": len(t.corners),
            "straights": len(t.straights),
            "elevation_change_m": round(float(np.max(t.arrays.z) - np.min(t.arrays.z)), 1),
            "max_gradient_pct": round(float(np.max(np.abs(t.arrays.gradient)) * 100), 2),
            "max_banking_deg": round(float(np.max(t.arrays.banking)), 1),
            "simulated_lap_time": self.lap.lap_time_str,
            "average_speed_kmh": round(self.lap.average_speed_kmh, 1),
            "maximum_speed_kmh": round(self.lap.max_speed_kmh, 1),
            "pavement_area_m2": round(t.boundaries.pavement_area_m2, 0),
            "cut_volume_m3": round(self.earthworks.cut_volume_m3, 0),
            "fill_volume_m3": round(self.earthworks.fill_volume_m3, 0),
            "runoff_area_m2": round(self.safety.total_runoff_area_m2, 0),
            "drainage_corridor_m": round(self.drainage.corridor_length_m, 0),
            "service_road_length_m": round(self.safety.service_road_length_m, 0),
            "land_area_km2": round(self.land.total_site_area_km2, 3),
            "conceptual_construction_cost": round(self.cost.total, 0),
        }
