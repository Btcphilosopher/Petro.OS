"""
engine.digital_twin.export
=============================
Export utilities (Sections 79-80): JSON, CSV, GeoJSON, and the
proprietary `.circuitforge` project format.
"""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from engine.digital_twin.twin import TrackDigitalTwin


def to_dataframe(twin: TrackDigitalTwin) -> pd.DataFrame:
    a = twin.track.arrays
    return pd.DataFrame({
        "s": a.s, "x": a.x, "y": a.y, "z": a.z, "heading": a.heading,
        "curvature": a.curvature, "gradient": a.gradient, "banking": a.banking,
        "camber": a.camber, "width": a.width,
        "speed_kmh": twin.lap.speed_kmh if twin.lap is not None else None,
        "lat_accel_g": (twin.lap.lateral_accel / 9.81) if twin.lap is not None else None,
        "long_accel_g": (twin.lap.longitudinal_accel / 9.81) if twin.lap is not None else None,
    })


def export_csv(twin: TrackDigitalTwin, path: str) -> str:
    to_dataframe(twin).to_csv(path, index=False)
    return path


def export_json(twin: TrackDigitalTwin, path: str) -> str:
    payload = {
        "track": {"name": twin.track.name, **twin.report()},
        "corners": [c.__dict__ | {"corner_class": c.corner_class.value} for c in twin.track.corners],
        "straights": [s.__dict__ for s in twin.track.straights],
        "design_history": [{"version": h.version, "summary": h.summary} for h in twin.history],
    }
    Path(path).write_text(json.dumps(payload, indent=2, default=str))
    return path


def export_geojson(twin: TrackDigitalTwin, path: str) -> str:
    a = twin.track.arrays
    coords = list(zip(a.x.tolist(), a.y.tolist(), a.z.tolist()))
    feature = {
        "type": "Feature",
        "properties": {"name": twin.track.name, "length_m": twin.track.total_length},
        "geometry": {"type": "LineString", "coordinates": coords},
    }
    fc = {"type": "FeatureCollection", "features": [feature]}
    Path(path).write_text(json.dumps(fc))
    return path


def export_circuitforge_project(twin: TrackDigitalTwin, path: str) -> str:
    """Writes the proprietary `.circuitforge` project file (Section 80)."""
    project = {
        "track": {"name": twin.track.name, **twin.report()},
        "terrain": {"kind": getattr(twin.terrain, "kind", "custom")} if twin.terrain is not None else {},
        "vehicle": twin.vehicle.model_dump(),
        "racing_line": {
            "offset_n": twin.racing_line.offset_n.tolist() if twin.racing_line else [],
            "converged": twin.racing_line.converged if twin.racing_line else None,
        },
        "construction": {
            "cut_m3": twin.earthworks.cut_volume_m3, "fill_m3": twin.earthworks.fill_volume_m3,
        },
        "costing": twin.cost.as_dict() if twin.cost else {},
        "scenarios": {},
    }
    if not path.endswith(".circuitforge"):
        path = path + ".circuitforge"
    Path(path).write_text(json.dumps(project, indent=2, default=str))
    return path
