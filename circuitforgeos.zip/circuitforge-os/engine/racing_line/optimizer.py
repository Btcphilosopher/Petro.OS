"""
engine.racing_line.optimizer
==============================
RacingLineOptimizer (Sections 29-30): computes a lateral-offset profile
n(s) (positive = toward the left edge) that approximates the minimum-
curvature racing line, subject to track-boundary constraints, using
SciPy numerical optimisation over a reduced control-point representation
(then re-interpolated to full pinpoint resolution with a cubic spline).

Method
------
For a centreline curvature kappa_c(s) and lateral offset n(s), the
curvature of the offset path is approximated (thin-track, small-angle
form used widely in minimum-curvature racing-line solvers) as:

    kappa(s) ~= (kappa_c(s) - n''(s)) / (1 - n(s) * kappa_c(s))

We minimise the integral of kappa(s)^2 ds (a standard proxy for lap-time
via "minimum curvature path" methods), subject to
    -half_width_track(s) <= n(s) <= half_width_track(s)
using a coarse control-point vector optimised with SciPy's L-BFGS-B, then
PCHIP-interpolated back onto the full pinpoint sample grid.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.interpolate import PchipInterpolator
from scipy.optimize import minimize

from engine.common import TrackArrays


@dataclass
class RacingLineResult:
    offset_n: np.ndarray          # lateral offset at each centreline sample [m]
    x: np.ndarray
    y: np.ndarray
    curvature: np.ndarray         # curvature of the racing line itself
    iterations: int
    converged: bool


class RacingLineOptimizer:
    def __init__(self, arrays: TrackArrays, car_width_m: float = 1.9,
                 n_control_points: int = 60):
        self.arrays = arrays
        self.car_width_m = car_width_m
        self.n_control_points = min(n_control_points, max(len(arrays.s) // 3, 4))

    def _half_width_available(self) -> np.ndarray:
        return np.maximum(self.arrays.width / 2.0 - self.car_width_m / 2.0, 0.1)

    def _offset_curvature(self, n: np.ndarray, ds: float) -> np.ndarray:
        kappa_c = self.arrays.curvature
        n_pp = np.gradient(np.gradient(n, ds), ds)
        denom = np.clip(1.0 - n * kappa_c, 0.2, None)
        return (kappa_c - n_pp) / denom

    def solve(self, maxiter: int = 150) -> RacingLineResult:
        s = self.arrays.s
        ds = self.arrays.ds
        half_w = self._half_width_available()

        ctrl_idx = np.linspace(0, len(s) - 1, self.n_control_points).astype(int)
        s_ctrl = s[ctrl_idx]
        bounds = [(-half_w[i], half_w[i]) for i in ctrl_idx]
        x0 = np.zeros(self.n_control_points)

        def expand(n_ctrl):
            interp = PchipInterpolator(s_ctrl, n_ctrl, extrapolate=True)
            return interp(s)

        def cost(n_ctrl):
            n_full = expand(n_ctrl)
            n_full = np.clip(n_full, -half_w, half_w)
            kappa = self._offset_curvature(n_full, ds)
            smoothness_penalty = np.sum(np.diff(n_ctrl) ** 2) * 0.01
            return float(np.sum(kappa ** 2) * ds + smoothness_penalty)

        res = minimize(cost, x0, method="L-BFGS-B", bounds=bounds,
                        options={"maxiter": maxiter})

        n_full = np.clip(expand(res.x), -half_w, half_w)
        kappa_line = self._offset_curvature(n_full, ds)

        nx = -np.sin(self.arrays.heading)
        ny = np.cos(self.arrays.heading)
        x = self.arrays.x + nx * n_full
        y = self.arrays.y + ny * n_full

        return RacingLineResult(
            offset_n=n_full, x=x, y=y, curvature=kappa_line,
            iterations=int(res.nit), converged=bool(res.success),
        )
