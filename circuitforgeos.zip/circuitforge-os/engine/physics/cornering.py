"""
engine.physics.cornering
==========================
Cornering-limit physics (Sections 24-25): available lateral force from
tyre friction + aerodynamic downforce, adjusted for banking and camber,
and the resulting maximum simulated corner speed for a given curvature.
"""
from __future__ import annotations

import numpy as np

from engine.common import G
from engine.physics.aero import downforce
from engine.vehicle.model import Vehicle


def lateral_accel_limit(vehicle: Vehicle, v_ms, banking_deg=0.0, camber_deg=0.0,
                         air_density: float = 1.225):
    """
    Simplified banked/cambered friction-circle cornering limit:
        a_lat_max = mu * g * cos(theta) + g * sin(theta) + mu * downforce / m
    where theta = banking + camber contribution (small-angle superposition).
    This is a simulation approximation, not a rigid-body vehicle-dynamics solve.
    """
    v_ms = np.asarray(v_ms, dtype=float)
    theta = np.radians(np.asarray(banking_deg, dtype=float) + 0.3 * np.asarray(camber_deg, dtype=float))
    df = downforce(vehicle, v_ms, air_density)
    mu = vehicle.tyre_mu
    a_friction = mu * G * np.cos(theta) + G * np.sin(theta)
    a_aero = mu * df / vehicle.mass_kg
    return np.maximum(a_friction + a_aero, 0.5)


def max_corner_speed(vehicle: Vehicle, curvature, banking_deg=0.0, camber_deg=0.0,
                      air_density: float = 1.225, v_top: float = 120.0):
    """
    Iteratively solve v_max such that a_lat_limit(v) == v^2 * |kappa|,
    since downforce (and hence the limit) itself depends on v.
    """
    curvature = np.asarray(curvature, dtype=float)
    banking_deg = np.broadcast_to(np.asarray(banking_deg, dtype=float), curvature.shape)
    camber_deg = np.broadcast_to(np.asarray(camber_deg, dtype=float), curvature.shape)

    kappa_safe = np.maximum(np.abs(curvature), 1e-5)
    v = np.full_like(curvature, 40.0, dtype=float)
    for _ in range(25):
        a_lim = lateral_accel_limit(vehicle, v, banking_deg, camber_deg, air_density)
        v_new = np.sqrt(a_lim / kappa_safe)
        v_new = np.minimum(v_new, v_top)
        v = 0.5 * v + 0.5 * v_new
    # straights (near-zero curvature) -> effectively unconstrained by cornering
    v = np.where(np.abs(curvature) < 1e-5, v_top, v)
    return v
