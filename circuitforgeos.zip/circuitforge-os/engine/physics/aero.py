"""engine.physics.aero — simplified aerodynamic drag & downforce (Section 23)."""
from __future__ import annotations
import numpy as np
from engine.vehicle.model import Vehicle


def drag_force(vehicle: Vehicle, v_ms, air_density: float = 1.225):
    v_ms = np.asarray(v_ms, dtype=float)
    return 0.5 * air_density * vehicle.drag_coefficient * vehicle.frontal_area_m2 * v_ms ** 2


def downforce(vehicle: Vehicle, v_ms, air_density: float = 1.225):
    v_ms = np.asarray(v_ms, dtype=float)
    return 0.5 * air_density * vehicle.downforce_coefficient * vehicle.frontal_area_m2 * v_ms ** 2
