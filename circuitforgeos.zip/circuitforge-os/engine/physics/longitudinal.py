"""
engine.physics.longitudinal
=============================
Longitudinal point-mass dynamics (Sections 22, 27): engine force, drag,
rolling resistance and grade resistance combine to a net force and
acceleration.
"""
from __future__ import annotations

import numpy as np

from engine.common import G
from engine.physics.aero import drag_force
from engine.vehicle.model import Vehicle


def engine_force(vehicle: Vehicle, v_ms):
    """Power-limited traction force, F = P*eta / v (capped at a low-speed traction limit)."""
    v_ms = np.asarray(v_ms, dtype=float)
    v_safe = np.maximum(v_ms, 3.0)
    f = (vehicle.engine_power_w * vehicle.drivetrain_efficiency) / v_safe
    traction_limit = vehicle.tyre_mu * vehicle.mass_kg * G
    return np.minimum(f, traction_limit)


def rolling_resistance(vehicle: Vehicle, gradient=None):
    return vehicle.rolling_resistance_coeff * vehicle.mass_kg * G


def grade_resistance(vehicle: Vehicle, gradient):
    gradient = np.asarray(gradient, dtype=float)
    theta = np.arctan(gradient)
    return vehicle.mass_kg * G * np.sin(theta)


def net_acceleration(vehicle: Vehicle, v_ms, gradient=0.0, air_density: float = 1.225,
                      braking: bool = False):
    v_ms = np.asarray(v_ms, dtype=float)
    if braking:
        f_net = -vehicle.brake_decel_max_ms2 * vehicle.mass_kg
    else:
        f_net = engine_force(vehicle, v_ms)
    f_drag = drag_force(vehicle, v_ms, air_density)
    f_roll = rolling_resistance(vehicle)
    f_grade = grade_resistance(vehicle, gradient)
    f_total = f_net - f_drag - f_roll - f_grade
    return f_total / vehicle.mass_kg
