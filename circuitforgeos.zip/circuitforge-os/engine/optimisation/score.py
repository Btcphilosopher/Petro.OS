"""engine.optimisation.score — Circuit Design Score (Section 91)."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict


@dataclass
class DesignScoreWeights:
    lap_quality: float = 1.0
    corner_variety: float = 1.0
    speed_variation: float = 1.0
    overtaking_potential: float = 1.0
    elevation_character: float = 1.0
    construction_efficiency: float = 1.0
    earthworks_efficiency: float = 1.0


@dataclass
class DesignScore:
    components: Dict[str, float]
    total: float


def score_design(lap_time_s: float, target_lap_time_s: float, corner_classes: list,
                  speed_std_kmh: float, overtaking_score_sum: float,
                  elevation_change_m: float, construction_cost: float,
                  earthworks_m3: float, weights: DesignScoreWeights = DesignScoreWeights()) -> DesignScore:
    lap_quality = max(0.0, 100 - abs(lap_time_s - target_lap_time_s) * 2)
    variety = len(set(corner_classes)) / 8.0 * 100
    speed_variation = min(speed_std_kmh / 1.2, 100)
    overtaking = min(overtaking_score_sum / 5.0, 100)
    elevation = min(elevation_change_m / 1.5, 100)
    construction_eff = max(0.0, 100 - construction_cost / 1_000_000)
    earthworks_eff = max(0.0, 100 - earthworks_m3 / 50_000)

    components = {
        "lap_quality": lap_quality * weights.lap_quality,
        "corner_variety": variety * weights.corner_variety,
        "speed_variation": speed_variation * weights.speed_variation,
        "overtaking_potential": overtaking * weights.overtaking_potential,
        "elevation_character": elevation * weights.elevation_character,
        "construction_efficiency": construction_eff * weights.construction_efficiency,
        "earthworks_efficiency": earthworks_eff * weights.earthworks_efficiency,
    }
    total_weight = sum(vars(weights).values())
    total = sum(components.values()) / max(total_weight, 1e-6)
    return DesignScore(components=components, total=round(total, 2))
