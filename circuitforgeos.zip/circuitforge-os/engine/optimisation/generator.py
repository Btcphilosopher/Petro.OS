"""
engine.optimisation.generator
================================
TrackGenerator (Section 65): builds a candidate circuit's primitive
sequence from high-level parameters. Section 90's "Ultimate Design Mode"
and the CircuitOptimizer (engine.optimisation.optimizer) both drive this.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

import numpy as np

from engine.geometry.primitives import TrackPrimitive, straight, eased_arc, chicane


@dataclass
class GeneratorParams:
    target_length_m: float = 5000.0
    corner_count: int = 15
    straight_ratio: float = 0.45          # fraction of length that is straight
    elevation_change_m: float = 60.0
    technicality: float = 0.5             # 0 (flowing) .. 1 (tight/technical)
    speed_character: float = 0.5          # 0 (slow) .. 1 (high-speed)
    direction_changes: Optional[int] = None
    seed: int = 0


class TrackGenerator:
    def __init__(self, params: GeneratorParams):
        self.p = params
        self.rng = np.random.default_rng(params.seed)

    def generate(self) -> List[TrackPrimitive]:
        p = self.p
        straight_len_total = p.target_length_m * p.straight_ratio
        corner_len_total = p.target_length_m - straight_len_total
        n_corners = max(p.corner_count, 3)

        # radius range narrows as technicality increases, widens with speed_character
        r_min = 15 + (1 - p.technicality) * 20
        r_max = 60 + p.speed_character * 140

        primitives: List[TrackPrimitive] = []
        cumulative_heading = 0.0
        elevation_remaining = p.elevation_change_m
        n_elevation_events = max(int(n_corners * 0.4), 2)

        # A predominantly one-way sequence of turns closes into a simple
        # loop (like most real circuits); a handful of counter-direction
        # corners add character without risking a self-intersecting layout.
        main_direction = 1 if self.rng.random() < 0.5 else -1
        n_counter = max(int(round(n_corners * 0.15)), 0) if n_corners >= 6 else 0
        directions = [main_direction] * n_corners
        counter_positions = self.rng.choice(n_corners, size=n_counter, replace=False) if n_counter else []
        for pos in counter_positions:
            directions[int(pos)] = -main_direction

        straight_lengths = self.rng.dirichlet(np.ones(n_corners)) * straight_len_total
        corner_share = self.rng.dirichlet(np.ones(n_corners)) * corner_len_total

        angles_deg = []
        radii = []
        for i in range(n_corners):
            radius = float(self.rng.uniform(r_min, r_max))
            length_budget = max(corner_share[i], radius * 0.3)
            angle_deg = float(np.degrees(length_budget / radius))
            angle_deg = float(np.clip(angle_deg, 20, 150))
            radii.append(radius)
            angles_deg.append(angle_deg)

        # Normalise the net signed turning to exactly +/-360 degrees so the
        # generated primitive sequence forms a closed, non-self-intersecting
        # loop once integrated by the GeometryBuilder.
        net_turn = sum(d * a for d, a in zip(directions, angles_deg))
        target = 360.0 if net_turn >= 0 else -360.0
        if abs(net_turn) > 1e-6:
            scale = target / net_turn
            angles_deg = [float(np.clip(a * scale, 15, 170)) for a in angles_deg]

        # Re-balance straight length so the *overall* circuit still lands
        # near target_length_m after the angle normalisation above changed
        # each corner's arc length (length = radius * angle_rad).
        corner_length_total = sum(r * np.radians(a) for r, a in zip(radii, angles_deg))
        straight_len_total = max(p.target_length_m - corner_length_total, corner_length_total * 0.15)
        straight_lengths = straight_lengths / max(np.sum(straight_lengths), 1e-6) * straight_len_total

        max_grade = 0.12  # 12% cap keeps gradients within a plausible racetrack range

        for i in range(n_corners):
            radius = radii[i]
            angle_deg = angles_deg[i]
            direction = directions[i]

            banking = float(np.clip(p.speed_character * 8.0 * self.rng.uniform(0.5, 1.0), 0, 12))

            transition_len = 15 + p.technicality * 10
            primitives.extend(eased_arc(radius, angle_deg, direction=direction,
                                         transition_length=transition_len,
                                         elevation_change=0.0, banking=banking,
                                         label=f"T{i + 1}"))
            straight_len = float(straight_lengths[i])
            if straight_len > 5:
                # Elevation change is applied along the following straight
                # (a much longer run than the corner arc), so the implied
                # gradient dz/ds stays within max_grade.
                elev = 0.0
                if i < n_elevation_events and elevation_remaining != 0:
                    step = elevation_remaining / max(n_elevation_events - i, 1)
                    step = float(np.clip(step, -max_grade * straight_len, max_grade * straight_len))
                    elev = step
                    elevation_remaining -= step
                primitives.append(straight(straight_len, elevation_change=elev, label=f"Straight {i + 1}"))

        return primitives
