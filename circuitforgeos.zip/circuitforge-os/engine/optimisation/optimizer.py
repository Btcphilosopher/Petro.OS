"""
engine.optimisation.optimizer
================================
CircuitOptimizer (Section 67) and multi-objective / Pareto-style search
(Section 68). Deliberately decoupled from the digital twin: callers pass
an `evaluate_fn(GeneratorParams) -> dict[str, float]` callback (typically
built from `TrackDigitalTwin.build_and_recompute`), keeping GEOMETRY /
PHYSICS / CONSTRUCTION / ECONOMICS / OPTIMISATION separated (Section 92).

Search method: randomised parameter search (a light-weight, dependency-
free stand-in for a full evolutionary/Bayesian optimiser) — for each
trial a GeneratorParams vector is perturbed, evaluated, and scored
against the requested objective(s). This is documented as a heuristic
search, not a claimed global optimum.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Dict, List, Optional

import numpy as np

from engine.optimisation.generator import GeneratorParams


class Objective(str, Enum):
    MIN_LAP_TIME = "MINIMUM LAP TIME"
    MAX_OVERTAKING = "MAXIMUM OVERTAKING POTENTIAL"
    MAX_CORNER_VARIETY = "MAXIMUM CORNER VARIETY"
    MIN_EARTHWORKS = "MINIMUM EARTHWORKS"
    MIN_CONSTRUCTION_COST = "MINIMUM CONSTRUCTION COST"
    BALANCED = "BALANCED CIRCUIT"


DIRECTION = {
    Objective.MIN_LAP_TIME: -1, Objective.MAX_OVERTAKING: +1,
    Objective.MAX_CORNER_VARIETY: +1, Objective.MIN_EARTHWORKS: -1,
    Objective.MIN_CONSTRUCTION_COST: -1, Objective.BALANCED: +1,
}

METRIC_FOR_OBJECTIVE = {
    Objective.MIN_LAP_TIME: "lap_time_s", Objective.MAX_OVERTAKING: "overtaking_score",
    Objective.MAX_CORNER_VARIETY: "corner_variety", Objective.MIN_EARTHWORKS: "earthworks_m3",
    Objective.MIN_CONSTRUCTION_COST: "construction_cost", Objective.BALANCED: "design_score",
}


@dataclass
class CandidateResult:
    params: GeneratorParams
    metrics: Dict[str, float]
    objective_value: float


@dataclass
class MultiObjectiveWeights:
    lap_time_weight: float = 1.0
    construction_cost_weight: float = 1.0
    earthworks_weight: float = 1.0
    safety_weight: float = 1.0
    overtaking_weight: float = 1.0
    spectator_weight: float = 1.0


class CircuitOptimizer:
    def __init__(self, base_params: GeneratorParams, evaluate_fn: Callable[[GeneratorParams], Dict[str, float]]):
        self.base_params = base_params
        self.evaluate_fn = evaluate_fn

    def _perturb(self, rng: np.random.Generator, trial: int) -> GeneratorParams:
        p = self.base_params
        return GeneratorParams(
            target_length_m=p.target_length_m * float(rng.uniform(0.95, 1.05)),
            corner_count=max(int(p.corner_count + rng.integers(-3, 4)), 4),
            straight_ratio=float(np.clip(p.straight_ratio + rng.uniform(-0.1, 0.1), 0.15, 0.75)),
            elevation_change_m=max(p.elevation_change_m + float(rng.uniform(-15, 15)), 0),
            technicality=float(np.clip(p.technicality + rng.uniform(-0.2, 0.2), 0, 1)),
            speed_character=float(np.clip(p.speed_character + rng.uniform(-0.2, 0.2), 0, 1)),
            seed=p.seed + trial,
        )

    def search(self, objective: Objective, n_trials: int = 12, seed: int = 1) -> List[CandidateResult]:
        rng = np.random.default_rng(seed)
        metric_key = METRIC_FOR_OBJECTIVE[objective]
        direction = DIRECTION[objective]
        results = []
        for t in range(n_trials):
            params = self._perturb(rng, t) if t > 0 else self.base_params
            metrics = self.evaluate_fn(params)
            value = metrics.get(metric_key, 0.0) * direction
            results.append(CandidateResult(params=params, metrics=metrics, objective_value=value))
        results.sort(key=lambda r: -r.objective_value)
        return results

    def pareto_front(self, objectives: List[Objective], n_trials: int = 20, seed: int = 1) -> List[CandidateResult]:
        """Return the non-dominated subset of randomly sampled candidates across multiple objectives."""
        rng = np.random.default_rng(seed)
        candidates = []
        for t in range(n_trials):
            params = self._perturb(rng, t) if t > 0 else self.base_params
            metrics = self.evaluate_fn(params)
            candidates.append(CandidateResult(params=params, metrics=metrics, objective_value=0.0))

        def dominates(a: CandidateResult, b: CandidateResult) -> bool:
            better_or_equal, strictly_better = True, False
            for obj in objectives:
                key = METRIC_FOR_OBJECTIVE[obj]
                d = DIRECTION[obj]
                av, bv = a.metrics.get(key, 0.0) * d, b.metrics.get(key, 0.0) * d
                if av < bv:
                    better_or_equal = False
                if av > bv:
                    strictly_better = True
            return better_or_equal and strictly_better

        front = [c for c in candidates if not any(dominates(o, c) for o in candidates if o is not c)]
        return front

    def multi_objective_search(self, weights: MultiObjectiveWeights, n_trials: int = 15,
                                seed: int = 1) -> List[CandidateResult]:
        rng = np.random.default_rng(seed)
        results = []
        for t in range(n_trials):
            params = self._perturb(rng, t) if t > 0 else self.base_params
            metrics = self.evaluate_fn(params)
            value = (
                -metrics.get("lap_time_s", 0) * weights.lap_time_weight
                - metrics.get("construction_cost", 0) / 1e6 * weights.construction_cost_weight
                - metrics.get("earthworks_m3", 0) / 1e5 * weights.earthworks_weight
                + metrics.get("overtaking_score", 0) * weights.overtaking_weight
                + metrics.get("corner_variety", 0) * weights.spectator_weight
                + metrics.get("design_score", 0) * 0.01 * weights.safety_weight
            )
            results.append(CandidateResult(params=params, metrics=metrics, objective_value=value))
        results.sort(key=lambda r: -r.objective_value)
        return results
