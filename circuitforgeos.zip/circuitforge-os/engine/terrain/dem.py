"""
engine.terrain.dem
====================
DigitalElevationModel (Section 50) — a synthetic terrain grid (x, y, z)
with generator archetypes (Section 51), plus track/terrain interaction
sampling (Section 52).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np
from scipy.interpolate import RegularGridInterpolator
from scipy.ndimage import gaussian_filter


@dataclass
class DigitalElevationModel:
    x: np.ndarray          # 1D grid coords
    y: np.ndarray
    z: np.ndarray          # 2D grid [len(y), len(x)]

    def interpolator(self) -> RegularGridInterpolator:
        return RegularGridInterpolator((self.y, self.x), self.z, bounds_error=False, fill_value=None)

    def sample(self, xs: np.ndarray, ys: np.ndarray) -> np.ndarray:
        interp = self.interpolator()
        pts = np.stack([ys, xs], axis=-1)
        return interp(pts)


def _grid(extent_m: float, resolution_m: float, seed: int = 42):
    n = max(int(extent_m / resolution_m), 8)
    coords = np.linspace(-extent_m / 2, extent_m / 2, n)
    xx, yy = np.meshgrid(coords, coords)
    rng = np.random.default_rng(seed)
    return coords, xx, yy, rng


def flat(extent_m: float = 4000, resolution_m: float = 25.0) -> DigitalElevationModel:
    coords, xx, _, _ = _grid(extent_m, resolution_m)
    return DigitalElevationModel(coords, coords, np.zeros_like(xx))


def rolling(extent_m: float = 4000, resolution_m: float = 25.0, amplitude: float = 8.0,
            seed: int = 42) -> DigitalElevationModel:
    coords, xx, yy, rng = _grid(extent_m, resolution_m, seed)
    noise = rng.normal(size=xx.shape)
    z = gaussian_filter(noise, sigma=xx.shape[0] / 12.0)
    z = (z - z.min()) / (z.max() - z.min() + 1e-9) * amplitude * 2 - amplitude
    return DigitalElevationModel(coords, coords, z)


def mountain(extent_m: float = 4000, resolution_m: float = 25.0, peak_height: float = 250.0,
             seed: int = 42) -> DigitalElevationModel:
    coords, xx, yy, rng = _grid(extent_m, resolution_m, seed)
    r = np.hypot(xx, yy)
    base = peak_height * np.exp(-(r / (extent_m * 0.35)) ** 2)
    noise = gaussian_filter(rng.normal(size=xx.shape), sigma=xx.shape[0] / 20.0) * peak_height * 0.05
    return DigitalElevationModel(coords, coords, base + noise)


def valley(extent_m: float = 4000, resolution_m: float = 25.0, depth: float = 120.0,
           seed: int = 42) -> DigitalElevationModel:
    coords, xx, yy, rng = _grid(extent_m, resolution_m, seed)
    r = np.hypot(xx, yy)
    base = -depth * np.exp(-(r / (extent_m * 0.4)) ** 2) + depth
    noise = gaussian_filter(rng.normal(size=xx.shape), sigma=xx.shape[0] / 20.0) * depth * 0.03
    return DigitalElevationModel(coords, coords, base + noise)


def coastal(extent_m: float = 4000, resolution_m: float = 25.0, slope: float = 0.02,
            seed: int = 42) -> DigitalElevationModel:
    coords, xx, yy, rng = _grid(extent_m, resolution_m, seed)
    base = np.clip(xx * slope, -5, extent_m * slope)
    noise = gaussian_filter(rng.normal(size=xx.shape), sigma=xx.shape[0] / 15.0) * 3.0
    return DigitalElevationModel(coords, coords, base + noise)


def plateau(extent_m: float = 4000, resolution_m: float = 25.0, height: float = 60.0,
            seed: int = 42) -> DigitalElevationModel:
    coords, xx, yy, rng = _grid(extent_m, resolution_m, seed)
    r = np.hypot(xx, yy)
    base = height / (1 + np.exp((r - extent_m * 0.3) / (extent_m * 0.03)))
    noise = gaussian_filter(rng.normal(size=xx.shape), sigma=xx.shape[0] / 20.0) * 2.0
    return DigitalElevationModel(coords, coords, base + noise)


GENERATORS: dict[str, Callable[..., DigitalElevationModel]] = {
    "flat": flat, "rolling": rolling, "mountain": mountain,
    "valley": valley, "coastal": coastal, "plateau": plateau,
}


def generate_terrain(kind: str, **kwargs) -> DigitalElevationModel:
    if kind not in GENERATORS:
        raise ValueError(f"Unknown terrain kind '{kind}'. Options: {list(GENERATORS)}")
    return GENERATORS[kind](**kwargs)
