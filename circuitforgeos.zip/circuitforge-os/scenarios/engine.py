"""
scenarios.engine
==================
ScenarioEngine (Section 78): named what-if scenarios applied on top of a
built TrackDigitalTwin, re-simulating the lap under different weather /
grip / driver / traffic assumptions without rebuilding geometry.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Dict, Optional

from engine.digital_twin.twin import TrackDigitalTwin
from engine.lap_time.simulator import simulate_lap, LapTimeResult
from engine.vehicle.driver import DRIVER_PRESETS, DriverProfile
from engine.vehicle.weather import WEATHER_PRESETS, WeatherCondition


class Scenario(str, Enum):
    DRY_DAY = "DRY_DAY"
    WET_DAY = "WET_DAY"
    HIGH_GRIP = "HIGH_GRIP"
    LOW_GRIP = "LOW_GRIP"
    AMATEUR_DRIVER = "AMATEUR_DRIVER"
    PRO_DRIVER = "PRO_DRIVER"
    HEAVY_TRAFFIC = "HEAVY_TRAFFIC"
    RACE_DAY = "RACE_DAY"
    CONSTRUCTION = "CONSTRUCTION"
    EARTHWORK_OPTIMISATION = "EARTHWORK_OPTIMISATION"


@dataclass
class ScenarioResult:
    scenario: Scenario
    lap: Optional[LapTimeResult]
    notes: str


def run_scenario(twin: TrackDigitalTwin, scenario: Scenario) -> ScenarioResult:
    vehicle = twin.vehicle
    driver = twin.driver
    grip_mult = 1.0
    driver_skill = driver.combined_skill
    notes = ""

    if scenario == Scenario.DRY_DAY:
        grip_mult = WEATHER_PRESETS[WeatherCondition.DRY].friction_multiplier
    elif scenario == Scenario.WET_DAY:
        grip_mult = WEATHER_PRESETS[WeatherCondition.WET].friction_multiplier
        notes = "Reduced friction & speed due to standing water (simulation estimate)."
    elif scenario == Scenario.HIGH_GRIP:
        grip_mult = 1.10
    elif scenario == Scenario.LOW_GRIP:
        grip_mult = 0.80
    elif scenario == Scenario.AMATEUR_DRIVER:
        driver_skill = DRIVER_PRESETS[DriverProfile.AMATEUR].combined_skill
    elif scenario == Scenario.PRO_DRIVER:
        driver_skill = DRIVER_PRESETS[DriverProfile.PRO].combined_skill
    elif scenario == Scenario.HEAVY_TRAFFIC:
        driver_skill *= 0.9
        notes = "Traffic congestion penalty applied as a driver-skill derate (simplified)."
    elif scenario == Scenario.RACE_DAY:
        driver_skill = DRIVER_PRESETS[DriverProfile.PRO].combined_skill
        grip_mult = 1.02
    elif scenario in (Scenario.CONSTRUCTION, Scenario.EARTHWORK_OPTIMISATION):
        return ScenarioResult(scenario=scenario, lap=None,
                               notes="Non-lap scenario — see twin.earthworks / twin.cost for results.")

    from engine.common import TrackArrays
    a = twin.track.arrays
    scaled_vehicle = vehicle.model_copy(deep=True)
    scaled_vehicle.tyre_mu = vehicle.tyre_mu * grip_mult

    line_arrays = TrackArrays(
        s=a.s, x=twin.racing_line.x, y=twin.racing_line.y, z=a.z, heading=a.heading,
        curvature=twin.racing_line.curvature, gradient=a.gradient, banking=a.banking,
        camber=a.camber, width=a.width,
    )
    lap = simulate_lap(line_arrays, scaled_vehicle, driver_skill=driver_skill)
    return ScenarioResult(scenario=scenario, lap=lap, notes=notes)


def run_all_scenarios(twin: TrackDigitalTwin) -> Dict[str, ScenarioResult]:
    return {s.value: run_scenario(twin, s) for s in Scenario}
