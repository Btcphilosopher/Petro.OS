"""
api.app
========
FastAPI surface for CIRCUITFORGE.OS (Sections 76-77). Serves a single
demo TrackDigitalTwin built at startup (see `main.build_demo_twin`) and
exposes REST + WebSocket endpoints for a future Kotlin/Compose or web
frontend. Run with:

    uvicorn api.app:app --reload
"""
from __future__ import annotations

import asyncio
from typing import Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect

from engine.digital_twin.twin import TrackDigitalTwin
from engine.optimisation.generator import GeneratorParams, TrackGenerator
from engine.geometry.builder import GeometryBuilder

app = FastAPI(title="CIRCUITFORGE.OS API",
              description="Pinpoint race-track design, physics and construction digital twin.",
              version="0.1.0")

_state = {"twin": None, "sim_running": False}


def get_twin() -> TrackDigitalTwin:
    if _state["twin"] is None:
        from main import build_demo_twin
        _state["twin"] = build_demo_twin()
    return _state["twin"]


@app.get("/track")
def get_track():
    twin = get_twin()
    return {"name": twin.track.name, **twin.report()}


@app.get("/track/geometry")
def get_geometry():
    twin = get_twin()
    a = twin.track.arrays
    return {"s": a.s.tolist(), "x": a.x.tolist(), "y": a.y.tolist(), "z": a.z.tolist(),
            "heading": a.heading.tolist(), "curvature": a.curvature.tolist(),
            "width": a.width.tolist()}


@app.get("/track/elevation")
def get_elevation():
    twin = get_twin()
    a = twin.track.arrays
    return {"s": a.s.tolist(), "z": a.z.tolist(), "gradient_pct": (a.gradient * 100).tolist()}


@app.get("/track/corners")
def get_corners():
    twin = get_twin()
    return [{
        "index": c.index + 1, "radius_m": round(c.min_radius_m, 1),
        "angle_deg": round(c.turn_angle_deg, 1), "class": c.corner_class.value,
        "entry_kmh": c.entry_speed_kmh, "apex_kmh": c.apex_speed_kmh, "exit_kmh": c.exit_speed_kmh,
    } for c in twin.track.corners]


@app.get("/track/sectors")
def get_sectors():
    twin = get_twin()
    from engine.topology.sectors import compute_sector_stats
    sectors = compute_sector_stats(twin.track.sectors, twin.track.arrays, twin.lap.speed_ms)
    return [{"name": s.name, "length_m": round(s.length_m, 1), "time_s": round(s.sector_time_s, 2),
             "avg_kmh": round(s.average_speed_kmh, 1), "max_kmh": round(s.maximum_speed_kmh, 1)}
            for s in sectors]


@app.get("/simulation/state")
def simulation_state():
    twin = get_twin()
    return {"running": _state["sim_running"], "lap_time": twin.lap.lap_time_str if twin.lap else None}


@app.get("/simulation/lap")
def simulation_lap():
    twin = get_twin()
    return {"lap_time_s": twin.lap.total_time_s, "lap_time": twin.lap.lap_time_str,
            "average_speed_kmh": twin.lap.average_speed_kmh, "max_speed_kmh": twin.lap.max_speed_kmh,
            "braking_zones": twin.lap.braking_zones}


@app.get("/simulation/telemetry")
def simulation_telemetry():
    twin = get_twin()
    lap = twin.lap
    return {"s": lap.s.tolist(), "speed_kmh": lap.speed_kmh.tolist(),
            "longitudinal_g": (lap.longitudinal_accel / 9.81).tolist(),
            "lateral_g": (lap.lateral_accel / 9.81).tolist()}


@app.get("/analysis/safety")
def analysis_safety():
    twin = get_twin()
    return {"runoff_area_m2": twin.safety.total_runoff_area_m2,
            "barrier_length_m": twin.safety.total_barrier_length_m,
            "marshal_posts": len(twin.safety.marshal_posts),
            "service_road_length_m": twin.safety.service_road_length_m,
            "disclaimer": twin.safety.disclaimer}


@app.get("/analysis/earthworks")
def analysis_earthworks():
    twin = get_twin()
    e = twin.earthworks
    return {"cut_m3": e.cut_volume_m3, "fill_m3": e.fill_volume_m3,
            "net_m3": e.net_volume_m3, "net_direction": e.net_direction}


@app.get("/analysis/construction")
def analysis_construction():
    twin = get_twin()
    from engine.construction.phases import build_phases
    from engine.construction.schedule import build_schedule
    phases = build_phases(
        earthworks_m3=twin.earthworks.net_volume_m3, pavement_m2=twin.pavement.surface_area_m2,
        drainage_m=twin.drainage.corridor_length_m, runoff_m2=twin.safety.total_runoff_area_m2,
        barrier_m=twin.safety.total_barrier_length_m, service_road_m2=twin.land.service_roads_m2,
        pit_area_m2=twin.pit_complex.total_pit_building_area_m2,
    )
    schedule = build_schedule(phases)
    return {"phases": [{"name": p.name.value, "duration_days": p.duration_days} for p in phases],
            "total_duration_days": schedule.total_duration_days}


@app.get("/analysis/cost")
def analysis_cost():
    twin = get_twin()
    return twin.cost.as_dict()


@app.post("/track/generate")
def track_generate(target_length_m: float = 5000, corner_count: int = 15,
                    straight_ratio: float = 0.45, elevation_change_m: float = 60,
                    technicality: float = 0.5, speed_character: float = 0.5, seed: int = 0):
    params = GeneratorParams(target_length_m, corner_count, straight_ratio,
                              elevation_change_m, technicality, speed_character, seed=seed)
    primitives = TrackGenerator(params).generate()
    arrays = GeometryBuilder(resolution_m=2.0).build(primitives)
    return {"length_m": arrays.length, "n_samples": len(arrays.s)}


@app.post("/track/optimise")
def track_optimise(objective: str = "BALANCED CIRCUIT", n_trials: int = 8):
    from engine.optimisation.optimizer import CircuitOptimizer, Objective
    twin = get_twin()

    def evaluate(params: GeneratorParams):
        primitives = TrackGenerator(params).generate()
        arrays = GeometryBuilder(resolution_m=2.0).build(primitives)
        from engine.topology.corners import detect_corners
        corners = detect_corners(arrays)
        return {"lap_time_s": arrays.length / 45.0, "earthworks_m3": 0,
                "construction_cost": arrays.length * 1000,
                "corner_variety": len(set(c.corner_class for c in corners)),
                "overtaking_score": 0, "design_score": arrays.length}

    base = GeneratorParams(target_length_m=twin.track.total_length, corner_count=len(twin.track.corners))
    opt = CircuitOptimizer(base, evaluate)
    results = opt.search(Objective(objective), n_trials=n_trials)
    return [{"objective_value": r.objective_value, "metrics": r.metrics} for r in results]


@app.post("/simulation/start")
def simulation_start():
    _state["sim_running"] = True
    return {"status": "started"}


@app.post("/simulation/stop")
def simulation_stop():
    _state["sim_running"] = False
    return {"status": "stopped"}


@app.post("/scenario/run")
def scenario_run(scenario: str = "DRY_DAY"):
    from scenarios.engine import run_scenario, Scenario
    twin = get_twin()
    result = run_scenario(twin, Scenario(scenario))
    if result.lap is None:
        return {"scenario": scenario, "notes": result.notes}
    return {"scenario": scenario, "lap_time": result.lap.lap_time_str,
            "average_speed_kmh": result.lap.average_speed_kmh, "notes": result.notes}


async def _ws_loop(ws: WebSocket, payload_fn):
    await ws.accept()
    try:
        while True:
            await ws.send_json(payload_fn())
            await asyncio.sleep(1.0)
    except WebSocketDisconnect:
        pass


@app.websocket("/ws/track")
async def ws_track(ws: WebSocket):
    await _ws_loop(ws, lambda: {"name": get_twin().track.name, "length_m": get_twin().track.total_length})


@app.websocket("/ws/simulation")
async def ws_simulation(ws: WebSocket):
    await _ws_loop(ws, lambda: {"running": _state["sim_running"], "lap_time": get_twin().lap.lap_time_str})


@app.websocket("/ws/vehicle")
async def ws_vehicle(ws: WebSocket):
    await _ws_loop(ws, lambda: get_twin().vehicle.model_dump())


@app.websocket("/ws/construction")
async def ws_construction(ws: WebSocket):
    await _ws_loop(ws, lambda: get_twin().cost.as_dict())
