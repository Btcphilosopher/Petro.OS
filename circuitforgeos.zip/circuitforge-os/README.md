# CIRCUITFORGE.OS

**Pinpoint Python digital race-track design & construction simulator.**

CIRCUITFORGE.OS is a parametric digital twin for fictional race-circuit
engineering. It lets you draw or parametrically generate a circuit and
immediately see how geometry, physics, terrain, safety and construction
cascade from a single change — the software's defining principle is
**parametric causality**:

```
geometry -> curvature -> elevation -> banking -> vehicle physics
-> racing line -> lap time -> safety/runoff -> terrain -> earthworks
-> construction -> cost -> optimisation -> new design
```

> **All vehicle-performance, safety, earthworks, drainage and cost figures
> produced by this software are SIMULATION ESTIMATES.** Nothing here is
> certified engineering, surveying, or motorsport safety approval.
> Increasing sampling resolution improves numerical precision, not
> real-world surveying accuracy.

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
python main.py
```

`python main.py` builds a synthetic demonstration circuit ("Taiwan
Mountain Circuit — DEMO"), runs it through the full engineering pipeline,
prints an engineering report, and writes CSV/JSON/GeoJSON/`.circuitforge`
exports plus PNG plots to `data/demo_output/`.

Run the API:

```bash
uvicorn api.app:app --reload
```

Run the test suite:

```bash
pytest
```

## Architecture

```
                 CIRCUITFORGE.OS
                       |
          +------------+------------+
          v            v            v
       GEOMETRY     PHYSICS      TERRAIN
          |            |            |
          v            v            v
      RACING LINE   VEHICLE      ELEVATION
          |            |            |
          +------------+------------+
                       v
                   LAP ENGINE
                       |
          +------------+------------+
          v            v            v
       SAFETY      DRAINAGE     CONSTRUCTION
          |            |            |
          +------------+------------+
                       v
                    COSTING
                       |
                       v
                 DIGITAL TWIN
```

Each subsystem lives in its own `engine/<subsystem>` package with a
clean interface — geometry, physics, safety, terrain, construction,
economics and optimisation are kept deliberately separate (no single
giant module).

## Project layout

```
circuitforge-os/
├── engine/
│   ├── geometry/       primitives (straight/arc/clothoid/hairpin/chicane/ess),
│   │                   curvature-integration builder, pavement boundaries
│   ├── topology/       RaceTrack, corner/straight/sector detection, circuit character
│   ├── spline/         CubicSpline/PCHIP/BSpline profile builder + continuity checks
│   ├── elevation/      elevation profile (hill/crest/valley/roller)
│   ├── banking/        banking profile + transitions
│   ├── camber/         camber profile
│   ├── vehicle/        Vehicle, presets, Gearbox, DriverModel, TyreModel, Weather, Surface
│   ├── physics/        aero drag/downforce, longitudinal dynamics, cornering limit
│   ├── racing_line/    SciPy minimum-curvature racing-line optimiser
│   ├── lap_time/       quasi-steady-state lap simulator, G-G diagram, traffic/overtaking
│   ├── safety/         SafetyZoneEngine (runoff/barriers/marshal posts/service roads)
│   ├── runoff/         speed-dependent runoff-zone sizing
│   ├── drainage/       conceptual surface-drainage analysis
│   ├── pavement/       pavement quantity take-off
│   ├── terrain/        synthetic DEM generators (flat/rolling/mountain/valley/coastal/plateau)
│   ├── earthworks/     cut/fill volumes, haul-distance estimate, vertical-alignment optimiser
│   ├── construction/   phases, Gantt-style schedule, equipment fleet, pit complex
│   ├── costing/        configurable cost database, land-requirement aggregation
│   ├── optimisation/   TrackGenerator, CircuitOptimizer, multi-objective/Pareto search, design score
│   └── digital_twin/   TrackDigitalTwin aggregator + JSON/CSV/GeoJSON/.circuitforge export
│
├── api/                FastAPI REST + WebSocket surface
├── scenarios/          ScenarioEngine (weather/grip/driver/traffic what-ifs)
├── visualisation/      Matplotlib track map, heatmaps, analytics charts, G-G diagram
├── data/                output/artefact directory
├── tests/              pytest suite (geometry, physics, lap time, racing line,
│                       earthworks, costing, optimisation, digital twin, API)
├── main.py
├── config.yaml
└── pyproject.toml
```

## Core object model

```python
class RaceTrack:
    track_id, name, total_length, width, centerline, elevation_profile,
    banking_profile, camber_profile, sectors, corners, straights,
    runoff_zones, terrain
```

Each centreline sample (`engine.common.TrackPoint`) carries
`distance, x, y, z, heading, curvature, gradient, banking, camber,
track_width` — the pinpoint unit the rest of the engine consumes.

## Parametric editing example

```python
from main import build_demo_twin

twin = build_demo_twin()
twin.edit_corner_radius(6, new_radius_m=55.0)   # Turn 7: 42m -> 55m
print(twin.report())   # curvature, racing line, speed, braking, lap time,
                        # earthworks, runoff and construction all recomputed
```

## Numerical methods used

- Curvature-to-Cartesian alignment via cumulative integration (Euler
  method) of a piecewise curvature function — the standard way
  road/rail/track alignments are generated from parametric primitives.
- `scipy.interpolate.CubicSpline` / `PchipInterpolator` / `BSpline` for
  elevation, banking, camber and width profiles, with C0/C1/C2
  continuity checking.
- `scipy.optimize.minimize` (L-BFGS-B) for the minimum-curvature racing
  line, and Nelder-Mead for the earthworks vertical-alignment optimiser.
- `scipy.optimize.brentq` for power-limited top-speed root finding.
- A forward/backward quasi-steady-state pass for lap-time simulation
  (corner-speed limit -> traction-limited forward integration ->
  braking-limited backward integration).
- `shapely` polygons for pavement, runoff and land-area geometry.
- `scipy.ndimage.gaussian_filter`-smoothed synthetic terrain generation.
- NumPy vectorisation throughout the per-sample pipeline (curvature,
  elevation, banking, cornering-limit, earthworks) to support 5–20 km
  tracks at 1 m (or finer) resolution.

## License / disclaimer

This is an engineering **simulator** for fictional circuits. It is not a
substitute for licensed civil, structural, or motorsport-safety
engineering, and produces no certified outputs.
