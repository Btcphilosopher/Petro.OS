# data/

Output directory for generated artefacts (CSV/JSON/GeoJSON/`.circuitforge`
exports, PNG plots). `python main.py` writes its demo outputs to
`data/demo_output/`.
