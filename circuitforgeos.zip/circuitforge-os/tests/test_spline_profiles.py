import numpy as np
from engine.spline.profiles import ControlPoint, ProfileSpline, continuity_report
from engine.elevation.engine import ElevationProfile
from engine.banking.engine import BankingProfile


def test_pchip_hits_control_points():
    cps = [ControlPoint(0, 0), ControlPoint(100, 10), ControlPoint(200, 0)]
    spline = ProfileSpline(cps, kind="pchip")
    assert spline(np.array([0.0]))[0] == 0
    assert abs(spline(np.array([100.0]))[0] - 10) < 1e-6


def test_elevation_gradient_sign():
    ep = ElevationProfile.hill(1000, 50)
    s = np.linspace(0, 1000, 1000)
    result = ep.evaluate(s)
    assert result.max_uphill_pct > 0
    assert result.max_downhill_pct < 0


def test_banking_no_instant_jump():
    bp = BankingProfile([ControlPoint(0, 0), ControlPoint(50, 10), ControlPoint(100, 10)])
    s = np.linspace(0, 100, 500)
    values = bp.evaluate(s)
    jumps = np.abs(np.diff(values))
    assert np.max(jumps) < 1.0  # smooth transition, no step change


def test_continuity_report_flags_c0():
    values = np.array([0, 1, 2, 3, 100, 5, 6])
    report = continuity_report(values.astype(float), ds=1.0)
    assert report["C1_continuous"] is False
