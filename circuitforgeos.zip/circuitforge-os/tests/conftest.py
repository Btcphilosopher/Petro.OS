"""
Shared pytest fixtures — a known synthetic "stadium" oval circuit
(two straights + two 180-degree semicircle arcs) with an exact expected
length, used across the geometry/physics/lap-time test suite (Section 93).
"""
from __future__ import annotations

import numpy as np
import pytest

from engine.geometry.builder import GeometryBuilder
from engine.geometry.primitives import straight, circular_arc
from engine.topology.track import RaceTrack
from engine.vehicle.model import get_preset, VehicleType
from engine.vehicle.driver import get_driver, DriverProfile


STRAIGHT_LEN = 400.0
RADIUS = 100.0


def oval_primitives():
    return [
        straight(STRAIGHT_LEN, label="Back straight"),
        circular_arc(RADIUS, 180, direction=1, label="Turn 1"),
        straight(STRAIGHT_LEN, label="Front straight"),
        circular_arc(RADIUS, 180, direction=1, label="Turn 2"),
    ]


@pytest.fixture
def oval_track():
    builder = GeometryBuilder(resolution_m=1.0)
    arrays = builder.build(oval_primitives(), start_width=12.0)
    return RaceTrack(track_id="TEST-OVAL", name="Test Oval", arrays=arrays).recompute_topology()


@pytest.fixture
def gt_vehicle():
    return get_preset(VehicleType.GT)


@pytest.fixture
def pro_driver():
    return get_driver(DriverProfile.PRO)
