import numpy as np
import pytest
from engine.geometry.builder import GeometryBuilder
from tests.conftest import oval_primitives, STRAIGHT_LEN, RADIUS


def test_expected_length():
    prims = oval_primitives()
    expected = 2 * STRAIGHT_LEN + 2 * np.pi * RADIUS
    total = sum(p.length for p in prims)
    assert abs(total - expected) < 1e-6


def test_closure(oval_track):
    report = oval_track.validate()
    assert report["closed_circuit"], report


def test_curvature_matches_radius(oval_track):
    arr = oval_track.arrays
    in_arc = np.abs(arr.curvature) > 1e-6
    radii = 1.0 / np.abs(arr.curvature[in_arc])
    assert np.allclose(radii, RADIUS, atol=1.0)


def test_pavement_area_positive(oval_track):
    assert oval_track.boundaries.pavement_area_m2 > 0
    assert oval_track.boundaries.average_width_m == pytest.approx(12.0, abs=0.5)


def test_boundaries_width(oval_track):
    left = np.hypot(oval_track.boundaries.left_x - oval_track.arrays.x,
                     oval_track.boundaries.left_y - oval_track.arrays.y)
    assert np.allclose(left, oval_track.arrays.width / 2.0, atol=1e-6)
