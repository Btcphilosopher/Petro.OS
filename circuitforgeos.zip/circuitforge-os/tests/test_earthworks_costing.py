import numpy as np
from engine.terrain.dem import mountain
from engine.earthworks.engine import compute_earthworks, estimate_haul
from engine.costing.engine import compute_cost
from engine.costing.land import compute_land_requirement


def test_earthworks_nonnegative(oval_track):
    dem = mountain(extent_m=3000, resolution_m=30, peak_height=100, seed=1)
    result = compute_earthworks(oval_track.arrays, dem, corridor_width_m=30, side_slope_ratio=2.0)
    assert result.cut_volume_m3 >= 0
    assert result.fill_volume_m3 >= 0


def test_haul_estimate_bounded(oval_track):
    dem = mountain(extent_m=3000, resolution_m=30, peak_height=100, seed=1)
    ew = compute_earthworks(oval_track.arrays, dem)
    haul = estimate_haul(ew, oval_track.arrays)
    assert haul.total_moved_m3 <= max(ew.cut_volume_m3, ew.fill_volume_m3) + 1


def test_cost_breakdown_sums_to_total():
    cfg = {"unit_costs": {
        "earthworks_per_m3": 10, "pavement_per_m2": 50, "drainage_per_m": 100,
        "runoff_per_m2": 5, "barrier_per_m": 200, "service_road_per_m2": 30,
        "pit_infrastructure_per_m2": 500, "land_prep_per_m2": 8,
    }, "currency": "TEST"}
    breakdown = compute_cost(1000, 2000, 300, 500, 400, 600, 700, 800, cfg)
    manual_total = sum([breakdown.earthworks, breakdown.pavement, breakdown.drainage,
                         breakdown.runoff, breakdown.barriers, breakdown.service_roads,
                         breakdown.pit_infrastructure, breakdown.land_preparation])
    assert breakdown.total == manual_total
    assert breakdown.total > 0


def test_land_requirement_positive():
    cfg = {"land": {"paddock_area_m2": 1000, "pit_complex_area_m2": 500,
                     "parking_area_m2": 2000, "landscape_buffer_m": 10}}
    land = compute_land_requirement(5000, 2000, 1000, 3000, cfg, track_perimeter_m=6000)
    assert land.total_site_area_m2 > 5000
