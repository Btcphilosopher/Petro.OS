from main import build_demo_twin


def test_demo_twin_builds_and_reports():
    twin = build_demo_twin(seed=3)
    report = twin.report()
    assert report["track_length_km"] > 0
    assert report["corners"] > 0
    assert twin.lap.total_time_s > 0
    assert report["conceptual_construction_cost"] > 0


def test_parametric_edit_recomputes_chain():
    twin = build_demo_twin(seed=3)
    before_cost = twin.cost.total
    before_lap = twin.lap.total_time_s
    twin.edit_corner_radius(0, twin.track.corners[0].min_radius_m * 1.5)
    after_cost = twin.cost.total
    after_lap = twin.lap.total_time_s
    # Something downstream must have changed after a geometric edit.
    assert (before_cost, before_lap) != (after_cost, after_lap)
    assert len(twin.history) >= 2


def test_design_history_grows():
    twin = build_demo_twin(seed=5)
    n0 = len(twin.history)
    twin.recompute()
    assert len(twin.history) == n0 + 1
