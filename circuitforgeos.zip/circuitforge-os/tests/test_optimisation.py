from engine.optimisation.generator import GeneratorParams, TrackGenerator
from engine.optimisation.optimizer import CircuitOptimizer, Objective
from engine.geometry.builder import GeometryBuilder


def test_generator_produces_target_length_within_tolerance():
    params = GeneratorParams(target_length_m=3000, corner_count=10, seed=1)
    primitives = TrackGenerator(params).generate()
    total = sum(p.length for p in primitives)
    assert abs(total - 3000) / 3000 < 0.15


def test_optimizer_search_ranks_by_objective():
    def evaluate(params: GeneratorParams):
        prims = TrackGenerator(params).generate()
        length = sum(p.length for p in prims)
        return {"lap_time_s": length / 40.0, "earthworks_m3": length * 10,
                "construction_cost": length * 500, "corner_variety": params.corner_count,
                "overtaking_score": params.straight_ratio * 10, "design_score": length}

    base = GeneratorParams(target_length_m=3000, corner_count=10, seed=1)
    opt = CircuitOptimizer(base, evaluate)
    results = opt.search(Objective.MIN_LAP_TIME, n_trials=6, seed=2)
    values = [r.objective_value for r in results]
    assert values == sorted(values, reverse=True)


def test_pareto_front_nonempty():
    def evaluate(params: GeneratorParams):
        prims = TrackGenerator(params).generate()
        length = sum(p.length for p in prims)
        return {"lap_time_s": length / 40.0, "earthworks_m3": length * 10,
                "construction_cost": length * 500, "corner_variety": params.corner_count,
                "overtaking_score": params.straight_ratio * 10, "design_score": length}

    base = GeneratorParams(target_length_m=3000, corner_count=10, seed=1)
    opt = CircuitOptimizer(base, evaluate)
    front = opt.pareto_front([Objective.MIN_LAP_TIME, Objective.MAX_OVERTAKING], n_trials=8, seed=3)
    assert len(front) >= 1
