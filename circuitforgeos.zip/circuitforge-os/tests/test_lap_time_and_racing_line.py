import numpy as np
from engine.lap_time.simulator import simulate_lap
from engine.racing_line.optimizer import RacingLineOptimizer


def test_lap_time_positive_and_reasonable(oval_track, gt_vehicle):
    result = simulate_lap(oval_track.arrays, gt_vehicle)
    assert result.total_time_s > 0
    # sanity: average speed should be well below vehicle top speed but above walking pace
    assert 20 < result.average_speed_kmh < 400


def test_lap_speed_drops_in_turns(oval_track, gt_vehicle):
    result = simulate_lap(oval_track.arrays, gt_vehicle)
    straight_mask = np.abs(oval_track.arrays.curvature) < 1e-5
    corner_mask = np.abs(oval_track.arrays.curvature) > 1e-3
    assert np.mean(result.speed_kmh[straight_mask]) > np.mean(result.speed_kmh[corner_mask])


def test_racing_line_stays_within_track(oval_track):
    rlo = RacingLineOptimizer(oval_track.arrays, car_width_m=1.9, n_control_points=20)
    result = rlo.solve(maxiter=60)
    half_w = oval_track.arrays.width / 2.0
    assert np.all(np.abs(result.offset_n) <= half_w + 1e-6)


def test_racing_line_reduces_or_maintains_peak_curvature(oval_track):
    rlo = RacingLineOptimizer(oval_track.arrays, car_width_m=1.9, n_control_points=20)
    result = rlo.solve(maxiter=60)
    centre_peak = np.max(np.abs(oval_track.arrays.curvature))
    line_peak = np.max(np.abs(result.curvature))
    assert line_peak <= centre_peak * 1.05
