import numpy as np
import pytest
from engine.physics.aero import drag_force, downforce
from engine.physics.cornering import max_corner_speed
from engine.physics.longitudinal import net_acceleration


def test_drag_increases_with_speed(gt_vehicle):
    v = np.array([20.0, 40.0, 60.0])
    d = drag_force(gt_vehicle, v)
    assert d[0] < d[1] < d[2]


def test_downforce_scales_v_squared(gt_vehicle):
    d1 = downforce(gt_vehicle, np.array([50.0]))[0]
    d2 = downforce(gt_vehicle, np.array([100.0]))[0]
    assert d2 == pytest.approx(d1 * 4, rel=0.02)


def test_max_corner_speed_decreases_with_curvature(gt_vehicle):
    kappa = np.array([0.005, 0.02, 0.05])
    v = max_corner_speed(gt_vehicle, kappa)
    assert v[0] > v[1] > v[2]


def test_net_acceleration_positive_at_low_speed(gt_vehicle):
    a = net_acceleration(gt_vehicle, 10.0, gradient=0.0)
    assert a > 0


def test_braking_deceleration_negative(gt_vehicle):
    a = net_acceleration(gt_vehicle, 50.0, gradient=0.0, braking=True)
    assert a < 0
