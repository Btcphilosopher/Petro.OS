from fastapi.testclient import TestClient
from api.app import app

client = TestClient(app)


def test_get_track():
    r = client.get("/track")
    assert r.status_code == 200
    assert "track_length_km" in r.json()


def test_get_corners():
    r = client.get("/track/corners")
    assert r.status_code == 200
    assert isinstance(r.json(), list)


def test_get_sectors():
    r = client.get("/track/sectors")
    assert r.status_code == 200


def test_analysis_cost():
    r = client.get("/analysis/cost")
    assert r.status_code == 200
    assert "total" in r.json()


def test_scenario_run():
    r = client.post("/scenario/run", params={"scenario": "WET_DAY"})
    assert r.status_code == 200
    assert "lap_time" in r.json()
