/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Fuel, ElementalComposition, ChamberInput, CycleConfig, SimulationOutput, EquilibriumComposition, SimulationResultItem, EconomicInput } from '../src/types';

// ============================================================================
// 1. FUEL DATABASE & DEFAULT PRESETS
// ============================================================================
export const FUEL_DATABASE: Fuel[] = [
  {
    id: 'methane',
    name: 'Pure Methane (CH4)',
    type: 'gas',
    composition: { c: 0.7487, h: 0.2513, o: 0, n: 0, s: 0, ash: 0, moisture: 0, inert: 0 },
    molecularWeight: 16.04,
    density: 0.6797, // kg/m^3 (ambient conditions)
    lhv: 50.00, // MJ/kg
    hhv: 55.50, // MJ/kg
    specificHeat: 2220, // J/kg-K
    physicalState: 'gas',
    uncertainty: { composition: 0.1, heatingValue: 0.2, price: 0.5 },
    price: 3.5, // USD/MMBtu
    currency: 'USD',
    source: 'NIST Chemistry WebBook'
  },
  {
    id: 'natural_gas',
    name: 'Pipeline Natural Gas (US Standard)',
    type: 'gas',
    composition: { c: 0.7250, h: 0.2350, o: 0.0050, n: 0.0150, s: 0.0001, ash: 0, moisture: 0, inert: 0.0199 },
    molecularWeight: 17.2,
    density: 0.720,
    lhv: 47.10,
    hhv: 52.20,
    specificHeat: 2180,
    physicalState: 'gas',
    uncertainty: { composition: 0.5, heatingValue: 0.5, price: 1.0 },
    price: 4.2, // USD/MMBtu
    currency: 'USD',
    source: 'AGA Report No. 8'
  },
  {
    id: 'propane',
    name: 'Industrial Propane (C3H8)',
    type: 'gas',
    composition: { c: 0.8171, h: 0.1829, o: 0, n: 0, s: 0, ash: 0, moisture: 0, inert: 0 },
    molecularWeight: 44.10,
    density: 1.867,
    lhv: 46.35,
    hhv: 50.35,
    specificHeat: 1670,
    physicalState: 'gas',
    uncertainty: { composition: 0.2, heatingValue: 0.3, price: 0.8 },
    price: 1.25, // USD/gallon
    currency: 'USD',
    source: 'GPA Standard 2145'
  },
  {
    id: 'diesel',
    name: 'Ultra-Low Sulfur Diesel (No. 2-D)',
    type: 'oil',
    composition: { c: 0.8580, h: 0.1380, o: 0.0010, n: 0.0008, s: 0.0002, ash: 0.0001, moisture: 0.0009, inert: 0.0010 },
    molecularWeight: 170.0,
    density: 840.0,
    lhv: 42.60,
    hhv: 45.50,
    specificHeat: 1900,
    viscosity: 0.0028, // Pa-s
    physicalState: 'liquid',
    uncertainty: { composition: 1.0, heatingValue: 0.8, price: 1.5 },
    price: 3.20, // USD/gallon
    currency: 'USD',
    source: 'EPA Emissions Factors Database'
  },
  {
    id: 'heavy_fuel_oil',
    name: 'Heavy Fuel Oil (No. 6 Bunker C)',
    type: 'oil',
    composition: { c: 0.8620, h: 0.1050, o: 0.0040, n: 0.0030, s: 0.0250, ash: 0.0008, moisture: 0.0002, inert: 0.0000 },
    molecularWeight: 450.0,
    density: 980.0,
    lhv: 39.80,
    hhv: 42.50,
    specificHeat: 1750,
    viscosity: 0.3800,
    physicalState: 'liquid',
    uncertainty: { composition: 1.5, heatingValue: 1.0, price: 2.0 },
    price: 520.0, // USD/tonne
    currency: 'USD',
    source: 'ISO 8217 Marine Fuels'
  },
  {
    id: 'coal_bituminous',
    name: 'Bituminous Steam Coal (UK Grade)',
    type: 'coal',
    composition: { c: 0.7100, h: 0.0480, o: 0.0750, n: 0.0130, s: 0.0180, ash: 0.0820, moisture: 0.0450, inert: 0.0090 },
    molecularWeight: 320.0, // pseudo-MW for carbon ring representation
    density: 1350.0,
    lhv: 26.50,
    hhv: 28.20,
    specificHeat: 1100,
    physicalState: 'solid',
    uncertainty: { composition: 2.0, heatingValue: 1.5, price: 3.0 },
    price: 115.0, // GBP/tonne
    currency: 'GBP',
    source: 'British Geological Survey'
  }
];

// ============================================================================
// 2. THERMODYNAMIC COEFFICIENTS & NASA SHOMATE EQUATIONS
// ============================================================================
// Shomate Equation:
// Cp = A + B*t + C*t^2 + D*t^3 + E/t^2 (J/mol-K)
// H - H298.15 = A*t + B*t^2/2 + C*t^3/3 + D*t^4/4 - E/t + F - H298_form (kJ/mol)
// S = A*ln(t) + B*t + C*t^2/2 + D*t^3/3 - E/(2*t^2) + G (J/mol-K)
// where t = T / 1000 (K)
// Valid for temperatures between 298.15 K and 6000 K (represented in standard ranges).
export interface ShomateCoefficients {
  A: number; B: number; C: number; D: number; E: number; F: number; G: number;
  Hf298: number; // Enthalpy of formation at 298.15 K in kJ/mol
}

export const SHOMATE_COEFFS: Record<string, ShomateCoefficients> = {
  CO2:  { A: 24.99735, B: 55.18696,  C: -33.69137, D: 7.948387, E: -0.136638, F: -403.6075, G: 228.2431, Hf298: -393.52 },
  CO:   { A: 25.56759, B: 6.096130,  C: -1.554760, D: 0.104168, E: 0.103714,  F: -118.0089, G: 201.2413, Hf298: -110.53 },
  H2O:  { A: 30.09200, B: 6.832514,  C: 6.793435,  D: -2.534480, E: 0.082139,  F: -250.8810, G: 223.3967, Hf298: -241.83 }, // Vapor
  H2:   { A: 33.06617, B: -11.36341, C: 11.43281,  D: -2.772874, E: -0.158558, F: -9.980797, G: 172.7079, Hf298: 0.0 },
  O2:   { A: 30.03235, B: 8.772912,  C: -3.435283, D: 0.469247,  E: -0.250847, F: -9.696460, G: 188.9431, Hf298: 0.0 },
  N2:   { A: 26.00266, B: 4.315904,  C: -0.701170, D: 0.046162,  E: 0.147079,  F: -7.935900, G: 191.1715, Hf298: 0.0 },
  SO2:  { A: 21.43048, B: 74.35094,  C: -53.51620, D: 13.82421,  E: -0.085805, F: -305.9388, G: 254.8872, Hf298: -296.84 },
  SO3:  { A: 31.96101, B: 122.9556,  C: -87.79549, D: 22.18378,  E: -0.245846, F: -412.3592, G: 282.8431, Hf298: -395.70 },
  NO:   { A: 26.11115, B: 6.471377,  C: -1.823901, D: 0.190139,  E: 0.144869,  F: 81.33436,  G: 214.3413, Hf298: 90.29 },
  NO2:  { A: 21.57912, B: 71.45188,  C: -49.33642, D: 12.34812,  E: -0.080536, F: 19.38722,  G: 247.8872, Hf298: 33.10 },
  OH:   { A: 28.53041, B: 1.096147,  C: 1.254760,  D: -0.410168, E: -0.103714, F: 30.50890,  G: 189.2413, Hf298: 39.00 },
  O:    { A: 25.42000, B: -0.01500,  C: 0.005000,  D: -0.000500, E: -0.040000, F: 245.8810,  G: 161.3967, Hf298: 249.17 },
  H:    { A: 20.78600, B: 0.000000,  C: 0.000000,  D: 0.000000,  E: 0.000000,  F: 216.0020,  G: 114.7079, Hf298: 218.00 }
};

// Return Specific Heat Cp in J/(mol-K)
export function getSpeciesCp(species: string, T: number): number {
  const coeff = SHOMATE_COEFFS[species];
  if (!coeff) return 29.1; // Default similar to N2
  const t = T / 1000;
  return coeff.A + coeff.B * t + coeff.C * t * t + coeff.D * t * t * t + coeff.E / (t * t);
}

// Return Absolute Enthalpy in kJ/mol (Formation + Sensible enthalpy)
export function getSpeciesEnthalpy(species: string, T: number): number {
  const coeff = SHOMATE_COEFFS[species];
  if (!coeff) return 0;
  const t = T / 1000;
  const H_sensible = coeff.A * t + (coeff.B * t * t) / 2 + (coeff.C * t * t * t) / 3 + (coeff.D * t * t * t * t) / 4 - coeff.E / t + coeff.F;
  return H_sensible; // Note: Shomate integration constant F incorporates Delta_f H(298) and H(T) relative scale.
}

// ============================================================================
// 3. STOICHIOMETRIC & PROCESS CALCULATOR
// ============================================================================
export interface StoichResult {
  stoichAFR: number; // kg air / kg fuel
  o2Required: number; // kg O2 / kg fuel
  co2Production: number; // kg CO2 / kg fuel
  h2oProduction: number; // kg H2O / kg fuel
  so2Production: number; // kg SO2 / kg fuel
  n2Production: number; // kg N2 / kg fuel (from air and fuel)
}

export function solveStoichiometry(composition: ElementalComposition): StoichResult {
  const { c, h, o, n, s, moisture } = composition;

  // Oxygen required for element oxidation (kmol O2 per kg fuel):
  // C + O2 -> CO2 (1 kmol O2 per 12.011 kg Carbon)
  // 4H + O2 -> 2H2O (1 kmol O2 per 4.032 kg Hydrogen)
  // S + O2 -> SO2 (1 kmol O2 per 32.06 kg Sulphur)
  // Oxygen in fuel reduces stoichiometry (1 kmol O2 per 31.998 kg Fuel Oxygen)
  const o2_demanded_kmol = (c / 12.011) + (h / 4.032) + (s / 32.06) - (o / 31.998);
  const o2Required_kmol = Math.max(0, o2_demanded_kmol);
  const o2Required_kg = o2Required_kmol * 31.998;

  // Air contains 23.2% O2 by mass, and 76.8% N2 + inerts by mass.
  const stoichAFR = o2Required_kg / 0.232;

  // Products per kg fuel
  const co2Production = (c / 12.011) * 44.01;
  const h2oProduction = (h / 2.016) * 18.015 + moisture;
  const so2Production = (s / 32.06) * 64.06;
  const n2Production = (stoichAFR * 0.768) + n;

  return {
    stoichAFR,
    o2Required: o2Required_kg,
    co2Production,
    h2oProduction,
    so2Production,
    n2Production
  };
}

// ============================================================================
// 4. CHEMICAL EQUILIBRIUM SOLVER
// ============================================================================
// Robust Water-Gas Shift equilibrium solver for rich conditions & minor dissociations
export function solveEquilibrium(
  composition: ElementalComposition,
  lambda: number,
  T_est: number,
  P_bar: number
): EquilibriumComposition {
  const stoich = solveStoichiometry(composition);
  
  // Total elements fed (moles per kg fuel)
  const C_tot = composition.c / 12.011;
  const H_tot = (composition.h / 1.008) + 2 * (composition.moisture / 18.015);
  // Air feed oxygen and nitrogen (mass to moles)
  const air_mass = lambda * stoich.stoichAFR;
  const O_air = (air_mass * 0.232) / 15.999;
  const O_fuel = composition.o / 15.999;
  const O_tot = O_air + O_fuel;
  
  const N_air = (air_mass * 0.768) / 14.007;
  const N_fuel = composition.n / 14.007;
  const N_tot = N_air + N_fuel;
  
  const S_tot = composition.s / 32.06;

  // Initial species moles estimate
  let n_CO2 = 0;
  let n_CO = 0;
  let n_H2O = 0;
  let n_H2 = 0;
  let n_O2 = 0;
  let n_N2 = N_tot / 2;
  let n_SO2 = S_tot;
  let n_SO3 = 0;
  let n_NO = 0;
  let n_NO2 = 0;
  let n_OH = 0;
  let n_O = 0;
  let n_H = 0;

  if (lambda >= 1.0) {
    // Lean: Complete oxidation + excess oxygen
    n_CO2 = C_tot;
    n_H2O = H_tot / 2;
    n_SO2 = S_tot;
    const O_used = 2 * n_CO2 + n_H2O + 2 * n_SO2;
    n_O2 = Math.max(0, (O_tot - O_used) / 2);
  } else {
    // Rich: Partition between CO2, CO, H2O, H2 via Water-Gas Shift
    // CO + H2O <-> CO2 + H2
    // Equilibrium constant Kw(T) = exp(-Delta G / RT)
    // Approximate Kw(T) as function of T (K)
    const t = T_est / 1000;
    const Kw = Math.exp(5068 / T_est - 4.417); // Water-gas shift K_p approximation

    // Conservation:
    // n_CO + n_CO2 = C_tot
    // 2*n_H2O + 2*n_H2 = H_tot
    // n_CO + 2*n_CO2 + n_H2O = O_reactive = O_tot - 2*S_tot
    const O_reactive = Math.max(0, O_tot - 2 * S_tot);

    // Solve for n_CO2 using quadratic equation:
    // Kw = (n_CO2 * n_H2) / (n_CO * n_H2O)
    // Solve iteratively or with a robust search
    let best_CO2 = C_tot * 0.5;
    for (let iter = 0; iter < 40; iter++) {
      const CO2 = best_CO2;
      const CO = Math.max(1e-8, C_tot - CO2);
      // H2O calculation based on oxygen balance:
      // O_reactive = CO + 2*CO2 + H2O = (C_tot - CO2) + 2*CO2 + H2O = C_tot + CO2 + H2O
      const H2O = Math.max(1e-8, O_reactive - C_tot - CO2);
      const H2 = Math.max(1e-8, (H_tot - 2 * H2O) / 2);
      
      const F = (CO2 * H2) - Kw * (CO * H2O);
      // Derivative with respect to CO2
      const dF = H2 + CO2 * 0.5 - Kw * (-H2O - CO);
      const step = F / dF;
      best_CO2 = Math.min(C_tot - 1e-6, Math.max(1e-6, best_CO2 - step));
    }
    
    n_CO2 = best_CO2;
    n_CO = C_tot - n_CO2;
    n_H2O = Math.max(0, O_reactive - C_tot - n_CO2);
    n_H2 = Math.max(0, (H_tot - 2 * n_H2O) / 2);
    n_O2 = 0;
  }

  // Handle thermal dissociation of CO2 <-> CO + 0.5 O2 at very high temperature (T > 1800K)
  if (T_est > 1600) {
    const K_co2 = Math.exp(-282400 / (8.314 * T_est) + 10.3); // CO2 dissociation constant
    // Adjust CO2/CO based on dissociation
    if (lambda >= 1.0 && n_CO2 > 0) {
      const diss_fraction = Math.min(0.1, K_co2 / (1.0 + P_bar));
      const diss_moles = n_CO2 * diss_fraction;
      n_CO2 -= diss_moles;
      n_CO += diss_moles;
      n_O2 += diss_moles * 0.5;
    }
    
    // Thermal NO formation (Extended Zeldovich equilibrium portion)
    // N2 + O2 <-> 2 NO
    const K_no = Math.exp(-180500 / (8.314 * T_est) + 2.5); // NO equilibrium constant
    if (n_N2 > 0 && n_O2 > 0) {
      const no_equil_moles = Math.sqrt(K_no * n_N2 * n_O2) * 2;
      const change = Math.min(n_N2 * 0.02, no_equil_moles / 2);
      n_N2 -= change;
      n_O2 -= change * 0.5;
      n_NO += change * 2;
    }

    // Trace free radicals OH, O, H, SO3 at high temperature
    const K_o = Math.exp(-249000 / (8.314 * T_est) + 6.1);
    if (n_O2 > 0) {
      n_O = Math.sqrt(K_o * n_O2);
    }
    const K_oh = Math.exp(-39000 / (8.314 * T_est) + 1.2);
    if (n_H2O > 0 && n_O2 > 0) {
      n_OH = K_oh * Math.sqrt(n_H2O * n_O2);
    }
  }

  // SO2 -> SO3 conversion (typically 1-5% in boiler, depending on temperature)
  if (n_SO2 > 0 && n_O2 > 0) {
    const K_so3 = Math.exp(99000 / (8.314 * T_est) - 10.2); // exothermic, favors SO3 at lower temp
    const ratio = Math.min(0.05, K_so3 * Math.sqrt(n_O2));
    n_SO3 = n_SO2 * ratio;
    n_SO2 -= n_SO3;
  }

  const n_sum = n_CO2 + n_CO + n_H2O + n_H2 + n_O2 + n_N2 + n_OH + n_O + n_H + n_NO + n_NO2 + n_SO2 + n_SO3;

  return {
    CO2: n_CO2 / n_sum,
    CO: n_CO / n_sum,
    H2O: n_H2O / n_sum,
    H2: n_H2 / n_sum,
    O2: n_O2 / n_sum,
    N2: n_N2 / n_sum,
    OH: n_OH / n_sum,
    O: n_O / n_sum,
    H: n_H / n_sum,
    NO: n_NO / n_sum,
    NO2: n_NO2 / n_sum,
    SO2: n_SO2 / n_sum,
    SO3: n_SO3 / n_sum
  };
}

// ============================================================================
// 5. ADIABATIC FLAME TEMPERATURE SOLVER (NEWTON-RAPHSON)
// ============================================================================
export function solveAdiabaticFlameTemp(
  fuel: Fuel,
  chamber: ChamberInput
): { aft: number; productsMoles: Record<string, number> } {
  const { lambda, inletTempAir, inletTempFuel } = chamber;
  const stoich = solveStoichiometry(fuel.composition);
  const air_mass = lambda * stoich.stoichAFR; // kg air / kg fuel

  // 1. Calculate Reactant Enthalpy H_in (kJ/kg fuel)
  // Air contains 23.2% O2 and 76.8% N2
  const o2_air_moles = (air_mass * 0.232) / 0.031998;
  const n2_air_moles = (air_mass * 0.768) / 0.028013;
  
  const h_o2_air = getSpeciesEnthalpy('O2', inletTempAir) * o2_air_moles;
  const h_n2_air = getSpeciesEnthalpy('N2', inletTempAir) * n2_air_moles;
  
  // Fuel enthalpy
  // Solid or liquid fuel represented via elemental parts. For pure gas fuels, use the molecule directly.
  let h_fuel = 0;
  if (fuel.physicalState === 'gas' && SHOMATE_COEFFS[fuel.id.toUpperCase()]) {
    const fuel_moles = 1000 / fuel.molecularWeight; // moles per kg fuel
    h_fuel = getSpeciesEnthalpy(fuel.id.toUpperCase(), inletTempFuel) * fuel_moles;
  } else {
    // For non-gaseous or complex hydrocarbons, we estimate the standard enthalpy of formation using heating values
    // LHV = H_reactants(298) - H_products(298)
    // Form of formation of products at 298.15K is known.
    // LHV (MJ/kg) = 1000 * LHV (kJ/kg)
    const n_co2_stoich = (fuel.composition.c / 12.011) * 1000;
    const n_h2o_stoich = ((fuel.composition.h / 2.016) * 1000) + (fuel.composition.moisture / 0.018015);
    const n_so2_stoich = (fuel.composition.s / 32.06) * 1000;
    
    const h_products_298 = (n_co2_stoich * SHOMATE_COEFFS.CO2.Hf298) + (n_h2o_stoich * SHOMATE_COEFFS.H2O.Hf298) + (n_so2_stoich * SHOMATE_COEFFS.SO2.Hf298);
    // H_fuel_formation = LHV + H_products_298
    const H_fuel_formation = (fuel.lhv * 1000) + h_products_298; // kJ/kg fuel
    const Cp_fuel = fuel.specificHeat; // J/kg-K
    const h_fuel_sensible = (Cp_fuel / 1000) * (inletTempFuel - 298.15); // kJ/kg fuel
    h_fuel = H_fuel_formation + h_fuel_sensible;
  }

  const H_reactants_total = h_o2_air + h_n2_air + h_fuel; // kJ/kg fuel

  // 2. Solve for flame temperature using Newton-Raphson iteration
  // products list: CO2, CO, H2O, H2, O2, N2, SO2, SO3, NO, NO2
  let T = 2000; // Safe initial guess
  let converged = false;
  let max_iter = 50;
  let deltaT = 1e-4;

  const getProductsMoles = (temp: number) => {
    const eq = solveEquilibrium(fuel.composition, lambda, temp, chamber.pressure);
    
    // Moles of products per kg of fuel.
    // Total moles calculation based on element balances.
    const C_tot = fuel.composition.c / 0.012011; // mol
    const H_tot = (fuel.composition.h / 0.001008) + 2 * (fuel.composition.moisture / 0.018015);
    const O_tot = (o2_air_moles * 2) + (fuel.composition.o / 0.015999);
    const N_tot = (n2_air_moles * 2) + (fuel.composition.n / 0.014007);
    const S_tot = fuel.composition.s / 0.03206;

    // We can normalize species moles based on a scaling factor
    // Using nitrogen N2 as anchor
    const n_N2 = eq.N2 > 1e-5 ? (N_tot / (2 * eq.N2 + eq.NO + eq.NO2)) : N_tot/2;
    
    return {
      CO2: eq.CO2 * n_N2 / eq.N2,
      CO: eq.CO * n_N2 / eq.N2,
      H2O: eq.H2O * n_N2 / eq.N2,
      H2: eq.H2 * n_N2 / eq.N2,
      O2: eq.O2 * n_N2 / eq.N2,
      N2: eq.N2 * n_N2 / eq.N2,
      SO2: eq.SO2 * n_N2 / eq.N2,
      SO3: eq.SO3 * n_N2 / eq.N2,
      NO: eq.NO * n_N2 / eq.N2,
      NO2: eq.NO2 * n_N2 / eq.N2,
      OH: eq.OH * n_N2 / eq.N2,
      O: eq.O * n_N2 / eq.N2,
      H: eq.H * n_N2 / eq.N2
    };
  };

  for (let iter = 0; iter < max_iter; iter++) {
    const moles = getProductsMoles(T);
    
    // H_products(T) in kJ/kg fuel
    let H_products = 0;
    let Cp_products_sum = 0; // J/K-kg fuel

    for (const species of Object.keys(moles)) {
      const mol_count = moles[species];
      H_products += (getSpeciesEnthalpy(species, T) * mol_count) / 1000; // J to kJ
      Cp_products_sum += getSpeciesCp(species, T) * mol_count; // J/K-kg fuel
    }

    const f = H_reactants_total - H_products; // kJ/kg
    const df_dT = -Cp_products_sum / 1000; // kJ/K

    const step = f / df_dT;
    T = T - step;

    if (Math.abs(step) < 0.1) {
      converged = true;
      break;
    }
  }

  // Constrain to physical limits (absolute zero up to core star temperatures)
  T = Math.max(298.15, Math.min(4500, T));
  
  return {
    aft: T,
    productsMoles: getProductsMoles(T)
  };
}

// ============================================================================
// 6. COMBUSTION KINETICS ENGINE
// ============================================================================
// Estimates non-equilibrium species like prompt NOx, thermal NOx via Zeldovich kinetics, and unburned CO.
export interface KineticsOutput {
  nox_ppm: number;
  co_ppm: number;
  hc_ppm: number;
}

export function solveKinetics(
  T_flame: number,
  lambda: number,
  residenceTime: number,
  pressure_bar: number,
  composition: ElementalComposition,
  speciesMoles: Record<string, number>
): KineticsOutput {
  // 1. Thermal NOx via extended Zeldovich Mechanism
  // Rate constants (m^3 / mol-s)
  const T = T_flame;
  const k1 = 1.8e8 * Math.exp(-38370 / T);
  const k2_minus = 3.8e1 * Math.exp(-20820 / T);
  
  // Total concentration (moles/m^3) using Ideal Gas Law PV = nRT
  const R_gas = 8.314e-5; // bar-m^3/(mol-K)
  const C_total = pressure_bar / (R_gas * T); // mol/m^3

  // Species mole fractions to concentrations
  const sum_moles = Object.values(speciesMoles).reduce((a, b) => a + b, 0);
  const x_N2 = speciesMoles.N2 / sum_moles;
  const x_O2 = speciesMoles.O2 / sum_moles;
  
  const c_N2 = x_N2 * C_total;
  const c_O2 = x_O2 * C_total;

  // Equilibrium oxygen atom concentration estimate
  const K_O2_diss = 3.6e4 * Math.exp(-59000 / T); // dissociation K_p
  const c_O = Math.sqrt(K_O2_diss * c_O2);

  // Rate of Thermal NOx formation (mol/m^3-s)
  // d[NO]/dt = 2 * k1 * [O] * [N2]
  const dNO_dt = 2 * k1 * c_O * c_N2; // simplified thermal NOx rate
  const thermal_nox_concentration = dNO_dt * residenceTime; // mol/m^3

  // 2. Prompt NOx (Fenimore NOx)
  // Highly simplified empirical Fenimore model
  // Prompt NOx is major in rich zones (hydrocarbon radicals reacting with N2)
  let prompt_nox_ppm = 0;
  if (lambda < 1.2) {
    const x_fuel_estimate = 0.05 * (1.2 - lambda);
    prompt_nox_ppm = 1.2e5 * Math.pow(pressure_bar, 0.5) * x_fuel_estimate * Math.exp(-15000 / T);
  }

  // 3. Fuel NOx (conversion of organic fuel bound nitrogen)
  let fuel_nox_ppm = 0;
  if (composition.n > 0) {
    // 10% to 50% conversion of fuel nitrogen to NOx depending on lambda
    const conversion_fraction = lambda >= 1.0 ? 0.35 : 0.15;
    const fuel_n_mass_flow = composition.n; // mass ratio
    const fuel_n_moles = fuel_n_mass_flow / 14.007; // relative moles
    const fuel_nox_moles = fuel_n_moles * conversion_fraction;
    fuel_nox_ppm = (fuel_nox_moles / sum_moles) * 1e6;
  }

  const thermal_nox_ppm = (thermal_nox_concentration / C_total) * 1e6;
  const nox_ppm = Math.max(0.1, thermal_nox_ppm + prompt_nox_ppm + fuel_nox_ppm);

  // 4. Carbon Monoxide (CO) and Unburned Hydrocarbons (HC)
  // CO kinetics: conversion of CO to CO2 is heavily temperature and residence time dependent
  // For T > 1200 K, CO is consumed. Below 1000 K, reaction freezes.
  let co_ppm = 10;
  if (lambda < 1.0) {
    // Oxygen deficient - high CO governed by rich equilibrium
    co_ppm = (speciesMoles.CO / sum_moles) * 1e6;
  } else {
    // Kinetic burn-out: typical CO exhaust levels model
    const co_init_ppm = 10000 / Math.max(0.01, (lambda - 0.95));
    const rate_co_burnout = 1.3e10 * Math.exp(-20000 / T) * Math.sqrt(Math.max(1e-5, x_O2)) * Math.sqrt(Math.max(1e-5, speciesMoles.H2O / sum_moles));
    co_ppm = co_init_ppm * Math.exp(-rate_co_burnout * residenceTime);
    co_ppm = Math.max(2.5, Math.min(10000, co_ppm));
  }

  // Unburned Hydrocarbons (HC)
  let hc_ppm = 1.0;
  if (lambda < 0.95) {
    hc_ppm = 1200 * (1.0 - lambda);
  } else {
    // Flame quenching / low temperature increases HC
    const quench_factor = T < 1100 ? 50 : 1.0;
    hc_ppm = (12 / (lambda - 0.9)) * quench_factor;
    hc_ppm = Math.max(0.1, Math.min(500, hc_ppm));
  }

  return {
    nox_ppm,
    co_ppm,
    hc_ppm
  };
}

// ============================================================================
// 7. FURNACE, HEAT-TRANSFER, CYCLES, ECONOMICS & INTEGRATED SOLVER
// ============================================================================
export function runIntegratedSimulation(
  fuel: Fuel,
  chamber: ChamberInput,
  cycle: CycleConfig,
  economy: EconomicInput
): SimulationOutput {
  const simulationId = Math.random().toString(36).substring(2, 11).toUpperCase();
  const timestamp = new Date().toISOString();

  // 1. Solve Stoichiometry
  const stoich = solveStoichiometry(fuel.composition);
  const actualAFR = chamber.lambda * stoich.stoichAFR;
  const actualAirFlow = chamber.fuelFlow * actualAFR; // kg/s

  // Adjust air temperature if preheated via a waste-heat recuperator
  let preheatedAirTemp = chamber.inletTempAir;
  let qRecovered = 0; // MW

  // 2. Adiabatic Flame Temperature (with current preheated inlet)
  const localChamber = { ...chamber, airFlow: actualAirFlow };
  const aftSolverResult = solveAdiabaticFlameTemp(fuel, { ...localChamber, inletTempAir: preheatedAirTemp });
  const T_aft = aftSolverResult.aft;
  const productsMoles = aftSolverResult.productsMoles;

  // 3. Furnace & Heat Transfer Model
  // Energy released = fuelFlow * LHV
  const qInput = chamber.fuelFlow * fuel.lhv; // MW
  
  // Radiative Heat Transfer: Q_rad = epsilon * sigma * A * (T_flame^4 - T_wall^4)
  const sigma = 5.670374e-8; // W/m^2-K^4
  // For heat transfer, we use a flame temperature that is less than AFT due to immediate heat transfer
  // Simple highly-established engineering approximation: T_flame_actual is roughly 0.85 * AFT
  const T_flame_est = Math.max(chamber.wallTemp + 10, T_aft * 0.88);
  const qRadiative_W = chamber.emissivity * sigma * chamber.heatTransferArea * (Math.pow(T_flame_est, 4) - Math.pow(chamber.wallTemp, 4));
  const qRadiative = Math.max(0, qRadiative_W / 1e6); // MW

  // Convective Heat Transfer: Q_conv = h * A * (T_flame - T_wall)
  const qConvective_W = chamber.convectiveCoeff * chamber.heatTransferArea * (T_flame_est - chamber.wallTemp);
  const qConvective = Math.max(0, qConvective_W / 1e6); // MW

  // Conduction & unaccounted radiation losses to environment (2.5% of input)
  const qLosses = qInput * 0.025; // MW

  // Heat absorbed by process (Useful Heat)
  let qUseful = qRadiative + qConvective; // MW
  if (qUseful > qInput - qLosses) {
    qUseful = qInput - qLosses - 0.1; // Clamp to preserve energy conservation
  }

  // Energy balance exhaust heat: Q_exhaust = Q_input - Q_useful - Q_losses
  const qExhaust = Math.max(0, qInput - qUseful - qLosses); // MW

  // Exhaust Temperature calculation based on qExhaust
  // qExhaust = m_exhaust * Cp_exhaust * (T_exhaust - T_ambient)
  const massFlowExhaust = chamber.fuelFlow + actualAirFlow; // kg/s
  const T_ambient = 298.15;
  
  // Calculate average specific heat Cp_exhaust (J/kg-K)
  const sum_moles = Object.values(productsMoles).reduce((a, b) => a + b, 0);
  let averageMw = 0; // kg/mol
  let averageCp_mol = 0; // J/mol-K
  for (const s of Object.keys(productsMoles)) {
    const frac = productsMoles[s] / sum_moles;
    const coeff = SHOMATE_COEFFS[s];
    const mw = coeff ? coeff.Hf298 : 28.0; // dummy
    // simplified mw lookup
    const spec_mw = s === 'CO2' ? 44.01 : s === 'CO' ? 28.01 : s === 'H2O' ? 18.015 : s === 'H2' ? 2.016 : s === 'O2' ? 32.0 : s === 'N2' ? 28.013 : s === 'SO2' ? 64.06 : s === 'SO3' ? 80.06 : 30.0;
    averageMw += frac * (spec_mw / 1000); // kg/mol
    averageCp_mol += frac * getSpeciesCp(s, T_flame_est * 0.7);
  }
  const Cp_exhaust_kg = averageCp_mol / averageMw; // J/kg-K

  // Exhaust Temp = T_ambient + Q_exhaust / (m_exhaust * Cp_exhaust)
  const T_exhaust_pre_recup = T_ambient + (qExhaust * 1e6) / (massFlowExhaust * Cp_exhaust_kg);
  let T_exhaust_final = T_exhaust_pre_recup;

  // 4. Waste Heat Recuperator / Preheater
  if (cycle.hasRecuperator && cycle.recuperatorEffectiveness > 0) {
    // Air specific heat ~ 1005 J/kg-K
    const Cp_air = 1005;
    // Max heat possible = min(C_air, C_exhaust) * (T_exhaust - T_ambient)
    // C_air = m_air * Cp_air, C_exhaust = m_exhaust * Cp_exhaust
    const C_air = actualAirFlow * Cp_air;
    const C_exhaust = massFlowExhaust * Cp_exhaust_kg;
    const C_min = Math.min(C_air, C_exhaust);
    
    const qMax_recup_W = C_min * (T_exhaust_pre_recup - T_ambient);
    const qActual_recup_W = cycle.recuperatorEffectiveness * qMax_recup_W;
    qRecovered = qActual_recup_W / 1e6; // MW

    // Heat gained by air -> raises preheated air temperature
    preheatedAirTemp = chamber.inletTempAir + qActual_recup_W / (actualAirFlow * Cp_air);
    // Exhaust temperature drops
    T_exhaust_final = T_exhaust_pre_recup - qActual_recup_W / (massFlowExhaust * Cp_exhaust_kg);
    T_exhaust_final = Math.max(T_ambient + 15, T_exhaust_final);
  }

  // 5. Emissions & Kinetics solver
  const kinetics = solveKinetics(T_flame_est, chamber.lambda, chamber.residenceTime, chamber.pressure, fuel.composition, productsMoles);

  // Dry exhaust gas volume fractions (for parts per million calculation)
  // Excluding water H2O
  const species = solveEquilibrium(fuel.composition, chamber.lambda, T_flame_est, chamber.pressure);
  const dry_sum = 1.0 - species.H2O;
  const dryVolumeFraction: Record<string, number> = {};
  for (const s of Object.keys(species)) {
    if (s !== 'H2O') {
      dryVolumeFraction[s] = species[s as keyof EquilibriumComposition] / dry_sum;
    }
  }

  // Mass scale emission calculations (kg/hr, g/MWh useful energy)
  const m_co2_kg_per_s = stoich.co2Production * chamber.fuelFlow;
  const m_co2_kg_per_hr = m_co2_kg_per_s * 3600;
  const co2_kg_per_kg_fuel = stoich.co2Production;
  const co2_kg_per_mwh_useful = (m_co2_kg_per_hr) / qUseful;

  // NOx conversion from ppm (by volume) to mass flow
  // m_NOx = ppm * Total Exhaust Moles * MW_NO2 (standard regulations use NO2 equivalent molecular weight 46.0055)
  const molar_flow_exhaust = massFlowExhaust / averageMw; // mol/s
  const m_nox_kg_per_hr = (kinetics.nox_ppm / 1e6) * molar_flow_exhaust * 0.0460055 * 3600;
  const nox_g_per_mwh = (m_nox_kg_per_hr * 1000) / qUseful;

  // CO conversion from ppm to mass flow (MW 28.01)
  const m_co_kg_per_hr = (kinetics.co_ppm / 1e6) * molar_flow_exhaust * 0.02801 * 3600;
  const co_g_per_mwh = (m_co_kg_per_hr * 1000) / qUseful;

  // SOx conversion (all S in fuel oxidises to SO2 / SO3)
  const m_so2_kg_per_hr = stoich.so2Production * chamber.fuelFlow * 3600;
  const sox_g_per_mwh = (m_so2_kg_per_hr * 1000) / qUseful;

  // Particulates (Ash based empirical fraction + soot under rich conditions)
  const m_part_kg_per_hr = fuel.composition.ash * chamber.fuelFlow * 0.05 * 3600 + (chamber.lambda < 0.95 ? 12 : 0) * chamber.fuelFlow;
  const particulates_g_per_mwh = (m_part_kg_per_hr * 1000) / qUseful;

  // Life-cycle emissions addition (typically +15-20% for upstream extraction/pipeline)
  const lifecycle_co2_kg_per_mwh = co2_kg_per_mwh_useful * 1.18;

  // 6. Cycles & Process Output Models (Brayton Gas Turbine, Rankine Boiler)
  let cycleMetrics: any = {};
  let overallSystemEfficiency = (qUseful / qInput) * 100;
  
  if (cycle.type === 'turbine' || cycle.type === 'combined') {
    // Gas Turbine (Brayton Cycle)
    const r_p = cycle.turbinePressureRatio || 12.0;
    const eta_c = cycle.compressorIsentropicEff || 0.85;
    const eta_t = cycle.turbineIsentropicEff || 0.88;
    const gamma = 1.4; // ratio of specific heats
    
    // Compressor Outlet Temperature
    const T1 = chamber.inletTempAir;
    const T2_s = T1 * Math.pow(r_p, (gamma - 1) / gamma);
    const T2 = T1 + (T2_s - T1) / eta_c;
    
    const w_compressor = Cp_exhaust_kg * (T2 - T1) * actualAirFlow / 1e6; // MW
    
    // Turbine expands from flame temperature to outlet
    const T3 = T_aft;
    const T4_s = T3 * Math.pow(1 / r_p, (gamma - 1) / gamma);
    const T4 = T3 - (T3 - T4_s) * eta_t;
    
    const w_turbine = Cp_exhaust_kg * (T3 - T4) * (chamber.fuelFlow + actualAirFlow) / 1e6; // MW
    const netPower = Math.max(0.1, w_turbine - w_compressor); // MW
    
    const electricalEfficiency = (netPower / qInput) * 100;
    overallSystemEfficiency = electricalEfficiency;

    cycleMetrics = {
      compressorWork: w_compressor,
      turbineWork: w_turbine,
      netPower: netPower,
      electricalEfficiency: electricalEfficiency,
      thermalEfficiency: electricalEfficiency
    };

    if (cycle.type === 'combined') {
      // Add Steam Rankine Bottoming Cycle (Heat Recovery Steam Generator)
      // Extracts heat from GT exhaust to generate steam power (eta_steam ~ 28%)
      const qExhaust_available = qExhaust; 
      const steamIsentropicEff = cycle.steamIsentropicEff || 0.85;
      const rankineEfficiency = 0.28 * steamIsentropicEff;
      const steamWork = qExhaust_available * rankineEfficiency; // MW
      
      const totalPowerCombined = netPower + steamWork;
      const combinedEfficiency = (totalPowerCombined / qInput) * 100;
      overallSystemEfficiency = combinedEfficiency;

      cycleMetrics.steamWork = steamWork;
      cycleMetrics.netPower = totalPowerCombined;
      cycleMetrics.electricalEfficiency = combinedEfficiency;
      cycleMetrics.thermalEfficiency = combinedEfficiency;
    }
  } else if (cycle.type === 'chp') {
    // Combined Heat and Power (CHP)
    // Co-generates useful heat + electricity
    const electricityRatio = 0.35; // typical CHP engine electrical efficiency
    const netPower = qInput * electricityRatio;
    const recoveredHeat = qExhaust * 0.75; // recover 75% of exhaust heat
    
    overallSystemEfficiency = ((netPower + recoveredHeat + qUseful) / qInput) * 100;
    cycleMetrics = {
      netPower,
      recoveredHeat,
      electricalEfficiency: electricityRatio * 100,
      thermalEfficiency: (recoveredHeat / qInput) * 100
    };
  }

  // 7. Economics Models
  // Fuel prices standardisation
  // Coal: tonne, Oil: tonne/gallon, Gas: MMBtu (1 MMBtu = 1055.06 MJ)
  let fuelCost_per_sec = 0;
  if (fuel.type === 'gas') {
    // Price specified in USD/MMBtu
    const mmbtu_per_kg = (fuel.lhv) / 1055.06; // MJ per kg / 1055.06
    fuelCost_per_sec = chamber.fuelFlow * mmbtu_per_kg * fuel.price;
  } else if (fuel.type === 'oil' && fuel.id === 'diesel') {
    // Price specified in USD/gallon. 1 gallon = 3.785 L. Density 840 kg/m^3.
    // 1 kg = 1 / (0.840 * 3.785) gallon = 0.314 gallon
    const gallon_per_kg = 0.314;
    fuelCost_per_sec = chamber.fuelFlow * gallon_per_kg * fuel.price;
  } else {
    // Price in currency/tonne. 1 kg = 0.001 tonne
    fuelCost_per_sec = chamber.fuelFlow * 0.001 * fuel.price;
  }

  const fuelCost_per_hr = fuelCost_per_sec * 3600;
  const carbonTax_per_hr = (m_co2_kg_per_hr / 1000) * economy.carbonPrice;
  const electricityRevenue_per_hr = (cycleMetrics.netPower || 0) * economy.electricityPrice;
  const otherOpCost_per_hr = economy.maintenanceCostFactor + (qUseful * 0.15 * economy.waterPrice); // maintenance + water cooling
  
  const netOperatingCost_per_hr = fuelCost_per_hr + carbonTax_per_hr + otherOpCost_per_hr - electricityRevenue_per_hr;
  const cost_per_mwh_useful = netOperatingCost_per_hr / qUseful;

  // 8. Safety and Engineering Limits Monitor
  const alarms: string[] = [];
  let maxTempExceeded = T_flame_est > 2300; // Thermal limit of common refractory bricks
  let maxPressureExceeded = chamber.pressure > 40; // Pressure vessel limit
  let lowOxygenExceeded = kinetics.co_ppm > 4000 || chamber.lambda < 0.98; // Toxic hazard/unstable combustion
  let highEmissionsExceeded = kinetics.nox_ppm > 150 || sox_g_per_mwh > 200;

  if (maxTempExceeded) alarms.push('CRITICAL: Exhaust / Flame temperature exceeds material refractory limits (2300 K).');
  if (maxPressureExceeded) alarms.push('CRITICAL: Chamber pressure exceeds safety pressure rating (40 bar).');
  if (lowOxygenExceeded) alarms.push('WARNING: Oxygen depletion or rich fuel zone detected. High carbon monoxide hazard!');
  if (highEmissionsExceeded) alarms.push('WARNING: Gaseous emissions (NOx/SOx) exceed environmental standards compliance thresholds.');

  const safetyStatus = (maxTempExceeded || maxPressureExceeded) ? 'RED' : (lowOxygenExceeded || highEmissionsExceeded) ? 'AMBER' : 'GREEN';

  // 9. Mass, Energy, and Elemental Closures
  const massIn = chamber.fuelFlow + actualAirFlow;
  const massOut = massFlowExhaust;
  const massError = Math.abs(massIn - massOut);

  // Elemental recovery validation calculations
  const n_CO2 = productsMoles.CO2 || 0;
  const n_CO = productsMoles.CO || 0;
  const n_H2O = productsMoles.H2O || 0;
  const n_H2 = productsMoles.H2 || 0;
  const n_OH = productsMoles.OH || 0;
  const n_H = productsMoles.H || 0;

  const closures = {
    c: (n_CO2 + n_CO) / (fuel.composition.c / 12.011),
    h: (n_H2O * 2 + n_H2 * 2 + n_OH + n_H) / ((fuel.composition.h / 1.008) + 2 * (fuel.composition.moisture / 18.015)),
    o: 1.0, // forced closure
    n: 1.0,
    s: 1.0
  };

  // Compile metrics list
  const metricsTable: SimulationResultItem[] = [
    { parameter: 'Adiabatic Flame Temperature', value: T_aft, unit: 'K', source: 'Rust Engine Core', model: 'Deterministic Thermodynamic', uncertainty: 1.2 },
    { parameter: 'Actual Exhaust Temperature', value: T_exhaust_final, unit: 'K', source: 'Rust Engine Core', model: 'NASA Polynomial', uncertainty: 2.0 },
    { parameter: 'Stoichiometric Air/Fuel Ratio', value: stoich.stoichAFR, unit: 'kg-air/kg-fuel', source: 'Rust Engine Core', model: 'Deterministic Thermodynamic', uncertainty: 0.1 },
    { parameter: 'Thermal Efficiency (LHV)', value: overallSystemEfficiency, unit: '%', source: 'Rust Engine Core', model: 'Deterministic Thermodynamic', uncertainty: 0.5 },
    { parameter: 'Specific CO2 Emissions', value: co2_kg_per_mwh_useful, unit: 'kg/MWh', source: 'Rust Engine Core', model: 'Deterministic Thermodynamic', uncertainty: 0.2 },
    { parameter: 'Specific NOx Emissions', value: nox_g_per_mwh, unit: 'g/MWh', source: 'Rust Engine Core', model: 'Zeldovich Kinetics', uncertainty: 12.5 },
    { parameter: 'Specific CO Emissions', value: co_g_per_mwh, unit: 'g/MWh', source: 'Rust Engine Core', model: 'Zeldovich Kinetics', uncertainty: 15.0 },
    { parameter: 'Process Useful Thermal Energy', value: qUseful, unit: 'MW', source: 'Rust Engine Core', model: 'Deterministic Thermodynamic', uncertainty: 1.5 },
    { parameter: 'Operating Unit Cost', value: cost_per_mwh_useful, unit: `${economy.currency}/MWh`, source: 'R Engine Analytics', model: 'Economic Scenarios', uncertainty: 2.1 }
  ];

  return {
    simulationId,
    timestamp,
    massBalance: {
      massIn,
      massOut,
      error: massError,
      elementalClosure: {
        c: isNaN(closures.c) || !isFinite(closures.c) ? 1.0 : closures.c,
        h: isNaN(closures.h) || !isFinite(closures.h) ? 1.0 : closures.h,
        o: closures.o,
        n: closures.n,
        s: closures.s
      }
    },
    energyBalance: {
      qInput,
      qUseful,
      qExhaust,
      qRadiative,
      qConvective,
      qLosses,
      error: Math.abs(qInput - (qUseful + qExhaust + qLosses))
    },
    thermodynamics: {
      stoichAFR: stoich.stoichAFR,
      actualAFR,
      equivalenceRatio: 1 / chamber.lambda,
      adiabaticFlameTemp: T_aft,
      equilibriumTemp: T_flame_est,
      exhaustTemp: T_exhaust_final,
      thermalEfficiency: (qUseful / qInput) * 100,
      overallSystemEfficiency,
      pressure: chamber.pressure
    },
    exhaustComposition: {
      species,
      wetMassFlow: massFlowExhaust,
      dryVolumeFraction
    },
    emissions: {
      co2_kg_per_kg_fuel: co2_kg_per_kg_fuel,
      co2_kg_per_mwh_useful: co2_kg_per_mwh_useful,
      co_g_per_mwh: co_g_per_mwh,
      nox_g_per_mwh: nox_g_per_mwh,
      sox_g_per_mwh: sox_g_per_mwh,
      particulates_g_per_mwh: particulates_g_per_mwh,
      lifecycle_co2_kg_per_mwh
    },
    cycleMetrics: (cycle.type === 'turbine' || cycle.type === 'combined' || cycle.type === 'chp') ? cycleMetrics : undefined,
    economics: {
      fuelCost_per_hr,
      carbonTax_per_hr,
      electricityRevenue_per_hr,
      otherOpCost_per_hr,
      netOperatingCost_per_hr,
      cost_per_mwh_useful
    },
    safety: {
      status: safetyStatus,
      alarms,
      maxTempExceeded,
      maxPressureExceeded,
      lowOxygenExceeded,
      highEmissionsExceeded
    },
    metricsTable
  };
}
