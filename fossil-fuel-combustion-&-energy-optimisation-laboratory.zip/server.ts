/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

import { FUEL_DATABASE, runIntegratedSimulation } from './server/combustionEngine';
import { runMonteCarloSimulation, calculateSensitivity, calculateParetoFrontier, calculateOptimizationLandscape } from './server/analyticsEngine';

// Load environment variables
dotenv.config();

// Initialize Express
const app = express();
app.use(express.json({ limit: '10mb' }));

const PORT = 3000;

// ============================================================================
// 1. COMPLIANT GOOGLE GENAI UTILITY INITIALIZATION
// ============================================================================
let ai: GoogleGenAI | null = null;
const apiKey = process.env.GEMINI_API_KEY;

if (apiKey) {
  try {
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
    console.log('Google GenAI SDK initialised successfully on server.');
  } catch (err) {
    console.error('Error initialising Google GenAI SDK:', err);
  }
} else {
  console.warn('GEMINI_API_KEY environment variable is not defined. AI features will run in sandbox mode.');
}

// ============================================================================
// 2. REST API ROUTING
// ============================================================================

// GET all fuel presets
app.get('/api/fuels', (req, res) => {
  res.json({ status: 'ok', fuels: FUEL_DATABASE });
});

// POST Integrated Combustion Simulation Run
app.post('/api/simulate', (req, res) => {
  try {
    const { fuel, chamber, cycle, economy } = req.body;
    if (!fuel || !chamber || !cycle || !economy) {
      res.status(400).json({ error: 'Missing configuration profiles.' });
      return;
    }
    const result = runIntegratedSimulation(fuel, chamber, cycle, economy);
    res.json({ status: 'ok', data: result });
  } catch (err: any) {
    console.error('Simulation Solver Error:', err);
    res.status(500).json({ error: err.message || 'Simulation execution failed.' });
  }
});

// POST High-Performance Stochastic Monte Carlo Simulation
app.post('/api/monte-carlo', (req, res) => {
  try {
    const { fuel, chamber, cycle, economy, trialsCount } = req.body;
    if (!fuel || !chamber || !cycle || !economy) {
      res.status(400).json({ error: 'Missing configuration profiles.' });
      return;
    }
    const trials = Math.min(25000, Math.max(100, trialsCount || 5000));
    const result = runMonteCarloSimulation(fuel, chamber, cycle, economy, trials);
    res.json({ status: 'ok', data: result });
  } catch (err: any) {
    console.error('Monte Carlo Engine Error:', err);
    res.status(500).json({ error: err.message || 'Monte Carlo execution failed.' });
  }
});

// POST Sensitivity Analysis Tornado Calculations
app.post('/api/sensitivity', (req, res) => {
  try {
    const { fuel, chamber, cycle, economy } = req.body;
    const result = calculateSensitivity(fuel, chamber, cycle, economy);
    res.json({ status: 'ok', data: result });
  } catch (err: any) {
    console.error('Sensitivity Engine Error:', err);
    res.status(500).json({ error: err.message || 'Sensitivity calculations failed.' });
  }
});

// POST Multi-Objective Optimization / Pareto Frontier
app.post('/api/pareto', (req, res) => {
  try {
    const { chamber, cycle, economy } = req.body;
    const result = calculateParetoFrontier(chamber, cycle, economy);
    res.json({ status: 'ok', data: result });
  } catch (err: any) {
    console.error('Pareto Frontier Engine Error:', err);
    res.status(500).json({ error: err.message || 'Pareto calculations failed.' });
  }
});

// POST 2D Optimization Grid Landscape
app.post('/api/landscape', (req, res) => {
  try {
    const { fuel, chamber, cycle, economy } = req.body;
    const result = calculateOptimizationLandscape(fuel, chamber, cycle, economy);
    res.json({ status: 'ok', data: result });
  } catch (err: any) {
    console.error('Optimization Landscape Sweep Error:', err);
    res.status(500).json({ error: err.message || 'Landscape sweep failed.' });
  }
});

// POST Gemini AI Combustion Diagnostics and Optimization Advisory
app.post('/api/gemini/analyze', async (req, res) => {
  try {
    const { data } = req.body; // Represents the active SimulationOutput
    if (!data) {
      res.status(400).json({ error: 'Missing active simulation dataset.' });
      return;
    }

    if (!ai) {
      // Return a simulated, high-quality, pre-compiled static combustion expert response if no API key is set
      res.json({
        status: 'sandbox',
        advice: `### Combustion Laboratory Diagnostic Analysis (Sandbox Mode)
Your current system operates with **Excess Air Ratio (\\lambda = ${data.thermodynamics.actualAFR / data.thermodynamics.stoichAFR})**. 
- **Thermal Efficiency**: **${data.thermodynamics.overallSystemEfficiency.toFixed(2)}%** is within normal industrial parameters. 
- **Flame Temperature**: **${Math.round(data.thermodynamics.equilibriumTemp)} K** is well-controlled.
- **Flue Gas Emissions**: Specific NOx is **${Math.round(data.emissions.nox_g_per_mwh)} g/MWh**, while CO2 intensity is **${Math.round(data.emissions.co2_kg_per_mwh_useful)} kg/MWh**.

#### Engineering Recommendations:
1. **Heat Loss Diagnosis**: Your stack temperature is **${Math.round(data.thermodynamics.exhaustTemp)} K**. Recovering heat by increasing recuperator effectiveness can yield a **1.5 - 3.2%** increase in thermodynamic efficiency, translating directly to fuel savings.
2. **Excess Air Tuning**: The current air/fuel mixture provides adequate oxygen, but excess nitrogen dilutes the heat zone, carrying sensible heat straight up the stack. Try reducing the Excess Air Ratio (\\lambda) closer to **1.05 - 1.15** to reduce stack sensible heat loss, provided your CO levels remain within safety compliance limits (<50 ppm).`
      });
      return;
    }

    const prompt = `You are a world-class combustion scientist, thermodynamicist, and process engineer.
Review the following active fossil-fuel combustion simulation results and write a rigorous, expert-level laboratory diagnostic report.

--- ACTIVE SIMULATION DATASET ---
Fuel Name: ${data.metricsTable[8]?.value > 0 ? "Configured Custom Fuel / Blend" : "Standard Preset Fuel"}
Adiabatic Flame Temp: ${Math.round(data.thermodynamics.adiabaticFlameTemp)} K
Exhaust Gas Temp: ${Math.round(data.thermodynamics.exhaustTemp)} K
Equilibrium Temperature: ${Math.round(data.thermodynamics.equilibriumTemp)} K
Air/Fuel Stoichiometric AFR: ${data.thermodynamics.stoichAFR.toFixed(3)} kg-air/kg-fuel
Actual Air/Fuel Ratio: ${data.thermodynamics.actualAFR.toFixed(3)} kg-air/kg-fuel
Overall System Efficiency: ${data.thermodynamics.overallSystemEfficiency.toFixed(2)} %
CO2 Emissions Intensity: ${data.emissions.co2_kg_per_mwh_useful.toFixed(1)} kg CO2 / MWh useful energy
NOx Emissions Intensity: ${data.emissions.nox_g_per_mwh.toFixed(1)} g / MWh
CO Emissions Intensity: ${data.emissions.co_g_per_mwh.toFixed(1)} g / MWh
SOx Emissions Intensity: ${data.emissions.sox_g_per_mwh.toFixed(1)} g / MWh
Safety Alarms: ${JSON.stringify(data.safety.alarms)}

Please provide a structured response containing:
1. **Thermodynamic Analysis**: Evaluate the adiabatic flame temperature, stack temperatures, and overall energy conversion efficiency. Identify where energy is lost (Sensible Heat in Flue Gas, Wall Heat Loss, etc.).
2. **Emissions and Chemistry Diagnosis**: Evaluate the emissions profile. Explain the chemical kinetics behind the NOx formation (thermal vs. fuel NOx) and the concentration of carbon monoxide/unburned hydrocarbons in relation to the current equivalence ratio.
3. **Engineering Optimization Actions**: Suggest concrete, actionable adjustments to Excess Air (lambda), Air Preheat Temperature, or Residence Time. Show how these adjustments will optimize the trade-off between thermal efficiency and NOx/CO emission thresholds.

Respond in clean, highly structured Markdown, omitting flowery intros. Use professional engineering terminology.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
      config: {
        systemInstruction: 'You are an elite, professional engineering research bot operating inside an advanced digital combustion laboratory.',
      }
    });

    res.json({ status: 'ok', advice: response.text });
  } catch (err: any) {
    console.error('Gemini AI Service Error:', err);
    res.status(500).json({ error: err.message || 'Failed to communicate with Gemini AI.' });
  }
});

// ============================================================================
// 3. VITE MIDDLEWARE SETUP AND STATIC ASSET SERVING
// ============================================================================
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
    console.log('Vite development server middleware mounted.');
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
    console.log('Production static file serving mounted.');
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Fossil Fuel Combustion Laboratory Server listening on http://localhost:${PORT}`);
  });
}

startServer();
