/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Fuel, ElementalComposition, ChamberInput, CycleConfig, SimulationOutput, EquilibriumComposition, SimulationResultItem } from '../types';

// Standard Shomate Coefficients for client-side sweeps
export const CLIENT_SHOMATE: Record<string, { A: number; B: number; C: number; D: number; E: number; F: number; G: number; Hf298: number }> = {
  CO2:  { A: 24.99735, B: 55.18696,  C: -33.69137, D: 7.948387, E: -0.136638, F: -403.6075, G: 228.2431, Hf298: -393.52 },
  CO:   { A: 25.56759, B: 6.096130,  C: -1.554760, D: 0.104168, E: 0.103714,  F: -118.0089, G: 201.2413, Hf298: -110.53 },
  H2O:  { A: 30.09200, B: 6.832514,  C: 6.793435,  D: -2.534480, E: 0.082139,  F: -250.8810, G: 223.3967, Hf298: -241.83 },
  H2:   { A: 33.06617, B: -11.36341, C: 11.43281,  D: -2.772874, E: -0.158558, F: -9.980797, G: 172.7079, Hf298: 0.0 },
  O2:   { A: 30.03235, B: 8.772912,  C: -3.435283, D: 0.469247,  E: -0.250847, F: -9.696460, G: 188.9431, Hf298: 0.0 },
  N2:   { A: 26.00266, B: 4.315904,  C: -0.701170, D: 0.046162,  E: 0.147079,  F: -7.935900, G: 191.1715, Hf298: 0.0 },
  SO2:  { A: 21.43048, B: 74.35094,  C: -53.51620, D: 13.82421,  E: -0.085805, F: -305.9388, G: 254.8872, Hf298: -296.84 }
};

export function localGetSpeciesEnthalpy(species: string, T: number): number {
  const coeff = CLIENT_SHOMATE[species];
  if (!coeff) return 0;
  const t = T / 1000;
  return coeff.A * t + (coeff.B * t * t) / 2 + (coeff.C * t * t * t) / 3 + (coeff.D * t * t * t * t) / 4 - coeff.E / t + coeff.F;
}

export function localGetSpeciesCp(species: string, T: number): number {
  const coeff = CLIENT_SHOMATE[species];
  if (!coeff) return 29.1;
  const t = T / 1000;
  return coeff.A + coeff.B * t + coeff.C * t * t + coeff.D * t * t * t + coeff.E / (t * t);
}

export function localSolveStoichiometry(composition: ElementalComposition) {
  const { c, h, o, n, s, moisture } = composition;
  const o2_demanded_kmol = (c / 12.011) + (h / 4.032) + (s / 32.06) - (o / 31.998);
  const o2Required_kg = Math.max(0, o2_demanded_kmol) * 31.998;
  const stoichAFR = o2Required_kg / 0.232;

  return {
    stoichAFR,
    co2Production: (c / 12.011) * 44.01,
    h2oProduction: (h / 2.016) * 18.015 + moisture,
    so2Production: (s / 32.06) * 64.06,
    n2Production: (stoichAFR * 0.768) + n
  };
}

export function localSolveEquilibrium(composition: ElementalComposition, lambda: number, T_est: number): EquilibriumComposition {
  const stoich = localSolveStoichiometry(composition);
  const C_tot = composition.c / 12.011;
  const H_tot = (composition.h / 1.008) + 2 * (composition.moisture / 18.015);
  const air_mass = lambda * stoich.stoichAFR;
  
  const O_tot = ((air_mass * 0.232) / 15.999) + (composition.o / 15.999);
  const N_tot = ((air_mass * 0.768) / 14.007) + (composition.n / 14.007);
  const S_tot = composition.s / 32.06;

  let n_CO2 = 0, n_CO = 0, n_H2O = 0, n_H2 = 0, n_O2 = 0, n_N2 = N_tot / 2, n_SO2 = S_tot;

  if (lambda >= 1.0) {
    n_CO2 = C_tot;
    n_H2O = H_tot / 2;
    n_O2 = Math.max(0, (O_tot - (2 * n_CO2 + n_H2O + 2 * n_SO2)) / 2);
  } else {
    const O_reactive = Math.max(0, O_tot - 2 * S_tot);
    const Kw = Math.exp(5068 / T_est - 4.417);
    let best_CO2 = C_tot * 0.5;
    
    for (let iter = 0; iter < 15; iter++) {
      const CO2 = best_CO2;
      const CO = Math.max(1e-8, C_tot - CO2);
      const H2O = Math.max(1e-8, O_reactive - C_tot - CO2);
      const H2 = Math.max(1e-8, (H_tot - 2 * H2O) / 2);
      const F = (CO2 * H2) - Kw * (CO * H2O);
      const dF = H2 + CO2 * 0.5 - Kw * (-H2O - CO);
      best_CO2 = Math.min(C_tot - 1e-6, Math.max(1e-6, best_CO2 - F / dF));
    }
    
    n_CO2 = best_CO2;
    n_CO = C_tot - n_CO2;
    n_H2O = Math.max(0, O_reactive - C_tot - n_CO2);
    n_H2 = Math.max(0, (H_tot - 2 * n_H2O) / 2);
  }

  // Zeldovich thermal NO portion
  let n_NO = 0;
  if (T_est > 1600 && n_N2 > 0 && n_O2 > 0) {
    const K_no = Math.exp(-180500 / (8.314 * T_est) + 2.5);
    n_NO = Math.sqrt(K_no * n_N2 * n_O2) * 2;
  }

  const n_sum = n_CO2 + n_CO + n_H2O + n_H2 + n_O2 + n_N2 + n_SO2 + n_NO;

  return {
    CO2: n_CO2 / n_sum,
    CO: n_CO / n_sum,
    H2O: n_H2O / n_sum,
    H2: n_H2 / n_sum,
    O2: n_O2 / n_sum,
    N2: n_N2 / n_sum,
    OH: 0, O: 0, H: 0,
    NO: n_NO / n_sum,
    NO2: 0,
    SO2: n_SO2 / n_sum,
    SO3: 0
  };
}

export function localSolveFlameTemp(fuel: Fuel, lambda: number): number {
  const stoich = localSolveStoichiometry(fuel.composition);
  const air_mass = lambda * stoich.stoichAFR;
  const o2_air_moles = (air_mass * 0.232) / 0.031998;
  const n2_air_moles = (air_mass * 0.768) / 0.028013;
  
  const h_air = (localGetSpeciesEnthalpy('O2', 298.15) * o2_air_moles) + (localGetSpeciesEnthalpy('N2', 298.15) * n2_air_moles);
  const n_co2_stoich = (fuel.composition.c / 12.011) * 1000;
  const n_h2o_stoich = ((fuel.composition.h / 2.016) * 1000) + (fuel.composition.moisture / 0.018015);
  const n_so2_stoich = (fuel.composition.s / 32.06) * 1000;
  
  const h_products_298 = (n_co2_stoich * -393.52) + (n_h2o_stoich * -241.83) + (n_so2_stoich * -296.84);
  const h_fuel = (fuel.lhv * 1000) + h_products_298;
  const H_reactants = h_air + h_fuel;

  let T = 2000;
  for (let iter = 0; iter < 12; iter++) {
    const eq = localSolveEquilibrium(fuel.composition, lambda, T);
    const C_tot = fuel.composition.c / 0.012011;
    const n_N2 = eq.N2 > 1e-5 ? ((n2_air_moles * 2) / (2 * eq.N2 + eq.NO)) : n2_air_moles;
    
    const moles = {
      CO2: eq.CO2 * n_N2 / eq.N2,
      CO: eq.CO * n_N2 / eq.N2,
      H2O: eq.H2O * n_N2 / eq.N2,
      H2: eq.H2 * n_N2 / eq.N2,
      O2: eq.O2 * n_N2 / eq.N2,
      N2: eq.N2 * n_N2 / eq.N2,
      SO2: eq.SO2 * n_N2 / eq.N2,
      NO: eq.NO * n_N2 / eq.N2
    };

    let H_products = 0;
    let Cp_sum = 0;
    for (const species of Object.keys(moles)) {
      const count = moles[species as keyof typeof moles];
      H_products += (localGetSpeciesEnthalpy(species, T) * count) / 1000;
      Cp_sum += localGetSpeciesCp(species, T) * count;
    }

    const step = (H_reactants - H_products) / (-Cp_sum / 1000);
    T -= step;
    if (Math.abs(step) < 0.2) break;
  }

  return Math.max(298.15, Math.min(3800, T));
}
