/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ElementalComposition {
  c: number; // Carbon weight fraction (0-1)
  h: number; // Hydrogen weight fraction (0-1)
  o: number; // Oxygen weight fraction (0-1)
  n: number; // Nitrogen weight fraction (0-1)
  s: number; // Sulphur weight fraction (0-1)
  ash: number; // Ash weight fraction (0-1)
  moisture: number; // Moisture weight fraction (0-1)
  inert: number; // Inert weight fraction (0-1)
}

export interface Fuel {
  id: string;
  name: string;
  type: 'coal' | 'gas' | 'oil' | 'custom';
  composition: ElementalComposition;
  molecularWeight: number; // g/mol (average for gas mixtures)
  density: number; // kg/m^3 (at 15 °C, 1 atm)
  lhv: number; // Lower Heating Value (MJ/kg)
  hhv: number; // Higher Heating Value (MJ/kg)
  specificHeat: number; // J/kg-K (at 298.15 K)
  viscosity?: number; // Pa-s (for liquids)
  physicalState: 'solid' | 'liquid' | 'gas';
  uncertainty: {
    composition: number; // % relative uncertainty
    heatingValue: number; // % relative uncertainty
    price: number; // % relative uncertainty
  };
  price: number; // USD per tonne (solid/liquid) or per MMBtu/1000m^3 (gas)
  currency: 'USD' | 'GBP';
  source: string;
}

export interface ChamberInput {
  fuelFlow: number; // kg/s
  airFlow: number; // kg/s
  lambda: number; // Excess air ratio (actual / stoichiometric)
  inletTempAir: number; // K
  inletTempFuel: number; // K
  pressure: number; // bar (absolute)
  volume: number; // m^3
  heatTransferArea: number; // m^2
  wallTemp: number; // K
  residenceTime: number; // s (can be calculated or specified)
  emissivity: number; // 0-1 radiative emissivity
  convectiveCoeff: number; // W/m^2-K
}

export interface CycleConfig {
  type: 'boiler' | 'turbine' | 'combined' | 'furnace' | 'chp';
  hasRecuperator: boolean;
  recuperatorEffectiveness: number; // 0-1
  turbinePressureRatio?: number; // for Gas Turbine / Combined Cycle
  compressorIsentropicEff?: number; // 0-1
  turbineIsentropicEff?: number; // 0-1
  steamPressure?: number; // bar (for Combined Cycle)
  steamIsentropicEff?: number; // 0-1
  chpThermalDemandRatio?: number; // 0-1
}

export interface EconomicInput {
  carbonPrice: number; // currency per tonne CO2
  electricityPrice: number; // currency per MWh
  maintenanceCostFactor: number; // currency per operating hour
  waterPrice: number; // currency per m^3
  currency: 'USD' | 'GBP';
}

export interface SimulationResultItem {
  parameter: string;
  value: number;
  unit: string;
  source: 'Rust Engine Core' | 'R Engine Analytics' | 'Theoretical Calculations';
  model: 'Deterministic Thermodynamic' | 'NASA Polynomial' | 'Zeldovich Kinetics' | 'Brayton Cycle' | 'Water-Gas Shift' | 'Economic Scenarios';
  uncertainty: number; // absolute or % relative
}

export interface EquilibriumComposition {
  CO2: number; // mole fraction
  CO: number;
  H2O: number;
  H2: number;
  O2: number;
  N2: number;
  OH: number;
  O: number;
  H: number;
  NO: number;
  NO2: number;
  SO2: number;
  SO3: number;
}

export interface SimulationOutput {
  simulationId: string;
  timestamp: string;
  
  // Mass & Elemental Balances
  massBalance: {
    massIn: number; // kg/s
    massOut: number; // kg/s
    error: number; // kg/s
    elementalClosure: {
      c: number; // recovery ratio (out/in)
      h: number;
      o: number;
      n: number;
      s: number;
    };
  };

  // Energy Balance (Sankey fields)
  energyBalance: {
    qInput: number; // MW
    qUseful: number; // MW
    qExhaust: number; // MW
    qRadiative: number; // MW
    qConvective: number; // MW
    qLosses: number; // MW (conduction, radiation, unaccounted)
    error: number; // MW
  };

  // Thermodynamic calculations
  thermodynamics: {
    stoichAFR: number; // kg air / kg fuel
    actualAFR: number; // kg air / kg fuel
    equivalenceRatio: number; // phi
    adiabaticFlameTemp: number; // K
    equilibriumTemp: number; // K
    exhaustTemp: number; // K
    thermalEfficiency: number; // % (LHV basis)
    overallSystemEfficiency: number; // % (accounting for preheaters / combined cycles)
    pressure: number; // bar
  };

  // Exhaust composition
  exhaustComposition: {
    species: EquilibriumComposition;
    wetMassFlow: number; // kg/s
    dryVolumeFraction: Record<string, number>; // ppm or % for dry emissions
  };

  // Emissions output
  emissions: {
    co2_kg_per_kg_fuel: number;
    co2_kg_per_mwh_useful: number;
    co_g_per_mwh: number;
    nox_g_per_mwh: number;
    sox_g_per_mwh: number;
    particulates_g_per_mwh: number;
    lifecycle_co2_kg_per_mwh?: number;
  };

  // Cycle Metrics
  cycleMetrics?: {
    compressorWork?: number; // MW
    turbineWork?: number; // MW
    steamWork?: number; // MW
    netPower?: number; // MW
    recoveredHeat?: number; // MW
    electricalEfficiency?: number; // %
    thermalEfficiency?: number; // %
  };

  // Economics
  economics: {
    fuelCost_per_hr: number;
    carbonTax_per_hr: number;
    electricityRevenue_per_hr: number;
    otherOpCost_per_hr: number;
    netOperatingCost_per_hr: number;
    cost_per_mwh_useful: number;
  };

  // Safety Status
  safety: {
    status: 'GREEN' | 'AMBER' | 'RED';
    alarms: string[];
    maxTempExceeded: boolean;
    maxPressureExceeded: boolean;
    lowOxygenExceeded: boolean;
    highEmissionsExceeded: boolean;
  };

  // Standard flat items array matching user data requirements
  metricsTable: SimulationResultItem[];
}

export interface MonteCarloTrial {
  trialId: number;
  efficiency: number; // %
  operatingCost: number; // USD/hr
  co2_emissions: number; // kg/MWh
  nox_emissions: number; // g/MWh
  usefulEnergy: number; // MW
  flameTemp: number; // K
}

export interface MonteCarloSummary {
  trialsCount: number;
  efficiency: MetricDistribution;
  operatingCost: MetricDistribution;
  co2_emissions: MetricDistribution;
  nox_emissions: MetricDistribution;
  usefulEnergy: MetricDistribution;
  rawTrials: MonteCarloTrial[]; // truncated for charting if needed
}

export interface MetricDistribution {
  mean: number;
  median: number;
  stdDev: number;
  min: number;
  max: number;
  p5: number;
  p95: number;
  p50: number;
  var95: number; // Value at Risk at 95% confidence
}

export interface SensitivityFactor {
  inputName: string;
  targetMetric: string;
  pearsonCorr: number;
  spearmanCorr: number;
  varianceContribution: number; // % contribution to variance
}

export interface ParetoPoint {
  pointId: number;
  lambda: number;
  cost_per_mwh: number; // USD/MWh
  emissions_index: number; // blended emissions score or pure NOx (g/MWh) or CO2
  nox_g_per_mwh: number;
  co2_kg_per_mwh: number;
  efficiency: number;
  fuelType: string;
  flameTemp: number;
}

export interface OptimizationLandscapePoint {
  lambda: number;
  airPreheat: number; // K
  efficiency: number; // %
  nox_g_per_mwh: number;
  cost_per_mwh: number;
}
