/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { SimulationOutput } from '../types';

interface SankeyDiagramProps {
  output: SimulationOutput;
}

export const SankeyDiagram: React.FC<SankeyDiagramProps> = ({ output }) => {
  const { energyBalance, massBalance, thermodynamics } = output;
  const { qInput, qUseful, qExhaust, qRadiative, qConvective, qLosses } = energyBalance;
  
  // Percentages for SVG rendering
  const getPct = (val: number) => (val / qInput) * 100;
  
  const pctUseful = getPct(qUseful);
  const pctExhaust = getPct(qExhaust);
  const pctLosses = getPct(qLosses);
  const pctRad = getPct(qRadiative);
  const pctConv = getPct(qConvective);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8" id="energy-mass-balance">
      {/* 1. Energy Flow Diagram */}
      <div className="border border-[#21262d] bg-[#0d1117] p-6 rounded-xl shadow-lg" id="energy-balance-card">
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2 mb-6">
          <h3 className="text-md font-semibold text-[#e1e4e8] font-mono uppercase tracking-tight">Energy Flow Path Analytics</h3>
          <span className="text-[10px] font-mono px-2.5 py-1 bg-[#161b22] text-emerald-400 border border-emerald-800/30 rounded">
            RESIDUAL ERROR: {energyBalance.error.toFixed(6)} MW
          </span>
        </div>

        <p className="text-xs text-slate-400 mb-6 leading-relaxed font-mono">
          Traces fuel chemical input energy (<span className="text-[#fb923c] font-bold">Q_input</span>) conversion into thermodynamics vectors, wall heat transfer losses, and net process output.
        </p>

        {/* Custom SVG flow chart */}
        <div className="relative w-full h-80 flex items-center justify-center">
          <svg className="w-full h-full" viewBox="0 0 600 320" fill="none" xmlns="http://www.w3.org/2000/svg">
            {/* Background grids */}
            <line x1="50" y1="20" x2="50" y2="300" stroke="#21262d" strokeDasharray="3 3" />
            <line x1="250" y1="20" x2="250" y2="300" stroke="#21262d" strokeDasharray="3 3" />
            <line x1="500" y1="20" x2="500" y2="300" stroke="#21262d" strokeDasharray="3 3" />

            {/* Input node */}
            <rect x="20" y="110" width="100" height="100" rx="4" fill="#161b22" stroke="#30363d" />
            <text x="70" y="150" fill="#e1e4e8" fontSize="11" fontWeight="600" fontFamily="monospace" textAnchor="middle">FUEL INPUT</text>
            <text x="70" y="172" fill="#8b949e" fontSize="10" fontFamily="monospace" textAnchor="middle">
              {qInput.toFixed(2)} MW
            </text>
            <text x="70" y="192" fill="#fb923c" fontSize="10" fontWeight="600" fontFamily="monospace" textAnchor="middle">100.0%</text>

            {/* Flows from input to middle transition (Combustion Chamber) */}
            <path d="M 120 160 Q 185 160 250 160" stroke="#f97316" strokeWidth="48" strokeLinecap="round" opacity="0.1" />
            <path d="M 120 160 Q 185 160 250 160" stroke="#ef4444" strokeWidth="8" strokeLinecap="round" opacity="0.2" />

            {/* Reaction Chamber Node */}
            <rect x="250" y="90" width="100" height="140" rx="4" fill="#161b22" stroke="#ef4444" strokeWidth="1" />
            <text x="300" y="125" fill="#e1e4e8" fontSize="11" fontWeight="600" fontFamily="monospace" textAnchor="middle">COMBUSTION</text>
            <text x="300" y="142" fill="#ef4444" fontSize="10" fontFamily="monospace" fontWeight="bold" textAnchor="middle">CHAMBER</text>
            <text x="300" y="175" fill="#8b949e" fontSize="9" fontFamily="monospace" textAnchor="middle">
              T_flame: {Math.round(thermodynamics.equilibriumTemp)} K
            </text>
            <text x="300" y="195" fill="#f87171" fontSize="9" fontFamily="monospace" textAnchor="middle">
              AFT: {Math.round(thermodynamics.adiabaticFlameTemp)} K
            </text>

            {/* Split Flows outwards */}
            {/* 1. Flow to Useful Process Heat (Upwardsright) */}
            <path d="M 350 120 Q 425 60 500 60" stroke="#10b981" strokeWidth={Math.max(4, pctUseful * 0.5)} strokeLinecap="round" opacity="0.7" />
            {/* 2. Flow to Flue Gas Loss (Straightwardsright) */}
            <path d="M 350 160 Q 425 160 500 160" stroke="#fb923c" strokeWidth={Math.max(4, pctExhaust * 0.5)} strokeLinecap="round" opacity="0.7" />
            {/* 3. Flow to Radiation & Wall Loss (Downwardsright) */}
            <path d="M 350 200 Q 425 260 500 260" stroke="#ef4444" strokeWidth={Math.max(4, pctLosses * 0.5)} strokeLinecap="round" opacity="0.7" />

            {/* Useful Process Heat Node */}
            <rect x="500" y="25" width="90" height="70" rx="2" fill="#064e3b" stroke="#10b981" />
            <text x="545" y="48" fill="#e1e4e8" fontSize="10" fontWeight="600" fontFamily="monospace" textAnchor="middle">USEFUL WORK</text>
            <text x="545" y="65" fill="#34d399" fontSize="9" fontFamily="monospace" textAnchor="middle">
              {qUseful.toFixed(2)} MW
            </text>
            <text x="545" y="80" fill="#10b981" fontSize="9" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
              {pctUseful.toFixed(1)}%
            </text>

            {/* Exhaust Flue Chimney loss Node */}
            <rect x="500" y="125" width="90" height="70" rx="2" fill="#78350f" stroke="#fb923c" />
            <text x="545" y="148" fill="#e1e4e8" fontSize="10" fontWeight="600" fontFamily="monospace" textAnchor="middle">FLUE LOSS</text>
            <text x="545" y="65" fill="#fde68a" fontSize="9" fontFamily="monospace" textAnchor="middle">
              {qExhaust.toFixed(2)} MW
            </text>
            <text x="545" y="180" fill="#fb923c" fontSize="9" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
              {pctExhaust.toFixed(1)}%
            </text>

            {/* Environmental Wall loss Node */}
            <rect x="500" y="225" width="90" height="70" rx="2" fill="#7f1d1d" stroke="#ef4444" />
            <text x="545" y="248" fill="#e1e4e8" fontSize="10" fontWeight="600" fontFamily="monospace" textAnchor="middle">WALL LOSS</text>
            <text x="545" y="265" fill="#fca5a5" fontSize="9" fontFamily="monospace" textAnchor="middle">
              {qLosses.toFixed(2)} MW
            </text>
            <text x="545" y="280" fill="#f87171" fontSize="9" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
              {pctLosses.toFixed(1)}%
            </text>
          </svg>
        </div>

        {/* Detailed breakdown footer */}
        <div className="grid grid-cols-3 gap-4 pt-4 border-t border-[#21262d] text-center text-xs">
          <div>
            <div className="text-slate-500 font-mono uppercase tracking-wider text-[10px] mb-1">Radiative Heat</div>
            <div className="font-bold text-rose-400 font-mono">{qRadiative.toFixed(3)} MW ({pctRad.toFixed(1)}%)</div>
          </div>
          <div>
            <div className="text-slate-500 font-mono uppercase tracking-wider text-[10px] mb-1">Convective Heat</div>
            <div className="font-bold text-sky-400 font-mono">{qConvective.toFixed(3)} MW ({pctConv.toFixed(1)}%)</div>
          </div>
          <div>
            <div className="text-slate-500 font-mono uppercase tracking-wider text-[10px] mb-1">Thermal Efficiency</div>
            <div className="font-bold text-emerald-400 font-mono">{thermodynamics.overallSystemEfficiency.toFixed(2)}%</div>
          </div>
        </div>
      </div>

      {/* 2. Mass Balance Closure */}
      <div className="border border-[#21262d] bg-[#0d1117] p-6 rounded-xl shadow-lg" id="mass-balance-card">
        <h3 className="text-md font-semibold text-[#e1e4e8] font-mono uppercase tracking-tight mb-4">Mass & Element Closures</h3>
        <p className="text-xs text-slate-400 mb-6 leading-relaxed font-mono">
          Validates chemical elements conservation criteria at boundary walls. Standard solver error margins are strictly verified.
        </p>

        {/* Mass Conservation */}
        <div className="space-y-4 mb-8">
          <div className="p-4 bg-[#161b22] border border-[#21262d] rounded-lg">
            <div className="flex justify-between items-center mb-3">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400">Mass Conservation Audit</span>
              {massBalance.error < 1e-4 ? (
                <span className="text-[10px] font-bold px-2 py-0.5 bg-[#111827] text-emerald-400 border border-emerald-800/30 rounded">CONSERVED</span>
              ) : (
                <span className="text-[10px] font-bold px-2 py-0.5 bg-[#111827] text-rose-400 border border-rose-800/30 rounded">STOCH_VAR</span>
              )}
            </div>
            <div className="grid grid-cols-3 gap-2 text-xs font-mono">
              <div>
                <div className="text-[10px] text-slate-500 uppercase">Mass In</div>
                <div className="font-semibold text-[#e1e4e8]">{massBalance.massIn.toFixed(5)} kg/s</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-500 uppercase">Mass Out</div>
                <div className="font-semibold text-[#e1e4e8]">{massBalance.massOut.toFixed(5)} kg/s</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-500 uppercase">Residual</div>
                <div className="font-semibold text-[#fb923c]">{massBalance.error.toFixed(6)} kg/s</div>
              </div>
            </div>
          </div>
        </div>

        {/* Atomic element-by-element recovery ratios */}
        <h4 className="text-xs font-semibold text-slate-400 font-mono uppercase tracking-wider mb-3">Elemental Recovery Closure (Out / In Ratio)</h4>
        <div className="space-y-4 font-mono text-xs">
          {/* Carbon */}
          <div>
            <div className="flex justify-between items-center mb-1 text-slate-400">
              <span>Carbon (C)</span>
              <span className="font-semibold text-[#e1e4e8]">{(massBalance.elementalClosure.c * 100).toFixed(4)}%</span>
            </div>
            <div className="w-full bg-[#161b22] border border-[#21262d] h-2 rounded-full overflow-hidden">
              <div 
                className="bg-slate-400 h-full rounded-full transition-all duration-300" 
                style={{ width: `${Math.min(100, massBalance.elementalClosure.c * 100)}%` }} 
              />
            </div>
          </div>

          {/* Hydrogen */}
          <div>
            <div className="flex justify-between items-center mb-1 text-slate-400">
              <span>Hydrogen (H)</span>
              <span className="font-semibold text-[#e1e4e8]">{(massBalance.elementalClosure.h * 100).toFixed(4)}%</span>
            </div>
            <div className="w-full bg-[#161b22] border border-[#21262d] h-2 rounded-full overflow-hidden">
              <div 
                className="bg-sky-400 h-full rounded-full transition-all duration-300" 
                style={{ width: `${Math.min(100, massBalance.elementalClosure.h * 100)}%` }} 
              />
            </div>
          </div>

          {/* Oxygen */}
          <div>
            <div className="flex justify-between items-center mb-1 text-slate-400">
              <span>Oxygen (O)</span>
              <span className="font-semibold text-[#e1e4e8]">{(massBalance.elementalClosure.o * 100).toFixed(4)}%</span>
            </div>
            <div className="w-full bg-[#161b22] border border-[#21262d] h-2 rounded-full overflow-hidden">
              <div 
                className="bg-rose-500 h-full rounded-full transition-all duration-300" 
                style={{ width: `${Math.min(100, massBalance.elementalClosure.o * 100)}%` }} 
              />
            </div>
          </div>

          {/* Nitrogen */}
          <div>
            <div className="flex justify-between items-center mb-1 text-slate-400">
              <span>Nitrogen (N)</span>
              <span className="font-semibold text-[#e1e4e8]">{(massBalance.elementalClosure.n * 100).toFixed(4)}%</span>
            </div>
            <div className="w-full bg-[#161b22] border border-[#21262d] h-2 rounded-full overflow-hidden">
              <div 
                className="bg-indigo-500 h-full rounded-full transition-all duration-300" 
                style={{ width: `${Math.min(100, massBalance.elementalClosure.n * 100)}%` }} 
              />
            </div>
          </div>

          {/* Sulphur */}
          <div>
            <div className="flex justify-between items-center mb-1 text-slate-400">
              <span>Sulphur (S)</span>
              <span className="font-semibold text-[#e1e4e8]">{(massBalance.elementalClosure.s * 100).toFixed(4)}%</span>
            </div>
            <div className="w-full bg-[#161b22] border border-[#21262d] h-2 rounded-full overflow-hidden">
              <div 
                className="bg-yellow-500 h-full rounded-full transition-all duration-300" 
                style={{ width: `${Math.min(100, massBalance.elementalClosure.s * 100)}%` }} 
              />
            </div>
          </div>
        </div>

        <p className="mt-5 text-[11px] text-slate-500 font-mono italic leading-normal">
          Double-precision thermodynamic conservation loops maintain error rates under &lt; 0.001% limit.
        </p>
      </div>
    </div>
  );
};
