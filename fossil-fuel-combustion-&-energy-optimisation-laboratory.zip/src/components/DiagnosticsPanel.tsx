/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SimulationOutput } from '../types';
import { Sparkles, Loader2, AlertCircle, RefreshCw } from 'lucide-react';

interface DiagnosticsPanelProps {
  currentOutput: SimulationOutput | null;
}

export const DiagnosticsPanel: React.FC<DiagnosticsPanelProps> = ({ currentOutput }) => {
  const [loading, setLoading] = useState(false);
  const [advice, setAdvice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const fetchAIAnalysis = async () => {
    if (!currentOutput) return;
    setLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/gemini/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data: currentOutput })
      });
      const resData = await response.json();
      if (response.ok) {
        setAdvice(resData.advice);
      } else {
        setError(resData.error || 'Failed to generate advisory diagnostics.');
      }
    } catch (err: any) {
      setError(err.message || 'Error communicating with AI research service.');
    } finally {
      setLoading(false);
    }
  };

  // Safe simple HTML parser for Markdown elements
  const parseMarkdown = (text: string) => {
    const lines = text.split('\n');
    return lines.map((line, idx) => {
      // Headers
      if (line.startsWith('### ')) {
        return <h4 key={idx} className="text-sm font-bold text-orange-400 mt-5 mb-2 flex items-center gap-1.5 font-mono uppercase tracking-wider">{line.replace('### ', '')}</h4>;
      }
      if (line.startsWith('#### ')) {
        return <h5 key={idx} className="text-xs font-semibold text-slate-300 mt-4 mb-1.5 font-mono uppercase tracking-wider">{line.replace('#### ', '')}</h5>;
      }
      if (line.startsWith('**') && line.endsWith('**')) {
        return <p key={idx} className="text-xs font-bold text-[#e1e4e8] my-1 font-mono">{line.replace(/\*\*/g, '')}</p>;
      }
      // Bullets
      if (line.startsWith('- ') || line.startsWith('* ')) {
        const clean = line.substring(2);
        // Detect bold in-line
        const parts = clean.split('**');
        return (
          <li key={idx} className="text-xs text-slate-300 list-disc ml-5 my-1 leading-relaxed">
            {parts.map((p, pIdx) => pIdx % 2 === 1 ? <strong key={pIdx} className="text-orange-400 font-mono font-bold">{p}</strong> : p)}
          </li>
        );
      }
      // Ordered list
      if (/^\d+\.\s/.test(line)) {
        const clean = line.replace(/^\d+\.\s/, '');
        const parts = clean.split('**');
        return (
          <li key={idx} className="text-xs text-slate-300 list-decimal ml-5 my-1 leading-relaxed font-mono">
            {parts.map((p, pIdx) => pIdx % 2 === 1 ? <strong key={pIdx} className="text-orange-400 font-bold">{p}</strong> : p)}
          </li>
        );
      }
      // Empty line
      if (line.trim() === '') {
        return <div key={idx} className="h-2" />;
      }
      
      // Standard line with inline bold support
      const parts = line.split('**');
      return (
        <p key={idx} className="text-xs text-slate-300 my-1 leading-relaxed">
          {parts.map((p, pIdx) => pIdx % 2 === 1 ? <strong key={pIdx} className="text-orange-400 font-bold">{p}</strong> : p)}
        </p>
      );
    });
  };

  return (
    <div className="border border-[#21262d] bg-[#0d1117] p-6 rounded-xl shadow-lg h-full flex flex-col justify-between" id="ai-diagnostics-panel">
      <div>
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="text-md font-semibold text-[#e1e4e8] flex items-center gap-2 tracking-tight uppercase font-mono">
              <Sparkles className="w-5 h-5 text-orange-500 fill-orange-500/20" />
              Gemini AI Combustion Advisor
            </h3>
            <p className="text-[11px] text-slate-500 mt-1 font-mono uppercase tracking-wider">
              Simulation Analytics: Active diagnostic modeling
            </p>
          </div>
          {advice && (
            <button 
              onClick={fetchAIAnalysis}
              disabled={loading || !currentOutput}
              className="p-1.5 text-slate-400 hover:text-orange-500 hover:bg-[#161b22] border border-[#21262d] rounded-lg transition-colors"
              title="Refresh AI Analysis"
              id="refresh-ai-btn"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            </button>
          )}
        </div>

        {/* Advisory Content Space */}
        <div className="min-h-60 mt-4 p-4 bg-[#161b22] border border-[#30363d] rounded-lg overflow-y-auto max-h-120">
          {loading ? (
            <div className="flex flex-col items-center justify-center h-60 space-y-3">
              <Loader2 className="w-8 h-8 text-orange-500 animate-spin" />
              <div className="text-xs text-slate-400 text-center font-mono uppercase tracking-wider animate-pulse">
                Analysing fluid kinetics & species...<br />
                <span className="text-[10px] text-slate-500">Querying Gemini on-server</span>
              </div>
            </div>
          ) : error ? (
            <div className="flex flex-col items-center justify-center h-60 text-center p-4">
              <AlertCircle className="w-8 h-8 text-rose-500 mb-2" />
              <div className="text-xs font-semibold text-rose-400 font-mono uppercase">Advisory Failure</div>
              <div className="text-[11px] text-slate-400 mt-1 max-w-sm font-mono">{error}</div>
              <button 
                onClick={fetchAIAnalysis}
                className="mt-4 px-3 py-1.5 text-xs font-medium text-black bg-orange-500 hover:bg-orange-600 rounded-md transition-colors shadow-sm font-mono uppercase tracking-wider"
              >
                Retry Analysis
              </button>
            </div>
          ) : advice ? (
            <div className="prose prose-sm max-w-none text-slate-300 leading-normal">
              {parseMarkdown(advice)}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-60 text-center p-4">
              <Sparkles className="w-12 h-12 text-[#21262d] mb-2 stroke-[1.5]" />
              <div className="text-xs font-semibold text-slate-400 font-mono uppercase tracking-wider">No Active Diagnosis</div>
              <div className="text-[11px] text-slate-500 mt-1 max-w-xs leading-normal font-mono">
                Click the diagnostic button below to request an advanced thermodynamic audit and emission tuning recommendation from Gemini.
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Trigger Button */}
      {!advice && !loading && (
        <button
          onClick={fetchAIAnalysis}
          disabled={!currentOutput}
          className="w-full mt-6 py-2.5 px-4 bg-orange-500 hover:bg-orange-600 disabled:bg-[#161b22] disabled:text-slate-600 text-black font-bold text-xs rounded-lg transition-all shadow flex items-center justify-center gap-2 uppercase tracking-wider font-mono"
          id="trigger-ai-btn"
        >
          <Sparkles className="w-4 h-4 fill-black" />
          Request Thermodynamic Expert Diagnosis
        </button>
      )}
    </div>
  );
};
