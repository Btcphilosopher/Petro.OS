/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { Fuel, SimulationOutput, MonteCarloSummary, SensitivityFactor, ParetoPoint, OptimizationLandscapePoint } from '../types';
import { localSolveFlameTemp, localSolveEquilibrium, localSolveStoichiometry } from '../lib/localSolver';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, AreaChart, Area, BarChart, Bar, Cell, ScatterChart, Scatter } from 'recharts';
import { BarChart3, TrendingUp, Cpu, Compass, ShieldAlert } from 'lucide-react';

interface ChartsPanelProps {
  activeFuel: Fuel;
  currentOutput: SimulationOutput | null;
  monteCarloData: MonteCarloSummary | null;
  sensitivityData: SensitivityFactor[] | null;
  paretoData: ParetoPoint[] | null;
  landscapeData: OptimizationLandscapePoint[] | null;
}

export const ChartsPanel: React.FC<ChartsPanelProps> = ({
  activeFuel,
  currentOutput,
  monteCarloData,
  sensitivityData,
  paretoData,
  landscapeData
}) => {
  const [activeTab, setActiveTab] = useState<'sweeps' | 'equilibrium' | 'stochastic' | 'sensitivity' | 'pareto' | 'landscape'>('sweeps');

  // 1. Generate client-side excess air lambda sweep data for instant interactive visualisations
  const lambdaSweepData = useMemo(() => {
    const data = [];
    const stoich = localSolveStoichiometry(activeFuel.composition);
    
    // Sweep lambda from 0.5 (rich) to 3.0 (lean)
    for (let l = 0.5; l <= 3.01; l += 0.1) {
      const temp = localSolveFlameTemp(activeFuel, l);
      const eq = localSolveEquilibrium(activeFuel.composition, l, temp);
      
      // Specific emissions estimates (relative scaling based on temp and excess oxygen)
      const co2 = stoich.co2Production;
      const h2o = stoich.h2oProduction;
      
      // Thermal NOx kinetics estimation: d[NO]/dt = k * exp(-Ea/RT) * [N2]*[O2]^0.5
      const o2_frac = Math.max(1e-5, eq.O2);
      const nox_kinetic = Math.max(0.1, 8.5e6 * Math.exp(-32000 / temp) * eq.N2 * Math.sqrt(o2_frac) * 1e6);

      // CO burnout kinetic estimation
      const co_kinetic = l < 1.0 ? eq.CO * 1e6 : Math.max(5.0, (1200 / (l - 0.95)) * Math.exp(-2.2e3 / temp));

      // Thermal Efficiency estimation (stack heat loss grows with lambda and exhaust temp)
      const stack_loss_fraction = 0.12 * l * (temp / 2000);
      const efficiency = Math.max(30, Math.min(95, 92 - stack_loss_fraction * 100));

      data.push({
        lambda: parseFloat(l.toFixed(2)),
        temp: Math.round(temp),
        efficiency: parseFloat(efficiency.toFixed(2)),
        CO2_kg: parseFloat((co2 * (l < 1.0 ? l : 1.0)).toFixed(3)),
        CO_ppm: Math.round(co_kinetic),
        NOx_ppm: Math.round(nox_kinetic),
        eq
      });
    }
    return data;
  }, [activeFuel]);

  // 2. Format equilibrium species data for Stacked Area Chart
  const speciesSweepData = useMemo(() => {
    return lambdaSweepData.map(d => ({
      lambda: d.lambda,
      CO2: parseFloat((d.eq.CO2 * 100).toFixed(4)),
      CO: parseFloat((d.eq.CO * 100).toFixed(4)),
      H2O: parseFloat((d.eq.H2O * 100).toFixed(4)),
      H2: parseFloat((d.eq.H2 * 100).toFixed(4)),
      O2: parseFloat((d.eq.O2 * 100).toFixed(4)),
      N2: parseFloat((d.eq.N2 * 100).toFixed(4)),
      NO: parseFloat((d.eq.NO * 1e6).toFixed(1)) // ppm for visibility
    }));
  }, [lambdaSweepData]);

  // 3. Format Monte Carlo Histogram Data
  const monteCarloHistData = useMemo(() => {
    if (!monteCarloData || !monteCarloData.rawTrials.length) return [];
    
    // Group trials into 15 equal bins for Efficiency
    const trials = monteCarloData.rawTrials;
    const minEff = Math.min(...trials.map(t => t.efficiency));
    const maxEff = Math.max(...trials.map(t => t.efficiency));
    const range = maxEff - minEff || 1;
    const binCount = 15;
    const binWidth = range / binCount;

    const bins = Array.from({ length: binCount }, (_, i) => {
      const start = minEff + i * binWidth;
      const end = start + binWidth;
      return {
        binLabel: `${start.toFixed(1)}-${end.toFixed(1)}%`,
        efficiencyBinStart: start,
        count: 0,
        avgCost: 0
      };
    });

    trials.forEach(t => {
      const binIdx = Math.min(binCount - 1, Math.floor((t.efficiency - minEff) / binWidth));
      if (binIdx >= 0 && binIdx < binCount) {
        bins[binIdx].count++;
        bins[binIdx].avgCost += t.operatingCost;
      }
    });

    bins.forEach(b => {
      if (b.count > 0) b.avgCost /= b.count;
    });

    return bins;
  }, [monteCarloData]);

  return (
    <div className="border border-[#21262d] bg-[#0d1117] p-6 rounded-xl shadow-lg" id="visual-laboratory-card">
      <div className="flex flex-col xl:flex-row xl:items-center justify-between border-b border-[#21262d] pb-4 mb-6 gap-4">
        <div>
          <h3 className="text-md font-semibold text-[#e1e4e8] font-mono uppercase tracking-tight">Process Optimization Analytics</h3>
          <p className="text-[11px] text-slate-500 mt-1 font-mono uppercase tracking-wider">
            Stochastic risk profiles and Pareto optimal operating thresholds.
          </p>
        </div>
        
        {/* Navigation Tabs */}
        <div className="flex flex-wrap gap-1.5" id="charts-tab-strip">
          <button
            onClick={() => setActiveTab('sweeps')}
            className={`px-3 py-1.5 text-xs font-mono font-bold rounded transition-all uppercase tracking-wider ${activeTab === 'sweeps' ? 'bg-orange-500 text-black shadow-md' : 'text-slate-400 hover:text-[#e1e4e8] hover:bg-[#161b22] border border-[#21262d]'}`}
          >
            Air/Fuel Sweeps
          </button>
          <button
            onClick={() => setActiveTab('equilibrium')}
            className={`px-3 py-1.5 text-xs font-mono font-bold rounded transition-all uppercase tracking-wider ${activeTab === 'equilibrium' ? 'bg-orange-500 text-black shadow-md' : 'text-slate-400 hover:text-[#e1e4e8] hover:bg-[#161b22] border border-[#21262d]'}`}
          >
            Equilibrium Gas
          </button>
          <button
            onClick={() => setActiveTab('stochastic')}
            disabled={!monteCarloData}
            className={`px-3 py-1.5 text-xs font-mono font-bold rounded transition-all uppercase tracking-wider disabled:opacity-30 disabled:cursor-not-allowed ${activeTab === 'stochastic' ? 'bg-orange-500 text-black shadow-md' : 'text-slate-400 hover:text-[#e1e4e8] hover:bg-[#161b22] border border-[#21262d]'}`}
          >
            Monte Carlo
          </button>
          <button
            onClick={() => setActiveTab('sensitivity')}
            disabled={!sensitivityData}
            className={`px-3 py-1.5 text-xs font-mono font-bold rounded transition-all uppercase tracking-wider disabled:opacity-30 disabled:cursor-not-allowed ${activeTab === 'sensitivity' ? 'bg-orange-500 text-black shadow-md' : 'text-slate-400 hover:text-[#e1e4e8] hover:bg-[#161b22] border border-[#21262d]'}`}
          >
            Sensitivities
          </button>
          <button
            onClick={() => setActiveTab('pareto')}
            disabled={!paretoData}
            className={`px-3 py-1.5 text-xs font-mono font-bold rounded transition-all uppercase tracking-wider disabled:opacity-30 disabled:cursor-not-allowed ${activeTab === 'pareto' ? 'bg-orange-500 text-black shadow-md' : 'text-slate-400 hover:text-[#e1e4e8] hover:bg-[#161b22] border border-[#21262d]'}`}
          >
            Pareto Frontier
          </button>
          <button
            onClick={() => setActiveTab('landscape')}
            disabled={!landscapeData}
            className={`px-3 py-1.5 text-xs font-mono font-bold rounded transition-all uppercase tracking-wider disabled:opacity-30 disabled:cursor-not-allowed ${activeTab === 'landscape' ? 'bg-orange-500 text-black shadow-md' : 'text-slate-400 hover:text-[#e1e4e8] hover:bg-[#161b22] border border-[#21262d]'}`}
          >
            2D Optimisation Space
          </button>
        </div>
      </div>

      {/* TAB CONTENT SPACES */}
      <div className="h-96 min-h-[380px] w-full" id="chart-viewport">
        {/* TAB 1: SWEEPS */}
        {activeTab === 'sweeps' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full">
            {/* Lambda vs Temp & Efficiency */}
            <div className="border border-[#21262d] p-4 rounded-lg bg-[#161b22] flex flex-col justify-between">
              <h4 className="text-xs font-bold text-slate-300 mb-2 flex items-center gap-1.5 font-mono uppercase tracking-wider"><TrendingUp className="w-3.5 h-3.5 text-emerald-500" /> Lambda (λ) vs. Flame Temp & Efficiency</h4>
              <div className="w-full h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={lambdaSweepData} margin={{ left: -10, right: 10, top: 10, bottom: 5 }}>
                    <CartesianGrid stroke="#21262d" strokeDasharray="3 3" />
                    <XAxis dataKey="lambda" tick={{ fontSize: 10, fill: '#8b949e' }} label={{ value: 'Actual/Stoich Air Ratio (λ)', position: 'insideBottom', offset: -5, fontSize: 10, fill: '#8b949e' }} />
                    <YAxis yAxisId="left" tick={{ fontSize: 10, fill: '#8b949e' }} label={{ value: 'Flame Temperature (K)', angle: -90, position: 'insideLeft', fontSize: 10, fill: '#8b949e' }} />
                    <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 10, fill: '#8b949e' }} label={{ value: 'Thermal Efficiency (%)', angle: 90, position: 'insideRight', fontSize: 10, fill: '#8b949e' }} />
                    <Tooltip contentStyle={{ fontSize: 11, backgroundColor: '#0d1117', borderColor: '#30363d', color: '#e1e4e8' }} />
                    <Legend wrapperStyle={{ fontSize: 10, color: '#e1e4e8' }} />
                    <Line yAxisId="left" type="monotone" dataKey="temp" name="Flame Temperature (K)" stroke="#f87171" strokeWidth={2} dot={false} activeDot={{ r: 4 }} />
                    <Line yAxisId="right" type="monotone" dataKey="efficiency" name="Thermal Efficiency (%)" stroke="#34d399" strokeWidth={2} dot={false} activeDot={{ r: 4 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Lambda vs Gaseous Emissions */}
            <div className="border border-[#21262d] p-4 rounded-lg bg-[#161b22] flex flex-col justify-between">
              <h4 className="text-xs font-bold text-slate-300 mb-2 flex items-center gap-1.5 font-mono uppercase tracking-wider"><ShieldAlert className="w-3.5 h-3.5 text-amber-500" /> Lambda (λ) vs. Gaseous Flue Emissions</h4>
              <div className="w-full h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={lambdaSweepData} margin={{ left: -10, right: 10, top: 10, bottom: 5 }}>
                    <CartesianGrid stroke="#21262d" strokeDasharray="3 3" />
                    <XAxis dataKey="lambda" tick={{ fontSize: 10, fill: '#8b949e' }} />
                    <YAxis yAxisId="left" tick={{ fontSize: 10, fill: '#8b949e' }} label={{ value: 'Emissions Concentration (ppm)', angle: -90, position: 'insideLeft', fontSize: 10, fill: '#8b949e' }} />
                    <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 10, fill: '#8b949e' }} label={{ value: 'Carbon Dioxide (kg/kg-fuel)', angle: 90, position: 'insideRight', fontSize: 10, fill: '#8b949e' }} />
                    <Tooltip contentStyle={{ fontSize: 11, backgroundColor: '#0d1117', borderColor: '#30363d', color: '#e1e4e8' }} />
                    <Legend wrapperStyle={{ fontSize: 10, color: '#e1e4e8' }} />
                    <Line yAxisId="left" type="monotone" dataKey="NOx_ppm" name="Nitrogen Oxides (NOx)" stroke="#60a5fa" strokeWidth={2} dot={false} />
                    <Line yAxisId="left" type="monotone" dataKey="CO_ppm" name="Carbon Monoxide (CO)" stroke="#fb923c" strokeWidth={2} dot={false} />
                    <Line yAxisId="right" type="monotone" dataKey="CO2_kg" name="Carbon Dioxide (CO2)" stroke="#94a3b8" strokeWidth={1.5} strokeDasharray="5 5" dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: EQUILIBRIUM */}
        {activeTab === 'equilibrium' && (
          <div className="border border-[#21262d] p-4 rounded-lg bg-[#161b22] h-full flex flex-col justify-between">
            <div>
              <h4 className="text-xs font-bold text-slate-300 flex items-center gap-1.5 font-mono uppercase tracking-wider"><Cpu className="w-3.5 h-3.5 text-[#fb923c]" /> Equilibrium Molecular Fraction Breakdown</h4>
              <p className="text-[10px] text-slate-500 mt-0.5 leading-relaxed font-mono">
                Stacked area distribution depicting chemical dissociation at equilibrium across fuel-rich (λ &lt; 1.0) and fuel-lean conditions.
              </p>
            </div>
            <div className="w-full h-76 mt-2">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={speciesSweepData} margin={{ left: -15, right: 10, top: 10, bottom: 5 }}>
                  <CartesianGrid stroke="#21262d" strokeDasharray="3 3" />
                  <XAxis dataKey="lambda" tick={{ fontSize: 10, fill: '#8b949e' }} />
                  <YAxis tick={{ fontSize: 10, fill: '#8b949e' }} label={{ value: 'Mole Fraction (%)', angle: -90, position: 'insideLeft', fontSize: 10, fill: '#8b949e' }} />
                  <Tooltip contentStyle={{ fontSize: 11, backgroundColor: '#0d1117', borderColor: '#30363d', color: '#e1e4e8' }} />
                  <Legend wrapperStyle={{ fontSize: 10 }} />
                  <Area type="monotone" dataKey="N2" stackId="1" stroke="#3b82f6" fill="#1e3a8a" name="N2" opacity={0.8} />
                  <Area type="monotone" dataKey="CO2" stackId="1" stroke="#94a3b8" fill="#334155" name="CO2" opacity={0.8} />
                  <Area type="monotone" dataKey="H2O" stackId="1" stroke="#0ea5e9" fill="#0c4a6e" name="H2O" opacity={0.8} />
                  <Area type="monotone" dataKey="O2" stackId="1" stroke="#22c55e" fill="#064e3b" name="O2" opacity={0.7} />
                  <Area type="monotone" dataKey="CO" stackId="1" stroke="#f97316" fill="#7c2d12" name="CO" opacity={0.7} />
                  <Area type="monotone" dataKey="H2" stackId="1" stroke="#a855f7" fill="#581c87" name="H2" opacity={0.7} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* TAB 3: STOCHASTIC MONTE CARLO */}
        {activeTab === 'stochastic' && monteCarloData && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 h-full">
            {/* Statistical summary list */}
            <div className="border border-[#21262d] p-4 rounded-lg bg-[#161b22] flex flex-col justify-between">
              <h4 className="text-xs font-bold text-slate-300 font-mono uppercase tracking-wider mb-2">Stochastic Risk Summary</h4>
              <div className="space-y-3 flex-1 overflow-y-auto pr-1">
                <div className="p-2.5 bg-[#0d1117] rounded border border-[#21262d]">
                  <div className="text-[10px] text-slate-500 font-semibold font-mono uppercase">Thermal Efficiency Probability</div>
                  <div className="text-sm font-bold text-emerald-400 font-mono">{(monteCarloData.efficiency.mean).toFixed(2)}% <span className="text-xs text-slate-500 font-normal">avg</span></div>
                  <div className="text-[10px] text-slate-400 mt-0.5 font-mono">90% Range: {monteCarloData.efficiency.p5.toFixed(1)}% to {monteCarloData.efficiency.p95.toFixed(1)}%</div>
                </div>

                <div className="p-2.5 bg-[#0d1117] rounded border border-[#21262d]">
                  <div className="text-[10px] text-slate-500 font-semibold font-mono uppercase">Unit Cost Distribution</div>
                  <div className="text-sm font-bold text-[#fb923c] font-mono">${(monteCarloData.operatingCost.mean).toFixed(2)}/hr <span className="text-xs text-slate-500 font-normal">avg</span></div>
                  <div className="text-[10px] text-slate-400 mt-0.5 font-mono">Value at Risk (95% cutoff): ${monteCarloData.operatingCost.var95.toFixed(1)}/hr</div>
                </div>

                <div className="p-2.5 bg-[#0d1117] rounded border border-[#21262d]">
                  <div className="text-[10px] text-slate-500 font-semibold font-mono uppercase">Nitrogen Oxides Variance</div>
                  <div className="text-sm font-bold text-blue-400 font-mono">{(monteCarloData.nox_emissions.mean).toFixed(1)} g/MWh</div>
                  <div className="text-[10px] text-slate-400 mt-0.5 font-mono">Volatility StdDev: {monteCarloData.nox_emissions.stdDev.toFixed(1)} g/MWh</div>
                </div>
              </div>
              <div className="text-[9px] text-slate-500 font-mono italic mt-2">Compiled across {monteCarloData.trialsCount} Monte Carlo iterations.</div>
            </div>

            {/* Histogram bars */}
            <div className="lg:col-span-2 border border-[#21262d] p-4 rounded-lg bg-[#161b22] flex flex-col justify-between">
              <h4 className="text-xs font-bold text-slate-300 font-mono uppercase tracking-wider mb-2">Efficiency Probability Density</h4>
              <div className="w-full h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={monteCarloHistData} margin={{ left: -15, right: 10, top: 10, bottom: 5 }}>
                    <CartesianGrid stroke="#21262d" strokeDasharray="3 3" />
                    <XAxis dataKey="binLabel" tick={{ fontSize: 9, fill: '#8b949e' }} />
                    <YAxis tick={{ fontSize: 10, fill: '#8b949e' }} label={{ value: 'Trials Count', angle: -90, position: 'insideLeft', fontSize: 10, fill: '#8b949e' }} />
                    <Tooltip contentStyle={{ fontSize: 11, backgroundColor: '#0d1117', borderColor: '#30363d', color: '#e1e4e8' }} />
                    <Bar dataKey="count" name="Frequency Count" fill="#f97316" radius={[2, 2, 0, 0]}>
                      {monteCarloHistData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={index === 7 ? '#fb923c' : '#7c2d12'} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: SENSITIVITIES */}
        {activeTab === 'sensitivity' && sensitivityData && (
          <div className="border border-[#21262d] p-4 rounded-lg bg-[#161b22] h-full flex flex-col justify-between">
            <div>
              <h4 className="text-xs font-bold text-slate-300 font-mono uppercase tracking-wider">Parametric Tornado Sensitivities [Target: Operating Cost ($/MWh)]</h4>
              <p className="text-[10px] text-slate-500 mt-0.5 font-mono">
                Horizontal ranking displaying Pearson/Spearman correlation and estimated variance contribution percentage on unit operating metrics.
              </p>
            </div>
            <div className="w-full h-72 mt-3">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={sensitivityData} layout="vertical" margin={{ left: 100, right: 10, top: 10, bottom: 5 }}>
                  <CartesianGrid stroke="#21262d" strokeDasharray="3 3" />
                  <XAxis type="number" domain={[-1, 1]} tick={{ fontSize: 10, fill: '#8b949e' }} />
                  <YAxis type="category" dataKey="inputName" tick={{ fontSize: 10, fill: '#8b949e' }} stroke="#30363d" />
                  <Tooltip contentStyle={{ fontSize: 11, backgroundColor: '#0d1117', borderColor: '#30363d', color: '#e1e4e8' }} />
                  <Bar dataKey="pearsonCorr" name="Pearson Correlation" radius={[0, 2, 2, 0]}>
                    {sensitivityData.map((entry, index) => {
                      const color = entry.pearsonCorr >= 0 ? '#f87171' : '#34d399'; // red for positive correlation (increases cost), green for negative (reduces cost)
                      return <Cell key={`cell-${index}`} fill={color} />;
                    })}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="flex gap-4 justify-center text-[10px] text-slate-500 pt-2 border-t border-[#21262d]">
              <span className="flex items-center gap-1.5 font-bold font-mono text-rose-400"><span className="w-2 h-2 rounded bg-rose-400" /> Positive Correlation (Increases Cost)</span>
              <span className="flex items-center gap-1.5 font-bold font-mono text-emerald-400"><span className="w-2 h-2 rounded bg-emerald-400" /> Negative Correlation (Reduces Cost)</span>
            </div>
          </div>
        )}

        {/* TAB 5: PARETO FRONTIER */}
        {activeTab === 'pareto' && paretoData && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 h-full">
            <div className="border border-[#21262d] p-4 rounded-lg bg-[#161b22] flex flex-col justify-between">
              <h4 className="text-xs font-bold text-slate-300 font-mono uppercase tracking-wider mb-2">Pareto Solutions List</h4>
              <div className="space-y-1.5 flex-1 overflow-y-auto max-h-72 pr-1 font-mono text-[10px]">
                {paretoData.slice(0, 15).map((p, idx) => (
                  <div key={idx} className="p-1.5 bg-[#0d1117] rounded border border-[#21262d] flex justify-between items-center">
                    <div>
                      <div className="font-bold text-slate-300 truncate max-w-[120px]">{p.fuelType}</div>
                      <div className="text-slate-500 text-[9px]">λ: {p.lambda.toFixed(2)} | Temp: {p.flameTemp} K</div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-orange-400">${p.cost_per_mwh.toFixed(1)}/MWh</div>
                      <div className="text-sky-400 font-bold text-[9px]">{Math.round(p.nox_g_per_mwh)} g_NOx</div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="text-[9px] text-slate-500 leading-normal mt-2 font-mono">
                Optimal trade-off boundary points where emissions cannot be lowered without raising unit costs.
              </div>
            </div>

            <div className="lg:col-span-2 border border-[#21262d] p-4 rounded-lg bg-[#161b22] flex flex-col justify-between">
              <h4 className="text-xs font-bold text-slate-300 font-mono uppercase tracking-wider mb-2">Cost vs. Emissions Pareto Frontier</h4>
              <div className="w-full h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <ScatterChart margin={{ left: -15, right: 10, top: 10, bottom: 5 }}>
                    <CartesianGrid stroke="#21262d" />
                    <XAxis type="number" dataKey="cost_per_mwh" name="Unit Cost" unit=" $/MWh" tick={{ fontSize: 9, fill: '#8b949e' }} />
                    <YAxis type="number" dataKey="nox_g_per_mwh" name="NOx Emissions" unit=" g/MWh" tick={{ fontSize: 9, fill: '#8b949e' }} />
                    <Tooltip cursor={{ strokeDasharray: '3 3' }} contentStyle={{ fontSize: 11, backgroundColor: '#0d1117', borderColor: '#30363d', color: '#e1e4e8' }} />
                    <Legend wrapperStyle={{ fontSize: 10 }} />
                    <Scatter name="Optimal Frontier Points" data={paretoData} fill="#f97316" line={{ stroke: '#fb923c', strokeWidth: 1.5 }} />
                  </ScatterChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: LANDSCAPE */}
        {activeTab === 'landscape' && landscapeData && (
          <div className="border border-[#21262d] p-4 rounded-lg bg-[#161b22] h-full flex flex-col justify-between">
            <div>
              <h4 className="text-xs font-bold text-slate-300 font-mono uppercase tracking-wider">Combustion Landscape [Excess Air (λ) vs. Air Preheat (K)]</h4>
              <p className="text-[10px] text-slate-500 mt-0.5 font-mono">
                Grid mapping depicting how air preheating and air/fuel stoichiometry interact to govern thermal efficiency levels.
              </p>
            </div>
            <div className="w-full h-72 mt-2">
              <ResponsiveContainer width="100%" height="100%">
                <ScatterChart margin={{ left: -15, right: 10, top: 10, bottom: 5 }}>
                  <CartesianGrid stroke="#21262d" />
                  <XAxis type="number" dataKey="lambda" name="Excess Air Ratio" tick={{ fontSize: 10, fill: '#8b949e' }} />
                  <YAxis type="number" dataKey="airPreheat" name="Air Preheat Temperature" unit=" K" tick={{ fontSize: 10, fill: '#8b949e' }} />
                  <Tooltip cursor={{ strokeDasharray: '3 3' }} contentStyle={{ fontSize: 11, backgroundColor: '#0d1117', borderColor: '#30363d', color: '#e1e4e8' }} />
                  <Legend wrapperStyle={{ fontSize: 10 }} />
                  <Scatter 
                    name="Operating Mesh Coordinates" 
                    data={landscapeData} 
                    fill="#10b981"
                  />
                </ScatterChart>
              </ResponsiveContainer>
            </div>
            <p className="text-[10px] text-slate-500 font-mono italic leading-normal">
              Higher preheat temperatures consistently maximize efficiency but run risks of thermal NOx spikes if stoichiometry sits near λ ~ 1.15.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
