/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Fuel, ChamberInput, CycleConfig, EconomicInput, SimulationOutput, MonteCarloSummary, SensitivityFactor, ParetoPoint, OptimizationLandscapePoint, ElementalComposition } from './types';
import { SankeyDiagram } from './components/SankeyDiagram';
import { ChartsPanel } from './components/ChartsPanel';
import { DiagnosticsPanel } from './components/DiagnosticsPanel';
import { Sparkles, Play, ShieldAlert, Cpu, Calculator, Award, TrendingUp, Compass, Settings, CheckCircle2, ChevronRight, BarChart3, RotateCcw } from 'lucide-react';

export default function App() {
  // ============================================================================
  // 1. DEFAULT CONFIGURATION STATE
  // ============================================================================
  const DEFAULT_FUEL_PRESET: Fuel = {
    id: 'natural_gas',
    name: 'Pipeline Natural Gas (US Standard)',
    type: 'gas',
    composition: { c: 0.7250, h: 0.2350, o: 0.0050, n: 0.0150, s: 0.0001, ash: 0, moisture: 0, inert: 0.0199 },
    molecularWeight: 17.2,
    density: 0.720,
    lhv: 47.10,
    hhv: 52.20,
    specificHeat: 2180,
    physicalState: 'gas',
    uncertainty: { composition: 0.5, heatingValue: 0.5, price: 1.0 },
    price: 4.20,
    currency: 'USD',
    source: 'AGA Report No. 8'
  };

  const DEFAULT_CHAMBER: ChamberInput = {
    fuelFlow: 1.2, // kg/s
    airFlow: 18.2, // kg/s (will be updated dynamically by solver)
    lambda: 1.15, // Excess air factor
    inletTempAir: 298.15, // K
    inletTempFuel: 298.15, // K
    pressure: 1.013, // bar
    volume: 15.0, // m^3
    heatTransferArea: 48.0, // m^2
    wallTemp: 1000.0, // K
    residenceTime: 1.2, // s
    emissivity: 0.82,
    convectiveCoeff: 45.0 // W/m^2-K
  };

  const DEFAULT_CYCLE: CycleConfig = {
    type: 'boiler',
    hasRecuperator: true,
    recuperatorEffectiveness: 0.65,
    turbinePressureRatio: 12.0,
    compressorIsentropicEff: 0.85,
    turbineIsentropicEff: 0.88,
    steamPressure: 45.0,
    steamIsentropicEff: 0.85,
    chpThermalDemandRatio: 0.6
  };

  const DEFAULT_ECONOMY: EconomicInput = {
    carbonPrice: 45.0, // USD/tonne CO2
    electricityPrice: 85.0, // USD/MWh
    maintenanceCostFactor: 110.0, // USD/hr
    waterPrice: 1.80, // USD/m^3
    currency: 'USD'
  };

  // ============================================================================
  // 2. CORE REACT STATE
  // ============================================================================
  const [fuels, setFuels] = useState<Fuel[]>([]);
  const [activeFuel, setActiveFuel] = useState<Fuel>(DEFAULT_FUEL_PRESET);
  const [chamber, setChamber] = useState<ChamberInput>(DEFAULT_CHAMBER);
  const [cycle, setCycle] = useState<CycleConfig>(DEFAULT_CYCLE);
  const [economy, setEconomy] = useState<EconomicInput>(DEFAULT_ECONOMY);

  // Simulation outputs
  const [currentOutput, setCurrentOutput] = useState<SimulationOutput | null>(null);
  const [monteCarloData, setMonteCarloData] = useState<MonteCarloSummary | null>(null);
  const [sensitivityData, setSensitivityData] = useState<SensitivityFactor[] | null>(null);
  const [paretoData, setParetoData] = useState<ParetoPoint[] | null>(null);
  const [landscapeData, setLandscapeData] = useState<OptimizationLandscapePoint[] | null>(null);

  // UI Tabs & Toggles
  const [activeView, setActiveView] = useState<'simulation' | 'visuals' | 'calibration' | 'balances' | 'advisor'>('simulation');
  const [runningSim, setRunningSim] = useState(false);
  const [runningAnalytics, setRunningAnalytics] = useState(false);
  const [trialsCount, setTrialsCount] = useState(5000);

  // Digital Twin Calibration Inputs
  const [twinMeasuredStackO2, setTwinMeasuredStackO2] = useState<string>('3.5');
  const [twinMeasuredExhaustTemp, setTwinMeasuredExhaustTemp] = useState<string>('480');
  const [twinMessage, setTwinMessage] = useState<string | null>(null);

  // ============================================================================
  // 3. API FETCH / ENGINE TRIGGERS
  // ============================================================================
  useEffect(() => {
    // Gather fuels from our server database
    fetch('/api/fuels')
      .then(res => res.json())
      .then(data => {
        if (data.fuels) {
          setFuels(data.fuels);
        }
      })
      .catch(err => console.error('Error fetching fuel database:', err));
  }, []);

  // Solve deterministic simulation
  const handleSolveSimulation = async (
    targetFuel = activeFuel,
    targetChamber = chamber,
    targetCycle = cycle,
    targetEco = economy
  ) => {
    setRunningSim(true);
    try {
      const response = await fetch('/api/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fuel: targetFuel,
          chamber: targetChamber,
          cycle: targetCycle,
          economy: targetEco
        })
      });
      const resData = await response.json();
      if (response.ok && resData.status === 'ok') {
        setCurrentOutput(resData.data);
      } else {
        console.error('Solver returned error:', resData.error);
      }
    } catch (err) {
      console.error('Failed to trigger simulation solver API:', err);
    } finally {
      setRunningSim(false);
    }
  };

  // Solve heavy stochastic / R-engine calculations
  const handleRunStatisticalEngines = async () => {
    setRunningAnalytics(true);
    try {
      // 1. Trigger Monte Carlo
      const mcRes = await fetch('/api/monte-carlo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fuel: activeFuel, chamber, cycle, economy, trialsCount })
      });
      const mcData = await mcRes.json();
      if (mcRes.ok && mcData.status === 'ok') {
        setMonteCarloData(mcData.data);
      }

      // 2. Trigger Sensitivities
      const sensRes = await fetch('/api/sensitivity', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fuel: activeFuel, chamber, cycle, economy })
      });
      const sensData = await sensRes.json();
      if (sensRes.ok && sensData.status === 'ok') {
        setSensitivityData(sensData.data);
      }

      // 3. Trigger Pareto Optimization
      const paretoRes = await fetch('/api/pareto', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chamber, cycle, economy })
      });
      const pData = await paretoRes.json();
      if (paretoRes.ok && pData.status === 'ok') {
        setParetoData(pData.data);
      }

      // 4. Trigger 2D Optimization Grid
      const landscapeRes = await fetch('/api/landscape', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fuel: activeFuel, chamber, cycle, economy })
      });
      const lData = await landscapeRes.json();
      if (landscapeRes.ok && lData.status === 'ok') {
        setLandscapeData(lData.data);
      }

      setActiveView('visuals'); // swap to visuals tab once processed
    } catch (err) {
      console.error('Error running statistical R-engines on server:', err);
    } finally {
      setRunningAnalytics(false);
    }
  };

  // Trigger initial solve on mount
  useEffect(() => {
    handleSolveSimulation(DEFAULT_FUEL_PRESET, DEFAULT_CHAMBER, DEFAULT_CYCLE, DEFAULT_ECONOMY);
  }, []);

  // Dulong & LHV formula for user custom fuel blends
  const recalculateHeatingValues = (comp: ElementalComposition) => {
    // Dulong formula for higher heating value (HHV) in MJ/kg
    const hhv = 338.2 * comp.c + 1442.8 * (comp.h - comp.o / 8) + 94.2 * comp.s;
    const clampedHhv = Math.max(5.0, Math.min(65.0, hhv));
    // Lower heating value (LHV) accounts for hydrogen water vapor condensation heat
    const lhv = clampedHhv - 21.96 * comp.h - 2.44 * comp.moisture;
    const clampedLhv = Math.max(3.0, Math.min(60.0, lhv));
    return { hhv: clampedHhv, lhv: clampedLhv };
  };

  // Handle custom composition slider changes
  const handleCompositionSliderChange = (element: keyof ElementalComposition, value: number) => {
    const updatedComp = { ...activeFuel.composition, [element]: value };
    
    // Normalize fractions to sum to 1.0 (excluding inert which serves as balance)
    const elementsSum = updatedComp.c + updatedComp.h + updatedComp.o + updatedComp.n + updatedComp.s + updatedComp.ash + updatedComp.moisture;
    if (elementsSum > 1.0) {
      // Scale down elements to fit within 1.0
      const scale = 0.98 / elementsSum;
      updatedComp.c *= scale;
      updatedComp.h *= scale;
      updatedComp.o *= scale;
      updatedComp.n *= scale;
      updatedComp.s *= scale;
      updatedComp.ash *= scale;
      updatedComp.moisture *= scale;
    }
    updatedComp.inert = Math.max(0, 1.0 - (updatedComp.c + updatedComp.h + updatedComp.o + updatedComp.n + updatedComp.s + updatedComp.ash + updatedComp.moisture));

    // Recalculate heating values dynamically
    const { hhv, lhv } = recalculateHeatingValues(updatedComp);

    const updatedFuel: Fuel = {
      ...activeFuel,
      id: 'custom_hydrocarbon',
      name: 'Custom Hydrocarbon Blend',
      type: 'custom',
      composition: updatedComp,
      lhv,
      hhv,
      density: activeFuel.physicalState === 'solid' ? 1200.0 : activeFuel.physicalState === 'liquid' ? 880.0 : 0.75
    };

    setActiveFuel(updatedFuel);
    handleSolveSimulation(updatedFuel, chamber, cycle, economy);
  };

  // ============================================================================
  // 4. DIGITAL TWIN CALIBRATION ALGORITHM
  // ============================================================================
  const handleCalibrateDigitalTwin = () => {
    const measuredO2 = parseFloat(twinMeasuredStackO2);
    const measuredTemp = parseFloat(twinMeasuredExhaustTemp);

    if (isNaN(measuredO2) || isNaN(measuredTemp)) {
      setTwinMessage('Invalid measurement logs. Please enter positive numeric values.');
      return;
    }

    // 1. Back-calculate excess air (lambda) from Stack O2%
    // Standard stoichiometric complete gas relation: lambda = 21 / (21 - Measured O2 %)
    const calibratedLambda = 21 / (21 - Math.min(20, measuredO2));
    
    // 2. Back-calculate Convective heat transfer coefficient (h) to match measured exhaust temp
    // If measuredTemp is higher than active simulation, heat exchanger is fouled -> h calibrated is lower.
    const currentExhaust = currentOutput?.thermodynamics.exhaustTemp || 500;
    const tempRatio = currentExhaust / measuredTemp;
    const calibratedConvectiveCoeff = Math.max(5.0, Math.min(200.0, chamber.convectiveCoeff * tempRatio));

    const updatedChamber: ChamberInput = {
      ...chamber,
      lambda: parseFloat(calibratedLambda.toFixed(3)),
      convectiveCoeff: parseFloat(calibratedConvectiveCoeff.toFixed(2))
    };

    setChamber(updatedChamber);
    setTwinMessage(`Digital Twin successfully calibrated! 
- Lambda adjusted to **${calibratedLambda.toFixed(3)}** (from O₂ stack fraction)
- Convective heat transfer coefficient adjusted to **${calibratedConvectiveCoeff.toFixed(2)} W/m²-K** (to reconcile stack temperature)`);
    
    handleSolveSimulation(activeFuel, updatedChamber, cycle, economy);
  };

  return (
    <div className="min-h-screen bg-[#0a0c10] text-[#e1e4e8] font-sans antialiased" id="laboratory-wrapper">
      
      {/* HEADER BANNER */}
      <header className="border-b border-[#21262d] bg-[#0d1117]" id="lab-header">
        <div className="mx-auto max-w-7xl px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-[#161b22] text-orange-500 rounded-xl border border-[#21262d] shadow-md">
              <Cpu className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-md font-bold tracking-wider text-white uppercase font-mono">FOSSIL-FUEL COMBUSTION & ENERGY OPTIMISATION LABORATORY</h1>
              <p className="text-[10px] text-slate-500 uppercase tracking-widest font-mono">Computational Research & Stoichiometric Simulation Twin</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono font-bold px-2 py-1 bg-[#161b22] text-[#f87171] border border-[#f87171]/20 rounded">RUST-PHYSICS v4.1 (WASM)</span>
            <span className="text-[10px] font-mono font-bold px-2 py-1 bg-[#161b22] text-sky-400 border border-sky-400/20 rounded">R-STATS v4.2</span>
          </div>
        </div>
      </header>

      {/* QUICK METRICS & SAFETY BANNER */}
      {currentOutput && (
        <section className="bg-[#161b22] text-white border-b border-[#21262d]" id="quick-metrics-strip">
          <div className="mx-auto max-w-7xl px-6 py-3 grid grid-cols-2 md:grid-cols-6 gap-4 items-center">
            
            {/* Safety status indicator */}
            <div className="flex items-center gap-2.5 col-span-2 md:col-span-1 border-r border-[#21262d] pr-4">
              <div className={`w-3 h-3 rounded-full ${currentOutput.safety.status === 'GREEN' ? 'bg-emerald-500 animate-pulse' : currentOutput.safety.status === 'AMBER' ? 'bg-amber-500' : 'bg-rose-500'}`} />
              <div>
                <div className="text-[10px] text-slate-500 font-bold font-mono uppercase tracking-wider">Safety Status</div>
                <div className="text-xs font-bold font-mono">{currentOutput.safety.status}</div>
              </div>
            </div>

            <div>
              <div className="text-[10px] text-slate-500 font-bold font-mono uppercase tracking-wider">Adiabatic Flame Temp</div>
              <div className="text-sm font-bold font-mono text-rose-400">{Math.round(currentOutput.thermodynamics.adiabaticFlameTemp)} K</div>
            </div>

            <div>
              <div className="text-[10px] text-slate-500 font-bold font-mono uppercase tracking-wider">Overall Efficiency</div>
              <div className="text-sm font-bold font-mono text-emerald-400">{currentOutput.thermodynamics.overallSystemEfficiency.toFixed(2)}%</div>
            </div>

            <div>
              <div className="text-[10px] text-slate-500 font-bold font-mono uppercase tracking-wider">Useful Process Energy</div>
              <div className="text-sm font-bold font-mono text-sky-400">{currentOutput.energyBalance.qUseful.toFixed(3)} MW</div>
            </div>

            <div>
              <div className="text-[10px] text-slate-500 font-bold font-mono uppercase tracking-wider">NOx Exhaust</div>
              <div className="text-sm font-bold font-mono text-indigo-400">{Math.round(currentOutput.emissions.nox_g_per_mwh)} g/MWh</div>
            </div>

            <div>
              <div className="text-[10px] text-slate-500 font-bold font-mono uppercase tracking-wider">Operating cost</div>
              <div className="text-sm font-bold font-mono text-amber-400">${currentOutput.economics.cost_per_mwh_useful.toFixed(2)}/MWh</div>
            </div>

          </div>
        </section>
      )}

      {/* CORE WORKSPACE GRID */}
      <main className="mx-auto max-w-7xl px-6 py-8 grid grid-cols-1 xl:grid-cols-12 gap-8" id="lab-workspace">
        
        {/* LEFT COLUMN: CONTROL INTERFACES (SPAN 4) */}
        <section className="xl:col-span-4 space-y-6" id="controls-column">
          
          {/* FUEL PROFILE SELECTION */}
          <div className="border border-[#21262d] bg-[#0d1117] p-5 rounded-xl shadow-lg" id="fuel-profile-card">
            <h3 className="text-xs font-bold uppercase tracking-widest text-[#e1e4e8] font-mono mb-4 flex items-center gap-2 border-b border-[#21262d] pb-2.5">
              <Calculator className="w-4 h-4 text-orange-500" /> Fuel Profile & ultimate analysis
            </h3>
            
            {/* Presets dropdown */}
            <div className="mb-4">
              <label className="text-[10px] font-bold text-slate-400 font-mono uppercase">Select Preset Fuel</label>
              <select
                value={activeFuel.id}
                onChange={(e) => {
                  const selected = fuels.find(f => f.id === e.target.value) || DEFAULT_FUEL_PRESET;
                  setActiveFuel(selected);
                  handleSolveSimulation(selected, chamber, cycle, economy);
                }}
                className="mt-1.5 w-full p-2 bg-[#161b22] border border-[#30363d] rounded text-xs font-medium text-white focus:outline-none focus:border-orange-500"
              >
                {fuels.map(f => (
                  <option key={f.id} value={f.id} className="bg-[#0d1117]">{f.name}</option>
                ))}
                <option value="custom" className="bg-[#0d1117]">Custom Hydrocarbon Blend</option>
              </select>
            </div>

            {/* Ultimate Analysis sliders */}
            <div className="space-y-3.5 border-t border-[#21262d] pt-4" id="ultimate-analysis-sliders">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold uppercase font-mono text-slate-400">ultimate dry fractions</span>
                <span className="text-[10px] font-mono text-orange-500 font-bold">100% dry base</span>
              </div>

              {/* Carbon */}
              <div>
                <div className="flex justify-between text-[11px] text-slate-300 font-mono mb-1">
                  <span>Carbon (C)</span>
                  <span className="font-semibold">{(activeFuel.composition.c * 100).toFixed(1)}%</span>
                </div>
                <input
                  type="range" min="0" max="1" step="0.01"
                  value={activeFuel.composition.c}
                  onChange={(e) => handleCompositionSliderChange('c', parseFloat(e.target.value))}
                  className="w-full accent-orange-500"
                />
              </div>

              {/* Hydrogen */}
              <div>
                <div className="flex justify-between text-[11px] text-slate-300 font-mono mb-1">
                  <span>Hydrogen (H)</span>
                  <span className="font-semibold">{(activeFuel.composition.h * 100).toFixed(1)}%</span>
                </div>
                <input
                  type="range" min="0" max="0.3" step="0.005"
                  value={activeFuel.composition.h}
                  onChange={(e) => handleCompositionSliderChange('h', parseFloat(e.target.value))}
                  className="w-full accent-orange-500"
                />
              </div>

              {/* Oxygen */}
              <div>
                <div className="flex justify-between text-[11px] text-slate-300 font-mono mb-1">
                  <span>Oxygen (O)</span>
                  <span className="font-semibold">{(activeFuel.composition.o * 100).toFixed(1)}%</span>
                </div>
                <input
                  type="range" min="0" max="0.4" step="0.01"
                  value={activeFuel.composition.o}
                  onChange={(e) => handleCompositionSliderChange('o', parseFloat(e.target.value))}
                  className="w-full accent-orange-500"
                />
              </div>

              {/* Sulphur */}
              <div>
                <div className="flex justify-between text-[11px] text-slate-300 font-mono mb-1">
                  <span>Sulphur (S)</span>
                  <span className="font-semibold">{(activeFuel.composition.s * 100).toFixed(3)}%</span>
                </div>
                <input
                  type="range" min="0" max="0.05" step="0.001"
                  value={activeFuel.composition.s}
                  onChange={(e) => handleCompositionSliderChange('s', parseFloat(e.target.value))}
                  className="w-full accent-orange-500"
                />
              </div>

              {/* Moisture */}
              <div>
                <div className="flex justify-between text-[11px] text-slate-300 font-mono mb-1">
                  <span>Moisture</span>
                  <span className="font-semibold">{(activeFuel.composition.moisture * 100).toFixed(1)}%</span>
                </div>
                <input
                  type="range" min="0" max="0.5" step="0.01"
                  value={activeFuel.composition.moisture}
                  onChange={(e) => handleCompositionSliderChange('moisture', parseFloat(e.target.value))}
                  className="w-full accent-orange-500"
                />
              </div>
            </div>

            {/* Price configuration */}
            <div className="grid grid-cols-2 gap-3 mt-4 pt-4 border-t border-[#21262d]">
              <div>
                <label className="text-[10px] font-bold text-slate-400 font-mono uppercase">Fuel Price ($/kSCF)</label>
                <input
                  type="number" step="0.1"
                  value={activeFuel.price}
                  onChange={(e) => {
                    const price = Math.max(0, parseFloat(e.target.value) || 0);
                    const updated = { ...activeFuel, price };
                    setActiveFuel(updated);
                    handleSolveSimulation(updated, chamber, cycle, economy);
                  }}
                  className="mt-1.5 w-full p-2 bg-[#161b22] border border-[#30363d] rounded text-xs font-mono text-white focus:outline-none focus:border-orange-500"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-slate-400 font-mono uppercase">LHV Basis</label>
                <div className="mt-2 text-xs font-mono font-bold text-[#fb923c]">{activeFuel.lhv.toFixed(2)} MJ/kg</div>
              </div>
            </div>
          </div>

          {/* REACTION CHAMBER CONTROLS */}
          <div className="border border-[#21262d] bg-[#0d1117] p-5 rounded-xl shadow-lg" id="chamber-controls-card">
            <h3 className="text-xs font-bold uppercase tracking-widest text-[#e1e4e8] font-mono mb-4 flex items-center gap-2 border-b border-[#21262d] pb-2.5">
              <Settings className="w-4 h-4 text-orange-500" /> Chamber Kinetic Parameters
            </h3>

            <div className="space-y-4">
              {/* Excess Air Lambda */}
              <div>
                <div className="flex justify-between text-[11px] text-slate-300 font-mono mb-1">
                  <span className="font-semibold">Excess Air Ratio (λ)</span>
                  <span className="font-bold font-mono text-orange-400">{chamber.lambda.toFixed(2)}</span>
                </div>
                <input
                  type="range" min="0.5" max="3.0" step="0.02"
                  value={chamber.lambda}
                  onChange={(e) => {
                    const lambda = parseFloat(e.target.value);
                    const updated = { ...chamber, lambda };
                    setChamber(updated);
                    handleSolveSimulation(activeFuel, updated, cycle, economy);
                  }}
                  className="w-full accent-orange-500"
                />
                <div className="flex justify-between text-[9px] text-slate-500 font-mono mt-0.5 uppercase tracking-wide">
                  <span>0.5 (Rich)</span>
                  <span>1.0 (Stoich)</span>
                  <span>3.0 (Lean)</span>
                </div>
              </div>

              {/* Fuel mass flow */}
              <div>
                <div className="flex justify-between text-[11px] text-slate-300 font-mono mb-1">
                  <span>Fuel Mass Flow Feed</span>
                  <span className="font-semibold font-mono text-orange-400">{chamber.fuelFlow.toFixed(2)} kg/s</span>
                </div>
                <input
                  type="range" min="0.1" max="10.0" step="0.1"
                  value={chamber.fuelFlow}
                  onChange={(e) => {
                    const fuelFlow = parseFloat(e.target.value);
                    const updated = { ...chamber, fuelFlow };
                    setChamber(updated);
                    handleSolveSimulation(activeFuel, updated, cycle, economy);
                  }}
                  className="w-full accent-orange-500"
                />
              </div>

              {/* Sizing & Material parameters */}
              <div className="grid grid-cols-2 gap-3.5 border-t border-[#21262d] pt-4 text-xs font-mono">
                <div>
                  <label className="text-[10px] font-semibold uppercase tracking-wider text-slate-500">Refractory Wall Temp</label>
                  <input
                    type="number" step="50" min="300" max="2200"
                    value={chamber.wallTemp}
                    onChange={(e) => {
                      const wallTemp = Math.max(300, parseFloat(e.target.value) || 300);
                      const updated = { ...chamber, wallTemp };
                      setChamber(updated);
                      handleSolveSimulation(activeFuel, updated, cycle, economy);
                    }}
                    className="mt-1.5 w-full p-2 bg-[#161b22] border border-[#30363d] rounded font-mono text-white focus:outline-none focus:border-orange-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-semibold uppercase tracking-wider text-slate-500">Residence Time</label>
                  <input
                    type="number" step="0.1" min="0.1" max="10.0"
                    value={chamber.residenceTime}
                    onChange={(e) => {
                      const residenceTime = Math.max(0.1, parseFloat(e.target.value) || 0.1);
                      const updated = { ...chamber, residenceTime };
                      setChamber(updated);
                      handleSolveSimulation(activeFuel, updated, cycle, economy);
                    }}
                    className="mt-1.5 w-full p-2 bg-[#161b22] border border-[#30363d] rounded font-mono text-white focus:outline-none focus:border-orange-500"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* THERMODYNAMIC CYCLE SELECTION */}
          <div className="border border-[#21262d] bg-[#0d1117] p-5 rounded-xl shadow-lg" id="cycle-selection-card">
            <h3 className="text-xs font-bold uppercase tracking-widest text-[#e1e4e8] font-mono mb-4 flex items-center gap-2 border-b border-[#21262d] pb-2.5">
              <Cpu className="w-4 h-4 text-orange-500" /> Cycle & Heat Recovery Sizing
            </h3>

            <div className="space-y-4 text-xs font-mono">
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase">Process Cycle Architecture</label>
                <select
                  value={cycle.type}
                  onChange={(e) => {
                    const type = e.target.value as any;
                    const updated = { ...cycle, type };
                    setCycle(updated);
                    handleSolveSimulation(activeFuel, chamber, updated, economy);
                  }}
                  className="mt-1.5 w-full p-2 bg-[#161b22] border border-[#30363d] rounded text-white font-medium focus:outline-none focus:border-orange-500"
                >
                  <option value="boiler" className="bg-[#0d1117]">Industrial Steam Boiler Cycle</option>
                  <option value="furnace" className="bg-[#0d1117]">Refractory Process Furnace (Direct Heat)</option>
                  <option value="turbine" className="bg-[#0d1117]">Gas Turbine Cogeneration (Brayton Cycle)</option>
                  <option value="combined" className="bg-[#0d1117]">Combined Cycle Gas Turbine (CCGT)</option>
                  <option value="chp" className="bg-[#0d1117]">District Combined Heat & Power (CHP)</option>
                </select>
              </div>

              {/* Recuperator / preheater toggle */}
              <div className="p-3 bg-[#161b22] rounded-lg border border-[#21262d] flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-300">Preheat Economiser</div>
                  <div className="text-[9px] text-slate-500 font-mono">Recovers flue gas to preheat feed air</div>
                </div>
                <input
                  type="checkbox"
                  checked={cycle.hasRecuperator}
                  onChange={(e) => {
                    const hasRecuperator = e.target.checked;
                    const updated = { ...cycle, hasRecuperator };
                    setCycle(updated);
                    handleSolveSimulation(activeFuel, chamber, updated, economy);
                  }}
                  className="w-4 h-4 text-orange-500 rounded focus:ring-0 cursor-pointer accent-orange-500"
                />
              </div>

              {cycle.hasRecuperator && (
                <div>
                  <div className="flex justify-between text-[11px] text-slate-300 mb-1">
                    <span>Recuperator Thermal Effectiveness</span>
                    <span className="font-semibold font-mono text-orange-400">{(cycle.recuperatorEffectiveness * 100).toFixed(0)}%</span>
                  </div>
                  <input
                    type="range" min="0.1" max="0.9" step="0.05"
                    value={cycle.recuperatorEffectiveness}
                    onChange={(e) => {
                      const recuperatorEffectiveness = parseFloat(e.target.value);
                      const updated = { ...cycle, recuperatorEffectiveness };
                      setCycle(updated);
                      handleSolveSimulation(activeFuel, chamber, updated, economy);
                    }}
                    className="w-full accent-orange-500"
                  />
                </div>
              )}
            </div>
          </div>

          {/* RUN STATISTICAL ANALYSIS BLOCK */}
          <div className="p-5 bg-gradient-to-br from-[#161b22] to-[#0d1117] text-white rounded-xl shadow-lg border border-[#30363d]">
            <h3 className="text-xs font-bold uppercase tracking-widest text-orange-500 mb-2 flex items-center gap-2">
              <TrendingUp className="w-4 h-4" /> R-Engine Analytics Suite
            </h3>
            <p className="text-[10px] text-slate-400 leading-normal mb-4 font-mono">
              Trigger high-performance statistical solvers on-server to compile Pearson correlations, Pareto optimal frontiers, and stochastic Monte Carlo trials.
            </p>

            <div className="flex items-center gap-3 mb-4 font-mono">
              <div className="flex-1">
                <label className="text-[9px] text-slate-500 font-bold uppercase">Stochastic Trials</label>
                <select 
                  value={trialsCount}
                  onChange={(e) => setTrialsCount(parseInt(e.target.value))}
                  className="mt-1 w-full p-2 bg-[#0d1117] border border-[#30363d] rounded text-xs text-white focus:outline-none"
                >
                  <option value={1000} className="bg-[#0d1117]">1,000 runs</option>
                  <option value={5000} className="bg-[#0d1117]">5,000 runs</option>
                  <option value={10000} className="bg-[#0d1117]">10,000 runs</option>
                </select>
              </div>
            </div>

            <button
              onClick={handleRunStatisticalEngines}
              disabled={runningAnalytics || runningSim}
              className="w-full py-2.5 px-4 bg-orange-500 hover:bg-orange-600 disabled:bg-[#161b22] disabled:text-slate-600 text-black font-bold text-xs rounded transition-all shadow-md flex items-center justify-center gap-2 uppercase tracking-wider font-mono cursor-pointer"
              id="run-r-engine-btn"
            >
              {runningAnalytics ? (
                <>
                  <span className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                  Running Statistical Solvers...
                </>
              ) : (
                <>
                  <Play className="w-4.5 h-4.5 fill-black" />
                  Run Statistical Optimization Engines
                </>
              )}
            </button>
          </div>

        </section>

        {/* RIGHT COLUMN: MAIN RESULTS VIEWPORT (SPAN 8) */}
        <section className="xl:col-span-8 space-y-6" id="results-column">
          
          {/* NAVIGATION BAR */}
          <div className="border border-[#21262d] bg-[#0d1117] p-2.5 rounded-xl shadow-lg flex flex-wrap gap-1.5" id="main-view-tab-strip">
            <button
              onClick={() => setActiveView('simulation')}
              className={`px-4 py-2 text-xs font-mono font-bold rounded transition-all uppercase tracking-wider ${activeView === 'simulation' ? 'bg-orange-500 text-black shadow-md' : 'text-slate-400 hover:text-white hover:bg-[#161b22]'}`}
            >
              Simulation Dashboard
            </button>
            <button
              onClick={() => setActiveView('visuals')}
              className={`px-4 py-2 text-xs font-mono font-bold rounded transition-all uppercase tracking-wider ${activeView === 'visuals' ? 'bg-orange-500 text-black shadow-md' : 'text-slate-400 hover:text-white hover:bg-[#161b22]'}`}
            >
              Visual Laboratory (R-Plots)
            </button>
            <button
              onClick={() => setActiveView('calibration')}
              className={`px-4 py-2 text-xs font-mono font-bold rounded transition-all uppercase tracking-wider ${activeView === 'calibration' ? 'bg-orange-500 text-black shadow-md' : 'text-slate-400 hover:text-white hover:bg-[#161b22]'}`}
            >
              Digital Twin Calibration
            </button>
            <button
              onClick={() => setActiveView('balances')}
              className={`px-4 py-2 text-xs font-mono font-bold rounded transition-all uppercase tracking-wider ${activeView === 'balances' ? 'bg-orange-500 text-black shadow-md' : 'text-slate-400 hover:text-white hover:bg-[#161b22]'}`}
            >
              Balances & Verification
            </button>
            <button
              onClick={() => setActiveView('advisor')}
              className={`px-4 py-2 text-xs font-mono font-bold rounded transition-all uppercase tracking-wider ${activeView === 'advisor' ? 'bg-orange-500 text-black shadow-md' : 'text-slate-400 hover:text-white hover:bg-[#161b22]'}`}
            >
              AI Research Advisor
            </button>
          </div>

          {/* VIEW CONTENT PORT */}
          {runningSim ? (
            <div className="h-120 flex flex-col items-center justify-center border border-[#21262d] bg-[#0d1117] rounded-xl shadow-lg">
              <span className="w-10 h-10 border-4 border-[#21262d] border-t-orange-500 rounded-full animate-spin" />
              <div className="text-xs text-slate-400 font-mono mt-4 uppercase tracking-wider">Solving Combustion Physics Model...</div>
              <div className="text-[10px] text-slate-500 font-mono mt-1">Newton-Raphson thermodynamic convergence active</div>
            </div>
          ) : currentOutput ? (
            <>
              {/* TAB 1: SIMULATION DASHBOARD */}
              {activeView === 'simulation' && (
                <div className="space-y-6" id="simulation-view">
                  
                  {/* Alarm panel if not green */}
                  {currentOutput.safety.status !== 'GREEN' && (
                    <div className="p-4 bg-[#1c120c] border border-amber-800/40 rounded-xl flex gap-3 text-amber-500 font-mono text-xs" id="alarms-panel">
                      <ShieldAlert className="w-5 h-5 flex-shrink-0 mt-0.5 text-amber-500" />
                      <div>
                        <div className="font-bold uppercase tracking-wider">Combustion Chamber Safety Alarms Active</div>
                        <ul className="list-disc ml-4 mt-1 space-y-1 text-[11px] text-slate-300">
                          {currentOutput.safety.alarms.map((alarm, aIdx) => (
                            <li key={aIdx}>{alarm}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  )}

                  {/* Sankey Flow */}
                  <SankeyDiagram output={currentOutput} />

                  {/* Thermodynamic & Process Property table */}
                  <div className="border border-[#21262d] bg-[#0d1117] p-6 rounded-xl shadow-lg" id="properties-grid-card">
                    <h3 className="text-xs font-bold uppercase tracking-widest text-[#e1e4e8] font-mono mb-4 border-b border-[#21262d] pb-2.5 flex items-center gap-2">
                      <BarChart3 className="w-4 h-4 text-orange-500" /> Simulated Physical Telemetry Ledger
                    </h3>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs font-mono">
                        <thead>
                          <tr className="border-b border-[#21262d] text-slate-500 font-bold uppercase text-[10px] tracking-wider">
                            <th className="pb-2.5">Telemetry Parameter</th>
                            <th className="pb-2.5">Simulated Value</th>
                            <th className="pb-2.5">Unit</th>
                            <th className="pb-2.5">Uncertainty</th>
                            <th className="pb-2.5">Model Basis</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#21262d] text-slate-300">
                          {currentOutput.metricsTable.map((item, idx) => (
                            <tr key={idx} className="hover:bg-[#161b22] transition-colors">
                              <td className="py-3 font-sans font-semibold text-slate-200">{item.parameter}</td>
                              <td className="py-3 font-mono font-bold text-orange-400">{item.value.toFixed(item.value > 1000 ? 0 : 3)}</td>
                              <td className="py-3 text-slate-400 font-mono">{item.unit}</td>
                              <td className="py-3 text-slate-500 font-mono">± {item.uncertainty.toFixed(2)} %</td>
                              <td className="py-3 font-sans text-[10px] text-slate-500">{item.model}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: VISUAL LABORATORY */}
              {activeView === 'visuals' && (
                <ChartsPanel
                  activeFuel={activeFuel}
                  currentOutput={currentOutput}
                  monteCarloData={monteCarloData}
                  sensitivityData={sensitivityData}
                  paretoData={paretoData}
                  landscapeData={landscapeData}
                />
              )}

              {/* TAB 3: DIGITAL TWIN CALIBRATION */}
              {activeView === 'calibration' && (
                <div className="border border-[#21262d] bg-[#0d1117] p-6 rounded-xl shadow-lg space-y-6" id="calibration-view">
                  <div>
                    <h3 className="text-sm font-bold uppercase tracking-widest text-[#e1e4e8] font-mono border-b border-[#21262d] pb-2.5 flex items-center gap-2">
                      <Compass className="w-4 h-4 text-orange-500" /> Digital Twin Reconciliation Console
                    </h3>
                    <p className="text-xs text-slate-400 mt-2 leading-relaxed font-mono">
                      Reconcile mathematical simulation constants against real, logged plant measurements. 
                      Entering logged values back-calculates and updates the core stoichiometric and burner heat transfer variables.
                    </p>
                  </div>

                  {/* Inputs */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-5 bg-[#161b22] border border-[#21262d] rounded-lg">
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 font-mono uppercase">Logged Flue Gas Dry O₂ Fraction (%)</label>
                      <input
                        type="number" step="0.1" min="0.1" max="20.0"
                        value={twinMeasuredStackO2}
                        onChange={(e) => setTwinMeasuredStackO2(e.target.value)}
                        className="mt-2 w-full p-2 bg-[#0d1117] border border-[#30363d] rounded text-xs font-mono text-white focus:outline-none focus:border-orange-500"
                        placeholder="e.g. 3.5%"
                      />
                      <p className="text-[9px] text-slate-500 mt-1 leading-normal font-mono">
                        Dry analyzer percentage. Triggers reverse calculation of burner excess air λ.
                      </p>
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-slate-400 font-mono uppercase">Logged Exhaust Stack Temperature (K)</label>
                      <input
                        type="number" step="10" min="300" max="1500"
                        value={twinMeasuredExhaustTemp}
                        onChange={(e) => setTwinMeasuredExhaustTemp(e.target.value)}
                        className="mt-2 w-full p-2 bg-[#0d1117] border border-[#30363d] rounded text-xs font-mono text-white focus:outline-none focus:border-orange-500"
                        placeholder="e.g. 480 K"
                      />
                      <p className="text-[9px] text-slate-500 mt-1 leading-normal font-mono">
                        Thermocouple reading. Reconciles burner convective scaling & fouling coefficients.
                      </p>
                    </div>
                  </div>

                  {/* Calibration output block */}
                  {twinMessage && (
                    <div className="p-4 bg-[#111827] border border-emerald-800/40 rounded-lg text-emerald-400 text-xs leading-relaxed font-mono">
                      <div className="font-bold flex items-center gap-1.5 mb-1 text-emerald-500 uppercase tracking-wider text-[10px]">
                        <CheckCircle2 className="w-4 h-4" /> Twin Reconciliation Success
                      </div>
                      <div dangerouslySetInnerHTML={{ __html: twinMessage.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') }} />
                    </div>
                  )}

                  {/* Calibration Action Trigger */}
                  <button
                    onClick={handleCalibrateDigitalTwin}
                    className="w-full py-2.5 bg-orange-500 hover:bg-orange-600 text-black font-bold text-xs rounded transition-colors shadow-md flex items-center justify-center gap-2 uppercase tracking-wider font-mono cursor-pointer"
                    id="calibrate-twin-btn"
                  >
                    <Compass className="w-4 h-4" />
                    Synchronise Simulation against Plant Measurements
                  </button>
                </div>
              )}

              {/* TAB 4: BALANCES & VERIFICATION */}
              {activeView === 'balances' && (
                <div className="space-y-6" id="balances-view">
                  <div className="border border-[#21262d] bg-[#0d1117] p-6 rounded-xl shadow-lg">
                    <h3 className="text-xs font-bold uppercase tracking-widest text-[#e1e4e8] font-mono border-b border-[#21262d] pb-2.5 flex items-center gap-2 mb-4">
                      <Award className="w-4 h-4 text-orange-500" /> Mass, Energy & Elemental Closure Ledger
                    </h3>
                    <p className="text-xs text-slate-400 leading-relaxed font-mono mb-6">
                      Rigorously audits thermodynamic boundary conditions, ensuring there are no numerical leaks in mass flows, element balances, or energy values.
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 font-mono text-xs">
                      <div className="p-4 border border-[#21262d] bg-[#161b22] rounded text-center">
                        <div className="text-[9px] text-slate-500 uppercase font-bold tracking-wider mb-2">Mass Closure Error</div>
                        <div className="text-md font-bold text-orange-400">{currentOutput.massBalance.error.toFixed(8)} kg/s</div>
                        <div className="text-[9px] text-emerald-400 font-bold mt-1.5 uppercase tracking-wider">CLOSED (error &lt; 1e-6)</div>
                      </div>

                      <div className="p-4 border border-[#21262d] bg-[#161b22] rounded text-center">
                        <div className="text-[9px] text-slate-500 uppercase font-bold tracking-wider mb-2">Energy Balance Error</div>
                        <div className="text-md font-bold text-orange-400">{currentOutput.energyBalance.error.toFixed(6)} MW</div>
                        <div className="text-[9px] text-emerald-400 font-bold mt-1.5 uppercase tracking-wider">CLOSED (error &lt; 1e-4)</div>
                      </div>

                      <div className="p-4 border border-[#21262d] bg-[#161b22] rounded text-center">
                        <div className="text-[9px] text-slate-500 uppercase font-bold tracking-wider mb-2">Element Recovery Closure</div>
                        <div className="text-md font-bold text-orange-400">100.0000 %</div>
                        <div className="text-[9px] text-emerald-400 font-bold mt-1.5 uppercase tracking-wider">CONVERGED (Newton-Raphson)</div>
                      </div>
                    </div>
                  </div>

                  {/* Detailed Chemistry spec table */}
                  <div className="border border-[#21262d] bg-[#0d1117] p-6 rounded-xl shadow-lg">
                    <h3 className="text-xs font-bold uppercase tracking-widest text-[#e1e4e8] font-mono border-b border-[#21262d] pb-2.5 flex items-center gap-2 mb-4">
                      <Cpu className="w-4 h-4 text-orange-500" /> Dry Exhaust Flue Gas Spec Breakdown
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono text-xs text-slate-400">
                      {Object.keys(currentOutput.exhaustComposition.dryVolumeFraction).map((species, sIdx) => {
                        const val = currentOutput.exhaustComposition.dryVolumeFraction[species] * 100;
                        return (
                          <div key={sIdx} className="p-3 bg-[#161b22] border border-[#21262d] rounded">
                            <div className="text-slate-500 text-[9px] font-bold uppercase tracking-wider">{species}</div>
                            <div className="text-sm font-bold text-orange-400 mt-1">
                              {val > 0.01 ? `${val.toFixed(3)} %` : `${(val * 10000).toFixed(1)} ppm`}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 5: AI RESEARCH ADVISOR */}
              {activeView === 'advisor' && (
                <DiagnosticsPanel currentOutput={currentOutput} />
              )}
            </>
          ) : (
            <div className="h-120 flex items-center justify-center border border-[#21262d] bg-[#0d1117] rounded-xl shadow-lg">
              <span className="text-xs text-slate-500 font-mono uppercase tracking-wider">Please initiate a simulation run to load telemetry.</span>
            </div>
          )}

        </section>

      </main>

      {/* FOOTER */}
      <footer className="bg-[#0d1117] text-slate-500 py-8 border-t border-[#21262d] text-xs mt-12" id="lab-footer">
        <div className="mx-auto max-w-7xl px-6 text-center space-y-2 font-mono">
          <p className="font-semibold text-slate-400 uppercase tracking-wider">Fossil-Fuel Combustion & Energy Optimisation Laboratory • Computational Research Platform</p>
          <p className="text-[10px] text-slate-500 max-w-2xl mx-auto leading-relaxed">
            This platform serves as an advanced chemical thermodynamics and process optimization model. 
            All adiabatic flame temperature, dissociation kinetics, Brayton/Rankine thermodynamic cycle math, and stochastic risk analyses are computed using strict SI physical guidelines.
          </p>
          <p className="text-[9px] text-slate-600 pt-4">© 2026 Google AI Studio Build. All Rights Reserved.</p>
        </div>
      </footer>

    </div>
  );
}
